"""Qosha makes pictures with the AI accounts the person already connected (Ren, 22 Nov 2026: "I want Qosha to be able
to use the models we have available, and ask them to make something ... and posts it on the chat").

The engine's own picture tool (image_generate) stays off until a picture backend is chosen in its settings, so Qosha
answered that its AI links were text only. Here Qosha registers ONE backend of its own, "qosha", and makes it the
default when the person has not chosen one. It never spends pay-per-use money: it uses subscriptions only, best first:
  1. ChatGPT sign-in: the engine's own "openai-codex" backend (gpt-image-2 through the ChatGPT plan; no API key), only
     when the sign-in's own token goes to ChatGPT's own address;
  2. Gemini sign-in (connected in Qosha): Google's agy, run as an agent whose ONLY tool is its picture tool
     (generate_image), sandboxed, with Qosha's no-tools settings for everything else, in a fresh folder, without any
     API key or Qosha session token in its environment.
A backend the person chose themselves (image_gen.provider, image_gen.use_gateway or image_gen.model in config.yaml) is
used as they chose; Qosha never switches to it on its own. While Qosha's default is in effect the engine's pay-per-use
picture paths refuse. When no subscription can make the picture the tool says so plainly.
Slice 1 (contract IMAGEGEN-S1): making pictures only; a request to change an existing picture is refused plainly.
Each picture is copied into the person's Qosha files folder (a project chat's: that project's folder), never over a
file, and shown in the chat with a MEDIA line (qosha-media.js). Same on Mac and Windows. Stop and ended access end
everything. Fail-open for set-up: if anything here cannot be set up, the engine behaves as before (tool off)."""
from __future__ import annotations

import dataclasses
import json
import logging
import os
import re
import secrets
import shutil
import stat
import subprocess
import tempfile
import threading
import time
import unicodedata
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

log = logging.getLogger("qosha.imagegen")

NAME = "qosha"
ENABLED = True                       # the feature switch (slice 1: off; slice 4, 1.20.19: on)
GEMINI_TIMEOUT = 240                 # seconds for one Gemini picture (Google took 22-55 s in tests on 22 Nov 2026)
MAX_BYTES = 25 * 1024 * 1024
MAX_PROMPT = 4000                    # characters in one picture request (F-AGY 15)
_IMAGE_MAGIC = ((b"\x89PNG\r\n\x1a\n", "png"), (b"\xff\xd8\xff", "jpg"), (b"RIFF", "webp"), (b"GIF87a", "gif"),
                (b"GIF89a", "gif"))
_PICTURE_SUFFIXES = (".png", ".jpg", ".jpeg", ".webp")
_NOT_DEFERRED = "image_generate"
_DASH_PREFIX = "HERMES_DASHBOARD_"
_SECRET_SUFFIXES = ("_API_KEY", "_TOKEN", "_SECRET")

NONE_CONNECTED = ("None of the AI accounts connected to Qosha can make pictures right now. Connect ChatGPT (or "
                  "Gemini) in AI accounts and ask again; Claude's sign-in makes text only.")
EDIT_NOT_YET = ("Changing an existing picture isn't available yet; I can make a new picture from a description "
                "instead.")
ACCESS_ENDED = "Your access to Qosha has ended, so Qosha can't make pictures."
STOPPED = "The picture was stopped."
TOO_LONG = ("That picture request is too long (more than 4,000 characters). Describe the picture more briefly and "
            "ask again.")
NO_FOLDER = ("Qosha's files folder isn't available right now, so no picture was made. Check the files folder in "
             "Qosha's settings and ask again.")
SAVE_FAILED = ("The picture was made, but Qosha couldn't save it in your files, so it isn't shown. Check that your "
               "files folder can be changed and ask again.")
PAID_REFUSED = ("Qosha couldn't make the picture just now. Qosha uses only your connected ChatGPT or Gemini "
                "subscriptions for pictures; ask again in a moment.")
CHATGPT_FAILED = "ChatGPT couldn't make this picture just now."
CHATGPT_LIMIT = ("ChatGPT's plan has reached its picture limit for now (it counts against the plan's limits); "
                 "it resets after a while.")
CHATGPT_SIGNIN = "ChatGPT's sign-in in Qosha needs to be connected again (AI accounts)."
CHATGPT_NOT_CONNECTED = "ChatGPT isn't connected in AI accounts."
GEMINI_NOT_SET_UP = "Gemini is not set up on this computer."
GEMINI_NOT_SIGNED_IN = "Gemini is not signed in on this computer yet."
GEMINI_UNREACHABLE = "Qosha could not reach Gemini just now."
GEMINI_UNSAFE = "Gemini couldn't start safely."
GEMINI_PREP = "Qosha could not prepare Gemini's safe settings."
GEMINI_START = "Gemini could not start on this computer just now."
GEMINI_SLOW = "Gemini took too long to make the picture."
GEMINI_OTHER = "Gemini tried to do something other than make the picture, so Qosha stopped it."
GEMINI_MANY = "Gemini tried to make more than one picture, so Qosha stopped it and kept none."
GEMINI_UNCLEAR = "Gemini didn't show clearly which picture it was making, so Qosha stopped it and kept none."
GEMINI_LIMIT = ("Gemini's plan has reached its limit for now (it counts against the plan's limits); it resets after "
                "a while.")
GEMINI_NO_PICTURE = "Gemini couldn't make this picture just now (Google sent no picture back)."
GEMINI_ELSEWHERE = "Gemini's picture was not in Gemini's own folder, so Qosha did not use it."
GEMINI_NO_WORKSPACE = "Qosha could not prepare a place for Gemini to work just now."
GEMINI_NAMES_FILE = ("Gemini isn't given requests that name a file or folder on this computer, so Qosha didn't send "
                     "it. Describe the picture in words only and ask again.")
NOT_AVAILABLE = "Qosha's picture maker isn't available just now, so no picture was made. Ask again in a moment."
NOT_MADE = "Qosha couldn't make the picture just now. Ask again in a moment."

GEMINI_AGENT = """---
name: {name}
description: "Qosha's picture maker: one picture with the picture tool, nothing else."
tools: [generate_image]
mainAgent: true
subagent: false
inheritMcp: false
excludeDefaultComponents: true
---

# Qosha picture maker

Make exactly one picture with the generate_image tool for the request you are given. Use no other tool. Then reply with
only the word DONE.
"""


# --- Stop and access (F-STOP) --------------------------------------------------------------------------------------
def _gate():
    """gemini_cli (access check, agy helpers), loaded lazily so a broken Gemini module never blocks ChatGPT."""
    try:
        from . import gemini_cli
        return gemini_cli
    except Exception:
        return None


def _access_ended() -> bool:
    g = _gate()
    if g is None:
        return True
    try:
        return bool(g._access_gate())
    except Exception:
        return True


def _interrupted() -> bool:
    """The person pressed Stop for this turn (the engine's per-thread interrupt)."""
    try:
        from tools.interrupt import is_interrupted
        return bool(is_interrupted())
    except Exception:
        return False


def _halt(access: bool = True) -> str:
    """The plain reason to stop now ("" to go on): access ended (fails closed) or Stop pressed."""
    if access and _access_ended():
        return ACCESS_ENDED
    if _interrupted():
        return STOPPED
    return ""


# --- where pictures go (F-SAVE) ------------------------------------------------------------------------------------
def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        h = os.environ.get("HERMES_HOME")
        return Path(h) if h else Path.home() / ".hermes"


def _network(p: str) -> bool:
    """A Windows network or device path (\\\\server\\share, //server/share): never used, as in media_api, since Windows
    would contact another computer just to resolve it."""
    return p.startswith("\\\\") or p.startswith("//") or p.startswith("\\/") or p.startswith("/\\")


def _junction(p) -> bool:
    try:
        return bool(getattr(Path(p), "is_junction", lambda: False)())
    except OSError:
        return True


def _linked(p) -> bool:
    try:
        return os.path.islink(str(p)) or _junction(p)
    except OSError:
        return True


def files_folder() -> Optional[Path]:
    """The person's Qosha files folder (the one the Files page and the chat's pictures use): the configured folder, else
    the home's files/ (made when missing). A configured folder that is missing is never replaced by another one; a
    network folder is never used."""
    f = os.environ.get(_DASH_PREFIX + "FILES_ROOT", "").strip()
    if f:
        if _network(f) or not os.path.isabs(f):
            return None
        return Path(f) if os.path.isdir(f) else None
    home = _home()
    if _network(str(home)):
        return None
    d = home / "files"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except OSError:
        return None
    return d if d.is_dir() else None


def _session_cwd() -> str:
    try:
        from agent.runtime_cwd import scoped_session_cwd
        return str(scoped_session_cwd() or "")
    except Exception:
        return ""


def _project_slug(cwd: str, root: str) -> Optional[str]:
    """projects_scope.project_of's rule, with this system's separators: the project's slug when the turn's working
    folder is <files>/Projects/<slug> (or inside it), else None."""
    if not cwd or not root:
        return None
    try:
        from .projects_scope import SLUG_RE
    except Exception:
        return None
    base = os.path.join(root, "Projects")
    nb = os.path.normcase(base)
    for c in (os.path.normpath(cwd), os.path.realpath(cwd)):
        nc = os.path.normcase(c)
        if nc.startswith(nb + os.sep):
            slug = c[len(base) + 1:].split(os.sep, 1)[0]
            return slug if SLUG_RE.match(slug) else None
    return None


def destination() -> Optional[Path]:
    """The folder this turn's picture goes to, checked BEFORE any account is asked: the files folder, or a project
    chat's own project folder. None when it can't be used (the picture is then not made at all)."""
    folder = files_folder()
    if folder is None:
        return None
    try:
        root = os.path.realpath(str(folder))
    except (OSError, ValueError):
        return None
    if _network(str(folder)) or _network(root) or not os.path.isdir(root):
        return None
    slug = _project_slug(_session_cwd(), root)
    if not slug:
        return Path(root)
    projects = os.path.join(root, "Projects")
    target = os.path.join(projects, slug)
    for p in (projects, target):
        if _linked(p) or not os.path.isdir(p):
            return None                  # a project chat's picture never goes anywhere else
    if os.path.normcase(os.path.realpath(target)) != os.path.normcase(target):
        return None
    return Path(target)


def _kind(raw: bytes) -> Optional[str]:
    for magic, ext in _IMAGE_MAGIC:
        if raw.startswith(magic) and (ext != "webp" or raw[8:12] == b"WEBP"):
            return ext
    return None


def _read_picture(p: Path) -> bytes:
    """At most MAX_BYTES + 1 bytes of a regular file that is not a link (O_NOFOLLOW where the system has it)."""
    if _linked(p):
        raise ValueError("linked file")
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(str(p), flags)
    with os.fdopen(fd, "rb") as fh:
        if not stat.S_ISREG(os.fstat(fh.fileno()).st_mode):
            raise ValueError("not a regular file")
        return fh.read(MAX_BYTES + 1)


def keep(src: str, folder: Optional[Path] = None) -> Path:
    """Copies a made picture into `folder` (default: destination()) as picture-YYYYMMDD-HHMMSS[-n].<ext>; returns the
    new path. Never overwrites a file; a half-written copy is removed. Raises ValueError for anything that is not a
    picture (checked by its bytes), too big or a link, OSError when it cannot be saved."""
    p = Path(src)
    try:
        raw = _read_picture(p)
    except OSError as exc:
        raise ValueError("no picture file") from exc
    if not raw or len(raw) > MAX_BYTES:
        raise ValueError("picture too big or empty")
    ext = _kind(raw)
    if not ext:
        raise ValueError("not a picture")
    if folder is None:
        folder = destination()
    if folder is None:
        raise OSError("files folder not available")
    stem = "picture-" + time.strftime("%Y%m%d-%H%M%S")
    for n in range(1, 1000):
        dest = Path(folder) / ("%s%s.%s" % (stem, "" if n == 1 else "-%d" % n, ext))
        try:
            fh = open(dest, "xb")           # never overwrites a file of the person's (nor follows a link there)
        except FileExistsError:
            continue
        try:
            with fh:
                fh.write(raw)
        except BaseException:
            try:
                os.unlink(dest)
            except OSError:
                pass
            raise
        return dest
    raise OSError("no free file name")


def media_line(path: str) -> str:
    """The chat's MEDIA line; a path with white space is quoted."""
    return 'MEDIA:"%s"' % path if any(c.isspace() for c in path) else "MEDIA:" + path


# --- ChatGPT (F-PAID) ----------------------------------------------------------------------------------------------
def _codex():
    """The engine's ChatGPT-sign-in picture backend, or None."""
    try:
        from tools.image_generation_tool import _get_plugin_provider
        return _get_plugin_provider("openai-codex")
    except Exception:
        return None


def _chatgpt_credential() -> Optional[Tuple[str, str]]:
    """(token, address) only when the engine's resolved ChatGPT credential is the auth.json sign-in's own access token
    AND it goes to ChatGPT's official address; else None (a pooled key, another address: the route is not available).
    The request is then sent with exactly this pair (never resolved a second time)."""
    try:
        from agent.auxiliary_client import _read_codex_singleton_token, _resolve_codex_credential_and_base
        from agent.codex_headers import is_official_codex_base_url
        token, base = _resolve_codex_credential_and_base()
        own = _read_codex_singleton_token()
        if not isinstance(token, str) or not isinstance(own, str) or not token.strip() or not own.strip():
            return None
        base = str(base or "")
        if secrets.compare_digest(token.strip(), own.strip()) and is_official_codex_base_url(base):
            return token.strip(), base
    except Exception:
        pass
    return None


def _chatgpt_signed_in() -> bool:
    return _chatgpt_credential() is not None


def _codex_parts(p) -> Optional[tuple]:
    """The engine's ChatGPT backend's own request pieces (from its module), so the request goes out with the credential
    Qosha checked: (post, model, size, save). None when they can't be found (no request is made then)."""
    try:
        ns = type(p).generate.__globals__
        parts = tuple(ns[k] for k in ("_post_image_request", "_resolve_model", "size_for", "save_b64_image"))
    except Exception:
        return None
    return parts if all(callable(x) for x in parts) else None


def chatgpt_ready() -> bool:
    if not _chatgpt_signed_in():
        return False
    p = _codex()
    try:
        return bool(p is not None and p.is_available())
    except Exception:
        return False


def _plain_chatgpt_error(res: dict) -> str:
    err = str(res.get("error") or "")
    low = err.lower()
    if "http 429" in low or "usage limit" in low or "rate limit" in low or "usage_limit" in low or "quota" in low:
        return CHATGPT_LIMIT
    if "http 401" in low or "http 403" in low or res.get("error_type") == "auth_required":
        return CHATGPT_SIGNIN
    return CHATGPT_FAILED


def via_chatgpt(prompt: str, aspect: str) -> dict:
    """One ChatGPT picture, sent with the very token and address checked here. {"ok": True, "path", ...} or
    {"ok": False, "plain"[, "made"]}; "made" = a picture came back but could not be saved (no second account then)."""
    p = _codex()
    cred = _chatgpt_credential() if p is not None else None     # checked right before the request, and bound to it
    if p is None or cred is None:
        return {"ok": False, "plain": CHATGPT_NOT_CONNECTED}
    parts = _codex_parts(p)
    if parts is None:
        log.warning("ChatGPT picture backend pieces not found; no request made")
        return {"ok": False, "plain": CHATGPT_FAILED}
    post, model_of, size_of, save = parts
    token, base = cred
    try:
        tier, meta = model_of()
        payload = post(token, prompt=prompt, size=size_of(aspect), quality=meta["quality"], base_url=base)
    except Exception as exc:
        log.info("ChatGPT picture refused: %s", type(exc).__name__)
        return {"ok": False, "plain": _plain_chatgpt_error({"error": str(exc)})}
    why = _halt()                       # Stop or ended access while ChatGPT worked: nothing is written anywhere
    if why:
        return {"ok": False, "plain": why, "stop": True}
    data = payload.get("data") if isinstance(payload, dict) else None
    b64 = data[0].get("b64_json") if isinstance(data, list) and data and isinstance(data[0], dict) else None
    if not isinstance(b64, str) or not b64:
        log.info("ChatGPT picture refused: no picture in the answer")
        return {"ok": False, "plain": CHATGPT_FAILED}
    try:
        saved = save(b64, prefix="qosha_chatgpt")
    except Exception as exc:                                    # made, but not saved: the request ends here
        log.warning("ChatGPT picture not cached: %s", type(exc).__name__)
        return {"ok": False, "plain": SAVE_FAILED, "made": True}
    return {"ok": True, "path": str(saved), "model": str(tier or "gpt-image-2"), "by": "ChatGPT"}


# --- Gemini (F-CONSENT, F-AGY) -------------------------------------------------------------------------------------
def _agy_path() -> str:
    g = _gate()
    if g is None:
        return ""
    try:
        name, path = g.find()
    except Exception:
        return ""
    return path if name == "agy" and path else ""


def gemini_ready() -> bool:
    """agy present AND Gemini connected in Qosha (Qosha's own marker): a disconnected account is never used."""
    g = _gate()
    if g is None or not _agy_path():
        return False
    try:
        return bool(g.connected())
    except Exception:
        return False


_NAMES_A_FILE = re.compile(
    r"(?<![a-z])file:(?!\s)"                          # file: links (also my_file:, x-file:)
    r"|~[\\/]"                                        # ~/ anywhere (use~/Desktop, -~/Desktop)
    r"|~[a-z_][\w.-]*[\\/]"                           # ~name/
    r"|(?<![a-z0-9])[a-z]:[\\/]"                      # drive letters (C:\, c:/)
    r"|\\\\|\\/|/\\"                                  # network shares (\\server\share) and mixed separators
    r"|(?<!https:)(?<!http:)//"                       # //server/share (only a web link's // is fine)
    r"|(?<![\w%\\/])[\\/](?=[^\s\\/])"                # a token that starts at the root, whatever comes after it
                                                      # (/Users, /@x, /(x), /$x; also image:/Users, path:\Users)
    r"|(?<![\w.])\.{1,2}[\\/]"                        # ./ and ../
    r"|(?:\$\{?[a-z_]\w*\}?|%[a-z_]\w*%)[\\/]"        # $HOME/, %USERPROFILE%\
    r"|[\"'`\u2018\u2019\u201c\u201d(\[<{]\s*[\\/~]\s*[\"'`\u2018\u2019\u201c\u201d)\]>}]"   # a quoted root: '/', "\", (~)
    r"|\b(?:folder|director(?:y|ies)|dir|path|root|drive|disk|volume|location)s?\s*[:=]?\s*[\\/](?![\w.~-])"
                                                      # the root named as a folder: "the folder /", "path: /"
    r"|\A\s*[\\/~]\s*\Z",                             # the request is just a root
    re.IGNORECASE)


def names_a_file(text: str) -> bool:
    """The request text names a file or folder on this computer. Google's picture tool reads a picture from any
    absolute path named in the request, even outside its folder and with file reading denied, so such a request is
    never given to Gemini. Ordinary text with a slash (50/50, red/blue) or a ratio (3:4) is fine."""
    t = unicodedata.normalize("NFKC", text or "")
    t = "".join(c for c in t if unicodedata.category(c) != "Cf")       # no invisible characters in between
    return bool(_NAMES_A_FILE.search(t))


def _clean_env(env: Dict[str, str]) -> Dict[str, str]:
    """agy's environment without pay-per-use keys or Qosha's own session tokens."""
    out = {}
    for k, v in env.items():
        u = str(k).upper()
        if u.endswith(_SECRET_SUFFIXES) or u == "FAL_KEY" or u.startswith(_DASH_PREFIX):
            continue
        out[k] = v
    return out


def _models_ok(g, path: str, env: Dict[str, str]) -> dict:
    """gemini_cli._usable's check (`agy models`, which never opens a sign-in), with the cleaned environment. Stop and
    ended access end the listing at once (checked while it runs, as in the picture run's wait)."""
    proc = None
    readers: list = []
    outs: list = []
    errs: list = []
    try:                     # stdin: an empty pipe, closed at once (as for the picture run), not the null device
        proc = subprocess.Popen([path, "models"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=False, env=env, **g._spawn_kw())
        try:
            proc.stdin.close()
        except (OSError, ValueError):
            pass
        readers = [threading.Thread(target=g._drain, args=(proc.stdout, outs), daemon=True),
                   threading.Thread(target=g._drain, args=(proc.stderr, errs), daemon=True)]
        for t in readers:
            t.start()
        end = time.monotonic() + 30
        n = 0
        while proc.poll() is None:
            why = _halt(access=(n % 5 == 0))         # Stop every 0.2 s, access every second: the listing ends at once
            n += 1
            if why:
                return {"ok": False, "plain": why, "stop": True}
            if time.monotonic() > end:
                log.warning("Gemini model list took too long")
                return {"ok": False, "plain": GEMINI_UNREACHABLE}
            time.sleep(0.2)
        _reap(g, proc, readers)                      # all of its output read before it is judged
        code = proc.returncode
    except Exception as exc:
        log.warning("Gemini model list could not run: %s", type(exc).__name__)
        return {"ok": False, "plain": GEMINI_UNREACHABLE}
    finally:
        _reap(g, proc, readers)
    stdout = b"".join(outs)
    text = (stdout + b"".join(errs)).decode("utf-8", "replace").lower()
    if "please sign in" in text or "not logged in" in text or "not signed in" in text:
        return {"ok": False, "plain": GEMINI_NOT_SIGNED_IN}
    if code != 0 or not g._ROW.search(stdout):
        log.warning("Gemini model list unusable (exit %s)", code)
        return {"ok": False, "plain": GEMINI_UNREACHABLE}
    return {"ok": True}


class _Watch:
    """agy's stream-json as it arrives, whole lines only: tool steps (any tool but generate_image counts as other; each
    distinct generate_image step_index counts once; a picture step without a valid step_index is refused) and the
    result event. Every conversation id seen is kept, so a refused run's pictures can be found and removed."""

    def __init__(self, chunks: list):
        self.chunks, self.used, self.buf = chunks, 0, b""
        self.other, self.steps, self.result = False, set(), None
        self.unindexed, self.convs = False, set()

    @staticmethod
    def _index(v) -> Optional[int]:
        """A step_index that names one step: a whole number from 0 (digits as text count the same); else None."""
        if isinstance(v, bool):
            return None
        if isinstance(v, int):
            return v if v >= 0 else None
        if isinstance(v, str) and v.isascii() and v.isdigit():
            return int(v)
        return None

    def _conv(self, d) -> None:
        c = d.get("conversation_id") if isinstance(d, dict) else None
        if isinstance(c, str) and c:
            self.convs.add(c)

    def feed(self) -> None:
        n = len(self.chunks)            # the reader thread only appends
        if n > self.used:
            self.buf += b"".join(self.chunks[self.used:n])
            self.used = n
            *lines, self.buf = self.buf.split(b"\n")
            for ln in lines:
                self._line(ln)

    def finish(self) -> None:
        self.feed()
        if self.buf:
            self._line(self.buf)
            self.buf = b""

    def _line(self, ln: bytes) -> None:
        ln = ln.strip()
        if not ln.startswith(b"{"):
            return
        try:
            ev = json.loads(ln)
        except ValueError:
            return
        if not isinstance(ev, dict):
            return
        self._conv(ev)
        su = ev.get("step_update")
        self._conv(su)
        if isinstance(su, dict) and (su.get("step_type") == "tool" or su.get("tool_name")):
            if str(su.get("tool_name") or "") != "generate_image":
                self.other = True
            else:
                i = self._index(su.get("step_index"))
                if i is None:
                    self.unindexed = True            # no identifiable picture step: refused (fail closed)
                else:
                    self.steps.add(i)
            return
        if ev.get("event") == "result" and isinstance(ev.get("result"), dict):
            self.result = ev["result"]
            self._conv(self.result)


_CONV = re.compile(r"^[0-9a-fA-F-]{8,64}$")


def _brain_picture(conv: str, started: float) -> Tuple[Optional[Path], str]:
    """The one picture agy's picture tool saved for this run in ~/.gemini/antigravity-cli/brain/<conversation>:
    (path, "") or (None, the plain reason). No link anywhere on the way; nothing from before the run's start; exactly
    one picture."""
    if not _CONV.match(conv or ""):
        return None, GEMINI_NO_PICTURE
    home = Path.home()
    brain = home / ".gemini" / "antigravity-cli" / "brain"
    folder = brain / conv
    found = []
    try:
        for p in (home / ".gemini", home / ".gemini" / "antigravity-cli", brain, folder):
            if _linked(p):
                return None, GEMINI_ELSEWHERE
        if not folder.is_dir():
            return None, GEMINI_NO_PICTURE
        real_folder = os.path.normcase(os.path.realpath(str(folder)))
        if real_folder != os.path.normcase(os.path.join(os.path.realpath(str(brain)), conv)):
            return None, GEMINI_ELSEWHERE
        for f in folder.iterdir():
            if f.suffix.lower() not in _PICTURE_SUFFIXES:
                continue
            st = os.lstat(str(f))
            if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode) or _junction(f):
                return None, GEMINI_ELSEWHERE
            if st.st_mtime <= started:
                continue                 # from before this run's actual start, or not provably after it: never used
            if os.path.normcase(os.path.dirname(os.path.realpath(str(f)))) != real_folder:
                return None, GEMINI_ELSEWHERE
            found.append(f)
    except OSError:
        return None, GEMINI_NO_PICTURE
    if len(found) != 1:
        return None, GEMINI_NO_PICTURE
    return found[0], ""


def _drop_run_pictures(convs, started: Optional[float]) -> None:
    """A refused run's pictures are not left behind: in each conversation folder this run named, inside
    ~/.gemini/antigravity-cli/brain with no link on the way, the regular picture files written after this run started
    are removed. Nothing else is touched: no file from before the run, no link, nothing outside Gemini's own folder."""
    if started is None:
        return
    home = Path.home()
    brain = home / ".gemini" / "antigravity-cli" / "brain"
    for conv in sorted(c for c in (convs or ()) if isinstance(c, str)):
        if not _CONV.match(conv):
            continue
        folder = brain / conv
        try:
            if any(_linked(p) for p in (home / ".gemini", home / ".gemini" / "antigravity-cli", brain, folder)):
                continue
            if not folder.is_dir():
                continue
            real_folder = os.path.normcase(os.path.realpath(str(folder)))
            if real_folder != os.path.normcase(os.path.join(os.path.realpath(str(brain)), conv)):
                continue
            for f in list(folder.iterdir()):
                if f.suffix.lower() not in _PICTURE_SUFFIXES:
                    continue
                try:
                    st = os.lstat(str(f))
                    if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode) or _junction(f):
                        continue
                    if st.st_mtime <= started:
                        continue             # from before this run: never this run's, never removed
                    os.unlink(str(f))
                except OSError:
                    continue
        except OSError:
            continue


def _reap(g, proc, readers: list) -> None:
    """Ends agy if it still runs, waits for it (bounded), lets the readers finish and closes its pipes."""
    if proc is None:
        return
    if proc.poll() is None:
        g._kill(proc)
    try:
        proc.wait(10)
    except Exception:
        pass
    for t in readers:
        t.join(5)
    for s in (proc.stdin, proc.stdout, proc.stderr):
        try:
            if s is not None:
                s.close()
        except Exception:
            pass


def via_gemini(prompt: str, aspect: str) -> dict:
    """One agy run that may only make one picture. {"ok": True, "path", ...} or {"ok": False, "plain"[, "stop"]}."""
    g = _gate()
    path = _agy_path()
    if g is None or not path:
        return {"ok": False, "plain": GEMINI_NOT_SET_UP}
    if not gemini_ready():
        return {"ok": False, "plain": NONE_CONNECTED}
    if names_a_file(prompt):                        # before anything of Google's runs
        log.warning("Gemini picture request names a file or folder; not sent")
        return {"ok": False, "plain": GEMINI_NAMES_FILE}
    why = _halt()
    if why:
        return {"ok": False, "plain": why, "stop": True}
    qenv = g._quiet_env()
    if qenv is None:                                # never where it could open a browser (fail closed)
        return {"ok": False, "plain": GEMINI_UNSAFE}
    env = _clean_env(qenv)
    u = _models_ok(g, path, env)
    if not u.get("ok"):
        return u
    try:
        block = str(g._text_only_settings())        # strict permission; every other tool kind denied
    except OSError:
        return {"ok": False, "plain": GEMINI_PREP}
    why = _halt()
    if why:
        return {"ok": False, "plain": why, "stop": True}
    if not gemini_ready():                          # disconnected while the model list ran: no picture run
        return {"ok": False, "plain": NONE_CONNECTED}
    try:
        work = tempfile.mkdtemp(prefix="qosha-gemini-img-")
    except OSError as exc:
        log.warning("Gemini picture run folder not made: %s", type(exc).__name__)
        return {"ok": False, "plain": GEMINI_NO_WORKSPACE}
    proc = None
    readers: list = []
    watch = None
    started = None
    kept_ok = False
    convs: set = set()
    try:
        agent = "qosha-picture-" + secrets.token_hex(6)
        d = Path(work) / ".agents" / "agents"
        d.mkdir(parents=True, exist_ok=True)
        (d / (agent + ".md")).write_text(GEMINI_AGENT.format(name=agent), encoding="utf-8")
        shape = {"landscape": "wide (landscape, about 16:9)", "portrait": "tall (portrait, about 9:16)",
                 "square": "square (1:1)"}.get(aspect, "wide (landscape)")
        ask = ("Make one picture with the generate_image tool. Shape: %s.\nPicture request:\n%s\n" % (shape, prompt))
        argv = [path, "--output-format", "stream-json", "--print-timeout", "%ds" % (GEMINI_TIMEOUT - 20), "--sandbox",
                "--settings", block, "--agent", agent, "--disable-slash-commands"]
        started = time.time()
        proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=work,
                                shell=False, env=env, **g._spawn_kw())
        outs: list = []
        errs: list = []
        readers = [threading.Thread(target=g._drain, args=(proc.stdout, outs), daemon=True),
                   threading.Thread(target=g._drain, args=(proc.stderr, errs), daemon=True)]
        for t in readers:
            t.start()
        watch = _Watch(outs)
        why = _halt()                               # Stop or access while agy was starting: nothing handed over
        if why:
            return {"ok": False, "plain": why, "stop": True}
        if not gemini_ready():                      # still connected right before the request is handed over
            return {"ok": False, "plain": NONE_CONNECTED}
        threading.Thread(target=g._write_stdin, args=(proc, ask.encode("utf-8")), daemon=True).start()
        end = time.monotonic() + GEMINI_TIMEOUT
        n = 0
        while proc.poll() is None:
            if time.monotonic() > end:
                return {"ok": False, "plain": GEMINI_SLOW}
            why = _halt(access=(n % 5 == 0))         # Stop every 0.2 s, access every second: agy is ended at once
            n += 1
            if why:
                return {"ok": False, "plain": why, "stop": True}
            watch.feed()
            if watch.other or watch.unindexed or len(watch.steps) > 1:   # one known picture step, the picture tool
                break                                                    # only (fail closed)
            if g._signin_seen(outs, errs):
                break
            time.sleep(0.2)
        _reap(g, proc, readers)
        watch.finish()
        out = b"".join(outs).decode("utf-8", "replace")
        err = b"".join(errs).decode("utf-8", "replace")
        if watch.other:
            log.warning("Gemini picture run used another tool; nothing kept")
            return {"ok": False, "plain": GEMINI_OTHER}
        if len(watch.steps) > 1:
            log.warning("Gemini picture run made more than one picture; nothing kept")
            return {"ok": False, "plain": GEMINI_MANY}
        if watch.unindexed:
            log.warning("Gemini picture step without a step index; nothing kept")
            return {"ok": False, "plain": GEMINI_UNCLEAR}
        if g._signin_seen(outs, errs):               # checked again after the run ended
            return {"ok": False, "plain": GEMINI_NOT_SIGNED_IN}
        why = _halt()
        if why:
            return {"ok": False, "plain": why, "stop": True}
        res = watch.result if watch.result is not None else g._envelope(out)
        if isinstance(res, dict):
            convs.add(str(res.get("conversation_id") or ""))      # also an answer without a result event
        good =(proc.returncode == 0                 # a run that exited with an error is never a success
                and isinstance(res, dict) and str(res.get("status") or "").upper() == "SUCCESS" and not res.get("error")
                and not res.get("denied_actions") and not res.get("is_error"))
        if not good:
            low = (out + " " + err).lower()
            if "resource_exhausted" in low or "quota" in low or "rate limit" in low or "usage limit" in low:
                return {"ok": False, "plain": GEMINI_LIMIT}
            return {"ok": False, "plain": GEMINI_NO_PICTURE}
        if len(watch.steps) != 1:
            return {"ok": False, "plain": GEMINI_NO_PICTURE}
        conv = str(res.get("conversation_id") or "")
        pic, why = _brain_picture(conv, started)
        if pic is None:
            return {"ok": False, "plain": why}
        kept_ok = True
        return {"ok": True, "path": str(pic), "model": "Gemini", "by": "Gemini", "conv": conv, "started": started}
    except OSError as exc:
        log.warning("Gemini picture run could not start: %s", type(exc).__name__)
        return {"ok": False, "plain": GEMINI_START}
    finally:
        _reap(g, proc, readers)                     # agy has ended before anything of its run is removed
        if not kept_ok:                             # a refused run leaves no picture behind in Gemini's folder
            try:
                if watch is not None:
                    watch.finish()
                    convs |= watch.convs
                _drop_run_pictures(convs, started)
            except Exception as exc:
                log.warning("Gemini picture run not cleaned up: %s", type(exc).__name__)
        shutil.rmtree(work, ignore_errors=True)


# --- the engine backend --------------------------------------------------------------------------------------------
def _provider_class():
    from agent.image_gen_provider import DEFAULT_ASPECT_RATIO, ImageGenProvider, error_response, \
        resolve_aspect_ratio, success_response

    class QoshaImageGenProvider(ImageGenProvider):
        """Qosha's picture maker: the person's ChatGPT, then Gemini, subscriptions; never a pay-per-use key."""

        @property
        def name(self) -> str:
            return NAME

        @property
        def display_name(self) -> str:
            return "Qosha (your connected AI accounts)"

        def is_available(self) -> bool:
            return True      # always offered: with no account that can, the tool answers so in plain words

        def get_setup_schema(self) -> dict:
            return {"name": self.display_name, "badge": "subscription", "env_vars": [],
                    "tag": "Pictures with your connected ChatGPT or Gemini sign-in; no API key."}

        def list_models(self) -> list:
            return [{"id": "auto", "display": "Best connected account"}]

        def capabilities(self) -> dict:
            return {"modalities": ["text"], "max_reference_images": 0}     # slice 1: making only, no edits

        def generate(self, prompt: str, aspect_ratio: str = DEFAULT_ASPECT_RATIO, *, image_url=None,
                     reference_image_urls=None, **_kw) -> dict:
            try:
                return self._generate(prompt, aspect_ratio, image_url, reference_image_urls)
            except Exception as exc:                  # never a raw error, a path or an engine name (fixed text)
                log.warning("picture request failed: %s", type(exc).__name__)
                return error_response(error=NOT_MADE, error_type="not_made", provider=NAME, model="auto",
                                      prompt=str(prompt or "")[:MAX_PROMPT],
                                      aspect_ratio=resolve_aspect_ratio(aspect_ratio))

        def _generate(self, prompt, aspect_ratio, image_url, reference_image_urls) -> dict:
            prompt = (prompt or "").strip()
            aspect = resolve_aspect_ratio(aspect_ratio)

            def fail(text, kind="provider_error"):
                return error_response(error=text, error_type=kind, provider=NAME, model="auto",
                                      prompt=prompt[:MAX_PROMPT], aspect_ratio=aspect)

            if not prompt:
                return fail("Say what the picture should show.", "prompt_required")
            if len(prompt) > MAX_PROMPT:
                return fail(TOO_LONG, "prompt_too_long")
            if image_url or reference_image_urls:     # slice 1: nothing is uploaded, no account is asked
                return fail(EDIT_NOT_YET, "edit_not_available")
            why = _halt()
            if why:
                return fail(why, "access_ended" if why == ACCESS_ENDED else "stopped")
            dest = destination()                      # checked before any account is asked
            if dest is None:
                return fail(NO_FOLDER, "files_unavailable")
            reasons = []
            routes = []
            if chatgpt_ready():
                routes.append("chatgpt")
            else:
                reasons.append(CHATGPT_NOT_CONNECTED)
            if gemini_ready():
                routes.append("gemini")
            if not routes:
                return fail(NONE_CONNECTED, "no_connected_account")
            for r in routes:
                why = _halt()
                if why:
                    return fail(why, "access_ended" if why == ACCESS_ENDED else "stopped")
                got = via_chatgpt(prompt, aspect) if r == "chatgpt" else via_gemini(prompt, aspect)
                if got.get("stop"):
                    return fail(got.get("plain") or STOPPED, "stopped")
                if got.get("made"):                   # a picture was made but not saved: no second account
                    return fail(SAVE_FAILED, "save_failed")
                if not got.get("ok"):
                    reasons.append(got.get("plain") or "")
                    continue
                def drop():                           # a Gemini picture not kept is not left in Gemini's folder
                    if r == "gemini":
                        try:
                            _drop_run_pictures({got.get("conv")}, got.get("started"))
                        except Exception as exc:
                            log.warning("Gemini picture not cleaned up: %s", type(exc).__name__)

                why = _halt()                         # before saving
                if why:
                    drop()
                    return fail(why, "access_ended" if why == ACCESS_ENDED else "stopped")
                try:
                    kept = keep(got["path"], dest)
                except (OSError, ValueError) as exc:
                    log.warning("picture not saved: %s", type(exc).__name__)
                    drop()
                    return fail(SAVE_FAILED, "save_failed")       # the picture was made: no second account
                where = str(kept)
                return success_response(
                    image=where, model=got.get("model") or "auto", prompt=prompt, aspect_ratio=aspect,
                    provider=NAME, modality="text",
                    extra={"made_with": got["by"] + " (your subscription; it counts against that plan's limits)",
                           "saved_in_files": where,
                           "show_it": "Put this line on its own line in your answer: " + media_line(where)})
            return fail(" ".join(x for x in reasons if x) or NONE_CONNECTED, "not_made")

    return QoshaImageGenProvider


# --- Qosha's default (F-PAID) --------------------------------------------------------------------------------------
def _image_gen_config() -> Optional[dict]:
    """config.yaml's image_gen section (a dict), or None when there is none or config.yaml can't be read."""
    try:
        from hermes_cli.config import load_config_readonly
        cfg = load_config_readonly()
    except Exception:
        return None
    sec = cfg.get("image_gen") if isinstance(cfg, dict) else None
    return sec if isinstance(sec, dict) else None


def _is_qosha(sec: Optional[dict]) -> bool:
    """This image_gen section's provider is "qosha" (set by hand)."""
    v = sec.get("provider") if sec is not None else None
    return isinstance(v, str) and v.strip().lower() == NAME


def _chose(sec: Optional[dict]) -> bool:
    """This image_gen section names a provider, a model or use_gateway: the person's own choice."""
    if sec is None:
        return False
    if sec.get("use_gateway") is not None:
        return True
    for k in ("provider", "model"):
        v = sec.get(k)
        if v is not None and str(v).strip():
            return True
    return False


def _selected_qosha() -> bool:
    """config.yaml's image_gen.provider is "qosha" (set by hand)."""
    return _is_qosha(_image_gen_config())


def _person_chose() -> bool:
    """config.yaml's image_gen names a provider, a model or use_gateway: the person's own choice."""
    return _chose(_image_gen_config())


def default_in_effect() -> bool:
    """Qosha's backend is the default now: no picture choice of the person's, and the backend is registered."""
    if _person_chose():
        return False
    try:
        from agent.image_gen_registry import get_provider
        return get_provider(NAME) is not None
    except Exception:
        return False


def _paid_refused() -> bool:
    """Once Qosha's guards are in place, the engine's pay-per-use picture paths run only on a picture choice the person
    made in config.yaml that is not Qosha's own backend. Qosha's backend going missing (or config.yaml unreadable)
    never opens them (fails closed); nor does "qosha" set by hand as the picture maker. Decided from ONE read of
    config.yaml, so a second read that fails can never open them; an unreadable config.yaml refuses."""
    sec = _image_gen_config()
    return sec is None or not _chose(sec) or _is_qosha(sec)


def _plain_dispatch(igt) -> None:
    """When Qosha's backend is the selected picture maker (Qosha's default or "qosha" set by hand), only its own answer
    goes back: if it can't be found (the lookup fails or finds nothing) or it raised, the request ends with a fixed
    plain message, never the engine's text (which names commands and settings) and never a fall-through to the
    pay-per-use paths. Any other selection is dispatched by the engine as before."""
    cur = getattr(igt, "_dispatch_to_plugin_provider")
    if getattr(cur, "qosha", False):
        return

    def _dispatch_to_plugin_provider(*a, **kw):
        try:
            p = igt._plugin_provider_name()
            ours = isinstance(p, str) and p.strip().lower() == NAME     # "Qosha", " qosha " count as Qosha's
        except Exception:
            ours = _paid_refused()
        if not ours:
            return cur(*a, **kw)
        try:
            raw = cur(*a, **kw)
            got = json.loads(raw) if isinstance(raw, str) else None
        except Exception:
            got = None
        if isinstance(got, dict) and got.get("provider") == NAME:
            return raw
        log.warning("Qosha's picture backend not reached; plain refusal")
        return json.dumps({"success": False, "image": None, "error": NOT_AVAILABLE, "error_type": "not_available"})

    _dispatch_to_plugin_provider.qosha = True
    _dispatch_to_plugin_provider.original = cur
    igt._dispatch_to_plugin_provider = _dispatch_to_plugin_provider


def _refuse_paid(igt) -> None:
    """Without a picture choice of the person's, the engine's pay-per-use picture paths (FAL and the managed gateways)
    refuse with a plain message instead of running (e.g. when Qosha's backend can't be found at call time, or its
    registry entry is gone)."""
    for attr in ("image_generate_tool", "_maybe_route_managed_model"):
        cur = getattr(igt, attr)
        if getattr(cur, "qosha", False):
            continue

        def make(original):
            def guarded(*a, **kw):
                if _paid_refused():
                    log.warning("pay-per-use picture path refused while Qosha's default is in effect")
                    return json.dumps({"success": False, "image": None, "error": PAID_REFUSED,
                                       "error_type": "not_available"})
                return original(*a, **kw)
            guarded.qosha = True
            guarded.original = original
            return guarded

        setattr(igt, attr, make(cur))
    _no_paid_probe(igt)
    _plain_dispatch(igt)


def _no_paid_probe(igt) -> None:
    """Without a picture choice of the person's, the engine's availability check (check_image_generation_requirements)
    never probes FAL or the managed gateway (a pay-per-use route Qosha refuses; its lazy install can outlast the check's
    window and drop the picture tool): the FAL probe it calls first answers "not available" without running (neither
    the gateway lookup nor the key check runs), so the check answers from Qosha's backend. The registry keeps the check
    function itself, so the probe it looks up at call time is the one guarded. A choice of the person's runs the
    engine's own probe as before."""
    cur = getattr(igt, "check_fal_api_key")
    if getattr(cur, "qosha", False):
        return

    def check_fal_api_key(*a, **kw):
        if _paid_refused():
            return False
        return cur(*a, **kw)

    check_fal_api_key.qosha = True
    check_fal_api_key.original = cur
    igt.check_fal_api_key = check_fal_api_key


def _own_defer_list() -> bool:
    """The person wrote their own tools.tool_search.defer list in config.yaml (it is then left alone)."""
    try:
        from hermes_cli.config import read_raw_config_readonly
        raw = read_raw_config_readonly() or {}
    except Exception:
        return True
    t = raw.get("tools") if isinstance(raw, dict) else None
    ts = t.get("tool_search") if isinstance(t, dict) else None
    return isinstance(ts, dict) and isinstance(ts.get("defer"), (list, tuple, set))


def _offer_directly() -> None:
    """While Qosha's default is in effect, image_generate is not deferred behind the on-demand tool search: it is
    removed from the curated default deferral (_DEFAULT_DEFERRED_TOOLS, which the loaded settings carry as the default
    list). A person's own tools.tool_search.defer list is left alone."""
    import tools.tool_search as ts
    for attr in ("load_config", "load_config_readonly"):
        cur = getattr(ts, attr)
        if getattr(cur, "qosha", False):
            continue

        def make(original):
            def load(*a, **kw):
                cfg = original(*a, **kw)
                try:
                    names = cfg.effective_defer_tools
                    if _NOT_DEFERRED in names and default_in_effect() and not _own_defer_list():
                        default = frozenset(n for n in ts._DEFAULT_DEFERRED_TOOLS if n != _NOT_DEFERRED)
                        kept = default if cfg.defer_tools is None else frozenset(n for n in names if n != _NOT_DEFERRED)
                        return dataclasses.replace(cfg, defer_tools=kept)
                except Exception:
                    pass
                return cfg
            load.qosha = True
            load.original = original
            return load

        setattr(ts, attr, make(cur))


def make_default() -> bool:
    """With no picture choice in config.yaml (image_gen provider, use_gateway and model unset) and Qosha's backend
    registered, Qosha's backend is the one used, offered directly, and the pay-per-use paths refuse. A choice of the
    person's stays theirs, read as the engine reads it. Idempotent; fail-open (the engine as before)."""
    try:
        import tools.image_generation_tool as igt
        _refuse_paid(igt)                 # first: the default is never set without the paid paths guarded
        cur = igt._read_configured_image_provider
        if not getattr(cur, "qosha", False):
            original = cur

            def _read_configured_image_provider():
                chosen = original()
                if chosen:
                    return chosen
                return NAME if default_in_effect() else chosen

            _read_configured_image_provider.qosha = True
            _read_configured_image_provider.original = original
            igt._read_configured_image_provider = _read_configured_image_provider
    except Exception as exc:
        log.warning("Qosha pictures: default not set (%s)", type(exc).__name__)
        return False
    try:
        _offer_directly()
    except Exception as exc:
        log.warning("Qosha pictures: tool stays on demand (%s)", type(exc).__name__)
    return True


def register(ctx) -> bool:
    """Registers Qosha's picture backend and makes it the default. Fail-open (the engine's tool stays as it was)."""
    if not ENABLED:
        return False
    try:
        ctx.register_image_gen_provider(_provider_class()())
    except Exception as exc:
        log.warning("Qosha pictures not registered: %s", type(exc).__name__)
        return False
    return make_default()
