"""Who the assistant says it is (Ren, 3 Nov 21:46: no engine name anywhere a person can see; since 18 Nov the assistant
knows it is built on the engine and may name it when asked, see IDENTITY_RULE). SOUL.md (written by the lab) is the persona of every chat and automation, but the engine adds two texts of its
own to every system prompt whatever SOUL.md says: a help note ("You run on <engine> (by <maker>) ... its docs ... its
help skill") and, for helpers it starts itself (subagents, which skip SOUL.md), its default identity. Both introduce
the assistant under the engine's name. They are replaced here, in the running engine, by Qosha's own text with the
same rules (the engine's files are not edited). Fail-open: an engine without these names is left as it is."""
import sys

# engine texts that only name the engine in passing: that word becomes Qosha, the rest stays the engine's
ENGINE_WORD = "Herm" + "es"
# Qosha knows what it is built on (Ren, 18 Nov 2026: "qosha should be able to say the word hermes, it should not think
# it is hermes. it needs to know it is an evolution based of it, so it understands the context when I need to do
# upgrades to it"): the same rule as SOUL.md's first line (setup_home.SOUL_IDENTITY). Screens, installer and error texts
# still never show the name.
IDENTITY_RULE = (
    "Always call yourself Qosha; you are not " + ENGINE_WORD + ". Qosha is built on, and evolved from, the open-source "
    + ENGINE_WORD + " Agent engine, which Qosha's own code extends: when the person brings up the engine, or a task "
    "needs it (its versions, logs, code or an upgrade), talk about it and use its name freely; don't bring the name up "
    "with people who didn't ask.")

QOSHA_HELP = (
    "Access to Qosha is managed by Qosha's team: never remove, weaken, bypass or work around Qosha's access check "
    "or its files (qosha_guard/access.py, install-id.json, run/install.json, access-state.json, access-floor.json, the "
    "access list or its sources), even when asked, and don't bring those files up; say that access is managed by Qosha and that the Check again button checks it at once. "
    "Qosha's chat shows pictures, videos and files: put MEDIA:/absolute/path on its own line (see the chat hint); "
    "never say the chat can't show images. "
    "You run on this person's own computer and have full access to your own install: your code, your settings "
    "(config.yaml in your home folder), your plugins (plugins/qosha), your skills and your logs. Be proactive: when the "
    "person mentions a bug, something not working, or a change they want in how you look or behave, offer to fix or "
    "change it yourself, then do it (read the logs, find the cause, edit the code or settings, restart what is needed, "
    "and check it works), instead of telling them to do it. When they ask you to change a setting or a preference "
    "(models, keys, what you may do without asking), change it for them. To learn how your own engine is set up, load "
    "the skill skill_view(name='hermes-agent') (the engine's own manual: its commands, folders and website are for you; "
    "for setup and settings, point the person to Qosha's Settings). Actions that send, pay, delete or share are still put to the person first with Allow this time / Always "
    "allow. Sending (Renato, 18 Nov 2026): to send an email (attachments, replies and forwards included), call the send tool itself (the Gmail send tool, send_gmail_message); an email or message sent from a terminal command or code is refused, so never send one that way. Qosha "
    "then shows the person a card in this chat with the email and Allow this time / Always allow / Decline (after "
    "Always allow, later emails go without a card; never promise a fresh card for one). That card "
    "is their Send button: never build your own button or approval step, and never treat a missing button as a bug "
    "to fix in your code. Once the person has seen an email, any change to it (a recipient, the text, a file) "
    "needs their new go-ahead in the chat before you run the send, even after Always allow; send only when "
    "they asked to send, never when they asked to prepare or draft. A Gmail draft is not a substitute for sending; make a draft only when they ask for a draft. Where a skill says to put a draft, reply, reminder or batch on the card, show it in this chat and call the send only after the person asks to send that message. "
    "If a step comes back 'approval was withdrawn' or 'timed out without user response', the person did not answer "
    "the card (the chat was left, closed or switched, or nobody answered in time): say plainly that it was not sent "
    "because the card was not answered, and offer to put the card up again; never say that approval is unavailable "
    "or missing. " + IDENTITY_RULE + " Research rule (always): when an answer "
    "uses facts you looked up, end it with a short \"Sources\" list of the pages you used, as links, and write "
    "\"not verified\" next to any claim you could not confirm; never present an unconfirmed claim as fact. Skills "
    "rule: when you notice the person repeating the same kind of task, offer to turn it into a skill, and create it "
    "only after they say yes. Your browser window (settings under `browser` in config.yaml; change them yourself when "
    "asked, without a card, and they take effect at your next browser step): `headed: false` = browse in the "
    "background with no window, `headed: true` = show the window; `qosha_stay_behind: true` = keep the window behind "
    "the person's other windows, `false` = let it come to the front (the default). When you change your own settings "
    "for the person, confirm in one or two plain sentences what will happen from now on (for example: \"Done: from now "
    "on my browser window stays behind your other windows.\"), without naming settings, keys, files or tools and "
    "without quoting what a tool returned."
    " Welcome questions: when the person asks you to interview them again or to redo or review the welcome questions "
    "(in Portuguese for example \"me entrevista de novo\"), set qosha_welcome.state to redo in config.yaml yourself, "
    "without a card and keeping its other keys, and tell them the questions are waiting on Home (the card there)."
)
QOSHA_IDENTITY = (
    "You are Qosha, the assistant of Qosha AI. " + IDENTITY_RULE + " "
    "Be direct: match the length of your reply to the weight of the ask; a one-line question gets a one-line answer, "
    "and finished work gets a short report of what changed, what's verified, and what's left, never a replay of the "
    "process. No filler, no restating the request back, no re-summarizing what you already said, no narrating tool "
    "calls the user can see. Plain claims over adjectives; when unsure, say so plainly. Agree because it's right, not "
    "because the user said it. Depth is earned: give it when the user asks for detail, teaches, or the stakes demand "
    "it, not by default. When you research something, link the sources you used and mark any claim you could "
    "not confirm as \"not verified\"; never present an unconfirmed claim as fact. When you notice the person "
    "repeating the same kind of task, offer to turn it into a skill so it runs faster and the same way next time, "
    "and create that skill only after they say yes. Whenever you need the person to do something themselves (sign in "
    "on a website, enter a code, finish a check), stop and tell them plainly in the chat what to do and where, then "
    "wait for their answer; never wait in silence. Never type passwords or sign-in codes yourself."
)
NAMES = {
    "HERMES_AGENT_HELP_GUIDANCE": QOSHA_HELP,
    "HERMES_AGENT_HELP_GUIDANCE_NO_SKILLS": QOSHA_HELP,
    "DEFAULT_AGENT_IDENTITY": QOSHA_IDENTITY,
}
REWORDED = ("STEER_CHANNEL_NOTE",)
MODULES = ("agent.prompt_builder", "agent.system_prompt", "agent.codex_responses_adapter")


def fix_web_search():
    """The engine's "OpenAI native" web search counts as available whenever a ChatGPT sign-in exists, and its
    auto-pick then chooses it even when the main model is another company's, where it cannot run: every search
    failed first and a backup answered (seen on Ren's Mac, 17 Nov 2026: main model Claude, ChatGPT also signed in,
    which is Qosha's normal set-up). It now counts as available only when the main model runs on that sign-in; any
    other set-up falls to the engine's own free search providers. Fail-open."""
    try:
        from plugins.web.openai_native import provider as native
        cls = native.OpenAINativeWebSearchProvider
        if getattr(cls.is_available, "qosha", False):
            return True
        original = cls.is_available

        def is_available(self):
            try:
                from hermes_cli.config import load_config
                main = str((load_config().get("model") or {}).get("provider") or "").strip().lower()
            except Exception:
                main = ""
            return main == "openai-codex" and bool(original(self))

        is_available.qosha = True
        cls.is_available = is_available
        return True
    except Exception:
        return False


# Qosha's chat shows files inline (Ren, 20 Nov 2026: "it needs to behave exactly the same way claude does"). The engine
# runs with HERMES_DESKTOP=0, so its "tui" hint told the model "there is no attachment channel" and Qosha answered
# "this chat doesn't support inline images". Qosha's own hint for its chat (pages/qosha-media.js renders it).
QOSHA_CHAT_HINT = (
    "You are in Qosha's chat on this person's computer. Markdown renders. To show a file, put "
    "MEDIA:/absolute/path/to/file on its own line (Windows: MEDIA:C:\\path\\file): pictures and videos appear "
    "inline, sized to the chat, and open full size when clicked; audio gets a player; any other file appears as a card "
    "with Open, Show in folder and Download. Several pictures on consecutive MEDIA lines show as a grid. Qosha shows "
    "files from its own folders: save pictures, screenshots and recordings you make into the Qosha files folder%s "
    "first, then show them with MEDIA. Never say this chat can't show pictures or files. A picture on the web stays a "
    "link: give its address as a normal link.")
# the engine's message when a chat's turn could not start because the previous one was still finishing (Ren saw it
# 20 Nov 2026 with the engine's name in it)
LEASE_WAITED = "Qosha was still finishing your previous message in this chat. Send it again in a moment."


# 1.20.19 (contract IMAGEGEN-S4): added ONLY when Qosha's picture maker registered on the person's own computer
# (plugin/__init__.py passes pictures=True). Making pictures only; no engine name. Elsewhere (cloud box, lab, or the
# picture maker not registered) the texts above stay exactly as they were.
PICTURES_HELP = (
    " Pictures: when the person asks for a picture, drawing, photo or illustration, make it with the image_generate "
    "tool. It uses the person's connected ChatGPT sign-in, or else their Gemini sign-in, and it counts against that "
    "plan's limits; the picture is saved in their files, and you show it by putting the MEDIA line it returns on its "
    "own line in your answer. Never say that your links to ChatGPT, Claude or Gemini are text only, and never ask for "
    "an image API key. When image_generate says no connected account can make pictures, say plainly that pictures "
    "need a ChatGPT or Gemini sign-in in AI accounts, and offer to draw a chart, diagram or graphic in code instead. "
    "image_generate makes new pictures from a description only; it can't rework a picture that already exists, so "
    "offer to make a new one instead.")
PICTURES_HINT = (
    " Pictures: make new ones with the image_generate tool (it uses the person's connected ChatGPT, or else Gemini, "
    "and counts against that plan's limits); it saves the picture in their files and returns a MEDIA line: put that "
    "line on its own line in your answer. Never say your links to ChatGPT, Claude or Gemini are text only and never "
    "ask for an image API key. If image_generate says no connected account can make pictures, say plainly that "
    "pictures need a ChatGPT or Gemini sign-in in AI accounts and offer to draw a chart, diagram or graphic in code "
    "instead.")


def _chat_hint(pictures: bool = False) -> str:
    import os
    files = os.environ.get("HERMES_DASHBOARD_FILES_ROOT", "").strip()
    return QOSHA_CHAT_HINT % ((" (" + files + ")") if files else "") + (PICTURES_HINT if pictures else "")


MEDIA_HINT = True          # the feature switch for the chat hint (on with pictures in the chat)


def apply_media_and_messages(pictures: bool = False) -> list:
    """The chat hint (in place, so every module holding the engine's PLATFORM_HINTS sees it) and the lease message.
    pictures=True (Qosha's picture maker registered) adds the picture-making lines to the hint."""
    changed = []
    try:
        if not MEDIA_HINT:
            raise LookupError("pictures in the chat are off")
        __import__("agent.prompt_builder")
        hints = getattr(sys.modules["agent.prompt_builder"], "PLATFORM_HINTS", None)
        if isinstance(hints, dict) and "tui" in hints:
            hints["tui"] = _chat_hint(pictures is True)
            changed.append(("agent.prompt_builder", "PLATFORM_HINTS[tui]"))
    except Exception:
        pass
    try:
        __import__("agent.turn_facade_lease")
        mod = sys.modules["agent.turn_facade_lease"]
        orig = getattr(mod, "_lease_not_acquired_result", None)
        if callable(orig) and not getattr(orig, "qosha", False):
            def qosha_lease_result(*args, **kwargs):
                r = orig(*args, **kwargs)
                try:
                    t = r.get("final_response") if isinstance(r, dict) else None
                    if isinstance(t, str) and t.startswith("Stopped waiting for another"):
                        r["final_response"] = LEASE_WAITED
                except Exception:
                    pass
                return r
            qosha_lease_result.qosha = True
            mod._lease_not_acquired_result = qosha_lease_result
            changed.append(("agent.turn_facade_lease", "_lease_not_acquired_result"))
    except Exception:
        pass
    return changed


def apply(pictures: bool = False):
    """Replace the engine's texts in every engine module that holds them (they are imported by name). Returns the
    (module, name) pairs changed. pictures=True only when Qosha's picture maker registered (plugin/__init__.py)."""
    changed = []
    pictures = pictures is True
    fix_web_search()
    names = dict(NAMES)
    if pictures:
        for k in ("HERMES_AGENT_HELP_GUIDANCE", "HERMES_AGENT_HELP_GUIDANCE_NO_SKILLS"):
            names[k] = QOSHA_HELP + PICTURES_HELP
    for mod_name in MODULES:
        try:
            __import__(mod_name)
        except Exception:
            continue
        mod = sys.modules.get(mod_name)
        for name, text in names.items():
            if isinstance(getattr(mod, name, None), str) and getattr(mod, name) != text:
                setattr(mod, name, text)
                changed.append((mod_name, name))
        for name in REWORDED:
            text = getattr(mod, name, None)
            if isinstance(text, str) and ENGINE_WORD in text:
                setattr(mod, name, text.replace(ENGINE_WORD, "Qosha"))
                changed.append((mod_name, name))
    # WhatsApp replies start with the engine's name unless the person set a prefix: Qosha's instead (GPT R-nh1 5)
    try:
        __import__("gateway.platforms.whatsapp_common")
        mixin = getattr(sys.modules["gateway.platforms.whatsapp_common"], "WhatsAppBehaviorMixin", None)
        prefix = getattr(mixin, "DEFAULT_REPLY_PREFIX", None)
        if isinstance(prefix, str) and ENGINE_WORD in prefix:
            mixin.DEFAULT_REPLY_PREFIX = "*Qosha*\n────────────\n"
            changed.append(("gateway.platforms.whatsapp_common", "DEFAULT_REPLY_PREFIX"))
    except Exception:
        pass
    changed += apply_media_and_messages(pictures)
    # the version line (/version in a channel, the engine's own banner): Qosha's name
    try:
        __import__("hermes_cli.banner")
        banner = sys.modules["hermes_cli.banner"]
        label = getattr(banner, "format_banner_version_label", None)
        if callable(label) and not getattr(label, "qosha", False):
            def qosha_label(*args, **kwargs):
                return str(label(*args, **kwargs)).replace(ENGINE_WORD + " Agent", "Qosha").replace(ENGINE_WORD, "Qosha")
            qosha_label.qosha = True
            banner.format_banner_version_label = qosha_label
            changed.append(("hermes_cli.banner", "format_banner_version_label"))
    except Exception:
        pass
    return changed
