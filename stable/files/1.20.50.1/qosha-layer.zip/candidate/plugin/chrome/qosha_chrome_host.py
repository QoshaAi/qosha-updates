"""Qosha's native-messaging host (mc21): the only program Chrome starts for the Qosha extension.

Chrome runs it when the Qosha extension calls chrome.runtime.connectNative("ai.qosha.chrome") and talks to it on
stdin/stdout (a 4-byte length in the machine's byte order, then one JSON message). It holds no rules and no state: it
passes messages between the extension and Qosha's relay, which listens on 127.0.0.1 only. The relay's port and a key are
in a file only this user can read (<Qosha home>/qosha/chrome-relay.json); the host proves itself with the key. It reads no
Chrome files, cookies or passwords. Standard library only; works the same on macOS and Windows (threads, no select on
stdin).

  Qosha extension  <-- stdin/stdout -->  this host  <-- TCP 127.0.0.1, JSON lines -->  Qosha's relay
"""
from __future__ import annotations

import json
import os
import socket
import struct
import sys
import threading
import time

EXT_ORIGINS = ("chrome-extension://ccnlbpfeglcmgfbhlppinokahnjcbcmb/",)
TO_CHROME_MAX = 1024 * 1024            # Chrome refuses a larger message from a host
FROM_CHROME_MAX = 64 * 1024 * 1024     # the most Chrome sends in one message
RETRY_S = 2.0

_out_lock = threading.Lock()


def _stdout():
    return sys.stdout.buffer


def to_chrome(obj) -> bool:
    data = json.dumps(obj, separators=(",", ":")).encode()
    if len(data) > TO_CHROME_MAX:
        return False
    with _out_lock:
        out = _stdout()
        out.write(struct.pack("=I", len(data)) + data)
        out.flush()
    return True


def read_chrome(inp):
    """One message from Chrome, or None when Chrome closed the port (or sent something malformed)."""
    head = inp.read(4)
    if len(head) < 4:
        return None
    n = struct.unpack("=I", head)[0]
    if n > FROM_CHROME_MAX:
        return None
    raw = inp.read(n)
    if len(raw) < n:
        return None
    try:
        return json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return {}


def relay_address(home: str):
    """(port, key) from <home>/qosha/chrome-relay.json, or None."""
    try:
        with open(os.path.join(home, "qosha", "chrome-relay.json"), "r", encoding="utf-8") as f:
            d = json.load(f)
        port, key = int(d.get("port") or 0), str(d.get("key") or "")
        return (port, key) if 0 < port < 65536 and len(key) >= 32 else None
    except (OSError, ValueError, TypeError, AttributeError):
        return None


def connect(home: str, origin: str):
    addr = relay_address(home)
    if not addr:
        return None
    try:
        s = socket.create_connection(("127.0.0.1", addr[0]), timeout=5)
        hello = {"event": "hello", "origin": origin, "key": addr[1], "host_pid": os.getpid()}
        s.sendall(json.dumps(hello, separators=(",", ":")).encode() + b"\n")
        s.settimeout(None)
        return s
    except OSError:
        return None


class Pipe:
    def __init__(self, home: str, origin: str):
        self.home, self.origin = home, origin
        self.sock = None
        self.lock = threading.Lock()
        self.done = threading.Event()

    def ensure(self):
        with self.lock:
            if self.sock is None:
                self.sock = connect(self.home, self.origin)
                if self.sock is not None:
                    to_chrome({"event": "relay_up"})
                    threading.Thread(target=self.from_relay, args=(self.sock,), daemon=True).start()
            return self.sock

    def drop(self, s):
        with self.lock:
            if self.sock is s and s is not None:
                try:
                    s.close()
                except OSError:
                    pass
                self.sock = None
                to_chrome({"event": "relay_down"})

    def from_relay(self, s):
        buf = b""
        while not self.done.is_set():
            try:
                chunk = s.recv(1 << 20)
            except OSError:
                chunk = b""
            if not chunk:
                self.drop(s)
                return
            buf += chunk
            while b"\n" in buf:
                raw, buf = buf.split(b"\n", 1)
                if not raw.strip():
                    continue
                try:
                    msg = json.loads(raw.decode("utf-8"))
                except (ValueError, UnicodeDecodeError):
                    continue
                if not to_chrome(msg) and isinstance(msg, dict) and msg.get("id") is not None:
                    err = {"id": msg["id"], "ok": False, "error": {"code": "too_large", "detail": "message too large"}}
                    try:
                        s.sendall(json.dumps(err, separators=(",", ":")).encode() + b"\n")
                    except OSError:
                        pass

    def keep_trying(self):
        while not self.done.is_set():
            if self.sock is None:
                self.ensure()
            time.sleep(RETRY_S)


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    home = ""
    if "--home" in argv:
        i = argv.index("--home")
        home = argv[i + 1] if i + 1 < len(argv) else ""
        del argv[i:i + 2]
    origin = next((a for a in argv if a.startswith("chrome-extension://")), "")
    if origin not in EXT_ORIGINS or not home:
        return 2                              # only Qosha's extension, only with Qosha's home
    pipe = Pipe(home, origin)
    pipe.ensure()
    threading.Thread(target=pipe.keep_trying, daemon=True).start()
    inp = sys.stdin.buffer
    while True:
        msg = read_chrome(inp)
        if msg is None:
            pipe.done.set()
            return 0                          # Chrome closed the port (extension unloaded, or Chrome quit)
        if not isinstance(msg, dict) or not msg:
            continue
        s = pipe.sock or pipe.ensure()
        if s is None:
            if msg.get("id") is not None:
                to_chrome({"id": msg["id"], "ok": False, "error": {"code": "relay_down", "detail": "Qosha is not running"}})
            continue
        try:
            s.sendall(json.dumps(msg, separators=(",", ":")).encode() + b"\n")
        except OSError:
            pipe.drop(s)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (BrokenPipeError, KeyboardInterrupt):
        sys.exit(0)
