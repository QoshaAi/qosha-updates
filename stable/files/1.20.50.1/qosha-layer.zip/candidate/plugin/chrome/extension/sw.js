/* Qosha extension (mc21): Qosha works in the person's own Chrome, only in its own tabs.
 *
 * Qosha's tabs: the ones Qosha opened (green "Qosha" tab group; in front by default, or in Qosha's own minimized window
 * when the person chose "Do it in the background") and the ones the person handed over from the toolbar popup. Chrome's
 * debugger is attached ONLY to those tabs; every other tab is out of reach (Chrome refuses commands for a tab that is not
 * attached). Commands come only from Qosha's relay, through Qosha's native host (chrome.runtime.connectNative); the
 * relay judges every command (final steps wait for the person's Allow in the Qosha app) and this worker checks again
 * that the tab is Qosha's and that the command is not one Qosha never sends (cookies, storage, request interception).
 * Pages and their scripts have no say: messages from a tab's banner can only pause, stop or hand back that tab.
 */
'use strict';

const HOST = 'ai.qosha.chrome';
const GROUP_TITLE = 'Qosha';
const MAX_TABS = 8;
const VERSION = chrome.runtime.getManifest().version;
// Commands this worker never sends to a page, whatever asks (the relay refuses them first): cookies, storage, request
// interception and rewriting, script injection on every page load, other targets, files.
const NEVER = [/^Storage\./, /^Fetch\./, /^Network\.(get|set|delete|clear)\w*Cookies?$/, /^Network\.(setRequestInterception|getResponseBody|getRequestPostData|setBlockedURLs|setExtraHTTPHeaders|replayXHR|loadNetworkResource|takeResponseBodyForInterceptionAsStream|streamResourceContent)$/,
  /^Page\.(addScriptToEvaluateOnNewDocument|setDownloadBehavior|printToPDF|setBypassCSP|setInterceptFileChooserDialog)$/,
  /^Runtime\.(compileScript|runScript|addBinding)$/, /^Browser\./, /^SystemInfo\./, /^IO\./, /^Debugger\./,
  /^Autofill\./, /^Target\.(createTarget|closeTarget|createBrowserContext|disposeBrowserContext|exposeDevToolsProtocol|setDiscoverTargets|attachToBrowserTarget|getTargets)$/];
// Sign-in and payment pages of the big account providers: the person does those; Chrome itself refuses them in Qosha's tabs.
const NEVER_HOSTS = ['accounts.google.com', 'myaccount.google.com', 'pay.google.com', 'payments.google.com',
  'login.microsoftonline.com', 'login.live.com', 'account.microsoft.com', 'appleid.apple.com', 'idmsa.apple.com',
  'secure.login.gov', 'chromewebstore.google.com', 'chrome.google.com'];
const LOCAL_RX = '^[a-z][a-z0-9+.-]*://([^/?#@]*@)?(localhost|127\\.[0-9.]+|0\\.0\\.0\\.0|10\\.[0-9.]+|192\\.168\\.[0-9.]+|172\\.(1[6-9]|2[0-9]|3[01])\\.[0-9.]+|169\\.254\\.[0-9.]+|\\[[0-9a-f:.]*\\]|[^/?#:]*\\.(local|localhost|internal|lan|home\\.arpa|localdomain))(:[0-9]+)?([/?#]|$)';

let S = {tabs: {}, win: null, mode: 'front', ctl: 'idle', denied: []};  // tabs: id -> {kind: 'opened'|'handed', url, at}
let port = null, relayUp = false, loaded = null, retryUp = null;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// a message to a tab's banner, with a time limit: a page that never answers (a frozen or hidden page) is not waited on
const tell = (tabId, msg, ms) => Promise.race([chrome.tabs.sendMessage(tabId, msg, {frameId: 0}),
  sleep(ms).then(() => { throw new Error('no answer'); })]);
const save = () => chrome.storage.session.set({S}).catch(() => {});
const load = () => loaded || (loaded = chrome.storage.session.get('S').then((v) => { if (v && v.S) S = Object.assign(S, v.S); }).catch(() => {}));
const post = (m) => { try { if (port) port.postMessage(m); } catch (e) { /* gone */ } };
const event = (name, more) => post(Object.assign({event: name}, more || {}));
const ours = (tabId) => !!S.tabs[String(tabId)];
class Fail extends Error { constructor(code, detail) { super(detail || code); this.code = code; } }

// Before each input Qosha sends, the tab's banner is told exactly what to expect (a press at a point, a key); any other
// real click or key press in that tab is the person's, and Qosha pauses (council: no timing guesses).
async function expect(tabId, method, p) {
  let e = null;
  if (method === 'Input.dispatchMouseEvent' && p.type === 'mousePressed') e = {kind: 'pointer', x: Number(p.x), y: Number(p.y)};
  else if (method === 'Input.dispatchKeyEvent' && (p.type === 'keyDown' || p.type === 'rawKeyDown')) e = {kind: 'key', key: String(p.key || '')};
  if (!e) return;
  // no banner to watch the person's clicks on this page: Qosha does not act there (fail closed; review r1 GPT 12)
  let ack = null;
  try { ack = await tell(tabId, Object.assign({qosha: 'expect'}, e), 2000); } catch (err) { ack = null; }
  if (!ack || !ack.ok) throw new Fail('no_watch', 'Qosha can\'t watch this page for your own clicks, so it does not click or type here. Ask the person to do this step.');
}

function connect() {
  if (port) return;
  try {
    port = chrome.runtime.connectNative(HOST);
  } catch (e) { port = null; return; }
  port.onMessage.addListener((m) => { load().then(() => onRelay(m)); });
  port.onDisconnect.addListener(() => {
    port = null; relayUp = false;
    load().then(() => stopAll('', false));   // fail closed: nothing stays attached
    setTimeout(connect, 3000);
  });
}

function hostOf(url) {
  try { const u = new URL(url); return (u.protocol === 'http:' || u.protocol === 'https:') ? u.hostname.toLowerCase().replace(/\.+$/, '') : null; }
  catch (e) { return null; }
}
// WhatsApp is never opened, read or taken over in the person's Chrome (the rest of Qosha reads WhatsApp only behind its
// own card): Chrome blocks its pages and frames in Qosha's tabs, redirects included, and the Qosha button refuses the tab.
const WA_HOSTS = ['whatsapp.com', 'whatsapp.net', 'wa.me'];
function deniedUrl(url) {
  const h = hostOf(url);
  if (!h) return 'Qosha only opens web addresses (http or https).';
  if (WA_HOSTS.some((d) => h === d || h.endsWith('.' + d))) return 'Qosha does not open or read WhatsApp in your Chrome. It uses WhatsApp only through its own WhatsApp connection.';
  if (new RegExp(LOCAL_RX, 'i').test(url) || /(^|\.)(localhost|local|internal|lan|home\.arpa|localdomain)$/.test(h)
      || /^(127|10|0)\.|^192\.168\.|^169\.254\.|^172\.(1[6-9]|2[0-9]|3[01])\.|^\[/.test(h)) return 'Qosha does not open pages on this computer or its local network.';
  const all = NEVER_HOSTS.concat(S.denied || []);
  if (all.some((d) => h === d || h.endsWith('.' + d))) return 'Qosha does not open ' + h + ': you sign in, pay or change account settings there yourself.';
  return '';
}

// Chrome itself refuses the never-hosts and local pages in Qosha's tabs, redirects included. Every request type is named:
// without resourceTypes Chrome leaves top-level page loads out (review r1 test R06b).
const ALL_TYPES = ['main_frame', 'sub_frame', 'stylesheet', 'script', 'image', 'font', 'object', 'xmlhttprequest', 'ping',
                   'csp_report', 'media', 'websocket', 'webtransport', 'webbundle', 'other'];
async function syncRules() {
  const ids = Object.keys(S.tabs).map(Number);
  const old = (await chrome.declarativeNetRequest.getSessionRules()).map((r) => r.id);
  // Chrome compiles each regexFilter into at most 2 KB, so local addresses are several small rules (review r1: one big
  // pattern was silently skipped by Chrome)
  const LOCAL_RULES = ['^[a-z]+://([^/@]*@)?(127|10|0)\\.', '^[a-z]+://([^/@]*@)?192\\.168\\.', '^[a-z]+://([^/@]*@)?169\\.254\\.',
                       '^[a-z]+://([^/@]*@)?172\\.(1[6-9]|2[0-9]|3[01])\\.', '^[a-z]+://([^/@]*@)?\\['];
  const add = ids.length ? [
    // Sign-in and payment hosts are NOT blocked here: Google's, Microsoft's and Apple's own sites pass through them to
    // refresh the person's session (the real Gmail journey, 22 Nov). Qosha never opens them itself and never clicks or
    // types on them (deniedUrl here; the relay's judge). Only the person's own never-list is blocked outright.
    {id: 1, priority: 1, action: {type: 'block'}, condition: {tabIds: ids, requestDomains: (S.denied || []).length ? S.denied : ['qosha-never.invalid'], resourceTypes: ['main_frame', 'sub_frame']}},
    {id: 2, priority: 1, action: {type: 'block'}, condition: {tabIds: ids, requestDomains: ['localhost', 'local', 'internal', 'lan', 'home.arpa', 'localdomain'], resourceTypes: ALL_TYPES}},
    {id: 30, priority: 1, action: {type: 'block'}, condition: {tabIds: ids, requestDomains: WA_HOSTS, resourceTypes: ['main_frame', 'sub_frame']}},
  ].concat(LOCAL_RULES.map((rx, i) => ({id: 3 + i, priority: 1, action: {type: 'block'}, condition: {tabIds: ids, regexFilter: rx, isUrlFilterCaseSensitive: false, resourceTypes: ALL_TYPES}}))) : [];
  // Chrome's own block of sign-in/payment hosts and local addresses must be in place: if it can't be set, Qosha refuses to
  // work in its tabs (fail closed; review r1 GPT 06)
  try { await chrome.declarativeNetRequest.updateSessionRules({removeRuleIds: old, addRules: add}); S.rulesOk = true; }
  catch (e) { S.rulesOk = false; }
  await save();
}

async function groupTab(tabId, windowId) {
  try {
    const groups = await chrome.tabGroups.query({windowId, title: GROUP_TITLE});
    const g = groups.length ? await chrome.tabs.group({tabIds: [tabId], groupId: groups[0].id}) : await chrome.tabs.group({tabIds: [tabId], createProperties: {windowId}});
    await chrome.tabGroups.update(g, {title: GROUP_TITLE, color: 'green'});
  } catch (e) { /* a window type without groups */ }
}

async function attach(tabId) {
  if (!ours(tabId)) throw new Fail('not_qosha_tab', 'That tab is not one of Qosha\'s.');   // checked at the moment of attaching
  try { await chrome.debugger.attach({tabId}, '1.3'); }
  catch (e) { if (!/already attached/i.test(String(e && e.message))) throw new Fail('attach', String(e && e.message || e)); }
  await banner(tabId);
}

async function banner(tabId) {
  try {
    await chrome.scripting.executeScript({target: {tabId, allFrames: true}, files: ['banner.js']});
    await tell(tabId, {qosha: 'state', ctl: S.ctl, kind: (S.tabs[String(tabId)] || {}).kind}, 2000);   // verify J-9
  } catch (e) { /* a page Chrome does not let extensions script (the banner is best effort; Chrome's own notice stays) */ }
}
const bannerAll = () => Promise.all(Object.keys(S.tabs).map((t) => banner(Number(t))));

async function qoshaWindow() {
  if (S.win != null) { try { await chrome.windows.get(S.win); return S.win; } catch (e) { S.win = null; } }
  const w = await chrome.windows.create({url: 'about:blank', focused: false, state: 'minimized'});
  S.win = w.id; await save();
  return w.id;
}

async function openTab(url, front) {
  const blank = url === 'about:blank';
  const why = blank ? '' : deniedUrl(url);
  if (why) throw new Fail('refused', why);
  if (Object.keys(S.tabs).length >= MAX_TABS) throw new Fail('too_many', 'Qosha has ' + MAX_TABS + ' tabs open already; it closes one first.');
  let tab;
  const bg = !front && S.mode === 'background';
  if (bg) {
    const win = await qoshaWindow();
    tab = await chrome.tabs.create({windowId: win, url: 'about:blank', active: true});
    const blanks = (await chrome.tabs.query({windowId: win})).filter((t) => t.id !== tab.id && (t.url === 'about:blank' || t.pendingUrl === 'about:blank'));
    for (const b of blanks) { if (!ours(b.id)) await chrome.tabs.remove(b.id).catch(() => {}); }
  } else {
    // in front: one of the person's own normal windows, never Qosha's background window and never a minimized one
    let win;
    try {
      const last = await chrome.windows.getLastFocused({windowTypes: ['normal']});
      if (last && last.id !== S.win && last.state !== 'minimized') win = last.id;
    } catch (e) { win = undefined; }
    if (win == null) {
      const all = await chrome.windows.getAll({windowTypes: ['normal']});
      const w = all.find((x) => x.id !== S.win && x.state !== 'minimized');
      win = w ? w.id : (await chrome.windows.create({url: 'about:blank', focused: true})).id;
    }
    tab = await chrome.tabs.create({windowId: win, url: 'about:blank', active: true});
    chrome.windows.update(win, {focused: true}).catch(() => {});
  }
  S.tabs[String(tab.id)] = {kind: 'opened', url, at: Date.now()};
  await save(); await syncRules();
  await groupTab(tab.id, tab.windowId);
  await attach(tab.id);
  if (!blank) await chrome.debugger.sendCommand({tabId: tab.id}, 'Page.navigate', {url});
  return info(await chrome.tabs.get(tab.id));
}

const info = (t) => ({tab: String(t.id), url: t.url || t.pendingUrl || '', title: (t.title || '').slice(0, 300), kind: (S.tabs[String(t.id)] || {}).kind || '',
  active: !!t.active, window: t.windowId, background: t.windowId === S.win});

async function letGo(tabId, why) {
  const rec = S.tabs[String(tabId)];
  if (!rec) return;
  delete S.tabs[String(tabId)];
  await save(); await syncRules();
  try { await chrome.debugger.detach({tabId}); } catch (e) { /* not attached */ }
  try { await tell(tabId, {qosha: 'off'}, 1000); } catch (e) { /* no banner, or it didn't answer (verify J-9) */ }
  if (rec.kind === 'handed') { try { await chrome.tabs.ungroup([tabId]); } catch (e) { /* gone */ } }
  else { try { await chrome.tabs.remove(tabId); } catch (e) { /* gone */ } }
  event('tab_gone', {tab: String(tabId), why: why || ''});
}

async function stopAll(why, person) {
  // Stop and a lost link: every debugger session ends at once (tabs stay open for the person to see; nothing more is sent).
  // Only the person's Stop holds until they let Qosha continue; a lost link just goes idle (Qosha reconnects later).
  S.ctl = person ? 'stopped' : (S.ctl === 'stopped' ? 'stopped' : 'idle'); await save();
  for (const t of Object.keys(S.tabs)) {
    try { await chrome.debugger.detach({tabId: Number(t)}); } catch (e) { /* not attached */ }
  }
  await bannerAll();
  if (why) event('stopped', {why});
}

const GUARD_OFF = '(function(){var g=window.__qoshaGuard;if(g&&g.off)g.off();return true})()';
const GUARD_LATER = '(function(){var g=window.__qoshaGuard;if(g&&g.off)setTimeout(g.off,1000);return true})()';

async function control(kind) {
  if (kind === 'stop') return stopAll('stop', true);
  if (kind === 'pause') { S.ctl = 'paused'; await save(); await bannerAll(); event('paused', {}); return; }
  if (kind === 'resume') { S.ctl = 'idle'; await save(); await bannerAll(); return; }
  if (kind === 'work') {
    if (S.ctl === 'stopped') throw new Fail('stopped', 'The person pressed Stop.');
    S.ctl = 'working'; await save();
    for (const t of Object.keys(S.tabs)) { try { await attach(Number(t)); } catch (e) { /* tab gone */ } }
    await bannerAll(); return;
  }
  if (kind === 'idle') { if (S.ctl !== 'stopped') { S.ctl = 'idle'; await save(); await bannerAll(); } return; }
  if (kind === 'done') { for (const t of Object.keys(S.tabs)) await letGo(Number(t), 'done'); if (S.ctl !== 'stopped') S.ctl = 'idle'; await save(); }
}

const FILES = ['manifest.json', 'sw.js', 'banner.js', 'popup.html', 'popup.js'];
// What this running code is: Qosha writes the digest of the files it ships here when it copies them (chrome_setup).
// Chrome can keep running an older copy of this worker after the files change (it caches it across restarts; real
// Gmail journey, 23 Nov), so the running code reports this constant, never a digest of whatever is on disk now.
const CODE = '__QOSHA_CODE__';
const UNBAKED = '__QOSHA_' + 'CODE__';
async function filesHash() {      // the files on disk now, with this constant put back to the placeholder
  const hex = (b) => Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, '0')).join('');
  let all = '';
  for (const f of FILES) {
    let buf = await (await fetch(chrome.runtime.getURL(f))).arrayBuffer();
    if (f === 'sw.js') {
      const txt = new TextDecoder().decode(buf).replace(/const CODE = '[0-9a-f]{64}';/, "const CODE = '" + UNBAKED + "';");
      buf = new TextEncoder().encode(txt);
    }
    all += f + ':' + hex(await crypto.subtle.digest('SHA-256', buf)) + '\n';
  }
  return hex(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(all)));
}

// Files on disk that are not this running code: reload once so Chrome starts the code on disk (at most once a minute,
// so a Chrome that keeps the old code cannot loop). Until they match, or when they can't be read, no hello: Qosha stays
// unconnected (verify J-7, fail closed).
async function freshOrReload() {
  if (CODE === UNBAKED) return true;           // not copied by Qosha: reported as is, and the relay refuses it
  try {
    if ((await filesHash()) !== CODE) {
      const last = (await chrome.storage.local.get('reloadAt')).reloadAt || 0;
      if (Date.now() - last > 60000) { await chrome.storage.local.set({reloadAt: Date.now()}); chrome.runtime.reload(); }
      return false;
    }
  } catch (e) { return false; }
  return true;
}

const CMDS = {
  async hello() { return {version: VERSION, ua: navigator.userAgent, ctl: S.ctl, mode: S.mode, files: CODE, tabs: await CMDS.list()}; },
  async list() {
    const out = [];
    for (const t of Object.keys(S.tabs)) { try { out.push(info(await chrome.tabs.get(Number(t)))); } catch (e) { delete S.tabs[t]; } }
    await save(); return out;
  },
  async open(a) { need(); return openTab(String(a.url || ''), !!a.front); },
  async cdp(a) {
    const tabId = Number(a.tab), method = String(a.method || '');
    // While the person has Qosha paused, only Qosha's own "let go" still runs, so a Pause never leaves a button held or the
    // person's own clicks blocked: letting a held press go at the page's corner (behind Qosha's click blocker), and taking
    // that blocker off (these two exact texts, in Qosha's own script world). Everything else is refused, at every step:
    // Pause is checked again right before anything is sent to the page.
    const p0 = a.params || {};
    const letsGo = () => S.ctl === 'paused' && S.rulesOk !== false && (
      (method === 'Runtime.evaluate' && Number(p0.contextId) > 0 && (p0.expression === GUARD_OFF || p0.expression === GUARD_LATER)) ||
      (method === 'Input.dispatchMouseEvent' && p0.type === 'mouseReleased' && Number(p0.x) === 0 && Number(p0.y) === 0));
    const gate = () => { if (!letsGo()) need(); };
    gate();
    if (!ours(tabId)) throw new Fail('not_qosha_tab', 'That tab is not one of Qosha\'s.');
    if (NEVER.some((rx) => rx.test(method))) throw new Fail('refused', method + ' is never sent.');
    if (method === 'Page.navigate') {
      if ((S.tabs[String(tabId)] || {}).kind === 'handed') throw new Fail('refused', 'A tab the person handed over is never taken to another address.');
      const why = deniedUrl(String((a.params || {}).url || '')); if (why) throw new Fail('refused', why);
    }
    if (/^Input\./.test(method)) { await expect(tabId, method, a.params || {}); gate(); }   // Pause may have come while the page answered
    const target = a.sessionId ? {tabId, sessionId: String(a.sessionId)} : {tabId};
    // a step the person allowed carries the end of their wait: past it, Chrome is never told to do it (pass 2 F5)
    const late = () => { if (a.until && Date.now() > Number(a.until)) throw new Fail('late', 'Chrome was busy too long; nothing was done.'); };
    late();
    try { return await chrome.debugger.sendCommand(target, method, a.params || {}); }
    catch (e) {
      // after a lost link the debugger was detached (fail closed); one of Qosha's own tabs is attached again, once
      if (!/not attached/i.test(String(e && e.message))) throw e;
      gate();
      await attach(tabId);
      gate();
      late();
      return chrome.debugger.sendCommand(target, method, a.params || {});
    }
  },
  async clear(a) {   // move Qosha's own pill away from a point Qosha is about to act on
    const tabId = Number(a.tab); if (!ours(tabId)) throw new Fail('not_qosha_tab', 'That tab is not one of Qosha\'s.');
    try { await tell(tabId, {qosha: 'clear', x: Number(a.x), y: Number(a.y)}, 1000); } catch (e) { /* no banner, or no answer */ }
    await sleep(60);
    return {};
  },
  async close(a) { const tabId = Number(a.tab); if (!ours(tabId)) throw new Fail('not_qosha_tab', 'That tab is not one of Qosha\'s.'); await letGo(tabId, 'closed'); return {}; },
  async activate(a) {
    const tabId = Number(a.tab); if (!ours(tabId)) throw new Fail('not_qosha_tab', 'That tab is not one of Qosha\'s.');
    const t = await chrome.tabs.update(tabId, {active: true});
    if (a.front) await chrome.windows.update(t.windowId, {focused: true, state: 'normal'}).catch(() => {});
    return info(t);
  },
  async config(a) { if (a.mode === 'front' || a.mode === 'background') S.mode = a.mode; if (Array.isArray(a.denied)) S.denied = a.denied.map(String).slice(0, 500); await save(); await syncRules(); return {mode: S.mode}; },
  async control(a) { await control(String(a.kind || '')); return {ctl: S.ctl}; },
  async end(a) {     // the answer ended: background tabs Qosha opened close; handed tabs stay the person's; banners go idle
    for (const t of Object.keys(S.tabs)) {     // handed tabs go back to the person at every answer's end (review r1 GPT 11)
      if (S.tabs[t].kind === 'handed' || (a.background && S.tabs[t].kind === 'opened')) await letGo(Number(t), 'answer ended');
    }
    if (S.ctl === 'working') { S.ctl = 'idle'; await save(); await bannerAll(); }
    return {ctl: S.ctl};
  },
};
function need() { if (S.rulesOk === false) throw new Fail('no_rules', 'Chrome did not accept Qosha\'s block of sign-in pages and local addresses, so Qosha does not work in your Chrome right now.');
                  if (S.ctl === 'stopped') throw new Fail('stopped', 'The person pressed Stop. Qosha does nothing in Chrome until they let it continue in the Qosha app.');
                  if (S.ctl === 'paused') throw new Fail('paused', 'The person paused Qosha in Chrome.'); }

async function onRelay(m) {
  if (!m || typeof m !== 'object') return;
  if (m.event === 'relay_up') {
    relayUp = true;
    if (retryUp) { clearTimeout(retryUp); retryUp = null; }   // one retry at a time (final-E Gemini F6)
    if (!(await freshOrReload())) {              // not yet the code on disk (or unreadable): check again in 30 s (pass 2 J-7)
      if (!retryUp) retryUp = setTimeout(() => { retryUp = null; if (relayUp && port) onRelay({event: 'relay_up'}); }, 30000);
      return;
    }
    event('ext_hello', await CMDS.hello()); return;
  }
  if (m.event === 'relay_down') { relayUp = false; if (retryUp) { clearTimeout(retryUp); retryUp = null; } await stopAll('', false); return; }
  if (m.id == null || !Object.prototype.hasOwnProperty.call(CMDS, m.cmd)) return;
  try { post({id: m.id, ok: true, result: await CMDS[m.cmd](m.args || {})}); }
  catch (e) { post({id: m.id, ok: false, error: {code: (e && e.code) || 'error', detail: String(e && e.message || e).slice(0, 500)}}); }
}

chrome.debugger.onEvent.addListener((src, method, params) => {
  if (!src || !ours(src.tabId)) return;
  event('cdp', {tab: String(src.tabId), sessionId: src.sessionId || null, method, params});
});
chrome.debugger.onDetach.addListener((src, reason) => {
  load().then(async () => {
    if (!src || !ours(src.tabId)) return;
    if (reason === 'canceled_by_user') await stopAll('cancel', true);   // Chrome's own "Cancel" on its debugging notice = Stop
    else event('detached', {tab: String(src.tabId), reason});
  });
});
chrome.tabs.onRemoved.addListener((tabId) => { load().then(async () => { if (ours(tabId)) { delete S.tabs[String(tabId)]; await save(); await syncRules(); event('tab_gone', {tab: String(tabId), why: 'closed by the person'}); } }); });
chrome.tabs.onUpdated.addListener((tabId, ch, tab) => {
  load().then(() => {
    if (!ours(tabId)) return;
    if (ch.status === 'complete') banner(tabId);
    if (ch.url || ch.title || ch.status) event('tab_updated', {tab: String(tabId), url: tab.url || '', title: (tab.title || '').slice(0, 300), status: tab.status});
  });
});
chrome.windows.onRemoved.addListener((w) => { load().then(() => { if (S.win === w) { S.win = null; save(); } }); });

// Messages from Qosha's own pages in the extension (popup) and from the banner in a Qosha tab.
chrome.runtime.onMessage.addListener((m, sender, respond) => {
  load().then(() => fromUi(m || {}, sender || {})).then((r) => respond(r || {}), (e) => respond({error: String(e && e.message || e)}));
  return true;
});
async function fromUi(m, sender) {
  const fromPopup = sender.id === chrome.runtime.id && !sender.tab && String(sender.url || '').startsWith(chrome.runtime.getURL('popup.html'));
  const tabId = sender.tab ? sender.tab.id : Number(m.tab);
  if (m.qosha === 'person' && sender.tab && ours(tabId)) {
    if (S.ctl === 'working') { await control('pause'); event('person_input', {tab: String(tabId)}); }
    return {};
  }
  if (m.qosha === 'banner' && sender.tab && ours(tabId)) {
    if (m.kind === 'pause') { await control('pause'); return {}; }
    if (m.kind === 'stop') { await stopAll('stop', true); return {}; }
    if (m.kind === 'takeover') { await control('pause'); event('takeover', {tab: String(tabId)}); return {}; }
    return {};
  }
  if (!fromPopup) return {error: 'not allowed'};
  if (m.qosha === 'state') {
    let t = null; try { t = await chrome.tabs.get(tabId); } catch (e) { /* none */ }
    return {relay: relayUp, ctl: S.ctl, ours: ours(tabId), kind: (S.tabs[String(tabId)] || {}).kind || '', host: t ? hostOf(t.url || '') : '', refused: t ? deniedUrl(t.url || '') : ''};
  }
  if (m.qosha === 'handover') {
    if (!relayUp) return {error: 'Open the Qosha app first.'};
    const t = await chrome.tabs.get(tabId);
    const why = deniedUrl(t.url || '');
    if (why) return {error: why};
    if (!ours(tabId)) { S.tabs[String(tabId)] = {kind: 'handed', url: t.url, at: Date.now()}; await save(); await syncRules(); }
    await groupTab(tabId, t.windowId);
    await attach(tabId);
    event('handover', {tab: String(tabId), url: t.url || '', title: (t.title || '').slice(0, 300)});
    return {ok: true};
  }
  if (m.qosha === 'takeback') { await letGo(tabId, 'taken back'); return {ok: true}; }
  if (m.qosha === 'pause') { await control('pause'); return {ok: true}; }
  if (m.qosha === 'stop') { await stopAll('stop', true); return {ok: true}; }
  return {error: 'unknown'};
}

chrome.runtime.onStartup.addListener(() => load().then(connect));
chrome.runtime.onInstalled.addListener(() => load().then(connect));
chrome.alarms.create('qosha-link', {periodInMinutes: 0.5});
chrome.alarms.onAlarm.addListener(() => load().then(connect));
load().then(connect);
