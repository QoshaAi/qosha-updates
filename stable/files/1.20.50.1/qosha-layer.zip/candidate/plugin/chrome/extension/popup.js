/* The Qosha button in Chrome's toolbar (mc21): hand this tab to Qosha, take it back, pause or stop. */
'use strict';
(async function () {
  const main = document.getElementById('main');
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  const ask = (m) => chrome.runtime.sendMessage(Object.assign({tab: tab ? tab.id : -1}, m));
  function el(tag, attrs, text) { const e = document.createElement(tag); Object.assign(e, attrs || {}); if (text != null) e.textContent = text; return e; }
  function button(label, cls, fn) { const b = el('button', {type: 'button', className: cls || ''}, label); b.addEventListener('click', async () => { b.disabled = true; const r = await fn(); if (r && r.error) { show(r.error); b.disabled = false; } else { render(); } }); return b; }
  function show(text) { const p = el('p', {className: 't3'}, text); main.appendChild(p); }
  async function render() {
    const st = await ask({qosha: 'state'}) || {};
    main.replaceChildren();
    document.getElementById('dot').className = 'dot' + (st.relay ? ' on' : '');
    document.getElementById('link').textContent = st.relay ? 'Connected to Qosha on this computer' : 'Not connected: open the Qosha app';
    const stop = document.getElementById('stop');
    stop.hidden = !st.relay || st.ctl === 'stopped';
    stop.onclick = async () => { await ask({qosha: 'stop'}); render(); };
    if (st.ctl === 'stopped') {
      main.append(el('h1', null, 'Qosha is stopped'), el('p', null, 'Qosha does nothing in Chrome until you let it continue in the Qosha app.'));
      return;
    }
    if (st.ours) {
      main.append(el('h1', null, st.ctl === 'working' ? 'Qosha is working in this tab' : st.ctl === 'paused' ? 'Qosha is paused' : (st.kind === 'handed' ? 'You handed this tab to Qosha' : 'This is Qosha’s tab')));
      main.append(el('p', null, 'It asks you in the Qosha app before anything is sent, paid, deleted, shared or submitted.'));
      if (st.ctl === 'working') main.append(button('Pause', '', () => ask({qosha: 'pause'})));
      main.append(button(st.kind === 'handed' ? 'Take back this tab' : 'Close Qosha’s tab', 'ghost', () => ask({qosha: 'takeback'})));
      if (st.kind === 'handed') main.append(el('p', {className: 't3'}, 'Taking it back never closes it.'));
      return;
    }
    main.append(el('h1', null, 'Let Qosha work in this tab?'));
    if (st.refused) { main.append(el('p', null, st.refused)); return; }
    const p = el('p'); p.append('Qosha will read '); p.append(el('b', null, st.host || 'this page')); p.append(' and act in this tab, signed in as you. It asks you in the Qosha app before anything is sent, paid, deleted, shared or submitted.');
    main.append(p);
    const b = button('Hand this tab to Qosha', '', () => ask({qosha: 'handover'}));
    if (!st.relay) b.disabled = true;
    main.append(b, el('p', {className: 't3'}, 'Other tabs stay yours. "Take back" here or in Qosha gives the tab back; it is never closed.'));
  }
  render();
})();
