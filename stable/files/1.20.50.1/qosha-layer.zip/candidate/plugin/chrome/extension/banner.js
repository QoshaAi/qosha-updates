/* Qosha's banner in one of Qosha's tabs (mc21): a soft gold edge while Qosha works, and a pill at the bottom with
   Pause / Take over / Stop. Runs in the extension's own isolated world; the page cannot reach it (closed shadow root).
   It reports the person's own clicks and key presses in this tab, so Qosha pauses (the worker tells them apart from
   Qosha's own input by timing). Injected again after each page load; one copy per page. */
(function () {
  'use strict';
  if (window.__qoshaBanner) { return; }
  window.__qoshaBanner = true;
  if (window.top !== window) {
    // in an embedded frame Qosha never clicks or types (the relay refuses it): every real click or key here is the person's
    var frameEv = function (ev) { if (ev.isTrusted) { try { chrome.runtime.sendMessage({qosha: 'person'}); } catch (e) { /* worker restarting */ } } };
    window.addEventListener('pointerdown', frameEv, true);
    window.addEventListener('keydown', frameEv, true);
    return;
  }
  var ICON = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAIKADAAQAAAABAAAAIAAAAACshmLzAAAFlklEQVRYCb1WeUwUdxT+dmZndmV3BdRakIUAiopUlB7eV0yoCVoF6pHWekRbq7U10WjSWDWt1bS11T+qVaN4hcYqVEuUmtbGaP0DI5aqEEUFT8rhQhc5l7373ih2VXZ2a9FHJjvMb37v+37v+N5o8MC8gKbhYnbKxTvW4U3NzUYvWftaZ/xqyExGY/OgmG5nQgfNOq8BFP/0S3e/fRmaU+3edPjspVlXKmskh8tJT5WlzsB+4MMLWSuhvznCmTkkKXt6pLhMk/pxg9abM03MrXFv+CLv5Lzia+WQtCKIbCcC/+uKg1pSfkO6Wm2ZJ0wZ5ybsRUJLfNqAvHOlc4vLytFFJ0MrihAF4Zlc7Jsx+KB5RVfmMLZw2dKaXFZlkSVafF7GWIx52dKULDTZWiSH2/W8sB/iOFwuMLZW0Ajep8m4x+OB0ihULwJdT1M3jK19SCmIGw8Vkd1hhySICO8aBlNICFxuN+obG9DY2gKRCpgr/b9Y0AQcTicMej1mT0zHzEmZ6BfXGzpZVqJgbbiHU4UF2JG7H+dKS6CXdUFHJCgCbXTqQX36I2vtBsSZY3Do+M/YfiAbd6110EkSEuMTMHXCRJzal4tNe3Zg3c7N8AqcGiFgMAIS4JMn9+6HX3Z8j5JrpZgxYxLKKm5DEAUI1K6sZ8cKTmPLgX2YmZaO79asR/ewcCz56lNoJCGgnKkS4CIL0emwZ91GXL1Zjowl78HmdMBAufc1Hf3D7+7Oy8E9qodDW7JQWHIBe/MPUd/rfV994l41Rm12O6a/PhGJCX2x+PNVaHXaIVPIOzLuAoPBgMMnf0VWzn6sWbwUYQbT/U7paMODZ6oEWLlmT5mGoyeOo+T6Ncq3rOLq/pJEhbntYDaiIyIxKuVV2CliauaXAPd5D8plEp3+eMHvNJuCUwtJ1KK84hZuVf6FEYNfgdvtUcOHfwJeD8JNXZUc3qmuUmZDR54en9mcChulrspyF9GRUQGL0C8BBruvbhq/eeTNWgqMi075OBEPHYAVMhADvwS4hxuamxTl6/XCi+CU+JqHEPWiBstGx+KD4TEAPeBnXvrjWono0VOJArH33fbEvX8C1OO19VaU3b6J8cNGkPNHCZDOoNHpwcEL1Rga1w3LxsRRPr1wOF2I7RWF+OgYnC0+T1qhPmX9EmCqdvoy+iE/DxmpaegTFQMnTTBfo0mG8nobVh4tRWKkCcvHxUOk2TA3fQZYnk//WQhZ7rht2/2oEmBNz87/CZa/6/DNilVKmHn4+JpMiljR5MDK/FJEmUSsT0/B22lvYEPWNlgogoHkWJUAS621uQHvrlqO1JFjsYtmQWiIAS2trRRqpzIJOSoelwO36xpxsrY7Rr3UFwWH1yH7SC4kOkAgUyXAmzkKp84XIuPD+Rj72jCcO5iP1Qs+woiBKUiIikZSbG9kjp+AHzdtw66NO1HYZEZl5XUsHxMNA80CLkw1U50F7RtZz0/8cQYjZ2bg/envYNbkN7Fi/iKlPbnVOBpFl0rw1tKFymDqHiLjk9QELBhixtYzFeDK8SdjQRFgIhyJ2sZ6rN66EV/v3Y6onhEII6HiFNTU1aLGWkun9Srv3XO4sfLYVZh01AEsBSpRCJoAkxCppUL0XeCkQrxeWaG0Jn2MKWNZ9pkTIkWFS7W+zU1FyDv9mxYajxrBDneyQvKgIkodrvNDxmUhVDVyJBj1BrueRqzygan6ductMhZ/SRn1erswMNJYlGiOsLkClWvn4YOxksyRrQMjQ4sE3eA5ZVOHDvh2ZHISbA4n+Hudc/wsLvbNGIyVOTRxM2PzMPN6NTWfaSaP9hwxRyy8XFEV7iQ9fxYmSVoMiO5VP/nlhO1pPW1rGfuRMvEW746/YnUkNbe0yY8K7v+nw+VqNOgd/bvJlzTJ8260e/wHXv9kRm0Bc7kAAAAASUVORK5CYII=';
  var host = document.createElement('qosha-banner');
  var root = host.attachShadow({mode: 'closed'});
  var css = ':host{all:initial}' +
    '.edge{position:fixed;inset:0;pointer-events:none;z-index:2147483646;box-shadow:inset 0 0 0 2px rgba(184,149,90,.85),inset 0 0 22px 4px rgba(184,149,90,.35);border-radius:2px;transition:opacity .2s}' +
    '.pill{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:2147483647;display:flex;align-items:center;gap:8px;' +
    'padding:7px 8px 7px 8px;border-radius:999px;background:#0B3326;color:#fff;box-shadow:0 6px 24px rgba(0,0,0,.25);' +
    'font:500 13px/1 "Google Sans Flex","Google Sans","Helvetica Neue",Arial,sans-serif;white-space:nowrap;max-width:calc(100vw - 32px)}' +
    '.pill img{width:22px;height:22px;border-radius:6px;display:block}' +
    '.msg{padding:0 4px;overflow:hidden;text-overflow:ellipsis}' +
    'button{all:unset;cursor:pointer;padding:6px 12px;border-radius:999px;border:1px solid rgba(255,255,255,.55);font:600 12px/1 inherit;color:#fff}' +
    'button:hover{background:rgba(255,255,255,.12)}button.solid{background:#fff;color:#0B3326;border-color:#fff}' +
    'button:focus-visible{outline:2px solid #E2C893;outline-offset:2px}';
  var st = document.createElement('style'); st.textContent = css; root.appendChild(st);
  var edge = document.createElement('div'); edge.className = 'edge'; root.appendChild(edge);
  var pill = document.createElement('div'); pill.className = 'pill'; pill.setAttribute('role', 'status'); pill.setAttribute('aria-live', 'polite');
  root.appendChild(pill);
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function send(kind) { try { chrome.runtime.sendMessage({qosha: 'banner', kind: kind}); } catch (e) { /* the worker is restarting */ } }
  function render(ctl, kind) {
    while (pill.firstChild) pill.removeChild(pill.firstChild);
    var img = el('img'); img.src = ICON; img.alt = ''; pill.appendChild(img);
    var btns = [];
    if (ctl === 'working') { pill.appendChild(el('span', 'msg', 'Qosha is working in this tab')); btns = [['Pause', 'pause', ''], ['Take over', 'takeover', ''], ['Stop', 'stop', 'solid']]; edge.style.opacity = '1'; }
    else if (ctl === 'paused') { pill.appendChild(el('span', 'msg', 'Qosha is paused. Let it continue in the Qosha app')); btns = [['Stop', 'stop', 'solid']]; edge.style.opacity = '.45'; }
    else if (ctl === 'stopped') { pill.appendChild(el('span', 'msg', 'Qosha stopped. It does nothing here until you let it continue in the Qosha app')); edge.style.opacity = '0'; }
    else { pill.appendChild(el('span', 'msg', kind === 'handed' ? 'You handed this tab to Qosha' : 'Qosha’s tab')); edge.style.opacity = '0'; }
    btns.forEach(function (b) { var x = el('button', b[2], b[0]); x.type = 'button'; x.addEventListener('click', function (ev) { ev.stopPropagation(); send(b[1]); }); pill.appendChild(x); });
    host.style.display = '';
  }
  function off() { host.style.display = 'none'; }
  function mount() { if (!host.isConnected) (document.documentElement || document).appendChild(host); }
  mount();
  render('idle', '');
  var expected = [];                    // what Qosha is about to send: [{kind, x, y, key, at}]
  chrome.runtime.onMessage.addListener(function (m, sender, respond) {
    if (!m || typeof m !== 'object') return;
    if (m.qosha === 'state') { mount(); render(String(m.ctl || 'idle'), String(m.kind || '')); }
    else if (m.qosha === 'off') { off(); }
    else if (m.qosha === 'expect') { expected.push({kind: m.kind, x: m.x, y: m.y, key: m.key, at: Date.now()}); respond({ok: true}); }
    else if (m.qosha === 'clear') {   // Qosha is about to act at (x, y): the pill moves to the other edge if it covers it
      var r = pill.getBoundingClientRect();
      if (m.x >= r.left - 12 && m.x <= r.right + 12 && m.y >= r.top - 12 && m.y <= r.bottom + 12) {
        var top = pill.style.top === '18px';
        pill.style.top = top ? '' : '18px';
        pill.style.bottom = top ? '18px' : 'auto';
      }
      respond({ok: true});
    }
  });
  function qoshas(ev) {
    var now = Date.now();
    expected = expected.filter(function (e) { return now - e.at < 3000; });
    for (var i = 0; i < expected.length; i++) {
      var e = expected[i];
      var hit = e.kind === 'pointer' ? (ev.type === 'pointerdown' && Math.abs(ev.clientX - e.x) <= 2 && Math.abs(ev.clientY - e.y) <= 2)
                                     : (ev.type === 'keydown' && ev.key === e.key);
      if (hit) { expected.splice(i, 1); return true; }
    }
    return false;
  }
  function person(ev) {
    if (!ev.isTrusted) return;
    if (ev.composedPath && ev.composedPath().indexOf(host) >= 0) return;   // the banner's own buttons
    if (qoshas(ev)) return;                                                 // exactly what Qosha just sent
    try { chrome.runtime.sendMessage({qosha: 'person'}); } catch (e) { /* worker restarting */ }
  }
  window.addEventListener('pointerdown', person, true);
  window.addEventListener('keydown', person, true);
})();
