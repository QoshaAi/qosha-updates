/* "Connect Qosha to your Chrome": the Home notice, one desktop notification and the guided setup (27 Nov 2026, Ren:
   "have qosha create a notification and either do the chrome extension install by suggesting it, or guide the user").
   Loaded once by the dashboard shell (index.js) in the top window. Every minute (and when the window comes back) it
   reads /api/plugins/qosha/chrome/guide; Qosha itself decides when the notice is offered (its extension files and
   Chrome are here, Chrome never connected, "In your own Chrome" is off, not hidden by Not now / Don't show again).
   * Home: a card with Set it up, Not now (3 days; the X too) and Don't show again.
   * Once ever: a desktop notification (only when this app may show them; it never asks); a click brings Home up.
   * Set it up (the Qosha app window only): Qosha writes its link to Chrome, copies the extension, opens Chrome's
     Extensions page and copies the folder's location to the clipboard; the card then shows the two steps only the
     person can do, and turns green by itself when the extension connects ("Use my Chrome" is the Settings switch).
   Text from the server is set as text, never as HTML. */
(function () {
  'use strict';
  if (window.__qoshaChromeGuide || window.top !== window) return;
  window.__qoshaChromeGuide = true;
  var API = '/api/plugins/qosha/chrome/';
  var ICON = '/dashboard-plugins/qosha/assets/brand/icons/apple-touch-icon.png';
  var QI = window.QoshaI18n, PT = !!(QI && QI.lang === 'pt-br');
  var W = {
    'label': ['Chrome', 'Chrome'],
    'title': ['Connect Qosha to your Chrome', 'Conecte o Qosha ao seu Chrome'],
    'offer': ['Qosha can work in your own Chrome, where you’re already signed in to your sites. It takes about a minute: Qosha does most of it, you press two buttons.',
              'O Qosha pode trabalhar no seu próprio Chrome, onde você já está conectado aos seus sites. Leva cerca de um minuto: o Qosha faz quase tudo, você aperta dois botões.'],
    'notify': ['Qosha can work in your own Chrome. Click to set it up (about a minute).', 'O Qosha pode trabalhar no seu próprio Chrome. Clique para configurar (cerca de um minuto).'],
    'setup': ['Set it up', 'Configurar'], 'later': ['Not now', 'Agora não'], 'never': ['Don’t show again', 'Não mostrar de novo'],
    'close': ['Close', 'Fechar'], 'working': ['Setting up…', 'Configurando…'],
    'steps': ['Two steps in Chrome', 'Dois passos no Chrome'],
    'done': ['Qosha did its part: the link to Chrome and the extension’s folder, and it asked Chrome to open its Extensions page. If you don’t see it, go to chrome://extensions in Chrome.',
             'O Qosha fez a parte dele: a ligação com o Chrome e a pasta da extensão, e pediu ao Chrome para abrir a página Extensões. Se ela não aparecer, vá para chrome://extensions no Chrome.'],
    'done_noopen': ['Qosha did its part: the link to Chrome and the extension’s folder. Open Chrome and go to chrome://extensions.',
                    'O Qosha fez a parte dele: a ligação com o Chrome e a pasta da extensão. Abra o Chrome e vá para chrome://extensions.'],
    'copied': ['The folder’s location is copied:', 'O local da pasta foi copiado:'],
    'copy_this': ['Copy this folder’s location:', 'Copie o local desta pasta:'],
    's1': ['Turn on Developer mode (top right of the Extensions page).', 'Ative o Modo do desenvolvedor (no canto superior direito da página Extensões).'],
    's2mac': ['Press Load unpacked. In the window that opens, press Command+Shift+G, paste with Command+V, press Return, then Select.',
              'Aperte Carregar sem compactação. Na janela que abrir, aperte Command+Shift+G, cole com Command+V, aperte Return e depois Selecionar.'],
    's2win': ['Press Load unpacked. In the window that opens, click the address bar at the top, paste with Ctrl+V, press Enter, then Select Folder.',
              'Aperte Carregar sem compactação. Na janela que abrir, clique na barra de endereço no alto, cole com Ctrl+V, aperte Enter e depois Selecionar pasta.'],
    'wait': ['Waiting for Chrome to connect…', 'Esperando o Chrome conectar…'],
    'copy_again': ['Copy the location again', 'Copiar o local de novo'], 'open_again': ['Open the Extensions page again', 'Abrir a página Extensões de novo'],
    'ok_title': ['Qosha is connected to your Chrome', 'O Qosha está conectado ao seu Chrome'],
    'ok_body': ['Use your Chrome when Qosha browses? Qosha works only in its own green tab group, signed in as you, and leaves Send, Pay, Delete, Share and Submit for you to press. You can change this in Settings > Browser.',
                'Usar o seu Chrome quando o Qosha navegar? O Qosha trabalha só no grupo de abas verde dele, conectado como você, e deixa Enviar, Pagar, Excluir, Compartilhar e Confirmar para você apertar. Você pode mudar isso em Configurações > Navegador.'],
    'use': ['Use my Chrome', 'Usar meu Chrome'], 'use_later': ['Later', 'Depois'],
    'used': ['Done: Qosha browses in your Chrome. You can change this in Settings > Browser.', 'Pronto: o Qosha navega no seu Chrome. Você pode mudar isso em Configurações > Navegador.'],
    'fail': ['Qosha couldn’t set this up just now. Please try again.', 'O Qosha não conseguiu configurar agora. Tente de novo.'],
    'window': ['Open the Qosha app to do this: only the Qosha app window can set up your Chrome.', 'Abra o app do Qosha para fazer isso: só a janela do app do Qosha pode configurar o seu Chrome.']
  };
  function t(k) { var w = W[k]; return w ? w[PT ? 1 : 0] : k; }
  function tok() { return String(window['__HERMES_SESSION_TOKEN__'] || ''); }
  function call(path, method, body) {
    var h = {'X-Hermes-Session-Token': tok()};
    if (body) h['Content-Type'] = 'application/json';
    return window.fetch(API + path, {method: method || 'GET', credentials: 'same-origin', cache: 'no-store', headers: h,
                                     body: body ? JSON.stringify(body) : undefined})
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (d) { return {status: r.status, ok: r.ok, data: d || {}}; }); });
  }
  function onHome() {
    var l = window.location || {};
    return String(l.pathname || '/').replace(/\/+$/, '') === '' && !/(?:^|[?&])view=/.test(String(l.search || ''));
  }
  var slot = null, phase = 'none', info = null, busy = false, off = false, poll = null, polls = 0, offered = false, folder0 = '', gen = 0, noting = false, noted = false, dismissing = false;
  function style() {
    if (document.getElementById('qcg-style')) return;
    var s = document.createElement('style'); s.id = 'qcg-style';
    s.textContent = '.qcg-slot{position:fixed;right:24px;bottom:24px;z-index:2147482980;width:400px;max-width:calc(100vw - 24px);font-family:"Google Sans Flex","Google Sans","Helvetica Neue",sans-serif;font-size:14px;line-height:20px;-webkit-font-smoothing:antialiased}' +
      '.qcg-card{position:relative;box-sizing:border-box;padding:18px 18px 16px;border-radius:20px;border:1px solid #E2E1DB;background:#FFFFFF;color:#0B0B0B;box-shadow:0 2px 4px rgba(11,11,11,.04),0 18px 48px rgba(11,51,38,.16)}' +
      '.qcg-card.qcg-green{border-color:#B9D7C6;background:#F3F9F5}' +
      '.qcg-k{display:flex;align-items:center;gap:8px;font-size:12px;font-weight:500;letter-spacing:.14em;text-transform:uppercase;color:#5E5D59}' +
      '.qcg-dot{width:8px;height:8px;border-radius:50%;background:#B8955A;box-shadow:0 0 0 4px rgba(184,149,90,.18)}.qcg-green .qcg-dot{background:#1E7A4C;box-shadow:0 0 0 4px rgba(30,122,76,.18)}' +
      '.qcg-h{margin:8px 0 4px;font-size:17px;line-height:24px;font-weight:500;padding-right:28px}' +
      '.qcg-p{margin:0 0 6px;color:#5E5D59}.qcg-ol{margin:8px 0 6px;padding-left:22px;color:#0B0B0B}.qcg-ol li{margin:0 0 6px}' +
      '.qcg-path{display:block;margin:2px 0 8px;padding:8px 10px;border-radius:10px;background:#F5F4F0;color:#0B0B0B;font:13px/18px "Google Sans Code",ui-monospace,Menlo,Consolas,monospace;word-break:break-all;user-select:all}' +
      '.qcg-wait{margin:6px 0 0;color:#0B3326;font-weight:500}.qcg-err{margin:8px 0 0;color:#6E1C14}' +
      '.qcg-acts{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}' +
      '.qcg-btn{height:40px;padding:0 18px;border-radius:999px;border:1px solid #E2E1DB;background:transparent;color:#0B0B0B;font:inherit;font-weight:500;cursor:pointer}' +
      '.qcg-btn:hover{background:#F5F4F0}.qcg-btn.pri{background:#0B3326;border-color:#0B3326;color:#FFFFFF}.qcg-btn[disabled]{opacity:.5;cursor:default}' +
      '.qcg-link{height:32px;padding:0 6px;border:0;background:transparent;color:#5E5D59;font:inherit;text-decoration:underline;cursor:pointer}' +
      '.qcg-x{position:absolute;top:12px;right:12px;width:32px;height:32px;border-radius:10px;border:0;background:transparent;color:#5E5D59;font-size:18px;line-height:32px;cursor:pointer}' +
      '.qcg-x:hover{background:#F5F4F0}.qcg-card :focus-visible{outline:2px solid #0B0B0B;outline-offset:2px}' +
      '@media (max-width:600px){.qcg-slot{left:12px;right:12px;bottom:12px;width:auto}}';
    (document.head || document.body).appendChild(s);
  }
  function el(tag, cls, text, attrs) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = String(text);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    return n;
  }
  function btn(text, cls, fn) { var b = el('button', cls || 'qcg-btn', text, {type: 'button'}); b.addEventListener('click', fn); return b; }
  function clear() { if (slot) slot.textContent = ''; }
  function card(title, kids, acts, onX, green) {
    style();
    if (!slot) { slot = el('div', 'qcg-slot', null, {id: 'qcg-slot', 'aria-live': 'polite'}); document.body.appendChild(slot); }
    var c = el('div', 'qcg-card' + (green ? ' qcg-green' : ''), null, {role: 'region', 'aria-label': t('title')});
    var k = el('div', 'qcg-k'); k.appendChild(el('span', 'qcg-dot', null, {'aria-hidden': 'true'})); k.appendChild(document.createTextNode(t('label')));
    c.appendChild(k); c.appendChild(el('h2', 'qcg-h', title));
    (kids || []).forEach(function (x) { if (x) c.appendChild(x); });
    if (acts && acts.length) { var a = el('div', 'qcg-acts'); acts.forEach(function (x) { a.appendChild(x); }); c.appendChild(a); }
    if (onX) { var x = btn('×', 'qcg-x', onX); x.setAttribute('aria-label', t('close')); c.appendChild(x); }
    slot.textContent = ''; slot.appendChild(c);
    return c;
  }
  function stopPoll() { if (poll) { clearInterval(poll); poll = null; } }
  function hide(forever) {
    phase = 'none'; offered = false; gen++; dismissing = true; stopPoll(); clear();
    // no read while it is being saved, and none started before it counts (review r2 M1)
    var done = function () { dismissing = false; gen++; };
    call('guide/dismiss', 'POST', {forever: !!forever}).then(done, done);
  }
  function showOffer() {
    phase = 'offer';
    card(t('title'), [el('p', 'qcg-p', t('offer'))],
      [btn(t('setup'), 'qcg-btn pri', start), btn(t('later'), null, function () { hide(false); }),
       btn(t('never'), 'qcg-link', function () { hide(true); })], function () { hide(false); });
  }
  function copy(text) {
    try {
      if (window.navigator && window.navigator.clipboard && window.navigator.clipboard.writeText)
        return window.navigator.clipboard.writeText(text).then(function () { return true; }, function () { return false; });
    } catch (e) { /* none */ }
    return Promise.resolve(false);
  }
  function showSteps(copied, err) {
    phase = 'steps';
    var i = info || {}, folder = String(i.folder || ''), ol = el('ol', 'qcg-ol');
    ol.appendChild(el('li', null, t('s1')));
    ol.appendChild(el('li', null, t(i.system === 'windows' ? 's2win' : 's2mac')));
    var kids = [el('p', 'qcg-p', t(i.opened ? 'done' : 'done_noopen')), el('p', 'qcg-p', t(copied ? 'copied' : 'copy_this')),
                el('code', 'qcg-path', folder), ol, el('p', 'qcg-wait', t('wait'), {role: 'status'})];
    if (err) kids.push(el('p', 'qcg-err', err, {role: 'alert'}));
    card(t('steps'), kids,
      [btn(t('copy_again'), null, function () { copy(folder).then(function (ok) { if (phase === 'steps') showSteps(ok); }); }),
       btn(t('open_again'), null, function () { call('guide/open', 'POST').then(function (r) { if (phase === 'steps' && r.status === 403) showSteps(copied, t('window')); }, function () {}); }),
       btn(t('close'), 'qcg-link', function () { hide(false); })],     // closed half-way: like Not now (Settings > Browser still sets it up)
      function () { hide(false); });
    if (!poll) { polls = 0; poll = setInterval(watch, 2000); }
  }
  function showConnected(msg) {
    phase = 'connected'; offered = false; stopPoll();
    card(t('ok_title'), [el('p', 'qcg-p', msg || t('ok_body'))],
      msg ? [btn(t('close'), 'qcg-btn pri', function () { phase = 'none'; clear(); })]
          : [btn(t('use'), 'qcg-btn pri', function () {
               call('mode', 'POST', {on: true}).then(function (r) {
                 if (r.status === 403) { showConnected(t('window')); return; }
                 showConnected(r.ok && r.data && r.data.enabled ? t('used') : t('fail'));
               }, function () { showConnected(t('fail')); });
             }),
             btn(t('use_later'), null, function () { phase = 'none'; clear(); })],
      function () { phase = 'none'; clear(); }, true);
  }
  function watch() {
    if (++polls > 450) { stopPoll(); poll = setInterval(watch, 10000); polls = 0; }   // after 15 minutes, every 10 s
    // Qosha's guide status, not the plain status: seeing the connection there records it, so the notice never comes
    // back after Later and a closed Chrome (review r1 H1)
    call('guide').then(function (r) { if (phase === 'steps' && r.ok && r.data && r.data.connected === true) showConnected(); }, function () {});
  }
  function start() {
    if (busy) return; busy = true; phase = 'working';     // place() leaves a card that is working alone
    var c = card(t('title'), [el('p', 'qcg-p', t('working'), {role: 'status'})], [], null);
    // the copy first, at the press: once Chrome opens it has the focus, and a page without focus can't copy
    var first = folder0 ? copy(folder0) : Promise.resolve(false);
    first.then(function (pre) { return call('guide/start', 'POST').then(function (r) { return [pre, r]; }); }).then(function (x) {
      var pre = x[0], r = x[1];
      busy = false;
      if (r.status === 403) { showOffer(); var e = el('p', 'qcg-err', t('window'), {role: 'alert'}); slot.firstChild.appendChild(e); return; }
      if (!r.ok || !r.data || r.data.ok !== true) { showOffer(); slot.firstChild.appendChild(el('p', 'qcg-err', t('fail'), {role: 'alert'})); return; }
      info = r.data;
      var f = String(info.folder || '');
      if (pre && f === folder0) showSteps(true); else copy(f).then(function (ok) { if (phase === 'working') showSteps(ok); });
    }, function () { busy = false; showOffer(); slot.firstChild.appendChild(el('p', 'qcg-err', t('fail'), {role: 'alert'})); });
    return c;
  }
  function can() { return typeof window.Notification === 'function' && window.Notification.permission === 'granted'; }
  function notifyOnce() {
    if (!can() || noting || noted) return;    // never asks; one claim at a time, one per page (review r1 H3)
    noting = true;
    call('guide/notified', 'POST').then(function (r) {
      noting = false;
      if (r.status === 403) { noted = true; return; }          // not the app window: it never claims (one try)
      if (!r.ok || !r.data || r.data.ok !== true) return;     // not recorded (or claimed elsewhere): Qosha's next answer decides
      noted = true;                                            // review r2 H4: only a recorded claim ends the tries
      try {
        var n = new window.Notification(t('title'), {body: t('notify'), tag: 'qosha-chrome-guide', icon: ICON});
        n.onclick = function (ev) {
          try { ev.preventDefault(); } catch (e) { /* none */ }
          try { window.focus(); } catch (e) { /* none */ }
          if (!onHome()) { if (typeof window.qoshaGo === 'function') window.qoshaGo('/'); else window.location.href = '/'; }
          try { n.close(); } catch (e) { /* none */ }
        };
      } catch (e) { /* the system refused: Home still shows the notice */ }
    }, function () { noting = false; });
  }
  function place() {                         // the notice is on Home only: it follows the person's moves in the app
    if (phase === 'offer' && !onHome()) { phase = 'none'; clear(); }
    else if (phase === 'none' && offered && onHome() && !busy) showOffer();
  }
  function read() {
    if (off || !tok() || dismissing || phase === 'steps' || phase === 'connected' || phase === 'working' || busy) return;
    var g0 = gen;
    call('guide').then(function (r) {
      if (g0 !== gen || dismissing || phase === 'steps' || phase === 'connected' || phase === 'working') return;   // answered too late (review r1, r2)
      if (r.status === 404) { off = true; return; }
      var d = r.data || {};
      if (!r.ok) return;
      offered = d.offer === true; folder0 = typeof d.folder === 'string' ? d.folder : '';
      if (!offered) { if (phase === 'offer') { phase = 'none'; clear(); } return; }
      if (d.notify === true) notifyOnce();
      place();
    }, function () { /* Qosha is restarting: the next minute tries again */ });
  }
  setTimeout(read, 5000);
  setInterval(read, 60000);
  window.addEventListener('focus', function () { setTimeout(read, 500); });
  setInterval(place, 1000);
})();
