/* "Qosha is working in your Chrome" bar with Show me / Stop (mc21, 22 Nov 2026). Loaded once by the dashboard shell
   (index.js) in the top window, on every Qosha page. Every 3 s it reads /api/plugins/qosha/chrome/status:
   * Qosha worked in the person's Chrome in the last 2 minutes: "Qosha is working in your Chrome · <site>" with Show me
     and Stop. Stop is a plain POST any Qosha page may make; it holds until the person lets Qosha continue.
   * Stopped or paused: says so, with "Let Qosha continue" (the Qosha app window only: the approval gate refuses it
     anywhere else, and the bar then says so).
   * The extension in Chrome is not the one this Qosha ships: "Load Qosha's extension again" (Settings > Browser).
   No bar otherwise. Text from the server is set as text, never as HTML. */
(function () {
  'use strict';
  if (window.__qoshaChrome || window.top !== window) return;
  window.__qoshaChrome = true;
  var API = '/api/plugins/qosha/chrome/';
  var bar = null, off = false, busy = false, last = '';
  function tok() { return String(window['__HERMES_SESSION_TOKEN__'] || ''); }
  function call(path, method) {
    return window.fetch(API + path, {method: method || 'GET', credentials: 'same-origin', cache: 'no-store',
      headers: {'X-Hermes-Session-Token': tok(), 'Content-Type': 'application/json'}});
  }
  function el(tag, css, text) { var e = document.createElement(tag); if (css) e.style.cssText = css; if (text != null) e.textContent = text; return e; }
  var BTN = 'margin-left:10px;padding:6px 14px;border-radius:999px;border:1px solid currentColor;background:transparent;' +
            'color:inherit;font:600 13px/1 inherit;cursor:pointer';
  function ensure() {
    if (bar) return bar;
    bar = el('div', 'position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:2147482990;display:none;' +
             'align-items:center;gap:8px;max-width:min(760px,calc(100vw - 32px));padding:8px 10px 8px 10px;' +
             'border-radius:14px;background:var(--q-forest,#0B3326);color:#fff;box-shadow:0 6px 24px rgba(0,0,0,.22);' +
             'font:500 14px/1.35 "Google Sans Flex","Google Sans","Helvetica Neue",sans-serif');
    bar.id = 'qosha-chrome-bar';
    bar.setAttribute('role', 'status');
    bar.setAttribute('aria-live', 'polite');
    document.body.appendChild(bar);
    return bar;
  }
  function render(st) {
    var b = ensure(), key, msg = '', btns = [];
    var act = st.activity || {};
    if (!st.enabled && !st.stopped) {
      key = 'none';
    } else if (st.mismatch) {
      key = 'mismatch';
      msg = 'The Qosha extension in Chrome is out of date. Load it again in Settings › Browser.';
    } else if (st.stopped) {
      key = 'stopped';
      msg = 'Stopped. Qosha won’t do anything in your Chrome until you let it.';
      btns = [['Let Qosha continue', 'continue']];
    } else if (st.paused) {
      key = 'paused';
      msg = 'Paused: you used Qosha’s tab in Chrome.';
      btns = [['Let Qosha continue', 'continue'], ['Stop', 'stop']];
    } else if (act.active && st.connected) {
      key = 'active|' + (act.site || '');
      msg = 'Qosha is working in your Chrome' + (act.site ? ' · ' + act.site : '');
      btns = [['Show me', 'show'], ['Stop', 'stop']];
    } else {
      key = 'none';
    }
    if (key === last) return;
    last = key;
    while (b.firstChild) b.removeChild(b.firstChild);
    if (key === 'none') { b.style.display = 'none'; return; }
    var tile = el('img', 'width:24px;height:24px;border-radius:7px;flex:none');
    tile.src = '/dashboard-plugins/qosha/assets/qosha-tile.png';
    tile.alt = '';
    b.appendChild(tile);
    b.appendChild(el('span', 'flex:1;min-width:0;padding:0 4px', msg));
    btns.forEach(function (one) {
      var x = el('button', BTN + (one[1] === 'stop' ? ';background:#fff;color:#0B3326;border-color:#fff' : ''), one[0]);
      x.type = 'button';
      x.addEventListener('click', function () { press(one[1], x); });
      b.appendChild(x);
    });
    // above the computer-use bar when both show
    var other = document.getElementById('qosha-desktop-bar');
    b.style.bottom = other && other.style.display !== 'none' ? '76px' : '18px';
    b.style.display = 'flex';
  }
  function press(what, x) {
    x.disabled = true;
    function again(text) { x.disabled = false; if (text) x.textContent = text; }
    call(what, 'POST').then(function (r) {
      if (r.status === 403) { again('Open the Qosha app to do this'); return null; }
      if (!r.ok) { again(what === 'stop' ? 'Stop (try again)' : 'Try again'); return null; }
      return r.json();
    }).then(function (st) {
      if (st && typeof st === 'object' && 'stopped' in st) { last = ''; render(st); } else if (st) { again(); }
      read();
    }, function () { again(what === 'stop' ? 'Stop (try again)' : 'Try again'); });
  }
  function read() {
    if (busy || off || !tok() || !document.body) return;
    busy = true;
    call('status').then(function (r) {
      if (r.status === 404) off = true;
      return r.ok ? r.json() : null;
    }).then(function (st) { busy = false; if (st) render(st); }, function () { busy = false; });
  }
  read();
  setInterval(read, 3000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) read(); });
})();
