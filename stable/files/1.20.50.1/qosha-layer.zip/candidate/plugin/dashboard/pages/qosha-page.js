/* Qosha owner pages: small shared helpers (UAT 2 Nov). Theme, the dashboard session token (read from the parent
   dashboard on every request, never stored, logged or put in a URL), JSON requests, safe element building (text only,
   never HTML from data), plain dates, and navigation inside the dashboard. */
(function () {
  'use strict';
  // CONTRACT-ACCESS: the Access ended card on every Qosha page (qosha-access.js; Settings stays open)
  try { var qa = document.createElement('script'); qa.src = (document.currentScript && document.currentScript.src ? new URL('qosha-access.js?v=1.20.6', document.currentScript.src).href : 'qosha-access.js?v=1.20.6'); qa.defer = true; (document.head || document.documentElement).appendChild(qa); } catch (e) { /* the engine's own block still stops every answer */ }
  var Q = {};
  try { if (window.localStorage.getItem('qosha.theme') === 'dark') document.documentElement.classList.add('t-dark'); } catch (e) { /* light */ }
  window.addEventListener('message', function (ev) {
    if (ev.origin === window.location.origin && ev.data && typeof ev.data.qoshaTheme === 'string') {
      document.documentElement.classList.toggle('t-dark', ev.data.qoshaTheme === 'dark');
    }
  });
  Q.token = function () {
    try {
      var f = window;
      while (f.parent && f.parent !== f) {
        f = f.parent;
        var t = f.__HERMES_SESSION_TOKEN__;
        if (typeof t === 'string' && /^[\x21-\x7e]+$/.test(t)) return t;
      }
    } catch (e) { /* no readable dashboard parent */ }
    return null;
  };
  // where this Qosha runs, for the words: a page that knows it sets Q.where ('mac', 'cloud' or 'computer'; Chat does,
  // from the assistants API); until then a page served over https is the cloud box (the Mac's Qosha is plain http on
  // this computer), and otherwise the words name no place
  Q.where = '';
  function where() { return /^(mac|cloud|computer)$/.test(Q.where) ? Q.where : window.location.protocol === 'https:' ? 'cloud' : ''; }
  Q.api = function (method, path, body, opts) {
    var headers = {};
    var t = Q.token();
    if (t) headers['X-Hermes-Session-Token'] = t;
    var init = {method: method, credentials: 'same-origin', cache: 'no-store', headers: headers};
    if (body instanceof FormData) init.body = body;
    else if (body !== undefined) { headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(body); }
    if (opts && opts.signal) init.signal = opts.signal;
    return fetch(path, init).then(function (r) {
      return r.text().then(function (txt) {
        var data = null;
        try { data = txt ? JSON.parse(txt) : null; } catch (e) { data = null; }
        if (!r.ok) {
          var d = data && (typeof data.detail === 'string' ? data.detail : (data.error || ''));
          var err = new Error(Q.plainError(r.status, d));
          err.status = r.status;
          // the server's own sentence, for a caller that knows its route sends plain words (Ask Gemini does)
          err.detail = data && typeof data.detail === 'string' ? data.detail.slice(0, 300) : '';
          if (data && data.detail && typeof data.detail === 'object') {   // a route's own code and plain sentence
            err.code = typeof data.detail.error === 'string' ? data.detail.error : undefined;
            err.plain = (typeof data.detail.plain === 'string' ? data.detail.plain
              : typeof data.detail.detail === 'string' ? data.detail.detail : '').slice(0, 300);
          }
          throw err;
        }
        return data;
      });
    }, function () {
      var w = where();
      throw new Error(w === 'cloud' ? 'Your cloud Qosha is not answering right now. Wait a minute, then try again.'
        : w === 'mac' || !w ? 'Qosha is not answering on this computer right now. Check that Qosha is running, then try again.'
        : 'Qosha is not answering on this computer right now. Check that Qosha is running, then try again.');
    });
  };
  Q.plainError = function (status, detail) {
    var w = where();
    if (status === 401 || status === 403) return w === 'cloud' ? 'This page needs to be opened inside your cloud Qosha (its sign-in is missing). Reload the page.'
      : 'This page needs to be opened inside Qosha (sign-in to this computer\'s Qosha is missing).';
    if (status === 404) return 'Not found. It may have been removed; reload the page.';
    // a 409's own plain sentence (never a bare error code) says why; the generic line only when there is none
    // (round 2: a plain sentence ends with . ! or ?, and carries no path and no all-caps code like ENOENT)
    // (round 3: at least two words, and no code such as TOKEN_CACHE_ERROR or SQLITE_BUSY either)
    if (status === 409) return (typeof detail === 'string' && detail.trim().length <= 300 && /\s/.test(detail.trim())
        && /[.!?]$/.test(detail.trim()) && !/[\/\\]/.test(detail)
        && !/(^|[^A-Za-z])[A-Z]{4,}(?![A-Za-z])|[A-Za-z0-9]_[A-Za-z0-9]/.test(detail)
        && !/hermes|nous/i.test(detail)) ? detail.trim()
      : 'That change isn\'t possible right now. Reload the page and try again.';
    // the engine's own error text can carry its internal names and paths: only a plain sentence is shown
    if (w === 'cloud') return 'Something went wrong in your cloud Qosha (error ' + status + '). Try again; if it keeps happening, tell Ren.';
    return 'Something went wrong on this computer (error ' + status + '). Try again; if it keeps happening, restart Qosha.';
  };
  // el('div', {class: 'x', onclick: fn, 'aria-label': 'y'}, 'text', child, ...): text is always text
  Q.el = function (tag, attrs) {
    var n = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v == null || v === false) return;
      if (k.slice(0, 2) === 'on' && typeof v === 'function') n.addEventListener(k.slice(2), v);
      else if (k === 'class') n.className = v;
      else if (k === 'text') n.textContent = v;
      else n.setAttribute(k, v === true ? '' : String(v));
    });
    for (var i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (c == null || c === false) continue;
      if (Array.isArray(c)) c.forEach(function (x) { if (x) n.appendChild(typeof x === 'string' ? document.createTextNode(x) : x); });
      else n.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
    }
    return n;
  };
  Q.clear = function (n) { while (n && n.firstChild) n.removeChild(n.firstChild); return n; };
  // plain dates: "Today 14:05", "Yesterday 09:12", "Mon 3 Nov", "3 Nov 2025"
  Q.when = function (v) {
    if (v == null || v === '') return '';
    var d = typeof v === 'number' ? new Date(v < 1e12 ? v * 1000 : v) : new Date(v);
    if (isNaN(d.getTime())) return '';
    var now = new Date(), day = 86400000;
    var start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    var hm = d.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
    if (d.getTime() >= start + day) {                 // the future (a next run): Tomorrow, a weekday, or a date
      if (d.getTime() < start + 2 * day) return 'Tomorrow ' + hm;
      if (d.getTime() < start + 7 * day) return d.toLocaleDateString([], {weekday: 'short', day: 'numeric', month: 'short'}) + ' ' + hm;
      return d.toLocaleDateString([], {day: 'numeric', month: 'short', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric'});
    }
    if (d.getTime() >= start) return 'Today ' + hm;
    if (d.getTime() >= start - day) return 'Yesterday ' + hm;
    if (d.getTime() >= start - 6 * day) return d.toLocaleDateString([], {weekday: 'short', day: 'numeric', month: 'short'});
    if (d.getFullYear() === now.getFullYear()) return d.toLocaleDateString([], {day: 'numeric', month: 'short'});
    return d.toLocaleDateString([], {day: 'numeric', month: 'short', year: 'numeric'});
  };
  // open a dashboard route (single-page navigation in the parent); a normal link when opened on its own
  Q.go = function (route) {
    var go = null;
    try { go = window.parent && window.parent !== window && window.parent.qoshaGo; } catch (e) { go = null; }
    if (typeof go === 'function') go(route); else window.location.href = route;
  };
  Q.status = function (node, text, isErr) {
    if (!node) return;
    node.textContent = text || '';
    node.classList.toggle('err', !!isErr && !!text);
    if (isErr && text) node.setAttribute('role', 'alert'); else node.setAttribute('role', 'status');
  };
  // the engine's name never on screen (Ren, 3 Nov 21:46): the same words as the dashboard shell (index.js), for
  // texts Qosha's pages show that the assistant made, e.g. a conversation's title. Display only.
  (function () {
    var H = 'h\u0065rmes', N = 'n\u006fus', HOME = '~/QoshaLab/home';
    function cased(word, like) {
      if (like === like.toUpperCase() && like !== like.toLowerCase()) return word.toUpperCase();
      return like.charAt(0) === like.charAt(0).toUpperCase() ? word.charAt(0).toUpperCase() + word.slice(1) : word;
    }
    var RULES = [
      // an address on the engine maker's site, or naming the engine: only a neutral host stays
      [new RegExp('https?://[^\\s"\'<>)]*(?:' + H + '|' + N + ')[^\\s"\'<>)]*', 'gi'), function (u) {
        var host = u.replace(/^https?:\/\//i, '').split(/[\/?#]/)[0];
        return new RegExp(H + '|' + N, 'i').test(host) ? 'the upstream website' : host + '/\u2026';
      }],
      [new RegExp('~/\\.' + H + '(?![A-Za-z0-9_])', 'gi'), function () { return HOME; }],
      [new RegExp('\\$\\{?' + H + '_HOME\\}?', 'gi'), function () { return HOME; }],
      // the engine maker's own models (e.g. "<maker>/<engine>-4-405b", "<engine> 3 70B") are not Qosha's: a neutral name
      [new RegExp('\\b' + N + ' ?research/' + H + '[- ]?', 'gi'), function () { return 'upstream/model-'; }],
      [new RegExp('\\b(?:' + N + '[- :]+)?' + H + '[- ]?(?=\\d)', 'gi'), function (m) { return cased('upstream model ', m); }],
      // who the assistant is: Qosha, by Qosha AI (only there: the maker's own models and services are never Qosha's)
      [new RegExp('\\b(I am|I\'m|I’m|you are|you\'re|you run on|this is|running on|runs on)\\s+' + H + '(?:[\\s_-]*agent)?,?\\s+\\(?(?:(?:built|made|created)\\s+)?by\\s+' + N + ' ?research\\)?', 'gi'),
       function (m, who) { return who + ' Qosha by Qosha AI'; }],
      // the engine's own docs and its program's module name (log lines) are the engine's, never Qosha's
      [new RegExp(H + '[\\s_-]*(?:agent[\\s_-]*)?(docs|documentation)\\b', 'gi'), function () { return 'upstream docs'; }],
      [new RegExp(H + '_cli\\b', 'gi'), function () { return 'engine'; }],
      [new RegExp(H + ' agent\\b', 'gi'), function (m) { return cased('qosha', m); }],
      [new RegExp('\\bthe ' + H + ' team\\b', 'gi'), function () { return 'the upstream team'; }],
      [new RegExp('@?(?<![A-Za-z])' + N + '[-_ ]?research\\b', 'gi'), function () { return 'the upstream project'; }],
      [new RegExp('(?<![A-Za-z])' + N + '[-_ ]?portal\\b', 'gi'), function (m) { return cased('engine portal', m); }],
      [new RegExp('\\b' + N + '-approved\\b', 'gi'), function (m) { return cased('curated', m); }],
      [new RegExp('(?<![A-Za-z])' + N + '[-_ ](?=[A-Za-z])', 'gi'), function () { return ''; }],
      [new RegExp('(?<![A-Za-z])' + N + '(?![A-Za-z])', 'gi'), function (m) { return cased('portal', m); }],
      [new RegExp(H, 'gi'), function (m) { return cased('qosha', m); }],
      [/\u2624/g, function () { return ''; }]];
    var HAS = new RegExp(H + '|(?<![A-Za-z])' + N + '|\u2624', 'i');
    Q.brand = function (t) { t = String(t == null ? '' : t); if (!HAS.test(t)) return t; for (var i = 0; i < RULES.length; i++) t = t.replace(RULES[i][0], RULES[i][1]); return t; };
  })();
  // ---- conversation titles: one rule for every list of conversations (the Home page carries the same rule) ---------
  // What a person reads for one conversation, never an id: the title it has (the person's own, or the one it was
  // given), else the words of its first message, else a plain label with its date.
  (function () {
    var IDS = /\s*\((?:Google Calendar event id|Calendar event id|Gmail message id|Gmail id|Gmail thread id|thread id)\s[^()]{1,200}\)/gi;
    var MODE = '(?:Chat\\. Answer in plain|Code\\. Work as a careful|Research\\. Search the web|Design\\. Make the page|Review\\. Give a critique|Automations\\. Set this up|Long-running\\. Treat this as)';
    var NOT_A_TITLE = new RegExp('^(?:\\(Qosha note:|@(?:file|folder|image|url|diff|staged|git):|\\[SYSTEM:|\\[What the person sees on Qosha Home|Untitled conversation\\b|Mode: ' + MODE + ')', 'i');
    var MODE_LINE = new RegExp('^\\s*Mode: ' + MODE + '[^\\n]*(?:\\n|$)');
    var MARK = '[What the person sees on Qosha Home right now';
    var T = {};
    function tx(text) { return window.QoshaI18n && typeof window.QoshaI18n.tx === 'function' ? window.QoshaI18n.tx(text) : text; }
    // A stored title without the engine's "#2" and without Qosha's own id notes. `by` is how the engine says the title
    // came to be: one it derived from the first message ('derived') and that is only something Qosha's own pages or
    // the engine put at the start of a message is no title (the first words name the conversation). A title a person
    // or the assistant wrote is never second-guessed.
    T.stored = function (title, by) {
      var t = String(title == null ? '' : title).replace(IDS, '').replace(/\s+/g, ' ').trim().replace(/\s+#\d{1,6}$/, '');
      return by === 'derived' && NOT_A_TITLE.test(t) ? '' : t;
    };
    // The words of a person's first message as a one-line title. Left out: what Qosha's own pages put around them (the
    // "Mode: ..." line the Chat page writes, "(Qosha note: ...)", file references, the "(Gmail id ...)" kind of id
    // notes, the JSON data note and the on-screen note). Spaces collapse; a long one is cut at a word near 60
    // characters. `text` is the engine's preview of the first message (its first 60 characters, then "...") or the
    // message itself. Gives {title, partial}: title '' when none of the person's words are in it; partial when one of
    // Qosha's notes took room in a preview the engine cut (or is all there is), so the message itself is read. A
    // preview with nothing of Qosha's in it is used as it is (a skill the person called reads as they typed it).
    T.parts = function (text) {
      var t = typeof text === 'string' ? text.slice(0, 4000) : '';
      var chars = Array.from(t);
      var cut = chars.length === 63 && t.slice(-3) === '...';
      if (cut) t = chars.slice(0, 60).join('');
      var raw = t, whole = t.replace(/\s+/g, ' ').trim(), before = null;
      var mark = t.indexOf(MARK);
      if (mark >= 0) t = t.slice(0, mark);
      else if (cut) {                                 // that note may begin inside the last characters of a preview
        var at = t.lastIndexOf('[');
        if (at >= 0 && MARK.indexOf(t.slice(at).replace(/\s+/g, ' ')) === 0) t = t.slice(0, at);
      }
      if (cut) {                                      // and so may any of the notes Qosha writes in brackets
        var open = t.lastIndexOf('('), tailNote = open >= 0 ? t.slice(open).replace(/\s+/g, ' ') : '';
        var NOTES = ['(the meeting in this JSON object', '(the email in this JSON object', '(Gmail id ', '(Gmail message id ', '(Gmail thread id ', '(thread id ', '(Calendar event id ', '(Google Calendar event id ', '(Qosha note:'];
        if (tailNote.length > 1 && tailNote.indexOf(')') < 0 && NOTES.some(function (m) { return m.indexOf(tailNote) === 0; })) t = t.slice(0, open);
      }
      while (before !== t) {
        before = t;
        t = t.replace(/^\s*\(Qosha note:[\s\S]*?(?:\)[ \t]*\n\s*\n|\)\s*$|$)/, '')
          .replace(MODE_LINE, '')
          .replace(/^\s*@(?:file|folder|image|url|diff|staged|git):(?:"[^"\n]*"|`[^`\n]*`|\S+)(?:\s+|$)/, '');
      }
      // (spaces are made single first, so each note is looked for from a fixed place)
      t = t.replace(/\s+/g, ' ')
        .replace(/ ?\((?:Google Calendar event id|Calendar event id|Gmail message id|Gmail id|Gmail thread id|thread id) [^()]*(?:\)|$)/gi, '')
        .replace(/ ?\((?:the meeting|the email) in this JSON object.*$/i, '')   // Home's data note: it and what follows
        .replace(/\s+/g, ' ').trim();
      var stripped = t !== whole;                            // something of Qosha's was in it
      var partial = (cut && stripped) || (!t && /\S/.test(whole));
      if (!t) return {title: '', partial: partial};
      var tail = t.slice(-12), tailKept = whole.slice(-tail.length) === tail;   // false when a note of Qosha's was the end
      var cps = Array.from(t);
      if (cps.length <= 60 && !(cut && tailKept)) return {title: t, partial: partial};
      var head = cps.slice(0, 60).join('');
      var midWord = cut ? !/\s$/.test(raw) : (cps.length > 60 && !/\s/.test(cps[60]));
      if (midWord && head.lastIndexOf(' ') > 0) head = head.slice(0, head.lastIndexOf(' '));
      return {title: head.replace(/[\s,;:.(\[\-–—]+$/, '') + '…', partial: partial};
    };
    T.fromPrompt = function (text) { return T.parts(text).title; };
    function whenFull(v) {
      if (v == null || v === '') return '';
      var n = Number(v), d = typeof v === 'number' || (String(v).trim() !== '' && isFinite(n)) ? new Date(n < 1e12 ? n * 1000 : n) : new Date(v);
      if (isNaN(d.getTime())) return '';
      var o = {month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'};
      if (d.getFullYear() !== new Date().getFullYear()) o.year = 'numeric';
      try { return d.toLocaleString(window.QoshaI18n && window.QoshaI18n.lang === 'pt-br' ? 'pt-BR' : undefined, o); } catch (e) { return ''; }
    }
    // how the engine says a row's title came to be: `by` when the caller named it, else the engine row's own field
    function by(s) { return s.by != null ? s.by : s.title_source; }
    // s: {title, by, preview, source, at} (by: the engine's title_source), or an engine row. An automation's first message is its own instructions, never a title: an
    // untitled run reads by the plain label (the lists show chats; a run is met only where a page lists it by title).
    T.name = function (s) {
      s = s || {};
      var auto = String(s.source || '') === 'cron', when = whenFull(s.at);
      return T.stored(s.title, by(s)) || (auto ? '' : T.fromPrompt(s.preview)) || tx('Conversation') + (when ? ' \u00b7 ' + when : '');
    };
    T.needsFirst = function (s) { return !!s && !T.stored(s.title, by(s)) && String(s.source || '') !== 'cron' && !!s.preview && T.parts(s.preview).partial; };
    // the person's first words of one conversation as a title, read from its first messages (for a row needsFirst
    // names); '' when there are none or the read fails
    T.first = function (id) {
      return Q.api('GET', '/api/sessions/' + encodeURIComponent(id) + '/messages?limit=6&offset=0&order=oldest&inline_images=false').then(function (body) {
        var list = body && Array.isArray(body.messages) ? body.messages : [];
        for (var i = 0; i < list.length; i++) {
          var m = list[i];
          if (!m || m.role !== 'user' || String(m.display_kind || '').toLowerCase() === 'hidden') continue;
          var v = m.display_content != null ? m.display_content : m.content;
          var text = typeof v === 'string' ? v : (Array.isArray(v) ? v.map(function (p) { return p && typeof p.text === 'string' ? p.text : ''; }).join('\n') : '');
          if (text.trim()) return T.fromPrompt(text);
        }
        return '';
      }, function () { return ''; });
    };
    window.QoshaTitle = T;
  })();
  window.Qosha = Q;
})();
