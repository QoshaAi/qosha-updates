"""Qosha's Gemini provider, as the engine finds it (<home>/plugins/model-providers/qosha-gemini/__init__.py).

The code itself is in the Qosha plugin (plugins/qosha/qosha_guard/gemini_provider/__init__.py), where Qosha's updates
and self-checks already look after it; this file only loads it, so there is never a second copy to go stale.
setup_home.py writes this file here (GEMINI-FULL, 26 Nov 2026)."""
import importlib.util
import sys

from hermes_constants import get_hermes_home

from pathlib import Path

_path = Path(get_hermes_home()) / "plugins" / "qosha" / "qosha_guard" / "gemini_provider" / "__init__.py"
if _path.is_file():                             # without the plugin's part there is no Gemini provider, and no error
    _spec = importlib.util.spec_from_file_location("qosha_gemini_provider", _path)
    if _spec is not None and _spec.loader is not None:
        _mod = importlib.util.module_from_spec(_spec)
        _spec.loader.exec_module(_mod)              # registers the provider profile with the engine
        sys.modules["qosha_gemini_provider"] = _mod     # published only once fully loaded
