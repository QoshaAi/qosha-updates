"""Qosha's startup barrier (GUARDFIX message 1, 6 Nov): no tool runs in a Qosha home until the approval guard is loaded
and has confirmed itself.

The engine discovers plugins in a background thread on some start paths (one-shot chats, fresh processes) and marks
discovery "done" before the plugins have registered their hooks, so a tool call arriving in that window found no guard
and ran (GOOGLEFIX: 2 of 10 fast runs). This module is installed beside the engine (a .pth file in the engine's own
environment imports it at every start, before the engine). When the engine's plugin module is imported it wraps the one
function every tool call passes through (hermes_cli.plugins._get_pre_tool_call_directive_details):
  1. wait for any discovery in flight (the engine's own join), running discovery if it never ran;
  2. in a Qosha home (HERMES_HOME/plugins/qosha exists), require a registered pre_tool_call callback that the Qosha
     plugin marked ready after its self-check (__qosha_guard_ready__); otherwise the call is BLOCKED.
Anything unexpected also blocks (fail closed). Outside a Qosha home it changes nothing.
Installed by install_barrier.py; the release suite checks it is active."""
import importlib.abc
import importlib.util
import os
import sys

TARGET = "hermes_cli.plugins"
BLOCKED = ("Not allowed by Qosha: Qosha's safety guard is not loaded and confirmed yet, so no tool runs. Nothing was "
           "done; try again in a moment.")


def _home() -> str:
    try:
        from hermes_constants import get_hermes_home
        return str(get_hermes_home())
    except Exception:
        return os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")


def _qosha_root_of_profile(home: str) -> str:
    """The Qosha home a named profile belongs to (<root>/profiles/<name>, the root holding plugins/qosha), or ""."""
    parent = os.path.dirname(os.path.normpath(home))
    root = os.path.dirname(parent)
    if os.path.basename(parent) == "profiles" and os.path.lexists(os.path.join(root, "plugins", "qosha")):
        return root
    return ""


def _qosha_home() -> bool:
    """A Qosha process or home: the box's or lab's own markers (QOSHA_BOX / QOSHA_LAB in the environment, set by their
    launchers), or a Qosha plugin entry (even a broken link), or Qosha named in the home's plugin settings. GPT r4: the
    absence of the plugin folder alone must not switch the barrier off."""
    if os.environ.get("QOSHA_BOX") or os.environ.get("QOSHA_LAB"):
        return True
    try:
        from hermes_constants import get_hermes_home
        home = str(get_hermes_home())
    except Exception:
        home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    if os.path.lexists(os.path.join(home, "plugins", "qosha")):
        return True
    if _qosha_root_of_profile(home):
        return True       # 1.20.4: a profile made without cloning has no plugin copy; it is still Qosha's (held below)
    try:
        with open(os.path.join(home, "config.yaml"), encoding="utf-8", errors="replace") as fh:
            return "qosha" in fh.read().lower()
    except OSError:
        return False


PROFILE_HELD = ("Not done: this profile has no copy of Qosha's safety guard, so no step runs here and nothing was sent, "
                "paid, deleted or shared. Tell the person plainly: switch back to Qosha's main profile to do this.")
LOCAL_HELD = ("Not done: Qosha's ask-first check is not loaded right now, so this action (%s) was not run and nothing was "
              "sent, paid, deleted or shared. Tell the person plainly and offer to repair Qosha yourself: check the Qosha "
              "plugin in the home folder (plugins/qosha) and the log (logs/agent.log), fix it, and restart Qosha.")


# r1210 (group 4, 22 Nov 2026): what is held by NAME when Qosha's guard isn't loaded on a person's computer: steps that
# act on websites, the desktop, other apps' servers, messages or Google, and wrappers that hide the real step. No
# classifier is needed for these, so a stale or missing one can't release them (findings 5, 6).
_HELD_BY_NAME = ("computer_use", "tool_call", "send_message", "qosha_google_change", "cronjob", "cronjob_manage",
                 "delegate_task", "qosha_computer_setup", "outlook_send", "dropbox_organize",
                 "qosha_chrome_setup", "qosha_browser_confirm")   # cu20 setup (GPT r1 CU-12); Qosha's Outlook and Dropbox tools (connectors)
_HELD_PREFIXES = ("browser_", "mcp__", "connectors__")
_READ_TOOLS = ("read_file", "search_files", "list_files", "list_directory", "web_search", "web_extract", "vision_analyze",
               "session_search", "skills_list", "skill_view", "todo", "clarify")
_COMMAND_TOOLS = ("terminal", "execute_code", "process", "process_manage")
MIN_GUARD_FORMAT = 20261122          # the oldest ask.py (GUARD_FORMAT) the fallback may use


def _held_by_name(tool_name) -> bool:
    t = str(tool_name or "")
    return t in _HELD_BY_NAME or t.startswith(_HELD_PREFIXES)


def _writes_qosha_home(tool_name, args) -> bool:
    """write_file / patch into Qosha's own home outside the person's files (its settings, plugins, approval code): held
    while the guard is down, as the self-edit card would ask (r1210 round 1, GPT 6)."""
    import re
    if not isinstance(args, dict):
        return False
    if tool_name in _COMMAND_TOOLS:            # a command naming Qosha's home or its settings files (r1210 r2, GPT 5)
        text = " ".join(str(args.get(k) or "") for k in ("command", "code", "input", "data"))
        home = os.path.realpath(_home())
        marks = (home, _home(), "config.yaml", "plugins/qosha", "plugins\\qosha", "qosha_guard", "auth.json", ".env",
                 "HERMES_HOME", "QOSHA_HOME", ".hermes")
        return any(m and m in text for m in marks)
    if tool_name not in ("write_file", "patch"):
        return False
    body = str(args.get("patch") or "")
    paths = [str(args.get("path") or args.get("file_path") or "")]
    # the engine's own patch headers, spacing as loose as its parser takes, and both ends of a move (r1210 r2, Gemini 2)
    paths += re.findall(r"^\*\*\*\s*(?:Update|Add|Delete)\s+File:\s*(.+?)\s*$", body, re.M | re.I)
    for a, b in re.findall(r"^\*\*\*\s*Move\s+File:\s*(.+?)\s*->\s*(.+?)\s*$", body, re.M | re.I):
        paths += [a, b]
    if re.search(r"^\*\*\*\s*Move\s+to:\s*(.+?)\s*$", body, re.M | re.I):
        paths += re.findall(r"^\*\*\*\s*Move\s+to:\s*(.+?)\s*$", body, re.M | re.I)
    fold = (lambda s: s.casefold()) if sys.platform in ("darwin", "win32") else (lambda s: s)
    home = fold(os.path.realpath(_home()))
    files = os.path.join(home, fold("files")) + os.sep
    for p in paths:
        if not p.strip():
            continue
        e = os.path.expanduser(p.strip())
        if not os.path.isabs(e):
            return True                        # where a relative path lands is the task's folder: not known here
        r = fold(os.path.realpath(e))
        if (r == home or r.startswith(home + os.sep)) and not r.startswith(files):
            return True
    return False


def _fallback(tool_name, args):
    """What Qosha holds when its guard isn't loaded, judged on the given (final) arguments: a plain-words kind, or None."""
    if _held_by_name(tool_name):
        return "a step on a website, the desktop, another app or Google"
    if _writes_qosha_home(tool_name, args):
        return "a change to Qosha's own settings or approval code"
    if tool_name in _READ_TOOLS:
        return None
    return _local_kind(tool_name, args)


def _local_kind(tool_name, args):
    """What the ask-first rule (plugins/qosha/qosha_guard/ask.py, loaded on its own) says this call is; if that file
    can't be loaded either, a plain-words fallback. None: the call may run."""
    try:
        from hermes_constants import get_hermes_home
        home = str(get_hermes_home())
    except Exception:
        home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    ask_py = os.path.join(home, "plugins", "qosha", "qosha_guard", "ask.py")
    if not os.path.exists(ask_py) and _qosha_root_of_profile(home):      # a profile without its own copy: the main one
        ask_py = os.path.join(_qosha_root_of_profile(home), "plugins", "qosha", "qosha_guard", "ask.py")
    try:
        spec = importlib.util.spec_from_file_location("qosha_ask_fallback", ask_py)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        if int(getattr(m, "GUARD_FORMAT", 0) or 0) < MIN_GUARD_FORMAT:
            raise RuntimeError("an older ask.py")   # a stale copy is never trusted (finding 5): the keyword rule decides
        k = m.kind_of(tool_name or "", args)
        return m.KIND_TEXT.get(k[0], k[0]) if k else None
    except Exception:
        try:                                   # anything unexpected here: held (G4, connectors)
            import re
            if _held_by_name(tool_name):       # the name first, before any argument is read (G4, connectors)
                return "send, pay, delete or share"
            if isinstance(args, dict):
                " ".join(str(v) for v in args.values())   # an argument that can't be read: held (G4), even for reads
            if tool_name in _READ_TOOLS:
                return None                        # a file's NAME is never an action ("sender.txt")
            if tool_name in _COMMAND_TOOLS and isinstance(args, dict):
                text = " ".join(str(args.get(k) or "") for k in ("command", "code", "input", "data"))
            else:
                text = (tool_name or "") + " " + " ".join(str(v) for v in (args or {}).values()) if isinstance(args, dict) else str(tool_name)
            hit = re.search(r"send|reply|forward|delete|remove|trash|\b(rm|rmdir|unlink|shred|truncate|mv|dd)\b|Remove-Item|del |"
                            r"pay|checkout|purchase|share|publish|post|git\b[^;&|\n]*\b(push|clean|reset)\b|rsvp|curl\b|wget\b", text, re.I)
            return "send, pay, delete or share" if hit else None
        except Exception:
            return "send, pay, delete or share"


def guard_ready(manager) -> bool:
    try:
        return any(getattr(cb, "__qosha_guard_ready__", False) is True
                   for cb in (getattr(manager, "_hooks", {}) or {}).get("pre_tool_call", []))
    except Exception:
        return False


def patch(mod) -> None:
    _patch_dispatch(mod)          # first, and on its own: an earlier barrier copy may have wrapped the directive already
    orig = getattr(mod, "_get_pre_tool_call_directive_details", None)
    if orig is None or getattr(orig, "__qosha_barrier__", False):
        return

    def _get_pre_tool_call_directive_details(tool_name, args, *a, **kw):
        try:
            qosha = _qosha_home()
        except Exception:
            qosha = True
        if qosha:
            try:
                mod._join_background_discovery()
                manager = mod._delivery_manager()      # runs discovery if it never ran
                mod._join_background_discovery()
                ok = guard_ready(manager)
            except Exception:
                ok = False
            if not ok:
                if os.environ.get("QOSHA_BOX") or os.environ.get("QOSHA_LAB"):
                    return mod._PreToolCallDirective(action="block", message=BLOCKED)
                # the person's own computer (Ren, 17 Nov): only what would send, pay, delete or share is held when the
                # ask-first check is missing; everything else runs, so Qosha can still repair itself
                h = _home()
                if not os.path.lexists(os.path.join(h, "plugins", "qosha")) and _qosha_root_of_profile(h):
                    # a profile without its own copy of the guard: nothing runs there (fail closed; v3 #4)
                    return mod._PreToolCallDirective(action="block", message=PROFILE_HELD)
                kind = _fallback(tool_name, args)
                if kind:
                    return mod._PreToolCallDirective(action="block", message=LOCAL_HELD % kind)
        return orig(tool_name, args, *a, **kw)

    _get_pre_tool_call_directive_details.__qosha_barrier__ = True
    _get_pre_tool_call_directive_details.__wrapped__ = orig
    mod._get_pre_tool_call_directive_details = _get_pre_tool_call_directive_details


DISPATCH_FAILED = ("Not done: Qosha's ask-first check could not finish for this step, so it did not run and nothing was "
                   "sent, paid, deleted or shared. Try again; if it keeps happening, restart Qosha.")


def _qosha_callback(mod):
    """Qosha's own ready callback, or None when it isn't loaded. A failure looking for it raises (refused: R3)."""
    for cb in (getattr(mod._delivery_manager(), "_hooks", {}) or {}).get("pre_tool_call", []):
        if getattr(cb, "__qosha_guard_ready__", False) is True:
            return cb
    return None


def _verdict_key(tool_name, args) -> str:
    import hashlib
    import json
    return hashlib.sha256(json.dumps([tool_name or "", args if isinstance(args, dict) else {}], sort_keys=True,
                                     default=str).encode()).hexdigest()


def _issued(mod):
    """The rule keys Qosha's own guard gave out (ask.ISSUED): a Qosha-named approve that is not among them is a copy."""
    cb = _qosha_callback(mod)
    rec = getattr(sys.modules.get(getattr(cb, "__module__", "") or ""), "ISSUED", None) if cb is not None else None
    return rec if isinstance(rec, dict) else {}


def _qosha_verdict(mod, tool_name, final, kw):
    """Qosha's own answer for the FINAL arguments: the one it gave in this dispatch when they are unchanged (recorded by
    ask.py per tool call), else asked again on the final ones (another plugin changed them; finding 3)."""
    cb = _qosha_callback(mod)
    if cb is None:
        kind = _fallback(tool_name, final)     # guard not loaded: the fallback, on the final arguments (R3)
        return {"action": "block", "message": LOCAL_HELD % kind} if kind else None
    tcid = str(kw.get("tool_call_id") or "")
    rec = getattr(sys.modules.get(getattr(cb, "__module__", "") or ""), "VERDICTS", None)
    fkey = _verdict_key(tool_name, final)
    slot = tcid or ("args:" + fkey)          # no id (code-execution calls): by the arguments (r1210 r2, GPT 4)
    if isinstance(rec, dict) and slot in rec:
        key, answer = rec.pop(slot)
        if key == fkey:
            return answer
    return cb(tool_name=tool_name, args=final, task_id=kw.get("task_id", "") or "",
              session_id=kw.get("session_id", "") or "", tool_call_id=tcid)


import contextvars as _cv
_STRICT = _cv.ContextVar("qosha_card_needs_a_person", default=False)


def _install_strict() -> bool:
    """Once per process: while Qosha's own card is asked (and only in that request's context), the engine's shortcuts
    don't apply: no yolo, no "approvals off", no AI deciding (smart), and cron / single-query / unattended runs count
    as "deny" (nobody can answer: refused). Other requests keep their settings (r1210 round 1: GPT 1, 9; Gemini 1, 5)."""
    try:
        import tools.approval as ap
        import tools.approval_context as ac
    except Exception:
        return False
    if getattr(ap, "_qosha_strict_card", False):
        return True

    def wrap(obj, name, strict_value):
        orig = getattr(obj, name, None)
        if orig is None:
            return False

        def f(*a, **kw):
            if _STRICT.get():
                return strict_value(orig, a, kw)
            return orig(*a, **kw)
        f.__wrapped__ = orig
        setattr(obj, name, f)
        return True

    ok = wrap(ap, "_yolo_active", lambda o, a, k: False)
    ok = wrap(ap, "is_approval_bypass_active_for_session", lambda o, a, k: False) and ok
    ok = wrap(ac, "_get_approval_mode", lambda o, a, k: (lambda m: "manual" if m in ("off", "smart") else m)(o(*a, **k))) and ok
    for n in ("cron", "single_query", "unattended"):
        ok = wrap(ac, "_get_%s_approval_mode" % n, lambda o, a, k: "deny") and ok
    ap._qosha_strict_card = ok
    return ok


def patch_middleware(mw, mod) -> None:
    """Execution middleware that hands the tool different arguments than were judged: the new ones are judged again
    (Qosha's verdict and card), and a refusal stops the tool (r1210 round 1: GPT 3, Gemini 3)."""
    orig = getattr(mw, "run_tool_execution_middleware", None)
    if orig is None or getattr(orig, "__qosha_barrier__", False):
        return

    def run_tool_execution_middleware(tool_name, args, next_call, **context):
        try:
            local = _qosha_home() and not (os.environ.get("QOSHA_BOX") or os.environ.get("QOSHA_LAB"))
        except Exception:
            local = True
        if not local:
            return orig(tool_name, args, next_call, **context)
        import copy
        import json
        judged = copy.deepcopy(args)

        def guarded(next_args=None):
            # a private copy goes on, never the middleware's own object (r1210 r2, GPT 3)
            final = copy.deepcopy(next_args) if isinstance(next_args, dict) else copy.deepcopy(judged)
            if final != judged:
                ids = {k: context.get(k, "") or "" for k in ("turn_id", "tool_call_id", "session_id", "task_id")}
                msg, changed = mod._dispatch_pre_tool_call_hooks(tool_name, final, **ids)
                if msg is not None:
                    return json.dumps({"error": msg})
                final = changed if isinstance(changed, dict) else final
            return next_call(final)
        return orig(tool_name, args, guarded, **context)

    run_tool_execution_middleware.__qosha_barrier__ = True
    run_tool_execution_middleware.__wrapped__ = orig
    mw.run_tool_execution_middleware = run_tool_execution_middleware


def _patch_dispatch(mod) -> None:
    """On a person's computer: Qosha's guard has the last word on the arguments that actually run, its card is always
    asked by a person, and any failure refuses the step (group 4 findings 1-4). The engine's call sites import this
    function at each call, so replacing the module attribute covers all of them."""
    orig = getattr(mod, "_dispatch_pre_tool_call_hooks", None)
    if orig is None or getattr(orig, "__qosha_barrier__", False):
        return

    def _dispatch_pre_tool_call_hooks(tool_name, args, *a, **kw):
        try:
            local = _qosha_home() and not (os.environ.get("QOSHA_BOX") or os.environ.get("QOSHA_LAB"))
        except Exception:
            local = True
        if not local:
            return orig(tool_name, args, *a, **kw)
        try:
            import copy
            try:
                import hermes_cli.middleware as _mw
                patch_middleware(_mw, mod)
            except ImportError:
                pass
            details = mod._get_pre_tool_call_directive_details(tool_name, args, **kw)
            ids = {k: kw.get(k, "") or "" for k in ("turn_id", "tool_call_id", "session_id")}
            changed = getattr(details, "modified_args", None)
            # a private copy is judged, and that copy is what runs (R2): a later change to the caller's object is ignored
            final = copy.deepcopy(changed if changed is not None else args)
            if getattr(details, "action", None) == "block":
                return details.message, final
            q = _qosha_verdict(mod, tool_name, final, kw)
            if isinstance(q, dict) and q.get("action") == "block":
                return (q.get("message") or DISPATCH_FAILED), final
            mine = isinstance(q, dict) and q.get("action") == "approve"
            dkey = str(getattr(details, "rule_key", "") or "")
            if getattr(details, "action", None) == "approve" and not (mine and dkey == (q.get("rule_key") or "")):
                if dkey.startswith(("qosha:", "plugin_rule:qosha:")):
                    if dkey not in _issued(mod):
                        return ("Not done: another plugin asked for approval under one of Qosha's own rule names, so "
                                "this step was not run."), final                 # R4
                    # Qosha's own answer for the arguments as first given: its answer on the final ones decides (q)
                else:
                    msg = mod._resolve_block_from_details(details, tool_name, **ids)   # another plugin's own ask
                    if msg is not None:
                        return msg, final
            if mine:
                if not _install_strict():
                    return DISPATCH_FAILED, final
                d = mod._PreToolCallDirective(action="approve", message=q.get("message"), rule_key=q.get("rule_key"))
                tok = _STRICT.set(True)
                try:
                    msg = mod._resolve_block_from_details(d, tool_name, **ids)
                finally:
                    _STRICT.reset(tok)
                if msg is not None:
                    return msg, final
            return None, final
        except Exception:
            return DISPATCH_FAILED, None

    _dispatch_pre_tool_call_hooks.__qosha_barrier__ = True
    _dispatch_pre_tool_call_hooks.__wrapped__ = orig
    mod._dispatch_pre_tool_call_hooks = _dispatch_pre_tool_call_hooks


class _Loader(importlib.abc.Loader):
    def __init__(self, inner):
        self.inner = inner

    def create_module(self, spec):
        return self.inner.create_module(spec)

    def exec_module(self, module):
        self.inner.exec_module(module)
        patch(module)


class _Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path=None, target=None):
        if name != TARGET:
            return None
        for f in sys.meta_path:
            if f is self or not hasattr(f, "find_spec"):
                continue
            spec = f.find_spec(name, path, target)
            if spec is not None:
                if spec.loader is not None:
                    spec.loader = _Loader(spec.loader)
                return spec
        return None


def install() -> None:
    if TARGET in sys.modules:
        patch(sys.modules[TARGET])
    elif not any(isinstance(f, _Finder) for f in sys.meta_path):
        sys.meta_path.insert(0, _Finder())


install()
