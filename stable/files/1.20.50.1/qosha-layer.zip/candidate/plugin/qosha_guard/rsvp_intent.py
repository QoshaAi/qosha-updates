"""Home's own Accept / Maybe / Decline press on a meeting invite (24 Nov 2026; Ren's card "Bind click to answer").

Round 1 recorded the press in a profile file that the assistant then used. Verification (GPT + Gemini, HIGH) showed the
assistant could write that file itself, with no card, and forge a press; the races, account and calendar gaps came from
the same file. So the assistant is not in Home's path at all: Home's button calls this route in the Home page's own
process, Qosha's own window only, and the route makes the answer itself through Qosha's one Google executor
(google_write.run_home_press) for exactly the meeting the peek showed (its rsvp_fp from /calendar/events). There is no
file, no press to claim, nothing another process or the assistant can write. One Home answer at a time.
"""
import importlib
import importlib.util
import json
import sys
import threading
from pathlib import Path

NOT_WINDOW = "Only Qosha's own window can answer a meeting invite from Home."
BAD = "Not done: that isn't a meeting and an answer Qosha can send."
BUSY = "Not done: Qosha is still answering another invite from Home. Try again in a moment."
SENT_NOTHING = "Nothing was sent: the meeting changed after you allowed it in the window. Open it again to answer."
_ONE = threading.Lock()
_GUARD_DIR = Path(__file__).resolve().parent


def _gw():
    """Qosha's Google executor in the Home page's process: the guard package as the dashboard loads it (decisions_api)."""
    m = sys.modules.get("qosha_guard.google_write")
    if m is not None:
        return m
    if "qosha_guard" not in sys.modules:
        spec = importlib.util.spec_from_file_location("qosha_guard", _GUARD_DIR / "__init__.py",
                                                      submodule_search_locations=[str(_GUARD_DIR)])
        pkg = importlib.util.module_from_spec(spec)
        sys.modules["qosha_guard"] = pkg
        spec.loader.exec_module(pkg)
    return importlib.import_module("qosha_guard.google_write")


def answer(event_id, response, fp, etag=None) -> dict:
    """The press itself (the route's body, checked): one at a time; the executor decides everything else."""
    if not isinstance(event_id, str) or not 1 <= len(event_id) <= 1024 or response not in ("accepted", "tentative", "declined") \
            or not isinstance(fp, str) or not 1 <= len(fp) <= 200:
        return {"ok": False, "message": BAD, "_status": 400}
    if not _ONE.acquire(blocking=False):
        return {"ok": False, "message": BUSY, "_status": 409}
    try:
        return _gw().run_home_press(event_id, response, fp, etag=etag) if etag is not None else \
            _gw().run_home_press(event_id, response, fp)
    finally:
        _ONE.release()


AFTER = []   # called after every press that reached the executor (the dashboard drops its saved calendar reads)


def _after() -> None:
    for fn in list(AFTER):
        try:
            fn()
        except Exception:  # noqa: BLE001
            pass


def mount(router=None) -> None:
    """POST /api/plugins/qosha/google/rsvp {event_id, response, fp}: Qosha's own window only (approval_gate's
    from_qosha_window, fail closed), plus the dashboard's session token as for every route. Answers the executor's
    result: {ok, message, result?}; Home says "Done" only when ok and result.answered is the click and home_press."""
    if router is None:
        return
    from fastapi import Request
    from fastapi.responses import JSONResponse
    from starlette.concurrency import run_in_threadpool

    def _window(request) -> bool:
        gate = sys.modules.get("qosha_approval_gate")
        try:
            return bool(gate is not None and getattr(gate, "_app_installed")() and gate.from_qosha_window(request.scope))
        except Exception:  # noqa: BLE001
            return False

    async def _post(request: Request):
        if not _window(request):
            return JSONResponse(status_code=403, content={"ok": False, "message": NOT_WINDOW})
        try:
            body = await request.json()
        except Exception:  # noqa: BLE001
            body = None
        if not isinstance(body, dict) or set(body) != {"event_id", "response", "fp"}:
            return JSONResponse(status_code=400, content={"ok": False, "message": BAD})
        approved = request.scope.get("qosha_window_approved")
        etag = None
        if approved is not None:
            # after the locked window's Allow: act on exactly what the person approved there, that version only
            # (trusted-surface 3c72a119, GPT GA-G01): the body must be it, and Google is answered with its etag
            if not isinstance(approved, dict) or approved.get("event_id") != body.get("event_id") or \
                    approved.get("answer") != body.get("response") or approved.get("fp") != body.get("fp") or \
                    not isinstance(approved.get("etag"), str):
                return JSONResponse(status_code=409, content={"ok": False, "message": SENT_NOTHING})
            etag = approved["etag"]
        try:
            out = await run_in_threadpool(answer, body["event_id"], body["response"], body["fp"], etag)
        except Exception:  # noqa: BLE001
            _after()
            # the executor itself never raises once a request may have reached Google (it answers "Outcome unknown"),
            # so this is before any change; still worded so it can never wrongly promise "not changed"
            return JSONResponse(status_code=503, content={"ok": False, "message": "Qosha couldn't confirm this answer. "
                                                          "Check the meeting in Google Calendar before trying again."})
        _after()
        status = out.pop("_status", 200)
        if etag is not None and out.pop("stale", False):
            return JSONResponse(status_code=409, content={"ok": False, "message": SENT_NOTHING})
        out.pop("stale", None)
        return JSONResponse(status_code=status, content=out, headers={"Cache-Control": "no-store"})

    router.post("/google/rsvp")(_post)
    _register_window()


ROUTE_RX = r"^/api/plugins/qosha/google/rsvp/?$"


def _describe(body: bytes, query: str, path: str = ""):
    """The locked Allow window's rows for a Home press (window_gate.register_confirmable): read from Google by the
    executor, never the page's words; None refuses (403, no window). `path` must be this route, whole."""
    import re
    if path and not re.fullmatch(ROUTE_RX, path):
        return None
    try:
        d = json.loads(body.decode("utf-8")) if isinstance(body, (bytes, bytearray)) else None
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(d, dict) or set(d) != {"event_id", "response", "fp"}:
        return None
    try:
        return _gw().home_window_facts(d["event_id"], d["response"], d["fp"])
    except Exception:  # noqa: BLE001
        return None


def _recheck(payload) -> bool:
    try:
        ok = _gw().home_window_recheck(payload) is True        # exactly True: anything else is no (window_gate rule)
    except Exception:  # noqa: BLE001
        ok = False
    if not ok:
        _after()             # the meeting changed while the window was open: no saved calendar read is served (verify 7)
    return ok


def _register_window() -> None:
    """Ren, ~23:55 26 Nov, "Confirm in the window": where the locked Allow window is on, Home's press opens it for one
    confirm of exactly {meeting, time, organizer, answer}, and only that window's press reaches the route (its mark is
    what makes from_qosha_window true). A window module without the API (1.20.50) registers nothing: there the route's
    own window check decides, as before."""
    gate = sys.modules.get("qosha_approval_gate")
    try:
        wg = gate._window_gate() if gate is not None and hasattr(gate, "_window_gate") else None
        if wg is not None and hasattr(wg, "register_confirmable"):
            wg.register_confirmable("POST", ROUTE_RX, _describe, kind="send", recheck=_recheck)
    except Exception:  # noqa: BLE001
        pass                            # no window: the route still refuses anything not from Qosha's own window
