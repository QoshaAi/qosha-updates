"""The Google connector always reads as the connected account (1.20.50, cal-read).

Every tool of the Google connector (engine name mcp__google__<tool>) wants a `user_google_email`. Nothing told the
assistant which account is connected, so it guessed: "me" was refused ("No valid 'user_google_email'"), and a wrong
address made the connector start its own Google sign-in. Qosha keeps one Google account; this hook puts that account
in, whatever the assistant sent. The account is the one Connections shows (google_connect.shown_account: the copy that
holds Qosha's stored sign-in), never just a file that happens to be in the folder (review r1, CAL-02)."""
from pathlib import Path
from typing import Any, Dict, Optional

KEY = "user_google_email"
NOT_CONNECTED = ("Not run: Google is not connected in Qosha on this computer, so there is nothing to read. Tell the "
                 "person to press Connect Google in Qosha, then try again. Don't ask them for an email address or a "
                 "sign-in link.")
NOT_CHECKED = "Not run: Qosha could not check which Google account is connected. Nothing was done."


def connected() -> str:
    """The connected Google account as Connections shows it, or ""."""
    from . import google_connect
    return str(google_connect.shown_account(Path(google_connect._home())) or "")


def _account_files() -> bool:
    """Whether the sign-in folder holds any account's file at all (names only)."""
    from . import google_connect
    d = Path(google_connect._home()) / "google_workspace_mcp" / "credentials"
    return d.is_dir() and any("@" in f.name[:-5].strip("@") for f in d.iterdir() if f.name.endswith(".json"))


def pre_tool_call(tool_name: str = "", args: Any = None, **_: Any) -> Optional[Dict[str, Any]]:
    try:
        if not str(tool_name or "").strip().lower().startswith("mcp__google__"):
            return None
        if not isinstance(args, dict) or KEY not in args:
            return None                      # a tool with no account field: nothing to fill in
        account = connected()
        if "@" not in account:
            if not _account_files():
                return {"action": "block", "message": NOT_CONNECTED}
            return None                      # files but no match (Google renewed the grant, or a leftover): as before
        if args.get(KEY) == account:         # only the stored spelling passes as it is (CAL-03)
            return None
        return {"action": "modify", "args": {KEY: account}}
    except Exception:
        return {"action": "block", "message": NOT_CHECKED}
