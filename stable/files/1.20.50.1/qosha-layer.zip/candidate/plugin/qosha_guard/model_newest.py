"""The provider's own newest model, for Qosha's defaults (Ren, 26 Nov 2026: ChatGPT "Yes, follow newest").

"Newest" is the provider's own top visible model: the first row of the account's VERIFIED catalogue as the engine
keeps it on disk (`provider_models_cache.json`, written by the engine's own picker refresh; ranked by the provider's
priority). Only a row for the credentials in use right now counts (the engine's own fingerprint: an account switch
invalidates it), and never a curated fallback row, a saved choice or a locally declared model (review F03/F04/F06).
Nothing here touches the network, starts a program or reads a credential beyond what the engine's fingerprint reads.
When no verified row is on this computer (a first start, signed out, an engine change), the safe fallback below is
used: a model the provider served when this release was checked (gates/models_current.py checks it every release).
"""

FALLBACK = {"openai-codex": "gpt-6.2-sol"}
_VARIANT = "-900k"   # the engine's own large-context picker variant, never a provider row of its own


def verified_top(pid: str):
    """The first model of the provider's verified catalogue on this computer, or None."""
    try:
        from hermes_cli import models as hm
        entry = hm._load_provider_models_cache().get(pid)
        if not isinstance(entry, dict) or entry.get("fallback"):
            return None
        if not hm._cache_entry_valid(entry, hm._credential_fingerprint(pid)):
            return None
        for m in entry.get("models") or []:
            if isinstance(m, str) and m and not m.endswith(_VARIANT):
                return m
    except Exception:
        return None
    return None


def newest(pid: str) -> str:
    """The provider's newest model: verified when known here, else the safe fallback ('' for a provider without one)."""
    return verified_top(pid) or FALLBACK.get(pid, "")
