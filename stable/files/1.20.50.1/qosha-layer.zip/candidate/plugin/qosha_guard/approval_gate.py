"""Only the real Qosha window can answer a card or change approval settings (Ren, card, 21 Nov 2026 ~21:55 MST, verbatim
choice: "Yes, both (Recommended)": "only the real Qosha window can press Allow, because Qosha checks which program owns
the connection").

Why: the dashboard puts its key in the page it serves at GET / to anyone on this computer, so the assistant's own
terminal could read it and answer its own card (S0 finding, 21 Nov). The key stays as it is (Qosha's pages need it);
what changes is that the routes that answer or grant approval also check WHICH PROGRAM owns the connection: the Qosha
app's own processes pass, anything else (curl, a script, another browser) is refused with a plain message.

Narrowed (Ren, card ~23:50 MST, verbatim choice "Keep browser chat"): browser tabs keep chat and ordinary settings;
answering, granting or turning off approval needs the app window. Done as ALLOWLISTS for anything that is not the
window (one ASGI gate in front of the dashboard app): the chat socket passes only the methods Qosha's chat uses (with
their session fields), and answers only to the engine's clarify/sudo/secret questions (never an approval answer);
REST writes pass only for Qosha's own plugin routes (except answering a decision), AI sign-in, saving an AI key,
renaming/deleting a chat, voice transcription, pausing/cancelling a job or running one now that is not paused, and
settings saves that change only display,
timezone, streaming and two Browser switches (shrunk after the round-2 verification); turning the inbox watch back on
when its job is paused needs the window;
sockets other than the chat socket, the event feed and voice streams are refused. The app window passes unchanged.
In the gateway process: the two ticket kinds that can answer cards or change settings ("interactive", "native-http") go
only to the process holding Qosha's dashboard port on 127.0.0.1 (the dashboard forwards its window's actions with them).
Known limit (same-user programs, MEDIUM): a program running as the person can still drive the window itself.
"""
from __future__ import annotations

import contextvars
import json
import logging
import os
import re
import sys
import threading
import time
from pathlib import Path


def _floor_marker() -> bool:
    """The native floor (council RC6): once this install answered approvals only in Qosha's approval window, the
    marker keeps it so in every later build that honours it (a rollback to N included), without patching any file."""
    try:
        from hermes_constants import get_default_hermes_root
        root = str(get_default_hermes_root())
    except Exception:
        root = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    try:
        return os.path.exists(os.path.join(root, "qosha", "native-approval.json"))
    except Exception:
        return True

log = logging.getLogger("qosha.approval_gate")

# with the trusted surface on: approvals are answered in Qosha's own approval window; old pages show this text as it is
# (they show a refusal verbatim when it starts with "Only the Qosha app window")
NATIVE_REFUSED = ("Only the Qosha app window's approval window can answer this now: Qosha opened it as a separate "
                  "window titled \"Qosha approval\". Answer there (or choose Show the approval window).")
REFUSED = ("Only the Qosha app window can do this (answer a card, or change what Qosha may do without asking). It "
           "was refused because it came from somewhere else (a browser tab or another program). Open the Qosha app "
           "and do it there.")
ANSWER_REFUSED = ("Open the Qosha app to approve: cards can only be answered in the Qosha app window, not in a browser "
                  "tab or another program.")
# Ren, card ~23:50 MST, "Keep browser chat": browser tabs keep chat and ordinary settings; only what answers, grants or
# turns off approval needs the app window. These writes always need it:
# A browser tab (any caller that is not the Qosha app window) may do only what Qosha's chat and ordinary settings use
# (Ren, card ~23:50 MST 21 Nov, "Keep browser chat"); everything else needs the window. An allowlist, so engine routes
# and socket methods added later are refused to browser tabs until someone decides otherwise (verification pass NG-1..15).
_BROWSER_HTTP = [   # (methods, path) writes a browser tab may make; PUT /api/config, PUT /api/env and running a job
    #                 now have their own checks below
    # cu20: lifting the person's Stop and setting up computer use are the window's only (desktop/continue, setup)
    ({"POST", "PUT", "PATCH", "DELETE"}, re.compile(r"^/api/plugins/qosha/(?!decisions/[^/]+/(approve|decline)/?$"
                                                    r"|desktop/+(?:continue|setup)(?:/|$)|trust/+on(?:/|$)"
                                                    r"|chrome/+(?:continue|setup|mode|open-extensions|show-folder|forget)(?:/|$))")),   # Trust mode ON: the window only
    ({"POST"}, re.compile(r"^/api/audio/transcribe/?$")),
    ({"POST"}, re.compile(r"^/api/providers/oauth/[^/]+/(start|submit)/?$")),          # signing in to an AI account
    ({"DELETE"}, re.compile(r"^/api/providers/oauth/sessions/[^/]+/?$")),
    ({"PATCH", "DELETE"}, re.compile(r"^/api/sessions/[^/]+/?$")),                       # rename / archive / delete a chat
    ({"POST"}, re.compile(r"^/api/cron/jobs/[^/]+/(pause|cancel)/?$")),
]
_BROWSER_SOCKETS = re.compile(r"^/api/(events|audio/(transcribe|speak)-stream|plugins/[^/]+/events)/?$")
# settings a browser tab may change: these top-level sections only, never the two paid-AI switches
# Shrunk after the round-2 verification (NG2-2/3/4): only these whole sections, and only these fields of "browser"
# (the switches Qosha's Browser page shows, except "use my own Chrome profile", which asks first). The model, its
# endpoints, browser and runtime programs, and every other section need the app window.
_BROWSER_CONFIG = frozenset({"display", "timezone", "streaming"})
_BROWSER_CONFIG_FIELDS = {"browser": frozenset({"headed", "qosha_stay_behind"})}
_PAID_SWITCHES = (("qosha_ai", "claude_key_on_limit"), ("qosha_ai", "paid_backup_on_limit"))
_BROWSER_ENV_KEY = re.compile(r"^((?!QOSHA_|HERMES_)[A-Z][A-Z0-9_]*_API_KEY|HF_TOKEN)$")   # an AI account's key
_BROWSER_ENV_FIELDS = frozenset({"key", "value", "profile", "api_key", "provider_setup"})
# the chat socket: the methods Qosha's chat page and Home's panels use, with the session fields they send
_BROWSER_WS_METHODS = frozenset({
    "ping", "client.capabilities", "session.create", "session.resume", "session.close", "session.interrupt",
    "session.set_hidden", "prompt.submit", "file.attach", "image.attach", "image.attach_bytes", "pdf.attach",
    "image.detach", "clarify.respond", "sudo.respond", "secret.respond", "config.set"})
_SESSION_CREATE_FIELDS = frozenset({"source", "close_on_disconnect", "title", "provider", "model", "reasoning_effort",
                                    "cwd", "cols", "rows"})
_CONFIG_SET_KEYS = frozenset({"reasoning", "model"})
# what a chat message from a browser tab may carry (Qosha's pages send session_id, text, queued): never a transcript
# rewind or its confirmations, never hosted-turn fields (review FO2-14, also for the browser-tab rules)
_PROMPT_FIELDS = frozenset({"session_id", "text", "queued", "interrupted", "display_kind", "title_preview",
                            "voice_turn", "voice_context"})
_REPLY_KINDS = frozenset({"clarify", "sudo", "secret"})     # server questions a browser tab may answer (never "approval")
_MAX_BODY = 4 * 1024 * 1024
_READ_METHODS = ("GET", "HEAD", "OPTIONS")
_LOOPBACK = {"127.0.0.1", "::1", "localhost"}


# ---- which program owns a connection -----------------------------------------------------------------------------
def _app_roots() -> list[str]:
    """Where the Qosha app is installed (lower-case path prefixes of its executables)."""
    roots = []
    if os.name == "nt":
        la = os.environ.get("LOCALAPPDATA", "")
        if la:
            roots.append(os.path.join(la, "Programs", "Qosha") + os.sep)
    else:
        roots += [str(Path.home() / "Applications" / "Qosha.app") + "/", "/Applications/Qosha.app/"]
    out = []
    for r in roots:                                     # both as written and as the system reports it (/var vs /private/var)
        for v in (r, os.path.realpath(r.rstrip("/\\")) + os.sep):
            if v.lower() not in out:
                out.append(v.lower())
    return out


_cache = {"at": 0.0, "pids": ()}
_lock = threading.Lock()


def _app_installed() -> bool:
    for r in _app_roots():
        if os.path.isdir(r.rstrip("/\\")):
            return True
    return False


def _app_pids(refresh: bool = False) -> tuple:
    import psutil
    with _lock:
        if not refresh and time.monotonic() - _cache["at"] < 10:
            return _cache["pids"]
        roots = _app_roots()
        pids = []
        for p in psutil.process_iter(["pid", "exe"]):
            exe = (p.info.get("exe") or "").lower()
            if exe and any(exe.startswith(r) for r in roots):
                pids.append(p.info["pid"])
        _cache.update(at=time.monotonic(), pids=tuple(pids))
        return _cache["pids"]


def _owner_is_app(peer_port: int, server_port: int) -> bool:
    import psutil
    for attempt in (False, True):                       # a window opened a moment ago: look again once
        for pid in _app_pids(refresh=attempt):
            try:
                for c in psutil.Process(pid).net_connections(kind="tcp"):
                    if c.laddr and c.laddr.port == peer_port and c.raddr and c.raddr.port == server_port:
                        return True
            except (psutil.Error, OSError):
                continue
    return False


def from_qosha_window(scope) -> bool:
    """True only when the connection's other end is one of the Qosha app's own processes (fail closed). With the
    trusted surface on, no connection is privileged by where it comes from: only a request the person allowed in
    Qosha's approval window (marked on its scope by the gate itself, which no caller can set) counts."""
    if _native():
        try:
            return scope.get("qosha_window_allowed") is _window_gate().ALLOWED
        except Exception:
            return False
    try:
        client, server = scope.get("client"), scope.get("server")
        if not client or not server or str(client[0]) not in _LOOPBACK:
            return False
        return _owner_is_app(int(client[1]), int(server[1]))
    except Exception:
        return False


# ---- the gate -----------------------------------------------------------------------------------------------------
def _query(scope) -> str:
    qs = scope.get("query_string") or b""
    return qs.decode("latin-1") if isinstance(qs, bytes) else str(qs)


def _default_profile(query: str, body_profile=None) -> bool:
    """A browser tab's write must be for the profile this dashboard serves (Qosha uses "default"); a repeated or other
    selector is refused (round-2 NG2-5, NG-11)."""
    from urllib.parse import parse_qs
    vals = parse_qs(query, keep_blank_values=True).get("profile") or []
    if len(vals) > 1:
        return False
    return all(str(v or "").strip() in ("", "default", "current") for v in (vals[0] if vals else "", body_profile))


def _ticketed_socket(scope) -> bool:
    """A socket that carries no page key but the engine's own server-spawned credential (?internal=) or a forwarding
    ticket (?ticket=, issued only to Qosha's dashboard; below): left to the engine's own checks."""
    from urllib.parse import parse_qs
    q = parse_qs(_query(scope), keep_blank_values=True)
    hdrs = {bytes(k).lower() for k, _v in (scope.get("headers") or [])}
    if "token" in q or b"x-hermes-session-token" in hdrs:
        return False
    return any(v and v[0] for v in (q.get("internal"), q.get("ticket")))


def _config_ok(body: bytes, query: str) -> bool:
    """PUT /api/config from a browser tab: allowed when every section it would change (compared after the engine's own
    deep merge over the current settings) is an ordinary one, and neither paid-AI switch changes. Anything that can't
    be compared this way (another profile, unreadable body or settings) is refused (verification pass NG-9, NG-11)."""
    try:
        data = json.loads(body.decode("utf-8"))
        incoming = data.get("config") if isinstance(data, dict) else None
        if not isinstance(incoming, dict) or not _default_profile(query, data.get("profile")):
            return False
        from hermes_cli.config import _deep_merge, load_config
        cur = load_config()
        new = _deep_merge(cur, incoming)
        dump = lambda v: json.dumps(v, sort_keys=True, default=str)

        def at(d, path):
            for k in path:
                d = d.get(k) if isinstance(d, dict) else None
            return d
        for k in set(cur) | set(new):
            if dump(cur.get(k)) == dump(new.get(k)) or k in _BROWSER_CONFIG:
                continue
            fields = _BROWSER_CONFIG_FIELDS.get(k)
            a, b = cur.get(k), new.get(k)
            if fields is None or not isinstance(a, dict) or not isinstance(b, dict):
                return False
            if any(dump(a.get(f)) != dump(b.get(f)) for f in set(a) | set(b) if f not in fields):
                return False
        return all(dump(at(cur, p)) == dump(at(new, p)) for p in _PAID_SWITCHES)
    except Exception:
        return False


def _env_ok(body: bytes, query: str) -> bool:
    """PUT /api/env from a browser tab: only saving an AI account's key (Settings > connect an AI)."""
    try:
        data = json.loads(body.decode("utf-8"))
        return (isinstance(data, dict) and set(data) <= _BROWSER_ENV_FIELDS
                and bool(_BROWSER_ENV_KEY.match(str(data.get("key") or "")))
                and _default_profile(query, data.get("profile")))
    except Exception:
        return False


def _browser_http_ok(path: str, method: str, query: str) -> bool:
    if any(method in ms and rx.match(path) for ms, rx in _BROWSER_HTTP):
        return True
    m = re.match(r"^/api/cron/jobs/([^/]+)/trigger/?$", path)     # run now: only a job that is not paused (a job
    #   paused between this check and the engine's own read is a known race, MEDIUM, round-2 NG2-6)
    return bool(m and method == "POST" and _default_profile(query) and not _paused_job(m.group(1)))


def _paused_job(job_id: str) -> bool:
    """Qosha pauses jobs that send outside it until the person turns them back on (review round 2, AG-21).
    Unknown job or unreadable store: treated as paused."""
    try:
        from cron.jobs import get_job
        job = get_job(job_id) or {}
        return job.get("enabled") is False or bool(job.get("paused_reason")) or not job
    except Exception:
        return True


def _inbox_settings_ok(body: bytes, query: str) -> bool:
    """The inbox watch's settings from a browser tab: turning it on resumes its job when that job is paused, and a
    paused job is turned back on only in the app window (round-2 NG2-7). Other settings pass."""
    try:
        data = json.loads(body.decode("utf-8") or "{}")
    except Exception:
        return False
    if not isinstance(data, dict) or data.get("enabled") is not True:
        return True
    try:
        from . import inbox_watch as iw
        j = iw._find_job(iw.load_state())
        return not (j and (j.get("enabled") is False or j.get("paused_reason")))
    except Exception:
        return False


def _browser_frame(frame, asked: dict):
    """(allowed, id) for one JSON-RPC frame a browser tab sends on the chat socket."""
    if not isinstance(frame, dict):
        return False, None
    fid = frame.get("id")
    if "method" not in frame:      # an answer to a question the engine asked this socket: only the kinds listed
        kind = asked.get(str(fid)) if fid is not None else None
        res = frame.get("result")
        ok = (kind in ("clarify", "approval-question") and isinstance(res, dict)) or \
             (kind == "approval" and _native() and isinstance(res, dict) and res.get("choice") == "deny"
              and set(res) <= {"choice", "reason"}) or \
             (kind in ("sudo", "secret") and (isinstance(res, dict) or isinstance(frame.get("error"), dict)))
        if ok:
            asked.pop(str(fid), None)      # a malformed answer leaves the question answerable (NG2-19)
            asked.pop("rid:" + str(asked.pop("pair:" + str(fid), "")), None)     # and its other form (TS-G-09)
        return ok, None
    method = str(frame.get("method") or "")
    params = frame.get("params") if isinstance(frame.get("params"), dict) else {}
    if method == "approval.respond" and _native() and str(params.get("choice") or "").strip().lower() == "deny" \
            and set(params) <= {"session_id", "choice", "request_id", "reason"}:
        return True, fid           # declining passes from anywhere (Stop must always work: TS-M-10)
    if method == "approval.respond" and _native() and asked.get("rid:" + str(params.get("request_id") or "")) == "q":
        rq = str(params.get("request_id") or "")
        asked.pop("rid:" + rq, None)                                       # answered once (TS-G-09)
        asked.pop(asked.pop("pair:rid:" + rq, ""), None)
        return True, fid           # a preference question the page answers itself (engine_cards.PAGE_QUESTIONS)
    if method not in _BROWSER_WS_METHODS:
        return False, fid
    if method == "session.create" and not set(params) <= _SESSION_CREATE_FIELDS:
        return False, fid
    if method == "config.set" and str(params.get("key") or "") not in _CONFIG_SET_KEYS:
        return False, fid
    if method == "prompt.submit" and not set(params) <= _PROMPT_FIELDS:   # no transcript rewind / consent fields
        return False, fid
    return True, fid


def _window_gate():
    """window_gate.py, the sibling module (loaded by path: this file is itself loaded by path)."""
    p = os.path.realpath(str(Path(__file__).resolve().parent / "window_gate.py"))
    for m in list(sys.modules.values()):           # the copy this process already has (TS-M2-03)
        try:
            if m is not None and os.path.realpath(getattr(m, "__file__", "") or "") == p:
                return m
        except Exception:
            continue
    if __package__:
        import importlib
        return importlib.import_module(__package__ + ".window_gate")
    m = sys.modules.get("qosha_window_gate")
    if m is None:
        import importlib.util as ilu
        spec = ilu.spec_from_file_location("qosha_window_gate", str(Path(__file__).resolve().parent / "window_gate.py"))
        m = ilu.module_from_spec(spec)
        spec.loader.exec_module(m)
        sys.modules["qosha_window_gate"] = m
    return m


def _native() -> bool:
    """The trusted approval surface is on: read from engine_cards.py's own text next to this file (one source for every
    component, no loader can make them disagree: TS-G-06). Unreadable = on (fail closed: no page may answer)."""
    try:
        with open(str(Path(__file__).resolve().parent / "engine_cards.py"), encoding="utf-8") as fh:
            if (re.search(r"(?m)^ON = True\b", fh.read()) or _floor_marker()):
                return True
    except Exception:
        return True
    try:                                   # tests turn it on in-process (it can only turn it on, never off)
        p = str(Path(__file__).resolve().parent / "engine_cards.py")
        return any(getattr(m, "ON", False) is True and os.path.realpath(getattr(m, "__file__", "") or "") == p
                   for m in list(sys.modules.values()) if m is not None)
    except Exception:
        return False


def _ready_state() -> dict:
    """One readiness per process (shared by every copy of this file: TS-M2-03)."""
    try:
        return _window_gate()._ST.ready
    except Exception:
        return {"ok": False}


class _Ready:
    def __getitem__(self, k):
        return _ready_state()[k]

    def __setitem__(self, k, v):
        _ready_state()[k] = v


_WINDOW_READY = _Ready()       # with the surface on: every hook that sends cards to the window is in place
NOT_READY = ("BLOCKED: Qosha's approval window could not be set up in this process, so nothing that needs the "
             "person's OK can run here. Restart Qosha; if it keeps happening, ask for help.")


def _page_question_rid(f) -> str:
    """The request id of an engine approval frame that is one of the page's own preference questions (the browser
    window's place: engine_cards.PAGE_QUESTIONS), from the server request "approval" or the approval.request event
    only, and only when EVERY key of the request is such a question (TS-G-09)."""
    try:
        qs = _window_gate()._guard("engine_cards").PAGE_QUESTIONS
        if not isinstance(f, dict):
            return ""
        p = f.get("params") if isinstance(f.get("params"), dict) else {}
        if f.get("method") == "approval":
            d = p
        elif str(p.get("type") or "") == "approval.request" and isinstance(p.get("payload"), dict):
            d = p["payload"]
        else:
            return ""
        keys = [str(k) for k in [d.get("pattern_key")] + list(d.get("pattern_keys") or []) if k]
        if keys and all(k in qs for k in keys) and d.get("request_id"):
            return str(d["request_id"])
    except Exception:
        pass
    return ""


class OwnerGate:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        kind = scope.get("type")
        path = scope.get("path") or ""
        native = _native()      # trusted surface on: the app window is treated like any other caller (H2)
        if kind == "websocket" and path.startswith("/api/") and not _ticketed_socket(scope) \
                and (native or not from_qosha_window(scope)):
            if path.rstrip("/") == "/api/ws":
                asked = {}
                return await self.app(scope, self._filtered(receive, send, asked), self._tracked(send, asked))
            if not _BROWSER_SOCKETS.match(path):    # terminals, consoles, display input: the app window only
                await send({"type": "websocket.close", "code": 4403, "reason": "Only the Qosha app window"})
                return
        elif kind == "http" and path.startswith("/api/") \
                and scope.get("method", "GET").upper() not in _READ_METHODS \
                and (native or not from_qosha_window(scope)):
            method, query = scope.get("method", "").upper(), _query(scope)
            if native and _window_gate().decline_passes(path, method):
                return await self.app(scope, receive, send)            # declining a decision: from anywhere
            check = {("PUT", "/api/config"): _config_ok, ("PUT", "/api/env"): _env_ok,
                     ("POST", "/api/plugins/qosha/inbox-watch/settings"): _inbox_settings_ok}.get((method, path.rstrip("/")))
            if check is None and _browser_http_ok(path, method, query):
                return await self.app(scope, receive, send)
            if check is None and not native:
                return await self._refuse(send, path)
            body, msgs = b"", []
            while True:
                msg = await receive()
                msgs.append(msg)
                if msg.get("type") != "http.request":
                    break
                body += msg.get("body", b"")
                if len(body) > _MAX_BODY or not msg.get("more_body", False):
                    break
            if len(body) > _MAX_BODY or msgs[-1].get("type") != "http.request":
                return await self._refuse(send, path)
            if check is not None and check(body, query):
                replay = list(msgs)

                async def again():
                    return replay.pop(0) if replay else await receive()
                return await self.app(scope, again, send)
            if not native:
                return await self._refuse(send, path)
            # a privileged write: shown in Qosha's approval window, passed on only after Allow this time (H2, H1)
            return await _window_gate().confirm(self.app, scope, body, receive, send, self._refuse)
        return await self.app(scope, receive, send)

    @staticmethod
    def _tracked(send, asked: dict):
        """Remembers which questions the engine asks this socket (id -> kind), so only clarify / sudo / secret
        answers pass from a browser tab, never an approval answer or a withdrawal of one (NG-2)."""
        async def tracked(msg):
            if msg.get("type") == "websocket.send" and msg.get("text"):
                try:
                    f = json.loads(msg["text"])
                    if isinstance(f, dict) and f.get("method") and f.get("id") is not None:
                        if len(asked) > 500:
                            asked.pop(next(iter(asked)))
                        asked[str(f["id"])] = str(f["method"]).split(".")[0]
                    q = _page_question_rid(f) if _native() else ""
                    if q:
                        asked["rid:" + q] = "q"
                        if isinstance(f, dict) and f.get("id") is not None and f.get("method") == "approval":
                            asked[str(f["id"])] = "approval-question"
                            asked["pair:" + str(f["id"])] = q          # one answer consumes both forms (TS-G-09)
                            asked["pair:rid:" + q] = str(f["id"])
                except Exception:
                    pass
            await send(msg)
        return tracked

    @staticmethod
    def _filtered(receive, send, asked: dict):
        async def filtered():
            while True:
                msg = await receive()
                if msg.get("type") == "websocket.receive":
                    text = msg.get("text")
                    if text is None and msg.get("bytes") is not None:
                        text = msg["bytes"].decode("utf-8", "replace")
                    try:
                        frame = json.loads(text or "")
                    except Exception:
                        frame = None
                    if isinstance(frame, dict) and frame.get("method") == "config.set" and \
                            isinstance(frame.get("params"), dict) and "confirm_expensive_model" in frame["params"]:
                        frame["params"].pop("confirm_expensive_model", None)   # a costly model is confirmed by the person
                        msg = dict(msg, text=json.dumps(frame))                 # (review FO2-13)
                        msg.pop("bytes", None)
                    ok, fid = _browser_frame(frame, asked)
                    if not ok:
                        log.warning("approval gate: a chat-socket frame was refused (not the app window)")
                        if fid is not None:
                            words = NATIVE_REFUSED if (_native() and isinstance(frame, dict) and str(
                                frame.get("method") or "").startswith("approval")) else REFUSED
                            await send({"type": "websocket.send", "text": json.dumps(
                                {"jsonrpc": "2.0", "id": fid, "error": {"code": -32001, "message": words}})})
                        continue
                return msg
        return filtered

    @staticmethod
    async def _refuse(send, path):
        log.warning("approval gate: %s refused (not the Qosha app window)", path)
        body = json.dumps({"detail": REFUSED, "error": "qosha_app_window_only"}).encode("utf-8")
        await send({"type": "http.response.start", "status": 403,
                    "headers": [(b"content-type", b"application/json"), (b"content-length", str(len(body)).encode())]})
        await send({"type": "http.response.body", "body": body})


def install(app) -> bool:
    """Put the gate in front of the dashboard app (before or after it started serving). Idempotent."""
    if getattr(app, "_qosha_owner_gate", False):
        return True
    stack = getattr(app, "middleware_stack", None)
    if stack is None:
        app.add_middleware(OwnerGate)
    else:
        app.middleware_stack = OwnerGate(stack)
    app._qosha_owner_gate = True
    return True


def mount(router=None) -> None:
    """Called from the dashboard plugin: record its port for the gateway it starts, then gate the engine's dashboard
    app (local installs only)."""
    try:
        port = int(os.environ.get("HERMES_DASHBOARD_PORT") or 0) or next(
            (int(a.split("=", 1)[1]) if a.startswith("--port=") else int(sys.argv[i + 1])
             for i, a in enumerate(sys.argv) if a == "--port" or a.startswith("--port=")), 9219)
        os.environ["QOSHA_DASHBOARD_PORT"] = str(port)    # inherited by the gateway this dashboard starts
    except Exception:
        pass
    if not _app_installed():
        return       # no Qosha app on this computer (a cloud or lab box: the window is elsewhere); unchanged there.
        #              Decided from the disk, never from the environment (.env is loaded into it at every start).
    if "dashboard" not in [str(a).lower() for a in sys.argv]:
        return       # only the dashboard serves the page key to anyone; the gateway's own listener is left as it is
        #              (the dashboard reaches it for its window's actions)
    ws = sys.modules.get("hermes_cli.web_server")
    app = getattr(ws, "app", None)
    if app is None:
        raise RuntimeError("dashboard app not found")
    install(app)
    if _native():
        try:
            _window_gate()._guard("engine_cards").mark_native()
        except Exception:
            log.warning("approval gate: the native-approval marker could not be written")
    if router is not None:
        from fastapi import Request

        def _window(request):
            """For the chat page: is this the Qosha app window (show Allow) or a browser tab (show "Open the app")."""
            if _native():       # pages show their ordinary buttons; every answer is settled in the approval window
                return {"window": True, "native": True}
            return {"window": from_qosha_window(request.scope), "native": False}
        _window.__annotations__ = {"request": Request}    # a real class (this module defers annotations)
        router.get("/approval-gate/window")(_window)

        def _show():
            """Pages' "Show the approval window": brings Qosha's open approval window to the front, nothing else."""
            try:
                return {"shown": bool(_window_gate()._guard("trusted_dialog").bring_forward())}
            except Exception:
                return {"shown": False}
        router.post("/approval-window/show")(_show)


# ---- the gateway's control socket ---------------------------------------------------------------------------------
# The two ticket kinds that can answer cards or change settings go only to a real dashboard (Qosha's own engine
# process serving the window, which forwards its window's actions to the gateway); a plain program (the assistant's
# terminal) gets none. Other ticket kinds and the socket's other requests are unchanged.
_REFUSED_TICKETS = {"interactive", "native-http"}
# the gateway answers requests on a worker thread, so the verdict travels with the request's own subject object (the
# string the gateway hands from the socket check to the ticket check), never by a lookup a caller could influence
_verdicts: dict = {}
_vlock = threading.Lock()


def _remember(subject, ok: bool) -> None:
    now = time.monotonic()
    with _vlock:
        for k in [k for k, (_s, _ok, t) in _verdicts.items() if now - t > 60]:
            _verdicts.pop(k, None)
        _verdicts[id(subject)] = (subject, ok, now)


def _verdict(subject) -> bool:
    with _vlock:
        entry = _verdicts.get(id(subject))
        return bool(entry and entry[0] is subject and entry[1])


def _peer_pid(sock):
    try:
        if hasattr(socket_mod(), "SO_PEERCRED"):
            import struct
            s = socket_mod()
            return struct.unpack("3i", sock.getsockopt(s.SOL_SOCKET, s.SO_PEERCRED, 12))[0]
        if sys.platform == "darwin":
            return int(sock.getsockopt(0, 0x002))          # SOL_LOCAL, LOCAL_PEERPID
    except (OSError, ValueError, TypeError):
        return None
    return None


def socket_mod():
    import socket
    return socket


def _dashboard_port() -> int:
    """The port Qosha's dashboard serves its window on: set by the dashboard in its own environment at start, which the
    gateway it starts inherits (nothing the assistant can write); 9219, Qosha's port, otherwise."""
    try:
        port = int(os.environ.get("QOSHA_DASHBOARD_PORT") or 9219)
        return port if 0 < port < 65536 else 9219
    except ValueError:
        return 9219


def _is_dashboard(pid) -> bool:
    """Qosha's dashboard: the process that holds Qosha's dashboard port open on this computer (a program the assistant
    starts cannot listen there while the dashboard runs; a word in a command line proves nothing)."""
    if not pid:
        return False
    try:
        import psutil
        port = _dashboard_port()
        return any(c.status == psutil.CONN_LISTEN and c.laddr and c.laddr.port == port and str(c.laddr.ip) == "127.0.0.1"
                   for c in psutil.Process(pid).net_connections(kind="tcp"))      # the dashboard binds exactly here
    except Exception:
        return False


def patch_gateway_tickets() -> bool:
    try:
        from gateway import control_socket as cs
    except Exception:
        return False
    cls = getattr(cs, "GatewayControlServer", None)
    orig = getattr(cls, "_session_ticket", None)
    opeer = getattr(cls, "_posix_peer_subject", None)
    if orig is None or opeer is None:
        return False
    if getattr(orig, "qosha_owner_gate", False):
        return True

    def _posix_peer_subject(self, writer, *a, **kw):
        subject = opeer(self, writer, *a, **kw)
        if subject:
            try:
                _remember(subject, _is_dashboard(_peer_pid(writer.get_extra_info("socket"))))
            except Exception:
                _remember(subject, False)
        return subject

    def _session_ticket(self, request, peer_subject, *a, **kw):
        params = request.get("params") if isinstance(request, dict) else None
        purpose = params.get("purpose", "interactive") if isinstance(params, dict) else None
        # Windows: the engine's own named-pipe server authenticates its client and this check has no peer process to
        # read, so the engine's behavior stays exactly as before there (review round 2, AG-19); POSIX: only the dashboard
        if os.name != "nt" and purpose in _REFUSED_TICKETS and not _verdict(peer_subject):
            raise PermissionError("on a Qosha install this ticket kind is issued only to Qosha's own dashboard")
        return orig(self, request, peer_subject, *a, **kw)

    _posix_peer_subject.__wrapped__ = opeer
    _session_ticket.qosha_owner_gate = True
    _session_ticket.__wrapped__ = orig
    cls._posix_peer_subject = _posix_peer_subject
    cls._session_ticket = _session_ticket
    return True


# ---- a self-edit card always reaches a person ---------------------------------------------------------------------
# The engine approves every card at once under yolo or approvals.mode off. Ren's rule for Qosha's approval code and
# settings is "asks every time", so for that one card kind those two shortcuts are ignored (review AG-10); with nobody
# to answer, the engine's plugin gate refuses (fail_closed_when_no_human).
_strict = contextvars.ContextVar("qosha_strict_self_edit", default=False)
SELF_EDIT_KEY = "plugin_rule:qosha:approval.self"
QOSHA_KEY = "plugin_rule:qosha:"


def patch_strict_self_edit() -> bool:
    try:
        from tools import approval as ap
        from tools import approval_context as ac
    except Exception:
        return False
    gate = getattr(ap, "_run_approval_gate", None)
    if gate is None or getattr(gate, "qosha_strict", False):
        return gate is not None
    oyolo, omode = ap._yolo_active, ac._get_approval_mode

    def _run_approval_gate(*a, **kw):
        if _native() and not _WINDOW_READY["ok"]:
            return {"approved": False, "message": NOT_READY, "description": str(kw.get("description") or "")}
        keys = [str(kw.get("pattern_key") or "")] + [str(k) for k in (kw.get("pattern_keys") or [])]
        # with the trusted surface on, every Qosha card is strict (H5): yolo and approvals.mode off never skip it;
        # only a recorded standing grant (Always allow given in the window, or Trust mode) does
        if not any(k.startswith(SELF_EDIT_KEY) or (k.startswith(QOSHA_KEY) and _native()) for k in keys):
            return gate(*a, **kw)
        tok = _strict.set(True)
        try:
            return gate(*a, **kw)
        finally:
            _strict.reset(tok)

    def _yolo_active(*a, **kw):
        return False if _strict.get() else oyolo(*a, **kw)

    def _get_approval_mode(*a, **kw):
        mode = omode(*a, **kw)
        return "manual" if _strict.get() and mode != "manual" else mode     # off, smart, any other (TS-R-F03)

    ounatt = getattr(ap, "_unattended_contexts", None)
    if ounatt is None and _native():
        return False                # no way to keep scheduled runs from approving a Qosha card: not ready (TS-R-12)

    class _Deny:
        """An unattended context (cron, a single query, an unattended platform) that never auto-approves a strict
        card: its own deny message, as with approvals.<ctx>_mode: deny (council RC3)."""
        def __init__(self, ctx):
            self._ctx = ctx

        def mode(self):
            return "deny"

        def __getattr__(self, name):
            return getattr(self._ctx, name)

    def _unattended_contexts(*a, **kw):
        out = ounatt(*a, **kw)
        return [_Deny(c) for c in out] if _strict.get() else out

    _run_approval_gate.qosha_strict = True
    _run_approval_gate.__wrapped__ = gate
    ap._run_approval_gate, ap._yolo_active, ac._get_approval_mode = _run_approval_gate, _yolo_active, _get_approval_mode
    if ounatt is not None:
        ap._unattended_contexts = _unattended_contexts
    return True


def patch_recorded_grants() -> bool:
    """With the trusted surface on, a saved "Always allow" for one of Qosha's rule keys counts only when the person
    gave it in the approval window (grants.py's record, H5). An entry added to the engine's list any other way (an
    edited settings file, an old page's answer) asks again. Other keys: the engine's own rule."""
    try:
        from tools import approval as ap
    except Exception:
        return False
    oia = getattr(ap, "is_approved", None)
    if oia is None:
        return False
    if getattr(oia, "qosha_recorded", False):
        orig = getattr(oia, "__wrapped__", None)
        for m in list(sys.modules.values()):        # late importers of the original, on every call (TS-M-07)
            try:
                if m is not None and orig is not None and getattr(m, "is_approved", None) is orig:
                    m.is_approved = oia
            except Exception:
                continue
        return True

    def is_approved(session_key, pattern_key, *a, **kw):
        ok = oia(session_key, pattern_key, *a, **kw)
        if ok and _native() and any(x in str(pattern_key or "") for x in ("desktop.automation", "approval.self")):
            return False                         # never by a saved grant: a fresh click every time (council RC3)
        if ok and _native() and str(pattern_key or "").startswith(QOSHA_KEY) \
                and str(pattern_key) not in _window_gate()._guard("engine_cards").PAGE_QUESTIONS:
            try:
                return bool(_window_gate()._guard("grants").has(pattern_key))
            except Exception:
                return False
        return ok

    is_approved.qosha_recorded = True
    is_approved.__wrapped__ = oia
    ap.is_approved = is_approved
    for m in list(sys.modules.values()):            # modules that imported it before this patch (TS-M-07)
        try:
            if m is not None and getattr(m, "is_approved", None) is oia:
                m.is_approved = is_approved
        except Exception:
            continue
    return True


def register(ctx=None) -> None:
    """Plugin hook (every engine process that loads Qosha): the gateway's tickets; self-edit cards always ask."""
    if not patch_gateway_tickets():
        log.warning("approval gate: the gateway's ticket check is not set up")
    strict = patch_strict_self_edit()
    if not strict:
        log.warning("approval gate: the self-edit card's always-ask rule is not set up")
    if not patch_recorded_grants():
        log.warning("approval gate: the recorded-grant rule is not set up")
    ok = False
    try:
        cards = bool(_window_gate()._guard("engine_cards").patch())        # always attempted (TS-G-06/G2-05)
        grants_ok = patch_recorded_grants()
        ok = bool(strict and cards and grants_ok)
    except Exception as e:
        log.warning("approval gate: the approval window is not set up for engine cards (%s)", e.__class__.__name__)
    _WINDOW_READY["ok"] = ok
    try:
        _window_gate()._guard("engine_cards").READY["ok"] = ok
    except Exception:
        pass
    if ok and _native():
        try:
            _window_gate()._guard("engine_cards").mark_native()
        except Exception:
            pass
    if not ok:
        log.warning("approval gate: the approval window is not set up for engine cards; with it on, cards are refused")
