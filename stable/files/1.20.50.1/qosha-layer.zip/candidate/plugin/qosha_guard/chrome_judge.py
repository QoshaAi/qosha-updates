"""What Qosha may do in the person's own Chrome (mc21): every command the engine's browser tool sends to one of
Qosha's tabs is judged here before the extension passes it on (council decision 22 Nov 2026, COUNCIL-DECISION.md).

* run: reading through fixed reader scripts, the accessibility tree and screenshots; scrolling; following a page's
  own links on a site the person allowed; typing into ordinary text fields on such a site;
* hold (the person's Allow in the Qosha app, tool qosha_browser_confirm): the first visit to or action on a site in an
  answer; a final step (send, pay, delete, share, submit a form, Enter that sends, OK on a page's own question). After
  Allow exactly that step is done once, only if the page and the element are still the same;
* refuse: everything else (arbitrary page scripts, cookies, storage, network details, uploads, password/card/code
  fields, letter shortcuts outside a field, right clicks, drags, unnamed buttons, embedded frames...).
The word lists are the computer-use guard's (desktop_use: 7 languages, exact negations, two effects = refused).
"""
from __future__ import annotations

import asyncio
import hashlib
import ipaddress
import json
import os
import re
import secrets
import socket
import sys
import threading
import time
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlsplit


def _sib(name: str):
    """A sibling module of Qosha's guard, the same one whether this file was imported as part of the plugin or loaded by
    file path from the dashboard (all state lives in one place per process: sys._qosha_chrome_shared)."""
    import importlib
    import importlib.util
    import os as _os
    import sys as _sys
    pkg = __name__.rpartition(".")[0]
    if pkg:
        try:
            return importlib.import_module(pkg + "." + name)
        except ImportError:
            pass
    for n, m in list(_sys.modules.items()):
        if n.endswith("qosha_guard." + name) or n == "qosha_chrome_" + name:
            return m
    spec = importlib.util.spec_from_file_location("qosha_chrome_" + name, _os.path.join(_os.path.dirname(__file__), name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    _sys.modules["qosha_chrome_" + name] = mod
    spec.loader.exec_module(mod)
    return mod


du = _sib("desktop_use")
_SHARED = sys.__dict__.setdefault("_qosha_chrome_shared", {})

HOLD_TTL = 60.0

KIND_TEXT = {
    "chrome.send": "send something from your Chrome",
    "chrome.pay": "pay or buy something in your Chrome",
    "chrome.delete": "delete something in your Chrome",
    "chrome.share": "share or publish something from your Chrome",
    "chrome.submit": "submit a form in your Chrome",
    "chrome.confirm": "answer yes to a page's question in your Chrome",
    "chrome.site": "open an address on another website in your Chrome, signed in as you",
    "chrome.type": "type into a field on a website in your Chrome, signed in as you (the website can see the text as it is typed)",
    "chrome.link": "open an address on a new website that may carry what it read in your Chrome",
    "chrome.click": "click ordinary buttons on a website in your Chrome, signed in as you (never Send, Pay, Delete, Share "
                    "or Submit; a web page can change what a button does at the moment it's clicked)",
}
# Ren, 22 Nov ~22:45 MST (overriding the council's first-site card): "I rather never ask, unless for send, pay, or submit
# (always allow should be an option there too)". Delete and share keep their cards too (product non-negotiable 1). Every
# final-step card offers "Always allow on <exact host>", per kind; the person takes it back in Settings > Browser.
SITE_ASK = False
# mc21 shrink (23 Nov 2026, orchestrator; capability change pending Ren's OK): in the person's own Chrome Qosha does not
# do final steps (send, pay, delete, share, submit, yes to a page's question): it refuses them with a plain message and
# the person presses the button. The only card left is the leak-shaped link (Ren, 22 Nov). The Allow-then-press path is
# gone (verification pass 2: 5 of 8 HIGH lived there).
HOLDABLE = {"chrome.link", "chrome.site", "chrome.type", "chrome.click"}
FINAL_TEXT = ("Qosha leaves Send, Pay, Delete, Share and Submit to you in your own Chrome: this step would %s, so Qosha "
              "did not do it. Tell the person it is ready and ask them to press it themselves, then take a new look.")
# Ren, 26 Nov 2026: a final button Qosha leaves to the person is scrolled into view and named. Payments and purchases
# wait for the person's own click on every website. (Per-website "Allow all" is not in this build: Ren's card, 26 Nov
# ~14:15 MST, "Ship now, Allow all later".)
PAY_TEXT = " Buttons that say they pay or show a price always wait for the person's own click, on every website."
UNREAD_TEXT = ("Qosha couldn't read what that button's form does (the page names a field like one of the form's own "
               "settings, or the read failed), so it did not click it. Ask the person to click it themselves.")
WA_HOSTS = ("whatsapp.com", "whatsapp.net", "wa.me")
WA_TEXT = ("Qosha doesn't open or read WhatsApp in your own Chrome. Qosha uses WhatsApp only through its own WhatsApp "
           "connection, where the person approves each read on Qosha's WhatsApp card (whatsapp_chats, whatsapp_read). "
           "Nothing was opened or read.")
ALWAYS_OK = {"chrome.send", "chrome.pay", "chrome.delete", "chrome.share", "chrome.submit", "chrome.confirm", "chrome.link",
             "chrome.site", "chrome.type", "chrome.click"}
# Ren, 22 Nov 23:1x MST ("Ask only for leak-shaped links (Recommended)"): an address on a host Qosha hasn't been on in
# this chat asks first when it looks like it carries data: query + fragment over LEAK_QUERY characters, a path segment
# over LEAK_SEGMENT characters, or LEAK_RUN characters of text Qosha read in this answer.
LEAK_QUERY, LEAK_SEGMENT, LEAK_RUN, LEAK_PATH = 100, 64, 24, 300
CARD_TYPE = 1000                                  # the typing card shows this much text, all of what Allow types
CARD_URL = 400                                    # the card shows this much of an address; longer ones are not opened

NEVER_HOSTS = ("accounts.google.com", "myaccount.google.com", "pay.google.com", "payments.google.com",
               "login.microsoftonline.com", "login.live.com", "account.microsoft.com", "appleid.apple.com",
               "idmsa.apple.com", "secure.login.gov", "chromewebstore.google.com", "chrome.google.com")
# A price: a currency sign or code next to a digit. The same pattern runs in Qosha's reader inside the page (on all of the
# text, however long) and here (on names and questions).
_CUR = "$\u20ac\u00a3\u00a5\u20b9\u20a9\u20bd\u20ba\u20ab\u20aa\u0e3f"
_CODES = "usd|eur|gbp|brl|cad|aud|chf|mxn|jpy|inr|cny"
_MONEY_SRC = r"(?:[%s]|\b(?:%s)\b)\s?\d|\d\s?(?:[%s]|(?:%s|reais|dollars?|euros?)\b)" % (_CUR, _CODES, _CUR, _CODES)
_MONEY = re.compile(_MONEY_SRC, re.I)
_LOCAL_NAME = re.compile(r"^(localhost|.*\.(local|localhost|internal|lan|home\.arpa|localdomain|intranet|corp|home))$", re.I)

# ---- commands ------------------------------------------------------------------------------------------------------
RUN = {
    "Page.enable", "Page.stopLoading", "Page.captureScreenshot", "Page.getFrameTree",
    "Page.getLayoutMetrics", "Page.setLifecycleEventsEnabled",
    "DOM.enable", "DOM.getDocument", "DOM.querySelector", "DOM.querySelectorAll", "DOM.describeNode",
    "DOM.getBoxModel", "DOM.getContentQuads", "DOM.getNodeForLocation", "DOM.requestChildNodes",
    "DOM.scrollIntoViewIfNeeded", "DOM.pushNodesByBackendIdsToFrontend", "DOM.getAttributes",
    "Accessibility.enable", "Accessibility.getFullAXTree", "Accessibility.getPartialAXTree",
    "Accessibility.queryAXTree", "Accessibility.getRootAXNode", "Accessibility.getChildAXNodes",
    "Emulation.setEmulatedMedia", "Emulation.setDeviceMetricsOverride", "Emulation.clearDeviceMetricsOverride",
    "Runtime.enable", "Runtime.releaseObject", "Runtime.releaseObjectGroup",
}
# Page/DOM events are what Qosha knows the page by (its address, its dialogs): they are never switched off (r1 Gemini F4)
NOOP = {"Network.enable", "Network.disable", "Network.setCacheDisabled", "Log.enable", "Log.disable", "Page.disable",
        "DOM.disable", "Runtime.disable", "Accessibility.disable"}
GATED = {"Page.captureScreenshot", "Page.getFrameTree", "DOM.getDocument", "DOM.querySelector", "DOM.querySelectorAll", "DOM.describeNode",
         "DOM.getBoxModel", "DOM.getContentQuads", "DOM.getNodeForLocation", "DOM.requestChildNodes", "DOM.getAttributes",
         "DOM.pushNodesByBackendIdsToFrontend", "DOM.scrollIntoViewIfNeeded", "Accessibility.getFullAXTree",
         "Accessibility.getPartialAXTree", "Accessibility.queryAXTree", "Accessibility.getRootAXNode",
         "Accessibility.getChildAXNodes", "Runtime.evaluate", "Input.dispatchMouseEvent", "Input.dispatchKeyEvent",
         "Input.insertText", "Page.handleJavaScriptDialog"}
JUDGED = {"Runtime.evaluate", "Page.navigate", "Page.navigateToHistoryEntry", "Page.bringToFront",
          "Page.handleJavaScriptDialog", "Input.dispatchMouseEvent", "Input.dispatchKeyEvent", "Input.insertText"}

READERS_HELP = ("In your own Chrome Qosha reads pages only with fixed readers: js(\"document.body.innerText\"), "
                "js(\"document.querySelector(<css>).innerText\"), js(\"[...document.querySelectorAll(<css>)].map(e=>e.innerText)\"), "
                "js(\"[...document.querySelectorAll('a')].map(a=>[a.innerText,a.href])\"), js(\"document.title\"), "
                "js(\"location.href\"), js(\"JSON.stringify(document.querySelector(<css>).getBoundingClientRect())\") for where an element is, page_info(), screenshots, or cdp('Accessibility.getFullAXTree'). Open "
                "addresses and links with goto_url(url). To type, click_at_xy on a text field (Qosha only puts the cursor "
                "there) and then type_text(\"...\"). On websites the person allowed Qosha clicks ordinary buttons: "
                "click_at_xy on a named button clicks it once (it asks them unless they always allow clicks there); Send, Pay, "
                "Delete, Share, Submit and OK stay the person's. No key presses, double or right clicks in the person's Chrome.")

_JSON_STR = r'"(?:[^"\\\x00-\x1f]|\\.)*"'
_SEL = r"""(?:%s|'[^'\\\x00-\x1f]*')""" % _JSON_STR
_TEMPLATES = [re.compile("^" + t + "$") for t in (
    # fixed readers (no input values, no cookies or storage)
    re.escape("document.body.innerText"), re.escape("document.title"), re.escape("location.href"),
    re.escape("document.querySelector(") + _SEL + re.escape(").innerText"),
    re.escape("[...document.querySelectorAll(") + _SEL + re.escape(")].map(e=>e.innerText)"),
    re.escape("[...document.querySelectorAll('a')].map(a=>[a.innerText,a.href])"),
    re.escape("JSON.stringify(document.querySelector(") + _SEL + re.escape(").getBoundingClientRect())"),
    # the browser tool's own helper scripts (browser-harness 0.1.13 helpers.py)
    re.escape("JSON.stringify({url:location.href,title:document.title,w:innerWidth,h:innerHeight,sx:scrollX,sy:scrollY,"
              "pw:document.documentElement.scrollWidth,ph:document.documentElement.scrollHeight})"),
    re.escape("document.readyState"), re.escape("window.devicePixelRatio"),
    re.escape("!!document.querySelector(") + _SEL + re.escape(")"),
    re.escape("(()=>{const e=document.querySelector(") + _JSON_STR + re.escape(");if(!e)return false;"
              "if(typeof e.checkVisibility==='function')return e.checkVisibility({checkOpacity:true,checkVisibilityCSS:true});"
              "const s=getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0'})()"),
)]
# fill_input's focus and its synthetic input/change events are not readers: they can make a page act (review r1 GPT 04)
# the same, wrapped by the harness's js() when a statement needs a function body: (function(){<expr>})()
_WRAP = re.compile(r"^\(function\(\)\{return (.*)\}\)\(\)$", re.S)


def template(expr: str) -> bool:
    e = (expr or "").strip()
    m = _WRAP.match(e)
    return any(t.match(e) or (m and t.match(m.group(1).rstrip(";"))) for t in _TEMPLATES)


# ---- state ---------------------------------------------------------------------------------------------------------
_lock = _SHARED.setdefault("lock", threading.RLock())
HELD: Dict[str, Dict[str, Any]] = _SHARED.setdefault("held", {})           # id -> held step
_TAB: Dict[str, Dict[str, Any]] = _SHARED.setdefault("tabs", {})          # tab -> {"dialog", "url", "main", "world", ...}
_FRONT = _SHARED.setdefault("front", [True])
LAST_ACTIVITY: Dict[str, Any] = _SHARED.setdefault("activity", {})       # for the app's bar: when and where Qosha worked
VISITED: Dict[str, set] = _SHARED.setdefault("visited", {})              # chat -> hosts Qosha has been on in it
READ: Dict[str, str] = _SHARED.setdefault("read", {})                    # chat -> text Qosha read in this answer (lowercase)


def front_mode() -> bool:
    return _FRONT[0]


def set_front(v: bool) -> None:
    _FRONT[0] = bool(v)


def _t(tab: str) -> Dict[str, Any]:
    return _TAB.setdefault(str(tab), {})


def site_of(url: str) -> str:
    """The exact host (council: exact origin host, no www folding, no parent domains)."""
    try:
        return (urlsplit(str(url or "")).hostname or "").lower().rstrip(".")
    except ValueError:
        return ""


def _always(rule: str) -> bool:
    """Is a rule on the person's Always-allow list (the engine's own list, written only by an answered card)?"""
    try:
        from hermes_cli.config import load_config
        return ("plugin_rule:" + rule) in set(str(x) for x in ((load_config() or {}).get("command_allowlist") or []))
    except Exception:
        return False


def rule_for(kind: str, site: str) -> str:
    """The name of the person's "Always allow" for this kind of step on this exact host. "Take back" raises the
    permission's generation in Qosha's own record, and the name carries it: every copy of the old permission, whoever
    saves it again later, then matches nothing (TAKEBACK-RESTORED)."""
    if not (site and re.fullmatch(r"[a-z0-9.-]{1,253}", site)):
        return ""
    base = "qosha:%s:%s" % (kind, site)
    g = state().get("gens")
    try:
        n = int(g.get(base) or 0) if isinstance(g, dict) else 0
    except (TypeError, ValueError):
        n = 0
    return base + (":%d" % n if n > 0 else "")


def _state_path() -> str:
    try:
        home = str(_sib("store").engine_home())
    except Exception:
        home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    return os.path.join(home, "qosha", "chrome-state.json")


def state() -> Dict[str, Any]:
    """Qosha's own record for the person's Chrome (the switch, the taken-back permissions). Only the Qosha app window
    writes it (chrome_api, one writer at a time across processes). Unreadable counts as empty: nothing is allowed."""
    try:
        with open(_state_path(), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _wa(host: str) -> bool:
    """WhatsApp's own websites: never opened or read in the person's Chrome (Qosha's WhatsApp card is the only way)."""
    h = str(host or "").lower().rstrip(".")
    return any(h == d or h.endswith("." + d) for d in WA_HOSTS)


def _here(st: Dict[str, Any]) -> str:
    """The tab's website, if Qosha opened it there with the person's say or they always allow it; "" after a redirect."""
    h = site_of(st.get("url") or "")
    return h if h and (h in st.get("ok", set()) or _site_ok(h)) else ""


def _carried(url: str) -> List[str]:
    """Websites of web addresses carried inside this one (a redirector's ?url=https://...), decoded up to twice."""
    from urllib.parse import unquote
    t, out = str(url or ""), []
    for _ in range(3):
        for m in re.finditer(r"https?:(?:/|%2f|\\\\){2}([a-z0-9.-]+)", t, re.I):
            h = m.group(1).lower().rstrip(".")
            if h and h not in out:
                out.append(h)
        t = unquote(t)
    return out[1:] if out and out[0] == site_of(url) else out


def _site_ok(site: str) -> bool:
    """ "Always allow" on this exact host. ("Allow this time" does only the held step, once: nothing is remembered.)"""
    if not site:
        return False
    r = rule_for("chrome.site", site)
    return bool(r) and _always(r)


def _type_ok(site: str) -> bool:
    if not site:
        return False
    r = rule_for("chrome.type", site)
    return bool(r) and _always(r)


def site_allowed(site: str) -> bool:
    if not SITE_ASK:
        return True                          # Ren's override: browsing, reading and ordinary clicks never ask
    return _site_ok(site)


DRIVER_IDLE = 900.0                               # a chat that drove nothing for 15 min (a cancelled answer) no longer counts
BUSY_TEXT = ("Chrome is busy with %s. Qosha works in your Chrome for one chat at a time: it can work here once that "
             "chat's answer has ended, or after 15 minutes without a step there.")


def _chat_name(sid: str) -> str:
    """The other chat's title for the "busy" message; "another chat" when it has none."""
    t = ""
    try:
        from hermes_state import SessionDB
        db = SessionDB()
        try:
            t = db.get_session_title(str(sid)) or ""
        finally:
            try:
                db.close()
            except Exception:
                pass
    except Exception:
        t = ""
    t = du.clean(t, 60).replace('"', "'").strip()
    return '"%s"' % t if t else "another chat"


def _forget_chat(keep: str) -> None:
    """Another chat drove Chrome last: what it was allowed in its tabs and its unanswered steps don't pass on
    (CROSS-CHAT-TAB-OK). A tab the person handed over that no chat has driven yet keeps their OK. Call under _lock."""
    for st in _TAB.values():
        if st.get("sid") not in (None, "", keep):
            st.pop("ok", None)
            st.pop("sid", None)
    for k in [k for k, h in HELD.items() if h.get("session", "") != keep]:
        HELD.pop(k, None)


def set_session(session_id: str) -> Optional[str]:
    """The chat whose browser step runs now. Ren, 23 Nov (card "One more round"): the person's Chrome serves ONE chat at a
    time, so what Qosha read, visited or was allowed in one chat can't serve another (CROSS-CHAT-*). Returns the refusal
    when another chat drove it within DRIVER_IDLE and its answer hasn't ended; nothing changes then."""
    sid = str(session_id or "")
    if not sid:
        return "Qosha can't tell which chat this step belongs to, so it doesn't work in your Chrome for it."
    with _lock:
        d = _SHARED.setdefault("drivers", {})
        if not isinstance(d, dict):
            d = _SHARED["drivers"] = {}
        now = time.time()
        for k in [k for k, t in d.items() if now - t > DRIVER_IDLE]:
            d.pop(k, None)
        other = next((k for k in d if k != sid), None)
        if other is None:
            if _SHARED.get("session") not in (None, "", sid):
                _forget_chat(sid)                # a takeover (the other chat ended or went idle): nothing of its stays
            d[sid] = now
            _SHARED["session"] = sid
    if other is not None:
        return BUSY_TEXT % _chat_name(other)
    return None


def last_driver_ends(session_id: str) -> bool:
    """This chat's answer ended: True when no other chat drove Chrome lately since Qosha's tabs last ended (verify F8)."""
    with _lock:
        d = _SHARED.setdefault("drivers", {})
        if not isinstance(d, dict):
            d = _SHARED["drivers"] = {}
        d.pop(str(session_id or ""), None)
        now = time.time()
        for k in [k for k, t in d.items() if now - t > DRIVER_IDLE]:
            d.pop(k, None)
        return not d


def end_answer(session_id: str = "") -> None:
    """An answer ended: its own unanswered held steps end with it (other chats' are left alone)."""
    sid = str(session_id or "")
    with _lock:
        for st in _TAB.values():                 # openings allowed "this time" end with the answer (CROSS-CHAT-TAB-OK)
            if not sid or st.get("sid") == sid:  # this chat's own tabs only: another chat's answer ending (a job, a
                st.pop("ok", None)               # second chat that never used Chrome) changes nothing for the chat
                st.pop("sid", None)              # that drives Chrome (CROSS-CHAT-END-ANSWER-LEAK)
        for k in [k for k, h in HELD.items() if h.get("session", "") in ("", sid)]:
            HELD.pop(k, None)
        for k in [k for k in READ if k == sid]:   # only this chat's read text (a blank end keeps others' leak memory)
            READ.pop(k, None)


def void_held(relay, why: str) -> None:
    with _lock:
        HELD.clear()
        _TAB.clear()


def _pending_in(tab: str) -> bool:
    now = time.time()
    with _lock:
        return any(h["tab"] == tab and now - h["at"] <= HOLD_TTL for h in HELD.values())


def _driven_now(st: Dict[str, Any]) -> bool:
    """Is this tab one the chat that drives Chrome right now has sent a step to? (A tab left open by an earlier chat, or
    one the person browses in, never adds to another chat's visited websites.)"""
    sid = _sid()
    with _lock:
        d = _SHARED.get("drivers")
        return bool(sid) and isinstance(d, dict) and sid in d and st.get("sid") == sid


def _visit_if_driven(st: Dict[str, Any], url: str) -> None:
    """Record the visit for the chat that drives this tab, in one step with the check that it does (a takeover in
    between can't hand chat A's visit to chat B: CROSS-CHAT-LEAK-RACE)."""
    h = site_of(url)
    with _lock:
        sid = str(_SHARED.get("session", "") or "")
        d = _SHARED.get("drivers")
        if h and sid and isinstance(d, dict) and sid in d and st.get("sid") == sid:
            VISITED.setdefault(sid, set()).add(h)


def on_ext_event(relay, ev: str, msg: Dict[str, Any]) -> None:
    if ev == "cdp":
        m = str(msg.get("method") or "")
        tab = str(msg.get("tab") or "")
        p = msg.get("params") or {}
        if m == "Page.javascriptDialogOpening":
            st = _t(tab)
            st["dseq"] = int(st.get("dseq") or 0) + 1
            st["dialog"] = {"type": str(p.get("type") or ""), "message": du.clean(p.get("message"), 300),
                            "url": str(p.get("url") or ""), "seq": st["dseq"]}
        elif m == "Page.javascriptDialogClosed":
            _t(tab).pop("dialog", None)
        elif m == "Page.frameNavigated" and not (p.get("frame") or {}).get("parentId"):
            st = _t(tab)
            u = str((p.get("frame") or {}).get("url") or "")
            if site_of(u) in st.get("ok", set()) or _site_ok(site_of(u)):   # a redirect elsewhere isn't a visit
                _visit_if_driven(st, u)
            st["url"] = str((p.get("frame") or {}).get("url") or "")
            st["main"] = str((p.get("frame") or {}).get("id") or "")
            st.pop("world", None)
    elif ev == "tab_updated":
        st = _t(str(msg.get("tab") or ""))
        u = str(msg.get("url") or "")
        if u and u != st.get("url"):
            if site_of(u) in st.get("ok", set()) or _site_ok(site_of(u)):
                _visit_if_driven(st, u)
            st["url"] = u                     # Chrome's own view of the tab's address (r1 Gemini F4)
            st.pop("world", None)
            st.pop("dialog", None)
    elif ev in ("tab_gone",):
        _TAB.pop(str(msg.get("tab") or ""), None)


# ---- addresses -----------------------------------------------------------------------------------------------------
def _private(host: str) -> bool:
    h = host.strip("[]")
    try:
        ip = ipaddress.ip_address(h)
        return not ip.is_global
    except ValueError:
        pass
    if _LOCAL_NAME.match(h):
        return True
    try:
        for fam, _, _, _, sa in socket.getaddrinfo(h, None)[:8]:
            if not ipaddress.ip_address(sa[0].split("%")[0]).is_global:
                return True
    except (OSError, ValueError, UnicodeError):
        return False                         # not found: Chrome will say so
    return False


def navigation(relay, tab: Optional[str], url: str, created: bool = False) -> Optional[str]:
    """A refusal for an address Qosha never opens, or None."""
    u = str(url or "").strip()
    if created and u in ("", "about:blank"):
        return None
    try:
        sp = urlsplit(u)
    except ValueError:
        return "Qosha could not read that address."
    if sp.scheme not in ("http", "https"):
        return "Qosha only opens web addresses (http or https) in your Chrome."
    if "%" in sp.netloc or not re.fullmatch(r"[A-Za-z0-9.:\[\]-]*", sp.netloc.split("@")[-1]):
        return "Qosha opens only plain web addresses (no encoded or non-Latin host names); ask the person to open it."
    if "\\" in u or "@" in sp.netloc:              # Chrome reads "\\" as "/": the real host would differ (G-BACKSLASH)
        return "Qosha doesn't open addresses with a backslash or a user name in them; ask the person to open it."
    h = (sp.hostname or "").lower().rstrip(".")      # "accounts.google.com." is the same host (r1 Gemini F9)
    if _wa(h) or any(_wa(x) for x in _carried(u)):   # also an address that carries a WhatsApp one (a redirector)
        return WA_TEXT
    if not h or _private(h):
        return "Qosha does not open pages on this computer or its local network in your Chrome."
    if any(h == d or h.endswith("." + d) for d in NEVER_HOSTS):
        return ("Qosha does not open %s: the person signs in, pays or changes account settings there themselves. Ask "
                "them to do that step." % h)
    return None


# ---- what is on the page (Qosha's own reads, in its own isolated world: the page cannot change them) ---------------
async def _cdp(relay, tab: str, method: str, params: Optional[dict] = None):
    return await relay.ext("cdp", tab=tab, method=method, params=params or {})


async def _world(relay, tab: str) -> int:
    st = _t(tab)
    if st.get("world"):
        return st["world"]
    if not st.get("main") or not st.get("url"):
        ft = await _cdp(relay, tab, "Page.getFrameTree")
        fr = ((ft or {}).get("frameTree") or {}).get("frame") or {}
        st["main"], st["url"] = str(fr.get("id") or ""), str(fr.get("url") or st.get("url") or "")
        st.pop("world", None)
    w = await _cdp(relay, tab, "Page.createIsolatedWorld", {"frameId": st["main"], "worldName": "qosha-read",
                                                            "grantUniveralAccess": False})
    st["world"] = int((w or {}).get("executionContextId") or 0)
    return st["world"]


_READ_FN = ("(function(){var e=this;var o={};try{var SEC=function(y){var t=String(y.type||'').toLowerCase();"
            "return t==='password'||t==='file'||/(^|\\s)(cc-[a-z-]+|one-time-code|current-password|new-password)(\\s|$)/i.test(String(y.autocomplete||''))};var rn=e.getRootNode&&e.getRootNode();o.qosha=!!(rn&&rn.host&&rn.host.tagName==='QOSHA-BANNER');"
            "var act=e.closest&&(e.closest('button,input,select,textarea,a[href]')||e.closest('[role=button],[role=link]'));"
            "if(act&&act!==e){o.act={tag:act.tagName.toLowerCase(),attrs:[].concat.apply([],[].map.call(act.attributes,function(x){return [x.name,x.value]}))};e=act}"
            "var a=e.closest&&e.closest('a[href]');o.href=a?a.href:'';var f=e.form||(e.closest&&e.closest('form'));"
            # The names of a form's submit buttons are part of what is judged, and they are page text. None of it is taken
            # from inside an editable area or a role=textbox (a draft), shadow trees included: when the form, one of its
            # submit buttons or an element such a button is labelled by sits in one, the form is unread (refused) and
            # nothing of it goes back (EXTERNAL-FORM-UNREAD).
            "var BAD=false,ED=function(q){for(;q;q=q.parentElement||(q.getRootNode&&q.getRootNode().host)||null){"
            "if(q.isContentEditable||(q.getAttribute&&q.getAttribute('role')==='textbox')||q.tagName==='TEXTAREA')return true}return false};"
            "if(f&&ED(f))return {unread:true};"
            # a field named like one of the form's own properties ("action", "method", "elements", "getAttribute"...) takes
            # that property's place on the form object: Qosha then can't read what the form does, and says so (RELEASE-ACTION)
            "if(f){var D=function(k){var q=Object.getPrototypeOf(f);while(q){var d=Object.getOwnPropertyDescriptor(q,k);if(d)return d;"
            "q=Object.getPrototypeOf(q)}return null};"
            "if(['action','method','elements','id','length'].some(function(k){var d=D(k);return !d||!d.get||f[k]!==d.get.call(f)})||"
            "['getAttribute','hasAttribute','querySelector','querySelectorAll'].some(function(k){var d=D(k);return !d||f[k]!==d.value}))"
            "return {unread:true}}"
            "if(f){var fa=(e.hasAttribute&&e.hasAttribute('formaction'))?e.formAction:f.action;var fm=(e.hasAttribute&&e.hasAttribute('formmethod'))?"
            "e.getAttribute('formmethod'):(f.getAttribute('method')||'get');o.form={method:String(fm).toLowerCase(),action:fa||'',"
            "fields:[]};"
            # what kind of fields the form has, never what is in them: no field value leaves the page (FORM-VALUES-LEAVE-CHROME)
            "for(var j=0;j<f.elements.length&&j<400;j++){var y=f.elements[j];var ya=String(y.autocomplete||''),"
            "yn=[y.name||'',y.id||'',y.getAttribute('placeholder')||'',y.getAttribute('aria-label')||''].join(' ');"
            "if(/(^|\\s)cc-/i.test(ya)||/card.?num|cardnumber|cc.?num|cvv|cvc|iban|routing|card.?holder|expir/i.test(yn))o.form.card=true;"
            "if(/amount|valor|quantia|monto|montant|betrag|importo|price|pre.o|total/i.test(yn))o.form.amount=true}"
            "if(f.elements.length>400)o.form.card=true;"
            "var nm=function(z){var t=[],l=z.getAttribute('aria-labelledby');if(l){l.split(/\\s+/).forEach(function(i){var n=document.getElementById(i);"
            "if(n){if(ED(n))BAD=true;t.push(n.innerText||n.textContent||'')}})}t.push(z.getAttribute('aria-label')||'',z.getAttribute('alt')||'',z.innerText||'');"
            "[].forEach.call(z.querySelectorAll?z.querySelectorAll('img[alt],[aria-label]'):[],function(c){t.push(c.getAttribute('alt')||c.getAttribute('aria-label')||'')});"
            "t.push(z.tagName==='INPUT'?String(z.value||''):'',z.getAttribute('title')||'');var s=t.join(' ').replace(/\\s+/g,' ').trim();"
            "return s.length>300?'':s};"                # a name too long to judge whole counts as no name (the person's)
            "var cand=[].slice.call(f.elements).concat([].slice.call(f.querySelectorAll('input[type=image]')));"
            "if(f.id)cand=cand.concat([].slice.call(document.querySelectorAll('input[type=image][form=\"'+CSS.escape(f.id)+'\"]')));"
            "cand=cand.filter(function(z,i){return cand.indexOf(z)===i&&z.form===f}).sort(function(a,b){return a.compareDocumentPosition(b)&2?1:-1});"
            "var subs=[],d=null;cand.forEach(function(z){var zt=String(z.type||'').toLowerCase();if((z.tagName==='BUTTON'&&zt==='submit')||"
            "(z.tagName==='INPUT'&&(zt==='submit'||zt==='image'))){if(ED(z))BAD=true;if(!d)d=z;subs.push(nm(z))}});"
            "if(BAD)return {unread:true};"
            "o.form.def=d?nm(d):'';o.form.subs=subs.slice(0,200);o.form.subs_more=subs.length>200;"
            "o.form.effm=String((d&&d.hasAttribute('formmethod'))?d.formMethod:f.method||'get').toLowerCase();"
            "o.form.effa=String((d&&d.hasAttribute('formaction'))?d.formAction:f.action||'');"
            "for(var i=0;i<f.elements.length&&i<40;i++){var x=f.elements[i];if(!x.name&&!x.id)continue;var t=(x.type||'').toLowerCase();"
            "o.form.fields.push([x.name||x.id,t])}}"
            "o.frame=(e.ownerDocument&&e.ownerDocument.defaultView!==window)?1:0;"
            # Nothing of the page's own text around the button is read (Ren, 26 Nov 2026 ~16:55 MST, the name-only rule):
            # what the button is called and what its form is (above) is all that is judged.
            "o.tag=(e.tagName||'').toLowerCase()}catch(x){return {unread:true}}return o})")


async def _node_read(relay, tab: str, backend: int) -> Dict[str, Any]:
    try:
        ctx = await _world(relay, tab)
        r = await _cdp(relay, tab, "DOM.resolveNode", {"backendNodeId": backend, "executionContextId": ctx})
        oid = ((r or {}).get("object") or {}).get("objectId")
        if not oid:
            return {"unread": True}
        res = await _cdp(relay, tab, "Runtime.callFunctionOn", {"objectId": oid, "functionDeclaration": _READ_FN,
                                                                 "returnByValue": True})
        await _cdp(relay, tab, "Runtime.releaseObject", {"objectId": oid})
        v = ((res or {}).get("result") or {}).get("value")
        if not isinstance(v, dict) or (res or {}).get("exceptionDetails"):
            return {"unread": True}              # a read that failed is never "no form" (RELEASE-ACTION): no click
        f = v.get("form")
        if f is not None and (not isinstance(f, dict) or not isinstance(f.get("method"), str) or not isinstance(f.get("action"), str)
                              or not isinstance(f.get("effm"), str) or not isinstance(f.get("effa"), str)):
            return {"unread": True}
        return v
    except Exception:
        return {"unread": True}


MOVING = ("The page is still moving (scrolling or animating), so what Qosha reads there may not be what a click would hit. "
          "Wait a moment, take a new look, then try again.")


async def settled(relay, tab: str) -> bool:
    """The page is not scrolling: its scroll position is the same twice, 150 ms apart (journey finding, 22 Nov)."""
    import asyncio
    ctx = await _world(relay, tab)
    q = {"expression": "JSON.stringify([scrollX, scrollY, document.documentElement.scrollTop])", "contextId": ctx,
         "returnByValue": True}
    a = ((await _cdp(relay, tab, "Runtime.evaluate", q)) or {}).get("result", {}).get("value")
    await asyncio.sleep(0.15)
    b = ((await _cdp(relay, tab, "Runtime.evaluate", q)) or {}).get("result", {}).get("value")
    return bool(a) and a == b


async def _backend_at(relay, tab: str, x: float, y: float) -> int:
    """Only which element is at the point (the quick re-check right before a press or release)."""
    vv = ((await _cdp(relay, tab, "Page.getLayoutMetrics")) or {}).get("cssVisualViewport") or {}
    try:
        loc = await _cdp(relay, tab, "DOM.getNodeForLocation", {"x": int(x + float(vv.get("pageX") or 0)),
                                                                  "y": int(y + float(vv.get("pageY") or 0)),
                                                                  "includeUserAgentShadowDOM": False})
    except Exception:
        return 0
    return int((loc or {}).get("backendNodeId") or 0)


async def element_at(relay, tab: str, x: float, y: float) -> Dict[str, Any]:
    await _cdp(relay, tab, "DOM.enable")
    # A click's x/y count from the top-left of the visible window; DOM.getNodeForLocation counts from the top-left of the
    # whole page. Without the page's scroll offset Qosha would judge a different element than the one the click hits
    # (real-site journey, httpbin.org, 22 Nov 2026).
    vv = ((await _cdp(relay, tab, "Page.getLayoutMetrics")) or {}).get("cssVisualViewport") or {}
    px, py = float(vv.get("pageX") or 0), float(vv.get("pageY") or 0)
    if not (0 <= x < float(vv.get("clientWidth") or 1e9) and 0 <= y < float(vv.get("clientHeight") or 1e9)):
        return {"offscreen": True}
    try:
        loc = await _cdp(relay, tab, "DOM.getNodeForLocation", {"x": int(x + px), "y": int(y + py),
                                                                  "includeUserAgentShadowDOM": False})
    except Exception:
        return {"offscreen": True}
    el = await describe(relay, tab, int((loc or {}).get("backendNodeId") or 0))
    if el and str((loc or {}).get("frameId") or "") not in ("", _t(tab).get("main") or ""):
        el["frame"] = True
    return el


async def focused(relay, tab: str) -> Dict[str, Any]:
    ctx = await _world(relay, tab)
    r = await _cdp(relay, tab, "Runtime.evaluate", {"expression": "document.activeElement", "contextId": ctx,
                                                     "returnByValue": False})
    oid = ((r or {}).get("result") or {}).get("objectId")
    if not oid:
        return {}
    d = await _cdp(relay, tab, "DOM.describeNode", {"objectId": oid})
    await _cdp(relay, tab, "Runtime.releaseObject", {"objectId": oid})
    el = await describe(relay, tab, int(((d or {}).get("node") or {}).get("backendNodeId") or 0))
    return {} if el.get("tag") in ("body", "html", "") else el


_NAMED_ROLES = ("button", "menuitem", "menuitemcheckbox", "menuitemradio", "checkbox", "radio", "switch", "tab",
                "option", "treeitem", "link", "textbox", "searchbox", "combobox", "spinbutton", "slider", "listbox")


async def _pseudo_host(relay, tab: str, backend: int) -> int:
    """The element a ::before/::after belongs to, read in Qosha's own script world (a page can't rewrite it there). 0 = unknown."""
    try:
        ctx = await _world(relay, tab)
        r = await _cdp(relay, tab, "DOM.resolveNode", {"backendNodeId": backend, "executionContextId": ctx})
        oid = ((r or {}).get("object") or {}).get("objectId")
        if not oid:
            return 0
        res = await _cdp(relay, tab, "Runtime.callFunctionOn", {"objectId": oid, "returnByValue": False,
                                                                 "functionDeclaration": "function () { return this.element || null; }"})
        await _cdp(relay, tab, "Runtime.releaseObject", {"objectId": oid})
        hid = ((res or {}).get("result") or {}).get("objectId")
        if not hid:
            return 0
        h = await _cdp(relay, tab, "DOM.describeNode", {"objectId": hid})
        await _cdp(relay, tab, "Runtime.releaseObject", {"objectId": hid})
        hn = (h or {}).get("node") or {}
        return 0 if hn.get("pseudoType") else int(hn.get("backendNodeId") or 0)
    except Exception:
        return 0


async def describe(relay, tab: str, backend: int, _host: bool = False) -> Dict[str, Any]:
    """What a person would see for this element: role and name from the accessibility tree (the nearest meaningful
    ancestor), tag and attributes, its form and the text of its form/dialog/region, and a fingerprint of all of it."""
    if not backend:
        return {}
    d = await _cdp(relay, tab, "DOM.describeNode", {"backendNodeId": backend, "depth": 0})
    node = (d or {}).get("node") or {}
    if node.get("pseudoType") and not _host:   # a ::before/::after icon: the click goes to its element (journey J-11, Gmail)
        host = await _pseudo_host(relay, tab, backend)
        if host and host != backend:
            el = await describe(relay, tab, host, _host=True)
            if el:                                 # what Chrome reports at the point stays the raw id (verify J-11)
                el["backend"] = backend
            return el
    attrs = node.get("attributes") or []
    a = {str(attrs[i]).lower(): str(attrs[i + 1]) for i in range(0, len(attrs) - 1, 2)}
    try:                                         # only the element and its ancestors (Gmail-sized pages stay fast)
        ax = await _cdp(relay, tab, "Accessibility.getAXNodeAndAncestors", {"backendNodeId": backend})
    except Exception:
        ax = await _cdp(relay, tab, "Accessibility.getPartialAXTree", {"backendNodeId": backend, "fetchRelatives": True})
    allnodes = (ax or {}).get("nodes") or []
    byid = {n.get("nodeId"): n for n in allnodes}
    me = next((n for n in allnodes if n.get("backendDOMNodeId") == backend), allnodes[0] if allnodes else None)
    nodes = []                                     # the node, then its ancestors only (never siblings or children)
    while me is not None and len(nodes) < 40:
        nodes.append(me)
        me = byid.get(me.get("parentId"))
    role, name, in_dialog, href = "", "", False, ""
    for n in nodes:
        r = str(((n.get("role") or {}).get("value")) or "").lower()
        if r in ("dialog", "alertdialog"):
            in_dialog = True
        if not role and r in _NAMED_ROLES:
            role, name = r, str(((n.get("name") or {}).get("value")) or "")
    if not role and nodes:
        role = str(((nodes[0].get("role") or {}).get("value")) or "").lower()
        name = str(((nodes[0].get("name") or {}).get("value")) or "")
    tag = str(node.get("nodeName") or "").lower()
    if tag == "a" or role == "link":
        href = a.get("href", "")
    rd = await _node_read(relay, tab, backend)
    if isinstance(rd.get("act"), dict):           # the point is on a child of a button/link: judge that control (r1 Gemini F3)
        tag = str(rd["act"].get("tag") or tag)
        at = rd["act"].get("attrs") or []
        a = {str(at[i]).lower(): str(at[i + 1]) for i in range(0, len(at) - 1, 2)}
    if rd.get("href"):
        href = str(rd["href"])                  # the real anchor, also when the point is on a child of it (r1 GPT 06)
    if role == "link" and not href:
        href = "?"
    el = {"backend": backend, "tag": tag, "attrs": a, "role": role, "name": du.clean(name, 160), "form": rd.get("form") or {},
          "name_cut": du.clean(name, 160) != du.clean(name, 10 ** 6),   # longer than what is judged (PAY-OWN-NAME-TRUNCATED)
          "qosha": bool(rd.get("qosha")), "unread": bool(rd.get("unread")),
          "in_dialog": in_dialog, "href": href,
          "frame": bool(rd.get("frame")) or tag in ("iframe", "frame", "embed", "object")}
    # bound to everything the step would send: every form field (hidden ones too, full length), the effective
    # destination and the whole text of its form/dialog (review r1 GPT 07)
    el["fp"] = hashlib.sha256(json.dumps([el["tag"], a, role, name, el["form"], href],
                                         sort_keys=True, default=str).encode()).hexdigest()
    # which element it is, without what is typed in it or around it: what a press and its release must share (22:00 cut)
    el["id"] = hashlib.sha256(json.dumps([backend, el["tag"], role, name, href], sort_keys=True, default=str).encode()).hexdigest()
    return el


def _secret(el: Dict[str, Any]) -> bool:
    a = el.get("attrs") or {}
    t = a.get("type", "").lower()
    ac = a.get("autocomplete", "").lower()
    toks = ac.split()                            # autocomplete is a token list: "billing cc-number" (verify Δ1)
    if t in ("password", "file", "hidden") or any(x.startswith("cc-") or x in ("one-time-code", "current-password", "new-password")
                                                  for x in toks):
        return True
    words = du._fold(" ".join([el.get("name") or "", a.get("name", ""), a.get("id", ""), a.get("placeholder", ""),
                               a.get("aria-label", "")]))
    return bool(du._SECRET_NAME.search(words) or re.search(r"card ?number|cardnumber|cc ?num|iban|routing|ssn|cpf|cvv|cvc",
                                                           words))


# ---- the judgment ---------------------------------------------------------------------------------------------------
def _hold(tab: str, kind: str, rows: List[Tuple[str, str]], step: Dict[str, Any], site: str) -> Tuple[str, Any]:
    if kind not in HOLDABLE:                     # a final step: the person presses it (mc21 shrink); grants don't apply
        return ("refuse", FINAL_TEXT % KIND_TEXT.get(kind, "finish something in your Chrome"))
    rule = rule_for(kind, site)
    if kind in ALWAYS_OK and rule and _always(rule):
        return ("run_always", step.get("params") or {})   # the person chose "Always allow" for this kind on this host
    hid = secrets.token_hex(6)
    with _lock:
        HELD[hid] = {"id": hid, "tab": tab, "kind": kind, "rows": rows, "step": step, "site": site, "at": time.time(),
                     "session": _SHARED.get("session", "")}
        while len(HELD) > 50:
            HELD.pop(next(iter(HELD)))
    return ("hold", "Not done yet: this step would %s, so it needs the person's OK. Call qosha_browser_confirm with "
                    "id \"%s\" (it asks them in the Qosha app), then take a new look and continue. Nothing was done."
            % (KIND_TEXT.get(kind, kind), hid))


def _ran(v: tuple) -> tuple:
    """A step the person always allowed runs as sent."""
    if v and v[0] == "run_always":
        return ("run", v[1])
    return v


def _site_hold(tab: str, site: str, what: str, step: Dict[str, Any], url: str = "") -> Tuple[str, str]:
    rows = [("Website", site), ("First step there", what)]
    if url:
        rows.append(("Address", du.clean(url, CARD_URL)))
    return _hold(tab, "chrome.site", rows, step, site)


async def judge(relay, tab: str, method: str, p: Dict[str, Any]) -> tuple:
    st = _t(tab)
    st["sid"] = _sid()                           # the chat that drives this tab now (one chat at a time)
    LAST_ACTIVITY.update({"at": time.time(), "site": site_of(st.get("url") or "")})
    if relay.paused:
        return ("refuse", "The person paused Qosha in Chrome (they clicked in Qosha's tab or pressed Pause). Ask them "
                          "to let Qosha continue in the Qosha app.")
    if method in NOOP:
        return ("run_noop", {})
    if method in GATED and not st.get("url"):
        await _world(relay, tab)                 # after a reconnect or Pause the tab's address is read first (fix 1)
    if method not in ("Page.navigate", "Page.stopLoading") and _wa(site_of(st.get("url") or "")):
        # a tab on WhatsApp (handed over, already open, or moved there by a redirect): nothing is read or done there,
        # whatever the person allowed for that website; 1.20.49's rule, here before any read (MERGE-WHATSAPP-WEB)
        return ("refuse", WA_TEXT + " This tab is on WhatsApp: open another address in it with goto_url, or leave it.")
    if method in GATED and (not st.get("url") or (site_of(st.get("url") or "") and not _here(st))) \
            and st.get("url") != "about:blank":
        # the tab is on a website Qosha didn't open there and the person never allowed (a redirect): no reading or
        # acting there; opening it with goto_url asks (shrink: G-REDIRECT)
        return ("refuse", "This tab moved to %s by itself (a redirect) and the person hasn't allowed that website. Qosha "
                          "doesn't read or act there; open it with goto_url if the person wants it (that asks them)."
                % site_of(st.get("url") or ""))
    if method in RUN:
        return ("run", p)
    if method not in JUDGED:
        return ("refuse", "%s is not available in your own Chrome. %s" % (method, READERS_HELP))
    if method == "Runtime.evaluate":
        expr = str(p.get("expression") or "")
        if not template(expr):
            return ("refuse", "Page scripts are not available in your own Chrome. " + READERS_HELP)
        return ("run", {"expression": expr, "returnByValue": True, "awaitPromise": bool(p.get("awaitPromise")),
                        "userGesture": False, "includeCommandLineAPI": False})
    if method in ("Page.navigateToHistoryEntry", "Page.reload"):
        return ("refuse", "Going back, forward or reloading is not available in your own Chrome (a reload can send a "
                          "form again); open the address with goto_url instead.")
    if method == "Page.navigate":
        url = str(p.get("url") or "")
        why = navigation(relay, tab, url)
        if why:
            return ("refuse", why)
        site = site_of(url)
        here = _here(st)                         # the tab's site only if Qosha got there with the person's say (G-REDIRECT)
        if len(url) > CARD_URL or du.clean(url, CARD_URL) != url:
            if site != here or leak(url) or _carried(url):
                return ("refuse", "That address is too long to show the person in full (%d characters); Qosha doesn't "
                                  "open it. Ask the person to open it." % len(url))
        step = {"method": method, "params": {"url": url}, "url": st.get("url")}
        why = leak(url)                          # about the host that receives it (R2-LINK-WRONG-HOST)
        need = [d for d in [site] + [x for x in _carried(url) if x != site] if d != here and not _site_ok(d)]
        if why and need:                         # a link grant never stands in for the site card (R2-LINK-SKIPS-SITE)
            return _hold(tab, "chrome.site", [("Website", need[0]), ("Address", du.clean(url, CARD_URL)),
                                              ("Why Qosha asks", why)], step, need[0])
        if why:                                  # about the receiving host; "Always allow" there runs it
            v = _ran(_hold(tab, "chrome.link", [("Website", site), ("Address", du.clean(url, CARD_URL)),
                                                ("Why Qosha asks", why)], step, site))
            if v[0] != "run":
                return v
        elif need:
            # Ren, 23 Nov ~15:10 MST ("Ask once per site"): an address on another website asks once per site ("Always
            # allow"); "Allow this time" opens exactly this address once (mc21 lite shrink)
            return _site_hold(tab, need[0], "open an address on another website" + ("" if need[0] == site else
                              " (the address carries %s)" % need[0]), step, url)
        st.setdefault("ok", set()).add(site)
        return ("run", {"url": url})
    if method == "Page.bringToFront":
        return ("run", {}) if front_mode() else ("run_noop", {})
    if method == "Page.handleJavaScriptDialog":
        if not p.get("accept"):
            return ("run", {"accept": False})
        dlg = st.get("dialog") or {}
        if dlg.get("type") == "alert":
            return ("run", {"accept": True})
        site = site_of(dlg.get("url") or st.get("url") or "")
        q = {"accept": True}
        if p.get("promptText") is not None:
            q["promptText"] = str(p.get("promptText"))[:500]
        return _ran(_hold(tab, "chrome.confirm", [("Website", site), ("The page asks", dlg.get("message") or "(no text)")]
                     + ([("Qosha's answer", du.clean(q["promptText"], 300))] if "promptText" in q else []),
                     {"method": method, "params": q, "url": st.get("url"), "dseq": dlg.get("seq")}, site))
    if _pending_in(tab):
        return ("refuse", "A step in this tab is waiting for the person's OK; nothing else is done there until they answer.")
    if not st.get("url"):
        await _world(relay, tab)                         # after a reconnect: read which page the tab is on first
    page_site = site_of(st.get("url") or "")
    if not page_site:
        return ("refuse", "Qosha could not tell which website this tab is on. Open the page again, then continue.")
    if any(page_site == d or page_site.endswith("." + d) for d in NEVER_HOSTS):
        return ("refuse", "This is a sign-in, payment or account page (%s). Qosha doesn't click or type there; ask the "
                          "person to do this step themselves, then continue." % page_site)
    if method == "Input.dispatchMouseEvent":
        return await _mouse(relay, tab, p, st, page_site)
    return await _keys(relay, tab, method, p, st, page_site)


# ---- mc21 lite (Ren, 23 Nov 2026: "do the liter version"): Qosha reads, opens addresses and types; mc22 (below) adds
# the judge's own clicks on ordinary buttons. No mouse press or release of the AI's and no key event reaches the page, so nothing a page does between Qosha's check and an event
# (moving focus, changing a form, dressing a button as a text box) can make Qosha press anything.
CLICK_TEXT = ("Qosha doesn't click that in your own Chrome: ask the person to click \"%s\" themselves, then take a new "
              "look. (Qosha opens links with goto_url, types into text fields and clicks ordinary named buttons.)")
KEYS_TEXT = ("Qosha doesn't press keys in your own Chrome (no Enter, Space, Tab or shortcuts). To type, put the cursor in a "
             "text field with click_at_xy on it, then type_text(\"...\"); the person clicks buttons and presses keys.")
FIELD_TEXT = ("Qosha types only into a text field it put the cursor in first (click_at_xy on the field, then type_text). "
              "Nothing was typed.")
SECRET_TEXT = ("Qosha never types into, copies from or acts in password, card, bank, ID or code fields. Ask the person to "
               "do that step themselves.")
# What a text field is, read from the element itself in Qosha's isolated world, never from the page's role labels:
# <textarea>, <input> of a text type, or an editable region (its outermost editable ancestor); not disabled or read-only.
# Called with true it also puts the cursor there: focus() can't press or submit anything.
_FIELD_FN = ("(function(doFocus){var e=this;if(e&&e.nodeType!==1)e=e.parentElement;if(!e||!e.tagName)return {kind:''};"
             "var t=e.tagName==='INPUT'?String(e.type||'').toLowerCase():'',k='';"
             "if(e.tagName==='TEXTAREA')k='textarea';"
             "else if(e.tagName==='INPUT'&&['text','search','email','url','tel','number'].indexOf(t)>=0)k='input';"
             "else if(e.isContentEditable){while(e.parentElement&&e.parentElement.isContentEditable)e=e.parentElement;k='editable'}"
             "if(k&&(e.disabled||e.readOnly))k='';var g=function(n){return String(e.getAttribute(n)||'')};"
             "var o={kind:k,pw:t==='password',tag:e.tagName.toLowerCase(),attrs:{type:t,autocomplete:g('autocomplete'),name:g('name'),"
             "id:String(e.id||''),placeholder:g('placeholder'),'aria-label':g('aria-label')}};"
             "var lb=[];try{[].forEach.call(e.labels||[],function(l){lb.push(l.innerText||'')});"
             "var rt=e.getRootNode&&e.getRootNode();g('aria-labelledby').split(/\\s+/).forEach(function(i){var n=i&&((rt&&rt.getElementById&&"
             "rt.getElementById(i))||document.getElementById(i));if(n)lb.push(n.innerText||n.textContent||'')})}catch(x){}"
             "var full=lb.join(' ');o.label_cut=full.length>2000;o.label=full.slice(0,2000);"
             "if(doFocus&&k){e.focus({preventScroll:true});window.__qoshaField=e;var a=document.activeElement;"
             "while(a&&a.shadowRoot&&a.shadowRoot.activeElement)a=a.shadowRoot.activeElement;o.focused=a===e}return o})")
_ACTIVE_EXPR = ("(function(){var a=document.activeElement;while(a&&a.shadowRoot&&a.shadowRoot.activeElement)"
                "a=a.shadowRoot.activeElement;if(!a||a===document.body||a===document.documentElement)return {kind:''};"
                "var o=(" + _FIELD_FN + ").call(a,false);o.same=Object.prototype.hasOwnProperty.call(window,'__qoshaField')"
                "&&a===window.__qoshaField;return o})()")


async def _field(relay, tab: str, backend: int, focus: bool = False) -> Dict[str, Any]:
    try:
        ctx = await _world(relay, tab)
        r = await _cdp(relay, tab, "DOM.resolveNode", {"backendNodeId": backend, "executionContextId": ctx})
        oid = ((r or {}).get("object") or {}).get("objectId")
        if not oid:
            return {}
        res = await _cdp(relay, tab, "Runtime.callFunctionOn", {"objectId": oid, "functionDeclaration": _FIELD_FN,
                                                                 "arguments": [{"value": bool(focus)}], "returnByValue": True})
        await _cdp(relay, tab, "Runtime.releaseObject", {"objectId": oid})
        v = ((res or {}).get("result") or {}).get("value")
        return v if isinstance(v, dict) else {}
    except Exception:
        return {}


_HOST_FN = ("(function(){var e=this;if(e&&e.nodeType!==1)e=e.parentElement;"
            "while(e&&e.parentElement&&e.parentElement.isContentEditable)e=e.parentElement;return e})")


async def _has_shadow(relay, tab: str, backend: int) -> bool:
    """Does the editable region (its outermost editable element) host a shadow tree, open or closed? Unknown counts."""
    try:
        ctx = await _world(relay, tab)
        r = await _cdp(relay, tab, "DOM.resolveNode", {"backendNodeId": backend, "executionContextId": ctx})
        oid = ((r or {}).get("object") or {}).get("objectId")
        res = await _cdp(relay, tab, "Runtime.callFunctionOn", {"objectId": oid, "functionDeclaration": _HOST_FN,
                                                                 "returnByValue": False})
        hid = ((res or {}).get("result") or {}).get("objectId")
        d = await _cdp(relay, tab, "DOM.describeNode", {"objectId": hid, "depth": 1, "pierce": False})
        for o in (oid, hid):
            if o:
                await _cdp(relay, tab, "Runtime.releaseObject", {"objectId": o})
        return bool(((d or {}).get("node") or {}).get("shadowRoots")) or not d
    except Exception:
        return True


_ACTIVE_HOST = ("(function(){var a=document.activeElement;while(a&&a.shadowRoot&&a.shadowRoot.activeElement)"
                "a=a.shadowRoot.activeElement;while(a&&a.parentElement&&a.parentElement.isContentEditable)a=a.parentElement;return a})()")


async def _active_has_shadow(relay, tab: str) -> bool:
    try:
        ctx = await _world(relay, tab)
        r = await _cdp(relay, tab, "Runtime.evaluate", {"expression": _ACTIVE_HOST, "contextId": ctx, "returnByValue": False})
        oid = ((r or {}).get("result") or {}).get("objectId")
        d = await _cdp(relay, tab, "DOM.describeNode", {"objectId": oid, "depth": 1, "pierce": False})
        if oid:
            await _cdp(relay, tab, "Runtime.releaseObject", {"objectId": oid})
        return bool(((d or {}).get("node") or {}).get("shadowRoots")) or not d
    except Exception:
        return True


async def _active_field(relay, tab: str) -> Dict[str, Any]:
    try:
        ctx = await _world(relay, tab)
        r = await _cdp(relay, tab, "Runtime.evaluate", {"expression": _ACTIVE_EXPR, "contextId": ctx, "returnByValue": True})
        v = ((r or {}).get("result") or {}).get("value")
        return v if isinstance(v, dict) else {}
    except Exception:
        return {}


async def _mouse(relay, tab: str, p: Dict[str, Any], st: Dict[str, Any], page_site: str) -> tuple:
    typ = str(p.get("type") or "")
    if typ == "mouseWheel":
        return ("run", p)
    if typ in ("mouseReleased", "mouseMoved"):
        return ("run_noop", {})                  # nothing was pressed, so nothing to release; no hover either
    if typ != "mousePressed":
        return ("refuse", "That mouse event is not available in your own Chrome.")
    x, y = float(p.get("x") or 0), float(p.get("y") or 0)
    try:
        await relay.ext("clear", tab=tab, x=x, y=y)       # Qosha's own pill never sits over the spot it reads
    except Exception:
        pass
    el = await element_at(relay, tab, x, y)
    if site_of(_t(tab).get("url") or "") != page_site:   # the tab went to another website while Qosha looked (CLICK-STALE-HOST)
        return ("refuse", MOVED_TEXT)
    if not el or el.get("offscreen"):
        return ("refuse", "Nothing Qosha can read is at that point (it may be outside the visible part of the page). "
                          "Scroll it into view, take a new look and try again.")
    if el.get("qosha"):
        return ("refuse", "That spot is under Qosha's own banner in the tab. Take a new look and try again.")
    if el.get("frame"):
        return ("refuse", "That is inside an embedded box from another page (payment and sign-in boxes often are). Qosha "
                          "doesn't act there; ask the person to do that step.")
    f = await _field(relay, tab, int(el.get("backend") or 0))
    if f.get("pw"):
        return ("refuse", SECRET_TEXT)
    if f.get("kind"):                            # a text field: Qosha puts the cursor there; no mouse event is sent
        if f.get("label_cut") or len(f.get("label") or "") >= 2000 or \
                _secret({"attrs": f.get("attrs") or {}, "name": "%s %s" % (el.get("name") or "", f.get("label") or "")}):
            return ("refuse", SECRET_TEXT)
        if f.get("kind") == "editable" and await _has_shadow(relay, tab, int(el.get("backend") or 0)):
            return ("refuse", "That editable area hides parts of itself from Qosha (a shadow tree), so Qosha can't tell "
                              "where text would go. Ask the person to type there.")   # G-SHADOW
        f = await _field(relay, tab, int(el.get("backend") or 0), focus=True)
        if f.get("focused"):
            return ("run_noop", {})
        return ("refuse", "Qosha couldn't put the cursor in that field. Take a new look and try again.")
    if el.get("href") and el["href"] != "?":
        return ("refuse", "Qosha doesn't click links in your own Chrome. To open the link \"%s\", open its address: goto_url(%r)."
                % (el.get("name") or "", el["href"]))
    return await _click(relay, tab, p, el, x, y, st, page_site)


# ---- mc22 (design B, Ren 23 Nov 2026): on websites the person allowed, Qosha clicks ordinary named buttons ------------
# The judge makes the click itself (the AI's own press and release send nothing): it watches the target for WATCH_S, presses,
# judges again at the point and releases only on the same, unchanged element. Otherwise it lets go at SAFE_XY, away from
# the target, after a guard in Qosha's isolated world that eats that one click (also when the page captured the pointer).
# The first click on a website asks (card chrome.click): "Allow this time" does exactly that click once, judged again
# through the same path; "Always allow" lets ordinary buttons on that exact host be clicked from then on.
WATCH_S = 0.3
SAFE_XY = (0, 0)
LONG_TEXT = ("That button's name is too long for Qosha to read whole, so it can't tell what it does and did not click it. "
             "Ask the person to click it themselves.")
UNNAMED_TEXT = ("That control has no name Qosha can read, so it can't tell what it does. Ask the person to click it, or "
                "use a named control.")
CHANGED_TEXT = ("The page changed that button just as Qosha went to click it, so Qosha did not click it. Take a new look; "
                "if it keeps changing, ask the person to click it.")
CHOICE_TEXT = ("Qosha ticks boxes and picks options in your own Chrome only in a search or filter form of the same website, "
               "and never in drop-down lists: ask the person to set \"%s\" themselves.")
LABEL_TEXT = ("That is a label: clicking it clicks the box, field or button it names. Click that control itself, or "
              "ask the person to do it.")
_CHOICE_ROLES = ("checkbox", "radio", "switch", "menuitemcheckbox", "menuitemradio")


def _final_kind(el: Dict[str, Any], page_site: str) -> Optional[str]:
    """chrome.<kind> when pressing this element is a final step, "mixed" for two effects, None when it is not."""
    k = du.label_kind(el.get("name") or "")
    if k == "mixed":
        return "mixed"
    if k and k != "desktop.confirm":
        return "chrome." + k.split(".", 1)[1]
    if k == "desktop.confirm":
        return "chrome.confirm"              # "Continue", "Confirm", "OK"... can commit (review r1 GPT 05)
    a = el.get("attrs") or {}
    f = el.get("form") or {}
    submit = f and ((el.get("tag") == "button" and a.get("type", "submit").lower() not in ("button", "reset")) or
                    (el.get("tag") == "input" and a.get("type", "").lower() in ("submit", "image")))
    if submit:
        if f.get("method", "get") == "get" and re.match(r"https?://", f.get("action") or "") \
                and site_of(f.get("action") or "") == page_site:
            return None                      # a search or a filter on the same site (final-C F10: scheme and host)
        return "chrome.submit"
    return None


def _final_submitter(el: Dict[str, Any]) -> bool:
    """Any way this form submits (its buttons, image buttons, buttons outside it) says a final step (pass 2 F10)."""
    f = el.get("form") or {}
    if f.get("subs_more"):                       # more submitters than Qosha reads: the person's (shrink pass F10)
        return True
    if any(not str(x or "").strip() for x in f.get("subs") or []):   # a submitter with no readable name (final-C F10)
        return True
    return any(du.label_kind(x or "") for x in [f.get("def") or ""] + list(f.get("subs") or []))


def _get_here(method: Any, action: Any, page_site: str) -> bool:
    return str(method or "").lower() == "get" and bool(re.match(r"https?://", str(action or ""), re.I)) \
        and site_of(str(action)) == page_site


class _Final(str):
    """A refusal that leaves a final button to the person: Qosha scrolls it into view and names it."""


def _final(what: str, name: str, pay: bool = False) -> "_Final":
    t = FINAL_TEXT % what
    if name:
        t += " Qosha scrolled to \"%s\" in its tab: ask the person to click it there." % name
    if pay:
        t += PAY_TEXT
    return _Final(t)


# names that pay beyond the shared word lists (round 1, PAY-VISIBLE-PRICE): renting, renewing, adding money, bidding, tipping
_PAY_MORE = re.compile(r"(?:^| )(?:rent\w*|alug\w+|renew\w*|renov\w+|top up|add funds|add money|recarregar|place bid|bid now|dar lance|"
                       r"tip|gorjeta)(?= |$)")


def _says_pay(text: Any) -> bool:
    return "desktop.pay" in du.label_kinds(str(text or ""))


def _pays(el: Dict[str, Any]) -> bool:
    """Does this ordinary-named button say it pays? Ren, 26 Nov 2026 (~16:55 MST, card: the name-only rule): under
    "Always allow" clicks only a button whose OWN NAME says Pay, Buy, Subscribe, Rent or similar, or shows a price, waits
    for the person; Qosha does not look for prices elsewhere on the page. Kept from the form's own facts, which are read
    anyway: a submit button of its form named that way, or a card, bank or amount field in its form.
    Accepted by Ren: a payment behind an ordinary name ("Next", "Complete") with none of these can be clicked on a
    website where the person chose "Always allow" clicks."""
    f = el.get("form") or {}
    name = str(el.get("name") or "")
    if _says_pay(name) or _MONEY.search(name) or _PAY_MORE.search(du._fold(name)):
        return True
    return bool(f.get("card") or f.get("amount")
                or any(_says_pay(x) or _MONEY.search(str(x or "")) for x in [f.get("def") or ""] + list(f.get("subs") or [])))


def _click_why(el: Dict[str, Any], page_site: str) -> Optional[str]:
    """Why Qosha does not click this element itself (None: it may click it). Judged for EVERY click, also on websites
    the person always allows, and again between the press and the release."""
    a, f = el.get("attrs") or {}, el.get("form") or {}
    tag, role, t = el.get("tag") or "", el.get("role") or "", str(a.get("type") or "").lower()
    name = str(el.get("name") or "").strip()
    if el.get("unread") or f.get("unread"):
        return UNREAD_TEXT                       # what the form does can't be read: never taken for "no form"
    if el.get("name_cut"):                       # the rule goes by the button's own name: a name cut short is not judged
        return _Final(LONG_TEXT)
    if _secret(el):
        return SECRET_TEXT
    if el.get("href"):                           # calls itself a link but has no address to open with goto_url
        return CLICK_TEXT % (name or "that link")
    if not name:
        return UNNAMED_TEXT
    k = _final_kind(el, page_site)
    here = bool(f) and _get_here(f.get("method"), f.get("action"), page_site) \
        and _get_here(f.get("effm", f.get("method")), f.get("effa", f.get("action")), page_site)
    sub = (tag == "button" and t not in ("button", "reset")) or (tag == "input" and t in ("submit", "image"))
    if not k and f and (_final_submitter(el) or (sub and not here)):
        k = "chrome.submit"
    if k == "mixed":
        return _Final("That control (\"%s\") says two different things it would do; Qosha won't press it. Ask the person to "
                      "press it themselves." % name)
    if k:
        return _final(KIND_TEXT.get(k, "finish something in your Chrome"), name, pay=k == "chrome.pay" or _says_pay(name))
    if _pays(el):                                # its own name (or its form's own facts) says it pays
        return _final(KIND_TEXT["chrome.pay"], name, pay=True)
    if tag == "select" or ((tag == "input" and t in ("checkbox", "radio")) or role in _CHOICE_ROLES) and not here:
        return CHOICE_TEXT % name
    return None


async def _show(relay, tab: str, el: Dict[str, Any]) -> None:
    """A final button stays the person's: Qosha only scrolls it into view (no press, no cursor put there)."""
    try:
        await _cdp(relay, tab, "DOM.scrollIntoViewIfNeeded", {"backendNodeId": int(el.get("backend") or 0)})
    except Exception:
        pass


_WATCH_FN = ("(function(){var e=this;if(e&&!e.nodeType&&e.element)e=e.element;if(e&&e.nodeType!==1)e=e.parentElement;"
             "if(!e||!e.closest)return {ok:false};var a=e.closest('button,input,select,textarea,a[href]')||"
             "e.closest('[role=button],[role=link]')||e;var W=window.__qoshaWatch;if(W&&W.o)W.o.disconnect();var n={c:0};"
             "var o=new MutationObserver(function(r){n.c+=r.length}),all={attributes:true,childList:true,subtree:true,"
             "characterData:true};o.observe(a,all);var f=a.form||a.closest('form');if(f)o.observe(f,all);"
             "if(a.parentNode)o.observe(a.parentNode,{childList:true});window.__qoshaWatch={o:o,n:n,e:a,x:e};"
             "var L=e.closest('label')||a.closest('label');return {ok:true,label:!!(L&&L.control&&L.control!==a)}})")
_COUNT_EXPR = ("(function(){var W=window.__qoshaWatch;if(!W)return -1;W.n.c+=W.o.takeRecords().length;"
               "var k=(W.e.isConnected&&W.x.isConnected)?W.n.c:-1;%sreturn k})()")
# The guard that eats a click goes in BEFORE Qosha presses, and comes off only in the same step as the last check: when
# anything is wrong after the press (or the page stops answering) the click is already blocked (CLICK-CANCEL-CAPTURE).
# It has no timer of its own: a page that stalls while the button is down can't wait it out (CANCEL-GUARD-EXPIRES). After
# a "let go" Qosha takes it off itself, one second after the release was delivered.
_GUARD_EXPR = ("(function(){var W=window,o=W.__qoshaGuard;if(o&&o.off)o.off();var T=['pointerup','mouseup','click','auxclick',"
               "'dblclick','contextmenu'],s=function(v){v.stopImmediatePropagation();v.preventDefault()},g={};"
               "g.off=function(){T.forEach(function(t){W.removeEventListener(t,s,true)});if(W.__qoshaGuard===g)W.__qoshaGuard=null};"
               "T.forEach(function(t){W.addEventListener(t,s,true)});W.__qoshaGuard=g;return true})()")
# (the extension knows these two exact texts and the let-go at SAFE_XY: all it still runs while the person has Qosha paused)
_GUARD_OFF = "(function(){var g=window.__qoshaGuard;if(g&&g.off)g.off();return true})()"
# what Qosha's extension answers when it refused a step BEFORE sending it to the page (plugin/chrome/extension/sw.js)
NOT_SENT = ("paused", "stopped", "no_watch", "late", "refused", "not_qosha_tab", "no_rules")
_GUARD_LATER = "(function(){var g=window.__qoshaGuard;if(g&&g.off)setTimeout(g.off,1000);return true})()"
_DISARM = "if(k===0){var g=window.__qoshaGuard;if(!g||!g.off)return -1;g.off()}"
MOVED_TEXT = ("The tab moved to another page while Qosha was about to click, so it did not click. Take a new look.")


async def _iso(relay, tab: str, expr: str) -> Any:
    ctx = await _world(relay, tab)
    r = await _cdp(relay, tab, "Runtime.evaluate", {"expression": expr, "contextId": ctx, "returnByValue": True})
    return ((r or {}).get("result") or {}).get("value")


async def _watch(relay, tab: str, backend: int) -> Dict[str, Any]:
    """Start watching the target, its form and its place in the page (Qosha's isolated world; the page can't see it)."""
    try:
        ctx = await _world(relay, tab)
        r = await _cdp(relay, tab, "DOM.resolveNode", {"backendNodeId": backend, "executionContextId": ctx})
        oid = ((r or {}).get("object") or {}).get("objectId")
        if not oid:
            return {}
        res = await _cdp(relay, tab, "Runtime.callFunctionOn", {"objectId": oid, "functionDeclaration": _WATCH_FN,
                                                                 "returnByValue": True})
        await _cdp(relay, tab, "Runtime.releaseObject", {"objectId": oid})
        v = ((res or {}).get("result") or {}).get("value")
        return v if isinstance(v, dict) else {}
    except Exception:
        return {}


def _same_doc(tab: str, page_site: str, world: int) -> bool:
    """Still the page Qosha judged: same website, same loaded document (a new page gets a new script world)."""
    st = _t(tab)
    return bool(world) and st.get("world") == world and site_of(st.get("url") or "") == page_site


async def _changes(relay, tab: str, end: bool = False, disarm: bool = False) -> int:
    """How many times the page changed the watched target since the watch began; -1: unknown or gone (fail closed).
    disarm: when nothing changed, take the click guard off in this same step (no guard there = -1)."""
    try:
        v = await _iso(relay, tab, _COUNT_EXPR % ((_DISARM if disarm else "") +
                                                  ("W.o.disconnect();window.__qoshaWatch=null;" if end else "")))
    except Exception:
        return -1
    return int(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else -1


async def _same_after_press(relay, tab: str, el: Dict[str, Any], x: float, y: float, page_site: str, world: int = 0) -> bool:
    """Between the press and the release: the same page, the same element at the point, same form and destination, still
    a button Qosha may click, and no change since the watch began. The last step also takes the click guard off."""
    now = await element_at(relay, tab, x, y)
    if world and not _same_doc(tab, page_site, world):
        return False
    if not now or now.get("offscreen") or now.get("frame") or now.get("qosha"):
        return False
    if now.get("backend") != el.get("backend") or now.get("id") != el.get("id"):
        return False
    fa, fb = el.get("form") or {}, now.get("form") or {}
    if bool(fa) != bool(fb) or any(fa.get(k) != fb.get(k) for k in ("method", "action", "effm", "effa")):
        return False
    if _click_why(now, page_site):
        return False
    if world and not _same_doc(tab, page_site, world):
        return False
    return await _changes(relay, tab, disarm=True) == 0


def _click_ok(site: str) -> bool:
    """ "Always allow" clicks on this exact host."""
    r = rule_for("chrome.click", site)
    return bool(r) and _always(r)


_SNAP = ("id", "backend", "form")


async def _click(relay, tab: str, p: Dict[str, Any], el: Dict[str, Any], x: float, y: float, st: Dict[str, Any],
                 page_site: str) -> tuple:
    if p.get("modifiers") or str(p.get("button") or "left") != "left" or str(p.get("clickCount") or 1) not in ("1", "1.0"):
        return ("refuse", "Only plain single left clicks are available in your own Chrome (no double, right, Shift or "
                          "Ctrl clicks).")
    why = _click_why(el, page_site)
    if why:
        if isinstance(why, _Final):
            await _show(relay, tab, el)
        return ("refuse", why)
    if not _click_ok(page_site):                 # asks: "Allow this time" = this click once; "Always allow" = this host
        return _hold(tab, "chrome.click", [("Website", page_site), ("Button", du.clean(el.get("name"), 160))],
                     {"method": "Input.dispatchMouseEvent", "params": {"x": x, "y": y}, "url": st.get("url"),
                      "el": {k: el.get(k) for k in _SNAP}}, page_site)
    return await _do_click(relay, tab, el, x, y, page_site)


async def _do_click(relay, tab: str, el: Dict[str, Any], x: float, y: float, page_site: str, late=None) -> tuple:
    backend = int(el.get("backend") or 0)
    world = await _world(relay, tab)             # the page Qosha judged: every later step must still be on it
    if not _same_doc(tab, page_site, world):
        return ("refuse", MOVED_TEXT)
    w = await _watch(relay, tab, backend)
    if not w.get("ok"):
        return ("refuse", "Qosha couldn't check that button before clicking it, so it did not click. Take a new look and "
                          "try again, or ask the person to click it.")
    if w.get("label"):
        await _changes(relay, tab, end=True)
        return ("refuse", LABEL_TEXT)
    t0 = time.monotonic()
    if not await settled(relay, tab):
        await _changes(relay, tab, end=True)
        return ("refuse", MOVING)
    await asyncio.sleep(max(0.0, WATCH_S - (time.monotonic() - t0)))
    if await _changes(relay, tab) != 0 or await _backend_at(relay, tab, x, y) != backend:
        await _changes(relay, tab, end=True)
        return ("refuse", CHANGED_TEXT)
    if late and late():
        await _changes(relay, tab, end=True)
        return ("refuse", "Chrome was busy too long; nothing was clicked.")
    try:
        armed = (await _iso(relay, tab, _GUARD_EXPR)) is True
    except Exception:
        armed = False
    if not armed or not _same_doc(tab, page_site, world):   # no guard, or another page meanwhile: no press at all
        try:
            await _iso(relay, tab, _GUARD_OFF)
        except Exception:
            pass
        await _changes(relay, tab, end=True)
        return ("refuse", MOVED_TEXT if armed else "Qosha couldn't make that click safe to take back, so it did not click. "
                                                   "Take a new look and try again, or ask the person to click it.")
    q = {"x": x, "y": y, "button": "left", "clickCount": 1}
    try:
        await _cdp(relay, tab, "Input.dispatchMouseEvent", dict(q, type="mousePressed", buttons=1))
    except Exception as x_:
        # The press did not happen for sure when Qosha's extension refused it before sending it (the person paused or
        # stopped Qosha, it can't watch the page, the wait ran out): no button is down, so the blocker comes off at
        # once and the person's own clicks work. The extension lets exactly this one step through while paused.
        # Anything else is an unknown outcome: let go at the corner behind the blocker (harmless when no press
        # arrived), and the blocker goes one second after that (GUARD-STRANDS-HUMAN-CLICKS).
        try:
            if str(getattr(x_, "code", "")) in NOT_SENT:
                await _iso(relay, tab, _GUARD_OFF)
            else:                                # the blocker goes only after the let-go really went out
                await _cdp(relay, tab, "Input.dispatchMouseEvent", dict(q, x=SAFE_XY[0], y=SAFE_XY[1], type="mouseReleased", buttons=0))
                await _iso(relay, tab, _GUARD_LATER)
        except Exception:
            pass
        try:
            await _changes(relay, tab, end=True)
        except Exception:
            pass
        raise
    try:
        same = await _same_after_press(relay, tab, el, x, y, page_site, world)
    except Exception:
        same = False
    if not same:                                 # let go away from the changed target; the guard (still on) eats that click
        q.update(x=SAFE_XY[0], y=SAFE_XY[1])
    # The let-go and the two blocker steps are the only things Qosha's extension still runs while the person has Qosha
    # paused, so a Pause during the hold ends cleanly (GUARD-PAUSE-AFTER-PRESS). The blocker goes only after the let-go
    # really went out: if that failed the button may still be down, and the blocker stays (nothing lands).
    await _cdp(relay, tab, "Input.dispatchMouseEvent", dict(q, type="mouseReleased", buttons=0))
    if not same:                                 # the guard ate that release; it goes one second after it was delivered
        try:
            await _iso(relay, tab, _GUARD_LATER)
        except Exception:
            pass
    try:
        await _changes(relay, tab, end=True)
    except Exception:
        if same:
            raise
    return ("run_noop", {}) if same else ("refuse", CHANGED_TEXT)


async def _typing_refusal(relay, tab: str, text: str) -> str:
    """Why this text may not go in now, or "": a real text field must have the cursor, the one Qosha put there, not a
    secret field (labels count, whole), no line break outside a <textarea>, no shadow tree in an editable region."""
    f = await _active_field(relay, tab)          # text only goes in where a real text field has the cursor
    if not f.get("kind"):
        return FIELD_TEXT
    if not f.get("same"):                        # the cursor isn't where Qosha put it (the page moved it): nothing typed
        return ("The cursor is no longer in the field Qosha put it in (the page moved it). Nothing was typed; "
                "click_at_xy on the field again, then type.")
    if ("\r" in text or "\n" in text) and f.get("kind") != "textarea":
        return ("Qosha types line breaks only into multi-line boxes: in a chat box or rich editor a line break "
                "can send. Type the text without line breaks and tell the person where to add them.")
    if f.get("label_cut") or len(f.get("label") or "") >= 2000 or \
            _secret({"attrs": f.get("attrs") or {}, "name": f.get("label") or ""}):
        return SECRET_TEXT                       # the whole label counts; one too long to judge is refused (G-LABEL)
    if f.get("kind") == "editable" and await _active_has_shadow(relay, tab):
        return ("That editable area hides parts of itself from Qosha (a shadow tree), so Qosha can't tell where text "
                "would go. Ask the person to type there.")
    return ""


async def _keys(relay, tab: str, method: str, p: Dict[str, Any], st: Dict[str, Any], page_site: str) -> tuple:
    if method != "Input.insertText":
        return ("refuse", KEYS_TEXT)
    text = str(p.get("text") or "")
    if not text:
        return ("run_noop", {})
    v = await _typing_refusal(relay, tab, text)
    if v:
        return ("refuse", v)
    if not _type_ok(page_site):                  # Ren, 23 Nov: the first typing on a website asks (once per site)
        if len(text) > CARD_TYPE or du.clean(text, CARD_TYPE) != text:   # the card shows all that Allow would type
            return ("refuse", "That text is too long (or has characters the card can't show) to show the person in full "
                              "before typing it on a new website. Type it in shorter parts.")
        return _hold(tab, "chrome.type", [("Website", page_site), ("Text", text)],
                     {"method": "Input.insertText", "params": {"text": text}, "url": st.get("url")}, page_site)
    return ("run", {"text": text})


_SECRET_TYPES = ("password", "hidden", "file")


def _secret_attrs(attrs: list) -> bool:
    d = {str(attrs[i]).lower(): str(attrs[i + 1]).lower() for i in range(0, len(attrs) - 1, 2)}
    ac = d.get("autocomplete", "")
    words = du._fold(" ".join([d.get("name", ""), d.get("id", ""), d.get("aria-label", ""), d.get("placeholder", "")]))
    toks = ac.split()
    return d.get("type", "") in _SECRET_TYPES or any(x.startswith("cc-") or x in ("one-time-code", "current-password",
                                                                                   "new-password") for x in toks) \
        or bool(du._SECRET_NAME.search(words))


_EDITABLE_ROLES = {"textbox", "searchbox", "combobox", "spinbutton", "textfield", "textfieldwithcomboboxrole"}
_TEXT_ROLES = {"statictext", "inlinetextbox", "text", "generic", "paragraph", "linebreak"}


def _ax_field_text(res: Any) -> None:
    """Text nodes inside an editable field lose their names; a text node whose ancestors aren't in the reply does too
    (it might be inside a field). Final pass Δ1."""
    nodes = (res or {}).get("nodes") if isinstance(res, dict) else None
    if not isinstance(nodes, list):
        return
    byid = {str(n.get("nodeId")): n for n in nodes if isinstance(n, dict)}

    def role(n):
        return str(((n.get("role") or {}).get("value")) or "").lower()
    for n in nodes:
        if not isinstance(n, dict):
            continue
        p, hidden, seen = n.get("parentId"), None, 0
        hidden, last = True, None                 # unresolved after 60 steps: hidden (final-C Δ1)
        while seen < 60:
            seen += 1
            if p is None or str(p) not in byid:   # resolved only at the page's root (final-D note); else unknown
                top = n if p is None and seen == 1 else byid.get(str(last)) if last is not None else n
                hidden = p is not None or role(top or {}) not in ("rootwebarea", "webarea")
                break
            last = p
            q = byid[str(p)]
            if role(q) in _EDITABLE_ROLES or q.get("properties") and any(
                    (pp.get("name") == "editable") for pp in q.get("properties") or [] if isinstance(pp, dict)):
                hidden = True
                break
            p = q.get("parentId")
        if hidden:
            n.pop("name", None)
            n.pop("value", None)


def redact(method: str, res: Any) -> Any:
    """DOM replies never carry the value written in a password, hidden, card or code field's HTML (review r1 GPT 03)."""
    def walk(x):
        if isinstance(x, dict):
            at = x.get("attributes")
            if isinstance(at, list) and (str(x.get("nodeName") or "").upper() in ("INPUT", "TEXTAREA", "") ) and _secret_attrs(at):
                for i in range(0, len(at) - 1, 2):
                    if str(at[i]).lower() == "value":
                        at[i + 1] = ""
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
        return x
    if method.startswith("Accessibility."):     # a field's value (a one-time code, an autofill) never leaves (pass A Δ1)
        _ax_field_text(res)
        def ax(x):
            if isinstance(x, dict):
                if "role" in x and ("nodeId" in x or "name" in x):   # an accessibility node: its field value goes
                    x.pop("value", None)
                    props = x.get("properties")
                    if isinstance(props, list):
                        x["properties"] = [pp for pp in props if not (isinstance(pp, dict) and pp.get("name") == "valuetext")]
                        role_ = str(((x.get("role") or {}).get("value")) or "").lower()
                        if role_ not in _EDITABLE_ROLES and any(isinstance(pp, dict) and pp.get("name") == "editable"
                                                                for pp in props):
                            x.pop("name", None)             # contenteditable text that isn't a field (final-E Gemini F5)
                for v in x.values():
                    ax(v)
            elif isinstance(x, list):
                for v in x:
                    ax(v)
            return x
        return ax(res)
    return walk(res) if method.startswith("DOM.") else res


def _sid() -> str:
    return str(_SHARED.get("session", "") or "")


def note_visit(url: str) -> None:
    h = site_of(url)
    if h:
        with _lock:
            VISITED.setdefault(_sid(), set()).add(h)


def note_read(res: Any) -> None:
    """Text that came back from a page this answer (reader results, accessibility names), kept to spot it in an address."""
    out = []

    def walk(x):
        if isinstance(x, str):
            if len(x) >= 8:
                out.append(x)
        elif isinstance(x, dict):
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
    walk(res)
    if out:
        with _lock:
            blob = READ.get(_sid(), "") + "\n" + "\n".join(out).lower()
            READ[_sid()] = blob[-400000:]


def leak(url: str) -> Optional[str]:
    """Why opening this address could carry data to a host Qosha hasn't been on in this chat, or None."""
    from urllib.parse import unquote_plus
    h = site_of(url)
    with _lock:
        if h in VISITED.get(_sid(), set()):
            return None
        blob = READ.get(_sid(), "")
    sp = urlsplit(url)
    if len(sp.query) + len(sp.fragment) > LEAK_QUERY:
        return "the address carries a long query (%d characters) to a website Qosha hasn't opened in this chat" % (len(sp.query) + len(sp.fragment))
    if any(len(seg) > LEAK_SEGMENT for seg in sp.path.split("/")):
        return "the address carries a long path part to a website Qosha hasn't opened in this chat"
    if len(sp.path) > LEAK_PATH:
        return "the address is long (%d characters) and goes to a website Qosha hasn't opened in this chat" % len(sp.path)
    if blob:
        text = re.sub(r"\s+", " ", unquote_plus(sp.path + " " + sp.query + " " + sp.fragment)).lower()
        flat = re.sub(r"\s+", " ", blob)
        for i in range(0, max(0, len(text) - LEAK_RUN) + 1):       # every offset (verify L1)
            piece = text[i:i + LEAK_RUN]
            if len(piece.strip()) >= LEAK_RUN - 2 and piece in flat:
                return "the address carries text Qosha read on a page in this answer, to a website Qosha hasn't opened in this chat"
    return None


def late_refusal(tab: str, method: str) -> Optional[str]:
    """After a read ran: the tab is now on WhatsApp, or on a website that isn't allowed for it (it moved while the
    read was on its way). The reply is dropped then; Chrome reports the move before it answers the read."""
    if method not in GATED or method.startswith("Input.") or method == "Page.handleJavaScriptDialog":
        return None                              # only reads: a step that already ran is reported as it went
    st = _t(tab)
    site = site_of(st.get("url") or "")
    if _wa(site):
        return WA_TEXT
    if site and st.get("url") != "about:blank" and not _here(st):
        return ("This tab moved to %s by itself (a redirect) while Qosha was reading; what came back is not used. Open it "
                "with goto_url if the person wants it (that asks them)." % site)
    return None


def after(relay, tab: str, method: str, params: Dict[str, Any], res: Any) -> None:
    if method in ("Runtime.evaluate", "Accessibility.getFullAXTree", "Accessibility.getPartialAXTree", "Accessibility.queryAXTree"):
        note_read(res)


# ---- the person's answer ---------------------------------------------------------------------------------------------
def held(hid: str) -> Optional[Dict[str, Any]]:
    with _lock:
        h = HELD.get(str(hid))
        if h and time.time() - h["at"] > HOLD_TTL:
            HELD.pop(str(hid), None)
            return None
        return dict(h) if h else None


def take(hid: str) -> Optional[Dict[str, Any]]:
    """Consumed once: a second Allow for the same id finds nothing."""
    with _lock:
        h = HELD.pop(str(hid), None)
    if h and time.time() - h["at"] > HOLD_TTL:
        return None
    return h


async def perform(relay, h: Dict[str, Any]) -> Dict[str, Any]:
    """After the person's Allow: open exactly the address the card showed, once, only if the tab is still on the same page
    (mc21 shrink: no clicks, keys or page answers are done after an Allow)."""
    tab, step = h["tab"], h["step"]
    st = _t(tab)
    if relay.stopped or relay.paused:
        return {"ok": False, "error": "The person stopped or paused Qosha in Chrome; nothing was done."}
    if h.get("session") and h["session"] != _sid():
        return {"ok": False, "error": "Another chat is working in Chrome now; nothing was done."}
    st["sid"] = str(h.get("session") or _sid())  # this chat drives the tab: what Allow opens here ends with it
    if step.get("url") and st.get("url") and step["url"] != st.get("url"):
        return {"ok": False, "error": "The page changed since the person was asked; nothing was done. Take a new look."}
    m, p = step["method"], step["params"]

    def late() -> bool:                            # past the person's wait: nothing is sent any more (verify F5)
        return time.monotonic() > float(h.get("deadline") or float("inf"))
    if h["kind"] == "chrome.type" and m == "Input.insertText":   # exactly the text the card showed, once (shrink L2)
        text = str(p.get("text") or "")
        v = await _typing_refusal(relay, tab, text)
        if v:
            return {"ok": False, "error": v}
        if late():
            return {"ok": False, "error": "Chrome was busy too long; nothing was typed."}
        until = int((time.time() + float(h.get("deadline") or 0) - time.monotonic()) * 1000) if h.get("deadline") else 0
        await relay.ext("cdp", tab=tab, method=m, params={"text": text}, until=until)
        return {"ok": True}
    if h["kind"] == "chrome.click":               # mc22: exactly the button the card showed, clicked once, judged again
        page_site, el0 = site_of(st.get("url") or ""), step.get("el") or {}
        if not _here(st):
            return {"ok": False, "error": "The tab is no longer on a website Qosha may act on; nothing was clicked."}
        el = await element_at(relay, tab, float(p.get("x") or 0), float(p.get("y") or 0))
        if site_of(_t(tab).get("url") or "") != page_site:
            return {"ok": False, "error": MOVED_TEXT}
        if not el or any(el.get(k) != el0.get(k) for k in _SNAP) or el.get("frame") or el.get("qosha") \
                or _click_why(el, page_site):
            return {"ok": False, "error": "That button changed since the person was asked; nothing was clicked. Take a "
                                          "new look."}
        v = await _do_click(relay, tab, el, float(p.get("x") or 0), float(p.get("y") or 0), page_site, late)
        return {"ok": True} if v[0] == "run_noop" else {"ok": False, "error": v[1]}
    if m == "Page.navigate":
        why = navigation(relay, tab, p.get("url"))
        if why:
            return {"ok": False, "error": why}
        if late():
            return {"ok": False, "error": "Chrome was busy too long; nothing was done."}
        until = int((time.time() + float(h.get("deadline") or 0) - time.monotonic()) * 1000) if h.get("deadline") else 0
        await relay.ext("cdp", tab=tab, method=m, params=p, until=until)   # the extension checks it too (pass 2 F5)
        st.setdefault("ok", set()).add(site_of(p.get("url")))   # Qosha opened it with the person's say (G-REDIRECT)
        after(relay, tab, m, p, None)
        return {"ok": True}
    return {"ok": False, "error": "Qosha can't do that step."}
