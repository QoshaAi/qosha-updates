"""Qosha's relay to the person's own Chrome (mc21).

Two local doors, both on 127.0.0.1 only, in the Qosha process that runs the person's chats:
* the extension's door: Qosha's native host connects here (Chrome starts the host for Qosha's extension only) and proves
  itself with the key in <home>/qosha/chrome-relay.json (this user only). One extension at a time.
* the engine's door: a Chrome DevTools endpoint at a random port and secret path. The engine's own browser tool
  (browser_exec, browser_cdp, browser_dialog) connects here, unchanged, when the person chose "In your own Chrome".

Behind the engine's door there is no whole browser: only Qosha's tabs (the ones it opened in its "Qosha" tab group, or
the person handed over). Each command is judged (chrome_judge) before the extension sends it to that one tab with Chrome's
debugger: commands Qosha never sends are refused (cookies, storage, request interception, scripts on every page load,
other targets); page scripts run in Chrome's side-effect-free mode (reads only), except the browser tool's own fixed
helper scripts; final steps (send, pay, delete, share, submit) are held for the person's Allow in the Qosha app.
Fails closed: when the extension's link drops, Stop is pressed or the address changes, every engine connection is cut
and nothing is queued for later.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import secrets
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional

log = logging.getLogger("qosha.chrome")

EXT_CALL_TIMEOUT = 30.0
_EVENTS_FORWARDED = {
    "Page.loadEventFired", "Page.domContentEventFired", "Page.frameNavigated", "Page.frameStartedLoading",
    "Page.frameStoppedLoading", "Page.javascriptDialogOpening", "Page.javascriptDialogClosed", "Page.lifecycleEvent",
    "Runtime.executionContextCreated", "Runtime.executionContextDestroyed", "Runtime.executionContextsCleared",
    "DOM.documentUpdated",
}
_NET_KEEP = ("requestId", "loaderId", "timestamp", "type", "frameId", "errorText", "canceled")


def _home() -> Path:
    try:
        return Path(_sib("store").engine_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or "~/.hermes").expanduser()


def _strip_event(method: str, params: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Only what the browser tool needs from an event: no headers, cookies, bodies or request data."""
    if method not in _EVENTS_FORWARDED:
        return None
    p = params if isinstance(params, dict) else {}
    if method.startswith("Network."):
        out = {k: p[k] for k in _NET_KEEP if k in p}
        if method == "Network.requestWillBeSent":
            out["request"] = {"method": str((p.get("request") or {}).get("method") or "")}
        return out
    if method == "Page.frameNavigated":
        fr = p.get("frame") or {}
        return {"frame": {k: fr.get(k) for k in ("id", "parentId", "loaderId", "url", "securityOrigin", "mimeType") if k in fr}}
    if method == "Runtime.executionContextCreated":
        c = p.get("context") or {}
        return {"context": {k: c.get(k) for k in ("id", "origin", "name", "uniqueId", "auxData") if k in c}}
    return p


def _sib(name: str):
    """A sibling module of Qosha's guard, the same one whether this file was imported as part of the plugin or loaded by
    file path from the dashboard (all state lives in one place per process: sys._qosha_chrome_shared)."""
    import importlib
    import importlib.util
    import os as _os
    import sys as _sys
    pkg = __name__.rpartition(".")[0]
    if pkg:
        try:
            return importlib.import_module(pkg + "." + name)
        except ImportError:
            pass
    for n, m in list(_sys.modules.items()):
        if n.endswith("qosha_guard." + name) or n == "qosha_chrome_" + name:
            return m
    spec = importlib.util.spec_from_file_location("qosha_chrome_" + name, _os.path.join(_os.path.dirname(__file__), name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    _sys.modules["qosha_chrome_" + name] = mod
    spec.loader.exec_module(mod)
    return mod


class Relay:
    """One per Qosha process. Thread-safe entry points: start(), stop(), status(), cdp_url(), control(), call_ext()."""

    def __init__(self, home: Optional[Path] = None):
        self.home = Path(home) if home else _home()
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.thread: Optional[threading.Thread] = None
        self.ready = threading.Event()
        self.key = secrets.token_urlsafe(32)
        self.path_secret = secrets.token_urlsafe(24)
        self.host_port = 0
        self.cdp_port = 0
        self.ext_writer: Optional[asyncio.StreamWriter] = None
        self.ext_info: Dict[str, Any] = {}
        self.ext_seen = 0.0
        self.pending: Dict[int, asyncio.Future] = {}
        self.tab_locks: Dict[str, Any] = {}
        self.next_id = 1
        self.clients: Dict[int, "Client"] = {}
        self.stopped = False             # the person's Stop (lifted only by resume from the Qosha window)
        self.paused = False
        self.epoch = 0                   # bumps on every cut: queued or held work from before is void
        self.lock = threading.Lock()
        self._servers = []

    # ---- life ------------------------------------------------------------------------------------------------------
    def start(self) -> "Relay":
        if self.thread and self.thread.is_alive():
            return self
        self.thread = threading.Thread(target=self._run, name="qosha-chrome-relay", daemon=True)
        self.thread.start()
        self.ready.wait(10)
        return self

    def _run(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self._serve())
        self.ready.set()
        self.loop.run_forever()

    async def _serve(self):
        import websockets
        # replies such as screenshots are far larger than asyncio's 64 KiB line default (review r1 GPT 13)
        host_srv = await asyncio.start_server(self._on_host, "127.0.0.1", 0, limit=96 * 1024 * 1024)
        self.host_port = host_srv.sockets[0].getsockname()[1]
        cdp_srv = await websockets.serve(self._on_cdp, "127.0.0.1", 0, max_size=64 * 1024 * 1024,
                                         process_request=self._check_path)
        self.cdp_port = list(cdp_srv.sockets)[0].getsockname()[1]
        self._servers = [host_srv, cdp_srv]
        self._write_address()

    def _write_address(self):
        d = self.home / "qosha"
        d.mkdir(parents=True, exist_ok=True)
        p = d / "chrome-relay.json"
        tmp = d / ("chrome-relay.json.%d.tmp" % os.getpid())
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump({"port": self.host_port, "key": self.key, "pid": os.getpid()}, f)
        os.replace(tmp, p)

    def stop(self):
        if not self.loop:
            return
        fut = asyncio.run_coroutine_threadsafe(self._shutdown(), self.loop)
        try:
            fut.result(5)
        except Exception:
            pass
        self.loop.call_soon_threadsafe(self.loop.stop)

    async def _shutdown(self):
        await self._cut("Qosha is closing its link to Chrome.")
        for s in self._servers:
            s.close()
        if self.ext_writer:
            self.ext_writer.close()

    def cdp_url(self) -> str:
        return "ws://127.0.0.1:%d/devtools/browser/%s" % (self.cdp_port, self.path_secret) if self.cdp_port else ""

    def connected(self) -> bool:
        """Linked AND the extension's files checked against the ones Qosha ships (review r1 GPT 15)."""
        return self.ext_writer is not None and bool(self.ext_info.get("verified"))

    def status(self) -> Dict[str, Any]:
        return {"connected": self.connected(), "stopped": self.stopped, "paused": self.paused,
                "extension": dict(self.ext_info), "clients": len(self.clients)}

    # ---- the extension's door --------------------------------------------------------------------------------------
    async def _on_host(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        try:
            line = await asyncio.wait_for(reader.readline(), 10)
            hello = json.loads(line or b"{}")
            if not (isinstance(hello, dict) and secrets.compare_digest(str(hello.get("key") or ""), self.key)):
                writer.close()
                return
        except Exception:
            writer.close()
            return
        if self.ext_writer is not None:          # one extension at a time: the newest replaces the old one
            old = self.ext_writer
            self.ext_writer = None
            await self._cut("Chrome reconnected.")
            old.close()
        self.ext_info = {}                     # a new link is checked again before anything runs (r2 GPT F11b)
        self.ext_writer = writer
        self.ext_seen = time.time()
        self._send_ext_raw({"event": "relay_up"})
        try:
            while True:
                line = await reader.readline()
                if not line:
                    break
                try:
                    msg = json.loads(line)
                except ValueError:
                    continue
                if isinstance(msg, dict):
                    await self._from_ext(msg)
        except Exception:
            pass
        finally:
            if self.ext_writer is writer:
                self.ext_writer = None
                self.ext_info = {}
                await self._cut("Chrome's link to Qosha closed.")
            writer.close()

    def _send_ext_raw(self, obj):
        w = self.ext_writer
        if w is None:
            return False
        w.write(json.dumps(obj, separators=(",", ":")).encode() + b"\n")
        return True

    async def ext(self, cmd: str, **args) -> Any:
        """One command to the extension; raises RelayError on refusal or a lost link."""
        if self.ext_writer is None:
            raise RelayError("not_connected", "Qosha is not connected to your Chrome.")
        i = self.next_id
        self.next_id += 1
        fut = self.loop.create_future()
        self.pending[i] = fut
        self._send_ext_raw({"id": i, "cmd": cmd, "args": args})
        t0 = time.time()
        try:
            r = await asyncio.wait_for(fut, EXT_CALL_TIMEOUT)
        finally:
            self.pending.pop(i, None)
            if os.environ.get("QOSHA_CHROME_TRACE") and time.time() - t0 > 0.3:
                with open(os.environ["QOSHA_CHROME_TRACE"], "a", encoding="utf-8") as f:
                    f.write("  ext %.2f %s %s\n" % (time.time() - t0, cmd, args.get("method", "")))
        if not r.get("ok"):
            e = r.get("error") or {}
            raise RelayError(str(e.get("code") or "error"), str(e.get("detail") or ""))
        return r.get("result")

    def call_ext(self, cmd: str, timeout: float = 35.0, **args) -> Any:
        """From any thread."""
        if not self.loop:
            raise RelayError("not_started", "Qosha's link to Chrome is not running.")
        return asyncio.run_coroutine_threadsafe(self.ext(cmd, **args), self.loop).result(timeout)

    async def _from_ext(self, msg: Dict[str, Any]):
        if msg.get("id") is not None and ("ok" in msg):
            fut = self.pending.get(msg["id"])
            if fut and not fut.done():
                fut.set_result(msg)
            return
        ev = str(msg.get("event") or "")
        if ev == "ext_hello":
            self.ext_info = {k: msg.get(k) for k in ("version", "ua", "ctl", "mode", "files")}
            if msg.get("ctl") == "stopped":
                self.stopped = True              # the person's Stop outlives a Qosha restart (the extension kept it)
            want = files_hash()
            if not want or msg.get("files") != want:   # no reference to compare with counts as a mismatch (fail closed)
                self.ext_info["mismatch"] = True
                w = self.ext_writer
                self.ext_writer = None
                await self._cut("The Qosha extension in Chrome is not the one this Qosha ships.")
                if w:
                    w.close()
                return
            self.ext_info["verified"] = True
            self._changed()
            threading.Thread(target=lambda: _sib("chrome_api").on_connected(), daemon=True).start()
        elif ev == "cdp":
            tab = str(msg.get("tab") or "")
            method = str(msg.get("method") or "")
            params = _strip_event(method, msg.get("params") or {})
            if params is None or msg.get("sessionId"):
                return
            if method == "Page.javascriptDialogOpening":   # a WhatsApp page's own question is not passed on either
                cj = _sib("chrome_judge")
                if cj._wa(cj.site_of(str(params.get("url") or ""))) or cj._wa(cj.site_of(str(cj._t(tab).get("url") or ""))):
                    params = dict(params, message="", defaultPrompt="")
            try:                                 # Qosha's own view of the tab first (its address, its dialogs), then the
                _sib("chrome_judge").on_ext_event(self, ev, msg)   # browser tool hears of the move (RELAY-EVENT-ORDER)
            except Exception:
                pass
            for c in list(self.clients.values()):
                await c.tab_event(tab, method, params)
        elif ev in ("stopped",):
            self.stopped = True
            await self._cut("The person pressed Stop.")
        elif ev in ("paused", "person_input", "takeover"):
            self.paused = True
        elif ev == "handover":
            # the person handed this tab to Qosha themselves: that is their OK for its website, in this tab only
            chrome_judge = _sib("chrome_judge")
            site = chrome_judge.site_of(str(msg.get("url") or ""))
            if site and msg.get("tab") is not None:
                chrome_judge._t(str(msg.get("tab"))).setdefault("ok", set()).add(site)
        elif ev == "tab_gone":
            for c in list(self.clients.values()):
                await c.tab_gone(str(msg.get("tab") or ""))
        if ev != "cdp":                          # (a page event was handled above, before it was passed on)
            try:
                chrome_judge = _sib("chrome_judge")
                chrome_judge.on_ext_event(self, ev, msg)
            except Exception:
                pass

    # ---- cutting (fail closed) ------------------------------------------------------------------------------------
    def _changed(self):
        """The link came up or went down: point the engine at the relay or away from it (another thread)."""
        def go():
            try:
                chrome_api = _sib("chrome_api")
                chrome_api.apply_mode()
            except Exception:
                pass
        threading.Thread(target=go, name="qosha-chrome-mode", daemon=True).start()

    async def _cut(self, why: str):
        self._changed()
        self.epoch += 1
        for c in list(self.clients.values()):
            await c.close(why)
        self.clients.clear()
        try:
            chrome_judge = _sib("chrome_judge")
            chrome_judge.void_held(self, why)
        except Exception:
            pass

    def cut(self, why: str):
        if self.loop:
            asyncio.run_coroutine_threadsafe(self._cut(why), self.loop).result(10)

    def control(self, kind: str) -> Dict[str, Any]:
        """stop / resume / work / idle / done / pause, from Qosha (Stop is also the extension's)."""
        if kind == "stop":
            self.stopped = True
            self.cut("The person pressed Stop.")
        elif kind == "resume":
            self.stopped = False
            self.paused = False
        try:
            return self.call_ext("control", kind=kind) or {}
        except Exception as e:
            return {"error": str(e)}

    # ---- the engine's door ---------------------------------------------------------------------------------------
    def _check_path(self, connection, request):
        path = getattr(request, "path", "") or ""
        hdr = getattr(request, "headers", {}) or {}
        host = str(hdr.get("Host") or "")
        # only local programs that know the secret path: no web page (an Origin header), no other host name (DNS
        # rebinding), no other path (council, Gemini R6)
        if (path != "/devtools/browser/" + self.path_secret or hdr.get("Origin") is not None
                or host not in ("127.0.0.1:%d" % self.cdp_port, "localhost:%d" % self.cdp_port)):
            from websockets.http11 import Response
            from websockets.datastructures import Headers
            return Response(404, "Not Found", Headers(), b"")
        return None

    async def _on_cdp(self, ws):
        if not self.connected() or self.stopped:
            await ws.close(1011, "Qosha is not connected to your Chrome" if not self.stopped else "Stopped")
            return
        c = Client(self, ws)
        self.clients[id(c)] = c
        try:
            async for raw in ws:
                try:
                    msg = json.loads(raw)
                except ValueError:
                    continue
                if isinstance(msg, dict):
                    asyncio.ensure_future(c.handle(msg))
        except Exception:
            pass
        finally:
            self.clients.pop(id(c), None)


class RelayError(Exception):
    def __init__(self, code: str, detail: str = ""):
        super().__init__(detail or code)
        self.code, self.detail = code, detail


class Client:
    """One engine connection: virtual browser target + flattened sessions onto Qosha's tabs."""

    def __init__(self, relay: Relay, ws):
        self.r = relay
        self.ws = ws
        self.epoch = relay.epoch
        self.sessions: Dict[str, str] = {}      # sessionId -> tab id
        self.discover = False

    async def send(self, obj):
        try:
            await self.ws.send(json.dumps(obj))
        except Exception:
            pass

    async def close(self, why: str):
        try:
            await self.ws.close(1011, why[:120])
        except Exception:
            pass

    async def tab_event(self, tab: str, method: str, params):
        for sid, t in list(self.sessions.items()):
            if t == tab:
                await self.send({"method": method, "params": params, "sessionId": sid})

    async def tab_gone(self, tab: str):
        for sid, t in list(self.sessions.items()):
            if t == tab:
                self.sessions.pop(sid, None)
                await self.send({"method": "Target.detachedFromTarget", "params": {"sessionId": sid, "targetId": tid(tab)}})
                await self.send({"method": "Target.targetDestroyed", "params": {"targetId": tid(tab)}})

    def _alive(self):
        if self.epoch != self.r.epoch:
            raise RelayError("cut", "Qosha's link to Chrome was reset; nothing from before runs.")
        if self.r.stopped:
            raise RelayError("stopped", "The person pressed Stop. Qosha does nothing in Chrome until they let it continue in the Qosha app.")
        if not self.r.connected():
            raise RelayError("not_connected", "Qosha is not connected to your Chrome.")
        try:                                     # the switch is checked for every command, in whichever Qosha process
            on = _sib("chrome_api").enabled()    # holds the relay: switched off anywhere = nothing runs (MODE-OFF-LIVE-RELAY)
        except Exception:
            on = False
        if not on:
            raise RelayError("off", "\"In your own Chrome\" is switched off (Settings > Browser), so Qosha does nothing in "
                                    "your Chrome.")

    async def handle(self, msg: Dict[str, Any]):
        mid = msg.get("id")
        method = str(msg.get("method") or "")
        params = msg.get("params") if isinstance(msg.get("params"), dict) else {}
        sid = msg.get("sessionId")
        try:
            self._alive()
            if sid:
                res = await self._session_cmd(str(sid), method, params)
            else:
                res = await self._browser_cmd(method, params)
            out = {"id": mid, "result": res if isinstance(res, dict) else {}}
        except RelayError as e:
            out = {"id": mid, "error": {"code": -32000, "message": e.detail or e.code, "data": e.code}}
        except asyncio.TimeoutError:
            out = {"id": mid, "error": {"code": -32000, "message": "Chrome did not answer in time."}}
        if sid:
            out["sessionId"] = sid
        await self.send(out)

    async def _tabs(self):
        return await self.r.ext("list") or []

    async def _browser_cmd(self, method: str, p: Dict[str, Any]):
        if method == "Browser.getVersion":
            ua = str(self.r.ext_info.get("ua") or "")
            prod = next((w for w in ua.split() if w.startswith("Chrome/")), "Chrome")
            return {"protocolVersion": "1.3", "product": prod, "revision": "", "userAgent": ua, "jsVersion": ""}
        if method in ("Browser.setDownloadBehavior", "Target.setAutoAttach"):
            return {}                                   # downloads stay the person's; no automatic attaching
        if method == "Target.setDiscoverTargets":
            self.discover = bool(p.get("discover"))
            if self.discover:
                for t in await self._tabs():
                    await self.send({"method": "Target.targetCreated", "params": {"targetInfo": target_info(t)}})
            return {}
        if method == "Target.getTargets":
            return {"targetInfos": [target_info(t) for t in await self._tabs()]}
        if method == "Target.getTargetInfo":
            want = str(p.get("targetId") or "")
            for t in await self._tabs():
                if tid(t["tab"]) == want:
                    return {"targetInfo": target_info(t)}
            raise RelayError("no_target", "No such tab of Qosha's.")
        if method == "Target.createTarget":
            # a new tab opens blank in Qosha's group; its address then goes through the same judgment as any other
            url = str(p.get("url") or "about:blank")
            front = chrome_judge_mod().front_mode() and not bool(p.get("background"))   # Settings decides (r1 Gemini F7)
            chrome_judge = _sib("chrome_judge")
            verdict = chrome_judge.navigation(self.r, None, url, created=True)
            if verdict:
                raise RelayError("refused", verdict)
            site = chrome_judge.site_of(url) if url not in ("", "about:blank") else ""
            t = await self.r.ext("open", url="about:blank", front=front)
            if site:
                v = await chrome_judge.judge(self.r, str(t["tab"]), "Page.navigate", {"url": url})
                if v[0] == "run":
                    await self.r.ext("cdp", tab=str(t["tab"]), method="Page.navigate", params=v[1])
                    chrome_judge.after(self.r, str(t["tab"]), "Page.navigate", v[1], None)
                elif v[0] in ("hold", "refuse"):
                    raise RelayError("needs_ok" if v[0] == "hold" else "refused",
                                     v[1] + " (A blank tab of Qosha's is open: %s.)" % tid(t["tab"]))
            return {"targetId": tid(t["tab"])}
        if method == "Target.attachToTarget":
            want = str(p.get("targetId") or "")
            for t in await self._tabs():
                if tid(t["tab"]) == want:
                    sid = "QS" + secrets.token_hex(12)
                    self.sessions[sid] = t["tab"]
                    await self.send({"method": "Target.attachedToTarget", "params": {
                        "sessionId": sid, "targetInfo": target_info(t), "waitingForDebugger": False}})
                    return {"sessionId": sid}
            raise RelayError("not_qosha_tab", "That tab is not one of Qosha's.")
        if method == "Target.detachFromTarget":
            self.sessions.pop(str(p.get("sessionId") or ""), None)
            return {}
        if method == "Target.closeTarget":
            tab = untid(str(p.get("targetId") or ""))
            await self.r.ext("close", tab=tab)
            return {"success": True}
        if method == "Target.activateTarget":
            tab = untid(str(p.get("targetId") or ""))
            chrome_judge = _sib("chrome_judge")
            await self.r.ext("activate", tab=tab, front=chrome_judge.front_mode())
            return {}
        raise RelayError("refused", "%s is not available in your own Chrome." % method)

    async def _session_cmd(self, sid: str, method: str, p: Dict[str, Any]):
        tab = self.sessions.get(sid)
        if not tab:
            raise RelayError("no_session", "No such session (the tab closed or Qosha's link was reset).")
        if method.startswith("Target."):
            if method == "Target.getTargetInfo":
                return await self._browser_cmd(method, {"targetId": tid(tab)})
            if method == "Target.setAutoAttach":
                return {}                      # no child targets are attached for Qosha (frames from other sites are refused)
            raise RelayError("refused", "%s is not available in your own Chrome." % method)
        chrome_judge = _sib("chrome_judge")
        lock = self.r.tab_locks.setdefault(tab, asyncio.Lock())
        async with lock:                       # judged and sent one at a time per tab: no race between them (r1 Gemini F5)
            return await self._judged(tab, method, p, chrome_judge)

    async def _judged(self, tab: str, method: str, p: Dict[str, Any], chrome_judge):
        t0 = time.time()
        verdict = await chrome_judge.judge(self.r, tab, method, p)
        if os.environ.get("QOSHA_CHROME_TRACE"):       # test tooling: how long each judgment took
            with open(os.environ["QOSHA_CHROME_TRACE"], "a", encoding="utf-8") as f:
                f.write("%.2f %s %s %s\n" % (time.time() - t0, method, p.get("type", ""), verdict[0]))
        kind = "run" if verdict[0] == "run_always" else verdict[0]
        if kind == "refuse":
            raise RelayError("refused", verdict[1])
        if kind == "hold":
            raise RelayError("needs_ok", verdict[1])
        if kind == "run_noop":
            return {}
        params = verdict[1] if len(verdict) > 1 and isinstance(verdict[1], dict) else p
        self._alive()
        res = chrome_judge.redact(method, await self.r.ext("cdp", tab=tab, method=method, params=params))
        late = chrome_judge.late_refusal(tab, method)
        if late:                               # the tab moved to WhatsApp or a website not allowed while this ran
            raise RelayError("refused", late)
        try:
            chrome_judge.after(self.r, tab, method, params, res)
        except Exception:
            pass
        return res


def chrome_judge_mod():
    return _sib("chrome_judge")


def files_hash(folder=None) -> str:
    """The code digest the extension must report (chrome_setup.code_hash of the files this Qosha ships)."""
    try:
        return _sib("chrome_setup").code_hash(folder)
    except Exception:
        return ""


def tid(tab) -> str:
    return "QOSHATAB%010d" % int(tab)


def untid(t: str) -> str:
    return str(int(t[8:])) if t.startswith("QOSHATAB") and t[8:].isdigit() else "-1"


def target_info(t: Dict[str, Any]) -> Dict[str, Any]:
    cj = chrome_judge_mod()
    wa = cj._wa(cj.site_of(str(t.get("url") or "")))   # a WhatsApp tab's title (unread counts, a chat's name) is not passed on
    return {"targetId": tid(t["tab"]), "type": "page", "title": "" if wa else (t.get("title") or ""), "url": t.get("url") or "",
            "attached": True, "canAccessOpener": False, "browserContextId": "QOSHA"}


_SHARED = sys.__dict__.setdefault("_qosha_chrome_shared", {})
_RELAY_LOCK = _SHARED.setdefault("relay_lock", threading.Lock())


def _own_lock(home: Path) -> bool:
    """Only one Qosha process on this computer serves the relay (the one that runs the person's chats starts first)."""
    try:
        d = home / "qosha"
        d.mkdir(parents=True, exist_ok=True)
        f = open(d / "chrome-relay.lock", "a+")
        if os.name == "nt":
            import msvcrt
            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        _SHARED["lockfile"] = f
        return True
    except OSError:
        return False


def relay(start: bool = True) -> Optional[Relay]:
    with _RELAY_LOCK:
        r = _SHARED.get("relay")
        if r is None and start:
            home = _home()
            if _SHARED.get("lockfile") is not None or _own_lock(home):
                r = _SHARED["relay"] = Relay(home=home).start()
        return r


def set_relay(r: Optional[Relay]) -> None:
    _SHARED["relay"] = r
