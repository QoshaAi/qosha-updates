"""The Python a browser step may run while Qosha works in the person's own Chrome (mc21, review r1 GPT 09).

The engine's browser tool runs the assistant's Python next to Chrome. In the person's Chrome that Python may only call
the browser helpers (every page command they send is judged by the relay) and plain, local Python: no imports beyond
json/re/time/math, no attribute access except a short list of str/list/dict methods and named json/re/time/math
functions, no private or double-underscore names, no other built-ins. Checked on the parse tree, not on spelling;
anything not understood is refused (fail closed).
"""
from __future__ import annotations

import ast
from typing import Optional

HELPERS = {"new_tab", "goto_url", "page_info", "click_at_xy", "type_text", "press_key", "scroll", "capture_screenshot",
           "list_tabs", "current_tab", "switch_tab", "activate_tab", "close_tab", "ensure_real_tab", "wait",
           "wait_for_load", "wait_for_element", "wait_for_network_idle", "js", "cdp"}
BUILTINS = {"print", "len", "range", "str", "int", "float", "bool", "round", "min", "max", "sum", "abs", "sorted",
            "reversed", "list", "dict", "tuple", "set", "enumerate", "zip", "any", "all", "isinstance", "repr", "True",
            "False", "None", "Exception", "ValueError", "KeyError", "IndexError", "TypeError", "RuntimeError"}
MODULES = {
    "json": {"dumps", "loads"},
    "re": {"search", "match", "fullmatch", "findall", "finditer", "sub", "split", "compile", "escape", "IGNORECASE",
           "I", "MULTILINE", "M", "DOTALL", "S"},
    "time": {"sleep", "time", "monotonic"},
    "math": {"floor", "ceil", "sqrt", "inf", "isnan"},
}
METHODS = {"get", "items", "keys", "values", "append", "extend", "insert", "pop", "join", "split", "rsplit", "strip",
           "lstrip", "rstrip", "lower", "upper", "replace", "startswith", "endswith", "find", "count", "format", "update",
           "index", "splitlines", "group", "groups", "title", "capitalize", "setdefault", "copy", "sort", "remove",
           "isdigit", "isalpha"}
_OK_NODES = (ast.Module, ast.Expr, ast.Assign, ast.AugAssign, ast.AnnAssign, ast.If, ast.For, ast.While, ast.Break,
             ast.Continue, ast.Pass, ast.Try, ast.ExceptHandler, ast.Raise, ast.FunctionDef, ast.Return, ast.arguments,
             ast.arg, ast.Call, ast.keyword, ast.Name, ast.Load, ast.Store, ast.Del, ast.Constant, ast.JoinedStr,
             ast.FormattedValue, ast.List, ast.Tuple, ast.Dict, ast.Set, ast.Subscript, ast.Slice, ast.BinOp,
             ast.UnaryOp, ast.BoolOp, ast.Compare, ast.IfExp, ast.ListComp, ast.DictComp, ast.SetComp,
             ast.GeneratorExp, ast.comprehension, ast.Attribute, ast.Starred, ast.Import, ast.ImportFrom, ast.alias,
             ast.Assert, ast.operator, ast.unaryop, ast.boolop, ast.cmpop, ast.expr_context)


def refusal(code: str) -> Optional[str]:
    """None when the code only does what a browser step in the person's Chrome may do; else why not."""
    try:
        tree = ast.parse(str(code or ""))
    except SyntaxError:
        return "it is not valid Python"
    defined = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
            defined.add(node.id)
        elif isinstance(node, ast.FunctionDef):
            defined.add(node.name)
            defined.update(a.arg for a in node.args.args + node.args.kwonlyargs)
        elif isinstance(node, ast.arg):
            defined.add(node.arg)
        elif isinstance(node, ast.ExceptHandler) and node.name:
            defined.add(node.name)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for al in node.names:
                defined.add(al.asname or al.name)
    import builtins as _b
    shadow = (defined & set(dir(_b))) - BUILTINS
    if shadow:                                   # "def f(open): ..." would make a later "open" look local (r2 GPT F1)
        return "it reuses the built-in name %s" % sorted(shadow)[0]
    aliases = {}
    for node in ast.walk(tree):
        if not isinstance(node, _OK_NODES):
            return "it uses %s" % type(node).__name__
        if isinstance(node, ast.Import):
            for al in node.names:
                if al.name not in MODULES:
                    return "it imports %s" % al.name
                aliases[al.asname or al.name] = al.name
        elif isinstance(node, ast.ImportFrom):
            if node.module not in MODULES or node.level:
                return "it imports from %s" % node.module
            for al in node.names:
                if al.name not in MODULES[node.module]:
                    return "it imports %s from %s" % (al.name, node.module)
        elif isinstance(node, ast.Name):
            n = node.id
            if n.startswith("_") and n not in defined:
                return "it uses the name %s" % n
            if isinstance(node.ctx, ast.Load) and n not in defined and n not in HELPERS and n not in BUILTINS \
                    and n not in MODULES:
                return "it uses %s" % n
            if isinstance(node.ctx, ast.Store) and (n in HELPERS or n in MODULES):
                return "it replaces %s" % n
        elif isinstance(node, ast.Attribute):
            if node.attr.startswith("_"):
                return "it reads a private attribute"
            base = node.value
            if isinstance(base, ast.Name) and (base.id in MODULES or base.id in aliases):
                mod = aliases.get(base.id, base.id)
                if node.attr not in MODULES[mod]:
                    return "it uses %s.%s" % (mod, node.attr)
            elif node.attr not in METHODS:
                return "it uses .%s" % node.attr
        elif isinstance(node, ast.Constant) and isinstance(node.value, str) and "__" in node.value and "{" in node.value:
            return "it formats a private attribute"
    return None
