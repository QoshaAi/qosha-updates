"""Qosha's ask-first rule on the person's own computer (Ren, 16-17 Nov 2026).

No built-in walls: the assistant may read and change anything, including its own code, settings and skills, and run
commands, like the engine does. Only an action that SENDS, PAYS, DELETES, SHARES/PUBLISHES or changes a calendar is
put to the person first, through the engine's own approval prompt (Allow once / Always allow / Deny). The rule_key is
the KIND of action, so one "Always allow" covers that whole kind from then on (the engine keeps it in its allowlist;
the person can ask Qosha to undo it, and Qosha can edit that setting itself).
Everything else returns None: the engine's own behavior (including its own dangerous-command prompts) applies.
"""
from __future__ import annotations

import json
import re
from typing import Any, Dict, Optional, Tuple

KIND_TEXT = {
    "email.send": "send an email",
    "message.send": "send a message",
    "calendar.change": "change your calendar",
    "delete": "delete something",
    "pay": "pay, buy or move money",
    "share": "share or publish something",
    "web.post": "send data to a website",
    "web.act": "do a final step on a website (send, buy, delete, confirm, sign in, upload)",
}

# commands, by what they do (checked on the whole command text, case-insensitive)
# A rule must match what the command DOES, never a word that only appears in a file name or in data (Ren, 17 Nov:
# attaching a file and Qosha reading it must never ask). So: programs are matched where a program stands (start of the
# command or after ; & | or sudo/xargs), and payment and mail by their real services and calls, not by plain words.
_AT = r"(?:^|[;&|\n]\s*|\$\(\s*|`\s*)(?:sudo\s+|xargs\s+(?:-\S+\s+)*|env\s+(?:\w+=\S+\s+)*)?"
_CMD_RULES = [
    ("email.send", r"(google_api\.py|\$GAPI|\bgws)\b.*\bgmail\s+(send|reply|forward|drafts?[-_ ]?send|\+send)\b"),
    ("email.send", _AT + r"himalaya\b[^;&|\n]*\b(send|reply|forward)\b"),
    ("email.send", _AT + r"(sendmail|msmtp|mutt|mailx?)\s"),
    ("calendar.change", r"(google_api\.py|\$GAPI|\bgws)\b.*\bcalendar\s+(create|update|delete|add|\+insert|events\s+(insert|patch|update|delete))\b"),
    # deleting something online is a DELETE, not a share (17 Nov: `gh repo delete` was filed as share)
    ("delete", r"(google_api\.py|\$GAPI)\b[^;&|\n]*\bdrive\s+delete\b|"
               + _AT + r"(gh|glab)\s+[a-z-]+\s+delete\b|" + _AT + r"gh\s+api\b[^;&|\n]*(-X\s*|--method[\s=]+)DELETE\b|"
               + _AT + r"git\s+push\b[^;&|\n]*(\s--delete\b|\s-d\b|\s\+?:[^\s;&|]+)"),
    ("share", r"google_api\.py\b.*\bdrive\s+(share|upload)\b"),
    ("share", _AT + r"(git\s+push\b|gh\s+(pr|issue|release|repo|gist)\s+(create|merge|comment|edit)\b|npm\s+publish\b|twine\s+upload\b)"),
    ("pay", r"api\.stripe\.com|" + _AT + r"stripe\s+(charges|payment_intents|payouts|refunds|transfers)\b|api(-m)?\.(sandbox\.)?paypal\.com"),
    ("delete", _AT + r"(rm|rmdir|shred|unlink|trash|del|erase|rd|Remove-Item)(\s|$)|\bfind\b[^;&|\n]*\s-delete\b|"
               + _AT + r"git\s+(clean\b|reset\s+--hard)|\bdrop\s+(table|database)\s|\bdelete\s+from\s"),
    ("web.post", _AT + r"curl\b[^;&|\n]*(\s-X\s*(POST|PUT|PATCH|DELETE)\b|\s(-d|--data\S*|-F|--form)\s)|Invoke-(WebRequest|RestMethod)[^;&|\n]*-Method\s+(Post|Put|Patch|Delete)"),
]
# code the assistant runs (execute_code): by the calls that act, not by words
_CODE_RULES = [
    ("email.send", r"smtplib\.SMTP|\.sendmail\(|\.send_message\("),
    ("delete", r"\bos\.(remove|unlink|rmdir|removedirs)\(|\bshutil\.rmtree\(|\.unlink\(\s*(missing_ok\s*=\s*\w+)?\s*\)|\.rmdir\(\)|\bfs\.(rm|unlink|rmdir)(Sync)?\("),
    ("pay", r"api\.stripe\.com|\bstripe\.(Charge|PaymentIntent|Payout|Refund|Transfer)\b|api(-m)?\.(sandbox\.)?paypal\.com"),
    ("web.post", r"\brequests\.(post|put|patch|delete)\(|\bhttpx\.(post|put|patch|delete)\(|method\s*[:=]\s*[\"'](POST|PUT|PATCH|DELETE)[\"']"),
    ("share", r"subprocess[^\n]*git[\"',\s]+push"),
]

# tool names (MCP and connector tools are named <server>_<action> or similar)
_TOOL_RULES = [
    ("email.send", r"(gmail|mail|email|outlook).*(send|reply|forward)|(send|reply|forward).*(mail|email)"),
    ("calendar.change", r"(calendar|event).*(create|update|delete|insert|patch|move)|(create|update|delete).*(event|calendar)"),
    ("pay", r"pay|checkout|purchase|charge|refund|transfer|invoice_send|buy"),
    ("delete", r"delete|remove|trash|destroy|purge|erase"),
    ("share", r"share|publish|(^|_)post|tweet|upload|invite|permission"),
    ("message.send", r"(^|_)send|message_create|chat_post|reply"),
]
# engine tools that never send/pay/delete on their own (reads, notes, its own UI)
_QUIET = {"read_file", "search_files", "web_search", "web_extract", "vision_analyze", "video_analyze", "skill_view",
          "skills_list", "todo", "todo_list", "memory", "session_search", "clarify", "browser_navigate",
          "browser_snapshot", "browser_scroll", "browser_back", "browser_close", "browser_vision", "set_theme",
          "delegate_task", "write_file", "image_generate", "text_to_speech", "tool_search"}


def _text(v: Any, n: int = 500) -> str:
    s = v if isinstance(v, str) else json.dumps(v, ensure_ascii=False, default=str)
    return s if len(s) <= n else s[:n] + " ..."


def kind_of(tool: str, args: Any, task_id: str = "") -> Optional[Tuple[str, str]]:
    """(kind, what to show the person), or None when the call just runs. A shell step that only deletes things that
    are already gone is None too (pre_tool_call then stops it with a plain note: there is nothing to ask about)."""
    tool = (tool or "").strip()
    a = args if isinstance(args, dict) else {}
    # engine v0.22+: rarely used tools (MCP tools among them) are called through the "tool_call" meta-tool; the hook
    # then sees tool_call, so the real tool and its arguments are judged
    for _ in range(3):
        if tool != "tool_call":
            break
        inner = a.get("arguments") if isinstance(a.get("arguments"), dict) else {}
        if isinstance(a.get("arguments"), str):
            try:
                inner = json.loads(a["arguments"])
            except Exception:
                inner = {}
        tool, a = str(a.get("name") or "").strip(), inner if isinstance(inner, dict) else {}
    if tool in ("terminal", "execute_code", "process", "process_manage"):
        text = str(a.get("command") or a.get("code") or a.get("input") or "")
        rules = _CODE_RULES if tool == "execute_code" else _CMD_RULES
        for kind, rx in rules:
            if re.search(rx, text, re.I | re.M):
                if kind == "delete" and _deletes_only_gone(tool, a, task_id):
                    continue   # what it would delete is not there: no card (17 Nov)
                return kind, _text(text)
        return None
    if tool == "browser_exec":
        # the engine's browser runs Python helpers; reading and moving between pages never asks, acting on a page does
        code = str(a.get("code") or "")
        return ("web.act", _text(code)) if web_plain(code)[3] else None
    if tool == "browser_cdp":
        # raw browser commands: a mouse press, the Enter key or a file given to the page cannot be told apart from a
        # final step, so they ask; everything else (reading, moving about) runs
        method = str(a.get("method") or "")
        params = a.get("params") if isinstance(a.get("params"), dict) else {}
        pseudo = 'cdp("%s", key="%s")' % (method, str(params.get("key") or "")) if re.fullmatch(r"[A-Za-z.]{1,60}", method) else ""
        if pseudo and re.search(r"Input\.dispatchMouseEvent|DOM\.setFileInputFiles", method) and str(params.get("type") or "mousePressed") in ("mousePressed", "", "mouseReleased"):
            return "web.act", pseudo
        if pseudo and method == "Input.dispatchKeyEvent" and str(params.get("key") or "") in ("Enter", "Return", "NumpadEnter") and str(params.get("type") or "") in ("keyDown", "rawKeyDown", ""):
            return "web.act", pseudo
        return None
    if tool == "patch" and re.search(r"^\*\*\* Delete File:", str(a.get("patch") or ""), re.M):
        return None if _deletes_only_gone(tool, a, task_id) else ("delete", _text(a.get("patch")))
    if tool == "send_message":
        if str(a.get("action") or "send").lower() in ("list", "targets"):
            return None
        return "message.send", "to %s: %s" % (a.get("target") or "?", _text(a.get("message") or a))
    if tool in _QUIET:
        return None
    low = tool.lower()
    # the engine names MCP tools mcp__<server>__<tool>
    base = low.rsplit("__", 1)[-1] if low.startswith("mcp__") else low
    act = str(a.get("action") or a.get("operation") or a.get("op") or "").lower()
    # Google Workspace MCP (and similar): reads never ask; actions are judged by what they do
    if re.match(r"^(get|list|search|read|check|query|find|fetch|describe)_", base):
        return None
    if act in ("delete", "remove", "trash", "clear", "destroy", "batch_delete"):
        return "delete", "%s %s" % (tool, _text(a))
    if re.search(r"(^|_)(manage_)?event", base) and act in ("create", "update", "rsvp", "respond", "move", "patch", "insert", "quick_add"):
        return "calendar.change", "%s %s" % (tool, _text(a))
    if re.search(r"access|permission|shar", base):
        return "share", "%s %s" % (tool, _text(a))
    if base.startswith("draft_"):
        return None
    for kind, rx in _TOOL_RULES:
        if re.search(rx, base):
            return kind, "%s %s" % (tool, _text(a))
    return None


def _flag_args(text: str) -> Dict[str, str]:
    """--to X --subject "Y" ... from a command line (the Google skill's script); {} when it can't be read."""
    import shlex
    try:
        words = shlex.split(text)
    except ValueError:
        return {}
    out, i = {}, 0
    while i < len(words):
        w = words[i]
        if w.startswith("--") and len(w) > 2:
            if "=" in w:
                k, v = w[2:].split("=", 1)
                out[k] = v
            elif i + 1 < len(words) and not words[i + 1].startswith("--"):
                out[w[2:]] = words[i + 1]
                i += 1
            else:
                out[w[2:]] = "yes"
        i += 1
    return out


def _unwrap(tool: str, a: Dict[str, Any]):
    for _ in range(3):
        if tool != "tool_call":
            break
        inner = a.get("arguments")
        if isinstance(inner, str):
            try:
                inner = json.loads(inner)
            except Exception:
                inner = {}
        tool, a = str(a.get("name") or "").strip(), inner if isinstance(inner, dict) else {}
    return tool, a


def rows_for(kind: str, tool: str, args: Any, what: str, task_id: str = "") -> list:
    """What the person sees on the card, as labelled rows (like the cloud Decision card): [(label, value), ...].
    Plain words only (Ren, 17 Nov): never a command line, code, a flag or a script."""
    tool, a = _unwrap((tool or "").strip(), args if isinstance(args, dict) else {})
    cmd = str(a.get("command") or a.get("code") or "")
    f = _flag_args(cmd) if tool in ("terminal", "execute_code") else {}
    g = lambda *ks: next((str(v) for v in ((a.get(k) if a.get(k) not in (None, "", [], {}) else f.get(k)) for k in ks) if v not in (None, "")), "")
    rows = []
    add = lambda k, v: rows.append((k, _text(v, 1500))) if v not in (None, "", [], {}) else None
    if kind in ("email.send", "message.send"):
        add("To", g("to", "target", "recipient", "recipients"))
        add("Cc", g("cc")); add("Bcc", g("bcc"))
        add("From", g("from", "from_email"))
        add("Subject", g("subject"))
        add("Body", g("body", "message", "text", "html_body"))
        add("Reply to message", g("thread_id", "in_reply_to", "message_id"))
        add("Attachments", g("attachments", "attach"))
        if not rows:
            add("What happens", "Send %s (Qosha could not read who it goes to from this step)" % ("an email" if kind == "email.send" else "a message"))
    elif kind == "calendar.change":
        ch = (g("action") or (re.search(r"calendar\s+(?:events\s+)?\+?(\w+)", cmd) or [0, ""])[1]).lower()
        add("Change", {"create": "Add an event", "insert": "Add an event", "add": "Add an event", "quick_add": "Add an event",
                       "update": "Change an event", "patch": "Change an event", "move": "Move an event",
                       "delete": "Delete an event", "rsvp": "Answer an invitation", "respond": "Answer an invitation"}.get(ch, "Change your calendar"))
        add("Event", g("summary", "title", "event_id"))
        add("Answer", g("response", "rsvp"))
        add("When", " to ".join(x for x in (g("start", "start_time"), g("end", "end_time")) if x))
        add("Where", g("location"))
        add("Guests", g("attendees"))
        add("Calendar", g("calendar_id", "calendar"))
    elif kind in ("delete", "share", "pay"):
        steps, gone, notes = plain_acts(kind, tool, a, task_id)
        if not steps:
            steps = [_not_understood(kind, tool)]
        if len(steps) > 1:
            add("Steps", "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(steps[:12])))
        else:
            add("What happens", steps[0])
        add("Already gone", ", ".join(gone[:12]) + (" and %d more" % (len(gone) - 12) if len(gone) > 12 else ""))
        add("Note from Qosha", " ".join(notes))
    elif kind in ("web.act", "web.post"):
        # plain words only (Ren, 17 Nov): the person never sees the browser code, a selector or a command
        site, steps, note, _final = web_plain(cmd or what, kind)
        add("Website", site)
        add("Note from Qosha", note)
        add("Steps" if len(steps) > 1 else "What happens", "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(steps)) if len(steps) > 1 else steps[0])
    if not rows:
        add("What happens", _not_understood(kind, tool))
    return rows   # the command or code itself is never added (Ren, 17 Nov)


# ---- delete / share / pay in plain words (Ren, 17 Nov: the card says what will happen; a command is never shown) ----
# Seen on Ren's Mac: a delete card showed `rm "/Users/.../Qosha-Setup.exe"`, a share card a long script. Each step is
# now read like the person would say it: what, which file or folder (by name) and where. What cannot be read is said
# so plainly ("Qosha could not ..."), and the person is still asked. Nothing here runs anything; files are only looked at.
_ZERO_DEC = {"bif", "clp", "djf", "gnf", "jpy", "kmf", "krw", "mga", "pyg", "rwf", "ugx", "vnd", "vuv", "xaf", "xof", "xpf"}
_ROLE = {"reader": "can view", "viewer": "can view", "commenter": "can comment", "writer": "can edit", "editor": "can edit",
         "fileorganizer": "can organize", "organizer": "can organize", "owner": "as the new owner"}
_KNOWN_DIRS = {"downloads": "in Downloads", "desktop": "on the Desktop", "documents": "in Documents", "pictures": "in Pictures",
               "movies": "in Movies", "videos": "in Videos", "music": "in Music", "onedrive": "in OneDrive"}
_SCRATCH = {"cache", "tmp", "temp", "scratch", "sandboxes", "audio_cache", "image_cache", "pending", "attachments", "composer-pastes"}
_DEL_CMDS = {"rm", "unlink", "del", "erase", "remove-item", "ri", "rd", "rmdir", "shred", "trash", "srm"}


def _homes() -> Tuple[str, str]:
    import os
    home = os.path.expanduser("~")
    try:
        from hermes_constants import get_hermes_home
        qh = str(get_hermes_home())
    except Exception:
        qh = os.environ.get("HERMES_HOME") or ""
    return home, qh


def _real(p: str) -> str:
    import os
    try:
        return os.path.normcase(os.path.realpath(p))
    except Exception:
        return os.path.normcase(os.path.abspath(p))


def _under(p: str, root: str) -> bool:
    import os
    if not root:
        return False
    rp, rr = _real(p), _real(root)
    return rp == rr or rp.startswith(rr.rstrip(os.sep) + os.sep)


def _label(folder: str) -> str:
    """A folder as the person knows it: "Downloads", "Your files", "your home folder", or its own name."""
    import os
    home, qh = _homes()
    if qh and _real(folder) == _real(os.path.join(qh, "files")):
        return "Your files"
    if _real(folder) == _real(home):
        return "your home folder"
    if _under(folder, home) and _real(os.path.dirname(folder.rstrip("/\\"))) == _real(home) and os.path.basename(folder.rstrip("/\\")).lower() in _KNOWN_DIRS:
        return os.path.basename(folder.rstrip("/\\"))
    return os.path.basename(folder.rstrip("/\\")) or folder


def _where(path: str) -> str:
    """Where a file or folder lies, in a few words: "in Downloads", "in Qosha's scratch folder", ..."""
    import os
    import tempfile
    parent = os.path.dirname(path.rstrip("/\\")) or path
    home, qh = _homes()
    if qh and _under(parent, qh):
        rel = os.path.relpath(_real(parent), _real(qh))
        top = rel.split(os.sep)[0].lower() if rel != "." else ""
        if top == "files":
            return "in Your files" if rel == "files" else "in the folder %s (in Your files)" % os.path.basename(parent)
        return "in Qosha's scratch folder" if top in _SCRATCH else "in Qosha's own folder"
    if _under(parent, home):
        rel = os.path.relpath(_real(parent), _real(home))
        if rel == ".":
            return "in your home folder"
        parts = rel.split(os.sep)
        top = parts[0].lower()
        if top in _KNOWN_DIRS:
            return _KNOWN_DIRS[top] if len(parts) == 1 else "in the folder %s (%s)" % (os.path.basename(parent), _KNOWN_DIRS[top])
        return "in the folder %s (in your home folder)" % os.path.basename(parent)
    if any(_under(parent, t) for t in {tempfile.gettempdir(), "/tmp", "/var/tmp", "/private/tmp"}):
        return "in the computer's temporary folder"
    return ("in the folder %s" % os.path.basename(parent)) if os.path.basename(parent) else "at the top of the disk"


def _count_files(folder: str, cap: int = 5000) -> int:
    import os
    n = 0
    for _r, _d, fs in os.walk(folder):
        n += len(fs)
        if n > cap:
            break
    return n


def _expand(t: str, cwd: str) -> Tuple[Optional[str], str]:
    """(full path or None when it cannot be known before the step runs, why). Only the home and temp folder names are
    filled in; any other $NAME, %NAME% or `...` is only known when the step runs."""
    import os
    import tempfile
    home = os.path.expanduser("~")
    s = t
    s = re.sub(r"^~(?=$|[/\\])", lambda m: home, s)
    s = re.sub(r"\$\{?HOME\}?|%USERPROFILE%|\$env:(USERPROFILE|HOME)", lambda m: home, s, flags=re.I)
    s = re.sub(r"\$\{?TMPDIR\}?|%TEMP%|%TMP%|\$env:(TEMP|TMP)", lambda m: tempfile.gettempdir(), s, flags=re.I)
    if re.search(r"[$`]|%\w+%", s):
        return None, "unknown"
    if re.match(r"^[A-Za-z]:[\\/]", s) and os.name != "nt":
        return None, "windows"          # a Windows path seen on a Mac: its name is known, the file cannot be looked at
    if not os.path.isabs(s):
        if not cwd:
            return None, "relative"
        s = os.path.join(cwd, s)
    return os.path.normpath(s), ""


def _cwd(a: Dict[str, Any], task_id: str = "") -> str:
    """The folder a shell step runs in, as the engine picks it (its workdir, the session's folder, its setting)."""
    import os
    w = str(a.get("workdir") or a.get("cwd") or "")
    if w:
        p, _why = _expand(w, "")
        if p:
            return p
    try:
        from tools.terminal_tool import get_session_cwd, resolve_task_overrides
        for c in ((resolve_task_overrides(task_id) or {}).get("cwd") if task_id else None, get_session_cwd(task_id) if task_id else None):
            if c and os.path.isabs(str(c)):
                return str(c)
    except Exception:
        pass
    try:
        from hermes_cli.config import load_config
        c = str(((load_config() or {}).get("terminal") or {}).get("cwd") or "")
        if c and os.path.isabs(c) and os.path.isdir(c):
            return c
    except Exception:
        pass
    return ""


def _segments(cmd: str) -> Optional[list]:
    """The simple commands of a shell text, as word lists, in order (quotes respected). None if it cannot be read."""
    import os
    import shlex
    win = os.name == "nt" or bool(re.search(r"(?<![\w$])[A-Za-z]:\\", cmd))
    text, out_q, i = [], None, 0
    while i < len(cmd):            # line breaks outside quotes end a command, like ;
        c = cmd[i]
        if c == "\\" and not win and i + 1 < len(cmd):
            text.append(" " if cmd[i + 1] == "\n" else c + cmd[i + 1])
            i += 2
            continue
        if out_q:
            out_q = None if c == out_q else out_q
        elif c in "'\"":
            out_q = c
        elif c == "\n":
            c = " ; "
        elif c == "#" and (not text or text[-1][-1:] in (" ", "\t", ";")):
            j = cmd.find("\n", i)       # a comment: to the end of the line
            i = len(cmd) if j < 0 else j
            continue
        text.append(c)
        i += 1
    try:
        lex = shlex.shlex("".join(text), posix=not win, punctuation_chars=";&|")
        lex.whitespace_split = True
        lex.commenters = ""
        toks = list(lex)
    except ValueError:
        return None
    segs, cur = [], []
    for t in toks:
        if t and set(t) <= set(";&|"):
            if cur:
                segs.append((cur, t))
            cur = []
            continue
        if win and len(t) >= 2 and t[0] == t[-1] and t[0] in "'\"":
            t = t[1:-1]
        cur.append(t)
    if cur:
        segs.append((cur, ""))
    # the separator BEFORE each command matters for "xargs" (its names come from the command before the pipe)
    return [(w, (segs[k - 1][1] if k else "")) for k, (w, _sep) in enumerate(segs)]


def _strip_prefix(w: list) -> Tuple[list, bool]:
    """sudo / env / nohup / time / VAR=value in front of a command are not the command; xargs reads its names from the
    command before it."""
    xargs = False
    while w:
        h = w[0].lower()
        if h in ("sudo", "nohup", "time", "command", "exec", "builtin", "nice"):
            w = w[1:]
            while w and w[0].startswith("-"):
                w = w[1:]
        elif h == "env" or re.fullmatch(r"[A-Za-z_]\w*=.*", w[0]):
            w = w[1:]
            while w and (re.fullmatch(r"[A-Za-z_]\w*=.*", w[0]) or w[0].startswith("-")):
                w = w[1:]
        elif h == "xargs":
            xargs = True
            w = w[1:]
            while w and w[0].startswith("-"):
                w = w[1:]
        else:
            break
    return w, xargs


def _item(t: str, cwd: str) -> Dict[str, Any]:
    """One named target: its name, where it is, whether it is there (True/False/None = cannot tell) and a folder."""
    import ntpath
    import os
    p, why = _expand(t, cwd)
    if p is None:
        name = ntpath.basename(t.rstrip("/\\")) if why == "windows" else os.path.basename(t.rstrip("/\\"))
        where = ""
        if why == "windows":
            par = ntpath.basename(ntpath.dirname(t.rstrip("/\\")))
            where = "in the folder %s" % par if par else ""
        elif why == "relative":
            where = "in the folder Qosha is working in"
        return {"name": name, "where": where, "exists": None, "dir": None, "unknown": why == "unknown", "path": ""}
    there = os.path.lexists(p)
    return {"name": os.path.basename(p.rstrip("/\\")) or p, "where": _where(p), "exists": there,
            "dir": os.path.isdir(p) if there else None, "unknown": False, "path": p}


def _thing_word(it: Dict[str, Any]) -> str:
    if it["dir"]:
        return "folder"
    if it["dir"] is False:
        return "file"
    return "file" if re.search(r"\.\w{1,8}$", it["name"]) else "item"


def _names(items: list, n: int = 6) -> str:
    names = [i["name"] for i in items]
    return ", ".join(names[:n]) + (" and %d more" % (len(names) - n) if len(names) > n else "")


def _delete_sentences(verb: str, items: list, recursive: bool) -> list:
    """Sentences for one delete command's targets (items that are there, or that cannot be checked)."""
    out = []
    files = [i for i in items if _thing_word(i) == "file"]
    same_where = len({i["where"] for i in items}) == 1
    if len(items) > 1 and len(files) == len(items) and same_where and verb in ("delete", "trash"):
        w = items[0]["where"]
        if verb == "trash":
            return ["Move %d files %s to the Trash: %s" % (len(items), w, _names(items))]
        return ["Delete %d files %s: %s" % (len(items), w, _names(items))]
    import os
    home, qh = _homes()
    for i in items:
        kindw, where = _thing_word(i), i["where"]
        if i["path"] and i["exists"]:
            special = ("everything on the computer's disk" if os.path.dirname(i["path"].rstrip("/\\") or i["path"]) == (i["path"].rstrip("/\\") or i["path"]) or _real(i["path"]) in ("/", _real("/")) else
                       "your whole home folder" if _real(i["path"]) == _real(home) else
                       "Qosha's whole home folder (its chats, settings and sign-ins)" if qh and _real(i["path"]) == _real(qh) else "")
            if special:
                out.append(("Move %s to the Trash" if verb == "trash" else "Delete %s") % special)
                continue
        par = " (%s)" % where if where else ""
        if verb == "trash":
            out.append("Move the %s %s%s to the Trash" % (kindw, i["name"], par))
        elif verb == "shred":
            out.append("Destroy the file %s%s so it cannot be recovered" % (i["name"], par))
        elif kindw == "folder" and verb == "rmdir":
            out.append("Delete the empty folder %s%s" % (i["name"], par))
        elif kindw == "folder" and (recursive or verb == "tree"):
            n = _count_files(i["path"]) if i["path"] and i["exists"] else -1
            size = "" if n < 0 else ("it is empty, " if n == 0 else ("more than 5000 files, " if n > 5000 else "%d file%s, " % (n, "" if n == 1 else "s")))
            out.append("Delete the folder %s and everything in it (%s%s)" % (i["name"], size, where) if where or size else
                       "Delete the folder %s and everything in it" % i["name"])
        else:
            out.append("Delete the %s %s%s" % (kindw, i["name"], par))
    return out


def _seg_delete(w: list, xargs: bool, cwd: str, trust: bool = True) -> Optional[Tuple[list, list, bool]]:
    """(sentences, names already gone, could not check something) for a delete command; None if it is not one.
    trust=False: an earlier part of the same step may create or move things, so "not there now" proves nothing: such
    names are asked about like any other."""
    import glob
    import os
    head = w[0].lower() if w else ""
    head = head[:-4] if head.endswith(".exe") else head
    if head not in _DEL_CMDS:
        return None
    win_style = head in ("del", "erase", "rd") or os.name == "nt"
    recursive, targets, value_next, after_dd = False, [], None, False
    verb = {"shred": "shred", "srm": "shred", "trash": "trash", "rmdir": "rmdir", "rd": "rmdir"}.get(head, "delete")
    for t in w[1:]:
        if re.fullmatch(r"\d*[<>]{1,2}&?", t):      # a redirection: the next word is where output goes, not a target
            value_next = "redirect"
            continue
        if re.match(r"\d*[<>]", t):
            continue
        if value_next:
            if value_next in ("-path", "-literalpath"):
                targets.append(t)
            value_next = None
            continue
        low = t.lower()
        if not after_dd and t == "--":
            after_dd = True
            continue
        if not after_dd and low in ("-path", "-literalpath", "-include", "-exclude", "-filter"):
            value_next = low
            continue
        if not after_dd and win_style and re.fullmatch(r"/[a-z]", low):
            recursive = recursive or low == "/s"
            continue
        if not after_dd and t.startswith("-") and len(t) > 1:
            # rm -r / -rf / -R / --recursive; PowerShell -Recurse (and its short forms). -Force is not recursive.
            if low in ("--recursive", "-recurse", "-recurs", "-recur", "-recu", "-rec") or (head in ("rm", "srm") and re.fullmatch(r"-[a-z]{1,4}", low) and "r" in low):
                recursive = True
            continue
        targets.append(t)
    if recursive and verb == "rmdir":
        verb = "tree"
    if xargs:
        return ["Delete files listed by an earlier part of the step (Qosha could not list them in advance)"], [], True
    items, gone, unknown = [], [], False
    for t in targets:
        if re.search(r"[*?\[]", t):
            p, why = _expand(t, cwd)
            if p is None:
                unknown = True
                continue
            hits = sorted(glob.glob(p))
            if not hits and trust:
                gone.append(os.path.basename(p))
            elif not hits:
                items.append({"name": os.path.basename(p), "where": _where(p), "exists": None, "dir": None, "unknown": False, "path": ""})
            items += [_item(h, "") for h in hits]
            continue
        it = _item(t, cwd)
        if it["unknown"]:
            unknown = True
        elif it["exists"] is False and trust:
            gone.append(it["name"])
        else:
            if it["exists"] is False:
                it.update(exists=None, dir=None, path="")
            items.append(it)
    out = _delete_sentences(verb if verb != "tree" else "delete", items, recursive or verb == "tree")
    if unknown:
        out.append("Delete something whose name is only known when the step runs (Qosha could not check it)")
    if not targets and not xargs:
        out.append("Delete something on this computer (Qosha could not tell what)")
        unknown = True
    cannot_check = unknown or any(i["exists"] is None for i in items)
    return out, gone, cannot_check


def _gapi(w: list) -> Optional[Tuple[str, list, Dict[str, str], list]]:
    """The Google skill's script: (service, action words, --flags, plain words after the action)."""
    for k, t in enumerate(w):
        if t.endswith("google_api.py") or t in ("$GAPI", "${GAPI}"):
            rest = w[k + 1:]
            if len(rest) < 2:
                return None
            flags = _flag_args(" ".join(_q(x) for x in rest))
            pos, skip = [], False
            for x in rest[2:]:
                if skip:
                    skip = False
                    continue
                if x.startswith("--"):
                    skip = "=" not in x
                    continue
                pos.append(x)
            return rest[0].lower(), [rest[1].lower()], flags, pos
    return None


def _q(s: str) -> str:
    import shlex
    return shlex.quote(s)


def _gh_thing(noun: str, arg: str, host: str) -> str:
    names = {"release": "the release %s", "gist": "the gist %s", "issue": "issue %s", "label": "the label %s",
             "secret": "the secret %s", "variable": "the setting %s", "run": "the workflow run %s", "cache": "the saved cache %s",
             "ssh-key": "the key %s", "gpg-key": "the key %s", "codespace": "the codespace %s", "project": "the project %s",
             "ruleset": "the rule set %s", "environment": "the environment %s", "snippet": "the snippet %s", "mr": "merge request %s",
             "deploy-key": "the key %s"}
    return (names.get(noun, "the " + noun.replace("-", " ") + " %s") % arg).strip() + " on " + host


def _money(amount: str, currency: str) -> str:
    cur = (currency or "").lower()
    try:
        n = int(str(amount).strip())
    except ValueError:
        return ""
    if cur in _ZERO_DEC:
        return "%d %s" % (n, cur.upper())
    v = "%d.%02d" % (n // 100, n % 100)
    return "%s %s" % (v, cur.upper()) if cur else "%s in the account's currency" % v


def _stripe(obj: str, data: Dict[str, str]) -> str:
    obj = obj.lower().replace("-", "_")
    amt = _money(data.get("amount", ""), data.get("currency", "")) if data.get("amount") else ""
    who = data.get("destination") or data.get("customer") or data.get("receipt_email") or ""
    if obj.startswith("transfer"):
        return ("Send %s to %s (Stripe)" % (amt, who) if who else "Send %s (Stripe)" % amt) if amt else "Send money through Stripe (Qosha could not tell the amount or who gets it)"
    if obj.startswith("refund"):
        return "Refund %s (Stripe)" % amt if amt else "Make a refund through Stripe (Qosha could not tell the amount)"
    if obj.startswith("payout"):
        return "Pay out %s to the bank account (Stripe)" % amt if amt else "Make a payout through Stripe (Qosha could not tell the amount or who gets it)"
    if obj.startswith("charge") or obj.startswith("payment_intent"):
        return ("Charge %s to %s (Stripe)" % (amt, who) if who else "Charge %s (Stripe)" % amt) if amt else "Take a payment through Stripe (Qosha could not tell the amount or from whom)"
    return "Make a payment through Stripe (Qosha could not tell the amount or who gets it)"


def _curl_parts(w: list) -> Tuple[str, Dict[str, str], str]:
    """(address, form fields, raw body) of a curl command."""
    url, data, raw, nxt = "", {}, "", None
    for t in w[1:]:
        if nxt:
            if nxt == "data":
                if t.lstrip().startswith("{"):
                    raw += t
                else:
                    for kv in t.split("&"):
                        if "=" in kv:
                            k, v = kv.split("=", 1)
                            data[k.strip()] = v.strip()
            nxt = None
            continue
        if t in ("-d", "--data", "--data-raw", "--data-urlencode", "--data-binary", "-F", "--form"):
            nxt = "data"
        elif t.startswith("-") and t in ("-u", "-H", "-X", "--user", "--header", "--request", "-o", "--output", "-A", "-e"):
            nxt = "skip"
        elif re.match(r"https?://", t) and not url:
            url = t
    return url, data, raw


def _paypal(raw: str) -> str:
    try:
        body = json.loads(raw)
    except Exception:
        body = None
    amt, who = "", ""

    def walk(x):
        nonlocal amt, who
        if isinstance(x, dict):
            if "value" in x and "currency_code" in x and not amt:
                amt = "%s %s" % (x["value"], str(x["currency_code"]).upper())
            for k in ("email_address", "receiver", "email"):
                if isinstance(x.get(k), str) and not who:
                    who = x[k]
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
    walk(body)
    if amt:
        return "Pay %s to %s (PayPal)" % (amt, who) if who else "Pay %s (PayPal)" % amt
    return "Make a payment through PayPal (Qosha could not tell the amount or who gets it)"


def _shell_acts(cmd: str, cwd: str, trust: bool = True) -> Tuple[list, list, bool, bool]:
    """(acts as (kind, sentence), names already gone, something could not be checked, every command is a delete or a
    change of folder) for a shell text. Commands that only read or prepare are left out: the card is about what acts."""
    import os
    segs = _segments(cmd)
    if segs is None:
        return [], [], True, False
    acts, gone, unknown, only_del = [], [], False, trust
    for words, sep in segs:
        w, xargs = _strip_prefix(list(words))
        # (xargs: its names come from elsewhere; never checked)
        if not w:
            continue
        h = w[0].lower()
        if h in ("bash", "sh", "zsh") and len(w) >= 3 and w[1] == "-c":
            a2, g2, u2, o2 = _shell_acts(w[2], cwd, only_del)
            acts += a2
            gone += g2
            unknown = unknown or u2
            only_del = only_del and o2
            continue
        if h in ("cd", "pushd", "set-location", "sl", "chdir"):
            dest = next((x for x in w[1:] if not re.fullmatch(r"/d|-\w+", x, re.I)), "~")
            p, _why = _expand(dest, cwd)
            cwd = p if p else ""
            continue
        d = _seg_delete(w, xargs, cwd, trust=only_del)
        if d is not None:
            acts += [("delete", s) for s in d[0]]
            gone += d[1]
            unknown = unknown or d[2]
            continue
        only_del = False
        g = _gapi(w)
        if g:
            svc, (act,), fl, pos = g
            if svc == "drive" and act == "delete":
                acts.append(("delete", "Delete a file in your Google Drive for good" if "permanent" in fl else "Move a file in your Google Drive to its trash"))
            elif svc == "drive" and act == "upload":
                it = _item(pos[0], cwd) if pos else None
                where = (" (%s)" % it["where"]) if it and it["where"] else ""
                name = it["name"] if it else "a file"
                as_name = fl.get("name") if fl.get("name") and it and fl.get("name") != it["name"] else ""
                acts.append(("share", "Upload the file %s%s to your Google Drive%s" % (name, where, (" as %s" % as_name) if as_name else "") if it else "Upload a file to your Google Drive"))
            elif svc == "drive" and act == "share":
                typ = (fl.get("type") or "user").lower()
                who = {"anyone": "anyone who has the link", "domain": "everyone at %s" % fl.get("domain", "a domain")}.get(typ, fl.get("email") or "someone Qosha could not read")
                acts.append(("share", "Share a Google Drive file with %s (%s)" % (who, _ROLE.get((fl.get("role") or "reader").lower(), "access: " + fl.get("role", "")))))
            elif svc == "gmail" and act in ("send", "reply", "forward"):
                acts.append(("email.send", "Send an email%s%s" % ((" to " + fl["to"]) if fl.get("to") else "", (": “%s”" % _say(fl["subject"])) if fl.get("subject") else "")))
            elif svc == "calendar" and act in ("create", "update", "delete"):
                acts.append(("calendar.change", {"create": "Add the event", "update": "Change the event", "delete": "Delete an event"}[act] + ((" “%s”" % _say(fl["summary"])) if fl.get("summary") else "")))
            continue
        if h in ("gh", "glab") and len(w) >= 3:
            host = "GitHub" if h == "gh" else "GitLab"
            noun, verb = w[1].lower(), w[2].lower()
            fl = _flag_args(" ".join(_q(x) for x in w[3:]))
            pos = [x for x in w[3:] if not x.startswith("-")]
            arg = pos[0] if pos else ""
            title = fl.get("title") or fl.get("t") or ""
            if noun == "api":
                if re.search(r"(-X\s*|--method[\s=]+)DELETE\b", " ".join(w), re.I):
                    acts.append(("delete", "Delete something on %s (Qosha could not tell exactly what)" % host))
                continue
            if verb == "delete":
                if noun == "repo":
                    acts.append(("delete", ("Delete the %s repository %s and everything in it" % (host, arg)) if arg else "Delete this project's %s repository and everything in it" % host))
                else:
                    acts.append(("delete", "Delete " + _gh_thing(noun, arg, host)))
            elif noun in ("pr", "mr") and verb == "create":
                acts.append(("share", "Propose code changes on %s: “%s”" % (host, _say(title)) if title else "Propose code changes on %s (a pull request)" % host))
            elif noun == "issue" and verb == "create":
                acts.append(("share", "Post a new issue on %s: “%s”" % (host, _say(title)) if title else "Post a new issue on %s" % host))
            elif noun == "release" and verb == "create":
                acts.append(("share", "Publish the release %s on %s" % (arg, host) if arg else "Publish a release on %s" % host))
            elif noun == "repo" and verb == "create":
                vis = " (public: anyone can see it)" if "public" in fl else " (private)" if "private" in fl else ""
                acts.append(("share", ("Create the %s repository %s%s" % (host, arg, vis)) if arg else "Create a %s repository%s" % (host, vis)))
            elif noun == "gist" and verb == "create":
                acts.append(("share", "Publish a snippet on %s (%s)" % (host, "public: anyone can see it" if "public" in fl or "p" in fl else "anyone with the link can see it")))
            elif verb == "merge":
                acts.append(("share", "Merge the pull request %s on %s" % (arg, host) if arg else "Merge a pull request on %s" % host))
            elif verb == "comment":
                body = fl.get("body") or fl.get("b") or ""
                acts.append(("share", "Post a comment on %s: “%s”" % (host, _say(body)) if body else "Post a comment on %s" % host))
            elif verb == "edit":
                acts.append(("share", "Change %s %s on %s" % ({"pr": "the pull request", "issue": "issue", "release": "the release", "repo": "the repository settings of", "gist": "the gist"}.get(noun, "the " + noun), arg, host)))
            continue
        if h == "git":
            k, proj = 1, _label(cwd) if cwd else "this project"
            while k < len(w) and w[k].startswith("-"):
                if w[k] == "-C" and k + 1 < len(w):
                    p, _why = _expand(w[k + 1], cwd)
                    proj = _label(p) if p else os.path.basename(w[k + 1].rstrip("/\\"))
                    k += 1
                k += 1
            sub = w[k].lower() if k < len(w) else ""
            rest = w[k + 1:]
            if sub == "push":
                pos = [x for x in rest if not x.startswith("-")]
                dels = [x.lstrip("+:") for x in pos[1:] if x.lstrip("+").startswith(":")]
                if any(x in ("--delete", "-d") for x in rest):
                    dels += pos[1:]
                if dels:
                    acts.append(("delete", "Delete the branch%s %s from the online copy of %s" % ("es" if len(dels) > 1 else "", ", ".join(dels), proj)))
                else:
                    acts.append(("share", "Upload the saved code changes in %s to its online copy" % proj))
                    if any(x in ("--force", "-f", "--force-with-lease") or x.startswith("--force") or x.startswith("+") for x in rest):
                        acts.append(("note", "This replaces the online copy: changes there that are not on this computer will be lost."))
            elif sub == "clean":
                acts.append(("delete", "Delete the files in %s that are not part of its saved history" % proj))
            elif sub == "reset" and "--hard" in rest:
                acts.append(("delete", "Throw away the unsaved changes in %s (they cannot be brought back)" % proj))
            continue
        if h == "find" and "-delete" in w:
            roots = [x for x in w[1:] if not x.startswith("-") and not x.startswith("(")][:1] or ["."]
            p, _why = _expand(roots[0], cwd)
            acts.append(("delete", "Delete the files inside %s that a search picks (Qosha could not list them in advance)" % (_label(p) if p else roots[0])))
            unknown = True
            continue
        if h == "npm" and len(w) > 1 and w[1] == "publish":
            acts.append(("share", "Publish this package on npm, where anyone can download it"))
            continue
        if h == "twine" and len(w) > 1 and w[1] == "upload":
            acts.append(("share", "Publish this package on PyPI, where anyone can download it"))
            continue
        if h == "stripe" and len(w) >= 3:
            fl = _flag_args(" ".join(_q(x) for x in w[3:]))
            acts.append(("pay", _stripe(w[1], fl)))
            continue
        if h == "curl" or h.startswith("invoke-"):
            url, data, raw = _curl_parts(w)
            m = re.match(r"https?://api\.stripe\.com/v\d+/([a-z_]+)", url)
            if m:
                acts.append(("pay", _stripe(m.group(1), data)))
            elif re.match(r"https?://api(-m)?\.(sandbox\.)?paypal\.com", url):
                acts.append(("pay", _paypal(raw)))
            continue
        if re.search(r"\b(drop\s+(table|database)|delete\s+from)\b", " ".join(w), re.I):
            db = next((os.path.basename(x) for x in w[1:] if re.search(r"\.(db|sqlite3?)$", x)), "")
            acts.append(("delete", "Delete data from the database %s" % db if db else "Delete data from a database (Qosha could not tell exactly which)"))
    return acts, gone, unknown, only_del


def _code_acts(code: str) -> Tuple[list, list, bool]:
    """Deletes in code the assistant runs: a name written in the code is looked at; anything else is said plainly."""
    acts, gone, unknown = [], [], False
    # "not there now" counts only when the code does nothing but delete (no line that could make or move a file first)
    trust = all(re.match(r"\s*($|#|import\s|from\s+\S+\s+import\s|(os\.(remove|unlink|rmdir|removedirs)|shutil\.rmtree|fs\.(rm|unlink|rmdir)(Sync)?|Path)\()", ln)
                for ln in code.split("\n"))
    lit = r"\s*(?:r|f)?(?P<q>['\"])(?P<name>[^'\"\n]+)(?P=q)\s*"
    found = False
    for m in re.finditer(r"\b(?P<fn>os\.(?:remove|unlink|rmdir|removedirs)|shutil\.rmtree|fs\.(?:rm|unlink|rmdir)(?:Sync)?)\((?:" + lit + r"[,)])?", code):
        found = True
        name = m.group("name")
        fn = m.group("fn")
        tree = fn == "shutil.rmtree" or fn in ("fs.rm", "fs.rmSync")
        if not name or "{" in name:
            unknown = True
            continue
        it = _item(name, "")
        if it["exists"] is False and trust:
            gone.append(it["name"])
            continue
        acts += [("delete", s) for s in _delete_sentences("delete", [it], tree)]
    for m in re.finditer(r"Path\(" + lit + r"\)\.(?P<m>unlink|rmdir)\(", code):
        found = True
        it = _item(m.group("name"), "")
        if it["exists"] is False and trust:
            gone.append(it["name"])
        else:
            acts += [("delete", s) for s in _delete_sentences("rmdir" if m.group("m") == "rmdir" else "delete", [it], False)]
    if re.search(r"\.unlink\(|\.rmdir\(\)", code) and not found:
        unknown = True
    if unknown or (not acts and not gone):
        acts.append(("delete", "Delete something on this computer whose name the code works out while it runs (Qosha could not check it)"))
        unknown = True
    return acts, gone, unknown


def _code_pay(code: str) -> list:
    m = re.search(r"stripe\.(Charge|PaymentIntent|Payout|Refund|Transfer)\.create\(([^)]*)\)", code)
    if m:
        data = {k: v for k, v in re.findall(r"(\w+)\s*=\s*['\"]?([\w.@-]+)", m.group(2))}
        return [("pay", _stripe({"PaymentIntent": "payment_intents"}.get(m.group(1), m.group(1).lower() + "s"), data))]
    if re.search(r"paypal\.com", code):
        return [("pay", "Make a payment through PayPal (Qosha could not tell the amount or who gets it)")]
    return [("pay", "Make a payment through Stripe (Qosha could not tell the amount or who gets it)")] if re.search(r"stripe", code, re.I) else []


def _service(tool: str) -> str:
    low = tool.lower()
    server = low.split("__")[1] if low.startswith("mcp__") and low.count("__") >= 2 else ""
    base = low.rsplit("__", 1)[-1]
    if server == "google" or re.search(r"drive|gmail|calendar|docs?_|sheet", base):
        for k, v in (("drive", "Google Drive"), ("gmail", "Gmail"), ("calendar", "Google Calendar"), ("doc", "Google Docs"),
                     ("sheet", "Google Sheets"), ("contact", "Google Contacts"), ("task", "Google Tasks"), ("form", "Google Forms"),
                     ("slide", "Google Slides")):
            if k in base:
                return v
        return "Google"
    return server.replace("_", " ").replace("-", " ").title() if server else ""


def _tool_acts(kind: str, tool: str, a: Dict[str, Any]) -> list:
    """Plain words for a connector's own tool (Google Drive, payment apps, ...), from its named arguments."""
    svc = _service(tool)
    base = tool.lower().rsplit("__", 1)[-1]
    get = lambda *ks: next((str(a[k]) for k in ks if a.get(k) not in (None, "", [], {})), "")
    in_svc = (" in %s" % svc) if svc else ""
    if kind == "share":
        act = get("action").lower()
        role = _ROLE.get(get("role").lower(), ("access: " + get("role")) if get("role") else "")
        typ = get("share_type", "type").lower()
        who = "anyone who has the link" if typ == "anyone" else ("everyone at %s" % get("share_with", "domain") if typ == "domain" else
                                                                 get("share_with", "email", "email_address", "user", "recipient"))
        if not who and isinstance(a.get("recipients"), list):
            who = ", ".join(str((r or {}).get("email") or (r or {}).get("email_address") or "") for r in a["recipients"] if isinstance(r, dict))
        what = ("the file %s" % get("file_name", "name", "title")) if get("file_name", "name", "title") else ("a %s file" % svc if svc else "a file")
        if act == "revoke":
            return ["Stop sharing %s with %s" % (what, who or "someone")]
        if act == "transfer_owner":
            return ["Make %s the owner of %s" % (get("new_owner_email") or who or "someone", what)]
        if act == "update":
            return ["Change what %s can do with %s%s" % (who or "someone", what, (" (%s)" % role) if role else "")]
        if re.search(r"upload|create", base):
            return ["Upload %s%s" % (("the file " + get("file_name", "name", "title")) if get("file_name", "name", "title") else "a file", (" to %s" % svc) if svc else "")]
        if who:
            return ["Share %s with %s%s" % (what, who, (" (%s)" % role) if role else "")]
        return ["Share or publish something%s (Qosha could not tell with whom)" % in_svc]
    if kind == "delete":
        name = get("file_name", "name", "title", "path", "summary", "subject")
        obj = re.sub(r"^(batch_)?(delete|remove|trash|destroy|purge|erase|manage)_?", "", base).replace("_", " ").strip() or "item"
        return [("Delete the %s %s%s" % (obj, name, in_svc)) if name else ("Delete a %s%s" % (obj, in_svc))]
    if kind == "pay":
        amt = get("amount", "total", "price", "value")
        who = get("to", "recipient", "payee", "email", "destination", "customer")
        cur = get("currency").upper()
        if amt:
            return ["Pay %s%s%s%s" % (amt, (" " + cur) if cur else "", (" to " + who) if who else "", (" (%s)" % svc) if svc else "")]
        return ["Make a payment%s (Qosha could not tell the amount or who gets it)" % ((" with " + svc) if svc else "")]
    return []


def plain_acts(kind: str, tool: str, a: Dict[str, Any], task_id: str = "") -> Tuple[list, list, list]:
    """(sentences, names already gone, notes) for a delete, share or pay card. The sentences cover every act of the
    step that would be asked about (a script that uploads and then shares shows both), in order."""
    import os
    if tool == "terminal":
        acts, gone, _u, _o = _shell_acts(str(a.get("command") or ""), _cwd(a, task_id))
    elif tool == "execute_code":
        code = str(a.get("code") or "")
        acts, gone = (_code_pay(code), []) if kind == "pay" else (_code_acts(code)[:2] if kind == "delete" else ([], []))
    elif tool == "patch":
        acts, gone = [], []
        cwd = _cwd(a, task_id)
        trust = not re.search(r"^\*\*\* (Add File|Move to):", str(a.get("patch") or ""), re.M)
        for m in re.finditer(r"^\*\*\* Delete File:\s*(.+?)\s*$", str(a.get("patch") or ""), re.M):
            it = _item(m.group(1), cwd)
            if it["exists"] is False and trust:
                gone.append(it["name"])
            else:
                acts += [("delete", s) for s in _delete_sentences("delete", [it], False)]
    else:
        acts, gone = [(kind, s) for s in _tool_acts(kind, tool, a)], []
    notes = [s for k, s in acts if k == "note"]
    steps = [s for k, s in acts if k in ("delete", "share", "pay", "email.send", "calendar.change")]
    return steps, gone, notes


def _not_understood(kind: str, tool: str) -> str:
    svc = _service(tool or "")
    return "Qosha could not put this step into plain words. It may %s%s." % (KIND_TEXT.get(kind, "act"), (" (in %s)" % svc) if svc else "")


def _deletes_only_gone(tool: str, a: Dict[str, Any], task_id: str = "") -> bool:
    """True when every thing the step would delete is checked and already gone (nothing else it does is asked)."""
    try:
        if tool == "terminal":
            acts, gone, unknown, _o = _shell_acts(str(a.get("command") or ""), _cwd(a, task_id))
            return bool(gone) and not unknown and not any(k == "delete" for k, _s in acts)
        if tool == "execute_code":
            acts, gone, unknown = _code_acts(str(a.get("code") or ""))
            return bool(gone) and not unknown and not acts
        if tool == "patch":
            steps, gone, _n = plain_acts("delete", "patch", a, task_id)
            return bool(gone) and not steps
    except Exception:
        return False
    return False


def _gone_only_names(a: Dict[str, Any], task_id: str = "") -> list:
    """For a shell step that does nothing but delete (and change folder), the names when ALL of them are already gone;
    [] otherwise (then the step runs or is asked as usual)."""
    acts, gone, unknown, only_del = _shell_acts(str(a.get("command") or ""), _cwd(a, task_id))
    if gone and not unknown and only_del and not acts:
        return gone
    return []


# ---- website actions in plain words (Ren, 17 Nov: "say what will happen in plain words only; the code is never shown") ----
# The steps are worked out from the code itself, in the order they appear. A step that cannot be put in words is said
# so honestly; nothing is guessed. The model's own first "# comment" may be shown as a note when it is plain language,
# but it never replaces the steps: code that clicks shows "Click ..." whatever its comment says.
_URL = r"https?://[^\s'\"<>)\\]+"
_STR = r"(?:'((?:[^'\\]|\\.)*)'|\"((?:[^\"\\]|\\.)*)\")"
_WEB_TRIGGER = r"click|press|submit|keyboard|Input\.dispatch|send_keys|upload|setFileInputFiles|fetch\([^)]*method"


def _host(url: str) -> str:
    h = re.sub(r"^https?://", "", url or "", flags=re.I).split("/")[0].split("?")[0].split("#")[0].split("@")[-1].split(":")[0].lower()
    return h   # as written: www.example.com is shown as www.example.com


def _say(t: str, n: int = 60) -> str:
    """A piece of page text as the person would read it: one line, no code characters left over, cut short."""
    t = re.sub(r"\\[nrt]", " ", t or "")
    t = re.sub(r"\\(.)", r"\1", t)
    t = re.sub(r"\s+", " ", t).strip(" '\"`")
    return t if len(t) <= n else t[: n - 1].rstrip() + "…"


def _thing(sel: str, default: str = "something on the page") -> str:
    """What a selector points at, in a word or two. Never the selector itself."""
    low = (sel or "").lower()
    if re.search(r"type\s*=\s*[\"']?submit|\[type=submit\]", low):
        return "the form's send button"
    if re.search(r"type\s*=\s*[\"']?password|password|passwd", low):
        return "the password box"
    if re.search(r"type\s*=\s*[\"']?email|e-?mail", low):
        return "the email box"
    if re.search(r"search|name\s*=\s*[\"']?q\b|\[name=q\]|#q\b", low):
        return "the search box"
    if re.search(r"type\s*=\s*[\"']?checkbox", low):
        return "a tick box"
    if re.search(r"type\s*=\s*[\"']?file", low):
        return "a file field"
    if re.search(r"user(name)?|login", low) and re.search(r"input|#|\[", low):
        return "the user name box"
    if re.search(r"(^|[\s>,(])textarea\b|comment|message", low):
        return "the message box"
    if re.search(r"(^|[\s>,(])select\b", low):
        return "a list of choices"
    if re.search(r"(^|[\s>,(])(button)\b|\.btn\b|role\s*=\s*[\"']?button", low):
        return "a button"
    if re.search(r"(^|[\s>,(])a(\b|\[|\.|#|:)|href", low):
        return "a link"
    if re.search(r"(^|[\s>,(])input\b", low):
        return "a box on the page"
    if re.search(r"(^|[\s>,(])form\b", low):
        return "a form"
    return default


def _plain_note(code: str) -> str:
    """The code's own first comment, only when it reads as ordinary language (letters and plain punctuation)."""
    m = re.match(r"\s*#\s*(.+)", code or "")
    if not m:
        return ""
    t = m.group(1).strip()
    if not (8 <= len(t) <= 140) or re.search(r"[(){}\[\]=;<>`$\\|_]|https?:|\.\w+\(|querySelector|\bjs\b", t) or len(t.split()) < 2:
        return ""
    # a note that plays the action down ("just read", "only look") is not shown next to steps that act: the steps
    # alone speak. It must itself name an action to be shown.
    if re.search(r"\b(just|only|merely|simply|read|reads|reading|look|looks|check|checks|view|views|see|nothing|harmless|safe)\b", t, re.I):
        return ""
    if not re.search(r"\b(click|press|type|fill|enter|send|submit|sign|log ?in|upload|choose|select|pick|tick|buy|order|book|post|open)", t, re.I):
        return ""
    return t


# "Only before final actions" (Ren, 17 Nov ~13:10): opening pages, reading, clicking links, typing and moving about
# never ask. A card comes only before a final step: sending or submitting a form, posting, buying or paying, deleting,
# confirming, signing in or up, uploading a file, accepting terms. When the code presses something and it cannot be
# told that it is NOT such a control, it counts as final (asked, in plain words).
_FINAL_WORDS = (
    r"send|submit|post|publish|share|buy|purchase|pay|order|check ?out|place|delete|remove|erase|confirm|sign ?in|log ?in|"
    r"sign ?up|register|create account|accept|agree|consent|save|subscribe|unsubscribe|book|reserve|donate|transfer|apply|"
    r"enviar|publicar|comprar|pagar|finalizar|pedir|excluir|apagar|remover|deletar|confirmar|entrar|acessar|cadastrar|"
    r"criar conta|aceitar|aceito|concordo|salvar|assinar|reservar|doar|transferir|"
    r"eliminar|borrar|quitar|iniciar sesi[oó]n|acceder|registrar|crear cuenta|aceptar|acepto|guardar|suscribir")
_SAFE_WORDS = (
    r"search|find|show|more|less|next|previous|prev|back|menu|open|close|expand|collapse|details|view|filter|sort|tab|"
    r"load|dismiss|cancel|skip|read|learn|about|help|home|"
    r"buscar|pesquisar|procurar|mostrar|ver|mais|menos|pr[oó]xim[oa]|anterior|voltar|abrir|fechar|detalhes|filtrar|ordenar|"
    r"cancelar|pular|ajuda|in[ií]cio|siguiente|volver|cerrar|detalles|ayuda")


def _is_final_word(text: str) -> bool:
    return bool(re.search(r"(?<![a-zà-ú])(%s)" % _FINAL_WORDS, (text or "").lower()))


def _is_safe_word(text: str) -> bool:
    return bool(re.search(r"(?<![a-zà-ú])(%s)" % _SAFE_WORDS, (text or "").lower())) and not _is_final_word(text)


def web_plain(code: str, kind: str = "web.act") -> Tuple[str, list, str, bool]:
    """(site, steps, note, final) for a website action: host only, short human steps in the code's order, an optional
    plain note, and whether any step is a final one (only then is the person asked)."""
    code = str(code or "")
    note = _plain_note(code)
    body = "\n".join(ln for ln in code.split("\n") if not ln.lstrip().startswith("#"))   # comments never count as actions
    urls = re.findall(_URL, body)
    site = _host(urls[0]) if urls else ""
    where = site or "the page that is open"
    found = []     # (position, end, sentence, final)
    covered = []   # more of the code that a step above already accounts for

    def hit(m, text, final=False):
        found.append((m.start(), m.end(), text, final))

    if kind == "web.post":
        verb = "Send data to"
        if re.search(r"\b(DELETE)\b|\.delete\(|-Method\s+Delete", body, re.I):
            verb = "Ask to delete something on"
        elif re.search(r"\b(PUT|PATCH)\b|\.(put|patch)\(|-Method\s+(Put|Patch)", body, re.I):
            verb = "Change data on"
        return site, ["%s %s" % (verb, where)], note, True
    for m in re.finditer(r"\b(new_tab|goto_url|goto|navigate|open_url)\(\s*" + _STR, body):
        u = m.group(2) or m.group(3) or ""
        h = _host(u)
        if h:
            path = re.sub(r"^https?://[^/]+", "", u).split("?")[0].split("#")[0].rstrip("/")
            hit(m, "Open %s%s" % (h, (" (the page %s)" % _say(path, 40)) if path else ""))
    boxes = []     # what was typed into, to judge a later Enter
    for m in re.finditer(r"\bfill_input\(\s*" + _STR + r"\s*,\s*" + _STR, body):
        sel, txt = m.group(1) or m.group(2) or "", m.group(3) or m.group(4) or ""
        box = _thing(sel, "a box on the page")
        boxes.append(box)
        if box == "the password box":
            hit(m, "Type a password into the password box")
        else:
            hit(m, "Type “%s” into %s" % (_say(txt), box) if txt.strip() else "Type into %s" % box)
    for m in re.finditer(r"\bfill_input\(\s*(?!['\"])[^)]*\)", body):
        boxes.append("a box on the page")
        hit(m, "Type into a box on the page")
    for m in re.finditer(r"\bclick_at_xy\([^)]*\)|Input\.dispatchMouseEvent", body):
        hit(m, "Click a spot on %s that Qosha could not identify" % where, True)
    for m in re.finditer(r"\.click\(\s*\)", body):
        stmt_start = max(body.rfind("\n", 0, m.start()), body.rfind("js(", 0, m.start()) - 1, 0)
        stmt = body[stmt_start:m.start()].replace("\\'", "'").replace('\\"', '"')   # quotes escaped inside the js("...") string read as plain quotes
        label = re.search(r"(?:textContent|innerText|ariaLabel|aria-label|title|value)[^'\"\n]{0,40}(?:includes\(|===?|==|indexOf\(|startsWith\(|contains\()\s*\\?" + _STR, stmt) \
            or re.search(r"(?:getByText|getByRole|:contains|has-text)\(?\s*\\?" + _STR, stmt) \
            or re.search(r"aria-label\s*[*^$]?=\s*\\?[\"']?([^\"'\]\\]{2,60})", stmt)
        sels = re.findall(r"querySelector(?:All)?\(\s*\\?" + _STR, stmt) or re.findall(r"getElementById\(\s*\\?" + _STR, stmt)
        sel = " ".join(x for pair in sels[-1:] for x in pair if x) if sels else ""
        what = _thing(sel)
        words = _say(next(g for g in label.groups() if g)) if label else ""
        link = what == "a link"
        if what == "the form's send button":
            text, final = ("Press the button “%s” (it sends the form)" % words if words else "Send the form"), True
        elif words and _is_final_word(words):
            text, final = "Press the %s “%s”" % ("link" if link else "button", words), True
        elif words and (link or _is_safe_word(words)):
            text, final = "Click the %s “%s”" % ("link" if link else "button", words), False
        elif words:
            text, final = "Press the button “%s”" % words, True          # a named control that is not known to be harmless
        elif link and not _is_final_word(sel):
            text, final = "Click a link", False
        elif _is_final_word(sel):
            text, final = "Press a button on %s (its name in the page suggests a final step)" % where, True
        else:
            text, final = "Press a button on %s that Qosha could not identify" % where, True
        found.append((m.start(), m.end(), text, final))
        covered.append((stmt_start, m.end()))   # the words that picked the element belong to this step
    for m in re.finditer(r"\.(?:requestSubmit|submit)\(\s*\)", body):
        hit(m, "Send the form", True)
    vals = list(re.finditer(r"\.value\s*=\s*(?!=)", body))
    if vals:
        pw = sum(1 for m in vals if re.search(r"passw", body[max(0, m.start() - 160):m.start()], re.I))
        text = "Fill %d field%s of a form" % (len(vals), "" if len(vals) == 1 else "s") + (" (one is a password)" if pw else "")
        found.append((vals[0].start(), vals[-1].end(), text, False))
        boxes.append("a form")
    for m in re.finditer(r"\.checked\s*=\s*(true|false|True|False)", body):
        near = body[max(0, m.start() - 200):m.start()]
        terms = bool(re.search(r"terms|agree|accept|consent|policy|termos|aceit|concord|t[eé]rminos|acept", near, re.I))
        hit(m, ("Tick the box that accepts the terms" if terms else "Tick a box") if m.group(1).lower() == "true" else "Untick a box", terms and m.group(1).lower() == "true")
    for m in re.finditer(r"\.selectedIndex\s*=|\.selected\s*=\s*true", body):
        hit(m, "Pick a choice from a list")
    for m in re.finditer(r"setFileInputFiles|\bupload\w*\(|input\[type=.?file", body, re.I):
        hit(m, "Upload a file", True)
    # Enter in a form sends it. The one exception is a plain search: the only thing typed into is a search box, so
    # Enter just shows results (moving about, like a link). Anything else typed, or nothing known: it is final.
    only_search = bool(boxes) and all(b == "the search box" for b in boxes)
    for m in re.finditer(r"(?:\bpress\(|\bsend_keys\(|key\s*[:=]\s*|code\s*[:=]\s*)\s*" + _STR, body):
        key = (m.group(1) or m.group(2) or "").strip()
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9+ ]{0,20}", key):
            continue
        key = {"Return": "Enter", "NumpadEnter": "Enter"}.get(key, key)
        if key == "Enter":
            hit(m, "Press Enter to search" if only_search else "Press Enter (it sends what was typed)", not only_search)
        else:
            hit(m, "Press the %s key" % key)
    for m in re.finditer(r"Input\.insertText|\.type\(\s*" + _STR + r"?|keyboard\.type", body):
        hit(m, "Type on the page")
    for m in re.finditer(r"fetch\([^)]{0,200}method\s*:\s*['\"](POST|PUT|PATCH|DELETE)['\"]", body, re.I | re.S):
        hit(m, "Send data to %s" % where, True)
    found.sort()
    steps, final = [], False
    # the website the card names (and "Always allow" is for) is the one the final step happens on: the page opened
    # last before it, not just the first address in the code
    opened = [(m.start(), _host(m.group(2) or m.group(3) or "")) for m in re.finditer(r"\b(new_tab|goto_url|goto|navigate|open_url)\(\s*" + _STR, body)]
    first_final = next((pos for pos, _e, _t, fin in found if fin), None)
    if first_final is not None:
        before = [h for pos, h in opened if pos < first_final and h]
        if before:
            site = before[-1]
    for _s, _e, t, fin in found:
        final = final or fin
        if not steps or steps[-1] != t:          # the same step twice in a row is said once
            steps.append(t)
    # anything that acts on the page and was not put in words above is said honestly, and counts as final
    rest = list(body)
    for s0, e0 in [(a0, b0) for a0, b0, _t, _f in found] + covered:
        for i in range(s0, min(e0, len(rest))):
            rest[i] = " "
    rest = "".join(rest)
    rest = re.sub(r"Input\.dispatchKeyEvent|keyboard", " ", rest) if any(t.startswith(("Press ", "Type on")) for t in steps) else rest
    if re.search(_WEB_TRIGGER, rest, re.I):
        final = True
        steps.append(("And something more on %s" if [t for t in steps if not t.startswith("Open ")] else "Do something on %s") % where
                     + " that Qosha could not describe in plain words")
    return site, steps[:12], note, final


def _asks_path():
    import os
    try:
        from hermes_constants import get_hermes_home
        home = str(get_hermes_home())
    except Exception:
        home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    d = os.path.join(home, "qosha")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "asks.json")


def _asks_edit(fn) -> list:
    """Read-modify-write of the small list of questions waiting in a chat (Home shows them)."""
    import os, time
    path = _asks_path()
    try:
        cur = json.loads(open(path, encoding="utf-8").read())
    except Exception:
        cur = []
    cur = [x for x in cur if isinstance(x, dict) and time.time() - float(x.get("at") or 0) < 3600]
    new = fn(cur)
    if new is not None and new != cur:
        tmp = path + ".tmp%d" % os.getpid()
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(new, fh)
        os.replace(tmp, path)
        cur = new
    return cur


def pending_asks() -> list:
    return _asks_edit(lambda cur: None)


_LAST: Dict[str, Dict[str, Any]] = {}   # message text -> what was asked (this process), for the approval hooks


def pre_approval_request(description: str = "", pattern_key: str = "", session_key: str = "", **_: Any) -> None:
    import time
    if not str(pattern_key).startswith("plugin_rule:qosha:"):
        return
    info = _LAST.get(description) or {}
    item = {"id": "ask-%d" % int(time.time() * 1000), "at": time.time(), "kind": str(pattern_key).split("qosha:", 1)[-1],
            "title": info.get("title") or description.split("\n", 1)[0], "rows": info.get("rows") or [],
            "session": info.get("session") or "", "session_key": session_key, "text": description}
    _asks_edit(lambda cur: [x for x in cur if not (x.get("session_key") == session_key and x.get("text") == description)] + [item])


def post_approval_response(description: str = "", pattern_key: str = "", session_key: str = "", **_: Any) -> None:
    if str(pattern_key) == "plugin_rule:" + _FRONT_RULE:
        try:
            if _browser_cfg().get("qosha_stay_behind") is True:
                _stay_behind_watch()
        except Exception:
            pass
        return
    if not str(pattern_key).startswith("plugin_rule:qosha:"):
        return
    try:
        # the person allowed the step on Qosha's card: the engine's own check is not asked again for this same step
        call = str(_.get("tool_call_id") or "")
        keys = _CALL_GRANTS.get(call) or (_LAST.get(description) or {}).get("grant") or []
        if keys and _consented(_.get("choice")):
            from . import engine_ask
            if engine_ask.grant(list(keys), call, session_key) and call:
                _GRANT_WHY[call] = "now"
    except Exception:
        pass
    _asks_edit(lambda cur: [x for x in cur if not (x.get("session_key") == session_key and x.get("text") == description)])


def _consented(choice: Any) -> bool:
    try:
        from tools.approval import CONSENT_ANSWERS, canonical_approval_choice
        return canonical_approval_choice(choice) in CONSENT_ANSWERS
    except Exception:
        return str(choice or "").lower() in ("once", "session", "always")


# Website steps no longer use rule_for (see sends_to_web below); its website keys are kept only so older code reads.
WEB_KINDS = ("web.act", "web.post")

# No "Always allow" for a step that sends data to a website (Ren, 19 Nov 2026: "No 'Always allow' for websites"). Such a
# step, and any step that also does one (an email + a POST, a delete + a POST, a payment made with curl), gets "Allow
# this time" only: its rule key is new for every call, so no "always" answer from any screen can ever cover another
# step, and every grant saved before (a website, a www or bare form, "step-...", the old all-websites key) matches
# nothing. Any web client named anywhere in a shell step or code counts, so when unsure the step asks.
_WEB_SEND = re.compile(
    r"(?<![\w.-])(?:curl|wget2?|Invoke-WebRequest|Invoke-RestMethod|Start-BitsTransfer)\b"
    r"|(?:^|[;&|(\n`]|\$\()\s*(?:sudo\s+|env\s+|\w+=\S*\s+)*(?:iwr|irm|https?|xh|httpie|aria2c)\s"
    r"|\b(?:requests|httpx|urllib3|aiohttp|pycurl|httplib2)\s*\.\s*\w+\s*\(|\burllib\.request\b|\bhttp\.client\b"
    r"|\b(?:from|import)\s+(?:requests|httpx|urllib|urllib3|aiohttp|pycurl|httplib2|http\.client)\b"
    r"|\bfetch\s*\(|XMLHttpRequest|sendBeacon|\bWebSocket\b", re.I | re.M)


def sends_to_web(kind: str, tool: str, args: Any) -> bool:
    if kind in WEB_KINDS:
        return True
    tool, a = _unwrap((tool or "").strip(), args if isinstance(args, dict) else {})
    if tool.startswith("browser"):
        return True   # a browser step that asks acts on a website (an upload, a press, a final step)
    if tool not in ("terminal", "execute_code", "process", "process_manage"):
        return False
    return bool(_WEB_SEND.search(" ".join(str(a.get(k) or "") for k in ("command", "code", "input"))))


def _once(kind: str) -> str:
    import secrets
    return "qosha:%s:once-%s" % (kind, secrets.token_hex(8))


def rule_for(kind: str, rows: list, code: str) -> str:
    if kind not in WEB_KINDS:
        return "qosha:" + kind
    site = next((str(v) for lab, v in rows if lab == "Website"), "")
    if site and re.fullmatch(r"[a-z0-9.-]{1,253}", site):
        return "qosha:%s:%s" % (kind, site)
    import hashlib
    return "qosha:%s:step-%s" % (kind, hashlib.sha256(str(code).encode("utf-8")).hexdigest()[:16])   # the code itself: only the very same step


# ---- Qosha's own browser on a person's computer (Ren, 17 Nov 13:21 and 13:42) ------------------------------------
# * It runs in the Google Chrome already on the computer when there is one (a separate, empty profile inside Qosha's
#   home; never the person's everyday profile), else in the bundled browser. Looked for before every browser step, so
#   a Chrome installed later is picked up, and one that was removed is dropped.
# * Visible or in the background: `browser.headed` (Settings > Browser "Do it in the background").
# * In front (the default) or behind: `browser.qosha_stay_behind` (Settings > Browser, or by telling Qosha).
# The engine reads its browser settings once per run; when one of them changed, its kept values are dropped and its
# running browser is closed, so the very next step starts a browser as chosen. Nothing here may raise.
FRONT_TITLE = "Qosha is about to open its browser window"
_FRONT_RULE = "qosha:browser.window"


def chrome_path() -> str:
    """The installed Google Chrome's program on this computer, or "" when there is none."""
    import os
    import sys
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        places = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                  home + "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    elif os.name == "nt":
        places = [os.path.join(os.environ.get(v) or "", "Google", "Chrome", "Application", "chrome.exe")
                  for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA") if os.environ.get(v)]
    else:
        places = ["/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/opt/google/chrome/chrome"]
    return next((x for x in places if os.path.isfile(x)), "")


def _is_chrome_program(path: str) -> bool:
    low = (path or "").replace("\\", "/").lower()
    return low.endswith("/google chrome.app/contents/macos/google chrome") or low.endswith("/google/chrome/application/chrome.exe") \
        or low in ("/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/opt/google/chrome/chrome")


def _browser_cfg() -> dict:
    try:
        from hermes_cli.config import load_config
        return dict((load_config() or {}).get("browser") or {})
    except Exception:
        return {}


def _set_cfg(key: str, value: str) -> None:
    import contextlib
    import io
    from hermes_cli.config import set_config_value
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        set_config_value(key, value, force=True)


def _truthy(v) -> bool:
    return str(v).strip().lower() in ("true", "1", "yes", "on")


_SEEN = {"exe": None, "args": None}


def _browser_sync() -> dict:
    """Bring the engine in line with the settings before a browser step; returns the browser settings as they are now."""
    br = _browser_cfg()
    changed = False
    try:
        # which browser: the installed Chrome unless the person named another program themselves
        cur = str(br.get("executable_path") or "")
        if br.get("qosha_use_chrome", True) is not False and (cur == "" or _is_chrome_program(cur)):
            found = chrome_path()
            if cur != found:
                _set_cfg("browser.executable_path", found)
                br["executable_path"] = found
                changed = True
        # the installed Chrome keeps its passwords in the system's store; Qosha's empty profile must never ask for it
        # or touch it: its own profile uses a plain store of its own (these two flags only concern that profile)
        try:
            from tools import browser_session_cloud as cloud
            if bool(cloud.is_headed_mode()) != _truthy(br.get("headed")):
                changed = True
        except Exception:
            cloud = None
        exe = str(br.get("executable_path") or "")
        if _SEEN["exe"] is not None and _SEEN["exe"] != exe:
            changed = True
        _SEEN["exe"] = exe
        if changed and cloud is not None:
            cloud.reset_caches()
            try:
                from tools.browser_use_cli import stop_harness_daemons
                stop_harness_daemons()
            except Exception:
                pass
            try:
                from tools.browser_launcher import stop_all_browsers
                stop_all_browsers()
            except Exception:
                pass
    except Exception:
        pass
    return br


def _front_app() -> Tuple[str, int]:
    """macOS: (bundle path, process id) of the app in front, or ("", 0)."""
    import subprocess
    try:
        asn = subprocess.run(["lsappinfo", "front"], capture_output=True, text=True, timeout=3).stdout.strip()
        out = subprocess.run(["lsappinfo", "info", "-only", "bundlepath", "-only", "pid", asn], capture_output=True, text=True, timeout=3).stdout
        m = re.search(r'"LSBundlePath"="([^"]+)"', out)
        n = re.search(r'"pid"\s*=\s*(\d+)', out)
        return (m.group(1) if m else ""), (int(n.group(1)) if n else 0)
    except Exception:
        return "", 0


def _is_qoshas_browser(pid: int) -> bool:
    """True only for a browser Qosha started: its profile folder lies inside Qosha's own home. The person's own
    Chrome (same program, their profile) is never touched."""
    import subprocess
    if not pid:
        return False
    try:
        from hermes_constants import get_hermes_home
        home = str(get_hermes_home())
        cmd = subprocess.run(["ps", "-o", "command=", "-p", str(pid)], capture_output=True, text=True, timeout=3).stdout
        import os
        return ("--user-data-dir=" + home) in cmd or ("--user-data-dir=" + os.path.realpath(home)) in cmd
    except Exception:
        return False


def _stay_behind_watch(seconds: float = 25.0) -> None:
    """ "Stay behind": macOS always puts a newly started app in front and the engine starts the browser itself, so the
    window cannot be started behind. The nearest thing: for the next seconds, the moment Qosha's browser takes the
    front, the front is handed straight back to the app the person was in (a brief flash, then their window again)."""
    import sys
    import threading
    if sys.platform != "darwin":
        return   # Windows: the window is started minimized instead (see _window_args)
    was, _was_pid = _front_app()
    if not was:
        return

    def run():
        import subprocess
        import time
        end = time.time() + seconds
        gave = 0
        while time.time() < end and gave < 3:
            time.sleep(0.15)
            now, pid = _front_app()
            if now and pid != _was_pid and _is_qoshas_browser(pid):   # only Qosha's own browser, never the person's Chrome
                try:
                    subprocess.run(["open", "-a", was], capture_output=True, timeout=5)   # brings the person's app back; starts nothing new
                    gave += 1
                except Exception:
                    return
    threading.Thread(target=run, name="qosha-browser-behind", daemon=True).start()


def _window_args(br: dict) -> None:
    """Keep the browser flags in line with the choices: Qosha's own empty profile never uses the system's password
    store; on Windows "stay behind" starts the window minimized."""
    import os
    try:
        args = [str(x) for x in (br.get("chromium_args") or [])]
        want = list(args)
        for flag in ("--mute-audio", "--disable-audio-output"):
            if flag not in want:
                want.append(flag)
        chrome = _is_chrome_program(str(br.get("executable_path") or ""))
        for flag in ("--password-store=basic", "--use-mock-keychain"):
            if chrome and flag not in want:
                want.append(flag)
            if not chrome and flag in want:
                want.remove(flag)   # the bundled browser gets them from the engine itself
        mini = os.name == "nt" and _truthy(br.get("headed")) and br.get("qosha_stay_behind") is True
        if mini and "--start-minimized" not in want:
            want.append("--start-minimized")
        if not mini and "--start-minimized" in want:
            want.remove("--start-minimized")
        if want != args:
            from hermes_cli.config import load_config, save_config
            cfg = load_config()
            cfg.setdefault("browser", {})["chromium_args"] = want
            save_config(cfg)
            br["chromium_args"] = want
    except Exception:
        pass


def _before_browser_step(final: bool) -> Optional[Dict[str, str]]:
    """Settings in line before a browser step; when the person chose "stay behind", the front is handed back to them."""
    br = _browser_sync()
    _window_args(br)
    if not _truthy(br.get("headed")):
        return None
    # Ren, 17 Nov 15:36: the window comes to the FRONT by default and nobody is asked; a person it bothers switches
    # "Keep the browser window behind my other windows" on in Settings > Browser, or tells Qosha in the chat.
    if br.get("qosha_stay_behind") is True:
        _stay_behind_watch()
    return None


def pre_tool_call(tool_name: str = "", args: Any = None, session_id: str = "", task_id: str = "", tool_call_id: str = "",
                  **_: Any) -> Optional[Dict[str, str]]:
    try:
        from . import engine_ask
    except Exception:
        engine_ask = None
    if engine_ask is not None:
        engine_ask.revoke(keep_call=tool_call_id)   # a grant given for an earlier step ends when the next one starts
    is_browser = "browser" in str(tool_name) or (tool_name == "tool_call" and "browser" in str((args or {}).get("name") if isinstance(args, dict) else ""))
    try:
        k = kind_of(tool_name, args, task_id)
    except Exception:
        return {"action": "approve", "rule_key": _once("unclear"),
                "message": "Qosha could not tell what this step does. Allow it?\n"
                           "(\"Always allow\" is not offered for this step: Qosha could not tell what it does.)"}
    if not k and tool_name == "terminal":
        # a shell step that ONLY deletes things that are already gone: no card, and nothing runs (the engine would
        # otherwise put its own question about a recursive delete); Qosha is told plainly and carries on
        try:
            gone = _gone_only_names(args if isinstance(args, dict) else {}, task_id)
        except Exception:
            gone = []
        if gone:
            return {"action": "block", "message": "Nothing to delete: %s %s already gone, so this step was skipped and "
                    "nothing ran. Carry on without it." % (", ".join(gone[:8]) + (" and more" if len(gone) > 8 else ""),
                                                           "is" if len(gone) == 1 else "are")}
    if is_browser:
        try:
            ask_window = _before_browser_step(bool(k))
        except Exception:
            ask_window = None
        if ask_window and not k:
            return ask_window
    # what the engine's own safety check would ask about for this same shell command (17 Nov 16:41, Ren's Mac: after
    # "Allow this time" on Qosha's card a second, technical card "delete in root path" came up). Qosha's one card
    # says it too, in plain words, and the engine's check is then not asked again for this step.
    eng, risks = [], []
    if engine_ask is not None and tool_name == "terminal" and isinstance(args, dict):
        eng = engine_ask.findings(str(args.get("command") or ""), bool(args.get("background"))) or []   # what it would ask
        if eng or k:
            risks = engine_ask.all_risks(str(args.get("command") or ""), bool(args.get("background")))  # what the card says
        for ek, ed in eng:
            if ek not in [r[0] for r in risks]:
                risks.append((ek, ed))
    if not k and not eng:
        return None
    if k:
        kind, what = k
        title = "Qosha wants to %s" % KIND_TEXT.get(kind, kind)
        try:
            rows = rows_for(kind, tool_name, args, what, task_id)
        except Exception:
            rows = [("What happens", _not_understood(kind, tool_name))]
        extra = [(ek, ed) for ek, ed in risks if engine_ask.plain(ed)[0] != kind]   # what Qosha's own kind does not cover
    else:
        kind, what, extra = "engine", "", []
        title = "Qosha wants to do a step that could be hard to undo"
        said = []
        for _ek, ed in risks:
            t = engine_ask.plain(ed)[1]
            if t not in said:
                said.append(t)
        rows = [("Steps", "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(said)))] if len(said) > 1 else [("What happens", said[0])]
    if extra:
        said = []
        for _ek, ed in extra:
            t = engine_ask.plain(ed)[1]
            if t not in said:
                said.append(t)
        rows.append(("Also", "\n".join(said)))
    # one labelled row per line; a value's own line breaks are indented so the card can tell them from a new row
    lines = ["%s: %s" % (lab, str(val).replace("\r", "").replace("\n", "\n    ")) for lab, val in rows]
    try:
        web = sends_to_web(kind, tool_name, args)
    except Exception:
        web = True
    if web:
        tail = '("Always allow" is not offered for this step: it sends data to a website.)'
    elif kind == "engine" or extra:
        tail = '("Always allow" covers this kind of step from now on.)'
    else:
        tail = '("Always allow" covers every future action of this kind: %s.)' % KIND_TEXT.get(kind, kind)
    if web:
        rule = _once(kind)
    elif kind == "engine" or extra:
        # the person's "Always allow" is then for exactly these kinds of risk (and Qosha's own kind, if any)
        rule = "qosha:engine:" + "+".join(([kind] if kind != "engine" else []) + sorted({ek for ek, _ed in (extra or risks)}))
    else:
        rule = rule_for(kind, rows, what)
    message = "%s\n%s\n%s" % (title, "\n".join(lines), tail)
    grant_keys = [ek for ek, _ed in eng]
    _LAST[message] = {"title": title, "rows": [list(r) for r in rows], "session": session_id or "", "grant": grant_keys}
    if grant_keys and tool_call_id:
        _CALL_GRANTS[tool_call_id] = grant_keys
        for store in (_CALL_GRANTS, _GRANT_WHY):
            if len(store) > 200:
                for key in list(store)[:100]:
                    store.pop(key, None)
        if engine_ask.is_allowed(rule):
            # "Always allow" (or this session) was already chosen for this card: the engine lets it through without
            # asking, and its own check must not ask either
            if engine_ask.grant(grant_keys, tool_call_id):
                _GRANT_WHY[tool_call_id] = "always"
    if len(_LAST) > 200:
        for key in list(_LAST)[:100]:
            _LAST.pop(key, None)
    return {"action": "approve", "rule_key": rule, "message": message}


_CALL_GRANTS: Dict[str, list] = {}   # tool call -> the engine's findings to grant once the person allows that step
_GRANT_WHY: Dict[str, str] = {}      # tool call -> "now" (allowed on Qosha's card for this step) or "always"
_NOTE = re.compile(r"Command was flagged \([^\"\n]*?\) and auto-approved by [^\"\n]*?\.")


def transform_tool_result(tool_name: str = "", result: Any = None, tool_call_id: str = "", **_: Any) -> Optional[str]:
    """The engine notes on a shell step's result that its own check was "auto-approved by an approval the user gave
    earlier in this session", and Qosha repeated that to the person (17 Nov: "it went through without asking you"),
    when the person had just allowed that very step on Qosha's card. For the steps Qosha granted, the note says what
    really happened. Every other result is left as it is."""
    why = _GRANT_WHY.pop(str(tool_call_id or ""), "")
    if not why or tool_name != "terminal" or not isinstance(result, str) or not _NOTE.search(result):
        return None
    text = ("The person allowed this exact step on Qosha's approval card just now." if why == "now" else
            "The person chose Always allow for this kind of step on Qosha's approval card earlier.")
    return _NOTE.sub(text, result, count=1)


def post_tool_call(tool_name: str = "", tool_call_id: str = "", **_: Any) -> None:
    """The step is over: the engine's grant given for it ends now (also ended at the start of the next step)."""
    try:
        from . import engine_ask
        engine_ask.revoke()
    except Exception:
        pass
