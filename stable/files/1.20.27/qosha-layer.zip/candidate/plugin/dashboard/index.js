/* Qosha dashboard registration bundle (manifest `entry`).
   The Qosha UI is a standalone page served by the native static route at
   /dashboard-plugins/qosha/index.html. This bundle only registers the tab (the home
   screen, manifest `tab.override: "/"`) that embeds that page; the page talks to the
   plugin API (plugin_api.py) itself. This bundle makes no requests, except the session check below. */
(function () {
  'use strict';
  // LABPOLISH 1 (5 Nov): the dashboard makes a new session token every time it starts. When this window gets focus or
  // becomes visible again (at most every 30 s, never in its first 30 s), it reads the dashboard's page again (same
  // origin, never cached) and adopts the token there if it changed, so a window left open across a lab restart keeps
  // working with no reload. Here, in the dashboard page itself, so it lasts whatever Qosha page comes and goes; each
  // Qosha page also renews on a refused request (pages/qosha-session.js). The token is never stored, logged or shown.
  (function renewOnFocus() {
    if (window.__qoshaTopRenewal) return;
    var VALID = /^[\x21-\x7e]{16,512}$/, IN_PAGE = /window\.__HERMES_SESSION_TOKEN__\s*=\s*"([\x21\x23-\x5b\x5d-\x7e]{16,512})"/;
    var last = Date.now(), busy = false;
    function check() {
      if (busy || document.visibilityState === 'hidden' || Date.now() - last < 30000) return;
      if (typeof window.__HERMES_SESSION_TOKEN__ !== 'string' || !VALID.test(window.__HERMES_SESSION_TOKEN__)) return;
      busy = true; last = Date.now();
      window.fetch('/', {method: 'GET', credentials: 'same-origin', cache: 'no-store', redirect: 'manual'}).then(function (r) {
        var type = (r.headers.get('content-type') || '').toLowerCase();
        var origin = ''; try { origin = new URL(r.url || '/', window.location.href).origin; } catch (e) { origin = ''; }
        if (!r.ok || r.type !== 'basic' || r.redirected || origin !== window.location.origin || type.indexOf('text/html') !== 0) return null;
        return r.text().then(function (html) {
          var m = IN_PAGE.exec(html.slice(0, 65536));
          if (m && VALID.test(m[1]) && window.__HERMES_SESSION_TOKEN__ !== m[1]) window.__HERMES_SESSION_TOKEN__ = m[1];
        });
      }).catch(function () { /* the dashboard is restarting: the next focus or a refused request tries again */ })
        .then(function () { busy = false; });
    }
    window.addEventListener('focus', check);
    document.addEventListener('visibilitychange', check);
    window.__qoshaTopRenewal = true;
  })();
  var registry = window.__HERMES_PLUGINS__;
  var sdk = window.__HERMES_PLUGIN_SDK__;
  if (!registry || typeof registry.register !== 'function' || !sdk || !sdk.React) return;
  var React = sdk.React;
  // the tab icon is Qosha's on every page, also where the built screens still name the engine's icon (2 Nov;
  // the lab rewrites the served index.html too: qoshalab.py brand_web)
  (function icons() {
    var base = '/dashboard-plugins/qosha/assets/brand/icons/';
    var have = document.querySelector('link[rel="icon"][href*="qosha-icon"]');
    if (have) return;
    Array.prototype.forEach.call(document.querySelectorAll('link[rel="icon"],link[rel="shortcut icon"],link[rel="apple-touch-icon"]'), function (l) { l.remove(); });
    [['icon', 'image/svg+xml', 'qosha-icon.svg'], ['icon', 'image/x-icon', 'favicon.ico'], ['apple-touch-icon', '', 'apple-touch-icon.png']].forEach(function (x) {
      var l = document.createElement('link'); l.rel = x[0]; if (x[1]) l.type = x[1]; l.href = base + x[2]; document.head.appendChild(l);
    });
  })();
  // "/" is the Qosha home; "/?view=settings" is Qosha's Settings page (UAT 2 Nov: the engine's own pages live there)
  // "/?view=projects" is Qosha's Projects page (UAT 11:42), "/?view=projects&id=<id>" one project
  // "/?view=skills" and "/?view=connections": the skill library and the apps (night job 3, 2 Nov)
  function viewName() { var m = /(?:^|[?&])view=(settings|projects|skills|connections|browser)(?:&|$)/.exec(window.location.search); return m ? m[1] : 'home'; }
  function viewSrc() {
    var v = viewName();
    if (v === 'settings') return '/dashboard-plugins/qosha/settings.html';
    if (v === 'skills' || v === 'connections' || v === 'browser') return '/dashboard-plugins/qosha/pages/' + v + '.html';
    if (v === 'projects') {
      var id = /(?:^|[?&])id=([A-Za-z0-9_-]{1,80})(?:&|$)/.exec(window.location.search);
      return '/dashboard-plugins/qosha/pages/projects.html' + (id ? '?id=' + id[1] : '');
    }
    return '/dashboard-plugins/qosha/index.html';
  }
  // ---- Home side chat (Ren, 22 Nov 2026: layout A, a side panel; proposals/home-sidechat/DECISION.md) ------------------
  // Home keeps its page; Qosha's own chat page (pages/chat.html, its compact "panel" mode) is docked on its right, so
  // nobody leaves Home to talk to Qosha. Folded, it is a 44 px strip. Open or folded, its width and its conversation are
  // remembered on this computer; open by default on windows 1200 px and wider. Home's hand-off of a question (the
  // question in this tab's session storage, then /chat?new=1) goes to the panel instead of leaving Home (qoshaGo
  // below). Expand opens the full chat page on the same conversation; the chat page's "Dock on Home" brings it back.
  // Under 900 px the chat is a drawer from the right over Home (88% wide, Home dimmed behind it), opened by an "Ask
  // Qosha" button or the hand-off; Esc, the dimmed edge or Fold closes it. Cmd+J (Mac) / Ctrl+J (Windows) opens or
  // folds it from anywhere on Home (slice 4).
  // On by default since all four slices are in (22 Nov 2026); off on a computer whose localStorage holds qosha.sidechat = "0".
  var SIDE = {key: 'qosha.sidechat.panel', min: 320, def: 360, narrow: 900, strip: 44};
  // the panel can be dragged from 320 px up to 3/4 of the window (Ren, 22 Nov 2026 ~21:20), remembered
  function sideMax() { return Math.max(SIDE.min, Math.floor(window.innerWidth * 0.75)); }
  var TILE = '/dashboard-plugins/qosha/assets/brand/tiles/qosha-tile-forest.svg';   // the real Q tile (brand kit artwork)
  var IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent || '');
  // things waiting for the person (approval cards, emails that need them): Home tells the shell, the folded strip shows a dot
  var sideBadge = 0, badgeSet = null;
  window.qoshaSideBadge = function (n) { sideBadge = Math.max(0, Number(n) || 0); if (badgeSet) badgeSet(sideBadge); };
  var CHAT_PAGE = '/dashboard-plugins/qosha/pages/chat.html';
  function sideOn() { try { return window.localStorage.getItem('qosha.sidechat') !== '0'; } catch (e) { return true; } }   // on unless switched off ("0")
  function sidePrefs() {
    var p = {};
    try { p = JSON.parse(window.localStorage.getItem(SIDE.key) || '{}') || {}; } catch (e) { p = {}; }
    var w = Number(p.width);
    return {open: typeof p.open === 'boolean' ? p.open : null,
            width: isFinite(w) ? Math.min(sideMax(), Math.max(SIDE.min, Math.round(w))) : SIDE.def,
            session: /^[A-Za-z0-9_.:-]{1,120}$/.test(String(p.session || '')) ? String(p.session) : '',
            dock: Number(p.dock) || 0};
  }
  function saveSide(patch) {
    var p = sidePrefs(), next = {open: p.open, width: p.width, session: p.session};
    Object.keys(patch || {}).forEach(function (k) { next[k] = patch[k]; });
    try { window.localStorage.setItem(SIDE.key, JSON.stringify(next)); } catch (e) { /* not remembered */ }
  }
  function panelSrc(extra) {
    var p = sidePrefs(), q = 'panel=1';
    if (extra) q += '&' + extra; else if (p.session) q += '&session=' + encodeURIComponent(p.session);
    return CHAT_PAGE + '?' + q;
  }
  // the conversation the panel shows now (the chat page writes ?session=<id> into its own address)
  function panelSession(frame) {
    try {
      var m = /(?:^|[?&])session=([A-Za-z0-9_.:-]{1,120})(?:&|$)/.exec(frame.contentWindow.location.search);
      return m ? m[1] : '';
    } catch (e) { return ''; }
  }
  var sideApi = null;   // the mounted panel: {take(url) -> true when the panel took the hand-off}
  // slice 3: the side chat reads what Home shows (only while its "On screen" chip is on) and asks Home to read its
  // cards again after an answer; both go straight to the Home page beside it (same origin), nothing is stored
  function homeWindow() { try { var f = document.querySelector('.qosha-side-home'); return f && f.contentWindow; } catch (e) { return null; } }
  window.qoshaSideToggle = function () { if (sideApi && sideApi.toggle) sideApi.toggle(); };
  window.qoshaSideEscape = function () { return !!(sideApi && sideApi.escape && sideApi.escape()); };   // Esc inside the narrow drawer
  document.addEventListener('keydown', function (ev) {
    if ((ev.metaKey || ev.ctrlKey) && !ev.altKey && !ev.shiftKey && (ev.key === 'j' || ev.key === 'J') && sideApi) { ev.preventDefault(); window.qoshaSideToggle(); }
  });
  // Esc closes the narrow drawer: taken first (capture), because while it is open it is the top layer; with no drawer
  // open, Esc goes on to whatever else uses it
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && window.qoshaSideEscape()) { ev.preventDefault(); ev.stopPropagation(); } }, true);
  window.qoshaOnScreen = function () { try { var w = homeWindow(); return w && typeof w.qoshaOnScreen === 'function' ? w.qoshaOnScreen() : null; } catch (e) { return null; } };
  window.qoshaHomeRefresh = function () { try { var w = homeWindow(); if (w && typeof w.qoshaRefresh === 'function') w.qoshaRefresh(); } catch (e) { /* Home reads again by itself */ } };
  function SideChat() {
    var e = React.createElement, useState = React.useState, useEffect = React.useEffect, useRef = React.useRef;
    var p0 = sidePrefs();
    var wideNow = function () { return window.innerWidth >= SIDE.narrow; };
    // folded the first time on every window size (Ren, 22 Nov 2026 ~21:05); after that, what the person last chose
    var st = useState(p0.open === null ? false : p0.open), open = st[0], setOpen = st[1];
    var sb = useState(sideBadge), badge = sb[0]; badgeSet = sb[1];
    var sw = useState(p0.width), width = sw[0], setWidth = sw[1];
    var ss = useState(panelSrc()), src = ss[0], setSrc = ss[1];
    var sn = useState(wideNow()), roomy = sn[0], setRoomy = sn[1];
    // the narrow window's drawer: never remembered open, except right after the chat page's Dock on Home (GPT hc-r1 H6)
    var sd = useState(function () { return !wideNow() && p0.dock > Date.now() - 15000 && p0.dock <= Date.now(); }), drawer = sd[0], setDrawer = sd[1];
    var frame = useRef(null);
    useEffect(function () { if (p0.dock) saveSide({}); }, []);   // the Dock mark is used once (Gemini hc-r2 N1)
    var wasDrawer = useRef(false);   // a drawer open from the start (Dock on Home) also gets the keyboard (GPT hc-r2 H5)
    // the drawer is a dialog: opening it moves the keyboard into it, closing it puts the keyboard back on the Ask Qosha
    // button (Gemini hc-r1 H3)
    useEffect(function () {
      if (roomy || drawer === wasDrawer.current) { wasDrawer.current = drawer; return; }
      wasDrawer.current = drawer;
      setTimeout(function () {
        var to = drawer ? document.querySelector('.qosha-side-drawer .qosha-side-btn[aria-label="Close the chat"]') : document.querySelector('.qosha-side-fab');
        if (to && to.focus) to.focus();
      }, 0);
    }, [drawer, roomy]);
    useEffect(function () {
      var onResize = function () { setRoomy(wideNow()); setWidth(function (w) { return Math.min(sideMax(), w); }); };
      window.addEventListener('resize', onResize);
      return function () { window.removeEventListener('resize', onResize); };
    }, []);
    var fold = function (v) {
      var sid = frame.current ? panelSession(frame.current) : '';
      saveSide(sid ? {open: v, session: sid} : {open: v});
      setOpen(v);
    };
    var toggle = function () { if (roomy) fold(!open); else setDrawer(!drawer); };
    useEffect(function () {
      sideApi = {take: function (url) {
        if (!/^\/chat\?new=1(?:&|$)/.test(url)) return false;
        if (roomy) { saveSide({open: true}); setOpen(true); } else setDrawer(true);
        setSrc(panelSrc('new=1&n=' + Date.now()));   // a fresh load takes the question from session storage
        return true;
      }, fold: fold, toggle: toggle, escape: function () { if (!roomy && drawer) { setDrawer(false); return true; } return false; }};
      return function () { sideApi = null; };
    });

    var big = !roomy || width >= sideMax() - 8;   // a narrow window's drawer has no bigger step: Expand opens the chat page (review R)
    var expand = function () {   // first a big view at 3/4 of the window; from there, the full chat page
      if (!big) { var w = sideMax(); setWidth(w); saveSide({width: w}); return; }
      var sid = frame.current ? panelSession(frame.current) : '';
      if (sid) saveSide({session: sid});
      var go = window.qoshaGo || function (u) { window.location.href = u; };
      go(sid ? '/chat?session=' + encodeURIComponent(sid) : '/chat');
    };
    var drag = function (ev) {
      ev.preventDefault();
      var x0 = ev.clientX, w0 = width, cover = document.createElement('div');
      cover.className = 'qosha-side-cover';            // the frames below must not swallow the pointer while dragging
      document.body.appendChild(cover);
      var move = function (m) { setWidth(Math.min(sideMax(), Math.max(SIDE.min, Math.round(w0 + (x0 - m.clientX))))); };
      var up = function (m) {
        window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); cover.remove();
        saveSide({width: Math.min(sideMax(), Math.max(SIDE.min, Math.round(w0 + (x0 - m.clientX))))});
      };
      window.addEventListener('pointermove', move); window.addEventListener('pointerup', up);
    };
    var keyResize = function (ev) {
      var d = ev.key === 'ArrowLeft' ? 16 : ev.key === 'ArrowRight' ? -16 : 0;
      if (!d) return;
      ev.preventDefault();
      var w = Math.min(sideMax(), Math.max(SIDE.min, width + d));
      setWidth(w); saveSide({width: w});
    };
    var home = e('iframe', {title: 'Qosha Control Center', src: viewSrc(), className: 'qosha-side-home'});
    var bar = function (closeLabel, onClose) {
      return e('div', {className: 'qosha-side-bar'},
        e('span', {className: 'qosha-side-name'}, 'Qosha'),
        e('button', {type: 'button', className: 'qosha-side-btn', title: big ? 'Open the full chat page' : 'Make the chat bigger', 'aria-label': big ? 'Open the full chat page' : 'Make the chat bigger', onClick: expand},
          e('svg', {viewBox: '0 0 24 24', 'aria-hidden': 'true'}, e('path', {d: 'M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7'}))),
        e('button', {type: 'button', className: 'qosha-side-btn', title: closeLabel, 'aria-label': closeLabel, onClick: onClose},
          e('svg', {viewBox: '0 0 24 24', 'aria-hidden': 'true'}, e('path', {d: 'm9 6 6 6-6 6'}))));
    };
    // one tree for every layout: the chat frame keeps its place (the last child of the aside), so folding, opening and
    // crossing 900 px never reload it and the conversation on screen stays (GPT hc-r1 H6)
    var mode = roomy ? (open ? 'panel' : 'strip') : 'drawer';
    // the chat page loads the first time the chat is shown (a panel kept folded loads nothing), then stays loaded
    var shownNow = mode === 'panel' || (mode === 'drawer' && drawer);
    var se = useState(shownNow), everShown = se[0], setEverShown = se[1];
    useEffect(function () { if (shownNow && !everShown) setEverShown(true); }, [shownNow, everShown]);
    var chat = everShown || shownNow
      ? e('iframe', {title: 'Qosha chat', src: src, ref: frame, className: 'qosha-side-frame', hidden: mode === 'strip'}) : null;
    var asideProps = mode === 'panel' ? {className: 'qosha-side-panel', style: {width: width + 'px'}, 'aria-label': 'Qosha chat'}
      : mode === 'strip' ? {className: 'qosha-side-strip', 'aria-label': 'Qosha chat, folded'}
      : {className: 'qosha-side-drawer', hidden: !drawer, 'aria-label': 'Qosha chat', role: 'dialog', 'aria-modal': 'true'};
    var aside = e('aside', asideProps,
      mode === 'panel' ? e('div', {className: 'qosha-side-grip', role: 'separator', 'aria-orientation': 'vertical', 'aria-label': 'Chat width',
                                   'aria-valuemin': SIDE.min, 'aria-valuemax': sideMax(), 'aria-valuenow': width, tabIndex: 0,
                                   onPointerDown: drag, onKeyDown: keyResize}) : null,
      mode === 'panel' ? bar('Fold the chat', function () { fold(false); })
        : mode === 'drawer' ? bar('Close the chat', function () { setDrawer(false); }) : null,
      mode === 'strip' ? e('button', {type: 'button', className: 'qosha-side-open', title: 'Open the chat (' + (IS_MAC ? '\u2318J' : 'Ctrl+J') + ')',
                                       'aria-label': 'Open the chat' + (badge ? ', ' + badge + ' waiting for you' : ''), onClick: function () { fold(true); }},
                           e('img', {src: TILE, alt: '', width: 28, height: 28, className: 'qosha-side-tile'}),
                           badge ? e('span', {className: 'qosha-side-dot', 'aria-hidden': 'true'}) : null) : null,
      mode === 'strip' ? e('span', {className: 'qosha-side-key', 'aria-hidden': 'true'}, IS_MAC ? '\u2318J' : 'Ctrl J') : null,
      chat);
    return e('div', {className: 'qosha-side'}, home,
      roomy ? null : e('button', {type: 'button', className: 'qosha-side-fab', hidden: drawer, onClick: function () { setDrawer(true); }}, 'Ask Qosha'),
      roomy ? null : e('div', {className: 'qosha-side-scrim', hidden: !drawer, onClick: function () { setDrawer(false); }}),
      aside);
  }
  function QoshaTab() {
    if (viewName() === 'home' && sideOn()) return React.createElement(SideChat, null);
    return React.createElement('iframe', {
      title: 'Qosha Control Center',
      src: viewSrc(),
      style: {width: '100%', height: '100vh', border: 0, display: 'block', background: 'transparent'}
    });
  }
  registry.register('qosha', QoshaTab);

  // Qosha is the home screen (manifest tab.override "/"). When the browser asked for "/", the dashboard sends it to
  // /sessions before plugin manifests have loaded, and the Dock app opens /qosha, which has no route of its own once
  // "/" is overridden. Both land on the home screen instead. A /sessions the person asked for (typed, bookmarked or
  // opened in a new tab) stays /sessions (Gemini R-brand).
  // the engine's own text-screen chat draws its banner (the engine's name and its maker's) on a canvas no page rule can
  // reach (GPT R-nh1 1): it is not part of Qosha; its address opens Qosha's Chat instead (the same conversation)
  function engineTerminal() {
    return window.location.pathname.replace(/\/+$/, '') === '/chat' && /(?:^|[?&])advanced=1(?:&|$)/.test(window.location.search);
  }
  // the engine's Profiles page (1.20.4): a profile made there without cloning runs without Qosha's approval guard, so
  // it is not offered until profiles are made Qosha-safe; its address opens Settings instead
  function engineProfiles() { return /^\/profiles\/?$/.test(window.location.pathname); }
  // /config, the engine's raw settings editor, and anything under it: Settings instead (slice 2, Gemini V2-2)
  function engineConfig() {          // the router's own rules: any case, percent-encoded letters (round 2, GPT V2-2)
    var seg = (window.location.pathname.split('/')[1] || '');   // only the first segment decides (Gemini F4)
    try { seg = decodeURIComponent(seg); } catch (e) {}
    return /^config(?:\/|$)/.test(seg.toLowerCase());   // an encoded slash too: /config%2Fraw (GPT F4)
  }
  function toSettings() {
    window.history.replaceState(window.history.state, '', '/?view=settings');
    window.dispatchEvent(new PopStateEvent('popstate', {state: window.history.state}));
  }
  function leaveEngineTerminal() {
    var q = window.location.search.replace(/^\?/, '').split('&').filter(function (x) { return x && !/^advanced=/.test(x); }).join('&');
    window.history.replaceState(window.history.state, '', '/chat' + (q ? '?' + q : '') + window.location.hash);
    window.dispatchEvent(new PopStateEvent('popstate', {state: window.history.state}));
  }
  try {
    var path = window.location.pathname, asked = null;
    try { asked = new URL((window.performance.getEntriesByType('navigation')[0] || {}).name || window.location.href); } catch (e) { asked = null; }
    // /docs is the engine maker's own online documentation under its name (Ren, 3 Nov 21:46): Settings instead.
    // /config, the engine's raw settings editor, shows its internal names (e.g. "hermes-cli"): Settings instead, where a
    // person asks Qosha to change any setting (orchestrator for Ren, 22 Nov 2026, option A)
    if (engineTerminal()) {
      leaveEngineTerminal();
    } else if (path === '/docs' || path === '/docs/' || engineProfiles() || engineConfig()) {
      window.history.replaceState(window.history.state, '', '/?view=settings');
      window.dispatchEvent(new PopStateEvent('popstate', {state: window.history.state}));
    } else if (path === '/qosha' || path === '/qosha/' || (path === '/sessions' && asked && asked.pathname === '/')) {
      // keep what the browser asked for (e.g. /?view=settings): the dashboard's own redirect dropped it
      var search = asked && asked.pathname === '/' ? asked.search : window.location.search;
      window.history.replaceState(window.history.state, '', '/' + search + window.location.hash);
      window.dispatchEvent(new PopStateEvent('popstate', {state: window.history.state}));
    }
  } catch (e) { /* stay where the dashboard put us */ }
  // in-app navigation (a link, Back or Forward) to /config goes to Settings too
  window.addEventListener('popstate', function () { try { if (engineConfig()) toSettings(); } catch (e) {} });
  ['pushState', 'replaceState'].forEach(function (k) {
    var orig = window.history[k];
    window.history[k] = function () {
      var r = orig.apply(this, arguments);
      try { if (engineConfig()) setTimeout(toSettings, 0); } catch (e) {}
      return r;
    };
  });

  // Qosha on screen, never the upstream name (UAT 2 Nov; CLAUDE.md naming rule). The dashboard shell is upstream code, so
  // the lab copy rebrands what it shows: visible text and labels, the tab title, the brand (qosha-shell.css draws the
  // Qosha lockup), and hides what belongs to the upstream project (its updater and online docs). Real interfaces
  // (the upstream command, its home folder, its environment variables) are lower-case or upper-case and stay as they are, and
  // nothing inside code, logs, inputs or editors is changed.
  var root = document.documentElement;
  root.classList.add('qosha-shell');
  function applyTheme(t) { root.classList.toggle('qosha-dark', t === 'dark'); }
  try { applyTheme(window.localStorage.getItem('qosha.theme')); } catch (e) { /* default: light */ }
  window.addEventListener('message', function (ev) {
    // the home page's menu button on phones opens the side panel (the engine's own button sits in the hidden bar)
    if (ev.origin === window.location.origin && ev.data && ev.data.qoshaMenu === true) {
      var menu = document.querySelector('#root header.fixed button');
      if (menu) menu.click();
      return;
    }
    if (ev.origin !== window.location.origin || !ev.data || typeof ev.data.qoshaTheme !== 'string') return;
    applyTheme(ev.data.qoshaTheme);
    // and on to the owner page, if one is open
    var f = ownerBox && ownerBox.firstChild;
    try { if (f && f.contentWindow && f.contentWindow !== ev.source) f.contentWindow.postMessage({qoshaTheme: ev.data.qoshaTheme}, window.location.origin); }
    catch (e) { /* not loaded yet: it reads the saved theme itself */ }
  });

  // The engine's name never on screen, in any form (Ren, 3 Nov 21:46: "there cannot be no [engine] reference
  // whatsoever"): visible text, also code, commands, log lines and paths; labels, tooltips, placeholders and what a
  // screen reader says. The words are written with escapes, so the page's own files don't carry them either.
  // Paths name the real Qosha folder. The engine maker's own services keep a neutral name, never Qosha's (they are not
  // Qosha's: honest claims). Left as they are: what the person types or edits (fields, editors) and the names of the
  // person's own files in the file browser.
  var SKIP = /^(TEXTAREA|INPUT|SCRIPT|STYLE|NOSCRIPT|IFRAME)$/;
  var H = 'h\u0065rmes', N = 'n\u006fus', HOME = 'Qosha\u2019s home folder';
  try {
    window.fetch('/api/status', {credentials: 'same-origin'}).then(function (r) { return r.ok ? r.json() : null; }).then(function (d) {
      var h = d && d[H + '_home'];
      if (typeof h === 'string' && /^\/[^\0]*$/.test(h) && !HAS.test(h)) HOME = h.replace(/^\/Users\/[^\/]+/, '~');
    }, function () { /* the standard place */ });
  } catch (e) { /* the standard place */ }
  function cased(word, like) {
    if (like === like.toUpperCase() && like !== like.toLowerCase()) return word.toUpperCase();
    return like.charAt(0) === like.charAt(0).toUpperCase() ? word.charAt(0).toUpperCase() + word.slice(1) : word;
  }
  var RULES = [
    // an address on the engine maker's site, or naming the engine: only a neutral host stays
    [new RegExp('https?://[^\\s"\'<>)]*(?:' + H + '|' + N + ')[^\\s"\'<>)]*', 'gi'), function (u) {
      var host = u.replace(/^https?:\/\//i, '').split(/[\/?#]/)[0];
      return new RegExp(H + '|' + N, 'i').test(host) ? 'the upstream website' : host + '/\u2026';
    }],
    [new RegExp('\\b' + H + '\\s+v?unknown\\b', 'gi'), function (m) { return cased('qosha', m); }],
    [/\bvunknown\b/g, function () { return ''; }],
    // the engine's own terminal commands don't exist for a Qosha customer: Qosha does it when asked in the chat
    [new RegExp('`?\\b' + H + '\\s+(?:auth\\s+add|auth|portal|login|logout|setup|model|update|pm|plugins?|tools|mcp|gateway|config|doctor)\\b[^`\\n.;)]*`?', 'gi'), function () { return 'ask Qosha in the chat'; }],
    [new RegExp('~/\\.' + H + '(?![A-Za-z0-9_])', 'gi'), function () { return HOME; }],
    [new RegExp('\\$\\{?' + H + '_HOME\\}?', 'gi'), function () { return HOME; }],
    // the engine maker's own models (e.g. "<maker>/<engine>-4-405b", "<engine> 3 70B") are not Qosha's: a neutral name
    [new RegExp('\\b' + N + ' ?research/' + H + '[- ]?', 'gi'), function () { return 'upstream/model-'; }],
    [new RegExp('\\b(?:' + N + '[- :]+)?' + H + '[- ]?(?=\\d)', 'gi'), function (m) { return cased('upstream model ', m); }],
    // who the assistant is: Qosha, by Qosha AI (only there: the maker's own models and services are never Qosha's)
    [new RegExp('\\b(I am|I\'m|I’m|you are|you\'re|you run on|this is|running on|runs on)\\s+' + H + '(?:[\\s_-]*agent)?,?\\s+\\(?(?:(?:built|made|created)\\s+)?by\\s+' + N + ' ?research\\)?', 'gi'),
     function (m, who) { return who + ' Qosha by Qosha AI'; }],
    // the engine's own docs and its program's module name (log lines) are the engine's, never Qosha's
    [new RegExp(H + '[\\s_-]*(?:agent[\\s_-]*)?(docs|documentation)\\b', 'gi'), function () { return 'upstream docs'; }],
    [new RegExp(H + '_cli\\b', 'gi'), function () { return 'engine'; }],
    [new RegExp(H + ' agent\\b', 'gi'), function (m) { return cased('qosha', m); }],
    [new RegExp('\\bthe ' + H + ' team\\b', 'gi'), function () { return 'the upstream team'; }],
    [new RegExp('@?(?<![A-Za-z])' + N + '[-_ ]?research\\b', 'gi'), function () { return 'the upstream project'; }],
    [new RegExp('(?<![A-Za-z])' + N + '[-_ ]?portal\\b', 'gi'), function (m) { return cased('engine portal', m); }],
    [new RegExp('\\b' + N + '-approved\\b', 'gi'), function (m) { return cased('curated', m); }],
    [new RegExp('(?<![A-Za-z])' + N + '[-_ ](?=[A-Za-z])', 'gi'), function () { return ''; }],
    [new RegExp('(?<![A-Za-z])' + N + '(?![A-Za-z])', 'gi'), function (m) { return cased('portal', m); }],
    [new RegExp(H, 'gi'), function (m) { return cased('qosha', m); }],
    [/\u2624/g, function () { return ''; }]];
  var HAS = new RegExp(H + '|(?<![A-Za-z])' + N + '|\u2624', 'i');
  // what a settings field is tested with (fixField): the engine's own name only, as before CONTRACT G1. The names added
  // just below are for text a person reads; a field whose value happens to hold one of them (a folder a person typed,
  // say) keeps its row (GPT review R8).
  var HAS_IN_FIELD = HAS;
  // >>> engine-acp-name (CONTRACT G1; tests/c18_engine_name_gate.py --log-control takes this block out)
  // The engine's ACP provider is the path Gemini runs through in a cloud Qosha, and the engine's own words name it
  // (log lines on the Logs page, labels, error texts). They are shown as Gemini's by the same display rules as the
  // engine's name above: added to the same list (RULES) and to the same test (HAS), so they apply to exactly the same
  // places (text a person reads and its labels; never what a person types, never what is sent back):
  //   the id, separator kept, also inside longer names:   co\u2026-acp -> gemini-relay,   co\u2026_acp -> gemini_relay
  //   the name, with or without "GitHub", brackets or a space:   "Co\u2026 ACP", "GitHub Co\u2026 (ACP)", "Co\u2026ACP\u2026" -> Gemini
  // The bare word is left alone: it is the engine's unrelated provider (on a desktop its account row is not shown,
  // see engine-account-card below).
  (function () {
    var C = 'copilot';
    RULES.push(
      [new RegExp('(?:github[\\s_-]*)?' + C + '\\s*\\(acp\\)', 'gi'), function () { return 'Gemini'; }],
      // the id keeps its separator and its case (an upper-case ACP beside a capitalised name follows the name)
      [new RegExp('(' + C + ')([-_])(acp)', 'gi'), function (m, a, sep, b) {
        return cased('gemini', a) + sep + cased('relay', b === b.toUpperCase() && a !== a.toUpperCase() ? a : b);
      }],
      [new RegExp('(?:github\\s+)?' + C + '\\s*acp', 'gi'), function () { return 'Gemini'; }]);
    HAS = new RegExp(HAS.source + '|' + C + '[\\s_-]*\\(?acp', 'i');
  })();
  // local installs (17 Nov): wording a customer must not see on the engine's own pages (visual QA MED 9)
  RULES.push(
    [/\bv?unknown\b(?=\s*$)/g, function () { return ''; }],
    // np19 (22 Nov 2026, council GPT/Gemini): the old text claimed an account of Qosha's that does not exist; this is
    // the engine maker's own provider account, which Qosha does not offer
    [/Engine portal[^\n]{0,40}not logged in/gi, function () { return 'This provider is not offered in Qosha'; }],
    [/Manage subscription/g, function () { return ''; }],
    [/Log in with\s+ask Qosha in the chat/gi, function () { return 'To sign in to an AI account, use Chat'; }],
    [/Couldn.t reach the update source/gi, function () { return 'Updates come from Qosha'; }]);
  HAS = new RegExp(HAS.source + '|\\bvunknown\\b|Manage subscription|update source|Engine portal', 'i');
  // <<< engine-acp-name
  function rebrand(text) {
    for (var i = 0; i < RULES.length; i++) text = text.replace(RULES[i][0], RULES[i][1]);
    return text;
  }
  // >>> person-words (Ren, 18 Nov 2026: "users should be able to type any word they want, including hermes")
  // What the person wrote and what the assistant answered are shown as written on the engine's pages too: a chat's
  // title (made from the person's words), its preview and its messages. The engine's own sessions API says which
  // texts those are: every title and message text this page receives from /api/sessions... is recorded, and text on
  // screen that is one of them (a title, also cut short with "…", or a long enough piece of a message) is never
  // renamed; text renamed before its record arrived is put back. Qosha's chrome and the engine's own words still are.
  var OWN = {titles: Object.create(null), list: [], texts: [], done: []};
  function ownNorm(s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); }
  function isOwn(v) {
    var n = ownNorm(v);
    if (!n) return false;
    if (OWN.titles[n]) return true;
    var cut = n.replace(/(?:\u2026|\.\.\.)$/, '').trim(), i;
    if (cut !== n && cut.length >= 3) for (i = 0; i < OWN.list.length; i++) if (OWN.list[i].indexOf(cut) === 0) return true;
    if (cut.length >= 16) for (i = 0; i < OWN.texts.length; i++) if (OWN.texts[i].indexOf(cut) >= 0) return true;
    return false;
  }
  var OWN_TITLE = {title: 1, preview: 1}, OWN_TEXT = {content: 1, text: 1, preview: 1, snippet: 1};
  function ownFrom(data) {
    var added = 0;
    (function walk(x, depth) {
      if (!x || typeof x !== 'object' || depth > 6) return;
      if (Array.isArray(x)) { for (var i = 0; i < x.length && i < 2000; i++) walk(x[i], depth + 1); return; }
      Object.keys(x).forEach(function (k) {
        var v = x[k];
        if (typeof v === 'string') {
          var n = ownNorm(v);
          if (!n || !HAS.test(n)) return;      // only text the rename rules would touch needs a record
          if (OWN_TITLE[k] && !OWN.titles[n]) { OWN.titles[n] = 1; OWN.list.push(n); added++; }
          if (OWN_TEXT[k] && n.length >= 16 && OWN.texts.indexOf(n) < 0 && n.length < 50000) { OWN.texts.push(n); added++; }
        } else walk(v, depth + 1);
      });
    })(data, 0);
    if (OWN.list.length > 2000) { OWN.list.splice(0, OWN.list.length - 2000); OWN.titles = Object.create(null); OWN.list.forEach(function (n) { OWN.titles[n] = 1; }); }
    if (OWN.texts.length > 400) OWN.texts.splice(0, OWN.texts.length - 400);
    if (!added) return;
    // what was renamed before the record arrived is put back (only where the page still shows our renamed text)
    OWN.done = OWN.done.filter(function (r) {
      if (!r.node.isConnected || r.node.nodeValue !== r.now) return false;
      if (!isOwn(r.was)) return true;
      r.node.nodeValue = r.was;
      return false;
    });
  }
  (function () {
    var f = window.fetch;
    if (typeof f !== 'function' || f.qoshaOwn) return;
    var w = function (input) {
      var p = f.apply(this, arguments);
      try {
        var url = typeof input === 'string' ? input : (input && input.url) || '';
        if (/\/api\/sessions(?:[\/?]|$)/.test(url.split('#')[0])) {
          p.then(function (r) { if (r && r.ok) r.clone().json().then(ownFrom, function () {}); }, function () {});
        }
      } catch (e) { /* not a sessions read */ }
      return p;
    };
    w.qosha = f.qosha; w.qoshaOwn = true;
    window.fetch = w;
    // the chats already listed before this page script ran
    try {
      var tok = window.__HERMES_SESSION_TOKEN__;
      if (tok) w('/api/sessions?limit=200&offset=0&order=recent', {headers: {'X-Hermes-Session-Token': tok}, credentials: 'same-origin'}).catch(function () {});
    } catch (e) { /* the next list read records them */ }
  })();
  // <<< person-words
  // Channels > Telegram creates the person's bot under the engine's name unless told otherwise: it is Qosha's
  (function () {
    var f = window.fetch;
    if (typeof f !== 'function' || f.qosha) return;
    var wrapped = function (input, init) {
      try {
        var url = typeof input === 'string' ? input : (input && input.url) || '';
        if (/\/api\/messaging\/telegram\/onboarding\/start$/.test(url.split('?')[0]) && init && typeof init.body === 'string') {
          var b = JSON.parse(init.body);
          // only the engine's own default name (or none): a name the person typed is theirs
          if (b && typeof b === 'object' && (!b.bot_name || String(b.bot_name).trim().toLowerCase() === H + ' agent')) {
            b.bot_name = 'Qosha';
            init = Object.assign({}, init, {body: JSON.stringify(b)});
          }
        }
      } catch (e) { /* not ours to change */ }
      return f.call(this, input, init);
    };
    wrapped.qosha = true;
    window.fetch = wrapped;
  })();
  // what the engine hands the person outside the page: a saved file's name (e.g. its config export) and the words of
  // a native dialog. Not a copied text: that is pasted as it is (a setting's real name, a command), so it stays real.
  (function () {
    var A = window.HTMLAnchorElement && window.HTMLAnchorElement.prototype;
    if (A && typeof A.click === 'function' && !A.click.qosha) {
      var click = A.click;
      var named = function () {
        try {
          // the person's own files keep their real names (the file browser)
          if (this.download && HAS.test(this.download) && window.location.pathname.replace(/\/+$/, '') !== '/files') this.download = rebrand(this.download);
        } catch (e) { /* saved as named */ }
        return click.apply(this, arguments);
      };
      named.qosha = true;
      A.click = named;
    }
    ['alert', 'confirm', 'prompt'].forEach(function (k) {
      var f = window[k];
      if (typeof f !== 'function' || f.qosha) return;
      var w = function (msg) {
        var args = Array.prototype.slice.call(arguments);
        if (typeof msg === 'string') args[0] = rebrand(msg);
        return f.apply(window, args);
      };
      w.qosha = true;
      window[k] = w;
    });
  })();
  // own: the element's own tag doesn't count (a field's placeholder is a label, its value is the person's)
  function skipped(el, own) {
    for (var n = el; n && n !== document.body; n = n.parentElement) {
      if ((!own || n !== el) && SKIP.test(n.tagName)) return true;
      if (n.isContentEditable || (n.classList && (n.classList.contains('cm-editor') || n.classList.contains('monaco-editor')))) return true;
      if (n.hasAttribute && n.hasAttribute('data-qosha-engine-account')) return true;   // the engine's hidden account row: left as it is
    }
    return false;
  }
  function fixText(node) {
    var v = node.nodeValue;
    if (!v || !HAS.test(v)) return;
    if (!node.parentElement || skipped(node.parentElement)) return;
    if (engineAccountText(node)) return;   // the engine's own account row on a desktop: hidden, not renamed
    if (isOwn(v)) return;                  // the person's or the assistant's words (person-words)
    var nv = rebrand(v);
    if (nv === v) return;
    OWN.done.push({node: node, was: v, now: nv});
    if (OWN.done.length > 600) OWN.done.splice(0, OWN.done.length - 600);
    // an option without a value attribute submits its text: keep what it submits
    var o = node.parentElement.closest('option');
    if (o && !o.hasAttribute('value')) o.setAttribute('value', o.value);
    node.nodeValue = nv;
  }
  var ATTRS = ['title', 'aria-label', 'aria-description', 'aria-valuetext', 'placeholder', 'alt'];
  function fixAttrs(el) {
    if (!el.getAttribute || skipped(el, true)) return;
    ATTRS.forEach(function (a) {
      var v = el.getAttribute(a);
      if (!v || !HAS.test(v) || isOwn(v)) return;
      var nv = rebrand(v);
      if (nv !== v) el.setAttribute(a, nv);   // only real changes: never an endless loop of identical writes
    });
  }
  function fixShell() {
    if (engineTerminal()) leaveEngineTerminal();
    if (engineProfiles()) {
      window.history.replaceState(window.history.state, '', '/?view=settings');
      window.dispatchEvent(new PopStateEvent('popstate', {state: window.history.state}));
    }
    document.querySelectorAll('a[href^="/profiles"]').forEach(function (a) {   // the engine's own menu entry too
      if (/^\/profiles\/?(?:[?#]|$)/.test(a.getAttribute('href') || '') && a.style.display !== 'none') {
        a.style.display = 'none'; a.setAttribute('data-qosha-hidden', 'profiles');
      }
    });
    // the System page's engine console (its prompt and title name the engine, drawn in a terminal): not offered
    if (window.location.pathname.replace(/\/+$/, '') === '/system') {
      document.querySelectorAll('main button').forEach(function (b) {
        if ((b.textContent || '').trim() === 'Open console' && !b.hasAttribute('data-qosha-engine-value')) b.setAttribute('data-qosha-engine-value', '');
      });
    }
    // the brand's second line ("Agent") and the upstream-only items
    // the brand spans show the Qosha lockup (CSS); for assistive technology they are one image named Qosha
    document.querySelectorAll('#app-sidebar > div:first-child > div:first-child > span:first-child, #root header.fixed > span').forEach(function (b) {
      if (b.getAttribute('role') !== 'img') b.setAttribute('role', 'img');
      if (b.getAttribute('aria-label') !== 'Qosha') b.setAttribute('aria-label', 'Qosha');
    });
    sidePanel();
    // text is changed on the dashboard's own text nodes (never replaced), so its later updates still land
    function setText(el, text) {
      var n = el && el.firstChild;
      if (n && n.nodeType === 3 && n.nodeValue !== text) n.nodeValue = text;
    }
    document.querySelectorAll('#app-sidebar .font-mono-ui').forEach(function (v) {
      if (/^v\d/.test((v.textContent || '').trim())) setText(v, 'qosha lab');
    });
    var home = window.location.pathname === '/';
    root.classList.toggle('qosha-home', home);
    // the home screen brings its own top bar (with a menu button on phones): no second bar above it (Gemini R-v6pages)
    root.classList.toggle('qosha-homeview', home && viewName() === 'home');
    // Back/Forward between Home and Settings: the page inside follows the address (without a history entry)
    var frame = document.querySelector('iframe[title="Qosha Control Center"]');
    if (frame && home) {
      try {
        var want = viewSrc();
        if (frame.contentWindow && frame.contentWindow.location.pathname + frame.contentWindow.location.search !== want) frame.contentWindow.location.replace(want);
      } catch (e) { /* not loaded yet */ }
    }
    var h1 = document.querySelector('header[role="banner"] h1');
    if (h1 && h1.firstChild && h1.firstChild.nodeType === 3) {
      // the dashboard titles "/" "Sessions"; we show "Home" there and give its own title back elsewhere, because
      // the dashboard won't rewrite a title it believes is already on screen (Gemini R-brand)
      if (home && h1.firstChild.nodeValue !== 'Home') { if (!h1.dataset.qoshaWas) h1.dataset.qoshaWas = h1.firstChild.nodeValue; setText(h1, 'Home'); }
      else if (!home && h1.firstChild.nodeValue === 'Home' && h1.dataset.qoshaWas) setText(h1, h1.dataset.qoshaWas);
    }
    var name = NAMES[window.location.pathname.replace(/\/+$/, '')];
    if (h1 && h1.firstChild && h1.firstChild.nodeType === 3 && name && h1.firstChild.nodeValue !== name) {
      // the engine's own page (opened from Settings) under its Qosha name: Conversations, Automations, Tasks
      setText(h1, name);
    }
    var title = home ? ({settings: 'Qosha · Settings', projects: 'Qosha · Projects', skills: 'Qosha · Skills', connections: 'Qosha · Connections'}[viewName()] || 'Qosha') : (name ? 'Qosha · ' + name : 'Qosha');
    if (waitingN > 0) title = '(' + waitingN + ') ' + title;   // something waits for the person: "(1) Qosha"
    if (document.title !== title) document.title = title;
    ownerPage();
  }
  // ---- owner pages (UAT 2 Nov 10:43/10:48, council C8): Chat, Conversations, Files, Automations and Tasks are Qosha
  // pages drawn over the main area; the engine's page stays mounted underneath, hidden, and opens as it is with
  // ?advanced=1 (linked from Settings). The engine's chat terminal, prune/import, lanes, blueprints etc. live there.
  var PAGES = {'/chat': 'chat', '/sessions': 'conversations', '/files': 'files', '/cron': 'automations', '/kanban': 'tasks'};
  function advanced() { return /(?:^|[?&])advanced=1(?:&|$)/.test(window.location.search); }
  function ownerSrc(page, search) {
    // pass the page's own query on (e.g. /chat?session=…), never "advanced"
    var q = (typeof search === 'string' ? search : window.location.search).replace(/^\?/, '').split('&').filter(function (x) { return x && !/^advanced=/.test(x); }).join('&');
    return '/dashboard-plugins/qosha/pages/' + page + '.html' + (q ? '?' + q : '');
  }
  var ownerBox = null, ownerCol = null, ownerRO = null;
  function placeOwner() {
    if (!ownerBox || !ownerCol) return;
    var r = ownerCol.getBoundingClientRect();
    var st = ownerBox.style;
    var want = [Math.round(r.left) + 'px', Math.round(Math.max(r.top, 0)) + 'px', Math.round(r.width) + 'px', Math.round(r.height - Math.max(0, -r.top)) + 'px'];
    if (st.left !== want[0]) st.left = want[0];
    if (st.top !== want[1]) st.top = want[1];
    if (st.width !== want[2]) st.width = want[2];
    if (st.height !== want[3]) st.height = want[3];
  }
  // the engine page underneath is inert while Qosha's page covers it: no focus, no clicks, not read out (council C8)
  // what the element had before is kept and given back (GPT R-shell3)
  function under(col, on) {
    if (on) {
      if (col.getAttribute('data-qosha-under') !== '1') {
        col.setAttribute('data-qosha-was', JSON.stringify({inert: col.hasAttribute('inert') ? col.getAttribute('inert') : null,
                                                          hidden: col.hasAttribute('aria-hidden') ? col.getAttribute('aria-hidden') : null}));
        col.setAttribute('data-qosha-under', '1');
      }
      if (!col.hasAttribute('inert')) col.setAttribute('inert', '');
      if (col.getAttribute('aria-hidden') !== 'true') col.setAttribute('aria-hidden', 'true');
    } else if (col.hasAttribute('data-qosha-under')) {
      var was = {inert: null, hidden: null};
      try { was = JSON.parse(col.getAttribute('data-qosha-was')) || was; } catch (e) { /* none saved */ }
      if (was.inert === null) col.removeAttribute('inert'); else col.setAttribute('inert', was.inert);
      if (was.hidden === null) col.removeAttribute('aria-hidden'); else col.setAttribute('aria-hidden', was.hidden);
      col.removeAttribute('data-qosha-was');
      col.removeAttribute('data-qosha-under');
    }
  }
  function ownerPage() {
    var page = PAGES[window.location.pathname.replace(/\/+$/, '')];
    var on = !!page && !advanced();
    var main = document.querySelector('#root main');
    var col = main && main.parentElement;
    root.classList.toggle('qosha-owner', on && !!col);
    // the engine also draws some things straight under <body> (the mobile chat side panel, its backdrop): while
    // Qosha's page is up they are inert and hidden too, and given back for Advanced (GPT R-shell2)
    Array.prototype.forEach.call(document.body.children, function (el) {
      if (el.id === 'root' || el.id === 'qosha-splash' || el.id === 'qosha-connect-ai' || el.id === 'qosha-ai-top' || el.id === 'qosha-rclick' || el.id === 'qosha-rclick-hint' || el === ownerBox || /^(SCRIPT|STYLE|LINK|TEMPLATE)$/.test(el.tagName)) return;
      if (on && col) { if (el.getAttribute('data-qosha-under') !== '1') { el.setAttribute('data-qosha-portal', '1'); under(el, true); } }
      else if (el.hasAttribute('data-qosha-portal')) { el.removeAttribute('data-qosha-portal'); under(el, false); }
    });
    if (!on || !col) {
      if (ownerBox) ownerBox.hidden = true;
      if (ownerCol) under(ownerCol, false);
      return;
    }
    if (ownerCol !== col) {
      if (ownerCol) under(ownerCol, false);
      ownerCol = col;
      if (ownerRO) ownerRO.disconnect();
      if (window.ResizeObserver) { ownerRO = new window.ResizeObserver(function () { placeOwner(); }); ownerRO.observe(col); }
    }
    under(col, true);
    if (!ownerBox) {
      ownerBox = document.createElement('div');
      ownerBox.id = 'qosha-page';
      var f = document.createElement('iframe');
      f.title = 'Qosha page';
      ownerBox.appendChild(f);
      document.body.appendChild(ownerBox);
    }
    ownerBox.hidden = false;
    var frame = ownerBox.firstChild;
    var want = ownerSrc(page);
    if (frame.dataset.src !== want) {
      frame.dataset.src = want;
      frame.title = 'Qosha · ' + NAMES['/' + ({chat: 'chat', conversations: 'sessions', files: 'files', automations: 'cron', tasks: 'kanban'})[page]];
      // replace, not a new history entry: Back goes to the previous dashboard page
      try { if (frame.contentWindow && frame.getAttribute('src')) frame.contentWindow.location.replace(want); else frame.src = want; }
      catch (e) { frame.src = want; }
    }
    placeOwner();
  }
  // ---- side panel (UAT 2 Nov: "only what is necessary for the user"; SIDEPANEL-REVIEW.md) ----------------
  // Kept, with Qosha names: Home, Chat, Conversations, Files, Automations, Tasks, and Settings at the bottom. Everything
  // else the engine lists moves to Settings (still reachable by URL). The engine's own links keep doing the routing;
  // Home and Settings are Qosha's, in a group of their own next to the engine's list (never inside it).
  // UAT 10:51 (A), approved: one Chat item (past conversations sit beside the chat); Conversations moved to Settings
  // UAT 11:42: Home, Chat, Projects, Files, Automations, Tasks, Settings. Chat is drawn in Qosha's own top group (with
  // Home and Projects, in that order), never inserted into the engine's list; the engine's own Chat item is hidden.
  // Skills tab (3 Nov): Home, Chat, Projects, Files, Skills, Automations, Tasks, Connections, Settings. Files joins Qosha's
  // top group (the engine's own Files item is hidden like its Chat item) so Skills can sit right under it.
  // Connections tab (3 Nov 17:52): Connections moves up from the bottom to right under Skills (one entry):
  // Home, Chat, Projects, Files, Skills, Connections, Automations, Tasks, Settings.
  var KEEP = {'/cron': 'Automations', '/kanban': 'Tasks'};
  var NAMES = {'/chat': 'Chat', '/sessions': 'Conversations', '/files': 'Files', '/cron': 'Automations', '/kanban': 'Tasks'};
  var IN_SETTINGS = {'/sessions': true};
  var ICONS = {
    home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/>',
    chat: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    projects: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M8 13h8"/>',
    files: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
    skills: '<path d="M12 3l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.4 6.8 19.1l1-5.8L3.5 9.2l5.9-.9z"/>',
    connections: '<path d="M9 7V3"/><path d="M15 7V3"/><path d="M6 7h12v4a6 6 0 0 1-12 0z"/><path d="M12 17v4"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'
  };
  function settingsView() { return window.location.pathname === '/' && /(?:^|[?&])view=settings(?:&|$)/.test(window.location.search); }
  function go(url) {
    // the dashboard is a single-page app: change the address and let its router (and our iframe) follow
    window.history.pushState(window.history.state, '', url);
    window.dispatchEvent(new PopStateEvent('popstate', {state: window.history.state}));
    run();
  }
  function qoshaLink(id, label, url) {
    var a = document.createElement('a');
    a.className = 'qosha-navlink';
    a.href = url;
    a.dataset.qoshaNav = id;
    a.dataset.tip = label;
    a.setAttribute('aria-label', label);   // its name also when the rail hides the text (Gemini R-ui3)
    a.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" ' +
                  'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICONS[id] + '</svg><span>' + label + '</span>';
    a.addEventListener('click', function (ev) {
      if (ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.button !== 0) return;   // new tab etc.: the browser's way
      ev.preventDefault();
      go(url);
      // on a phone the panel is a drawer: close it like the engine's own links do (GPT R-shell2)
      var close = document.querySelector('#app-sidebar button[aria-label="Close navigation"]');
      if (close && close.offsetParent) close.click();
    });
    return a;
  }
  function group(cls, link, more) {
    var d = document.createElement('div');
    d.className = 'qosha-nav ' + cls;
    d.setAttribute('role', 'list');
    [link].concat(more || []).forEach(function (l) {
      var li = document.createElement('div');
      li.setAttribute('role', 'listitem');
      li.appendChild(l);
      d.appendChild(li);
    });
    return d;
  }
  var WIDE = window.matchMedia('(min-width: 1024px)');
  function sidePanel() {
    var aside = document.getElementById('app-sidebar');
    var nav = aside && aside.querySelector(':scope > nav');
    if (!aside || !nav) return;
    if (!aside.querySelector(':scope > .qosha-nav-top')) {
      aside.insertBefore(group('qosha-nav-top', qoshaLink('home', 'Home', '/'),
                               [qoshaLink('chat', 'Chat', '/chat'), qoshaLink('projects', 'Projects', '/?view=projects'),
                                qoshaLink('files', 'Files', '/files'), qoshaLink('skills', 'Skills', '/?view=skills'),
                                qoshaLink('connections', 'Connections', '/?view=connections')]), nav);
    }
    if (!aside.querySelector(':scope > .qosha-nav-bottom')) {
      nav.after(group('qosha-nav-bottom', qoshaLink('settings', 'Settings', '/?view=settings')));
    }
    var path = window.location.pathname.replace(/\/+$/, '') || '/';
    // the engine's list: keep five items under Qosha names, hide the rest (and its section headings)
    nav.querySelectorAll('li').forEach(function (li) {
      var a = li.querySelector('a[href]');
      var href = a && a.getAttribute('href');
      var keep = href && Object.prototype.hasOwnProperty.call(KEEP, href);
      li.classList.toggle('qosha-hidden', !keep);
      if (!keep) return;
      var label = a.querySelector('span');
      if (label && label.firstChild && label.firstChild.nodeType === 3 && label.firstChild.nodeValue !== KEEP[href]) label.firstChild.nodeValue = KEEP[href];
      if (a.dataset.tip !== KEEP[href]) a.dataset.tip = KEEP[href];
      if (a.getAttribute('aria-label') !== KEEP[href]) a.setAttribute('aria-label', KEEP[href]);
      var cur = path === href;
      if (cur && a.getAttribute('aria-current') !== 'page') a.setAttribute('aria-current', 'page');
      if (!cur && a.hasAttribute('aria-current')) a.removeAttribute('aria-current');
    });
    // section headings go; a section stays only if it still holds a kept item (Tasks lives in the plugins section)
    nav.querySelectorAll(':scope > :not(ul)').forEach(function (sec) {
      sec.classList.toggle('qosha-hidden', !sec.querySelector('li:not(.qosha-hidden)'));
      sec.querySelectorAll(':scope > :not(ul)').forEach(function (h) { h.classList.add('qosha-hidden'); });
      if (sec.classList.contains('border-t')) sec.classList.add('qosha-flat');
    });
    [['home', path === '/' && viewName() === 'home'], ['chat', path === '/chat'], ['projects', path === '/' && viewName() === 'projects'],
     ['files', path === '/files'], ['skills', path === '/' && viewName() === 'skills'], ['connections', path === '/' && viewName() === 'connections'],
     ['settings', settingsView() || !!IN_SETTINGS[path]]].forEach(function (x) {
      var a = aside.querySelector('[data-qosha-nav="' + x[0] + '"]');
      if (!a) return;
      if (x[1] && a.getAttribute('aria-current') !== 'page') a.setAttribute('aria-current', 'page');
      if (!x[1] && a.hasAttribute('aria-current')) a.removeAttribute('aria-current');
    });
    // the side panel opens and closes by itself (UAT 2 Nov): no collapse button. The engine's own button stays
    // in its markup but is hidden (CSS) and out of the keyboard order; the engine is held collapsed, so a saved
    // "expanded" choice from before can't leave anybody with the panel stuck open
    var btn = aside.querySelector('button[aria-label="Collapse"], button[aria-label="Expand"], button[data-qosha-collapse]');
    if (btn) {
      btn.dataset.qoshaCollapse = '1';
      if (btn.getAttribute('aria-hidden') !== 'true') btn.setAttribute('aria-hidden', 'true');
      if (btn.getAttribute('tabindex') !== '-1') btn.setAttribute('tabindex', '-1');
      // the engine marks its collapsed state with the class lg:w-14 (one click, then wait for it to re-render)
      if (!aside.classList.contains('lg:w-14') && !(Date.now() - (+btn.dataset.qoshaForced || 0) < 1500)) {
        btn.dataset.qoshaForced = String(Date.now());
        btn.click();
      }
    }
    try { window.localStorage.removeItem('qosha.panel'); } catch (e) { /* storage off */ }
    root.classList.add('qosha-rail');   // the rail exists only on wide screens (CSS); a phone keeps the drawer
    if (!WIDE.matches && root.classList.contains('qosha-peek')) root.classList.remove('qosha-peek');
    if (!aside.dataset.qoshaPeek) {
      aside.dataset.qoshaPeek = '1';
      // hover intent, one timer: the rail opens once the pointer has rested on it for 150 ms (a quick pass over it
      // does nothing) and closes 350 ms after the pointer leaves the open panel (coming back cancels the close);
      // scrolling over it counts as resting on it. Keyboard focus inside opens it at once; Escape or focus leaving
      // closes it. Opening never moves the page: the panel lies over it (CSS)
      var timer = 0, pending = null, byKeyboard = false;
      var isOpen = function () { return root.classList.contains('qosha-peek'); };
      var setOpen = function (on) { root.classList.toggle('qosha-peek', !!on && WIDE.matches); };
      var cancel = function () { window.clearTimeout(timer); timer = 0; pending = null; };
      var later = function (on, ms) {
        if (pending === on) return;
        cancel();
        pending = on;
        timer = window.setTimeout(function () {
          timer = 0; pending = null;
          if (!on || aside.matches(':hover')) setOpen(on);   // the pointer must still be resting on it
        }, ms);
      };
      var keyboardInside = function () { return !!aside.querySelector(':focus-visible'); };
      var rest = function () { if (isOpen()) cancel(); else later(true, 150); };
      aside.addEventListener('pointerenter', function (ev) { if (ev.pointerType !== 'touch') rest(); });
      // a trackpad keeps sending scroll events to the panel after the pointer has left it (GPT R-sp1): those don't count
      aside.addEventListener('wheel', function () { if (aside.matches(':hover')) rest(); }, {passive: true});
      aside.addEventListener('pointerleave', function () {
        if (!isOpen()) cancel();
        else if (!keyboardInside()) later(false, 350);
      });
      aside.addEventListener('focusin', function () { if (keyboardInside()) { byKeyboard = true; cancel(); setOpen(true); } });
      // keyboard focus leaving closes it, even with the mouse parked on it (GPT R-sp1); a mouse click that drops focus
      // while the pointer rests on the panel leaves it to the pointer
      aside.addEventListener('focusout', function (ev) {
        if (aside.contains(ev.relatedTarget)) return;
        var kb = byKeyboard;
        byKeyboard = false;
        if (!kb && aside.matches(':hover')) return;
        cancel(); setOpen(false);
      });
      aside.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') { cancel(); setOpen(false); } });
    }
  }
  // A page asks for another page (Home hands a question to Chat: /chat?new=1). The page inside is kept loaded while
  // another one shows, and it was reloaded only when the wanted address differed from the LAST wanted one. A second
  // question from Home wants the same /chat?new=1 again, so Chat was never loaded again and never took the question:
  // it was lost, and the person saw an empty or old chat (Ren, 15 Nov 2026; reproduced every time on the second
  // hand-over). So when a page asks for the very address the frame already holds, that page is loaded afresh.
  // Only then (16 Nov 2026, verification M2): a request for any other place leaves the kept page as it is, so a plain
  // return to it finds it as it was left (an unsent draft in Chat). A different page address loads by itself below.
  window.qoshaGo = function (url) {
    if (typeof url !== 'string' || url.charAt(0) !== '/' || url.charAt(1) === '/') return;
    // Home side chat: a question handed over from Home opens in the panel instead (when it is there and has room)
    if (sideApi && viewName() === 'home' && window.location.pathname.replace(/\/+$/, '') === '' && sideApi.take(url)) return;
    var m = /^([^?#]*)(\?[^#]*)?/.exec(url), search = m[2] || '';
    var page = PAGES[m[1].replace(/\/+$/, '')], frame = ownerBox && ownerBox.firstChild;
    if (page && frame && !/(?:^|[?&])advanced=1(?:&|$)/.test(search) && frame.dataset.src === ownerSrc(page, search)) frame.dataset.src = '';
    go(url);
  };
  window.addEventListener('popstate', function () { window.requestAnimationFrame(run); });
  // the dashboard's own links change the address without a popstate (e.g. /chat?advanced=1 → /chat): follow them too
  ['pushState', 'replaceState'].forEach(function (m) {
    var orig = window.history[m];
    if (typeof orig !== 'function' || orig.qosha) return;
    var wrapped = function () { var r = orig.apply(this, arguments); window.requestAnimationFrame(run); return r; };
    wrapped.qosha = true;
    window.history[m] = wrapped;
  });
  window.addEventListener('resize', function () { window.requestAnimationFrame(run); });
  window.addEventListener('scroll', function () { placeOwner(); }, true);

  // a settings field that holds one of the engine's own ids (e.g. its toolset name on the Config page): its row is not
  // shown while it holds one (first-paint.html hides [data-qosha-engine-value]); the value itself is never changed
  function fixField(input) {
    var row = input.closest && input.closest('.grid');
    if (!row || skipped(input, true)) return;
    var named = HAS_IN_FIELD.test(input.value || '');
    if (named !== row.hasAttribute('data-qosha-engine-value')) {
      if (named) row.setAttribute('data-qosha-engine-value', ''); else row.removeAttribute('data-qosha-engine-value');
    }
  }
  // >>> engine-account-card (CONTRACT G1; tests/c18_engine_name_gate.py --card-control takes this block out)
  // The engine's Keys page lists its own account "GitHub Copilot (ACP)": on a desktop that is an outside command-line
  // login Qosha doesn't use. That one row is not shown, with the command and the docs link that sit inside it. Only a
  // row whose name is exactly that, and only when it is one account's row in the engine's list; nothing else is
  // hidden. In a cloud Qosha the engine names that row "Gemini" (qosha_guard/gemini_chat.py), so it is shown there.
  // The row keeps the engine's own words while it is hidden (the display rules above skip it: skipped()), so it is
  // never shown under Gemini's name with the engine's command in it, and a row that no longer carries the name is
  // shown again. A tooltip inside the hidden row that names the account (its docs link's "Open … docs") is taken
  // off: a hidden link has no tooltip to show, and the engine writes it again if the row's name ever changes.
  var ENGINE_ACCOUNT = 'GitHub Copilot (ACP)';
  function accountRow(span) {
    // the account's row: the ancestor that sits directly in the engine's list of accounts, holding this one name only
    for (var n = span; n && n !== document.body; n = n.parentElement) {
      var list = n.parentElement;
      if (list && list.classList && list.classList.contains('divide-y')) return n.querySelectorAll('span.font-medium').length === 1 ? n : null;
    }
    return null;
  }
  function hideAccountRow(row) {
    if (!row.hasAttribute('data-qosha-engine-account')) { row.setAttribute('data-qosha-engine-account', ''); row.classList.add('qosha-hidden'); }
    row.querySelectorAll('[title]').forEach(function (t) { if (t.getAttribute('title').indexOf(ENGINE_ACCOUNT) >= 0) t.removeAttribute('title'); });
  }
  // a text that is exactly the account's name, in its row: the row is hidden before any display rule touches the name
  function engineAccountText(node) {
    if ((node.nodeValue || '').trim() !== ENGINE_ACCOUNT) return false;
    var s = node.parentElement;
    var row = s && s.matches && s.matches('span.font-medium') ? accountRow(s) : null;
    if (!row) return false;
    hideAccountRow(row);
    return true;
  }
  function hideEngineAccount(rootNode) {
    if (!rootNode || !rootNode.querySelectorAll) return;
    rootNode.querySelectorAll('[data-qosha-engine-account]').forEach(function (row) {
      var s = row.querySelector('span.font-medium');
      if (s && (s.textContent || '').trim() === ENGINE_ACCOUNT) return;
      row.removeAttribute('data-qosha-engine-account'); row.classList.remove('qosha-hidden');
    });
    var spans = Array.prototype.slice.call(rootNode.querySelectorAll('span.font-medium'));
    if (rootNode.matches && rootNode.matches('span.font-medium')) spans.push(rootNode);
    spans.forEach(function (s) {
      if ((s.textContent || '').trim() !== ENGINE_ACCOUNT) return;
      var row = accountRow(s);
      if (row) hideAccountRow(row);
    });
  }
  // <<< engine-account-card
  function sweep(rootNode) {
    hideEngineAccount(rootNode);   // first: the hidden account row keeps the engine's own words (see skipped())
    var w = document.createTreeWalker(rootNode, NodeFilter.SHOW_TEXT);
    while (w.nextNode()) fixText(w.currentNode);
    if (rootNode.querySelectorAll) {
      if (rootNode.tagName === 'INPUT') fixField(rootNode);
      rootNode.querySelectorAll('input').forEach(fixField);
      if (rootNode.nodeType === 1) fixAttrs(rootNode);
      rootNode.querySelectorAll('[title],[aria-label],[aria-description],[aria-valuetext],[placeholder],[alt]').forEach(fixAttrs);
    }
  }
  // ---- first paint (P0, 3 Nov 21:45): the served page (first_paint.py) shows only Qosha's loading screen and keeps
  // the engine's shell hidden until this mark. Set once Qosha's shell is in place: its look applied (qosha-shell.css
  // loaded), Qosha's menu in the side panel, the engine's names swept (run() does that first), and the Qosha page
  // frame loaded (at most 1.5 s more, so the screen doesn't open on an empty main area).
  var readySince = 0;
  function shellReady() {
    if (!root.classList.contains('qosha-shell')) return false;
    if (!window.getComputedStyle(root).getPropertyValue('--q-forest').trim()) return false;
    var aside = document.getElementById('app-sidebar');
    if (aside ? !aside.querySelector(':scope > .qosha-nav-top') : !document.querySelector('#root main, #root header')) return false;
    return true;
  }
  function frameLoaded() {
    // the Qosha page this address should show (Home and its views; the owner pages), loaded at its own address; a
    // frame that isn't there yet is not loaded (GPT R-fp1 2). Engine pages (Advanced) have none.
    var home = window.location.pathname === '/';
    var owner = !!PAGES[window.location.pathname.replace(/\/+$/, '')] && !advanced();
    if (!home && !owner) return true;
    var f = home ? document.querySelector('iframe[title="Qosha Control Center"]') : (ownerBox && !ownerBox.hidden && ownerBox.firstChild);
    if (!f) return false;
    try {
      var doc = f.contentDocument, want = home ? viewSrc() : ownerSrc(PAGES[window.location.pathname.replace(/\/+$/, '')]);
      return !!doc && doc.readyState !== 'loading' && !!doc.body && doc.location.pathname === want.split('?')[0];
    } catch (e) { return true; }
  }
  function markReady() {
    if (root.hasAttribute('data-qosha-ready')) return;
    if (!shellReady()) { readySince = 0; window.setTimeout(markReady, 50); return; }
    if (!readySince) readySince = Date.now();
    if (frameLoaded() || Date.now() - readySince > 1500) {
      root.setAttribute('data-qosha-ready', '1');
      var sp = document.getElementById('qosha-splash');
      if (sp) sp.remove();            // its job is done: gone, not just hidden (a reload brings it back first)
      return;
    }
    window.setTimeout(markReady, 50);
  }
  var pending = false, mo;
  function run() {
    sweep(document.body);
    fixShell();
    if (mo) mo.takeRecords();   // our own changes don't wake the observer again
  }
  mo = new MutationObserver(function (records) {
    // new text is fixed right here, before the browser paints it (a change made inside an animation frame would
    // otherwise wait for the next frame); the rest of the shell follows in the next frame
    records.forEach(function (r) {
      if (r.type === 'characterData') fixText(r.target);
      else if (r.type === 'attributes') fixAttrs(r.target);
      else r.addedNodes.forEach(function (n) { if (n.nodeType === 3) fixText(n); else if (n.nodeType === 1) sweep(n); });
    });
    mo.takeRecords();
    if (pending) return;
    pending = true;
    window.requestAnimationFrame(function () { pending = false; run(); });
  });
  mo.observe(document.documentElement, {subtree: true, childList: true, characterData: true, attributes: true,
                                        attributeFilter: ATTRS});
  run();
  markReady();
  // an address that is no page (visual QA LOW): a plain "not here" card with a way back, instead of a blank page
  function notHere() {
    var path = window.location.pathname.replace(/\/+$/, '') || '/';
    if (path === '/' || document.getElementById('qosha-notfound')) return;
    var known = {'/qosha': 1, '/chat': 1, '/docs': 1};
    document.querySelectorAll('aside a[href], nav a[href]').forEach(function (a) {
      var h = String(a.getAttribute('href') || '').split('?')[0].replace(/\/+$/, ''); if (h) known['/' + h.split('/')[1]] = 1;
    });
    if (Object.keys(known).length < 6 || known['/' + path.split('/')[1]]) return;   // the list is not drawn yet, or a real page
    var main = document.querySelector('main') || document.body;
    var box = document.createElement('div');
    box.id = 'qosha-notfound';
    box.setAttribute('style', 'margin:48px auto;max-width:440px;padding:28px 32px;border:1px solid #E2E1DB;border-radius:20px;background:#fff;font-family:"Google Sans Flex",sans-serif;color:#0B0B0B');
    var h = document.createElement('h2'); h.textContent = 'This page isn\u2019t here'; h.setAttribute('style', 'margin:0 0 8px;font-size:22px;font-weight:500;color:#0B3326');
    var p = document.createElement('p'); p.textContent = 'The address may be mistyped, or the page moved.'; p.setAttribute('style', 'margin:0 0 16px;color:#3E4B45');
    var a = document.createElement('a'); a.href = '/'; a.textContent = 'Go to Home'; a.setAttribute('style', 'display:inline-block;padding:10px 18px;border-radius:999px;background:#0B3326;color:#fff;text-decoration:none');
    box.appendChild(h); box.appendChild(p); box.appendChild(a); main.appendChild(box);
  }
  setTimeout(notHere, 2500);
  // local installs: the engine's own account service ("Engine portal": sign-in, subscription) is not part of Qosha, and
  // its version badge reads "unknown" there; Qosha's own version is shown instead (visual QA MED 9)
  var qoshaVersion = '';
  try { window.fetch('/dashboard-plugins/qosha/manifest.json').then(function (r) { return r.ok ? r.json() : null; }).then(function (m) { if (m && /^[0-9][0-9A-Za-z.+-]{0,30}$/.test(String(m.version))) qoshaVersion = String(m.version); }, function () {}); } catch (e) { /* none */ }
  var isLocal = false;
  try { window.fetch('/api/plugins/qosha/signin/local', {credentials: 'same-origin', headers: {'X-H\u0065rmes-Session-Token': String(window['__H\u0045RMES_SESSION_TOKEN__'] || '')}}).then(function (r) { return r.ok ? r.json() : null; }).then(function (d) { isLocal = !!(d && d.local); }, function () {}); } catch (e) { /* not local */ }
  function localTidy() {
    var path = window.location.pathname.replace(/\/+$/, '');
    // the engine's public catalog of third-party plugins is not offered on a customer's computer: back to Settings
    if (isLocal && (path === '/plugins' || path === '/achievements')) { window.location.replace('/?view=settings'); return; }
    // Settings > Conversations: conversations with no messages and no title are not listed
    if (isLocal && path === '/sessions' && !/advanced=1/.test(window.location.search)) {
      var sw = document.createTreeWalker(document.querySelector('main') || document.body, NodeFilter.SHOW_TEXT), sn;
      while ((sn = sw.nextNode())) {
        if (!/^\s*0\s*(msgs?|messages?)\b/i.test(sn.nodeValue)) continue;
        var row = sn.parentNode.closest('li, tr, [role="row"], [role="listitem"], a, button') || null;
        if (row && /untitled/i.test(row.textContent) && row.textContent.length < 400) { row.style.display = 'none'; row.setAttribute('data-qosha-hidden', 'empty-conversation'); }
      }
      return;
    }
    if (path !== '/system' && path !== '/env') return;
    var w = document.createTreeWalker(document.querySelector('main') || document.body, NodeFilter.SHOW_TEXT), n, hide = [];
    while ((n = w.nextNode())) {
      var v = n.nodeValue.trim(), el = n.parentNode;
      if (v === 'unknown' && el.nodeName === 'SPAN' && qoshaVersion) { n.nodeValue = qoshaVersion; continue; }
      if (/^(?:Engine portal|This provider is not offered in Qosha)$/i.test(v)) {   // np19: the rewritten card too (Gemini G09)
        // the whole card or row that carries it
        var box = el.closest('section, article, li, [class*="card"], [class*="Card"]') || (el.nodeName === 'H2' ? el.parentNode : null);
        if (!box && el.nodeName === 'SPAN') {
          // Keys page: an account row (…justify-between) or a provider group (button inside a bordered box)
          var btn = el.closest('button');
          box = btn ? btn.parentNode : el.closest('div[class*="justify-between"]');
        }
        if (box && box !== document.body && box.querySelectorAll('h2').length <= 1 && box.innerText.length < 600) hide.push(box);
      }
    }
    hide.forEach(function (b) { b.style.display = 'none'; b.setAttribute('data-qosha-hidden', 'engine-account'); });
  }
  setInterval(localTidy, 1500);
  // something waiting for the person (a question in a chat, or a sign-in Qosha stopped for): its count in the tab
  // title, "(1) Qosha", on every page and while the tab is in the background
  var waitingN = 0, waitingOff = false;
  function waitingRead() {
    if (waitingOff) return;
    try {
      window.fetch('/api/plugins/qosha/waiting', {credentials: 'same-origin', cache: 'no-store', headers: {'X-H\u0065rmes-Session-Token': String(window['__H\u0045RMES_SESSION_TOKEN__'] || '')}})
        .then(function (r) { if (r.status === 404) waitingOff = true; return r.ok ? r.json() : null; })
        .then(function (d) { var n = d && typeof d.count === 'number' ? d.count : 0; if (n !== waitingN) { waitingN = n; run(); } }, function () {});
    } catch (e) { /* none */ }
  }
  waitingRead();
  setInterval(waitingRead, 4000);
  // "Connect your AI" lives in the top window (pages/qosha-connect-ai.js): the panel and the AI accounts button
  (function () { var s = document.createElement('script'); s.src = '/dashboard-plugins/qosha/pages/qosha-connect-ai.js'; s.async = true; document.head.appendChild(s); })();
  // the right-click menu (Cut, Copy, Paste, Select all, Copy link, Copy image) on every Qosha page, in the app only
  (function () { var s = document.createElement('script'); s.src = '/dashboard-plugins/qosha/pages/qosha-rclick.js'; s.async = true; document.head.appendChild(s); })();
  // desktop notifications for the inbox watch (21 Nov 2026): mail that needs the person and the morning digest
  (function () { var s = document.createElement('script'); s.src = '/dashboard-plugins/qosha/pages/qosha-notify.js'; s.async = true; document.head.appendChild(s); })();
  // "Qosha is using your computer" with Stop, on every page (cu20, 22 Nov 2026)
  (function () { var s = document.createElement('script'); s.src = '/dashboard-plugins/qosha/pages/qosha-desktop.js'; s.async = true; document.head.appendChild(s); })();
  // After an update, the open window loads the new Qosha (22 Nov 2026: Ren's window kept the old Home after 1.20.21).
  // Before the reload, the text typed in any chat box (this page and its Qosha frames, open shadow roots too) is kept
  // for this tab only (sessionStorage) and put back after the reload, into the same box when it is still empty.
  // Editable text boxes only (never read-only or disabled ones, never passwords or other inputs); kept 2 minutes.
  // Keys name the frame (its path, hash and place among its parent's frames) and the box (its id, name, label or
  // placeholder; else its place, with the count, so a box that moved is left alone) (review r1, Gemini F2).
  (function () {
    var KEY = 'qosha.reloadDrafts', KEEP_MS = 120000;
    function frameKey(w) {
      var parts = [];
      try {
        for (var x = w; x && x !== window.top && x !== x.parent; x = x.parent) {
          var idx = -1, fs = x.parent.document.querySelectorAll('iframe');
          for (var i = 0; i < fs.length; i++) { if (fs[i].contentWindow === x) { idx = i; break; } }
          parts.unshift(x.location.pathname + x.location.search + x.location.hash + '@' + idx);
        }
      } catch (e) { return null; }
      return parts.join(' > ') || '/';
    }
    function boxes(doc) {        // every editable textarea in a document and its open shadow roots, in document order
      var out = [];
      (function walk(root, prefix) {
        var all = root.querySelectorAll('*'), list = [], hosts = {};
        for (var i = 0; i < all.length; i++) {
          var el = all[i];
          if (el.tagName === 'TEXTAREA' && !el.readOnly && !el.disabled) list.push(el);
          if (el.shadowRoot) {
            var t = el.tagName.toLowerCase(); hosts[t] = (hosts[t] || 0) + 1;
            walk(el.shadowRoot, prefix + (el.id ? '#' + el.id : t + ':' + (hosts[t] - 1)) + '/');
          }
        }
        list.forEach(function (el, n) {
          var name = el.id ? '#' + el.id : el.getAttribute('name') ? 'name=' + el.getAttribute('name')
            : el.getAttribute('aria-label') ? 'label=' + el.getAttribute('aria-label')
            : el.getAttribute('placeholder') ? 'ph=' + el.getAttribute('placeholder') : 'textarea:' + n + '/' + list.length;
          out.push({el: el, k: prefix + name});
        });
      })(doc, '');
      return out;
    }
    function frames(w, acc) {   // this window and every same-origin frame inside it
      acc = acc || [];
      var doc; try { doc = w.document; } catch (e) { return acc; }
      if (!doc) return acc;
      acc.push(w);
      var fs = doc.querySelectorAll('iframe');
      for (var i = 0; i < fs.length; i++) { try { if (fs[i].contentWindow) frames(fs[i].contentWindow, acc); } catch (e) {} }
      return acc;
    }
    function collect() {
      var items = [];
      frames(window).forEach(function (w) {
        var f = frameKey(w); if (f === null) return;
        boxes(w.document).forEach(function (b) { if (b.el.value && b.el.value.trim()) items.push({f: f, k: b.k, v: b.el.value}); });
      });
      return items;
    }
    function put(el, v) {        // as typing does: the box's own value setter and an input event that leaves the shadow
      try { Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(el, v); } catch (e) { el.value = v; }
      try { el.dispatchEvent(new Event('input', {bubbles: true, composed: true})); } catch (e) {}
    }
    window.qoshaReloadKeepingDrafts = function () {
      var items = collect();
      try { if (items.length) sessionStorage.setItem(KEY, JSON.stringify({at: Date.now(), items: items})); else sessionStorage.removeItem(KEY); } catch (e) {}
      window.location.reload();
    };
    window.qoshaReloadKeepingDrafts.collect = collect;   // for tests: what a reload would keep, and how a box is filled
    window.qoshaReloadKeepingDrafts.put = put;
    var saved = null, raw = null;
    try { raw = sessionStorage.getItem(KEY); sessionStorage.removeItem(KEY); } catch (e) {}
    try { saved = JSON.parse(raw || 'null'); } catch (e) { saved = null; }
    if (!saved || !saved.items || !(Date.now() - saved.at <= KEEP_MS)) return;
    var left = saved.items.slice(), tries = 0;
    var timer = setInterval(function () {
      tries++;
      frames(window).forEach(function (w) {
        var f = frameKey(w); if (f === null) return;
        var bs = null;
        left = left.filter(function (it) {
          if (it.f !== f) return true;
          bs = bs || boxes(w.document);
          var b = bs.filter(function (x) { return x.k === it.k; })[0];
          if (!b) return true;
          if (!b.el.value) put(b.el, it.v);
          return false;
        });
      });
      if (!left.length || tries > 60) clearInterval(timer);   // 30 seconds at most
    }, 500);
  })();
})();
