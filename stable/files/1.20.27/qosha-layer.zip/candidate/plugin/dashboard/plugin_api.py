"""Qosha's read-only dashboard, backed by upstream data sources."""
import base64
import contextvars
import importlib.util
import json
import math
import os
import re
import sys
import sqlite3
import threading
import time
from collections import OrderedDict
from contextlib import closing, contextmanager
from datetime import datetime, timedelta
from email.utils import parseaddr, parsedate_to_datetime
from functools import wraps
from html.parser import HTMLParser
from pathlib import Path

from fastapi import APIRouter
from fastapi.responses import JSONResponse
from hermes_constants import get_hermes_home


# ---- the approval gate's fail-safe, first of all (1.20.8 open item 1; reviews FO-1..16, FO2-1..7): on a local install
# the dashboard starts CLOSED (qosha_guard/gate_failsafe.py) and opens only once the gate is confirmed on the
# dashboard's own app; anything that fails before or during that (this file included) leaves approvals refused.
import importlib.util as _fs_ilu, pathlib as _fs_pl, sys as _fs_sys
_fs_local = (any(_fs_pl.Path(p).is_dir() for p in (
    [_fs_pl.Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Qosha"] if os.name == "nt"
    else [_fs_pl.Path.home() / "Applications" / "Qosha.app", _fs_pl.Path("/Applications/Qosha.app")]))
    and "dashboard" in [str(_x).lower() for _x in _fs_sys.argv])
_fs_mod = None
try:
    _fs_path = _fs_pl.Path(__file__).resolve().parent.parent / "qosha_guard" / "gate_failsafe.py"
    _fs_spec = _fs_ilu.spec_from_file_location("qosha_gate_failsafe", _fs_path)
    _fs_try = _fs_ilu.module_from_spec(_fs_spec)
    _fs_spec.loader.exec_module(_fs_try)
    _fs_sys.modules["qosha_gate_failsafe"] = _fs_mod = _fs_try        # published only once it loaded (FO-8)
    if _fs_local:
        _fs_mod.engage("starting")
except Exception as _fs_exc:
    import logging as _fs_logging
    _fs_logging.getLogger("qosha.approval_gate").error("Qosha approval check fail-safe not loaded: %s", type(_fs_exc).__name__)
    _fs_mod = None

# >>> engine-theme-names
# the engine's built-in theme names reach the page from the server ("Hermes Teal" in the theme picker, in the page before
# Qosha's words load): renamed in place, in this process (22 Nov 2026: never show the engine's name). Only when the
# dashboard's module is already loaded (this is its process); the list object is shared with the router that serves it.
try:
    _wsd = _fs_sys.modules.get("hermes_cli.web_server_dashboard")
    for _t in (getattr(_wsd, "_BUILTIN_DASHBOARD_THEMES", None) or []) if _wsd else []:
        if isinstance(_t, dict):
            for _k in ("label", "description"):
                if isinstance(_t.get(_k), str):
                    _v = re.sub(r"\bNous Blue\b", "Qosha Blue", _t[_k])
                    _v = re.sub(r"\bNous-blue\b", "blue", _v)          # the maker's name too (council, 22 Nov 2026)
                    _t[_k] = re.sub(r"hermes", "Qosha", _v, flags=re.I)
except Exception:
    pass
# <<< engine-theme-names
# Qosha's words on the engine's own sign-in and "unavailable" pages (qosha_pages.py), loaded here too: this file runs in
# the dashboard process before the sign-in routes are imported, so it holds even when the environment's .pth didn't
# run (an environment the engine rebuilt; Gemini ep18 F1). setup_home copies it beside the plugin.
try:
    if "qosha_pages" not in _fs_sys.modules:
        _qp = _fs_pl.Path(__file__).resolve().parent.parent / "qosha_pages.py"
        if _qp.is_file():
            _qps = _fs_ilu.spec_from_file_location("qosha_pages", _qp)
            _qpm = _fs_ilu.module_from_spec(_qps)
            _fs_sys.modules["qosha_pages"] = _qpm
            _qps.loader.exec_module(_qpm)
except Exception:
    _fs_sys.modules.pop("qosha_pages", None)

router = APIRouter()

# Insert into existing dashboard/plugin_api.py after router creation; existing middleware applies.
@router.get("/runtime-layout")
def runtime_layout(nonce: str = ""):
    """Read this serving process's live layout; never return arbitrary paths or environment values."""
    if os.environ.get("QOSHA_BOX") != "1":
        return JSONResponse(status_code=404, content={"error": "not_available"},
                            headers={"Cache-Control": "no-store"})
    if not re.fullmatch(r"[0-9a-f]{32}", nonce):
        return JSONResponse(status_code=400, content={"error": "bad_request"},
                            headers={"Cache-Control": "no-store"})
    try:
        cwd_is_files = os.getcwd() == "/opt/data/files"
        terminal_cwd_is_files = os.environ.get("TERMINAL_CWD") == "/opt/data/files"
    except OSError:
        return JSONResponse(status_code=503, content={"error": "unavailable"},
                            headers={"Cache-Control": "no-store"})
    return JSONResponse(content={"schema": 1, "nonce": nonce, "pid": os.getpid(), "uid": os.getuid(),
                                 "cwd_is_files": cwd_is_files,
                                 "terminal_cwd_is_files": terminal_cwd_is_files},
                        headers={"Cache-Control": "no-store"})

CACHE_SECONDS = 30
PROFILE_SECONDS = 600
GOOGLE_TIMEOUT = 15
_cache = OrderedDict()
_cache_lock = threading.Lock()
_google_slots = threading.BoundedSemaphore(16)
_NOT_CONNECTED = {"connected": False, "reason": "google_not_signed_in"}
# Google ended the stored sign-in (a refresh answered invalid_grant / revoked): Home says "Reconnect Google", never an
# error code, and Connections says the same (google_connect.signed_out; orchestrator 22 Nov, Ren's live Qosha).
_SIGNED_OUT = {"connected": False, "reason": "google_signed_out"}


def _gconn():
    import sys as _s
    mod = _s.modules.get("qosha_google_connect_page")
    if mod is None:
        spec = importlib.util.spec_from_file_location(
            "qosha_google_connect_page", Path(__file__).resolve().parent.parent / "qosha_guard" / "google_connect.py")
        mod = importlib.util.module_from_spec(spec)
        _s.modules["qosha_google_connect_page"] = mod
        try:
            spec.loader.exec_module(mod)
        except BaseException:
            _s.modules.pop("qosha_google_connect_page", None)
            raise
    return mod


def _signed_out_now() -> bool:
    try:
        return bool(_gconn().signed_out(get_hermes_home()))
    except Exception:
        return False


def _not_connected():
    return dict(_SIGNED_OUT) if _signed_out_now() else dict(_NOT_CONNECTED)
_QUERIES = {
    "focused": "in:inbox -category:promotions -category:social -category:updates -category:forums",
    "other": "in:inbox {category:promotions category:social category:updates category:forums}",
    "mentions": "in:inbox to:me -category:promotions -category:social -category:updates -category:forums",
}


def _warm_speech_to_text() -> None:
    """Local installs: load the speech-to-text model once when the screens start, so the first spoken turn does not
    wait for it (measured 13.5 s on the first call, 0.6-1.4 s after)."""
    def work():
        try:
            import struct, tempfile, wave
            from tools.voice_mode import transcribe_recording
            with tempfile.NamedTemporaryFile(prefix="qosha-warm-", suffix=".wav", delete=False) as f:
                name = f.name
            w = wave.open(name, "wb"); w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
            w.writeframes(struct.pack("<h", 0) * 8000); w.close()
            try:
                transcribe_recording(name)
            finally:
                os.unlink(name)
        except Exception:
            pass
    threading.Thread(target=work, daemon=True, name="qosha-stt-warm").start()


if not os.environ.get("QOSHA_BOX") and not os.environ.get("QOSHA_LAB"):
    _warm_speech_to_text()


def _kb_connect():
    """The engine's kanban board connection: kanban_db.connect up to v0.20, kanban_db_connect.connect from v0.22."""
    from hermes_cli import kanban_db
    fn = getattr(kanban_db, "connect", None)
    if fn is None:
        from hermes_cli.kanban_db_connect import connect as fn
    return fn


class APIError(Exception):
    def __init__(self, status, error, detail):
        self.status, self.error, self.detail = status, error, detail


def _endpoint(fn):
    @wraps(fn)
    def handle(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except APIError as exc:
            if exc.error == "google_signed_out":
                return dict(_SIGNED_OUT)          # the page shows Reconnect Google, not an error code
            return JSONResponse(status_code=exc.status,
                                content={"error": exc.error, "detail": exc.detail})
        except Exception as exc:
            return JSONResponse(status_code=503,
                                content={"error": "unavailable", "detail": type(exc).__name__})
    return handle


def _sqlite_read(read, *args, **kwargs):
    """Retry only transient SQLite contention, with three total attempts."""
    for attempt in range(3):
        try:
            return read(*args, **kwargs)
        except sqlite3.OperationalError as exc:
            if attempt == 2 or not re.search(r"\b(locked|busy)\b", str(exc), re.I):
                raise
            time.sleep(0.1)


def _integer(value, low, high, name):
    if not re.fullmatch(r"[0-9]+", str(value)) or not low <= int(value) <= high:
        raise APIError(400, "bad_request", f"{name} must be between {low} and {high}.")
    return int(value)


def _cached(key, fresh, produce, ttl=CACHE_SECONDS):
    key = (str(get_hermes_home().resolve()), os.environ.get("QOSHA_GOOGLE_API_PATH"), key)
    with _cache_lock:
        saved = _cache.get(key)
        if fresh != "1" and saved and time.monotonic() - saved[0] < ttl:
            return saved[1]
    result = produce()
    with _cache_lock:
        _cache[key] = (time.monotonic(), result)
        _cache.move_to_end(key)
        while len(_cache) > 512:
            _cache.popitem(last=False)
    return result


def _now():
    return datetime.now().astimezone()


def _date(value):
    if value is None or value == "":
        return None
    if isinstance(value, (float, int)):
        return datetime.fromtimestamp(value).astimezone()
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone()
    except ValueError:
        return parsedate_to_datetime(str(value)).astimezone()


def _iso(value):
    date = _date(value)
    return date.isoformat() if date else None


def _midnight(day):
    # Convert each naive local midnight separately: DST days can be 23/25 hours.
    return datetime.combine(day, datetime.min.time()).astimezone()


def _day_bounds(days=1):
    today = _now().date()
    return _midnight(today), _midnight(today + timedelta(days=days))


def _google_failure():
    return APIError(502, "google_api_error", "Qosha could not read Google data. Try again.")


def _limited(call, grant=None):
    """Bound caller latency and worker count, including credential refresh/build. grant: the sign-in the call uses
    (its mark), when known from the request's own credentials."""
    if not _google_slots.acquire(blocking=False):
        raise _google_failure()
    done, result = threading.Event(), []
    context = contextvars.copy_context()
    if grant is None:
        try:
            grant = _gconn().current_grant(get_hermes_home())   # read just before a build: the sign-in it loads
        except Exception:
            grant = ""

    def work():
        try:
            result.append((True, context.run(call)))
        except (Exception, SystemExit) as exc:
            revoked = False
            try:
                revoked = bool(_gconn().is_revoked_error(exc))
                if revoked and grant:
                    # recorded here, even when the caller already timed out, and only for the sign-in this call used:
                    # a Reconnect made meanwhile stays usable (r4 H1, H6)
                    _gconn().mark_signed_out(get_hermes_home(), grant=grant)
            except Exception:
                pass
            result.append((False, "signed_out" if revoked else None))
        finally:
            _google_slots.release()
            done.set()

    threading.Thread(target=work, daemon=True, name="qosha-google-read").start()
    if not done.wait(GOOGLE_TIMEOUT) or not result[0][0]:
        if result and result[0][1] == "signed_out":
            raise APIError(401, "google_signed_out", "Google signed Qosha out. Reconnect Google.")
        raise _google_failure()
    return result[0][1]


def _access_stopped_now() -> bool:
    """CONTRACT-ACCESS (final-pass review #6): Google reads for Home stop before any credential refresh or request
    while Qosha's access has ended or can't be confirmed. Fails closed."""
    try:
        m = _a_sys.modules.get("qosha_access")
        if m is None:
            p = _a_pl.Path(__file__).resolve().parent.parent / "qosha_guard" / "access.py"
            spec = _a_ilu.spec_from_file_location("qosha_access_google", p)
            m = _a_ilu.module_from_spec(spec)
            spec.loader.exec_module(m)
            _a_sys.modules["qosha_access_google"] = m
        return bool(m.stopped())
    except Exception:
        return True


def _google():
    if _access_stopped_now():
        raise APIError(403, "access_ended", "Your access to Qosha has ended.")
    import hermes_constants
    relative = Path("skills/productivity/google-workspace/scripts/google_api.py")
    candidates = []
    if os.environ.get("QOSHA_GOOGLE_API_PATH"):
        candidates.append(Path(os.environ["QOSHA_GOOGLE_API_PATH"]))
    candidates.extend((get_hermes_home() / relative, Path(hermes_constants.__file__).parent / relative))
    try:
        path = next(p for p in candidates if p.is_file())
        spec = importlib.util.spec_from_file_location("qosha_google_read", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    except (Exception, SystemExit):
        raise _google_failure() from None
    try:
        token = json.loads(Path(module.TOKEN_PATH).read_text(encoding="utf-8"))
        if not isinstance(token, dict):
            return None
        if _signed_out_now():
            return None                           # Google ended this sign-in: no refresh is tried again
        scopes = token.get("scopes", [])
        scopes = [s.rsplit("/", 1)[-1] for s in scopes if isinstance(s, str)] if isinstance(scopes, list) else []
        stamp = Path(module.TOKEN_PATH).stat()
    except (OSError, ValueError):
        return None
    return module, scopes, (str(path), stamp.st_mtime_ns, stamp.st_size)


def _service(google, api, version):
    # Upstream build_service calls its own get_credentials; no connector here.
    service = _limited(lambda: google[0].build_service(api, version))
    transport = getattr(service, "_http", None)
    if transport is not None:
        transport.timeout = GOOGLE_TIMEOUT
    return service


def _execute(request):
    if _access_stopped_now():           # every request, not only the first (1.20.1, final-pass #6)
        raise APIError(403, "access_ended", "Your access to Qosha has ended.")
    grant = None
    try:   # the sign-in this request was built with, not whatever is on disk now (a Reconnect may have happened; r5 H1)
        rt = getattr(getattr(getattr(request, "http", None), "credentials", None), "refresh_token", None)
        if rt:
            grant = _gconn().grant_of(str(rt))
    except Exception:
        grant = None
    return _limited(lambda: request.execute(num_retries=0), grant)


def _google_cached(route, params, fresh, produce):
    google = _google()
    if google is None:
        return _not_connected()
    return _cached((route, params, google[2]), fresh, lambda: produce(google))


@router.get("/status")
@_endpoint
def status(fresh: str = "0"):
    google = _google()
    account = None
    if google:
        try:
            account = _cached(("account", google[2]), fresh,
                              lambda: _execute(_service(google, "gmail", "v1").users().getProfile(userId="me")).get("emailAddress"),
                              PROFILE_SECONDS)
        except APIError:
            pass
    out = {"connected": google is not None and not _signed_out_now(), "account": account,
           "scopes": google[1] if google else []}
    if not out["connected"]:
        out["reason"] = _not_connected()["reason"]
    return {"plugin": "qosha", "build": "c18", "google": out, "time": _now().isoformat(),
            "assistants": _assistants(fresh), "brain": _brain_summary()}


def _brain_summary():
    """The main assistant in plain words (UAT 11:46), read from config.yaml only: no model list, no lookups, no network.
    The home page shows it from this read; the full list loads only when the person opens the Change dialog."""
    import sys as _s
    mod = _s.modules.get("qosha_brain_api")
    if mod is None:
        return None
    try:
        return mod.home() if hasattr(mod, "home") else mod.summary()   # the Home composer's choices too
    except Exception:
        return None


def _assistants(fresh="0"):
    """Which assistants answer on this computer (booleans only; UAT 2 Nov, D17). Cached like the other reads."""
    import sys as _s
    mod = _s.modules.get("qosha_assistants_api")
    if mod is None:
        return {"claude": True, "chatgpt": False, "gemini": False, "gemini_chat": False}
    try:
        a = mod.assistants()   # not cached: a helper that just (re)started shows up on the next read (UAT 10:40)
        chat = bool(a.get("gemini_chat"))                     # CONTRACT G1: Gemini as a full chat model
        app = a.get("gemini_app") if isinstance(a.get("gemini_app"), dict) else {}
        # CONTRACT G3: the models are the ones the person's Gemini app offers (ids and labels only)
        return {"claude": True, "chatgpt": bool(a.get("chatgpt")), "gemini": bool(a.get("gemini")), "gemini_chat": chat,
                "gemini_models": list(app.get("models") or []) if chat else [],
                "gemini_default": str(app.get("default") or "") if chat else ""}
    except Exception:
        return {"claude": True, "chatgpt": False, "gemini": False, "gemini_chat": False}


def _calendar(google, days, fresh="0"):
    return _cached(("calendar", days, google[2]), fresh, lambda: _fetch_calendar(google, days))


def _fetch_calendar(google, days):
    start, end = _day_bounds(days)
    response = _execute(_service(google, "calendar", "v3").events().list(
        calendarId="primary", timeMin=start.isoformat(), timeMax=end.isoformat(),
        singleEvents=True, orderBy="startTime", maxResults=50))
    events = []
    next_event = None
    now = _now()
    tomorrow = _midnight(now.date() + timedelta(days=1))
    for event in response.get("items", []):
        begins, ends = event.get("start", {}), event.get("end", {})
        a, b = _date(begins.get("dateTime") or begins.get("date")), _date(ends.get("dateTime") or ends.get("date"))
        if not a or not b:
            continue
        meet = event.get("hangoutLink") or next((p.get("uri") for p in event.get("conferenceData", {}).get("entryPoints", []) if p.get("entryPointType") == "video"), None)
        org = event.get("organizer") or {}
        guests = [g for g in event.get("attendees") or [] if isinstance(g, dict) and not g.get("resource")]
        me = next((g for g in guests if g.get("self")), None)
        item = {"id": event["id"], "title": event.get("summary") or "(no title)",
                "start": a.isoformat(), "end": b.isoformat(), "all_day": "date" in begins,
                "location": event.get("location", ""), "meet_link": meet,
                "status": event.get("status", "confirmed"), "html_link": event.get("htmlLink", ""),
                # Home side chat's meeting peek (22 Nov 2026): who organizes it, whether it is the person, their answer
                "organizer": {"name": str(org.get("displayName") or "")[:120], "email": str(org.get("email") or "")[:200],
                              "self": bool(org.get("self"))},
                "my_response": str((me or {}).get("responseStatus") or "")[:20], "guests": len(guests)}
        events.append(item)
    events.sort(key=lambda item: _date(item["start"]))
    for item in events:
        a, b = _date(item["start"]), _date(item["end"])
        if a < tomorrow and b > now and item["status"] != "cancelled":
            next_event = {k: item[k] for k in ("id", "title", "start")}
            next_event["minutes_until"] = max(0, math.ceil((a - now).total_seconds() / 60))
            break
    return {"connected": True, "start": start.isoformat(), "end": end.isoformat(), "events": events, "next": next_event}


@router.get("/calendar/events")
@_endpoint
def calendar_events(days: str = "1", fresh: str = "0"):
    days = _integer(days, 1, 14, "days")
    google = _google()
    return _calendar(google, days, fresh) if google else _not_connected()


def _headers(message):
    return {h["name"].lower(): h.get("value", "") for h in message.get("payload", {}).get("headers", [])}


def _message_date(message, headers):
    try:
        return _iso(headers.get("date")) or _iso(int(message.get("internalDate", 0)) / 1000)
    except (TypeError, ValueError, OverflowError):
        return _iso(int(message.get("internalDate", 0)) / 1000)


def _counts(google, fresh="0", keys=None):
    queries = {k: v + " is:unread" for k, v in _QUERIES.items()}
    queries["unread"] = "in:inbox is:unread"
    queries["important_unread"] = "in:inbox is:unread is:important"
    service = None

    def fetch(query):
        nonlocal service
        if service is None:
            service = _service(google, "gmail", "v1")
        response = _execute(service.users().messages().list(userId="me", q=query, maxResults=100))
        return response.get("resultSizeEstimate", len(response.get("messages", [])))

    return {key: _cached(("inbox-count", queries[key], google[2]), fresh,
                         lambda key=key: fetch(queries[key])) for key in (keys if keys is not None else queries)}


def _inbox(google, tab, maximum, fresh="0"):
    messages = _cached(("inbox-messages", tab, maximum, google[2]), fresh,
                       lambda: _inbox_messages(google, tab, maximum))
    return {"connected": True, "tab": tab, "messages": messages, "counts": _counts(google, fresh)}


def _inbox_messages(google, tab, maximum):
    service = _service(google, "gmail", "v1")
    response = _execute(service.users().messages().list(userId="me", q=_QUERIES[tab], maxResults=maximum))
    messages = []
    for entry in response.get("messages", [])[:maximum]:
        message = _execute(service.users().messages().get(userId="me", id=entry["id"], format="metadata", metadataHeaders=["From", "Subject", "Date"]))
        headers = _headers(message)
        name, address = parseaddr(headers.get("from", ""))
        labels = message.get("labelIds", [])
        messages.append({"id": message["id"], "thread_id": message.get("threadId", ""),
                         "from_name": name or address, "from_email": address,
                         "subject": headers.get("subject", ""), "snippet": message.get("snippet", ""),
                         "date": _message_date(message, headers), "unread": "UNREAD" in labels,
                         "important": "IMPORTANT" in labels})
    return messages


@router.get("/email/inbox")
@_endpoint
def email_inbox(tab: str = "focused", max: str = "10", fresh: str = "0"):
    if tab not in _QUERIES:
        raise APIError(400, "bad_request", "Unknown inbox tab.")
    maximum = _integer(max, 1, 25, "max")
    google = _google()
    return _inbox(google, tab, maximum, fresh) if google else _not_connected()


class _Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.hidden = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.hidden += 1
        if not self.hidden and tag in ("p", "br", "div", "li", "tr"):
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.hidden = max(0, self.hidden - 1)
        if not self.hidden and tag in ("p", "div", "li", "tr"):
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


def _body(payload):
    plain, html = [], []

    def visit(part):
        if part.get("filename"):
            return
        data = part.get("body", {}).get("data")
        mime = part.get("mimeType", "text/plain")
        if data and mime in ("text/plain", "text/html"):
            raw = base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))
            content_type = next((h.get("value", "") for h in part.get("headers", []) if h.get("name", "").lower() == "content-type"), "")
            charset = re.search(r'charset=["\']?([^\s;"\']+)', content_type, re.I)
            try:
                text = raw.decode(charset.group(1) if charset else "utf-8", errors="replace")
            except LookupError:
                text = raw.decode("utf-8", errors="replace")
            (plain if mime == "text/plain" else html).append(text)
        for child in part.get("parts", []):
            visit(child)
    visit(payload)
    if plain:
        return "\n".join(plain)[:20000]
    parser = _Text()
    parser.feed("\n".join(html))
    return "".join(parser.parts).strip()[:20000]


def _message(google, message_id):
    message = _execute(_service(google, "gmail", "v1").users().messages().get(userId="me", id=message_id, format="full"))
    headers = _headers(message)
    return {"connected": True, "id": message["id"], "thread_id": message.get("threadId", ""),
            "from": headers.get("from", ""), "to": headers.get("to", ""), "subject": headers.get("subject", ""),
            "date": _message_date(message, headers), "labels": message.get("labelIds", []),
            "body": _body(message.get("payload", {}))}


@router.get("/email/message/{id}")
@_endpoint
def email_message(id: str, fresh: str = "0"):
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", id):
        raise APIError(400, "bad_request", "Invalid message id.")
    return _google_cached("message", id, fresh, lambda g: _message(g, id))


@contextmanager
def _sessions():
    from hermes_state import SessionDB
    path = get_hermes_home() / "state.db"
    if not path.is_file():
        yield None
    else:
        with closing(_sqlite_read(SessionDB, db_path=path, read_only=True)) as db:
            yield db


def _all_sessions(db):
    if db is None:
        return
    offset = 0
    while True:
        rows = _sqlite_read(db.list_sessions_rich, limit=200, offset=offset, include_children=True,
                                     include_archived=True, include_hidden=True,
                                     project_compression_tips=False, compact_rows=True)
        yield from rows
        if len(rows) < 200:
            break
        offset += len(rows)


def _jobs():
    from cron import jobs
    with jobs.use_cron_store(get_hermes_home()):
        return _sqlite_read(jobs.list_jobs, include_disabled=True)


def _run_status(run):
    if run.get("end_reason") == "cron_complete":
        return "ok"
    return "error" if run.get("ended_at") is not None else None


def _cron_words(expr, kind=None):
    """A schedule in words for Home (22 Nov: Ren saw "*/15 * * * *"). A cron line Qosha can't put in words exactly is
    "On a schedule", never the line itself; a schedule the job already words (such as "once at ...") is kept."""
    text = str(expr or "").strip()
    m = re.fullmatch(r"every (\d{1,6})m", text)
    if m:                                    # the engine's own interval words ("every 30m", "every 120m")
        n = int(m.group(1))
        if n <= 0:
            return "On a schedule"
        return "Every %d h" % (n // 60) if n >= 60 and n % 60 == 0 else "Every %d min" % n
    f = text.split()
    # a cron line by its shape (the engine keeps a person's own words such as "Every day at 9 PM" as the display even
    # for a cron job, so the kind alone doesn't say the text is a cron line); R/H: the engine's random/hashed fields
    looks = len(f) in (5, 6) and all(re.fullmatch(r"[0-9A-Za-z*/,?#-]+", x) for x in f) \
        and all(re.fullmatch(r"[0-9*/,RH?-]+", x) for x in f[:2])
    if not looks:
        return text
    if len(f) == 5:                          # day names as numbers ("MON-FRI" -> "1-5")
        f[4] = {"MON-FRI": "1-5", "SAT,SUN": "0,6", "SUN,SAT": "6,0"}.get(f[4].upper(), f[4])
    if len(f) == 5 and all(re.fullmatch(r"[0-9*/,-]{1,20}", x) for x in f):
        mi, hr, dom, mon, dow = f
        if dom == mon == "*":
            days = {"*": "Every day", "1-5": "Weekdays", "0,6": "Weekends", "6,0": "Weekends"}.get(dow)
            m = re.fullmatch(r"\*/(\d{1,2})", mi)
            if m and hr == "*" and dow == "*" and 0 < int(m.group(1)) and 60 % int(m.group(1)) == 0:
                return "Every %d min" % int(m.group(1))
            m = re.fullmatch(r"\*/(\d{1,2})", hr)
            if mi == "0" and m and dow == "*" and 0 < int(m.group(1)) and 24 % int(m.group(1)) == 0:
                return "Every %d h" % int(m.group(1))
            if mi == "0" and hr == "*" and dow == "*":
                return "Every hour"
            if days and mi.isdigit() and hr.isdigit() and int(mi) < 60 and int(hr) < 24:
                h = int(hr)
                at = "%d%s %s" % (h % 12 or 12, ":%02d" % int(mi) if int(mi) else "", "AM" if h < 12 else "PM")
                return "%s at %s" % (days, at)
    return "On a schedule"


def _inbox_tile(job, iw, st):
    """The inbox watch's own words for its tile, or None for any other job (the watch's state is read once a request)."""
    if iw is None or st is None:
        return None
    try:
        if job.get("id") != st.get("job_id") and not (job.get("name") == iw.JOB_NAME and job.get("script") == iw.SCRIPT):
            return None
        try:
            first = _date(job.get("next_run_at")).timestamp()
        except Exception:
            first = None
        return iw.tile(st=st, first=first)
    except Exception:
        return None


def _safe_iso(value):
    try:
        return _iso(value)
    except (ValueError, OverflowError, OSError, TypeError):
        return None


def _automations():
    from cron.jobs import effective_job_state
    result = []
    cutoff = _now() - timedelta(days=7)
    iw = sys.modules.get("qosha_inbox_watch")
    try:
        iw_state = iw.load_state() if iw is not None else None
    except Exception:
        iw_state = None
    with _sessions() as db:
        for job in _jobs():
            recent, offset = [], 0
            while True:
                runs = _sqlite_read(db.list_cron_job_runs, job["id"], limit=200, offset=offset) if db else []
                recent.extend(r for r in runs if r.get("ended_at") is not None and _date(r["started_at"]) >= cutoff)
                if len(runs) < 200 or _date(runs[-1]["started_at"]) < cutoff:
                    break
                offset += len(runs)
            ok = sum(_run_status(r) == "ok" for r in recent)
            eff = effective_job_state(job)
            state = "error" if eff == "error" else "paused" if eff in ("paused", "completed") or not job.get("enabled", True) else "running"
            last = job.get("last_status")
            last = "ok" if last == "ok" else "error" if last else None
            sched = job.get("schedule")
            kind = sched.get("kind") if isinstance(sched, dict) else None
            schedule = sched.get("display", "") if isinstance(sched, dict) else sched if isinstance(sched, str) else ""
            raw = job.get("schedule_display") or schedule
            inbox = _inbox_tile(job, iw, iw_state)
            if inbox and inbox.get("off"):
                state = "paused"                 # switched off in Settings: the job itself stays as the person left it
            try:
                words = (inbox or {}).get("schedule_words") or _cron_words(raw, kind)
            except Exception:
                words = "On a schedule"
            nxt = (inbox or {}).get("next_check_at") if inbox else job.get("next_run_at")
            result.append({"id": job["id"], "name": job.get("name", ""), "state": state, "completed": eff == "completed",
                           "schedule": raw, "schedule_words": words,
                           "inbox_watch": bool(inbox), "need_you": (inbox or {}).get("need_you"),
                           "waiting": (inbox or {}).get("waiting"), "off": bool((inbox or {}).get("off")),
                           "last_check_at": _safe_iso((inbox or {}).get("last_check_at")),
                           "last_run_at": _safe_iso(job.get("last_run_at")), "last_status": last,
                           "runs_7d": len(recent), "ok_7d": ok,
                           "success_pct": round(100 * ok / len(recent), 2) if recent else None,
                           "next_run_at": _safe_iso(nxt) if state == "running" else None})
    return {"jobs": result, "counts": {"total": len(result), "running": sum(j["state"] == "running" for j in result),
            "paused": sum(j["state"] == "paused" for j in result), "needs_review": sum(j["state"] != "paused" and (j["last_status"] == "error" or j["state"] == "error")
                                    for j in result)}}   # the Review tab's own rule (an off watch is not "to review")


@router.get("/automations")
@_endpoint
def automations(fresh: str = "0"):
    return _cached("automations", fresh, _automations)


def _tasks():
    from hermes_cli import kanban_db
    start, end = _day_bounds()
    with closing(_sqlite_read(_kb_connect(), board="qosha-m1")) as conn:
        row = _sqlite_read(lambda: conn.execute("SELECT SUM(status NOT IN ('done','archived')), "
                           "SUM(status NOT IN ('done','archived') AND priority >= 2), "
                           "SUM(status = 'done' AND completed_at >= ? AND completed_at < ?) FROM tasks",
                           (start.timestamp(), end.timestamp())).fetchone())
    return dict(zip(("board", "open", "high", "done_today"), ("qosha-m1", *(int(v or 0) for v in row))))


@router.get("/tasks/summary")
@_endpoint
def tasks_summary(fresh: str = "0"):
    return _cached("tasks", fresh, _tasks)


def _activity(limit):
    from hermes_cli import kanban_db
    items = []
    with _sessions() as db:
        for session in _all_sessions(db):
            items.append({"kind": "automation" if session.get("source") == "cron" else "chat",
                          "title": session.get("title") or session.get("preview") or "Qosha conversation",
                          "detail": (_run_status(session) or "running") if session.get("source") == "cron" else "",
                          "at": _iso(session.get("last_active") or session["started_at"]), "ref": session["id"]})
    with closing(_sqlite_read(_kb_connect(), board="qosha-m1")) as conn:
        rows = _sqlite_read(lambda: conn.execute("SELECT e.*, t.title FROM task_events e LEFT JOIN tasks t ON t.id=e.task_id "
                            "ORDER BY e.created_at DESC, e.id DESC LIMIT ?", (limit,)).fetchall())
        for row in rows:
            items.append({"kind": "task", "title": row["title"] or "Qosha task", "detail": row["kind"],
                          "at": _iso(row["created_at"]), "ref": row["task_id"]})
    try:
        from qosha_guard.store import recent_events
    except ImportError:
        recent_events = None
    if recent_events:
        for event in recent_events(limit):
            items.append({"kind": "decision", "title": event.get("title") or event.get("summary") or "Qosha decision",
                          "detail": event.get("detail") or event.get("status", ""),
                          "at": _iso(event.get("at") or event.get("created_at")),
                          "ref": str(event.get("ref") or event.get("decision_id") or event.get("id", ""))})
    items.sort(key=lambda item: _date(item["at"]).timestamp() if item["at"] else 0, reverse=True)
    return {"items": items[:limit]}


def _decisions_stamp():
    """Changes whenever a decision changes (WAL store: the -wal file is written on every commit), so Recent activity
    shows a send at once instead of after the cache time (one Approve, 3 Nov)."""
    try:
        from qosha_guard.store import db_path
        base = str(db_path())
        return tuple(os.stat(base + s).st_mtime_ns if os.path.exists(base + s) else 0 for s in ("", "-wal"))
    except Exception:
        return None


@router.get("/activity")
@_endpoint
def activity(limit: str = "10", fresh: str = "0"):
    limit = _integer(limit, 1, 50, "limit")
    return _cached(("activity", limit, _decisions_stamp()), fresh, lambda: _activity(limit))


def _local_stats():
    jobs, tasks = _automations(), _tasks()
    start, end = _day_bounds()
    with _sessions() as db:
        assists = sum(start <= _date(s["started_at"]) < end for s in _all_sessions(db)
                      if s.get("source") != "cron" and not s.get("parent_session_id"))
    return {"meetings_today": None, "next_meeting_minutes": None, "unread": None, "important_unread": None,
              "automations": jobs["counts"]["total"], "automations_need_review": jobs["counts"]["needs_review"],
              "open_tasks": tasks["open"], "high_tasks": tasks["high"], "ai_assists_today": assists,
              "ai_assists_basis": "assistant sessions started today"}


def _stats(google, fresh="0"):
    # Compose independently cached sources; an outer response cache would extend
    # the lifetime of Google data that was already old when stats first used it.
    result = _cached(("stats-local", _now().date().isoformat()), fresh, _local_stats).copy()
    if google:
        calendar = _calendar(google, 1, fresh)
        counts = _counts(google, fresh, keys=("unread", "important_unread"))
        result["meetings_today"] = sum(e["status"] != "cancelled" for e in calendar["events"])
        result["next_meeting_minutes"] = calendar["next"]["minutes_until"] if calendar["next"] else None
        result["unread"], result["important_unread"] = counts["unread"], counts["important_unread"]
    return result


@router.get("/stats")
@_endpoint
def stats(fresh: str = "0"):
    google = _google()
    return _stats(google, fresh)


# --- Claude-owned assistants routes (UAT 2 Nov, D17): which assistants are reachable, and Ask Gemini. ---
import importlib.util as _a_ilu, pathlib as _a_pl, sys as _a_sys
_a_spec = _a_ilu.spec_from_file_location("qosha_assistants_api", _a_pl.Path(__file__).with_name("assistants_api.py"))
_a_mod = _a_ilu.module_from_spec(_a_spec); _a_sys.modules["qosha_assistants_api"] = _a_mod
_a_spec.loader.exec_module(_a_mod)
router.include_router(_a_mod.router, prefix="/assistants")


# --- Qosha Council (P0, 8 Nov 2026): the gateway learns council turns (All / "Ask all 3") as soon as the screens
# start, before any chat has built an agent; and a page that reconnects mid-run reads the job's progress here. ---
def _council():
    _c_path = _a_pl.Path(__file__).resolve().parent.parent / "qosha_council" / "__init__.py"
    mod = _a_sys.modules.get("qosha_council_pkg_loader")
    if mod is None:
        spec = _a_ilu.spec_from_file_location("qosha_council_pkg_loader", _c_path)
        mod = _a_ilu.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _a_sys.modules["qosha_council_pkg_loader"] = mod
    return mod.load()


try:
    _council().protect_env()            # the Gemini helper key out of the environment; seat names never reach commands
    _council().install_gateway_wrapper()
except Exception as _c_exc:   # the screens still work; the plugin's own registration installs it again
    import logging as _c_logging
    _c_logging.getLogger("qosha.council").warning("council gateway wrapper not installed: %s", type(_c_exc).__name__)


# --- Gemini as a full chat model (CONTRACT G1, 9 Nov 2026): the engine is pinned to Qosha's relay as soon as the
# screens start, before any chat or model list asks for it (the plugin's own registration applies it again). Loaded
# after the council above, so the Gemini helper key is already in its private store. ---
try:
    _g_spec = _a_ilu.spec_from_file_location(
        "qosha_gemini_chat", _a_pl.Path(__file__).resolve().parent.parent / "qosha_guard" / "gemini_chat.py")
    _g_mod = _a_ilu.module_from_spec(_g_spec)
    _g_spec.loader.exec_module(_g_mod)
    _a_sys.modules["qosha_gemini_chat"] = _g_mod     # published only once fully loaded (assistants_api reads ready())
    _g_mod.apply()
except Exception as _g_exc:   # the screens still work: Gemini stays text-only (assistants_api._gemini_chat)
    import logging as _g_logging
    _g_logging.getLogger("qosha.gemini_chat").warning("Gemini chat was not set up: %s", type(_g_exc).__name__)


@router.post("/council/ensure")
def council_ensure():
    """The chat page asks this right before an "All 3" message: is the council listening on the chat's submit call
    now? (Engine v0.22+ can register its own handler again after the screens start, which silently sent an "All 3"
    message to the ordinary assistant: found 17 Nov with a real account.) It is put in place here if it is not."""
    try:
        ok = bool(_council().install_gateway_wrapper())
    except Exception:
        ok = False
    return JSONResponse(content={"ready": ok}, headers={"Cache-Control": "no-store"})


def _council_keeper() -> None:
    """Keeps the council's place on the chat's submit call for as long as the screens run (checked every 3 s)."""
    import threading as _t, time as _time
    def work():
        while True:
            _time.sleep(3)
            try:
                _council().install_gateway_wrapper()
            except Exception:
                pass
    _t.Thread(target=work, daemon=True, name="qosha-council-keeper").start()


_council_keeper()


@router.get("/council/{request_id}")
def council_status(request_id: str):
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", request_id or ""):
        return JSONResponse(status_code=400, content={"error": "bad_request"}, headers={"Cache-Control": "no-store"})
    try:
        st = _council().council_status(request_id)   # running, or accepted and queued (GPT R2 #6)
    except Exception:   # a failed lookup is "don't know", never "not found" (GPT R3 #7)
        return JSONResponse(status_code=503, content={"error": "unknown"}, headers={"Cache-Control": "no-store"})
    if st is None:
        return JSONResponse(status_code=404, content={"error": "not_found"}, headers={"Cache-Control": "no-store"})
    return JSONResponse(content=st, headers={"Cache-Control": "no-store"})


# --- Claude-owned files routes (UAT 2 Nov 10:48; GPT R-pages): the Files page's uploads and deletes, no-follow and
# no-clobber inside the lab's locked files folder. A copy without files_api.py (the read API tests) mounts nothing. ---
_f_path = _a_pl.Path(__file__).with_name("files_api.py")
if _f_path.is_file():
    _f_spec = _a_ilu.spec_from_file_location("qosha_files_api", _f_path)
    _f_mod = _a_ilu.module_from_spec(_f_spec); _a_sys.modules["qosha_files_api"] = _f_mod
    _f_spec.loader.exec_module(_f_mod)
    router.include_router(_f_mod.router, prefix="/files")


# --- Claude-owned main brain routes (UAT 2 Nov 11:46/11:48): the engine's main model and effort, Claude or ChatGPT. ---
# A copy without brain_api.py (the read API tests) mounts nothing.
_b_path = _a_pl.Path(__file__).with_name("brain_api.py")
if _b_path.is_file():
    _b_spec = _a_ilu.spec_from_file_location("qosha_brain_api", _b_path)
    _b_mod = _a_ilu.module_from_spec(_b_spec); _a_sys.modules["qosha_brain_api"] = _b_mod
    _b_spec.loader.exec_module(_b_mod)
    router.include_router(_b_mod.router, prefix="/brain")


# --- Qosha's natural on-device voice for read-aloud (17 Nov 2026): voice_api.py ---
_vo_path = _a_pl.Path(__file__).with_name("voice_api.py")
if _vo_path.is_file():
    _vo_spec = _a_ilu.spec_from_file_location("qosha_voice_api", _vo_path)
    _vo_mod = _a_ilu.module_from_spec(_vo_spec); _a_sys.modules["qosha_voice_api"] = _vo_mod
    _vo_spec.loader.exec_module(_vo_mod)
    router.include_router(_vo_mod.router, prefix="/voice")
    # local installs: the voice is loaded as Qosha starts (Ren, 18 Nov 2026: "Load when Qosha starts"), so the first
    # spoken answer is not late (19 s on the Windows test PC, 4-5 s once loaded); about 360 MB while Qosha runs
    if not os.environ.get("QOSHA_BOX") and not os.environ.get("QOSHA_LAB"):
        try:
            _vo_mod.status()   # starts the voice worker in the background when this computer has the voice
        except Exception:
            pass


# --- pictures, videos and files inside the chat (Ren, 20 Nov 2026): media_api.py ---
_md_path = _a_pl.Path(__file__).with_name("media_api.py")
if _md_path.is_file():
    _md_spec = _a_ilu.spec_from_file_location("qosha_media_api", _md_path)
    _md_mod = _a_ilu.module_from_spec(_md_spec); _a_sys.modules["qosha_media_api"] = _md_mod
    _md_spec.loader.exec_module(_md_mod)
    router.include_router(_md_mod.router, prefix="/media")


# --- AI subscription sign-in from Qosha's screens (local installs, 17 Nov 2026): signin_api.py ---
_si_path = _a_pl.Path(__file__).with_name("signin_api.py")
if _si_path.is_file():
    _si_spec = _a_ilu.spec_from_file_location("qosha_signin_api", _si_path)
    _si_mod = _a_ilu.module_from_spec(_si_spec); _a_sys.modules["qosha_signin_api"] = _si_mod
    _si_spec.loader.exec_module(_si_mod)
    router.include_router(_si_mod.router, prefix="/signin")
# --- "Waiting for you": sign-ins Qosha stopped for in its browser (17 Nov 2026): qosha_guard/waiting.py ---
_wt_path = _a_pl.Path(__file__).resolve().parent.parent / "qosha_guard" / "waiting.py"
if _wt_path.is_file():
    try:
        _wt_spec = _a_ilu.spec_from_file_location("qosha_waiting_api", _wt_path)
        _wt_mod = _a_ilu.module_from_spec(_wt_spec); _a_sys.modules["qosha_waiting_api"] = _wt_mod
        _wt_spec.loader.exec_module(_wt_mod)
        if getattr(_wt_mod, "router", None) is not None:
            router.include_router(_wt_mod.router, prefix="/waiting")
    except Exception as _wt_exc:
        import logging as _wt_log
        _wt_log.getLogger("qosha").warning("Qosha waiting list not mounted: %s", type(_wt_exc).__name__)
# --- Qosha uses the person's computer (cu20, 22 Nov 2026): status, Stop, Let Qosha continue, setup ---
_du_path = _a_pl.Path(__file__).resolve().parent.parent / "qosha_guard" / "desktop_api.py"
if _du_path.is_file():
    try:
        _du_spec = _a_ilu.spec_from_file_location("qosha_desktop_api", _du_path)
        _du_mod = _a_ilu.module_from_spec(_du_spec); _a_sys.modules["qosha_desktop_api"] = _du_mod
        _du_spec.loader.exec_module(_du_mod)
        if getattr(_du_mod, "router", None) is not None:
            router.include_router(_du_mod.router, prefix="/desktop")
    except Exception as _du_exc:
        import logging as _du_log
        _du_log.getLogger("qosha").warning("Qosha computer-use routes not mounted: %s", type(_du_exc).__name__)
# --- The welcome questions on Home (backlog item 7, 17 Nov 2026): welcome_api.py ---
_w_path = _a_pl.Path(__file__).with_name("welcome_api.py")
if _w_path.is_file():
    _w_spec = _a_ilu.spec_from_file_location("qosha_welcome_api", _w_path)
    _w_mod = _a_ilu.module_from_spec(_w_spec); _a_sys.modules["qosha_welcome_api"] = _w_mod
    _w_spec.loader.exec_module(_w_mod)
    router.include_router(_w_mod.router, prefix="/welcome")


# --- Claude-owned projects routes (UAT 2 Nov 11:42; council C9 → D20): Projects on the engine's own projects store. ---
_p_path = _a_pl.Path(__file__).with_name("projects_api.py")
if _p_path.is_file():
    _p_spec = _a_ilu.spec_from_file_location("qosha_projects_api", _p_path)
    _p_mod = _a_ilu.module_from_spec(_p_spec); _a_sys.modules["qosha_projects_api"] = _p_mod
    _p_spec.loader.exec_module(_p_mod)
    router.include_router(_p_mod.router, prefix="/projects")


# --- Claude-owned skills and connections routes (night job 3, 2 Nov): the side panel's Skills and
# Connections pages. A copy without apps_api.py (the read API tests) mounts nothing. ---
_s_path = _a_pl.Path(__file__).with_name("apps_api.py")
if _s_path.is_file():
    _s_spec = _a_ilu.spec_from_file_location("qosha_apps_api", _s_path)
    _s_mod = _a_ilu.module_from_spec(_s_spec); _a_sys.modules["qosha_apps_api"] = _s_mod
    _s_spec.loader.exec_module(_s_mod)
    router.include_router(_s_mod.router)


# --- Claude-owned decisions routes (INTERFACES.md §4.4). Do not edit. ---
import importlib.util as _q_ilu, pathlib as _q_pl, sys as _q_sys
_q_spec = _q_ilu.spec_from_file_location("qosha_decisions_api", _q_pl.Path(__file__).with_name("decisions_api.py"))
_q_mod = _q_ilu.module_from_spec(_q_spec); _q_sys.modules["qosha_decisions_api"] = _q_mod
_q_spec.loader.exec_module(_q_mod)
router.include_router(_q_mod.router, prefix="/decisions")


def _engine_api_pages_off():
    """The engine's API pages (/docs, /redoc, /openapi.json) are titled with the engine's name and draw their look from
    a public site; Qosha uses none of them (Ren, 3 Nov 21:46: no engine name on any page a person can open). They are
    taken off the dashboard this plugin runs in, so those addresses get the dashboard's own page (which opens Settings)."""
    ws = _q_sys.modules.get("hermes_cli.web_server")
    app = getattr(ws, "app", None)
    if app is None:
        return
    gone = {"/docs", "/docs/oauth2-redirect", "/redoc", "/openapi.json"}
    app.router.routes[:] = [r for r in app.router.routes if getattr(r, "path", None) not in gone]
    app.title, app.openapi_schema = "Qosha", None
    app.docs_url = app.redoc_url = app.openapi_url = None


_engine_api_pages_off()


def _thread_name_qosha():
    """The engine names its main thread after itself (Activity Monitor > Sample Process, hang and crash reports on
    macOS): Qosha's name instead, set from the main thread this module is loaded on (macOS only; best effort)."""
    if _q_sys.platform != "darwin" or threading.current_thread() is not threading.main_thread():
        return
    try:
        import ctypes
        import ctypes.util
        libc = ctypes.CDLL(ctypes.util.find_library("c"))
        libc.pthread_setname_np(b"qosha")
    except Exception:
        pass


_thread_name_qosha()


def _prime_agent_browser_lookup():
    """SETTLEFIX (5 Nov, council: Claude + GPT + Gemini, option B), cloud box only: every GET /api/tools/toolsets (the
    engine's Automations and Skills pages) runs `npx --version` twice to see whether its browser helper could start
    (tools.browser_tool._find_agent_browser(validate=False) does not keep the answer); a Node start costs seconds of the
    box's 0.5 vCPU each time. Here the engine's own lookup is made once and its own answer kept, exactly as its
    validated lookup keeps it (the npx branch of _find_agent_browser), so those calls start nothing. Only the npx case:
    if an agent-browser program exists, or npx doesn't answer, nothing is changed (no install is ever started)."""
    if os.environ.get("QOSHA_BOX") != "1":
        return
    try:
        import shutil
        from tools import browser_tool as bt
        if getattr(bt, "_agent_browser_resolved", True) or not hasattr(bt, "NPX_AGENT_BROWSER_SENTINEL"):
            return
        extended = bt._merge_browser_path("")
        local_bin = Path(bt.__file__).resolve().parent.parent / "node_modules" / ".bin"
        if (shutil.which("agent-browser") or (extended and shutil.which("agent-browser", path=extended))
                or (local_bin.is_dir() and shutil.which("agent-browser", path=str(local_bin)))):
            return
        if bt._resolve_npx_bin():
            bt._cached_agent_browser = bt.NPX_AGENT_BROWSER_SENTINEL
            bt._agent_browser_resolved = True
    except Exception:
        pass


_prime_agent_browser_lookup()


# --- Qosha updates and the one-time setup code (17 Nov 2026): qosha_guard/updater.py (routes under /updates, the
# engine's own self-update switched off, the daily check) and qosha_guard/setupcode.py (routes under /setup). ---
def _gate_down(reason):
    """The gate did not install: stay closed and say so (local install, dashboard process)."""
    if not _fs_local:
        return
    try:
        if _fs_mod is not None:
            _fs_mod.report_down(reason, router)
            return
    except Exception:
        pass
    # the fail-safe itself didn't load either (FO2-3): a minimal stand-in, every caller untrusted. Decisions refuse
    # approving, every /api write except declining and the updater is refused, /api sockets are closed, the pages say so.
    try:
        import json as _sd_json, re as _sd_re, types as _sd_types
        _msg = "Qosha's approval check didn't start, so nothing can be approved right now. Restart Qosha."
        _open = (_sd_re.compile(r"^/api/plugins/qosha/decisions/[^/]+/decline/?$"),
                 _sd_re.compile(r"^/api/plugins/qosha/updates/(check|apply|activity)/?$"))
        _fs_sys.modules["qosha_gate_failsafe"] = _sd_types.SimpleNamespace(
            FAILED=reason, check_decision=lambda approve: {"error": "approval_check_down", "plain": _msg} if approve else None)

        class _StandIn:
            def __init__(self, app):
                self.app = app

            async def __call__(self, scope, receive, send):
                path, kind = scope.get("path") or "", scope.get("type")
                if kind == "http" and path.startswith("/api/") and scope.get("method", "GET").upper() not in ("GET", "HEAD", "OPTIONS") \
                        and not any(rx.match(path) for rx in _open):
                    body = _sd_json.dumps({"detail": {"error": "approval_check_down", "plain": _msg}}).encode()
                    await send({"type": "http.response.start", "status": 503, "headers": [
                        (b"content-type", b"application/json"), (b"content-length", str(len(body)).encode())]})
                    await send({"type": "http.response.body", "body": body})
                    return
                if kind == "websocket" and path.startswith("/api/"):
                    await send({"type": "websocket.close", "code": 4403, "reason": "Qosha's approval check didn't start"})
                    return
                return await self.app(scope, receive, send)
        app = getattr(_fs_sys.modules.get("hermes_cli.web_server"), "app", None)
        if app is not None and not getattr(app, "_qosha_standin", False):
            if getattr(app, "middleware_stack", None) is None:
                app.add_middleware(_StandIn)
            else:
                app.middleware_stack = _StandIn(app.middleware_stack)
            app._qosha_standin = True

        @router.get("/approval-gate/window")
        def _sd_window():
            return {"window": None, "down": _msg}
    except Exception as _gd_exc:
        import logging as _gd_logging
        _gd_logging.getLogger("qosha.approval_gate").error("Qosha approval check: could not hold it closed: %s",
                                                            type(_gd_exc).__name__)


def _gate_confirm():
    """Open only when the gate really sits on the dashboard's app (a mount that returned without installing counts as
    down: Gemini FO-3, GPT FO-2)."""
    app = getattr(_a_sys.modules.get("hermes_cli.web_server"), "app", None)
    if getattr(app, "_qosha_owner_gate", False):
        if _fs_mod is not None:
            _fs_mod.release()
    elif _fs_local:
        _gate_down("the approval gate is not on the dashboard app")


for _u_name in ("approval_gate", "access", "updater", "setupcode", "inbox_watch", "wa_summary"):
    _u_path = _a_pl.Path(__file__).resolve().parent.parent / "qosha_guard" / (_u_name + ".py")
    if not _u_path.is_file():
        if _u_name == "approval_gate":
            _gate_down("approval_gate.py is missing")
        continue
    try:
        _u_spec = _a_ilu.spec_from_file_location("qosha_" + _u_name, _u_path)
        _u_mod = _a_ilu.module_from_spec(_u_spec); _a_sys.modules["qosha_" + _u_name] = _u_mod
        _u_spec.loader.exec_module(_u_mod)
        if _u_name in ("approval_gate", "updater", "access", "inbox_watch", "wa_summary"):
            _u_mod.mount(router)
            if _u_name == "approval_gate":
                _gate_confirm()   # approval_gate: only the Qosha window answers cards or changes approvals (21 Nov);
            #                        access: CONTRACT-ACCESS (routes under /access, the ID, the 2-minute check);
            #                        inbox_watch: routes under /inbox-watch, the job, the engine's cron ticker (21 Nov)
        elif _u_mod.router is not None:
            router.include_router(_u_mod.router, prefix="/setup")
    except Exception as _u_exc:   # the screens still work without it
        import logging as _u_logging
        _u_logging.getLogger("qosha.updates").warning("Qosha %s not set up: %s", _u_name, type(_u_exc).__name__)
        if _u_name == "approval_gate":
            _gate_down("%s: %s" % (type(_u_exc).__name__, str(_u_exc)[:120]))
