"""Qosha's Google write tool (1.20.9, CONTRACT-GEXEC + the 12-hour plan, 21 Nov 2026).

The Google sign-in Qosha keeps on disk can only read (google_connect.SIGNIN_SCOPES). A change in the person's Google
account (send an email, add/change/delete a calendar event, move a Drive file to the trash, share it) runs only here,
inside the engine's own process, after the person pressed Allow on its card:
  1. the request is checked against the fields each operation takes (nothing else gets through);
  2. Google's sign-in opens in the person's browser for that one operation's permission (a separate Cloud project,
     "Qosha Writes", so its grant never mixes with the read sign-in), for the account that is connected;
  3. the grant is kept in memory only, checked to be for that account, used for exactly the approved request, once;
  4. then it is revoked at Google (REVOKE_AFTER_USE, option A), so the next write needs the person's click on
     Google's page again. Nothing is written to disk at any step.
"""
from __future__ import annotations

import contextlib
import urllib.error
import hashlib
import json
import logging
import math
import os
import re
import sys
import threading
import time
import webbrowser
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

REVOKE_AFTER_USE = True     # option A (orchestrator 22:06: B lets any same-user program get a write grant with no click)
WAIT_SECONDS = 300
_G = "https://www.googleapis.com/auth/"
_ID = ["openid", _G + "userinfo.email"]
_EVENT = ("summary", "start", "end", "location", "description", "attendees", "calendar_id")
OPS = {   # operation: (Google permission, the card's kind, required fields, optional fields)
    "gmail.send": (_G + "gmail.send", "email.send", ("to", "subject", "body"), ("cc", "bcc", "thread_id", "in_reply_to")),
    "calendar.create": (_G + "calendar.events", "calendar.change", ("summary", "start", "end"), _EVENT),
    "calendar.update": (_G + "calendar.events", "calendar.change", ("event_id",), _EVENT),
    "calendar.delete": (_G + "calendar.events", "calendar.change", ("event_id",), ("calendar_id",)),
    # answer an invitation (cal-respond, 25 Nov 2026): on the primary calendar only, only the connected account's own
    # answer is sent. `summary`, `start` and `organizer` are shown on the card and checked live before the change
    "calendar.respond": (_G + "calendar.events", "calendar.invite", ("event_id", "summary", "start", "organizer", "response"), ()),
    "drive.trash": (_G + "drive", "delete", ("file_id",), ()),
    "drive.share": (_G + "drive", "share", ("file_id", "email", "role"), ()),
    # gap 6 (22 Nov 2026, SPEC-G; council D1-D9): organize Drive, make and add to Docs and Sheets. One file per card;
    # anything shared, in a Shared drive or not the person's own is refused (checked live, _private); new files go to
    # the top of My Drive. Every op asks only "drive" (it covers the Docs and Sheets APIs; orchestrator 22 Nov ~15:50: no
    # documents/spreadsheets/drive.file unless a real call proves it's needed), so a kept grant needs nothing more
    "drive.folder": (_G + "drive", "file.organize", ("name",), ()),
    "drive.move": (_G + "drive", "file.organize", ("file_id", "name", "to_folder_id", "to_folder_name"), ()),
    "drive.rename": (_G + "drive", "file.organize", ("file_id", "name", "new_name"), ()),
    "drive.copy": (_G + "drive", "file.organize", ("file_id", "name", "to_folder_id", "to_folder_name"), ("new_name",)),
    "docs.create": (_G + "drive", "file.edit", ("title", "text"), ()),
    "docs.append": (_G + "drive", "file.edit", ("document_id", "title", "text"), ()),
    "sheets.create": (_G + "drive", "file.edit", ("title", "rows"), ()),
    "sheets.append": (_G + "drive", "file.edit", ("spreadsheet_id", "title", "sheet", "rows"), ()),
    # Gmail tidying (SPEC-M, kind mail.tidy): one email of the person's own mailbox; INBOX/UNREAD labels only; undoable
    "gmail.archive": (_G + "gmail.modify", "mail.tidy", ("message_id", "subject"), ()),
    "gmail.unarchive": (_G + "gmail.modify", "mail.tidy", ("message_id", "subject"), ()),
    "gmail.mark_read": (_G + "gmail.modify", "mail.tidy", ("message_id", "subject"), ()),
    "gmail.mark_unread": (_G + "gmail.modify", "mail.tidy", ("message_id", "subject"), ()),
}
_ROLES = ("reader", "commenter", "writer")
_RESPONSES = ("accepted", "declined", "tentative")
NO_TITLE = "(no title)"     # an event without a title, as Qosha's calendar reader and Calendar show it (any case)
_TIDY = {"gmail.archive": ({"removeLabelIds": ["INBOX"]}, "gmail.unarchive"),
         "gmail.unarchive": ({"addLabelIds": ["INBOX"]}, "gmail.archive"),
         "gmail.mark_read": ({"removeLabelIds": ["UNREAD"]}, "gmail.mark_unread"),
         "gmail.mark_unread": ({"addLabelIds": ["UNREAD"]}, "gmail.mark_read")}
NO_SUBJECT = "(no subject)"
# the label each op changes, and whether it must be there for the op to change anything (M-2)
_STATE = {"gmail.archive": ("INBOX", True), "gmail.unarchive": ("INBOX", False),
          "gmail.mark_read": ("UNREAD", True), "gmail.mark_unread": ("UNREAD", False)}
_ALREADY = {"gmail.archive": "already archived", "gmail.unarchive": "already in the inbox",
            "gmail.mark_read": "already read", "gmail.mark_unread": "already unread"}
_NAMES = ("name", "new_name", "title", "sheet", "to_folder_name", "subject")       # shown on the card: no hidden characters (D8)
_FOLDER = "application/vnd.google-apps.folder"
_EDITORS = ("application/vnd.google-apps.document", "application/vnd.google-apps.spreadsheet",
            "application/vnd.google-apps.presentation", "application/vnd.google-apps.drawing")   # can be published
_DOC = "application/vnd.google-apps.document"
_SHEET = "application/vnd.google-apps.spreadsheet"
MAX_ROWS, MAX_CELLS, MAX_TEXT, MAX_NAME, MAX_DEPTH = 500, 50, 50000, 200, 25
NEW_SHEET_CELLS = 26        # a Sheet Drive makes has columns A to Z (R2-D)


class GrantError(Exception):
    pass


class PartlyDone(Exception):
    """The first of two requests was done, the second wasn't: said plainly, never repeated. `result` names what was
    made (journey 22 Nov 2026: without the new Sheet's id nobody could find, open or trash it)."""

    def __init__(self, msg: str, result: Optional[Dict[str, Any]] = None):
        super().__init__(msg)
        self.result = dict(result or {})


class ServiceOff(RuntimeError):
    """Google refused because the service (Docs, Sheets, ...) is switched off in Qosha's Google project (journey
    22 Nov 2026: Docs/Sheets were off and Qosha said only "Google said 403")."""

    def __init__(self, service: str):
        super().__init__("Google said 403")
        self.service = service


# which Google service a request went to: by the request's exact host, and on www.googleapis.com by its fixed API path
# (never by text anywhere in the address, which can hold ids and names; never from Google's answer) (GPT s1 H1)
_HOSTS = {"docs.googleapis.com": ("Google Docs", "docs.googleapis.com"),
          "sheets.googleapis.com": ("Google Sheets", "sheets.googleapis.com"),
          "gmail.googleapis.com": ("Gmail", "gmail.googleapis.com")}
_WWW_PATHS = (("/drive/", ("Google Drive", "drive.googleapis.com")), ("/upload/drive/", ("Google Drive", "drive.googleapis.com")),
              ("/calendar/", ("Google Calendar", "calendar-json.googleapis.com")))


def _service_for(url: str) -> Tuple[str, str]:
    """(the name a person reads, Google's id for the service) of the request's API."""
    from urllib.parse import urlparse
    u = urlparse(url)
    host = (u.hostname or "").lower()
    if host in _HOSTS:
        return _HOSTS[host]
    if host == "www.googleapis.com":
        for prefix, found in _WWW_PATHS:
            if u.path.startswith(prefix):
                return found
    return ("This Google service", "")


def _service_off(exc, url: str) -> Optional[str]:
    """The service's name when a 403 says the request's own service is switched off: Google's ErrorInfo with reason
    SERVICE_DISABLED (whose metadata.service, when given, must be that service), or the older accessNotConfigured.
    None for every other 403 or an unreadable answer: it stays an ordinary refusal (GPT s1 M1)."""
    try:
        err = json.loads(exc.read(65536).decode("utf-8", "replace")).get("error") or {}
        details = [d for d in (err.get("details") or []) if isinstance(d, dict)]
        errors = [e for e in (err.get("errors") or []) if isinstance(e, dict)]
    except Exception:  # noqa: BLE001
        return None
    name, service = _service_for(url)
    for d in details:
        if not str(d.get("@type", "")).endswith("google.rpc.ErrorInfo") or d.get("reason") != "SERVICE_DISABLED":
            continue
        meta = d.get("metadata") if isinstance(d.get("metadata"), dict) else {}
        if meta.get("service") and meta.get("service") != service:
            continue
        return name
    disabled = any(str(d.get("@type", "")).endswith("google.rpc.ErrorInfo") and d.get("reason") == "SERVICE_DISABLED"
                   for d in details)
    if not disabled and any(e.get("reason") == "accessNotConfigured" for e in errors):
        return name             # the older form, only when no ErrorInfo names a service (another one's isn't ours; M10)
    return None


def _acked(r) -> Dict[str, Any]:
    """A create's answer must name what was made; with no id it may or may not have been made (shrink review GPT H2)."""
    if not isinstance(r, dict) or not r.get("id"):
        raise OutcomeUnknown()
    return r


class OutcomeUnknown(Exception):
    """The request may have reached Google but its answer was lost: never sent again (GPT r1209 r2 HIGH 1)."""


class Refused(Exception):
    """Qosha read the item and won't change it (nothing was changed); the message says why in plain words."""


# The "Qosha Writes" app (Google Cloud project qosha-writes-7213, made 21 Nov 2026 22:10–22:22 MST): pinned, so no other
# app's file can stand in for it (a revoke in the read project would end the read sign-in) (GPT r2 HIGH 10)
PINNED_CLIENT_ID = "406638105175-o9d4dhig58b0rbfc578q331k3cdim08s.apps.googleusercontent.com"
PINNED_AUTH = "https://accounts.google.com/o/oauth2/auth"
PINNED_TOKEN = "https://oauth2.googleapis.com/token"


def _below_warning(record) -> bool:
    return record.levelno >= logging.WARNING


for _n in ("requests_oauthlib", "requests_oauthlib.oauth2_session", "oauthlib", "google_auth_oauthlib", "google.auth",
           "google.auth.transport.requests"):
    _lg = logging.getLogger(_n)
    if not any(getattr(f, "__name__", "") == "_below_warning" for f in _lg.filters):
        _lg.addFilter(_below_warning)      # token answers are logged at DEBUG: never, at any time (GPT r2 HIGH 12)


# The "Qosha Writes" sign-in app file travels inside the public update locked (Ren, 22:45 MST: "Locked in the update"):
# its key comes from the read sign-in app file every install already holds, so the public page shows nothing readable
# or scannable. It is opened in memory only. (A Desktop app's secret is not confidential to Google; this keeps it out
# of public view and out of secret scanners.)
LOCKED_FILE = Path(__file__).resolve().parent / "google_write_client.locked"


def _lock_key(read_client: Dict[str, Any]) -> bytes:
    r = list(read_client.values())[0] if read_client else {}
    return hashlib.sha256(b"qosha-write-client-v1\0" + str(r.get("client_id", "")).encode() + b"\0" +
                          str(r.get("client_secret", "")).encode()).digest()


def _stream(key: bytes, salt: bytes, n: int) -> bytes:
    out, i = bytearray(), 0
    while len(out) < n:
        out += hashlib.sha256(key + salt + i.to_bytes(8, "big")).digest()
        i += 1
    return bytes(out[:n])


def lock(write_client: Dict[str, Any], read_client: Dict[str, Any]) -> str:
    import base64
    import hmac
    key = _lock_key(read_client)
    salt = os.urandom(16)
    plain = json.dumps(write_client, sort_keys=True).encode()
    data = bytes(a ^ b for a, b in zip(plain, _stream(key, salt, len(plain))))
    mac = hmac.new(key, salt + data, hashlib.sha256).hexdigest()
    return json.dumps({"v": 1, "salt": base64.b64encode(salt).decode(), "data": base64.b64encode(data).decode(), "mac": mac})


def unlock(blob: str, read_client: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    import base64
    import hmac
    try:
        d = json.loads(blob)
        key = _lock_key(read_client)
        salt, data = base64.b64decode(d["salt"]), base64.b64decode(d["data"])
        if not hmac.compare_digest(hmac.new(key, salt + data, hashlib.sha256).hexdigest(), str(d["mac"])):
            return None
        return json.loads(bytes(a ^ b for a, b in zip(data, _stream(key, salt, len(data)))).decode())
    except Exception:
        return None


def _client_config(h: Path) -> Tuple[Optional[Dict[str, Any]], str]:
    """The "Qosha Writes" app: the plain file a new install carries, else the locked one in the update (in memory)."""
    plain = h / "google_write_client_secret.json"
    if plain.exists():
        try:
            return json.loads(plain.read_text(encoding="utf-8")), ""
        except Exception:
            return None, "Qosha's Google change sign-in file can't be read"
    if not LOCKED_FILE.exists():
        return None, "Qosha's Google change sign-in isn't set up on this computer yet"
    try:
        read = json.loads((h / "google_client_secret.json").read_text(encoding="utf-8"))
    except Exception:
        return None, "reconnect Google in Qosha to finish the update (Settings → Connections)"
    cfg = unlock(LOCKED_FILE.read_text(encoding="utf-8"), read)
    if cfg is None:
        return None, "reconnect Google in Qosha to finish the update (Settings → Connections)"
    return cfg, ""


# A request becomes runnable only when the person allowed its card: pre_tool_call records it as pending for that tool
# call (with the Google account the card named); the engine's post_approval_response with a consenting choice makes it
# runnable; each runs once. All in the engine's own memory: a program the agent starts has its own empty copy, and
# with approvals switched off nothing is ever consented, so nothing runs (GPT r1209 HIGH 8; r2 HIGH 2, 3).
_PENDING: Dict[str, Tuple[str, str, float]] = {}
_EXPECTED: Dict[str, Tuple[str, float]] = {}
_EXP_LOCK = threading.Lock()
_EXPECT_FOR = 900


def _key(args: Any) -> str:
    return hashlib.sha256(json.dumps(args if isinstance(args, dict) else {}, sort_keys=True, default=str).encode()).hexdigest()


def _prune(now: float) -> None:
    for d in (_PENDING, _EXPECTED):
        for k in [k for k, v in d.items() if now - v[-1] > _EXPECT_FOR]:
            d.pop(k, None)


def pending(tool_call_id: str, args: Any, account_: str) -> None:
    if not tool_call_id:
        return
    with _EXP_LOCK:
        now = time.monotonic()
        _prune(now)
        _PENDING[str(tool_call_id)] = (_key(args), str(account_ or "").lower(), now)


def consent(tool_call_id: str, allowed: bool) -> None:
    with _EXP_LOCK:
        p = _PENDING.pop(str(tool_call_id or ""), None)
        if p and allowed:
            _EXPECTED[p[0]] = (p[1], time.monotonic())


def _take(args: Any) -> Optional[str]:
    """The account the person allowed this exact request for, or None (not allowed, already done, or too old)."""
    with _EXP_LOCK:
        v = _EXPECTED.pop(_key(args), None)
        if v is None or time.monotonic() - v[1] > _EXPECT_FOR:
            return None
        return v[0]


@contextlib.contextmanager
def _quiet_oauth():
    """The OAuth libraries log whole token answers at DEBUG: never while a grant is exchanged, refused or revoked
    (GPT HIGH 6; P0 final pass H3). One counted guard for the whole process (the sign-in and the write module share
    it, even when loaded twice), covering every logger under those names; the person's levels come back when the
    last exchange ends."""
    import logging
    import types
    st = sys.modules.get("qosha_oauth_quiet_state")
    if st is None:
        st = sys.modules.setdefault("qosha_oauth_quiet_state", types.ModuleType("qosha_oauth_quiet_state"))
    if not hasattr(st, "lock"):
        st.lock, st.depth, st.saved = threading.Lock(), 0, {}
    names = ("requests_oauthlib", "oauthlib", "google_auth_oauthlib", "google.auth", "urllib3")
    with st.lock:
        if st.depth == 0:
            every = [n for n in list(logging.root.manager.loggerDict)
                     if any(n == p or n.startswith(p + ".") for p in names)]
            st.saved = {n: (logging.getLogger(n).level, logging.getLogger(n).propagate) for n in set(every) | set(names)}
            for n in st.saved:
                logging.getLogger(n).setLevel(logging.WARNING)
                logging.getLogger(n).propagate = False
        st.depth += 1
    try:
        yield
    finally:
        with st.lock:
            st.depth -= 1
            if st.depth == 0:
                for n, (lvl, prop) in st.saved.items():
                    logging.getLogger(n).setLevel(lvl)
                    logging.getLogger(n).propagate = prop
                st.saved = {}


def _event_id(op: str, clean: Dict[str, Any]) -> str:
    """A stable event id for an approved create (base32hex), so a repeated request can't make a second event."""
    d = hashlib.sha256((op + json.dumps(clean, sort_keys=True)).encode()).digest()
    alpha = "0123456789abcdefghijklmnopqrstuv"
    n = int.from_bytes(d[:20], "big")
    return "".join(alpha[(n >> (5 * i)) & 31] for i in range(32))


def _home() -> Path:
    try:
        from .google_connect import _home as gc_home   # the engine's profile-aware home, as Connect uses
        return Path(gc_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or (Path.home() / ".hermes"))


def account(home: Path) -> str:
    """The connected Google account: the read sign-in's credentials file is named after it."""
    files = sorted((home / "google_workspace_mcp" / "credentials").glob("*.json"))
    return files[0].stem if len(files) == 1 else ""


def validate(args: Any) -> Tuple[str, Dict[str, Any]]:
    a = args if isinstance(args, dict) else {}
    op = str(a.get("operation") or "")
    if op not in OPS:
        raise ValueError("Qosha can't do '%s' in Google yet. It can send an email, add, change or delete a calendar "
                         "event, answer a calendar invitation, move a Drive file to the trash or share it, make a folder, move, rename or copy a file, "
                         "make a Doc or Sheet, add text to a Doc or rows to a Sheet, or archive an email or mark it read or unread." % op[:40])
    _scope, _kind, need, opt = OPS[op]
    extra = [k for k in a if k not in ("operation",) + need + opt]
    if extra:
        raise ValueError("Not done: %s is not something Qosha passes to Google for %s." % (", ".join(sorted(extra))[:120], op))
    missing = [k for k in need if a.get(k) in (None, "", [])]
    if missing:
        raise ValueError("Not done: %s needs %s." % (op, ", ".join(missing)))
    if op in _NEW_OPS:
        empty = [k for k in opt if k in a and (a[k] in (None, "", []) or not isinstance(a[k], str))]
        if empty:                                  # absence means Google's default; an empty value never does (G-H5)
            raise ValueError("Not done: %s was given but empty; leave it out or give a value." % ", ".join(empty))
    clean = {k: a[k] for k in need + opt if a.get(k) not in (None, "", [])}
    if op == "calendar.update" and "summary" in a and a["summary"] == "":
        raise ValueError("Not done: clearing an event's title isn't offered; give the new title.")
    if op == "calendar.update":
        for k, empty in (("attendees", []), ("location", ""), ("description", "")):
            if k in a and a[k] == empty:
                clean[k] = empty               # an explicit empty value clears it (GPT HIGH 11; r2 HIGH 13)
    for k, v in clean.items():
        if k == "rows":
            _rows_ok(v, NEW_SHEET_CELLS if op == "sheets.create" else MAX_CELLS)
            continue
        if k == "attendees":
            if not (isinstance(v, list) and all(isinstance(x, str) for x in v)):
                raise ValueError("Not done: attendees must be a list of email addresses.")
        elif not isinstance(v, str):
            raise ValueError("Not done: %s must be text." % k)
    if op == "drive.share" and clean["role"] not in _ROLES:
        raise ValueError("Not done: role must be reader, commenter or writer.")
    if op == "calendar.respond":
        if clean["response"] not in _RESPONSES:
            raise ValueError("Not done: response must be accepted, declined or tentative.")
        for k in ("summary", "start", "organizer"):
            _name_ok(k, clean[k])
    for k in _NAMES:
        if k in clean and (op in _NEW_OPS or k != "subject"):
            _name_ok(k, clean[k])
    if op in ("docs.create", "docs.append"):
        _text_ok(clean["text"])
    size = len(clean.get("text", "")) + sum(len(str(c)) for r in clean.get("rows", []) for c in r)
    if size > MAX_TEXT:
        raise ValueError("Not done: that is more than %d characters for one change; split it." % MAX_TEXT)
    return op, clean


def _name_ok(k: str, v: str) -> None:
    """A name the card shows: 1-200 characters, none hidden or reordering (control or format characters) (D8)."""
    import unicodedata
    if not 1 <= len(v) <= MAX_NAME or any(unicodedata.category(c) in ("Cc", "Cf") for c in v):
        raise ValueError("Not done: %s must be 1 to %d visible characters (no hidden or direction characters)."
                         % (k.replace("_", " "), MAX_NAME))


def _text_ok(v: str) -> None:
    """Text Google Docs stores as given: Docs drops carriage returns and private-use characters, so the Doc would
    differ from the card (G-H7). New lines and tabs are fine."""
    import unicodedata
    if any(c not in "\n\t" and unicodedata.category(c) in ("Cc", "Co") for c in v):
        raise ValueError("Not done: the text has a hidden or special character Google Docs would drop (like a "
                         "carriage return); write it without that character.")


def _rows_ok(v: Any, cells: int = 0) -> None:
    cells = cells or MAX_CELLS
    bad = ValueError("Not done: rows must be a list of 1 to %d rows, each a list of 1 to %d text or number cells."
                     % (MAX_ROWS, cells))
    if not isinstance(v, list) or not 1 <= len(v) <= MAX_ROWS:
        raise bad
    for r in v:
        if not isinstance(r, list) or not 1 <= len(r) <= cells:
            raise bad
        for c in r:
            if isinstance(c, bool) or not isinstance(c, (str, int, float)):
                raise bad
            # Sheets keeps numbers as doubles: a number it would change is refused (G-H6)
            if (isinstance(c, float) and not math.isfinite(c)) or (isinstance(c, int) and abs(c) > 2 ** 53):
                raise ValueError("Not done: the number %s can't be kept exactly in a Sheet; write it as text." % str(c)[:40])


def _private(g: Any, file_id: str, who: str) -> Tuple[Optional[Dict[str, Any]], str]:
    """(the item's live details, "") when the person owns it and nobody else can see it, nor any folder above it, up to
    the top of My Drive; else (None, why). Read with the read sign-in; any doubt refuses (D2, D3)."""
    me = who.lower()
    item, cur, seen = None, file_id, 0
    while True:
        seen += 1
        if seen > MAX_DEPTH:
            return None, "its folders are nested too deep for Qosha to check"
        try:
            m = g.meta(cur)
        except Exception:  # noqa: BLE001
            return None, "Qosha couldn't check who can see it"
        if not isinstance(m, dict):
            return None, "Qosha couldn't check who can see it"
        item = item or m
        what = "it" if m is item else "a folder it is in"
        if m.get("ownedByMe") is not True:
            return None, "%s isn't yours" % what
        if m.get("shared") is True or m.get("driveId"):
            return None, "%s is shared or in a shared drive" % what
        if m.get("published") is True:
            return None, "%s is published to the web" % what
        if m.get("mimeType") in _EDITORS and "published" in m and m.get("published") is not False:
            return None, "Qosha couldn't check whether %s is published to the web" % what
        if m.get("trashed") is True:
            return None, "%s is in the trash" % what
        perms = m.get("permissions")
        if not isinstance(perms, list) or not perms or any(not isinstance(p, dict) or p.get("type") != "user" or
                                              str(p.get("emailAddress") or "").lower() != me for p in perms):
            return None, "someone else can see %s" % what
        parents = m.get("parents") or []
        if not isinstance(parents, list) or len(parents) > 1:
            return None, "%s is in more than one folder" % what
        if not parents:
            return item, ""
        cur = str(parents[0])


def _check(g: Any, op: str, c: Dict[str, Any], who: str, seen: Optional[Dict[str, Any]] = None) -> str:
    """Why this change is refused ("" when every target is the person's own, private, and named as on the card).
    `seen` gets the checked file's parents: a move removes exactly those, never a later read's (G-H4)."""
    moved: Dict[str, Any] = {} if seen is None else seen
    def one(fid: str, shown: str, kind: str, folder: Optional[bool], mime: str = "") -> str:
        m, why = _private(g, fid, who)
        if m is not None and kind == "file":
            moved["parents"] = [str(p) for p in (m.get("parents") or [])]
        if m is None:
            return "Qosha only changes files nobody else can see, and %s %s" % (
                {"file": "the file", "dest": "the folder it would go to", "doc": "the Doc", "sheet": "the Sheet"}[kind], why)
        live = str(m.get("name") or "")
        if live != shown:
            # the live name is never echoed (it may be someone else's text, M-5)
            return "the card showed '%s', but %s is different now" % (
                shown, {"file": "the file's name", "dest": "the folder's name", "doc": "the Doc's title",
                        "sheet": "the Sheet's title"}[kind])
        if kind == "dest":
            if not m.get("id"):
                return "Qosha couldn't check which folder that is"
            moved["dest_id"] = str(m["id"])         # the live id: "root" and its real id are the same folder (R2-B)
        is_folder = m.get("mimeType") == _FOLDER
        if folder is True and not is_folder:
            return "'%s' is not a folder" % shown
        if folder is False and is_folder:
            return "Qosha doesn't move or copy whole folders yet ('%s' is a folder)" % shown
        if mime and m.get("mimeType") != mime:
            return "'%s' is not a Google %s" % (shown, "Doc" if mime == _DOC else "Sheet")
        return ""
    if op in _TIDY:
        try:
            m = g.message(c["message_id"])
        except Exception:  # noqa: BLE001
            return "Qosha couldn't find that email in your mailbox"
        labels = m.get("labelIds") if isinstance(m, dict) else None
        if not isinstance(m, dict) or m.get("id") != c["message_id"] or not isinstance(labels, list) or \
                not all(isinstance(x, str) for x in labels) or not isinstance(m.get("subject", ""), str):
            return "Qosha couldn't find that email in your mailbox"      # incomplete answers prove nothing (M-3)
        live = m.get("subject") or NO_SUBJECT                            # verbatim; only empty is "(no subject)" (M-4)
        try:
            _name_ok("subject", live)
        except ValueError:
            return "the email's subject can't be shown on a card exactly"
        if live != c["subject"]:
            return "the card showed '%s', but the email's subject is different now" % c["subject"]   # no echo (M-5)
        if "TRASH" in labels or "SPAM" in labels:
            return "Qosha doesn't tidy emails in the trash or spam"
        label, present = _STATE[op]
        if (label in labels) != present:
            if seen is not None:
                seen["already"] = True          # nothing to do: no request and no Undo (M-2)
            return ""
        return ""
    if op in ("drive.move", "drive.copy"):
        why = one(c["file_id"], c["name"], "file", False) or one(c["to_folder_id"], c["to_folder_name"], "dest", True)
        if why or op == "drive.copy":
            return why
        here = moved.get("parents") or []
        if not here:
            return "the file isn't in any folder Qosha can move it out of"
        return "it is already in that folder" if moved.get("dest_id") in here or c["to_folder_id"] in here else ""
    if op == "drive.rename":
        return one(c["file_id"], c["name"], "file", None)
    if op == "docs.append":
        return one(c["document_id"], c["title"], "doc", None, _DOC)
    if op == "sheets.append":
        why = one(c["spreadsheet_id"], c["title"], "sheet", None, _SHEET)
        if why:
            return why
        try:
            info = g.sheet_info(c["spreadsheet_id"])
            tabs = info.get("tabs")
        except Exception:  # noqa: BLE001
            return "Qosha couldn't read the Sheet's tabs"
        if info.get("external") is True:
            # a formula already in the Sheet could send the new cells out (G-H3)
            return "the Sheet may send its cells to other websites (it allows formulas that fetch from them)"
        return "" if isinstance(tabs, list) and c["sheet"] in tabs else "the Sheet has no tab called '%s'" % c["sheet"]
    return ""


class Google:
    """The real Google side. Every method keeps tokens in memory only."""

    def obtain(self, client_config: Dict[str, Any], scopes: list, login_hint: str, timeout: int) -> Any:
        from http.server import BaseHTTPRequestHandler, HTTPServer
        from google_auth_oauthlib.flow import Flow
        got: Dict[str, Any] = {}
        done = threading.Event()

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                from urllib.parse import parse_qs, urlparse
                q = parse_qs(urlparse(self.path).query)
                if "state" in q or "error" in q:
                    got.update({k: v[0] for k, v in q.items()})
                    done.set()
                body = b"<p>Qosha got Google's answer. You can close this tab.</p>"
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        srv = HTTPServer(("127.0.0.1", 0), H)
        srv.timeout = 0.5
        try:
            flow = Flow.from_client_config(client_config, scopes=scopes,
                                                 redirect_uri="http://127.0.0.1:%d/" % srv.server_address[1],
                                                 autogenerate_code_verifier=True)   # PKCE: the verifier stays here
            url, state = flow.authorization_url(login_hint=login_hint, prompt="consent")
            webbrowser.open(url)
            end = time.monotonic() + timeout
            while not done.is_set() and time.monotonic() < end:
                srv.handle_request()
        finally:
            srv.server_close()
        if not done.is_set():
            raise GrantError("timeout")
        if got.get("error") or got.get("state") != state or not got.get("code"):
            raise GrantError("refused")
        os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"
        with _quiet_oauth():
            flow.fetch_token(code=got["code"])
        return flow.credentials

    def who(self, creds) -> str:
        import urllib.request
        req = urllib.request.Request("https://openidconnect.googleapis.com/v1/userinfo",
                                     headers={"Authorization": "Bearer " + creds.token})
        with urllib.request.urlopen(req, timeout=15) as r:
            return str(json.loads(r.read().decode("utf-8")).get("email") or "")

    _open = None
    home: Optional[Path] = None

    def _read(self, api: str, version: str):
        """A Google service on the READ sign-in (it can only read): who can see a file, its name, a Sheet's tabs.
        Refreshed in memory only, never saved: a late refresh can't put an older sign-in back over a newer one
        (shrink review GPT H1). Never logs a token."""
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build
        try:
            data = json.loads(((self.home or _home()) / "google_token.json").read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            raise RuntimeError("not signed in to Google") from None
        if not isinstance(data, dict) or not data.get("refresh_token"):
            raise RuntimeError("not signed in to Google")
        creds = Credentials.from_authorized_user_info(data)
        if not creds.valid:
            creds.refresh(Request())                         # in memory: the file is never written here
        return build(api, version, credentials=creds, cache_discovery=False)

    def meta(self, file_id: str) -> Dict[str, Any]:
        d = self._read("drive", "v3")
        m = d.files().get(fileId=file_id, supportsAllDrives=True,
                          fields="id,name,mimeType,ownedByMe,shared,driveId,parents,trashed").execute()
        perms, token = [], None
        while True:
            # the published view too: "Publish to the web" readers are someone else (G-H2)
            r = d.permissions().list(fileId=file_id, supportsAllDrives=True, pageToken=token,
                                     includePermissionsForView="published",
                                     fields="nextPageToken,permissions(type,role,emailAddress)").execute()
            perms += r.get("permissions") or []
            token = r.get("nextPageToken")
            if not token:
                break
        m["permissions"] = perms
        if m.get("mimeType") in _EDITORS:
            # "Publish to the web" lives on the revisions, not on the permissions (N-H1): any published one counts
            token, published, seen_any = None, False, False
            while True:
                r = d.revisions().list(fileId=file_id, pageToken=token,
                                       fields="nextPageToken,revisions(published,publishAuto)").execute()
                revs = r.get("revisions") or []
                seen_any = seen_any or bool(revs)
                published = published or any(v.get("published") or v.get("publishAuto") for v in revs)
                token = r.get("nextPageToken")
                if not token:
                    break
            m["published"] = published if seen_any else None     # no revision listed: can't tell (R2-A)
        return m

    def message(self, message_id: str) -> Dict[str, Any]:
        """One email of the person's own mailbox (users/me), read with the read sign-in; raises when it isn't there."""
        m = self._read("gmail", "v1").users().messages().get(userId="me", id=message_id, format="metadata",
                                                              metadataHeaders=["Subject"]).execute()
        subj = next((str(h.get("value") or "") for h in (m.get("payload") or {}).get("headers") or []
                     if str(h.get("name") or "").lower() == "subject"), "")
        raw = m.get("labelIds", [])               # Gmail leaves an empty list out; any other shape is refused (M-3)
        return {"id": m.get("id"), "labelIds": list(raw) if isinstance(raw, list) else None, "subject": subj}

    def sheet_info(self, spreadsheet_id: str) -> Dict[str, Any]:
        """A Sheet's tab names, and whether its formulas may fetch from other websites (True/False, None = not said)."""
        r = self._read("sheets", "v4").spreadsheets().get(
            spreadsheetId=spreadsheet_id,
            fields="properties.importFunctionsExternalUrlAccessAllowed,sheets.properties.title").execute()
        ext = (r.get("properties") or {}).get("importFunctionsExternalUrlAccessAllowed")
        return {"tabs": [str(x.get("properties", {}).get("title", "")) for x in r.get("sheets") or []],
                "external": ext if isinstance(ext, bool) else None}

    def _call(self, creds, method: str, url: str, body: Optional[Dict[str, Any]] = None,
              raw: Optional[bytes] = None, ctype: str = "application/json") -> Dict[str, Any]:
        """One HTTPS request, sent once: no library retry or reconnect can send a change twice (GPT r2 HIGH 1)."""
        import urllib.request
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        req = urllib.request.Request(url, data=data, method=method,
                                     headers={"Authorization": "Bearer " + str(getattr(creds, "token", "")),
                                              "Content-Type": ctype})
        opener = self._open or urllib.request.urlopen
        try:
            with opener(req, timeout=60) as r:
                raw = r.read()
            return json.loads(raw.decode("utf-8")) if raw else {}     # an unreadable answer is not a refusal (M-6)
        except urllib.error.HTTPError as exc:
            if exc.code >= 500:                    # Google's side failed: it may still have done it (R2-C2)
                raise OutcomeUnknown() from None
            off = _service_off(exc, url) if exc.code == 403 else None
            if off:
                raise ServiceOff(off) from None
            raise RuntimeError("Google said %s" % exc.code) from None
        except Exception:
            raise OutcomeUnknown() from None

    def perform(self, op: str, c: Dict[str, Any], creds) -> Dict[str, Any]:
        import urllib.error  # noqa: F401  (used in _call)
        from urllib.parse import quote
        if op == "gmail.send":
            import base64
            from email.mime.text import MIMEText
            m = MIMEText(c["body"], "plain", "utf-8")
            m["To"], m["Subject"] = c["to"], c["subject"]
            for k, h in (("cc", "Cc"), ("bcc", "Bcc"), ("in_reply_to", "In-Reply-To")):
                if c.get(k):
                    m[h] = c[k]
            if c.get("in_reply_to"):
                m["References"] = c["in_reply_to"]
            body = {"raw": base64.urlsafe_b64encode(m.as_bytes()).decode()}
            if c.get("thread_id"):
                body["threadId"] = c["thread_id"]
            r = self._call(creds, "POST", "https://gmail.googleapis.com/gmail/v1/users/me/messages/send", body)
            return {"id": r.get("id")}
        if op.startswith("calendar."):
            cal = quote(c.get("calendar_id") or "primary", safe="")
            base = "https://www.googleapis.com/calendar/v3/calendars/%s/events" % cal
            if op == "calendar.delete":
                self._call(creds, "DELETE", base + "/" + quote(c["event_id"], safe=""))
                return {"deleted": c["event_id"]}
            if op == "calendar.respond":
                return self._respond(creds, base + "/" + quote(c["event_id"], safe=""), c)
            body = {k: c[k] for k in ("summary", "location", "description") if k in c}
            for k in ("start", "end"):
                if k in c:
                    body[k] = {"dateTime": c[k]}
            if "attendees" in c:
                body["attendees"] = [{"email": x} for x in c["attendees"]]
            if op == "calendar.create":
                body["id"] = _event_id(op, c)
                return {"id": self._call(creds, "POST", base, body).get("id")}
            return {"id": self._call(creds, "PATCH", base + "/" + quote(c["event_id"], safe=""), body).get("id")}
        if op in _TIDY:
            body, undo = _TIDY[op]
            r = self._call(creds, "POST", "https://gmail.googleapis.com/gmail/v1/users/me/messages/%s/modify"
                           % quote(c["message_id"], safe=""), body)
            if not isinstance(r, dict) or r.get("id") != c["message_id"]:
                raise OutcomeUnknown()             # Gmail didn't confirm this email: no Undo offered (M-6)
            return {"id": c["message_id"],
                    "undo": {"operation": undo, "message_id": c["message_id"], "subject": c["subject"]}}
        if op in _NEW_OPS:
            return self._perform_new(op, c, creds)
        f = "https://www.googleapis.com/drive/v3/files/" + quote(c["file_id"], safe="")
        if op == "drive.trash":
            self._call(creds, "PATCH", f + "?supportsAllDrives=true", {"trashed": True})
            return {"trashed": c["file_id"]}
        r = self._call(creds, "POST", f + "/permissions?sendNotificationEmail=false&supportsAllDrives=true",
                       {"type": "user", "role": c["role"], "emailAddress": c["email"]})
        return {"permission": r.get("id")}

    def _respond(self, creds, url: str, c: Dict[str, Any]) -> Dict[str, Any]:
        """Answer an invitation on the primary calendar: read the event, check it is the one the card showed and that
        the connected account is on it once as an ordinary guest, then send only that account's own answer
        (attendeesOmitted: Google changes only that answer; nobody else's entry is ever sent)."""
        try:
            ev = self._call(creds, "GET", url)
        except ServiceOff:
            raise
        except RuntimeError as exc:
            raise Refused("Qosha couldn't read the event (%s)" % exc) from None
        except Exception:  # noqa: BLE001
            raise Refused("Qosha couldn't read the event from Google") from None
        if not isinstance(ev, dict):
            raise Refused("Qosha couldn't read the event from Google")
        if ev.get("status") == "cancelled":
            raise Refused("the event was cancelled")
        if ev.get("recurrence"):
            raise Refused("this is a whole repeating series; answer one occurrence at a time")
        title = str(ev.get("summary") or "")
        if title != c["summary"] and not (not title and c["summary"].lower() == NO_TITLE):
            raise Refused("the card showed \u201c%s\u201d, but the event's title in Google is different now" % c["summary"])
        st = ev.get("start") if isinstance(ev.get("start"), dict) else {}
        start = str(st.get("dateTime") or st.get("date") or "")
        if start != c["start"]:
            raise Refused("the card showed the start as %s, but the event's start in Google is different now" % c["start"])
        org = ev.get("organizer") if isinstance(ev.get("organizer"), dict) else {}
        org_email = str(org.get("email") or "").lower()
        if org_email != c["organizer"].lower():
            raise Refused("the card showed the organizer as %s, but the event's organizer in Google is different now"
                          % c["organizer"])
        me = str(c.get("_me") or "")
        if not me:
            raise Refused("Qosha doesn't know which Google account to answer for")
        if org_email == me.lower() or org.get("self") is True:
            raise Refused("you're the organizer of this event, so there is no invitation to answer")
        guests = ev.get("attendees")
        if not isinstance(guests, list) or not guests:
            raise Refused("this event has no guests, so there is no invitation to answer")
        mine = [x for x in guests if isinstance(x, dict) and str(x.get("email") or "").lower() == me.lower()]
        if not mine:
            raise Refused("you're not a guest on this event (Qosha couldn't find %s on its guest list; an invitation "
                          "through a group can't be answered from Qosha yet)" % me)
        if len(mine) > 1:
            raise Refused("%s is on this event's guest list more than once" % me)
        if mine[0].get("resource") is True or mine[0].get("organizer") is True:
            raise Refused("%s isn't an ordinary guest on this event" % me)
        if mine[0].get("responseStatus") == c["response"]:
            return {"id": ev.get("id"), "already": c["response"]}      # already the answer: nobody is told again
        body = {"attendees": [{"email": me, "responseStatus": c["response"]}], "attendeesOmitted": True}
        r = self._call(creds, "PATCH", url + "?sendUpdates=all", body)
        if not isinstance(r, dict) or not r.get("id"):
            raise OutcomeUnknown()             # Google didn't confirm the event: it may or may not have the answer
        return {"id": r.get("id"), "response": c["response"]}

    def _perform_new(self, op: str, c: Dict[str, Any], creds) -> Dict[str, Any]:
        """Gap 6 (SPEC-G section 3): one request per change; values are never read as formulas."""
        from urllib.parse import quote
        q = lambda v: quote(str(v), safe="")
        drv = "https://www.googleapis.com/drive/v3/files"
        if op == "drive.folder":
            r = _acked(self._call(creds, "POST", drv + "?supportsAllDrives=true&ignoreDefaultVisibility=true",
                           {"name": c["name"], "mimeType": _FOLDER}))
            return {"id": r.get("id")}
        if op == "drive.move":
            olds = ",".join(q(p) for p in c["_parents"])
            r = self._call(creds, "PATCH", "%s/%s?addParents=%s&removeParents=%s&supportsAllDrives=true" % (
                drv, q(c["file_id"]), q(c["to_folder_id"]), olds), {})
            return {"moved": r.get("id") or c["file_id"]}
        if op == "drive.rename":
            r = self._call(creds, "PATCH", "%s/%s?supportsAllDrives=true" % (drv, q(c["file_id"])), {"name": c["new_name"]})
            return {"renamed": r.get("id") or c["file_id"]}
        if op == "drive.copy":
            body = {"parents": [c["to_folder_id"]]}
            if c.get("new_name"):
                body["name"] = c["new_name"]
            r = _acked(self._call(creds, "POST", "%s/%s/copy?supportsAllDrives=true&ignoreDefaultVisibility=true" % (drv, q(c["file_id"])),
                           body))
            return {"id": r.get("id")}
        if op == "docs.create":
            import uuid
            b = "qosha-" + uuid.uuid4().hex
            raw = ("--%s\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n%s\r\n--%s\r\nContent-Type: text/plain; "
                   "charset=UTF-8\r\n\r\n" % (b, json.dumps({"name": c["title"], "mimeType": _DOC}), b)).encode() + \
                c["text"].encode("utf-8") + ("\r\n--%s--\r\n" % b).encode()
            r = _acked(self._call(creds, "POST", "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&"
                           "supportsAllDrives=true&ignoreDefaultVisibility=true", raw=raw, ctype="multipart/related; boundary=" + b))
            return {"id": r.get("id")}
        if op == "docs.append":
            self._call(creds, "POST", "https://docs.googleapis.com/v1/documents/%s:batchUpdate" % q(c["document_id"]),
                       {"requests": [{"insertText": {"endOfSegmentLocation": {}, "text": "\n" + c["text"]}}]})
            return {"appended": c["document_id"]}
        if op == "sheets.create":
            # first a read-only check that the Sheets service is on: if it's off, nothing is made (journey 22 Nov).
            # A made-up id answers 404 when the service is on; only "switched off" stops here, nothing else does.
            try:
                self._call(creds, "GET", "https://sheets.googleapis.com/v4/spreadsheets/qosha-check?fields=spreadsheetId")
            except ServiceOff:
                raise
            except Exception:  # noqa: BLE001
                pass
            # made through Drive so the domain's default sharing is not applied (G-H1), then the rows as values (RAW)
            r = self._call(creds, "POST", drv + "?supportsAllDrives=true&ignoreDefaultVisibility=true",
                           {"name": c["title"], "mimeType": _SHEET})
            sid = r.get("id") if isinstance(r, dict) else None
            if not sid:
                raise OutcomeUnknown()     # no id in Google's answer: it may or may not have made it (review GPT H2)
            try:
                ack = self._call(creds, "PUT", "https://sheets.googleapis.com/v4/spreadsheets/%s/values/A1?"
                                 "valueInputOption=RAW" % q(sid), {"values": c["rows"]})
            except ServiceOff as exc:              # the check's answer was lost, then Sheets refused as switched off
                raise PartlyDone("the empty Sheet '%s' was made, but its rows were not added: %s isn't switched on for "
                                 "Qosha yet (Google said 403)" % (c["title"], exc.service), {"id": sid}) from None
            except RuntimeError as exc:            # Google answered with an error: the rows were not added
                raise PartlyDone("the empty Sheet '%s' was made, but its rows were not added (%s)" % (c["title"], exc),
                                 {"id": sid}) from None
            except Exception:  # noqa: BLE001     # the answer was lost or unreadable: say so, never guess (R2-C)
                raise PartlyDone("the Sheet '%s' was made, but Google's answer about its rows was lost, so they may or "
                                 "may not be in it; check it in Google before trying again" % c["title"],
                                 {"id": sid}) from None
            if not isinstance(ack, dict) or type(ack.get("updatedRows")) is not int or ack["updatedRows"] != len(c["rows"]):
                raise PartlyDone("the Sheet '%s' was made, but Google didn't confirm its rows; check it in Google "
                                 "before trying again" % c["title"], {"id": sid})
            return {"id": sid}
        # sheets.append: RAW (text stays text, never a formula) and INSERT_ROWS (nothing below is overwritten)
        rng = q("'%s'!A1" % c["sheet"].replace("'", "''"))
        r = self._call(creds, "POST", "https://sheets.googleapis.com/v4/spreadsheets/%s/values/%s:append?"
                       "valueInputOption=RAW&insertDataOption=INSERT_ROWS" % (q(c["spreadsheet_id"]), rng),
                       {"values": c["rows"]})
        up = r.get("updates") if isinstance(r, dict) else None
        up = up if isinstance(up, dict) else {}          # any other shape is no confirmation (GPT v H5)
        if type(up.get("updatedRows")) is not int or up["updatedRows"] != len(c["rows"]):
            raise OutcomeUnknown()         # Google didn't confirm the rows: they may or may not be in it (review GPT H2)
        return {"updated": up.get("updatedRange")}

    def revoke(self, creds) -> bool:
        from .google_connect import _revoke
        tok = getattr(creds, "refresh_token", None) or getattr(creds, "token", None)
        return bool(tok) and _revoke(str(tok))


def _client_ok(h: Path, cfg: Dict[str, Any]) -> str:
    """Only the pinned "Qosha Writes" app, with Google's own endpoints, as the file's one and only entry (the sign-in
    library would prefer any "web" entry beside it) (GPT r1209 HIGH 7; r2 HIGH 10; verification HIGH 6)."""
    if not isinstance(cfg, dict) or list(cfg) != ["installed"]:
        return "Qosha's Google change sign-in is set up wrongly (it must be Qosha's own Google change app)"
    w = cfg["installed"] if isinstance(cfg.get("installed"), dict) else {}
    if w.get("client_id") != PINNED_CLIENT_ID or w.get("token_uri") != PINNED_TOKEN or w.get("auth_uri") != PINNED_AUTH:
        return "Qosha's Google change sign-in is set up wrongly (it must be Qosha's own Google change app)"
    return ""


_LEFT_GRANTS: list = []          # grants Google didn't confirm withdrawn: no new write until they are (GPT r2 HIGH 11)


def _withdraw(g, creds, tries: int, pause: float) -> bool:
    for _i in range(tries):
        try:
            if g.revoke(creds):
                return True
        except Exception:  # noqa: BLE001
            pass
        time.sleep(pause)
    return False


def run(args: Any, home: Optional[Path] = None, google: Optional[Any] = None) -> Dict[str, Any]:
    """Does one change the person allowed. Never raises; never writes a file; never logs a token."""
    before = len(_LEFT_GRANTS)
    r = _run(args, home, google)
    return _note_left(r) if len(_LEFT_GRANTS) > before else r


def _run(args: Any, home: Optional[Path] = None, google: Optional[Any] = None) -> Dict[str, Any]:
    g = google or Google()
    pause = 0 if google is not None else 1
    for creds in list(_LEFT_GRANTS):           # first, any grant still out there from an earlier change
        if _withdraw(g, creds, 2, pause):
            _LEFT_GRANTS.remove(creds)
    if _LEFT_GRANTS:
        return {"ok": False, "message": "Not done: Google still holds the permission from the last change and Qosha "
                "couldn't withdraw it yet. Try again in a minute, or remove it at myaccount.google.com/permissions "
                "(Qosha Writes)."}
    h = Path(home) if home else _home()
    try:
        op, clean = validate(args)
    except ValueError as exc:
        return {"ok": False, "message": str(exc)}
    allowed_for = _take(args)
    if allowed_for is None:
        return {"ok": False, "message": "Not done: this change wasn't allowed on Qosha's card (or was already done)."}
    who = account(h)
    cfg, bad = _client_config(h)
    bad = bad or _client_ok(h, cfg)
    if bad:
        return {"ok": False, "message": "Not done: %s." % bad}
    if not who:
        return {"ok": False, "message": "Not done: connect Google in Qosha first (Settings → Connections)."}
    if allowed_for != who.lower():           # exact: a card shown with no account never covers one (verification HIGH 8)
        return {"ok": False, "message": "Not done: the card was for %s, but Google is now connected as %s." % (allowed_for, who)}
    if op in _NEW_OPS:
        if getattr(g, "home", None) is None:
            try:
                g.home = h
            except Exception:  # noqa: BLE001
                pass
        first: Dict[str, Any] = {}
        why = _check(g, op, clean, who, first)     # before Google's page: a refused change never opens it
        if why:
            return {"ok": False, "message": "Not done: %s. Nothing was changed." % why}
        if first.get("already"):
            return {"ok": True, "message": "Nothing to do: the email is %s." % _ALREADY[op], "result": {}}
    creds = None
    try:
        creds = g.obtain({"installed": dict(cfg["installed"])}, sorted(set([OPS[op][0]] + _ID)), who, WAIT_SECONDS)
        if str(g.who(creds)).lower() != who.lower():
            return {"ok": False, "message": "Not done: Google's page was finished for another account. Use %s." % who}
        granted = getattr(creds, "granted_scopes", None)
        if granted is not None and OPS[op][0] not in list(granted):
            # every box on Google's page starts unticked: this change's own box wasn't ticked (P0)
            return {"ok": False, "message": "Not done: the permission box on Google's page wasn't ticked, so nothing was "
                    "changed. Try again, and tick the box (or \u201cSelect all\u201d) before pressing Continue."}
        if account(h).lower() != who.lower():
            return {"ok": False, "message": "Not done: Google was disconnected or changed in Qosha meanwhile."}
        if op in _NEW_OPS:
            seen: Dict[str, Any] = {}
            why = _check(g, op, clean, who, seen)  # again, just before the change (it may have been shared meanwhile)
            if why:
                return {"ok": False, "message": "Not done: %s. Nothing was changed." % why}
            if seen.get("already"):
                return {"ok": True, "message": "Nothing to do: the email is %s." % _ALREADY[op], "result": {}}
            if op == "drive.move":
                clean = dict(clean, _parents=seen["parents"])
        if op == "calendar.respond":
            clean = dict(clean, _me=who)           # the connected account: the only guest entry ever answered
        out = g.perform(op, clean, creds)
        return {"ok": True, "message": "Done in Google (%s)." % op, "result": out}
    except Refused as exc:
        return {"ok": False, "message": "Not done: %s. Nothing was changed." % exc}
    except PartlyDone as exc:
        return {"ok": False, "message": "Partly done: %s. Qosha won't repeat it on its own." % exc, "result": exc.result}
    except OutcomeUnknown:
        return {"ok": False, "message": "Outcome unknown: Google's answer was lost, so it may or may not have been done. "
                "Check in Google before trying again (Qosha won't repeat it on its own)."}
    except GrantError as exc:
        return {"ok": False, "message": "Not done: Google's page wasn't finished%s, so nothing was changed." %
                (" in time" if str(exc) == "timeout" else "")}
    except ServiceOff as exc:
        return {"ok": False, "message": "Not done: %s isn't switched on for Qosha yet, so nothing was changed "
                "(Google said 403). It has to be switched on in Qosha's Google setup first." % exc.service}
    except RuntimeError as exc:
        return {"ok": False, "message": "Not done: %s; nothing more was tried." % exc}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "message": "Not done: Google answered with an error (%s); nothing more was tried." % type(exc).__name__}
    finally:
        if creds is not None and REVOKE_AFTER_USE and not _withdraw(g, creds, 3, pause):
            _LEFT_GRANTS.append(creds)          # kept in memory only, to withdraw before any next write
        creds = None


_NEW_OPS = frozenset(("drive.folder", "drive.move", "drive.rename", "drive.copy", "docs.create", "docs.append",
                      "sheets.create", "sheets.append", "gmail.archive", "gmail.unarchive", "gmail.mark_read",
                      "gmail.mark_unread"))


def _note_left(r: Dict[str, Any]) -> Dict[str, Any]:
    if _LEFT_GRANTS:
        r = dict(r)
        r["message"] = (r.get("message", "") + " Qosha could not withdraw Google's permission for this change "
                        "afterwards; it will try again before the next change. The person can also remove it at "
                        "myaccount.google.com/permissions (Qosha Writes).")
    return r


SCHEMA = {"name": "qosha_google_change",
          "description": ("Change something in the person's Google account: send an email (gmail.send), add, change or "
                          "delete a calendar event (calendar.create/update/delete), answer an invitation the person is a guest on "
                          "on their primary calendar (calendar.respond: event_id of one occurrence, never a whole repeating "
                          "series; summary, start and organizer exactly as Calendar shows them (start: its dateTime, or date "
                          "for an all-day event; organizer: the organizer's email); response accepted/declined/tentative; "
                          "only the person's own answer is sent, and Google tells the organizer and may notify the other "
                          "guests; never use calendar.update for this), move a Drive file to the trash "
                          "(drive.trash) or share it (drive.share), make a folder at the top of My Drive (drive.folder), "
                          "move one file into a folder, rename one file or folder, copy one file into a folder "
                          "(drive.move/rename/copy: give each file's and folder's current name exactly as Drive shows "
                          "it), make a Doc or Sheet at the top of My Drive (docs.create, sheets.create), add plain text "
                          "to the end of a Doc (docs.append) or rows to a Sheet's tab (sheets.append; give the current "
                          "title). Only files the person owns that nobody else can see can be moved, renamed, copied or "
                          "added to. Tidy one email of the person's own Gmail: archive, unarchive, mark read or unread "
                          "(gmail.archive / gmail.unarchive / gmail.mark_read / gmail.mark_unread, with its message_id and "
                          "its subject exactly as Gmail shows it, or (no subject)). The person approves it on Qosha's card, then confirms on Google's page in their "
                          "browser. Google reads go through the google tools (search, get, list)."),
          "parameters": {"type": "object", "properties": {
              "operation": {"type": "string", "enum": sorted(OPS)},
              "to": {"type": "string"}, "cc": {"type": "string"}, "bcc": {"type": "string"},
              "subject": {"type": "string"}, "body": {"type": "string", "description": "plain text"},
              "thread_id": {"type": "string"}, "in_reply_to": {"type": "string"},
              "event_id": {"type": "string"}, "calendar_id": {"type": "string"},
              "summary": {"type": "string"}, "start": {"type": "string", "description": "RFC 3339 with time zone (calendar.respond: exactly as Calendar shows it)"},
              "end": {"type": "string"}, "location": {"type": "string"}, "description": {"type": "string"},
              "attendees": {"type": "array", "items": {"type": "string"}},
              "response": {"type": "string", "enum": list(_RESPONSES), "description": "calendar.respond: the answer"},
              "organizer": {"type": "string", "description": "calendar.respond: the organizer's email, as Calendar shows it"},
              "file_id": {"type": "string"}, "email": {"type": "string"},
              "role": {"type": "string", "enum": list(_ROLES)},
              "name": {"type": "string", "description": "the file's or new folder's name, exactly as Drive shows it"},
              "new_name": {"type": "string"}, "to_folder_id": {"type": "string"},
              "to_folder_name": {"type": "string", "description": "the folder's current name, exactly"},
              "title": {"type": "string", "description": "the Doc's or Sheet's title (current title to add to one)"},
              "text": {"type": "string", "description": "plain text"}, "document_id": {"type": "string"},
              "message_id": {"type": "string"}, "spreadsheet_id": {"type": "string"}, "sheet": {"type": "string", "description": "the tab's name"},
              "rows": {"type": "array", "items": {"type": "array", "items": {"type": ["string", "number"]}},
                       "description": "rows of text or number cells; written as values, never as formulas"}},
              "required": ["operation"]}}


def _handler(args, **_kw) -> str:
    return json.dumps(run(args))


def register(ctx) -> None:
    ctx.register_tool(name="qosha_google_change", toolset="qosha", schema=SCHEMA, handler=_handler,
                      check_fn=lambda: True, description=SCHEMA["description"], emoji="✉️")
