/* Dictation and voice mode (2 Nov on Home, 4 Nov on Chat too): one copy, used by the Home composer (composer.js) and the
   Chat page's text box (pages/chat.html). The microphone button is dictation: press, speak, press again; the engine's
   speech-to-text (/api/audio/transcribe, where Qosha runs: this computer or the cloud box) puts the words in the box and nothing is sent. The waveform
   button is voice mode: press, speak, press again; the words are handed to the page to send, and the page reads the
   answer aloud with the device's own voice. Only the person's own press sends: a recording that stops at 2 minutes, or
   by itself (the microphone unplugged, an error), is never sent; its words go in the box (GPT R-chatvoice1 HIGH). Starting a recording stops an answer being read aloud, so the microphone never hears it. Text only, never
   HTML from data. */
(function () {
  'use strict';
  if (window.QoshaVoice) return;
  var MAX_REC_MS = 120000;
  var LABEL = {dict: 'Dictate: speak and the words appear in the box', voice: 'Voice mode: talk, and the answer is read aloud'};
  var STOP = {dict: 'Stop dictating', voice: 'Stop talking and send'};
  var PATHS = {
    mic: [['rect', {x: '9', y: '3', width: '6', height: '11', rx: '3'}], ['path', {d: 'M5 11a7 7 0 0 0 14 0M12 18v3'}]],
    wave: [['path', {d: 'M4 10v4M8 7v10M12 4v16M16 7v10M20 10v4'}]]
  };
  function icon(d) {
    var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('aria-hidden', 'true'); s.setAttribute('class', 'ic');
    d.forEach(function (x) { var p = document.createElementNS('http://www.w3.org/2000/svg', x[0]); Object.keys(x[1]).forEach(function (k) { p.setAttribute(k, x[1][k]); }); s.appendChild(p); });
    return s;
  }
  function button(kind) {
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'vb ' + (kind === 'dict' ? 'mic' : 'voice');
    b.setAttribute('aria-pressed', 'false'); b.setAttribute('aria-label', LABEL[kind]);
    b.title = kind === 'dict' ? 'Dictate' : 'Voice mode';
    b.appendChild(icon(kind === 'dict' ? PATHS.mic : PATHS.wave));
    return b;
  }

  // o: {mic, voice (buttons from buttons()), box (the textarea), say(text, err), transcribe(body) → Promise of
  //     {transcript}, heard(text) (voice mode: send it), blocked(kind) → '' or why it can't start now, started(kind) (a
  //     recording begins: drop any answer waiting to be read aloud), stopped(kind) (the person pressed stop: in voice mode,
  //     the moment they chose to send), grow() optional, where() optional: 'mac', 'cloud' or 'computer' (where Qosha runs,
  //     for the words; without it they name no place)}
  function attach(o) {
    var rec = null, seq = 0;
    var say = function (t, err) { o.say(t || '', !!err); };
    var where = function () { var w = typeof o.where === 'function' ? String(o.where()) : ''; return /^(mac|cloud|computer)$/.test(w) ? w : ''; };
    function setRec(kind, phase) {
      o.mic.setAttribute('aria-pressed', kind === 'dict' && phase === 'rec' ? 'true' : 'false');
      o.voice.setAttribute('aria-pressed', kind === 'voice' && phase === 'rec' ? 'true' : 'false');
      o.mic.classList.toggle('busy', phase === 'busy'); o.voice.classList.toggle('busy', phase === 'busy');
      o.mic.setAttribute('aria-label', kind === 'dict' && phase === 'rec' ? STOP.dict : LABEL.dict);
      o.voice.setAttribute('aria-label', kind === 'voice' && phase === 'rec' ? STOP.voice : LABEL.voice);
    }
    function toggle(kind) {
      if (rec) { if (rec.kind === kind && rec.phase === 'rec') { rec.byUser = true; if (o.stopped) o.stopped(kind); stop(); } return; }
      var why = o.blocked ? o.blocked(kind) : '';
      if (why) { say(why, true); return; }
      start(kind);
    }
    function start(kind) {
      var md = navigator.mediaDevices;
      if (!md || typeof md.getUserMedia !== 'function' || typeof window.MediaRecorder !== 'function') {
        say('This window can’t record sound, so dictation isn’t available here. Type your message instead.', true); return;
      }
      try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (e) { /* nothing playing */ }
      if (o.started) o.started(kind);
      var mine = ++seq;
      rec = {kind: kind, phase: 'ask'};
      say('Asking to use the microphone…');
      md.getUserMedia({audio: true}).then(function (stream) {
        if (!rec || mine !== seq) { stream.getTracks().forEach(function (t) { t.stop(); }); return; }
        var types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'];
        var mime = '';
        for (var i = 0; i < types.length; i++) { try { if (MediaRecorder.isTypeSupported(types[i])) { mime = types[i]; break; } } catch (e) { /* older engine */ } }
        var r;
        try { r = mime ? new MediaRecorder(stream, {mimeType: mime}) : new MediaRecorder(stream); }
        catch (e) { stream.getTracks().forEach(function (t) { t.stop(); }); rec = null; setRec(kind, ''); say('The microphone could not be started here. Type your message instead.', true); return; }
        var chunks = [];
        r.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); };
        r.onstop = function () {
          stream.getTracks().forEach(function (t) { t.stop(); });
          if (mine !== seq) return;   // cancelled (a New chat, another conversation): nothing is turned into text
          clearTimeout(rec && rec.timer);
          if (rec && rec.phase === 'rec') { rec.phase = 'busy'; setRec(kind, 'busy'); }   // stopped by itself (GPT R-chatvoice3 LOW)
          // a recording that ran out of time is never sent by itself: its words go in the box (GPT R-composer1 HIGH)
          var timedOut = !!(rec && rec.timedOut), byUser = !!(rec && rec.byUser);
          finish(kind, new Blob(chunks, {type: (r.mimeType || mime || 'audio/webm')}), timedOut, byUser, mine);
        };
        rec = {kind: kind, phase: 'rec', r: r, stream: stream, timer: setTimeout(function () { if (rec) rec.timedOut = true; stop(); }, MAX_REC_MS)};
        r.start();
        setRec(kind, 'rec');
        say(kind === 'voice' ? 'Listening… press the voice button again when you finish; your words are sent and the answer is read aloud.'
                             : 'Listening… press the microphone again to stop. Nothing is sent until you press Send.');
      }, function (e) {
        if (mine !== seq) return;
        rec = null; setRec(kind, '');
        var n = e && e.name;
        if (n === 'NotAllowedError' || n === 'SecurityError' || n === 'PermissionDeniedError') {
          say('Qosha can’t use the microphone: permission is turned off. Allow it (in your computer’s privacy settings for the microphone, and in the browser: the icon at the left of the address bar), then try again.', true);
        } else if (n === 'NotFoundError' || n === 'DevicesNotFoundError') say('No microphone was found on ' + (where() === 'mac' ? 'this computer' : where() === 'computer' ? 'this computer' : 'this device') + '.', true);
        else say('The microphone could not be started (' + (n || 'unknown problem') + '). Type your message instead.', true);
      });
    }
    function stop() {
      if (!rec || rec.phase !== 'rec') return;
      rec.phase = 'busy'; setRec(rec.kind, 'busy');
      try { rec.r.stop(); } catch (e) { rec = null; setRec('', ''); }
    }
    // drop a recording (or its speech-to-text) without using it: nothing goes in the box, nothing is sent
    function cancel() {
      if (!rec) return;
      var r = rec; seq++; rec = null; setRec('', '');
      clearTimeout(r.timer);
      try { if (r.r && r.r.state !== 'inactive') r.r.stop(); } catch (e) { /* stopped */ }
      try { if (r.stream) r.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) { /* stopped */ }
    }
    function finish(kind, blob, timedOut, byUser, mine) {
      var done = function () { rec = null; setRec(kind, ''); };
      if (!blob.size) { done(); say('Nothing was recorded. Try again, or type your message.', true); return; }
      say('Turning your speech into text' + ({mac: ' on this computer', cloud: ' in your cloud Qosha', computer: ' on this computer'}[where()] || '') + '…');
      var type = String(blob.type || 'audio/webm').split(';')[0];
      var fr = new FileReader();
      fr.onload = function () {
        if (mine !== seq) return;
        var b64 = String(fr.result || '').split(',')[1] || '';
        o.transcribe({data_url: 'data:' + type + ';base64,' + b64, mime_type: type}).then(function (r) {
          if (mine !== seq) return;
          done();
          var t = String((r && r.transcript) || '').trim();
          if (!t) { say('No words were heard. Nothing was added.', true); return; }
          if (kind === 'voice' && byUser && !timedOut) { o.heard(t); return; }
          insert(t);
          say(timedOut ? 'The recording stopped after 2 minutes. What you said is in the box: check it, then press Send.'
            : !byUser ? 'The recording stopped by itself (was the microphone disconnected?). What you said is in the box: check it, then press Send.'
            : 'Added what you said. Nothing is sent until you press Send.', timedOut || !byUser);
        }, function (e) { if (mine !== seq) return; done(); say('Your speech could not be turned into text (' + e.message + '). Nothing was sent.', true); });
      };
      fr.onerror = function () { if (mine !== seq) return; done(); say('The recording could not be read. Nothing was sent.', true); };
      fr.readAsDataURL(blob);
    }
    // the words at the cursor, with a space on either side where needed
    function insert(t) {
      var ta = o.box, v = ta.value, s = ta.selectionStart == null ? v.length : ta.selectionStart, e = ta.selectionEnd == null ? v.length : ta.selectionEnd;
      var before = v.slice(0, s), after = v.slice(e);
      var ins = (before && !/\s$/.test(before) ? ' ' : '') + t + (after && !/^\s/.test(after) ? ' ' : '');
      ta.value = before + ins + after; if (o.grow) o.grow();
      var pos = (before + ins).length; try { ta.setSelectionRange(pos, pos); } catch (x) { /* not focused */ }
      ta.focus();
    }
    o.mic.addEventListener('click', function () { toggle('dict'); });
    o.voice.addEventListener('click', function () { toggle('voice'); });
    return {
      toggle: toggle, stop: stop, cancel: cancel, insert: insert,
      recording: function () { return !!(rec && rec.phase === 'rec'); },
      active: function () { return rec ? rec.kind : ''; }
    };
  }

  window.QoshaVoice = {buttons: function () { return {mic: button('dict'), voice: button('voice')}; }, attach: attach, MAX_REC_MS: MAX_REC_MS};
})();
