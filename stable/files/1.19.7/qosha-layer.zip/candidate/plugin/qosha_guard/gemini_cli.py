"""Gemini on the person's own Google subscription, through Google's own command-line tool (Ren, 17 Nov 2026:
"subscriptions, not API keys"; never by driving the Gemini web page).

Google ships two command-line tools that sign in with the person's Google account: Antigravity's `agy` and the
`gemini` CLI. This module finds one, asks it a question (text in, text out) and tells whether it is signed in. The
sign-in is the tool's own (Google's address, then the code Google shows is handed back to the tool); Qosha runs it
from its own "Connect your AI" panel (login_start / login_finish below) and reads no credential file.

How a question is asked (the same way as Qosha's Gemini seat on the Mac lab and the boxes):
- the question goes in on standard input, never on the command line (other programs can read command lines);
- no shell; fixed flags only; the tool's own sandbox flag on; never its "skip permissions" flag;
- the working folder is a fresh empty folder, removed afterwards, so the tool has no files to act on;
- a time limit ends the whole process group.
Used by: the "Connect your AI" panel (signin_api.py), Ask Gemini / the Gemini choice in Chat (assistants_api.py) and
the MCP tool ask_gemini (gemini_mcp.py), which lets Qosha itself ask Gemini inside a chat.

Which agy (contract AGYGUARD, 18 Nov 2026): Qosha's own copy, installed at the version Qosha tested
(<root>/engine/agy/agy, agy_pin.py), comes first; an agy the person installed elsewhere is used only when Qosha's own
is missing. Every agy call Qosha makes carries AGY_CLI_DISABLE_AUTO_UPDATE=true, so agy never replaces itself.
"""
from __future__ import annotations

import json
import os
import re
import secrets
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

TIMEOUT = 150
WIN = os.name == "nt"


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes"))


# Qosha's own agy, installed at the version Qosha tested (agy_pin.py; contract AGYGUARD, 18 Nov 2026), is used first.
# Every agy call Qosha makes carries this switch, so agy never replaces itself (the cloud boxes' setting).
NOUPDATE_ENV = {"AGY_CLI_DISABLE_AUTO_UPDATE": "true"}


def _env(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    env = dict(os.environ)
    env.update(NOUPDATE_ENV)
    if extra:
        env.update(extra)
    return env


def own_agy() -> Path:
    """<root>/engine/agy/agy(.exe): Qosha's own pinned copy (root = the home's parent)."""
    return _home().parent / "engine" / "agy" / ("agy.exe" if WIN else "agy")


def find() -> Tuple[str, str]:
    """("agy" | "gemini" | "", path): Google's command-line tool on this computer. Qosha's own pinned agy first; an agy
    the person installed elsewhere only when Qosha's own is missing."""
    try:
        own = own_agy()
        if own.is_file():
            return "agy", str(own)
    except Exception:
        pass
    local = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
    places = {"agy": [Path.home() / ".local" / "bin" / "agy", local / "agy" / "bin" / "agy.exe",   # Google's default place on Windows
                      local / "Programs" / "agy" / "agy.exe"],
              "gemini": [Path("/opt/homebrew/bin/gemini"), Path("/usr/local/bin/gemini")]}
    if WIN:   # the Windows installer puts Google's tool beside the engine: <install>\\engine\\gemini-cli\\gemini.cmd
        places["gemini"].insert(0, _home().parent / "engine" / "gemini-cli" / "gemini.cmd")
    for name in ("agy", "gemini"):
        hit = shutil.which(name) or next((str(p) for p in places[name] if p.is_file()), "")
        if hit:
            return name, hit
    return "", ""


def _kill(proc) -> None:
    try:
        if WIN:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True, timeout=10,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
        else:
            os.killpg(proc.pid, signal.SIGKILL)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def _drain(stream, sink: list) -> None:
    """Reads a pipe to its end into sink (so a full pipe never stalls the tool)."""
    try:
        while True:
            chunk = stream.read1(65536) if hasattr(stream, "read1") else stream.read(4096)
            if not chunk:
                break
            sink.append(chunk)
    except (OSError, ValueError):
        pass


def _envelope(out: str) -> dict:
    out = (out or "").strip()
    for cand in [out] + [ln for ln in reversed(out.splitlines()) if ln.strip().startswith("{")]:
        try:
            obj = json.loads(cand)
            if isinstance(obj, dict):
                return obj
        except Exception:
            continue
    return {}


def _spawn_kw() -> Dict[str, Any]:
    """Own process group (so a time limit ends the whole tree) and, on Windows, NO console window: Qosha's server has
    no visible console, and a console program started from it would otherwise get a window of its own."""
    if WIN:
        return {"creationflags": getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x200) | getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)}
    return {"start_new_session": True}


# What agy prints when it is NOT signed in and waits for a Google sign-in (seen 17 Nov 2026, agy 1.5.10, print mode:
# the Google address, "Waiting for authentication (timeout 60s)...", "Or, paste the authorization code here").
_SIGNED_OUT_MARKS = ("paste the authorization code", "waiting for authentication", "accounts.google.com/o/oauth2")


def ask(question: str, timeout: int = TIMEOUT, program: Optional[Tuple[str, str]] = None) -> Dict[str, Any]:
    """{"ok": True, "answer", "tool"} or {"ok": False, "error", "plain"}. `program` ("agy", path) asks through that
    program instead of find()'s (the daily canary checks a new Google release through this exact path)."""
    name, path = program if program else find()
    if not name:
        return {"ok": False, "error": "not_installed", "plain": "Google's command-line tool (agy or gemini) is not installed on this computer."}
    question = str(question or "").strip()
    if not question:
        return {"ok": False, "error": "empty", "plain": "There was nothing to ask."}
    if name == "agy":
        argv = [path, "--output-format", "json", "--print-timeout", "120s", "--sandbox"]
    else:
        argv = [path, "-p", "Answer the request given on standard input, in plain text.", "-o", "json", "--approval-mode", "plan"]
    work = tempfile.mkdtemp(prefix="qosha-gemini-")
    try:
        proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                cwd=work, shell=False, env=_env(), **_spawn_kw())
        outs: list = []
        errs: list = []
        readers = [threading.Thread(target=_drain, args=(proc.stdout, outs), daemon=True),
                   threading.Thread(target=_drain, args=(proc.stderr, errs), daemon=True)]
        for t in readers:
            t.start()
        try:
            proc.stdin.write(question.encode("utf-8"))
            proc.stdin.close()
        except OSError:
            pass
        end = time.time() + timeout
        signed_out = False
        while proc.poll() is None:
            if time.time() > end:
                _kill(proc)
                return {"ok": False, "error": "timeout", "plain": "Gemini took too long to answer."}
            # not signed in: the tool sits waiting for a Google sign-in (60 s, and it may open a browser tab);
            # stop it at once and say so, instead of a long wait for nothing (those lines go to its error output;
            # the answer itself goes to standard output, so an answer that mentions sign-ins is not mistaken for it)
            if name == "agy" and any(m in b"".join(errs).decode("utf-8", "replace").lower() for m in _SIGNED_OUT_MARKS):
                signed_out = True
                _kill(proc)
                break
            time.sleep(0.2)
        for t in readers:
            t.join(5)
        out = b"".join(outs).decode("utf-8", "replace")
        err = b"".join(errs).decode("utf-8", "replace")
        if signed_out:
            return {"ok": False, "error": "signed_out", "plain": "Gemini is not signed in on this computer yet."}
    except OSError as exc:
        return {"ok": False, "error": "start", "plain": "Google's command-line tool could not start (%s)." % type(exc).__name__}
    finally:
        shutil.rmtree(work, ignore_errors=True)
    env = _envelope(out)
    text = str(env.get("response") or env.get("result") or "").strip()
    low = ((err or "") + " " + (out or "")).lower()
    if not text or env.get("is_error") or env.get("error"):
        # Google refusing the TOOL (seen 17 Nov with gemini-cli 0.68.0: the sign-in is fine, the client is turned away)
        # is not "signed out": checked before the sign-in words, because Google's message also says "auth".
        if "ineligibletier" in low.replace(" ", "").replace("_", "") or "no longer supported" in low:
            return {"ok": False, "error": "tool_refused", "plain": (
                "Google no longer lets this tool use a personal Gemini plan. Qosha needs Google's newer tool; "
                "ask Qosha to set it up.")}
        if any(w in low for w in ("sign in", "signin", "log in", "login", "unauthenticated", "not authenticated", "auth", "credential")):
            return {"ok": False, "error": "signed_out", "plain": "Gemini is not signed in on this computer yet."}
        return {"ok": False, "error": "no_answer", "plain": "Gemini gave no answer just now."}
    return {"ok": True, "answer": text[:20000], "tool": name}


def _marker() -> Path:
    d = _home() / "qosha"
    d.mkdir(parents=True, exist_ok=True)
    return d / "gemini_cli.json"


def connected() -> bool:
    """What the last check found (no call to Google here)."""
    try:
        return json.loads(_marker().read_text(encoding="utf-8")).get("ok") is True and bool(find()[0])
    except Exception:
        return False


def _signed_out_quick(path: str) -> bool:
    """agy only: `agy models` says "Please sign in ..." at once when nobody is signed in, and opens nothing. (A question
    asked while signed out makes agy open Google's sign-in in the browser by itself, for a sign-in Qosha then ends: a
    code from that page would be refused. Seen 17 Nov 2026 on Mac and Windows, agy 1.5.10.)"""
    try:
        r = subprocess.run([path, "models"], stdin=subprocess.DEVNULL, capture_output=True, timeout=30, shell=False,
                           env=_env(), **_spawn_kw())
    except Exception:
        return False
    text = (r.stdout + r.stderr).decode("utf-8", "replace").lower()
    return "please sign in" in text or "not logged in" in text


def check() -> Dict[str, Any]:
    """One very short question through the tool: it answers only when the person's Google sign-in works."""
    name, path = find()
    if name == "agy" and _signed_out_quick(path):
        r = {"ok": False, "error": "signed_out", "plain": "Gemini is not signed in on this computer yet."}
    else:
        r = ask("Reply with the single word: OK", timeout=90) if name else {"ok": False, "error": "not_installed",
                                                                             "plain": "Google's command-line tool is not installed yet."}
    try:
        _marker().write_text(json.dumps({"ok": bool(r.get("ok")), "tool": name, "at": time.time()}), encoding="utf-8")
    except OSError:
        pass
    return {"ok": bool(r.get("ok")), "tool": name, "error": r.get("error") or "", "plain": r.get("plain") or ""}


def forget() -> None:
    """Disconnect in Qosha: Qosha stops using the tool (the tool's own Google sign-in is the person's and stays)."""
    try:
        _marker().write_text(json.dumps({"ok": False, "at": time.time()}), encoding="utf-8")
    except OSError:
        pass


# ---- Sign-in inside Qosha's own "Connect your AI" panel (17 Nov 2026: Renato, Windows, copied Google's code but had
# no place to paste it: the old way opened the tool in a console window that could sit behind everything).
# Google's supported route is agy's own ACP terminal sign-in, `agy acp --login` (agy 1.5.10 `agy help acp`: "Log in
# with Google interactively, then exit (ACP terminal auth)"). It prints one Google address, waits for one line (the code
# Google shows, or the full address of the page you land on) and exits: 0 when Google accepted it and the sign-in is
# saved where agy keeps it (Apple Keychain, Windows Credential Manager), 1 otherwise. It reads ordinary pipes, so no
# terminal emulation is needed on either system. Qosha only relays: the address to the page, the code to the tool.
# Nothing here reads or writes the tool's stored sign-in itself.
LOGIN_TTL = 600            # a sign-in waits 10 minutes for the code, then ends by itself
_LOGINS: Dict[str, Dict[str, Any]] = {}
_LLOCK = threading.Lock()
_ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)|\x1b[()][A-Za-z0-9]|\x1b[=>]")
_GURL = re.compile(r"https://accounts\.google\.com/[^\s\"'<>]+")
_CODE_OK = re.compile(r"^[\x21-\x7e]{4,4096}$")    # one line of visible characters: a code or the landing address
_PROMPT = ("authorization code", "press enter")


def _ltext(sess: Dict[str, Any]) -> str:
    return _ANSI.sub("", b"".join(sess["out"]).decode("utf-8", "replace")).replace("\r", "")


def _lend(sess: Dict[str, Any], why: str) -> None:
    """Ends one sign-in cleanly: the tool's input is closed (agy: "login cancelled", exit 1); killed if it lingers."""
    sess.setdefault("ended", why)
    t = sess.get("timer")
    if t is not None:
        t.cancel()
    p = sess["proc"]
    if p.poll() is None:
        try:
            p.stdin.close()
        except Exception:
            pass
        try:
            p.wait(5)
        except Exception:
            _kill(p)
            try:
                p.wait(5)
            except Exception:
                pass
    r = sess.get("reader")
    if r is not None:
        r.join(2)
    shutil.rmtree(sess.get("work") or "", ignore_errors=True)


def _lexpire(sid: str) -> None:
    with _LLOCK:
        sess = _LOGINS.pop(sid, None)
    if sess:
        _lend(sess, "expired")


def login_cancel(sid: Optional[str] = None) -> Dict[str, Any]:
    """Ends one sign-in (or every one when no id is given): the panel was closed, or a new sign-in starts."""
    with _LLOCK:
        gone = [_LOGINS.pop(k) for k in list(_LOGINS) if sid is None or k == sid]
    for sess in gone:
        _lend(sess, "cancelled")
    return {"ok": True, "ended": len(gone)}


def login_active() -> int:
    with _LLOCK:
        return sum(1 for s in _LOGINS.values() if s["proc"].poll() is None)


def _login_attempt(path: str) -> Dict[str, Any]:
    """Starts `agy acp --login` once over plain pipes (its output and errors read together in the background; its
    input is a pipe, and closing it ends the sign-in). -> the session dict; OSError when it cannot start."""
    work = tempfile.mkdtemp(prefix="qosha-gemini-login-")
    try:
        proc = subprocess.Popen([path, "acp", "--login"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, cwd=work, shell=False, env=_env(), **_spawn_kw())
    except OSError:
        shutil.rmtree(work, ignore_errors=True)
        raise
    sess: Dict[str, Any] = {"proc": proc, "out": [], "work": work, "at": time.time()}
    sess["reader"] = threading.Thread(target=_drain, args=(proc.stdout, sess["out"]), daemon=True)
    sess["reader"].start()
    return sess


def login_start(wait: float = 30.0) -> Dict[str, Any]:
    """Starts Google's sign-in in the background and returns the address to open: {"ok", "id", "url", "expires_in"}.
    No window of any kind is opened."""
    name, path = find()
    if not name:
        return {"ok": False, "error": "not_installed", "plain": "Google's command-line tool is not installed yet."}
    if name != "agy":
        return {"ok": False, "error": "no_inline", "plain": "This version of Google's tool signs in only in its own window."}
    login_cancel()
    end = time.time() + wait
    try:
        sess = _login_attempt(path)
    except OSError as exc:
        return {"ok": False, "error": "start", "plain": "Google's sign-in could not start (%s)." % type(exc).__name__}
    url = ""
    while time.time() < end:
        txt = _ltext(sess)
        m = _GURL.search(txt)
        if m and any(k in txt.lower() for k in _PROMPT):
            url = m.group(0)
            break
        if sess["proc"].poll() is not None:
            break                        # it ended before asking for a code: no sign-in to finish
        time.sleep(0.1)
    if not url or sess["proc"].poll() is not None:
        rc = sess["proc"].poll()
        detail = "rc=%s out=%r" % (rc, _ltext(sess)[-160:])
        _lend(sess, "no_url")
        return {"ok": False, "error": "no_url", "plain": "Google's sign-in did not start.", "detail": detail}
    sid = secrets.token_urlsafe(12)
    sess["timer"] = threading.Timer(LOGIN_TTL, _lexpire, args=(sid,))
    sess["timer"].daemon = True
    sess["timer"].start()
    with _LLOCK:
        _LOGINS[sid] = sess
    return {"ok": True, "id": sid, "url": url, "expires_in": LOGIN_TTL, "tool": name}


def login_finish(sid: str, code: str, wait: float = 90.0) -> Dict[str, Any]:
    """Hands the code the person copied from Google to the waiting tool, then checks that Gemini answers.
    {"ok": True, "connected": True} or {"ok": False, "error", "plain"} (plain words for the panel)."""
    code = str(code or "").strip()
    again = "Press “Open Google’s sign-in” again, sign in, and paste the new code."
    with _LLOCK:
        sess = _LOGINS.get(str(sid or ""))
        if sess is not None and _CODE_OK.match(code):
            _LOGINS.pop(str(sid), None)
    if sess is None:
        return {"ok": False, "error": "expired", "plain": "This sign-in has ended (it waits 10 minutes). " + again}
    if not _CODE_OK.match(code):   # the sign-in stays open: the person can paste again
        return {"ok": False, "error": "bad_format", "plain": "That doesn’t look like Google’s code. Copy the whole code Google shows (one line) and paste it here."}
    t = sess.get("timer")
    if t is not None:
        t.cancel()
    p = sess["proc"]
    if p.poll() is not None:
        _lend(sess, "gone")
        return {"ok": False, "error": "expired", "plain": "This sign-in had already stopped. " + again}
    mark = len(_ltext(sess))
    try:
        p.stdin.write(code.encode("ascii") + b"\n")
        p.stdin.flush()
    except (OSError, ValueError):
        _lend(sess, "write")
        return {"ok": False, "error": "expired", "plain": "This sign-in had already stopped. " + again}
    try:
        p.wait(wait)
    except subprocess.TimeoutExpired:
        pass
    if p.poll() is not None and sess.get("reader") is not None:
        sess["reader"].join(2)           # the last lines it wrote before ending
    after = _ltext(sess)[mark:].lower()
    rc = p.poll()
    _lend(sess, "finished")
    if rc != 0 or "couldn't log in" in after or "invalid_grant" in after:
        if "invalid_grant" in after:
            return {"ok": False, "error": "refused", "plain": "Google did not accept that code. A code works once and only for a few minutes. " + again}
        if rc is None:
            return {"ok": False, "error": "timeout", "plain": "Google took too long to answer. " + again}
        return {"ok": False, "error": "failed", "plain": "The sign-in did not finish. " + again}
    r = check()
    if r.get("ok"):
        return {"ok": True, "connected": True, "plain": "Gemini is connected."}
    return {"ok": False, "error": r.get("error") or "check", "plain": "Google accepted the sign-in, but Gemini did not answer yet. "
            + (r.get("plain") or "") + " Press Check again in a minute."}


def _front_windows(title: str, seconds: float = 8.0) -> None:
    """Brings the console window titled `title` to the front (Windows only; best effort). A window started by a
    program in the background otherwise opens behind the person's other windows."""
    try:
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        found: list = []
        proto = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def cb(h, _l):
            n = u.GetWindowTextLengthW(h)
            if n:
                b = ctypes.create_unicode_buffer(n + 1)
                u.GetWindowTextW(h, b, n + 1)
                if b.value.startswith(title) and u.IsWindowVisible(h):
                    found.append(h)
            return True
        end = time.time() + seconds
        while time.time() < end and not found:
            u.EnumWindows(proto(cb), 0)
            if not found:
                time.sleep(0.25)
        k = ctypes.windll.kernel32
        for h in found[:1]:
            u.ShowWindow(h, 9)                       # SW_RESTORE
            # Windows lets only the program in front hand over the front: borrow its input queue for a moment
            # (AttachThreadInput), with a tap of Alt, then raise and focus the sign-in window
            fg = u.GetForegroundWindow()
            me = k.GetCurrentThreadId()
            them = u.GetWindowThreadProcessId(fg, None) if fg else 0
            if them and them != me:
                u.AttachThreadInput(me, them, True)
            try:
                u.keybd_event(0x12, 0, 0, 0)
                u.keybd_event(0x12, 0, 2, 0)
                u.SetWindowPos(h, -1, 0, 0, 0, 0, 0x0043)   # on top (shown, not moved or sized) ...
                u.SetWindowPos(h, -2, 0, 0, 0, 0, 0x0043)   # ... then back to normal stacking, still above the rest
                u.BringWindowToTop(h)
                u.SetForegroundWindow(h)
                u.SwitchToThisWindow(h, True)
            finally:
                if them and them != me:
                    u.AttachThreadInput(me, them, False)
    except Exception:
        pass


def open_signin() -> Dict[str, Any]:
    """Fallback when the sign-in inside the panel cannot start: Google's sign-in in a window of its own, titled
    "Sign in to Gemini", brought to the front. The person pastes the code there and presses Enter."""
    name, path = find()
    if not name:
        return {"ok": False, "error": "not_installed", "plain": "Google's command-line tool is not installed yet."}
    args = ["acp", "--login"] if name == "agy" else []
    try:
        if sys.platform == "darwin":
            import shlex
            # the Terminal window's shell does not inherit Qosha's environment: the no-self-update switch is set inline
            sh = ("printf '\\033]0;Sign in to Gemini\\007'; clear; "
                  + " ".join("%s=%s" % kv for kv in NOUPDATE_ENV.items()) + " "
                  + " ".join(shlex.quote(x) for x in [path] + args))
            osa = 'tell application "Terminal"\nactivate\ndo script "%s"\nend tell' % sh.replace("\\", "\\\\").replace('"', '\\"')
            subprocess.Popen(["/usr/bin/osascript", "-e", osa], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            where = "A Terminal window titled “Sign in to Gemini” opened."
        elif WIN:
            subprocess.Popen(["cmd", "/c", "start", "Sign in to Gemini", "cmd", "/k", path] + args, shell=False,
                             env=_env(), creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
            threading.Thread(target=_front_windows, args=("Sign in to Gemini",), daemon=True).start()
            where = "A window titled “Sign in to Gemini” opened."
        else:
            return {"ok": False, "error": "manual", "plain": "Open a terminal and run: %s %s" % (name, " ".join(args))}
    except OSError as exc:
        return {"ok": False, "error": "open", "plain": "The sign-in window could not be opened (%s)." % type(exc).__name__}
    return {"ok": True, "tool": name, "plain": where + " Google\u2019s sign-in page opens in your browser (if not, open the "
            "address shown in that window). Sign in; Google then shows a code: copy it, click into the \u201cSign in to "
            "Gemini\u201d window, paste the code there and press Enter. Then come back here and press Check again."}
