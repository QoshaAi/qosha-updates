"""Sign in to an AI subscription from Qosha's own screens (Ren, 17 Nov 2026: "sign in from the app"). Mounted at
/api/plugins/qosha/signin.

The engine does ChatGPT (and xAI, MiniMax) sign-in in the app already (device code, /api/providers/oauth/...), and the
page calls that directly. Claude's subscription sign-in exists in the engine only as a terminal command (a PKCE link,
then the code Claude shows is pasted back). These two routes run the same engine flow from the page:

POST /claude/start            -> {"id", "url"}: the person opens url, signs in to Claude, and copies the code shown
POST /claude/finish {id,code} -> {"ok": true} once the engine's own credential pool holds the new Claude sign-in
GET  /status                  -> which subscriptions are signed in (the engine's own oauth status list)

Gemini (Google's own command-line tool on the person's Google subscription, qosha_guard/gemini_cli.py):
POST /gemini/check            -> is the tool installed and signed in
POST /gemini/login/start      -> {"id", "url"}: Google's sign-in, run in the background; the page opens url
POST /gemini/login/finish {id,code} -> the code Google shows goes to the tool; {"ok": true} once Gemini answers
POST /gemini/login/cancel {id}-> ends that sign-in (it ends by itself after 10 minutes)
POST /gemini/open             -> fallback: the same sign-in in a window of its own, brought to the front
POST /gemini/repair           -> reinstalls Qosha's own pinned Google tool (agy_pin.repair) and checks it again
GET  /accounts                -> also "gemini_state"/"gemini_plain"/"gemini_version"/"gemini_checked_at": the last daily
                                 self-check of that tool (shown in "Connect your AI" and in Settings)
"""
from __future__ import annotations

import dataclasses
import secrets
import threading
import time
from typing import Any, Dict

from fastapi import APIRouter, Body
from fastapi.responses import JSONResponse

router = APIRouter()
_PENDING: Dict[str, Dict[str, Any]] = {}
_LOCK = threading.Lock()
TTL = 900


def _gc() -> None:
    now = time.time()
    for k in [k for k, v in _PENDING.items() if now - v["at"] > TTL]:
        _PENDING.pop(k, None)


@router.post("/claude/start")
def claude_start():
    from urllib.parse import urlencode
    from agent import anthropic_credentials as ac
    verifier, challenge = ac._generate_pkce()
    state = secrets.token_urlsafe(32)
    params = {"code": "true", "client_id": ac._OAUTH_CLIENT_ID, "response_type": "code",
              "redirect_uri": ac._OAUTH_REDIRECT_URI, "scope": ac._OAUTH_SCOPES, "code_challenge": challenge,
              "code_challenge_method": "S256", "state": state}
    sid = secrets.token_urlsafe(12)
    with _LOCK:
        _gc()
        _PENDING[sid] = {"verifier": verifier, "state": state, "at": time.time()}
    return {"id": sid, "url": "https://claude.ai/oauth/authorize?" + urlencode(params)}


@router.post("/claude/finish")
def claude_finish(body: dict = Body(...)):
    import json
    from agent import anthropic_credentials as ac
    sid = str((body or {}).get("id") or "")
    raw = str((body or {}).get("code") or "").strip()
    with _LOCK:
        _gc()
        pend = _PENDING.pop(sid, None)
    if not pend:
        return JSONResponse({"ok": False, "plain": "This sign-in expired. Press Sign in with Claude again."}, status_code=410)
    code, _, got_state = raw.partition("#")
    if not code or got_state != pend["state"]:
        return JSONResponse({"ok": False, "plain": "That code doesn't match this sign-in. Copy the whole code Claude shows and try again."},
                            status_code=400)
    try:
        data = json.dumps({"grant_type": "authorization_code", "client_id": ac._OAUTH_CLIENT_ID, "code": code,
                           "state": got_state, "redirect_uri": ac._OAUTH_REDIRECT_URI,
                           "code_verifier": pend["verifier"]}).encode()
        result = ac._post_oauth_token(data, content_type="application/json", timeout=15, what="exchange")
        if not result.get("access_token"):
            raise RuntimeError("no access token")
        creds = ac._oauth_token_state(result)
        # stored exactly as the engine's `auth add anthropic` stores it (its own credential pool entry)
        from hermes_cli import auth_commands as A
        from agent.credential_pool import load_pool
        spec = A._OAUTH_ADD_SPECS["anthropic"]
        A._OAUTH_ADD_SPECS["anthropic"] = dataclasses.replace(spec, login=lambda args: creds)
        try:
            class _Args:
                label = "Claude subscription"
                priority = None
            A._add_credential(_Args(), "anthropic", load_pool("anthropic"), A.AUTH_TYPE_OAUTH)
        finally:
            A._OAUTH_ADD_SPECS["anthropic"] = spec
    except Exception as exc:
        return JSONResponse({"ok": False, "plain": "Claude did not accept the sign-in (%s). Try again." % type(exc).__name__},
                            status_code=502)
    return {"ok": True, "plain": "Claude is signed in."}


@router.get("/status")
async def status():
    from hermes_cli.web_routers.oauth import list_oauth_providers
    try:
        rows = await list_oauth_providers(None)
    except Exception:
        return {"providers": []}
    rows = rows.get("providers", rows) if isinstance(rows, dict) else rows
    return {"providers": [{"id": r.get("id"), "name": r.get("name"), "flow": r.get("flow"),
                           "signed_in": bool((r.get("status") or {}).get("logged_in"))} for r in rows or []]}


@router.get("/local")
def local():
    """Whether this Qosha runs on the person's own computer (not a cloud box, not the Mac lab): the screens then hide
    what a customer doesn't need (the engine's public plugin catalog)."""
    import os
    return {"local": not os.environ.get("QOSHA_BOX") and not os.environ.get("QOSHA_LAB") and not os.environ.get("QOSHA_CONNECTOR_URL")}


def _pool_count(provider: str) -> int:
    """How many sign-ins the engine's own credential pool holds for this provider (a count only; nothing is read out)."""
    try:
        from agent.credential_pool import load_pool
        return len(load_pool(provider).entries())
    except Exception:
        return 0


@router.get("/accounts")
def accounts():
    """Which AI accounts are connected on this computer, for the "Connect your AI" panel."""
    import os
    out = {"claude": _pool_count("anthropic") > 0, "chatgpt": _pool_count("openai-codex") > 0, "gemini": False, "keys": []}
    try:
        from hermes_cli.config import load_env
        env = load_env()
    except Exception:
        env = {}
    has = lambda k: bool(env.get(k) or os.environ.get(k))
    has = lambda k: bool(env.get(k))   # what is saved in Qosha's own key file now (not what a process started with)
    out["gemini"] = _gcli().connected()
    out["gemini_how"] = "your Google subscription" if out["gemini"] else ""
    # the last daily self-check of Qosha's own Gemini tool (updater.agy_daily_check, or a Repair): "ok", "signed_out",
    # "missing", "wrong_version", "tampered", "broken"; None where no check ran (a cloud box, a fresh install's first minute)
    chk = _agy_check()
    out["gemini_state"] = chk.get("state") if isinstance(chk.get("state"), str) else None
    out["gemini_plain"] = str(chk.get("plain") or "") if out["gemini_state"] else ""
    # for Settings' Gemini line: the tool version the check saw and when it ran (seconds since 1970)
    out["gemini_version"] = str(chk.get("version") or "") if out["gemini_state"] else ""
    out["gemini_checked_at"] = chk.get("at") if out["gemini_state"] and isinstance(chk.get("at"), int) else None
    out["keys"] = [n for k, n in (("OPENROUTER_API_KEY", "OpenRouter"), ("OPENAI_API_KEY", "OpenAI"), ("ANTHROPIC_API_KEY", "Anthropic key"),
                                  ("GOOGLE_API_KEY", "Gemini key")) if has(k)]
    return out


@router.post("/disconnect/{which}")
def disconnect(which: str):
    """Remove one connected account (the engine's own clearing code for sign-ins; the key store for keys)."""
    try:
        if which in ("claude", "chatgpt"):
            from hermes_cli.auth import clear_provider_auth
            clear_provider_auth("anthropic" if which == "claude" else "openai-codex")
        elif which == "gemini":
            _gcli().forget()   # Qosha stops using Google's tool; the tool's own Google sign-in is the person's and stays
        else:
            return JSONResponse({"ok": False, "plain": "Unknown account."}, status_code=404)
    except Exception as exc:
        return JSONResponse({"ok": False, "plain": "Could not disconnect (%s)." % type(exc).__name__}, status_code=500)
    return {"ok": True}


def _gcli():
    import importlib.util, sys
    from pathlib import Path
    mod = sys.modules.get("qosha_gemini_cli")
    if mod is None:
        spec = importlib.util.spec_from_file_location("qosha_gemini_cli", Path(__file__).resolve().parent.parent / "qosha_guard" / "gemini_cli.py")
        mod = importlib.util.module_from_spec(spec)
        sys.modules["qosha_gemini_cli"] = mod
        spec.loader.exec_module(mod)
    return mod


@router.post("/gemini/check")
def gemini_check():
    """Is Google's command-line tool installed and signed in with the person's Google account? (One very short
    question through it; nothing is read from its files.)"""
    g = _gcli()
    name, _ = g.find()
    r = g.check()
    return {"installed": bool(name), "tool": name, "connected": bool(r.get("ok")), "error": r.get("error") or "", "plain": r.get("plain") or ""}


@router.post("/gemini/login/start")
def gemini_login_start():
    """Gemini sign-in inside the panel: starts Google's tool's own sign-in in the background (no window) and returns
    the Google address for the page to open -> {"ok", "id", "url", "expires_in"}."""
    r = _gcli().login_start()
    return r if r.get("ok") else JSONResponse(r, status_code=200 if r.get("error") in ("no_inline", "not_installed") else 502)


@router.post("/gemini/login/finish")
def gemini_login_finish(body: dict = Body(...)):
    """{id, code}: the code Google showed goes to the waiting sign-in; then one short question checks Gemini answers."""
    r = _gcli().login_finish(str((body or {}).get("id") or ""), str((body or {}).get("code") or ""))
    if r.get("ok"):
        return r
    return JSONResponse(r, status_code={"expired": 410, "bad_format": 400, "refused": 400}.get(r.get("error"), 502))


@router.post("/gemini/login/cancel")
def gemini_login_cancel(body: dict = Body(default={})):
    """The panel closed or the person pressed Cancel: that sign-in ends now (it also ends by itself after 10 minutes)."""
    sid = str((body or {}).get("id") or "")
    return _gcli().login_cancel(sid) if sid else {"ok": True, "ended": 0}


@router.post("/gemini/open")
def gemini_open():
    """Fallback: Google's sign-in in a window of its own ("Sign in to Gemini"), brought to the front."""
    return _gcli().open_signin()


# ---- Qosha's own Gemini tool (agy at the version Qosha tested; qosha_guard/agy_pin.py) -------------------------------
_REPAIR_LOCK = threading.Lock()


def _agy():
    import importlib.util, sys
    from pathlib import Path
    mod = sys.modules.get("qosha_agy_pin")
    if mod is None:
        spec = importlib.util.spec_from_file_location("qosha_agy_pin", Path(__file__).resolve().parent.parent / "qosha_guard" / "agy_pin.py")
        mod = importlib.util.module_from_spec(spec)
        sys.modules["qosha_agy_pin"] = mod
        spec.loader.exec_module(mod)
    return mod


def _agy_check_path():
    return _gcli()._home() / "qosha" / "agy-check.json"


def _agy_check() -> dict:
    import json
    try:
        d = json.loads(_agy_check_path().read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


@router.post("/gemini/repair")
def gemini_repair():
    """Repair: reinstalls the pinned version of Google's Gemini tool into Qosha's own folder (Google's file from
    GitHub, checked against the pinned size and sha256, as the installer does), then checks it again. Never switches
    to another tool or provider."""
    import json
    import os
    root = _gcli()._home().parent
    if not (root / "engine").is_dir():
        return JSONResponse({"ok": False, "error": "not_local", "plain": "Gemini's tool is managed elsewhere on this computer."},
                            status_code=404)
    if not _REPAIR_LOCK.acquire(blocking=False):
        return JSONResponse({"ok": False, "error": "busy", "plain": "A repair is already running. Wait a minute."}, status_code=409)
    try:
        try:
            r = _agy().repair(root)
        except Exception as exc:
            r = {"ok": False, "state": "broken", "repaired": False,
                 "plain": "Gemini needs a repair: the repair could not run (%s)." % type(exc).__name__}
        try:
            p = _agy_check_path()
            p.parent.mkdir(parents=True, exist_ok=True)
            tmp = p.with_name("." + p.name + ".tmp")
            tmp.write_text(json.dumps(dict(r, at=int(time.time()))), encoding="utf-8")
            os.replace(tmp, p)
        except OSError:
            pass
    finally:
        _REPAIR_LOCK.release()
    return r
