"""Qosha's name in the engine's chat error texts (fallback for strings the engine's locale overlay doesn't cover:
tui_gateway/user_messages.py and hermes_cli/auth.py write the engine's name into the text).
Installed beside the engine (a .pth in its environment imports it at every start). When tui_gateway.server is imported
it wraps _event_frame: in error events, and in a turn that ended in error, "Hermes"/"hermes" become "Qosha"/"qosha".
The assistant's own answers are never changed. Only active in a Qosha home (HERMES_HOME/plugins/qosha exists)."""
import importlib.abc
import os
import re
import sys

TARGET = "tui_gateway.server"
_WORD = re.compile(r"\bHermes Agent\b|\bHERMES\b|\bHermes\b|\bhermes\b")
_PATHISH = re.compile(r"[\\/]hermes[\\/]|\.hermes\b")


def _qosha_home() -> bool:
    home = os.environ.get("HERMES_HOME") or ""
    return bool(home) and os.path.isdir(os.path.join(home, "plugins", "qosha"))


def rename(text):
    if not isinstance(text, str) or "ermes" not in text and "ERMES" not in text:
        return text

    def sub(m):
        w = m.group(0)
        return {"Hermes Agent": "Qosha", "HERMES": "QOSHA", "Hermes": "Qosha", "hermes": "qosha"}[w]
    # leave real paths alone (an engine folder name in a path is not a name shown as the product)
    parts = re.split(r"(\S*[\\/]\S*)", text)
    out = "".join(p if (i % 2 and _PATHISH.search(p)) else _WORD.sub(sub, p) for i, p in enumerate(parts))
    # no terminal commands in what the person reads: point to Qosha's Settings instead
    out = re.sub(r"Run `qosha model` to pick one.*?\.env\.?\)", "Open Settings in Qosha and add an AI account or key.", out, flags=re.S)
    out = re.sub(r"Check the model and provider with /model, or run `qosha setup` in a terminal to reconfigure\.?",
                 "Check the AI account and model in Qosha's Settings.", out)
    out = re.sub(r"Run 'qosha auth add [a-z0-9_-]+' to sign in, or set [^\n]*?(?:\.env\.?|(?=\n)|$)", "Open Settings in Qosha and sign in or add a key.", out)
    out = re.sub(r",? or run `qosha [a-z -]+`( in a terminal)?( to [a-z ]+)?", "", out)
    # any other sentence that tells the person to run a terminal command ('qosha model', `qosha doctor`, ...)
    if re.search(r"['`]qosha [a-z][a-z <>_-]*['`]", out):
        out = re.sub(r"[^.!?\n]*['`]qosha [a-z][a-z <>_-]*['`][^.!?\n]*[.!?]?", " Open Settings in Qosha to check the AI account and model.", out, count=1)
        out = re.sub(r"[^.!?\n]*['`]qosha [a-z][a-z <>_-]*['`][^.!?\n]*[.!?]?", " ", out)
    # the engine's chat commands (/retry, /model, ...) mean nothing in Qosha's chat: those sentences are dropped (the same
    # rule as the chat page's own plainProv), and a retry is said plainly instead
    had = bool(re.search(r"(?:^|\s)/retry\b", out))
    out = re.sub(r"[^.!?\n]*(?:^|\s)/(?:retry|model|login|setup|new|reset|logs)\b[^.!?\n]*[.!?]?", " ", out)
    out = re.sub(r"[ \t]{2,}", " ", out).strip()
    out = re.sub(r"[ \t]+\n", "\n", out)
    if had:
        out = out.rstrip() + ("\n" if "\n" in out else " ") + "You can send your message again."
    return re.sub(r"(?<!\.)\.\.(?!\.)", ".", out)


def _fix(event, payload):
    if not isinstance(payload, dict):
        return payload
    errorish = event in ("error", "gateway.error", "turn.error") or str(payload.get("status") or "") in ("error", "interrupted")
    if not errorish:
        return payload
    out = dict(payload)
    for k in ("message", "text", "detail", "error", "hint", "title"):
        if isinstance(out.get(k), str):
            out[k] = rename(out[k])
    return out


def patch(mod) -> None:
    orig = getattr(mod, "_event_frame", None)
    if orig is None or getattr(orig, "__qosha_names__", False):
        return

    def _event_frame(event, sid, payload=None):
        if payload is not None and _qosha_home():
            try:
                payload = _fix(event, payload)
            except Exception:
                pass
        return orig(event, sid, payload)

    _event_frame.__qosha_names__ = True
    mod._event_frame = _event_frame


class _Loader(importlib.abc.Loader):
    def __init__(self, inner):
        self.inner = inner

    def create_module(self, spec):
        return self.inner.create_module(spec)

    def exec_module(self, module):
        self.inner.exec_module(module)
        patch(module)


class _Finder(importlib.abc.MetaPathFinder):
    _qosha_names_finder = True      # two copies of this file may be loaded (environment and plugin): only one acts

    def find_spec(self, name, path=None, target=None):
        if name != TARGET:
            return None
        for f in sys.meta_path:
            if f is self or getattr(f, "_qosha_names_finder", False) or not hasattr(f, "find_spec"):
                continue
            spec = f.find_spec(name, path, target)
            if spec is not None:
                if spec.loader is not None:
                    spec.loader = _Loader(spec.loader)
                return spec
        return None


if TARGET in sys.modules:
    patch(sys.modules[TARGET])
elif not any(getattr(f, "_qosha_names_finder", False) for f in sys.meta_path):
    sys.meta_path.insert(0, _Finder())
