"""Qosha's startup barrier (GUARDFIX message 1, 6 Nov): no tool runs in a Qosha home until the approval guard is loaded
and has confirmed itself.

The engine discovers plugins in a background thread on some start paths (one-shot chats, fresh processes) and marks
discovery "done" before the plugins have registered their hooks, so a tool call arriving in that window found no guard
and ran (GOOGLEFIX: 2 of 10 fast runs). This module is installed beside the engine (a .pth file in the engine's own
environment imports it at every start, before the engine). When the engine's plugin module is imported it wraps the one
function every tool call passes through (hermes_cli.plugins._get_pre_tool_call_directive_details):
  1. wait for any discovery in flight (the engine's own join), running discovery if it never ran;
  2. in a Qosha home (HERMES_HOME/plugins/qosha exists), require a registered pre_tool_call callback that the Qosha
     plugin marked ready after its self-check (__qosha_guard_ready__); otherwise the call is BLOCKED.
Anything unexpected also blocks (fail closed). Outside a Qosha home it changes nothing.
Installed by install_barrier.py; the release suite checks it is active."""
import importlib.abc
import importlib.util
import os
import sys

TARGET = "hermes_cli.plugins"
BLOCKED = ("Not allowed by Qosha: Qosha's safety guard is not loaded and confirmed yet, so no tool runs. Nothing was "
           "done; try again in a moment.")


def _qosha_home() -> bool:
    """A Qosha process or home: the box's or lab's own markers (QOSHA_BOX / QOSHA_LAB in the environment, set by their
    launchers), or a Qosha plugin entry (even a broken link), or Qosha named in the home's plugin settings. GPT r4: the
    absence of the plugin folder alone must not switch the barrier off."""
    if os.environ.get("QOSHA_BOX") or os.environ.get("QOSHA_LAB"):
        return True
    try:
        from hermes_constants import get_hermes_home
        home = str(get_hermes_home())
    except Exception:
        home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    if os.path.lexists(os.path.join(home, "plugins", "qosha")):
        return True
    try:
        with open(os.path.join(home, "config.yaml"), encoding="utf-8", errors="replace") as fh:
            return "qosha" in fh.read().lower()
    except OSError:
        return False


LOCAL_HELD = ("Not done: Qosha's ask-first check is not loaded right now, so this action (%s) was not run and nothing was "
              "sent, paid, deleted or shared. Tell the person plainly and offer to repair Qosha yourself: check the Qosha "
              "plugin in the home folder (plugins/qosha) and the log (logs/agent.log), fix it, and restart Qosha.")


def _local_kind(tool_name, args):
    """What the ask-first rule (plugins/qosha/qosha_guard/ask.py, loaded on its own) says this call is; if that file
    can't be loaded either, a plain-words fallback. None: the call may run."""
    try:
        from hermes_constants import get_hermes_home
        home = str(get_hermes_home())
    except Exception:
        home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    try:
        spec = importlib.util.spec_from_file_location("qosha_ask_fallback", os.path.join(home, "plugins", "qosha", "qosha_guard", "ask.py"))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        k = m.kind_of(tool_name or "", args)
        return m.KIND_TEXT.get(k[0], k[0]) if k else None
    except Exception:
        import re
        text = (tool_name or "") + " " + " ".join(str(v) for v in (args or {}).values()) if isinstance(args, dict) else str(tool_name)
        hit = re.search(r"send|reply|forward|delete|remove|trash|\brm\b|del |pay|checkout|purchase|share|publish|post|git push|rsvp", text, re.I)
        return "send, pay, delete or share" if hit else None


def guard_ready(manager) -> bool:
    try:
        return any(getattr(cb, "__qosha_guard_ready__", False) is True
                   for cb in (getattr(manager, "_hooks", {}) or {}).get("pre_tool_call", []))
    except Exception:
        return False


def patch(mod) -> None:
    orig = getattr(mod, "_get_pre_tool_call_directive_details", None)
    if orig is None or getattr(orig, "__qosha_barrier__", False):
        return

    def _get_pre_tool_call_directive_details(tool_name, args, *a, **kw):
        try:
            qosha = _qosha_home()
        except Exception:
            qosha = True
        if qosha:
            try:
                mod._join_background_discovery()
                manager = mod._delivery_manager()      # runs discovery if it never ran
                mod._join_background_discovery()
                ok = guard_ready(manager)
            except Exception:
                ok = False
            if not ok:
                if os.environ.get("QOSHA_BOX") or os.environ.get("QOSHA_LAB"):
                    return mod._PreToolCallDirective(action="block", message=BLOCKED)
                # the person's own computer (Ren, 17 Nov): only what would send, pay, delete or share is held when the
                # ask-first check is missing; everything else runs, so Qosha can still repair itself
                kind = _local_kind(tool_name, args)
                if kind:
                    return mod._PreToolCallDirective(action="block", message=LOCAL_HELD % kind)
        return orig(tool_name, args, *a, **kw)

    _get_pre_tool_call_directive_details.__qosha_barrier__ = True
    _get_pre_tool_call_directive_details.__wrapped__ = orig
    mod._get_pre_tool_call_directive_details = _get_pre_tool_call_directive_details


class _Loader(importlib.abc.Loader):
    def __init__(self, inner):
        self.inner = inner

    def create_module(self, spec):
        return self.inner.create_module(spec)

    def exec_module(self, module):
        self.inner.exec_module(module)
        patch(module)


class _Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, name, path=None, target=None):
        if name != TARGET:
            return None
        for f in sys.meta_path:
            if f is self or not hasattr(f, "find_spec"):
                continue
            spec = f.find_spec(name, path, target)
            if spec is not None:
                if spec.loader is not None:
                    spec.loader = _Loader(spec.loader)
                return spec
        return None


def install() -> None:
    if TARGET in sys.modules:
        patch(sys.modules[TARGET])
    elif not any(isinstance(f, _Finder) for f in sys.meta_path):
        sys.meta_path.insert(0, _Finder())


install()
