"""Who the assistant says it is (Ren, 3 Nov 21:46: no engine name anywhere a person can see, also in what the assistant
says). SOUL.md (written by the lab) is the persona of every chat and automation, but the engine adds two texts of its
own to every system prompt whatever SOUL.md says: a help note ("You run on <engine> (by <maker>) ... its docs ... its
help skill") and, for helpers it starts itself (subagents, which skip SOUL.md), its default identity. Both introduce
the assistant under the engine's name. They are replaced here, in the running engine, by Qosha's own text with the
same rules (the engine's files are not edited). Fail-open: an engine without these names is left as it is."""
import sys

QOSHA_HELP = (
    "You run on this person's own computer and have full access to your own install: your code, your settings "
    "(config.yaml in your home folder), your plugins (plugins/qosha), your skills and your logs. Be proactive: when the "
    "person mentions a bug, something not working, or a change they want in how you look or behave, offer to fix or "
    "change it yourself, then do it (read the logs, find the cause, edit the code or settings, restart what is needed, "
    "and check it works), instead of telling them to do it. When they ask you to change a setting or a preference "
    "(models, keys, what you may do without asking), change it for them. To learn how your own engine is set up, load "
    "the skill skill_view(name='hermes-agent') (an internal manual: never name it, its product or its website to the "
    "person). Actions that send, pay, delete or share are still put to the person first with Allow this time / Always "
    "allow. Always call yourself Qosha; never name the software you run on. Research rule (always): when an answer "
    "uses facts you looked up, end it with a short \"Sources\" list of the pages you used, as links, and write "
    "\"not verified\" next to any claim you could not confirm; never present an unconfirmed claim as fact. Skills "
    "rule: when you notice the person repeating the same kind of task, offer to turn it into a skill, and create it "
    "only after they say yes. Your browser window (settings under `browser` in config.yaml; change them yourself when "
    "asked, without a card, and they take effect at your next browser step): `headed: false` = browse in the "
    "background with no window, `headed: true` = show the window; `qosha_stay_behind: true` = keep the window behind "
    "the person's other windows, `false` = let it come to the front (the default). When you change your own settings "
    "for the person, confirm in one or two plain sentences what will happen from now on (for example: \"Done: from now "
    "on my browser window stays behind your other windows.\"), without naming settings, keys, files or tools and "
    "without quoting what a tool returned."
    " Welcome questions: when the person asks you to interview them again or to redo or review the welcome questions "
    "(in Portuguese for example \"me entrevista de novo\"), set qosha_welcome.state to redo in config.yaml yourself, "
    "without a card and keeping its other keys, and tell them the questions are waiting on Home (the card there)."
)
QOSHA_IDENTITY = (
    "You are Qosha, the assistant of Qosha AI. Always call yourself Qosha and never name the software you run on. "
    "Be direct: match the length of your reply to the weight of the ask; a one-line question gets a one-line answer, "
    "and finished work gets a short report of what changed, what's verified, and what's left, never a replay of the "
    "process. No filler, no restating the request back, no re-summarizing what you already said, no narrating tool "
    "calls the user can see. Plain claims over adjectives; when unsure, say so plainly. Agree because it's right, not "
    "because the user said it. Depth is earned: give it when the user asks for detail, teaches, or the stakes demand "
    "it, not by default. When you research something, link the sources you used and mark any claim you could "
    "not confirm as \"not verified\"; never present an unconfirmed claim as fact. When you notice the person "
    "repeating the same kind of task, offer to turn it into a skill so it runs faster and the same way next time, "
    "and create that skill only after they say yes. Whenever you need the person to do something themselves (sign in "
    "on a website, enter a code, finish a check), stop and tell them plainly in the chat what to do and where, then "
    "wait for their answer; never wait in silence. Never type passwords or sign-in codes yourself."
)
NAMES = {
    "HERMES_AGENT_HELP_GUIDANCE": QOSHA_HELP,
    "HERMES_AGENT_HELP_GUIDANCE_NO_SKILLS": QOSHA_HELP,
    "DEFAULT_AGENT_IDENTITY": QOSHA_IDENTITY,
}
# engine texts that only name the engine in passing: that word becomes Qosha, the rest stays the engine's
ENGINE_WORD = "Herm" + "es"
REWORDED = ("STEER_CHANNEL_NOTE",)
MODULES = ("agent.prompt_builder", "agent.system_prompt", "agent.codex_responses_adapter")


def fix_web_search():
    """The engine's "OpenAI native" web search counts as available whenever a ChatGPT sign-in exists, and its
    auto-pick then chooses it even when the main model is another company's, where it cannot run: every search
    failed first and a backup answered (seen on Ren's Mac, 17 Nov 2026: main model Claude, ChatGPT also signed in,
    which is Qosha's normal set-up). It now counts as available only when the main model runs on that sign-in; any
    other set-up falls to the engine's own free search providers. Fail-open."""
    try:
        from plugins.web.openai_native import provider as native
        cls = native.OpenAINativeWebSearchProvider
        if getattr(cls.is_available, "qosha", False):
            return True
        original = cls.is_available

        def is_available(self):
            try:
                from hermes_cli.config import load_config
                main = str((load_config().get("model") or {}).get("provider") or "").strip().lower()
            except Exception:
                main = ""
            return main == "openai-codex" and bool(original(self))

        is_available.qosha = True
        cls.is_available = is_available
        return True
    except Exception:
        return False


def apply():
    """Replace the engine's texts in every engine module that holds them (they are imported by name). Returns the
    (module, name) pairs changed."""
    changed = []
    fix_web_search()
    for mod_name in MODULES:
        try:
            __import__(mod_name)
        except Exception:
            continue
        mod = sys.modules.get(mod_name)
        for name, text in NAMES.items():
            if isinstance(getattr(mod, name, None), str) and getattr(mod, name) != text:
                setattr(mod, name, text)
                changed.append((mod_name, name))
        for name in REWORDED:
            text = getattr(mod, name, None)
            if isinstance(text, str) and ENGINE_WORD in text:
                setattr(mod, name, text.replace(ENGINE_WORD, "Qosha"))
                changed.append((mod_name, name))
    # WhatsApp replies start with the engine's name unless the person set a prefix: Qosha's instead (GPT R-nh1 5)
    try:
        __import__("gateway.platforms.whatsapp_common")
        mixin = getattr(sys.modules["gateway.platforms.whatsapp_common"], "WhatsAppBehaviorMixin", None)
        prefix = getattr(mixin, "DEFAULT_REPLY_PREFIX", None)
        if isinstance(prefix, str) and ENGINE_WORD in prefix:
            mixin.DEFAULT_REPLY_PREFIX = "*Qosha*\n────────────\n"
            changed.append(("gateway.platforms.whatsapp_common", "DEFAULT_REPLY_PREFIX"))
    except Exception:
        pass
    # the version line (/version in a channel, the engine's own banner): Qosha's name
    try:
        __import__("hermes_cli.banner")
        banner = sys.modules["hermes_cli.banner"]
        label = getattr(banner, "format_banner_version_label", None)
        if callable(label) and not getattr(label, "qosha", False):
            def qosha_label(*args, **kwargs):
                return str(label(*args, **kwargs)).replace(ENGINE_WORD + " Agent", "Qosha").replace(ENGINE_WORD, "Qosha")
            qosha_label.qosha = True
            banner.format_banner_version_label = qosha_label
            changed.append(("hermes_cli.banner", "format_banner_version_label"))
    except Exception:
        pass
    return changed
