"""The council's real seats (P0, 8 Nov 2026). Each returns a core.SeatBackend: (prompt_bytes, timeout, cancel) -> SeatAnswer.

- Claude and ChatGPT: the engine's own text-only completion, agent.auxiliary_client.call_llm, through the sign-ins
  already in this Qosha (its credential pool). tools=None, so no tool is ever offered (the tools key is only added when
  tools are given). A fresh message list every time: no conversation, no files, no MCP.
  Claude: this file picks the pool entry itself, so it knows (and the report says) when the Qosha API key fallback
  answered instead of the subscription seat. The pool's own order puts the seat first (credential_pool.py:2835-2866).
- Gemini: the box's Gemini helper (agy on the person's Google AI Pro sign-in), reached over HTTP with its key; on a Mac,
  the connector's Gemini. Text in, text out.

Errors are classified for core: sign-in refused -> AUTH (no retry); no sign-in -> NOT_CONNECTED; timeouts, 5xx, rate
limits and network errors -> RETRYABLE; an unknown model -> the next model in the seat's list (reported as fallback).
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

try:   # inside the plugin package
    from . import core
except ImportError:  # loaded by path (tests)
    import qosha_council_core as core  # type: ignore

# One place for the seat models (handoff 4a). The first model in each list is the one asked for; the others are
# fallbacks, used only when the first one does not exist on this sign-in, and always named in the report.
SEAT_MODELS = {
    "claude": ["claude-opus-5-5"],
    "chatgpt": ["gpt-6-astra", "gpt-5.6-sol"],
    "gemini": ["gemini-4-argon-high", "gemini-3.8-flash-high"],
}
MERGE_MODELS = [("claude", "claude-opus-5-5"), ("chatgpt", "gpt-6-astra")]
EFFORT = "high"
MAX_TOKENS = 4096


def _status(exc) -> int:
    for attr in ("status_code", "status", "code", "http_status"):
        v = getattr(exc, attr, None)
        if isinstance(v, int):
            return v
    resp = getattr(exc, "response", None)
    v = getattr(resp, "status_code", None)
    return v if isinstance(v, int) else 0


def classify(exc) -> tuple:
    """(kind, reason, model_missing) for an exception from a provider call."""
    name = type(exc).__name__
    text = str(exc)
    low = text.lower()
    code = _status(exc)
    if "no api key was found" in low or "no codex oauth token" in low or "no anthropic credentials" in low \
            or "not signed in" in low:
        return core.NOT_CONNECTED, "not connected", False
    if code == 404 or ("model" in low and ("not_found" in low or "not found" in low or "does not exist" in low
                                           or "unsupported model" in low or "not supported" in low)):
        return core.FATAL, "model not available", True
    if code in (401, 403) or "authentication" in low or "unauthorized" in low or "invalid_grant" in low \
            or "relogin" in low or "expired" in low and "token" in low:
        return core.AUTH, "sign-in refused (HTTP %d)" % code if code else "sign-in refused", False
    if code == 429 or "rate limit" in low or "rate_limit" in low or "usage limit" in low or "overloaded" in low:
        return core.RETRYABLE, "rate limited", False
    if code >= 500 or "timeout" in low or "timed out" in name.lower() or "timeout" in name.lower() \
            or "connection" in low or "connection" in name.lower() or "temporar" in low:
        return core.RETRYABLE, ("timeout" if "time" in low or "time" in name.lower() else "HTTP %d" % code if code
                                else "network error"), False
    return core.FATAL, name, False


def _text_of(resp) -> str:
    """The answer text from an OpenAI-shaped reply (what the engine's provider clients return, its Anthropic adapter
    included) or, defensively, a native Anthropic-shaped one."""
    try:
        if getattr(resp, "choices", None):
            return (resp.choices[0].message.content or "").strip()
        parts = getattr(resp, "content", None) or []
        return "".join(getattr(p, "text", "") or "" for p in parts if getattr(p, "type", "text") == "text").strip()
    except Exception:
        return ""


def direct_call(provider: str, model: str, text: str, timeout: float, effort: str, api_key=None, stop=None):
    """ONE text-only call to exactly `provider` (GPT R1 #5). The engine's call_llm may fall back to another provider
    on capacity, connection or rate-limit errors even when a provider is named (auxiliary_client.py:10455-10475), so the
    seats use the engine's provider client for that provider and the engine's own request builder, nothing else: no
    fallback chain, no tools (the tools key is only added when tools are given)."""
    import agent.auxiliary_client as aux
    client, resolved = aux.resolve_provider_client(provider, model, explicit_api_key=api_key)
    if client is None:
        raise core.SeatError(core.NOT_CONNECTED, "not connected")
    if stop is not None and stop.is_set():          # abandoned while the client was being made: send nothing
        raise core.SeatError(core.RETRYABLE, "timeout")
    kw = aux._build_call_kwargs(provider, resolved or model, [{"role": "user", "content": text}], max_tokens=MAX_TOKENS,
                                tools=None, timeout=timeout, reasoning_config={"enabled": True, "effort": effort})
    kw.pop("tools", None)
    kw.pop("tool_choice", None)
    return client.chat.completions.create(**kw)


def engine_seat(provider: str, models, effort: str = EFFORT, call_llm=None, pool_loader=None):
    """A seat on the engine's credential pool. call_llm (same keyword shape as direct_call's inputs) and pool_loader
    are injectable for tests; the default is direct_call."""
    models = list(models)

    def backend(prompt: bytes, timeout: float, cancel) -> core.SeatAnswer:
        note, api_key, entry = "", None, None
        if cancel is not None and cancel.is_set():
            raise core.SeatError(core.RETRYABLE, "timeout")
        if provider == "anthropic":
            entry = _pick_anthropic_entry(pool_loader)   # this call's own entry (never shared between calls)
            if entry is None:
                raise core.SeatError(core.NOT_CONNECTED, "not connected")
            api_key = getattr(entry, "runtime_api_key", None) or getattr(entry, "access_token", None)
            if _is_api_key_entry(entry):
                note = "Qosha API key fallback"
        text = prompt.decode("utf-8")
        last = None
        for i, model in enumerate(models):
            if cancel is not None and cancel.is_set():
                raise core.SeatError(core.RETRYABLE, "timeout")   # abandoned: no request is started (GPT R2 #2, R3 #4)
            try:
                if call_llm is not None:
                    resp = call_llm(provider=provider, model=model, messages=[{"role": "user", "content": text}],
                                    tools=None, max_tokens=MAX_TOKENS, timeout=timeout,
                                    reasoning_config={"enabled": True, "effort": effort},
                                    **({"api_key": api_key} if api_key else {}))
                else:
                    resp = direct_call(provider, model, text, timeout, effort, api_key, stop=cancel)
            except core.SeatError:
                raise
            except Exception as exc:
                kind, reason, missing = classify(exc)
                if missing and i + 1 < len(models):
                    last = reason
                    continue
                if provider == "anthropic" and kind == core.RETRYABLE and reason == "rate limited":
                    # Ren's rule: the Qosha API key only when the seat's usage runs out. The pool benches the seat,
                    # so the council's one retry picks the next entry (the key). Sign-in errors are never retried.
                    _rotate_anthropic(pool_loader, exc, entry)
                raise core.SeatError(kind, reason)
            out = _text_of(resp)
            ran = getattr(resp, "model", None) or model
            n = note
            if i > 0:
                n = (n + "; " if n else "") + "fallback model"
            return core.SeatAnswer(out, str(ran), n)
        raise core.SeatError(core.FATAL, last or "no model available")
    return backend


# ---- Claude credential choice (seat first, Qosha API key fallback) -------------------------------------------------

def _load(pool_loader):
    if pool_loader is not None:
        return pool_loader("anthropic")
    from agent.credential_pool import load_pool
    return load_pool("anthropic")


def _pick_anthropic_entry(pool_loader):
    try:
        pool = _load(pool_loader)
        return pool.select()
    except Exception:
        return None


def _is_api_key_entry(entry) -> bool:
    src = str(getattr(entry, "source", "") or "")
    return getattr(entry, "auth_type", "") == "api_key" or src.endswith("ANTHROPIC_API_KEY")


def _rotate_anthropic(pool_loader, exc, entry):
    if entry is None:
        return
    try:
        pool = _load(pool_loader)
        pool.mark_exhausted_and_rotate(status_code=_status(exc) or 429, credential_id=getattr(entry, "id", None))
    except Exception:
        pass


def _has_other_anthropic_entry(pool_loader) -> bool:
    try:
        pool = _load(pool_loader)
        return len([e for e in pool.entries()]) > 1
    except Exception:
        return False


# ---- Gemini -------------------------------------------------------------------------------------------------------

def helper_seat(url: str, key_reader, models=None, opener=urllib.request.urlopen):
    """The box's Gemini helper: POST {url}/v1/ask {"question", "models"} with X-Qosha-Key ->
    {"answer", "model"}; its errors: 401/403 sign-in, 503 not connected, 429/5xx/timeout retryable."""
    models = list(models or SEAT_MODELS["gemini"])

    def backend(prompt: bytes, timeout: float, cancel) -> core.SeatAnswer:
        body = json.dumps({"question": prompt.decode("utf-8"), "models": models,
                           "timeout": max(1, int(timeout) - 2)}).encode()
        req = urllib.request.Request(url.rstrip("/") + "/v1/ask", data=body, method="POST",
                                     headers={"Content-Type": "application/json", "X-Qosha-Key": key_reader() or ""})
        try:
            with opener(req, timeout=timeout) as r:
                d = json.loads(r.read())
        except urllib.error.HTTPError as e:
            try:
                err = json.loads(e.read()).get("error", "")
            except Exception:
                err = ""
            if e.code == 503 and err in ("gemini_not_connected", "gemini_not_available", "not_signed_in"):
                raise core.SeatError(core.NOT_CONNECTED, "not connected")
            if err == "tool_used":
                raise core.SeatError(core.FATAL, "used a tool, so its answer was not used")
            if err == "quota_reached":
                raise core.SeatError(core.FATAL, "its plan's usage limit is reached for now")
            if e.code in (401, 403) or err == "sign_in_needed":
                raise core.SeatError(core.AUTH, "sign-in needed")
            if e.code == 429 or e.code >= 500:
                raise core.SeatError(core.RETRYABLE, "HTTP %d" % e.code)
            raise core.SeatError(core.FATAL, "HTTP %d" % e.code)
        except (OSError, ValueError) as e:
            raise core.SeatError(core.RETRYABLE, "timeout" if "timed out" in str(e).lower() else "network error")
        ans = d.get("answer") if isinstance(d, dict) else None
        if not isinstance(ans, str) or not ans.strip():
            raise core.SeatError(core.RETRYABLE, "empty answer")
        model = str(d.get("model") or models[0])
        note = "fallback model" if model != models[0] else ""
        return core.SeatAnswer(ans, model, note)
    return backend


def connector_seat(client, model_label: str = ""):
    """Gemini through the Mac connector (connector_client.ask): text in, text out."""
    def backend(prompt: bytes, timeout: float, cancel) -> core.SeatAnswer:
        try:
            r = client.ask("gemini", prompt.decode("utf-8"))
        except Exception as e:
            code = _status(e)
            low = str(e).lower()
            if code == 503 or "not_available" in low or "not set up" in low:
                raise core.SeatError(core.NOT_CONNECTED, "not connected")
            if code in (429, 502, 504) or "busy" in low or "timeout" in low:
                raise core.SeatError(core.RETRYABLE, "HTTP %d" % code if code else "busy")
            raise core.SeatError(core.FATAL, type(e).__name__)
        ans = (r or {}).get("answer", "")
        if not ans.strip():
            raise core.SeatError(core.RETRYABLE, "empty answer")
        return core.SeatAnswer(ans, (r or {}).get("model") or model_label or "gemini")
    return backend


def merge_backends(call_llm=None, pool_loader=None):
    """Claude first, then the ChatGPT seat model; both text only (handoff 4a)."""
    return [("claude-opus-5-5", engine_seat("anthropic", ["claude-opus-5-5"], call_llm=call_llm, pool_loader=pool_loader)),
            ("gpt-6-astra", engine_seat("openai-codex", ["gpt-6-astra", "gpt-5.6-sol"], call_llm=call_llm))]
