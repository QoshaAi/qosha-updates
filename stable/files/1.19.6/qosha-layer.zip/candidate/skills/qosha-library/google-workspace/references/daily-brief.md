# Daily Brief (Gmail + Calendar)

Produce an action-oriented start-of-day or next-day brief from Gmail and Google Calendar. Load this reference when the user asks for a morning brief, "what's on my calendar and what email needs attention," meeting preparation, or tomorrow's deadlines and conflicts. The main SKILL.md owns the commands; this reference owns the brief-composition procedure.

Upstream credit for this workflow is in NOTICE.

## Procedure

### 1. Resolve day and identity

Confirm Google account, timezone, and target local day. Use an explicit half-open window `[day_start, next_day_start)` in the account's timezone rather than vague "today" filters — the account timezone and the machine timezone are frequently different. Done when the exact UTC and local window are stated.

### 2. Fetch calendar events

Use `calendar list` with the exact window, once per calendar in scope (`--calendar`, default `primary`), with a `--max` large enough for the day (for example 100). Each call returns one page only, so if a call returns exactly `--max` events, narrow the window or raise `--max`; if that still can't be confirmed, name the gap. Include all-day events, holds, location/video links (from `location` and `description`), and leave out events whose `status` is `cancelled`. This read returns no organizer or attendee response status: don't guess whether a meeting is accepted or tentative; say "response status not available" in the coverage section, or ask the person. Detect overlaps and unrealistic travel gaps between consecutive events. Done when every calendar in scope was read (or named as missing) and cancelled events are excluded intentionally.

### 3. Fetch relevant Gmail threads

Search a bounded recent window plus messages connected to meeting participants, subjects, projects, and explicit deadlines (see `gmail-search-syntax.md` for operators). Search returns one page of up to `--max` messages; if it returns exactly `--max`, there may be more, so narrow the query or say so. There is no whole-thread command: for each relevant thread, search for its other messages (subject and participants, `in:anywhere`), keep those with the same `threadId`, and `gmail get` each. If earlier messages can't be found, mark that thread "may be incomplete". Do not dump every unread newsletter into the brief. Done when each included email changes preparation, priority, or follow-up, and every gap is listed under data coverage.

### 4. Link mail to meetings

Match by thread references, participant addresses, company/domain, event title, and project context. Treat fuzzy matches as suggestions, not facts — one shared keyword is not an association. Extract promised documents, unanswered questions, pre-read links, and decisions needed. Done when each meeting has either preparation items or an explicit "no preparation found."

### 5. Build the brief

Use this order:

1. Schedule at a glance
2. Conflicts and tight transitions
3. Meetings requiring preparation
4. Urgent mail and deadlines
5. Follow-ups owed by the user
6. Waiting on others
7. Data coverage or connector failures

Rank by consequence and time, not message count. Done when each included item has a clear preparation, deadline, conflict, or follow-up reason.

### 6. Offer bounded actions

A brief request is not authorization to change anything. Offer, and present in full:

- **Replies:** show the full reply text in chat (Gmail drafts in the mailbox are not available). If the person wants it sent, prepare a `gmail reply` with the exact text; it goes to Decisions waiting for their Approve.
- **Calendar holds:** prepare a `calendar create`; it goes to Decisions waiting for their Approve.
- **Tasks:** this skill has no task command. Create tasks only through a task app connected in Connections that offers task creation (that write also goes to Decisions waiting); otherwise put the task list in the brief or in Your files, and say which kind of app to connect if they want tasks created.

Never say a reply was sent or a hold was booked until Qosha's executor confirms it; then read the event or sent message back. Done when every offered action is either waiting in Decisions waiting, confirmed by the executor with a Google ID/link and correct time/recipient, or delivered as a local list.

## Pitfalls

- Mixing account timezone with the machine timezone.
- Hiding all-day commitments below timed meetings.
- Treating tentative meetings as confirmed.
- Associating an email to a meeting from one shared keyword alone.
- Creating calendar events while the user only requested a brief.

## Verification

- [ ] The day window and calendars covered are stated, or gaps are named.
- [ ] Every prep item, deadline, and conflict traces to a specific event or thread.
- [ ] No change happened without the person's Approve in Decisions waiting; executor-confirmed changes were read back.
- [ ] Paging limits, missing calendars, possibly incomplete threads and unavailable attendee status are named under data coverage.
