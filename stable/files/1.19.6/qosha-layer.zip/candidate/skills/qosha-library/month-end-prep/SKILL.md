---
name: month-end-prep
description: Use to check a month's books before the accountant.
version: 1.0.0
author: Qosha
license: Qosha original (owned by Qosha AI LLC)
metadata:
  hermes:
    tags:
    - Finance
    - Bookkeeping
    - Month End
    - Reconciliation
    related_skills:
    - close-month
    - pay-the-bills
    - ap-processor
    - spreadsheets
    - pdf-files
---
# Month-end checks

Check a month's books against the money that really moved and hand the accountant a packet they can work from without
asking anyone. Four questions: does the money in the bank match the books, does payroll tie, is anything entered
twice, and is every line coded and backed by a receipt. Then explain the month in plain words. This skill only reads
and reports; it never changes the books.

## When to Use
- "Get last month ready for my accountant."
- "Do the bank deposits match Stripe?"
- "Is anything entered twice?"
- "Which expenses are missing receipts?"
- close-month or pay-the-bills asked for the checks.

Not for: the full close with a cash outlook and one signed-off packet (use close-month).

## What it needs
- **Required:** a connected accounting app (QuickBooks, Xero, Zoho Books or similar), or two exports uploaded to Your
  files: the profit and loss report and the transaction detail for the month.
- **Recommended:** payment and store apps (Stripe, Square, PayPal, Shopify), or their settlement files with fees; a bank
  statement.
- **Optional:** card or expense apps; a payroll app (Gusto); receipt files uploaded to Your files.
- **From Memory or the accounting app,** asked once if missing: business currency and year end.
- **Matching settings,** asked once and used for this run. Show the exact settings proposed for Memory and save them
  only after the owner explicitly agrees. Qosha defaults; the owner can change each (kept in Memory):
  - amounts tie within 1.00 of the business currency;
  - payout and deposit dates within 4 calendar days;
  - possible duplicate: same amount to the cent, same supplier or customer, within 10 days;
  - receipt expected for expenses of 75 or more (or the accountant's own rule), matched within 1.00 and 5 days;
  - an expense line is called out when it moves 15% or more against last month.

## Steps
**When pay-the-bills asks:** check only the entries of the payment run it supplies, for uncoded lines, a bill paid
twice and settlement gaps. Return the findings to pay-the-bills; any fix is its own decision. Do not read the whole
month, run the steps below or build the packet.

1. **Confirm the month and that it is safe to check.** Default: the last full calendar month. If the month is filed or
   locked, stop. With two accounting apps, the owner names the one that holds these books; every figure comes from it.
   Read nothing until the month is confirmed open.
2. **Read everything and say what was covered.** Read every page of the month's records. List which kinds were seen
   (register, bills, invoices, bank feed, payouts, payroll runs) and which weren't, and why. A summary figure that
   contradicts its own rows gives way to the row total (zero costs next to real sales is a warning sign). An app that
   returns nothing for a month with activity is a gap: ask for an export, never report it as clean.
3. **Tie money in.** Give every payout of the month a result:
   - "Tied": matches a bank deposit, net of fees, within tolerance.
   - "Open": the missing side named, or the size of the amount or date gap shown.
   - Refunds tie to credit notes; held funds carry forward; bank lines the books haven't matched stay open.
   - Call no deposit unexplained until every connected payment app was searched.
   - For a shop, orders against booked sales and payouts against the bank are two separate answers.
4. **Tie payroll (only with a payroll app; totals only).** Gross wages, employer taxes and benefits, and net pay agree
   with the expense accounts and the cash that left. Roll each payroll liability forward: opening balance (last close,
   or the books' opening figure, saying which) plus the month's accruals, minus payments to the tax office or provider
   taken from the payroll app or bank (never from the liability account itself), plus or minus recorded adjustments,
   equals the closing balance. Compare contractor pay with whatever account the books use. Each gap beyond tolerance
   is its own item with a likely cause.
5. **Find anything booked twice.** Treat the split lines of one transaction as one. Where the books keep bills and
   invoices as documents, compare the documents, so an unpaid bill keyed twice is found. State the window used; widen
   it for a supplier the owner doubts. The owner rules on each pair.
6. **Find what is uncoded or unsupported.** Everything the accounting app marks as needing attention, uncoded card or
   expense spend, and each expense at or above the receipt limit with no attachment or matching upload. Count
   reimbursements once.
7. **The owner decides every open item before any file exists.** Show the full list. For each, the owner fixes it in
   the accounting app or defers it. Deferred items stay visible in every output. If the owner wants Qosha to make a fix,
   it goes to Decisions waiting (close-month runs this). Done when no item is undecided.
8. **Recheck after corrections.** When the owner says fixes were made (or an approved fix went through), read the
   changed entries again from the accounting app, or ask for refreshed exports. Rerun every check those entries touch
   and recompute the affected totals. Any new or still-open finding goes back to step 7. Go on only when the reread
   books show no undecided item.
9. **Explain the month** in about a minute's reading: the result, each material change against the comparison month
   with the figures behind it, and what is still open or uncertain. Every claim traces to a figure in the packet. Never
   state a cause the books don't show; say "cause unknown". Money received for work not yet delivered is named "not
   yet earned". Explain any accounting word used.
   Show the currency code beside every amount, in Chat and in every output.
10. **Build the packet once the owner says go.** Then tell the owner in chat what tied, what is open, and where the
   files are.

## Where results go
- **Your files,** with year and month in each name (e.g. month-end-2026-10.xlsx):
  - a workbook where an accountant can trace each result to its source rows, see every open or deferred item and what
    would settle it, check the month's profit and loss, and (with payroll) check payroll totals and each liability
    roll-forward;
  - a short printable summary (PDF) for someone who won't open the workbook;
  - a review page in the owner's preferred format (HTML unless Memory says Word or PDF).
- **Chat:** what tied, what is open, where the files are.
- Every output names the sources used, those unavailable and why, and says: "Not legal or tax advice; check with a
  professional."

## What waits for Approve
- Getting the packet to the accountant. The packet stays in Your files. Qosha can draft a cover note: Gmail as
  copy-ready text in Chat, or one exact send in Decisions waiting (Qosha can't create Gmail drafts); Outlook as a
  draft in the owner's mailbox for them to send. Qosha's Gmail send can't carry attachments yet, so the owner
  attaches the packet files and sends, or a connected app's own send action is used when it has one. Never upload
  or share a file to get around this.
- Sharing the packet (a shared folder or link) isn't available in Qosha yet; the owner shares it from Your files.
- Qosha reports each item as prepared, waiting for Approve, or handed to the owner. Whether it went out shows in
  Decisions waiting after the owner's Approve; this skill never says it was sent.
- Creating a page in Notion or Canva.
- Any fix to the books the owner asks Qosha to make; this skill never edits, voids or recodes an entry itself.

Saving files in Your files needs no approval. Approve covers exactly the message shown; any later edit is a new
decision.

## When an app isn't connected
- **No accounting app:** ask for the profit and loss export and the transaction detail export as two files.
- **No payment app:** ask for settlement files that include fees.
- **No bank feed or report access:** ask for the bank statement or exports.
- Suggest the kind of app to connect in Connections. Never ask for passwords or keys in chat.

## Be careful
- Split lines are not duplicates. Compare gross with gross and net with net.
- Payouts made in the first days of next month may belong to this month's sales; say which.
- A payment app in another currency stays in its own currency code; never convert silently.
- A partial month, or no earlier close for the opening liability: say so and which figure was used.
- Payroll shows totals only: no names, per-person pay, ID numbers or bank numbers.

## How to check it worked
- A payout of 3,210.45 after fees and a deposit of 3,210.45 two days later: tied. A payout of 760.00 with no deposit:
  open, missing on the bank side, amount shown.
- A 418.90 bill from one supplier entered twice five days apart, both unpaid, is flagged with no bank line; one
  2,050.00 purchase split over three accounts is not.
- Withholding of 1,780 accrued and paid, opening 0, closing 0: no gap. Same month with the payment never booked: one
  1,780 gap on that liability and no wage gap.
- Revenue 6,500 lower because a regular customer wasn't invoiced: the account points to the missing invoice; a 4,000
  prepayment is "not yet earned"; an unexplained rise in fuel says "cause unknown".
- A deferred item shows in the workbook and in the summary's open count; with any item undecided, no file exists.
- After the owner recodes a flagged line, it is read again and drops off the list; a correction that creates a new
  duplicate is caught and decided before any file exists.
- No record in the accounting app was changed.
