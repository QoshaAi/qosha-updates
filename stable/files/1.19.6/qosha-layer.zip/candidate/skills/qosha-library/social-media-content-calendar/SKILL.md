---
name: social-media-content-calendar
description: Use to plan social posts across platforms, for Approve.
version: 0.1.0
author: Qosha (based on MIT/Apache-licensed work; see NOTICE)
license: MIT
platforms:
- linux
- macos
- windows
metadata:
  hermes:
    tags:
    - Social-Media
    - Content-Calendar
    - Campaigns
    - Publishing
    related_skills:
    - humanizer
---
# Social Media Content Calendar

## In Qosha

In Qosha you plan and draft. Posting, scheduling or changing a post on any platform needs that platform connected in Connections and offering a post or schedule action, and each post goes to Decisions waiting for the person's Approve. If the platform is not connected, or it is connected but offers no post or schedule action, give the person the finished posts to publish themselves. Never use any other route (a command-line tool, a direct API call, a browser login) to post.

Plan a concrete calendar across selected social platforms. This skill owns campaign structure, post briefs, channel adaptation, approvals, and publishing status. For platforms without a connected app that can post or schedule, the handoff ends at finished drafts for the person's own scheduler: say so rather than claiming publication.

## When to Use

- "Build next month's social calendar."
- "Turn this launch into posts for X, LinkedIn, Instagram, and TikTok."
- "Draft and schedule a campaign."
- "Repurpose these articles/videos into social content."

Don't use for: a single one-off post. Draft it directly; if its platform is connected and offers a post action, put it in Decisions waiting, otherwise hand the finished post to the person.

## Procedure

### 1. Define campaign constraints

Record objective, audience, offer/message, platforms, date range, cadence, voice, mandatory/prohibited claims, links, tracking convention, localization, and approval/publishing authority. Done when each proposed post has a clear business purpose.

### 2. Inventory source material

Collect verified product facts, launches, articles, media, testimonials with permission, brand assets, and key dates using `read_file` and `web_extract`. Mark claim owners and expiration. Done when unsupported claims and missing assets are visible.

### 3. Build themes and calendar slots

Create a balanced mix such as education, proof, product, community, event, behind-the-scenes, and conversation. Account for platform cadence and campaign milestones. Done when dates, platforms, themes, and objectives form a coherent calendar rather than duplicate cross-posts.

### 4. Write platform-specific briefs

For each post specify hook, core message, format, copy length, CTA, link, asset dimensions/content, accessibility text, tags/mentions, and success metric. Adapt rather than copy-paste between platforms. Done when a creator can produce the asset without hidden context.

### 5. Draft copy and assets

Load `humanizer` for voice. For visuals, use the person's existing or uploaded assets from Your files. If Canva is connected in Connections and offers a design action, you can prepare the design there; any write into Canva goes to Decisions waiting for the person's Approve. Otherwise write an asset brief (size, content, text on image, alt text) for each post and save it in Your files. Keep any asset file you produce in Your files. Preserve factual claims and shared campaign identity while respecting platform norms. Done when every calendar slot has draft copy and asset status.

### 6. Run editorial and risk review

Check factual accuracy, tone, repetition, rights/permissions, accessibility, disclosures, link destination, date relevance, and crisis sensitivity. Mark `draft`, `needs review`, or `approved`; do not publish from draft. Done when every post has a disposition and owner.

### 7. Schedule or hand off

Present the approval batch. For each post whose platform is connected in Connections and offers a post or schedule action, put the post (platform, account, time, final copy and assets) into Decisions waiting; it is published or scheduled only after the person presses Approve. For platforms that are not connected, or connected without a post or schedule action, deliver the finished package (copy, assets, timing) for the user's scheduling tool and mark those slots handed-off, not published. Mark a slot published or scheduled only after Qosha's confirmation for that approved decision; then read back the scheduled time, account, content preview, and the platform's post or job ID. Until then, say the post is waiting for Approve. Done when the calendar reflects verified publishing or handoff status per slot.

## Pitfalls

- Identical copy on every platform.
- Filling cadence with low-value repetitive posts.
- Publishing unverified metrics, testimonials, or future claims.
- Confusing generated asset completion with scheduled publication.
- Claiming "scheduled" for platforms where the handoff ended at drafts.

## Verification

- [ ] Every post traces to a campaign objective and a verified claim inventory.
- [ ] No post was published from `draft` or `needs review` state.
- [ ] Published slots have provider-confirmed IDs; handed-off slots are marked as such.
- [ ] Rights, permissions, and disclosures checked before any publish.
