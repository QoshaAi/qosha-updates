---
name: independent-review
description: Use to get an independent check before relying on work.
version: 1.0.0
author: Qosha
license: Qosha original (owned by Qosha AI LLC)
metadata:
  version: 1.0.0
---
# Independent review

**When to use:** Get an independent second (and third) check of an answer, a document, research, a design or code before relying on it. Use when you ask for a second opinion, a fact-check, an independent review or 'check this properly'.

A check by reviewers that did not produce the work. Agreement is not evidence; each claim needs its own evidence.

## Steps

1. **Register what is being checked** before any review: the artifact (file paths or the exact text) and a claims
   table, one row per claim that matters, each with the evidence that would prove or refute it.
2. **Send it to independent reviewers.** First check which review capability this workspace actually offers (a
   separate assistant or model, in a fresh context, that did not produce the work). If one is available, give each
   reviewer the same packet in a fresh context, using different models when the setup offers them. Reviewers work
   separately and do not see each other's answers. Ask each to end with `FAILURES: n` and one line per failure
   (claim, why, evidence).
   If no independent reviewer is available, save a review packet in Your files (the artifact or its location, the
   claims table, the review instructions and the `FAILURES: n` format) for the person to give to reviewers they
   arrange, and mark every claim pending until their findings come back. Never count a review by whoever produced the work
   (including this assistant, if it produced it) as an independent one.
3. **Resolve each claim** to exactly one status: verified (scope stated, evidence cited), refuted (evidence cited),
   pending (not checkable yet), or preference (a matter of taste; the person decides).
4. **Recheck after fixes.** A fixed claim goes back to a reviewer; a fix is not verified by the person who made it.
5. **Report** to the person: the claims table with statuses, what each reviewer found, what is still pending.

## Rules

- Never type a reviewer's verdict yourself; quote what the reviewer actually returned.
- Say what each check could and could not have seen. A null result from a weak check is not evidence of absence.
- Sharing is not available: never share a file or link to get a review. Material goes to an outside reviewer only
  through an action a connected app actually offers; that action goes to Decisions waiting and runs only after the
  person presses Approve on that exact action (a chat "OK" is not an Approve). If no such action exists, the person
  passes the review packet from Your files on themselves.
- No purchases or paid calls on your own; anything that would cost money is the person's call.
- Tell the person how many model calls the review will take before starting.
