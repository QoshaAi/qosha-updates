---
name: build-and-verify
description: Use to build or change software the careful way.
version: 1.0.0
author: Qosha
license: Qosha original (owned by Qosha AI LLC)
metadata:
  version: 1.0.0
---
# Build and verify

**When to use:** Build or change software with a frozen agreement, sandboxed tests and independent reviews before anything ships. Use when you ask to build, fix or change code carefully, 'the careful way', or with a contract and reviews.

A build loop where the builder never grades its own work. It is slower than "just change it" and is meant for changes
that matter. Suggest it for important code changes; start it only when you ask for it.

## The loop

1. **Agree the contract first.** Write down, with the person, before any code: the goal, the acceptance criteria, the
   expected results (including at least one input that must fail), the exact test command, the files in scope, the
   files that are frozen (tests, configs), the risk level and a cap on fix cycles. The person approves it in their own
   words. After approval the contract is frozen: a change to it is a new contract.
2. **Build in a copy inside Your files.** Work only from a project the person uploaded to Your files with no secrets
   in it (no `.env`, keys, tokens, credential or OAuth files, customer data dumps). Before copying, list any file that
   looks like a secret; if there is one, stop and ask for a clean upload instead of copying it. Make the work copy in
   a run folder inside Your files (a git commit as baseline). The builder edits only the copy, only files in scope,
   never frozen files. The copy, patch, logs and evidence packet all stay in that run folder.
3. **Test in a sandbox, only if the sandbox is proven.** Running in a terminal is not isolation by itself. Before
   running any project code, check that the run will have no outbound network, no secrets in the environment and
   writes only inside the copy: for example a network call that must fail, an environment listing with no keys, and
   a write outside the copy that must be refused. If any of these cannot be enforced and shown, do not run the
   project code: stop, say which restriction is missing, and give the person the exact test command and expected
   result to run themselves. When the sandbox is proven, write the expected result before running the agreed test
   command, and make sure the test can fail (a deliberate failure, a negative control).
4. **Two independent reviews.** Use a reviewer only through a review capability this workspace actually offers
   (a separate assistant or model in a fresh context that did not build the change); check that it is available
   before counting on it. If none is available, put a review packet in the run folder (the contract, the patch, the
   test results, and the two review jobs below) for the person to give to reviewers they arrange, and mark the
   reviews pending until their findings come back. The builder never stands in for a reviewer. The reviewers work
   blind and separately, with different jobs: one runs the behaviour and tries to break it, one checks logic and
   safety. Each ends with `BLOCKING: n` and `VERDICT: PASS|BLOCK`.
5. **Fix cycles.** A failed test or a blocking review uses one cycle. Stop when the same failure happens twice, the cap
   is reached, the contract is broken, or the reviewers disagree after a fix. Every stop still produces the packet.
6. **Evidence packet** in the run folder in Your files: a five-line summary for the person, the test results with
   counts, both reviews (or "pending" with what is missing), the patch.
7. **The person decides, and the release is checked before it is queued.**
   - Apply the patch to a fresh copy of the project in Your files and re-run the agreed checks there. Only a
     candidate that passes after applying goes forward.
   - If a connected app (a code host or deployment service) offers the exact release action (merge, push, deploy),
     prepare that action and put it in Decisions waiting. It runs only after the person presses Approve on that
     exact action (a chat "OK" is not an Approve).
   - If no such action is offered, hand over the patch file and step-by-step apply and check instructions for the
     person to run themselves.
   - Say the release happened only when the executor confirms it. A rollback that touches anything outside Your
     files is its own decision: prepare the exact rollback action and put it in Decisions waiting; never roll back on
     your own.

## Hard rules

- The builder never marks its own work as passed; the sandboxed test run and the reviewers are the evidence.
- Changed files outside the scope, or any byte changed in a frozen file, stop the loop.
- Never lower the bar to get a pass: no skipping a review, no weaker test, no editing a frozen test.
- Tell the person the expected number of model calls before starting (build + reviews + summary, plus each fix cycle).
- Keep a short record of each run (goal, outcome, cycles, where the packet is) in Your files.
- Never read, print or copy secrets into the copy, the logs or the packet.

## Known limits

- Reviews by models can miss things; tests are the stronger evidence, and both together are the minimum.
- A sandbox without network makes tests that need the internet fail. That is intended; ask before loosening it.
- Without a proven sandbox or an available reviewer, the loop produces instructions and a pending packet, not a pass.
