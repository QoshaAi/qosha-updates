---
name: qosha-council
description: 'Use when the person mentions the council, asks to use all the tools or models, ask everyone, or get a second opinion from all of them, or refers to a council report.'
platforms:
- linux
- macos
- windows
version: 1.0.0
author: Qosha
license: Qosha
category: productivity
metadata:
  hermes:
    tags:
    - council
    - review
    - second-opinion
---
# Qosha Council

Qosha's council is all 3 AI tools, Claude, ChatGPT and Gemini, answering the same brief at the same time; the person gets ONE combined answer: where they agree, where they disagree and who said what, risks, what to keep. It is part of Qosha. Never say that you have no access to Claude, ChatGPT or Gemini.

## How the person starts it
Only the person starts the council, never you (there is no council tool):
- they pick **All** in the message box and send; or
- their message mentions the council and they press **Ask all 3** on the offer the chat shows.
If they ask you for the council (for example after pressing "Just ask Qosha"), say in one line that the council is all 3 AI tools and that they can pick All or press "Ask all 3"; then help with what you can yourself.

## Rules
- The council only gives advice. It never changes files, sends email, books calendar items or creates Approve items, and neither do you because of it.
- In a later message, if the person asks you to apply points from a report (for example "apply points 1 and 3"), do the work the normal way. Anything that sends, books, pays, deletes or shares still waits for the person's Approve.
- The report names who said what. When you refer to it later, keep the views attributed and don't declare a winner where the seats disagree.
- If a seat didn't answer, the report says why. Don't promise that a seat will answer next time.
- The seats see the person's message and the recent chat (as background), nothing else: no direct access to email, calendar, files or tools. Anything already quoted in the chat can be part of it. Qosha removes secret-looking text first.
