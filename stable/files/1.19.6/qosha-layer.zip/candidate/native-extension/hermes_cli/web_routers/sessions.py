"""Session dashboard routes (extracted verbatim from web_server.py).

Three routers because the original registration points are far apart and
global route order matters: ``list_router`` (GET /api/sessions) was registered
before the profiles ``sessions_router`` include, ``search_router``
(GET /api/sessions/search) right after it, and ``manage_router`` (the
mutation/detail endpoints) thousands of lines later - each is mounted at its
original registration point so the app's route table is byte-identical.

Handler bodies are byte-identical; web_server-owned helpers are reached via
the late-binding seam in :mod:`hermes_cli.web_deps` so tests that
``monkeypatch.setattr(web_server, "_helper", ...)`` keep working.
"""

import asyncio  # noqa: F401 — used by handlers
import base64
import hashlib
import json
import logging
import threading
import time  # noqa: F401
from typing import Any, Dict, List, Optional  # noqa: F401

from fastapi import APIRouter, HTTPException, Query, Request  # noqa: F401
from fastapi.encoders import jsonable_encoder
from fastapi.responses import StreamingResponse

from hermes_cli.web_deps import late
from hermes_state import _sql_session_last_active
from hermes_cli.web_models import (
    BulkDeleteSessions,
    SessionImport,
    SessionOwnerBackfill,
    SessionPrune,
    SessionRename,
)

# Same logger the handlers used before extraction (identical logger object).
_log = logging.getLogger("hermes_cli.web_server")

list_router = APIRouter()
search_router = APIRouter()
manage_router = APIRouter()

# Late-bound web_server helpers (resolved at call time; cycle-safe,
# monkeypatch-transparent).
_cron_default_profile = late("_cron_default_profile")
_cron_profile_home = late("_cron_profile_home")
_import_sessions_for_profile = late("_import_sessions_for_profile")
_maybe_auto_archive_for_profile = late("_maybe_auto_archive_for_profile")
_open_session_db_for_profile = late("_open_session_db_for_profile")
_prune_sessions = late("_prune_sessions")
_read_session_import_body = late("_read_session_import_body")
_session_latest_descendant = late("_session_latest_descendant")
_strip_session_list_rows = late("_strip_session_list_rows")


@list_router.get("/api/sessions")
def get_sessions(
    request: Request,
    # The 100-row page cap (idea from #39200) is enforced below: an unbounded
    # limit lets one request drag every session row (plus correlated-subquery
    # preview work) out of SQLite in a single hit. It is checked in the body
    # so the opt-in owned-v1 projection can report range errors as HTTP 400.
    limit: int = Query(20, ge=0),
    offset: int = Query(0, ge=0),
    min_messages: int = 0,
    archived: str = "exclude",
    order: str = "created",
    source: str = None,
    sources: str = None,
    exclude_sources: str = None,
    cwd_prefix: str = None,
    full: bool = False,
    profile: Optional[str] = None,
):
    """List sessions.

    ``archived`` controls how soft-archived sessions are treated:
    ``exclude`` (default) hides them, ``only`` returns just the archived ones
    (used by the desktop "Archived sessions" settings panel), and ``include``
    returns both.

    ``order`` controls pagination order: ``created`` (default, by original
    start time) or ``recent`` (by latest activity across the compression
    chain). ``recent`` keeps a long-running conversation on the first page
    after it auto-compresses into a fresh continuation id.

    Rows omit ``system_prompt``/``model_config`` (the payload-dominating
    fields no list UI reads) unless ``full=1`` is passed.

    ``projection=owned`` opts into the read-only owned-v1 conversation
    projection (see ``_qosha_owned_response``); without it this handler is
    the unchanged native list.
    """
    if "projection" in request.query_params:
        return _qosha_owned_response(request, "list", limit)
    if limit > 100:
        # Same 422 the former ``le=100`` query constraint produced.
        from fastapi.exceptions import RequestValidationError

        raise RequestValidationError([{
            "type": "less_than_equal",
            "loc": ("query", "limit"),
            "msg": "Input should be less than or equal to 100",
            "input": request.query_params.get("limit"),
            "ctx": {"le": 100},
        }])
    if archived not in ("exclude", "only", "include"):
        raise HTTPException(
            status_code=400,
            detail="archived must be one of: exclude, only, include",
        )
    if order not in ("created", "recent"):
        raise HTTPException(
            status_code=400,
            detail="order must be one of: created, recent",
        )
    profile_name: Optional[str] = None
    if profile:
        profile_name, _ = _cron_profile_home(profile)
    try:
        # Auto-archive is the only configured write on this GET path. Run it
        # through a dedicated maintenance connection, close that writer, then
        # open the listing connection read-only.
        _maybe_auto_archive_for_profile(profile)
        db = _open_session_db_for_profile(profile, read_only=True)
        try:
            min_message_count = max(0, min_messages)
            archived_only = archived == "only"
            include_archived = archived == "include"
            # Optional source scoping: ``source`` includes a single class,
            # ``sources`` includes any of several comma-separated classes, and
            # ``exclude_sources`` (comma-separated) drops classes. The desktop
            # uses these to split recents (exclude=cron) from the cron-jobs
            # section (source=cron) into two independent lists.
            source_list = [s.strip() for s in (sources or "").split(",") if s.strip()]
            exclude_list = [s.strip() for s in (exclude_sources or "").split(",") if s.strip()]
            sessions = db.list_sessions_rich(
                source=source or None,
                sources=source_list or None,
                exclude_sources=exclude_list or None,
                cwd_prefix=(cwd_prefix or None),
                limit=limit,
                offset=offset,
                min_message_count=min_message_count,
                include_archived=include_archived,
                archived_only=archived_only,
                order_by_last_active=order == "recent",
                # SQL-level projection: when the caller didn't ask for full
                # rows, skip the system_prompt blob inside SQLite too (pairs
                # with the API-level _strip_session_list_rows below).
                compact_rows=not full,
                include_pinned=True,
            )
            total = db.session_count(
                source=source or None,
                sources=source_list or None,
                cwd_prefix=(cwd_prefix or None),
                exclude_sources=exclude_list or None,
                min_message_count=min_message_count,
                include_archived=include_archived,
                archived_only=archived_only,
                exclude_children=True,
            )
            now = time.time()
            # Same ownership contract as get_session_detail: rows are stamped
            # with the serving profile even when the request wasn't explicitly
            # scoped, so default-profile rows never circulate unowned.
            row_profile = profile_name or _cron_default_profile()
            for s in sessions:
                s["is_active"] = (
                    s.get("ended_at") is None
                    and (now - s.get("last_active", s.get("started_at", 0))) < 300
                )
                s["profile"] = row_profile
                s["is_default_profile"] = row_profile == "default"
                # SQLite stores the flag as 0/1; expose a real JSON boolean.
                s["archived"] = bool(s.get("archived"))
                s["pinned"] = bool(s.get("pinned"))
            if not full:
                _strip_session_list_rows(sessions)
            return {"sessions": sessions, "total": total, "limit": limit, "offset": offset}
        finally:
            db.close()
    except HTTPException:
        raise
    except Exception:
        _log.exception("GET /api/sessions failed")
        raise HTTPException(status_code=500, detail="Internal server error")


@search_router.get("/api/sessions/search")
async def search_sessions(
    request: Request,
    q: str = "",
    limit: int = 20,
    profile: Optional[str] = None,
    source: str = None,
    sources: str = None,
    exclude_sources: str = None,
):
    """Search sessions by ID plus full-text message content using FTS5.

    Direct session-id matches are surfaced first, then FTS message-content
    matches. Results are deduped by compression lineage, not by raw
    ``session_id``. Auto-compression rotates a conversation onto a fresh
    session id (and leaves the old segment's messages in the FTS index), so one
    logical chat can own many ``sessions`` rows that all match the same query.
    Branches also use ``parent_session_id``, but they are real alternate
    conversations; don't collapse branch-specific hits back into the parent.

    ``mode=literal`` opts into the read-only owned-v1 literal search over
    owned conversations (see ``_qosha_owned_response``); without it this
    handler is the unchanged native search.
    """
    if "mode" in request.query_params:
        if limit < 0:
            # Negative typed integers stay framework 422s in the new mode.
            from fastapi.exceptions import RequestValidationError

            raise RequestValidationError([{
                "type": "greater_than_equal",
                "loc": ("query", "limit"),
                "msg": "Input should be greater than or equal to 0",
                "input": request.query_params.get("limit"),
                "ctx": {"ge": 0},
            }])
        return _qosha_owned_response(request, "search", limit)
    if not q or not q.strip():
        return {"results": []}
    try:
        db = _open_session_db_for_profile(profile, read_only=True)
        try:
            safe_limit = max(1, min(int(limit or 20), 100))
            source_filter = source or None
            source_list = [s.strip() for s in (sources or "").split(",") if s.strip()]
            include_sources = [source_filter] if source_filter else (source_list or None)
            exclude_list = [s.strip() for s in (exclude_sources or "").split(",") if s.strip()]
            now = time.time()

            # Walk parent_session_id to the compression root, memoized so a
            # chain of compression segments only costs one walk. We deliberately
            # stop at branch/delegate edges: those sessions may diverge from the
            # parent and should remain searchable on their own.
            root_cache: dict = {}

            def compression_root(session_id: str) -> str:
                if not session_id:
                    return session_id
                if session_id in root_cache:
                    return root_cache[session_id]
                chain = []
                cur = session_id
                visited = set()
                root = session_id
                while cur and cur not in visited:
                    visited.add(cur)
                    chain.append(cur)
                    if cur in root_cache:
                        root = root_cache[cur]
                        break
                    try:
                        s = db.get_session(cur)
                    except Exception:
                        s = None
                    if not s:
                        root = cur
                        break
                    parent = s.get("parent_session_id") if isinstance(s, dict) else None
                    if not parent:
                        root = cur
                        break
                    try:
                        parent_session = db.get_session(parent)
                    except Exception:
                        parent_session = None
                    if not parent_session:
                        root = cur
                        break
                    parent_ended_at = parent_session.get("ended_at")
                    started_at = s.get("started_at")
                    is_compression_edge = (
                        parent_session.get("end_reason") == "compression"
                        and parent_ended_at is not None
                        and started_at is not None
                        and started_at >= parent_ended_at
                    )
                    if not is_compression_edge:
                        root = cur
                        break
                    cur = parent
                for node in chain:
                    root_cache[node] = root
                return root

            tip_cache: dict = {}

            def lineage_tip(root_id: str) -> str:
                if root_id in tip_cache:
                    return tip_cache[root_id]
                tip = root_id
                try:
                    resolved = db.get_compression_tip(root_id)
                    if resolved:
                        tip = resolved
                except Exception:
                    pass
                tip_cache[root_id] = tip
                return tip

            # Both ID matches and content matches share one keyspace, keyed by
            # compression lineage root, so an id-hit and a content-hit on the
            # same logical conversation collapse to a single result. The first
            # hit for a lineage wins; ID matches run first and take priority.
            seen: dict = {}

            def add_lineage_result(raw_sid: str, payload: dict) -> None:
                if not raw_sid:
                    return
                root = compression_root(raw_sid)
                if root in seen or len(seen) >= safe_limit:
                    return
                payload = dict(payload)
                sid = lineage_tip(root)
                payload["session_id"] = sid
                payload["lineage_root"] = root
                try:
                    row = db.get_session_rich_row(sid)
                except Exception:
                    row = None
                if row:
                    payload.update(
                        {
                            "id": row.get("id") or sid,
                            "source": row.get("source"),
                            "model": row.get("model"),
                            "title": row.get("title"),
                            "started_at": row.get("started_at"),
                            "ended_at": row.get("ended_at"),
                            "last_active": row.get("last_active") or row.get("started_at"),
                            "is_active": (
                                row.get("ended_at") is None
                                and (now - (row.get("last_active") or row.get("started_at") or 0)) < 300
                            ),
                            "message_count": row.get("message_count") or 0,
                            "tool_call_count": row.get("tool_call_count") or 0,
                            "input_tokens": row.get("input_tokens") or 0,
                            "output_tokens": row.get("output_tokens") or 0,
                            "preview": row.get("preview"),
                            "parent_session_id": row.get("parent_session_id"),
                            "archived": bool(row.get("archived")),
                        }
                    )
                else:
                    payload["id"] = sid
                seen[root] = payload

            # Direct ID matches first: users often paste a session id from CLI,
            # logs, or another Hermes surface. FTS can't find those unless the
            # id happens to appear in message text. search_sessions_by_id is
            # SQL-bounded, so this stays cheap even with thousands of sessions.
            for row in db.search_sessions_by_id(
                q,
                limit=safe_limit,
                include_archived=True,
                source=source_filter,
                sources=source_list or None,
                exclude_sources=exclude_list or None,
            ):
                sid = row.get("id")
                preview = (row.get("preview") or "").strip()
                snippet = preview or f"Session ID: {sid}"
                add_lineage_result(
                    sid,
                    {
                        "snippet": snippet,
                        "role": None,
                        "source": row.get("source"),
                        "model": row.get("model"),
                        "session_started": row.get("started_at"),
                    },
                )

            # Auto-add prefix wildcards so partial words match
            # e.g. "nimb" → "nimb*" matches "nimby"
            # Preserve quoted phrases and existing wildcards as-is
            import re
            terms = []
            for token in re.findall(r'"[^"]*"|\S+', q.strip()):
                if token.startswith('"') or token.endswith("*"):
                    terms.append(token)
                else:
                    terms.append(token + "*")
            prefix_query = " ".join(terms)
            # Over-fetch so lineage dedup can still surface `limit` distinct
            # conversations even when several hits collapse onto one root.
            fetch_limit = max(safe_limit * 5, 50)
            matches = db.search_messages(
                query=prefix_query,
                source_filter=include_sources,
                exclude_sources=exclude_list or None,
                limit=fetch_limit,
                fields=(
                    "session_id",
                    "role",
                    "snippet",
                    "source",
                    "model",
                    "session_started",
                ),
            )

            for m in matches:
                if len(seen) >= safe_limit:
                    break
                add_lineage_result(
                    m["session_id"],
                    {
                        "snippet": m.get("snippet", ""),
                        "role": m.get("role"),
                        "source": m.get("source"),
                        "model": m.get("model"),
                        "session_started": m.get("session_started"),
                    },
                )
            return {"results": list(seen.values())}
        finally:
            db.close()
    except HTTPException:
        raise
    except Exception:
        _log.exception("GET /api/sessions/search failed")
        raise HTTPException(status_code=500, detail="Search failed")


@manage_router.post("/api/sessions/bulk-delete")
async def bulk_delete_sessions_endpoint(body: BulkDeleteSessions):
    """Delete every session in ``body.ids`` in a single DB transaction.

    Backs the dashboard's bulk-select-and-delete flow on the sessions
    page. POST (not DELETE) because most HTTP clients refuse to send a
    request body on DELETE and a body is the natural shape for a list
    of IDs — Starlette accepts both, but POSTing a list keeps proxies,
    curl, and the browser ``fetch`` API consistent.

    Per-row contract matches :meth:`SessionDB.delete_sessions`:

    * Unknown IDs are silently skipped (the response ``deleted`` count
      reflects what really happened, not the input length). This is
      deliberate — UI selection state can race against another tab's
      delete, and we'd rather succeed-on-the-rest than fail-the-whole-
      batch.
    * Children of every deleted parent are orphaned, not cascade-
      deleted.
    * Active and archived sessions ARE deleted when explicitly
      selected — unlike ``DELETE /api/sessions/empty``, the user
      hand-picked the rows so we trust the selection.
    * Like the other session-delete endpoints, this does NOT pass a
      ``sessions_dir`` through; on-disk transcript / request-dump
      cleanup runs at the CLI/agent layer on the next prune pass.

    The response carries the actual deleted count, so the dashboard
    can surface it in a toast. The IDs that were removed are not
    echoed back because the client already knows what it asked to
    delete (unknown IDs are silently skipped — see contract above)
    and can prune its in-memory list directly from the request.
    """
    # Enforce a hard cap so a runaway/typo'd selection can't lock the
    # DB writer for an extended window. The dashboard pages 20 rows
    # at a time; 500 covers a "select all on every page in a
    # reasonable scrollback" worst case without opening the door to
    # multi-thousand-row transactions.
    if len(body.ids) > 500:
        raise HTTPException(
            status_code=400,
            detail="ids must contain at most 500 entries",
        )
    def _delete() -> int:
        db = _open_session_db_for_profile(body.profile, read_only=False)
        try:
            return db.delete_sessions(body.ids)
        finally:
            db.close()

    deleted = await asyncio.to_thread(_delete)
    return {"ok": True, "deleted": deleted}


@manage_router.post("/api/sessions/import")
async def import_sessions_endpoint(request: Request):
    """Import one or more sessions exported from the dashboard or CLI.

    This is intentionally separate from ``/api/ops/import``: that endpoint
    restores a whole Hermes backup archive, while this endpoint is scoped to
    session rows/messages and is safe to use from the Sessions page.
    """
    try:
        raw_body = await _read_session_import_body(request)
        body = SessionImport.model_validate_json(raw_body)
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid session import payload") from exc

    try:
        result = await asyncio.to_thread(_import_sessions_for_profile, body.profile, body.sessions)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    if not result.get("ok", False):
        raise HTTPException(status_code=400, detail=result)
    return result


@manage_router.get("/api/sessions/empty/count")
async def count_empty_sessions_endpoint(profile: Optional[str] = None):
    """Return the number of empty, ended, non-archived sessions.

    Drives the dashboard's "Delete empty (N)" button — when N is 0 the
    UI hides the affordance so users aren't presented with a button
    that does nothing. Cheap, single-COUNT query.
    """
    def _count() -> int:
        db = _open_session_db_for_profile(profile, read_only=True)
        try:
            return db.count_empty_sessions()
        finally:
            db.close()

    return {"count": await asyncio.to_thread(_count)}


@manage_router.delete("/api/sessions/empty")
async def delete_empty_sessions_endpoint(profile: Optional[str] = None):
    """Delete every empty, ended, non-archived session in a single
    transaction.

    Safety contract mirrors :meth:`SessionDB.delete_empty_sessions`:

    * "Empty" means the session owns no rows in ``messages`` at all — not
      merely ``message_count == 0``. A rewound or in-place-compacted chat
      keeps its dropped turns as soft-archived (``active = 0``) rows while
      the counter reads zero, and those rows are the only recoverable copy
      of the transcript (#95868).
    * Active sessions are skipped (``ended_at IS NULL``) so a live
      agent isn't yanked mid-handshake.
    * Archived sessions are skipped — the user explicitly chose to
      keep those rows.
    * Children of deleted parents are orphaned, not cascade-deleted.

    Like the single-session ``DELETE /api/sessions/{id}`` endpoint
    below, this doesn't pass a ``sessions_dir`` through — the on-disk
    transcript / request-dump cleanup is wired at the CLI/agent layer
    but the web server historically leaves file cleanup to the next
    prune-on-startup pass. Matching that pre-existing trade-off keeps
    the two delete endpoints' DB-vs-disk behaviour consistent.
    """
    def _delete() -> int:
        db = _open_session_db_for_profile(profile, read_only=False)
        try:
            return db.delete_empty_sessions()
        finally:
            db.close()

    deleted = await asyncio.to_thread(_delete)
    return {"ok": True, "deleted": deleted}


@manage_router.get("/api/sessions/stats")
async def get_session_stats(profile: Optional[str] = None):
    """Session-store statistics for the Sessions page (mirrors `hermes sessions stats`).

    Registered before ``/api/sessions/{session_id}`` so the literal ``stats``
    path isn't captured as a session id by the parameterized route.
    """
    db = _open_session_db_for_profile(profile, read_only=True)
    try:
        total = db.session_count(include_archived=True)
        active_store = db.session_count(include_archived=False)
        archived = db.session_count(archived_only=True)
        messages = db.message_count()
        by_source: Dict[str, int] = {}
        try:
            by_source = db.session_count_by_source(
                include_archived=True,
                exclude_children=True,
            )
        except Exception:
            pass
        return {
            "total": total,
            "active_store": active_store,
            "archived": archived,
            "messages": messages,
            "by_source": by_source,
        }
    finally:
        db.close()


@manage_router.get("/api/sessions/{session_id}")
async def get_session_detail(session_id: str, profile: Optional[str] = None):
    db = _open_session_db_for_profile(profile, read_only=True)
    try:
        sid = db.resolve_session_id(session_id)
        session = db.get_session(sid) if sid else None
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        # Always stamp the owning profile — the serving profile is known even
        # when the request carries no ``?profile=`` (it's this process's own
        # profile). Stamping only on explicit ``?profile=`` left rows for the
        # default/primary profile systematically unowned, so multi-profile
        # clients resolved them to whichever gateway happened to be active
        # (cross-profile open asymmetry, #67603 family).
        session["profile"] = (
            _cron_profile_home(profile)[0] if profile else _cron_default_profile()
        )
        session["is_default_profile"] = session["profile"] == "default"
        return session
    finally:
        db.close()


@manage_router.get("/api/sessions/{session_id}/latest-descendant")
async def get_session_latest_descendant(
    session_id: str,
    profile: Optional[str] = None,
):
    def _lookup():
        db = _open_session_db_for_profile(profile, read_only=True)
        try:
            return _session_latest_descendant(session_id, db)
        finally:
            db.close()

    latest, path = await asyncio.to_thread(_lookup)
    if not latest:
        raise HTTPException(status_code=404, detail="Session not found")
    return {
        "requested_session_id": path[0] if path else session_id,
        "session_id": latest,
        "path": path,
        "changed": bool(path and latest != path[0]),
    }


@manage_router.get("/api/sessions/{session_id}/messages")
async def get_session_messages(
    request: Request,
    session_id: str,
    profile: Optional[str] = None,
    limit: Optional[int] = Query(None, ge=0),
    offset: int = Query(0, ge=0),
    order: Optional[str] = Query(None),
    include_compacted: bool = Query(False),
    follow_chain: bool = Query(True),
):
    if "consistency" in request.query_params:
        # Opt-in owned-v1 transcript of one canonical owner (see
        # ``_qosha_owned_response``); every other call is unchanged.
        return _qosha_owned_response(request, "messages", limit, offset, session_id)
    if order not in (None, "oldest", "latest"):
        raise HTTPException(
            status_code=400,
            detail="order must be one of: oldest, latest",
        )

    def _read():
        db = _open_session_db_for_profile(profile, read_only=True)
        try:
            sid = db.resolve_session_id(session_id)
            if not sid:
                return None
            if follow_chain:
                # Default (unchanged): read the session a resume would open,
                # i.e. the newest continuation of this ID.
                sid = db.resolve_resume_session_id(sid)
            elif sid != session_id:
                # Exact-segment mode (opt-in): only a complete existing ID
                # (resolve_session_id returns an exact match first) reads its
                # own stored segment. A prefix must never select a different
                # record, and no continuation is substituted.
                return None
            # Always page this endpoint. An omitted limit used to load an
            # entire transcript, which can be hundreds of thousands of rows
            # for a runaway session and exhaust the dashboard process. Keep
            # explicit pagination anchored at the start, while the default
            # dashboard view returns the latest page in chronological order.
            default_page = limit is None
            latest_page = order == "latest" or (order is None and default_page)
            _limit = 500 if default_page else min(limit, 500)
            return sid, _limit, db.get_messages(
                sid,
                limit=_limit,
                offset=offset,
                latest=latest_page,
                include_compacted=include_compacted,
            )
        finally:
            db.close()

    result = await asyncio.to_thread(_read)
    if result is None:
        raise HTTPException(status_code=404, detail="Session not found")
    sid, _limit, messages = result
    from agent.compaction_display import project_compaction_message_for_display
    from agent.context_compressor import is_compaction_summary_message

    projected_messages = []
    for message in messages:
        if not is_compaction_summary_message(message):
            projected_messages.append(message)
            continue
        display_view = project_compaction_message_for_display(message)
        projected = message.copy()
        if display_view is None:
            if not projected.get("display_kind"):
                projected["display_kind"] = "hidden"
        else:
            # Keep the physical content for inspection/export compatibility;
            # Desktop consumes this display-only projection. A legacy hidden
            # wrapper must not hide a successfully recovered live ask.
            projected["display_content"] = display_view.get("content")
            projected.pop("display_kind", None)
        projected_messages.append(projected)
    return {
        "session_id": sid,
        "messages": projected_messages,
        "pagination": {
            "limit": _limit,
            "offset": offset,
            "order": order or ("latest" if limit is None else "oldest"),
            "returned": len(projected_messages),
        },
    }


@manage_router.delete("/api/sessions/{session_id}")
async def delete_session_endpoint(session_id: str, profile: Optional[str] = None):
    # ``profile`` deletes a session belonging to another (local) profile by
    # opening its state.db directly. Remote profiles never reach here — the
    # desktop routes their DELETE to the remote backend. Omit for current/default.
    def _delete():
        db = _open_session_db_for_profile(profile, read_only=False)
        try:
            # Resolve exact ids / unique prefixes like every other session endpoint
            # (detail, messages, rename, export all do). A session that no longer
            # exists is an idempotent success: DELETE's contract is "ensure it's
            # gone", and the desktop optimistically removes the row then RESTORES it
            # on any error — so a 404 on an already-absent row resurrected a ghost
            # row and surfaced "session not found". /goal + auto-compression churn
            # leaves transient empty rows (reaped by empty-session hygiene) that
            # race the sidebar snapshot, which is exactly when this fired. Mirrors
            # the bulk-delete endpoint, which already treats ghost ids as success.
            sid = db.resolve_session_id(session_id)
            if not sid:
                return {"ok": True, "already_absent": True}
            db.delete_session(sid)
            return {"ok": True}
        finally:
            db.close()

    return await asyncio.to_thread(_delete)


@manage_router.post("/api/sessions/owner-backfill")
async def backfill_session_owner_profiles(body: SessionOwnerBackfill):
    """Stamp legacy ``profile_name = NULL`` session rows with this store's own
    serving-profile identity (#94724 legacy-session migration).

    Pre-#95407 rows never recorded an owning profile. That was fine while one
    backend served everything, but a Desktop with registry topology (≥2
    registered connections) fails closed on unowned rows by design — leaving
    every pre-campaign session unresumable with no migration path. Each
    profile's ``state.db`` belongs to exactly one profile, so stamping that
    store's own name is a single-match backfill, never a guess; the value
    written is the SAME serving-profile identity the list endpoints already
    stamp onto outgoing rows (``row_profile`` in ``get_sessions``). Idempotent
    and one-shot-per-row: non-NULL owners are never overwritten and a second
    call reports 0.
    """
    profile_name: Optional[str] = None
    if body.profile:
        profile_name, _ = _cron_profile_home(body.profile)
    stamp = profile_name or _cron_default_profile()

    def _backfill():
        db = _open_session_db_for_profile(body.profile, read_only=False)
        try:
            return db.backfill_null_session_profiles(stamp)
        finally:
            db.close()

    try:
        stamped = await asyncio.to_thread(_backfill)
    except HTTPException:
        raise
    except Exception:
        _log.exception("POST /api/sessions/owner-backfill failed")
        raise HTTPException(status_code=500, detail="Internal server error")

    if stamped:
        _log.info(
            "owner-backfill: stamped %d legacy NULL-profile session row(s) with profile %r",
            stamped,
            stamp,
        )
    return {"ok": True, "stamped": stamped, "profile": stamp}


@manage_router.patch("/api/sessions/{session_id}")
async def rename_session_endpoint(session_id: str, body: SessionRename):
    """Update a session: rename, archive, hide, pin, and/or mark read/unread.

    ``title`` renames (empty/null clears the title); ``archived`` soft-hides or
    restores the session; ``hidden`` controls generic list visibility;
    ``pinned`` sets the durable keep flag (exempts the
    session from the auto-archive sweep); ``unread`` toggles the read-state
    watermark (True = explicitly unread, False = read up to now — see
    ``SessionDB.set_session_read``). Any field may be omitted. ``profile``
    targets another profile's session.
    """
    db = _open_session_db_for_profile(body.profile, read_only=False)
    try:
        sid = db.resolve_session_id(session_id)
        if not sid:
            raise HTTPException(status_code=404, detail="Session not found")
        if (
            body.title is None
            and body.archived is None
            and body.hidden is None
            and body.pinned is None
            and body.unread is None
        ):
            raise HTTPException(
                status_code=400,
                detail="Nothing to update; provide 'title', 'archived', 'hidden', 'pinned', and/or 'unread'.",
            )
        if body.title is not None:
            try:
                db.set_session_title(sid, body.title or "")
            except ValueError as e:
                # Title too long, invalid characters, or already in use.
                raise HTTPException(status_code=400, detail=str(e))
        if body.archived is not None:
            db.set_session_archived(sid, body.archived)
        if body.hidden is not None:
            db.set_session_hidden(sid, body.hidden)
        if body.pinned is not None:
            db.set_session_pinned(sid, body.pinned)
        if body.unread is not None:
            db.set_session_read(sid, read=not body.unread)
        result = {"ok": True, "title": db.get_session_title(sid) or ""}
        if body.archived is not None:
            result["archived"] = bool(body.archived)
        if body.hidden is not None:
            result["hidden"] = bool(body.hidden)
        if body.pinned is not None:
            result["pinned"] = bool(body.pinned)
        if body.unread is not None:
            result["unread"] = bool(body.unread)
        return result
    finally:
        db.close()


@manage_router.get("/api/sessions/{session_id}/export")
async def export_session_endpoint(session_id: str, profile: Optional[str] = None):
    """Stream a single session (metadata + messages) as JSON."""
    def _prepare_export():
        db = _open_session_db_for_profile(profile, read_only=True)
        try:
            sid = db.resolve_session_id(session_id)
            return (sid, db.get_session(sid)) if sid else None
        finally:
            db.close()

    prepared = await asyncio.to_thread(_prepare_export)
    if prepared is None or prepared[1] is None:
        raise HTTPException(status_code=404, detail="Session not found")

    sid, session = prepared

    def _stream_export():
        db = _open_session_db_for_profile(profile, read_only=True)
        try:
            metadata = json.dumps(
                jsonable_encoder(session),
                ensure_ascii=False,
                separators=(",", ":"),
            )
            yield metadata[:-1] + ',"messages":['

            # Keyset pagination (id > last_seen): O(n) total over the
            # transcript, vs OFFSET's O(n²) on huge sessions.
            last_id = None
            first = True
            while True:
                messages = db.get_messages(
                    sid,
                    limit=500,
                    after_id=last_id if last_id is not None else 0,
                )
                for message in messages:
                    if not first:
                        yield ","
                    yield json.dumps(
                        jsonable_encoder(message),
                        ensure_ascii=False,
                        separators=(",", ":"),
                    )
                    first = False
                if len(messages) < 500:
                    break
                last_id = messages[-1].get("id")
                if last_id is None:
                    break  # defensive: cannot keyset without row ids

            yield "]}"
        finally:
            db.close()

    return StreamingResponse(
        _stream_export(),
        media_type="application/json",
    )


@manage_router.post("/api/sessions/prune")
async def prune_sessions_endpoint(body: SessionPrune):
    """Delete ended sessions matching filters without blocking the event loop."""
    return await asyncio.to_thread(_prune_sessions, body)


# ---------------------------------------------------------------------------
# Qosha owned-v1 projection. Opt-in only: ``projection=owned`` on the list,
# ``mode=literal`` on search and ``consistency=owned-v1`` on messages. Calls
# without those keys never reach these helpers.
#
# Each request owns one worker thread, which opens ONE read-only connection to
# this process's default store, takes ONE explicit read snapshot
# (BEGIN ... ROLLBACK) and derives conversation owners, their native display
# history, owner revisions, the result fingerprint and the requested page from
# that snapshot alone. There is no cache, index, writer or second backend, and
# nothing persists between requests. Raw model_config and session_key values
# never leave SQLite: only marker presence, key equality and JSON validity do.
# ---------------------------------------------------------------------------


def _qosha_owned_digest(value):
    """SHA-256 of deterministic canonical JSON (sorted keys, no whitespace)."""
    text = json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, default=repr)
    return hashlib.sha256(text.encode("utf-8", "surrogatepass")).hexdigest()


def _qosha_owned_check(state):
    """Cooperative stop point: request cancellation/disconnect or the deadline."""
    if state["stop"].is_set() or time.monotonic() >= state["deadline"]:
        raise TimeoutError("owned-v1 read stopped")


def _qosha_owned_cursor(token=None, **fields):
    """Encode ``fields`` as a cursor, or decode and validate ``token``.

    A cursor is unpadded base64url UTF-8 JSON with exactly ``v``, ``kind``,
    ``offset``, ``limit`` and ``fingerprint``. Decoding returns the field dict,
    or None for any structural defect (HTTP 400). Kind/limit context and the
    fingerprint are compared later, against the current snapshot.
    """
    if token is None:
        raw = json.dumps({"v": 1, "kind": fields["kind"], "offset": fields["offset"],
                          "limit": fields["limit"], "fingerprint": fields["fingerprint"]},
                         separators=(",", ":"))
        return base64.urlsafe_b64encode(raw.encode("ascii")).decode("ascii").rstrip("=")
    import re

    if (not token or re.fullmatch(r"[A-Za-z0-9_-]+", token) is None
            or len(token) > 2048 or len(token) % 4 == 1):
        return None
    try:
        text = base64.urlsafe_b64decode(token + "=" * (-len(token) % 4)).decode("utf-8")
    except (ValueError, UnicodeDecodeError):
        return None

    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate cursor key")
            result[key] = value
        return result

    def constant(name):
        raise ValueError("non-finite cursor number")

    try:
        value = json.loads(text, object_pairs_hook=unique, parse_constant=constant)
    except (ValueError, RecursionError):
        return None
    if not isinstance(value, dict) or set(value) != {"v", "kind", "offset", "limit", "fingerprint"}:
        return None
    fingerprint = value["fingerprint"]
    if (type(value["v"]) is not int or value["v"] != 1
            or not isinstance(value["kind"], str) or value["kind"] not in ("list", "search")
            or type(value["offset"]) is not int or value["offset"] < 1
            or type(value["limit"]) is not int or not 1 <= value["limit"] <= 100
            or not isinstance(fingerprint, str)
            or re.fullmatch(r"[0-9a-f]{64}", fingerprint) is None):
        return None
    return value


def _qosha_owned_query(request, kind, limit, offset=0, session_id=None):
    """Validate an owned-v1 request before any store access.

    Returns ``(params, None)`` or ``(None, failure)``. A profile is never
    accepted: every owned-v1 read uses this process's own default store.
    ``limit``/``offset`` arrive already parsed by the native query typing
    (malformed or negative values are framework 422s before this point).
    """
    import re

    allowed = {
        "list": ("projection", "limit", "archived", "order", "cursor"),
        "search": ("mode", "q", "limit", "archived", "order", "cursor"),
        "messages": ("follow_chain", "consistency", "owner_id", "owner_revision",
                     "include_compacted", "order", "limit", "offset"),
    }[kind]

    def invalid(message):
        return None, {"status": 400, "code": "invalid_request", "message": message}

    values = {}
    for key, value in request.query_params.multi_items():
        if key in values:
            return invalid("Duplicate query parameters are not accepted.")
        values[key] = value
    if "profile" in values:
        return invalid("The profile parameter is not accepted by owned-v1 reads.")
    for key in values:
        if key not in allowed:
            return invalid("Unknown query parameter for an owned-v1 read.")
    if kind == "messages":
        for key in allowed[:-1]:
            if key not in values:
                return invalid("A required owned-v1 transcript parameter is missing.")
        if values["consistency"] != "owned-v1":
            return invalid("Unsupported consistency version.")
        if values["follow_chain"] != "false" or values["include_compacted"] != "true":
            return invalid("Owned-v1 transcripts require follow_chain=false and include_compacted=true.")
        if values["owner_id"] != session_id:
            return invalid("owner_id must equal the requested session ID.")
        if re.fullmatch(r"[0-9a-f]{64}", values["owner_revision"]) is None:
            return invalid("owner_revision must be 64 lowercase hexadecimal characters.")
        if values["order"] not in ("oldest", "latest"):
            return invalid("order must be oldest or latest.")
        if limit is None or not 1 <= limit <= 500:
            return invalid("limit must be an integer from 1 to 500.")
        return {"session_id": session_id, "revision": values["owner_revision"],
                "order": values["order"], "limit": limit, "offset": offset}, None
    if kind == "list" and values["projection"] != "owned":
        return invalid("Unsupported projection version.")
    if kind == "search" and values["mode"] != "literal":
        return invalid("Unsupported search mode.")
    if not 1 <= limit <= 100:
        return invalid("limit must be an integer from 1 to 100.")
    archived = values.get("archived", "exclude")
    if archived not in ("exclude", "only", "include"):
        return invalid("archived must be exclude, only or include.")
    if values.get("order", "recent") != "recent":
        return invalid("order must be recent.")
    cursor = None
    if "cursor" in values:
        cursor = _qosha_owned_cursor(values["cursor"])
        if cursor is None:
            return invalid("The cursor is not a valid owned-v1 cursor.")
    return {"q": values.get("q", "") if kind == "search" else None, "limit": limit,
            "archived": archived, "cursor": cursor}, None


def _qosha_owned_facts(conn, state, what, ids=None):
    """Fixed parameterized reads inside the caller's snapshot.

    ``what="messages"`` returns native display-history rows (``active = 1 OR
    compacted = 1``, i.e. ``get_messages(include_compacted=True)``), optionally
    restricted to ``ids``, ordered by session then insertion id.
    ``what="sessions"`` returns every stored session's admission facts keyed by
    full ID.
    """
    _qosha_owned_check(state)
    if what == "messages":
        sql = "SELECT * FROM messages WHERE (active = 1 OR compacted = 1)"
        if ids is None:
            return conn.execute(sql + " ORDER BY session_id, id").fetchall()
        ordered = sorted(set(ids))
        rows = []
        for start in range(0, len(ordered), 900):  # SQLite's bound-variable ceiling.
            _qosha_owned_check(state)
            chunk = ordered[start:start + 900]
            rows.extend(conn.execute(
                sql + " AND session_id IN (" + ",".join("?" * len(chunk)) + ")"
                " ORDER BY session_id, id",
                chunk,
            ).fetchall())
        return rows
    config = "COALESCE(s.model_config, '{}')"

    def marker(name):
        # JSON null is an absent marker; unparseable configs yield NULL here
        # and are reported through config_valid instead of raising.
        return ("CASE WHEN json_valid(" + config + ") THEN json_extract("
                + config + ", '$." + name + "') IS NOT NULL END")

    sql = (
        "SELECT s.id AS id, s.parent_session_id AS parent_id,"
        " COALESCE(s.source, '') AS source, COALESCE(s.hidden, 0) AS hidden,"
        " s.end_reason AS end_reason, s.ended_at AS ended_at,"
        " s.started_at AS started_at, s.title AS title,"
        " COALESCE(s.pinned, 0) AS pinned, COALESCE(s.archived, 0) AS archived,"
        " " + _sql_session_last_active("s") + " AS last_active,"
        " json_valid(" + config + ") AS config_valid,"
        " " + marker("_branched_from") + " AS has_branch,"
        " " + marker("_reset_from") + " AS has_reset,"
        " " + marker("_delegate_from") + " AS has_delegate,"
        " CASE WHEN COALESCE(s.session_key, '') != '' AND s.session_key = p.session_key"
        " THEN 1 ELSE 0 END AS same_key"
        " FROM sessions s LEFT JOIN sessions p ON p.id = s.parent_session_id"
        " ORDER BY s.id"
    )
    facts = {}
    for row in conn.execute(sql).fetchall():
        _qosha_owned_check(state)
        facts[row["id"]] = row
    return facts


def _qosha_owned_projection(facts, state):
    """Classify every stored session: owned chain, excluded family or damage.

    Top-down from roots. A root is a parentless, non-hidden session with a
    parseable config and no delegate marker. For each owned segment, children
    are classified as: unparseable config -> damage; delegate marker or
    internal tool source -> excluded family; branch/reset marker, legacy
    branch (parent ended ``branched`` no later than the child started) or
    legacy reset (one of the native reset end reasons with an equal non-empty
    session key) -> a separate owner seed (excluded when hidden); otherwise,
    under a ``compression`` parent, a continuation candidate; otherwise an
    excluded orphan. Among candidates the native ``get_compression_tip``
    preference wins (compression-ended, then live, then newest activity, start
    and ID); losing siblings and their descendants are stale and excluded.
    Rows never reached from a root (cycles, missing parents) are damage unless
    independently excluded (hidden, delegate marker, internal tool source).

    Returns ``(owners, damage)``: owners maps each canonical tip ID to its
    oldest-to-tip segment list; damage is the set of unclassifiable IDs.
    """
    reset_reasons = ("session_reset", "session_switch", "idle", "daily",
                     "suspended", "resume_pending_expired")
    children = {}
    for sid in facts:
        _qosha_owned_check(state)
        parent = facts[sid]["parent_id"]
        if parent is not None:
            children.setdefault(parent, []).append(sid)
    status = {}

    def exclude(start):
        stack = [start]
        while stack:
            _qosha_owned_check(state)
            sid = stack.pop()
            if sid in status:
                continue
            status[sid] = "excluded"
            stack.extend(children.get(sid, ()))

    queue = []
    for sid in sorted(facts):
        _qosha_owned_check(state)
        row = facts[sid]
        if row["parent_id"] is not None:
            continue
        if row["hidden"]:
            exclude(sid)
        elif not row["config_valid"]:
            status[sid] = "damage"
        elif row["has_delegate"]:
            exclude(sid)
        else:
            status[sid] = "seed"
            queue.append(sid)

    def preference(sid):
        row = facts[sid]
        return ((row["last_active"] is not None, row["last_active"] or 0),
                (row["started_at"] is not None, row["started_at"] or 0), sid)

    def rank(sid):
        row = facts[sid]
        if row["end_reason"] == "compression":
            return 0
        return 1 if row["ended_at"] is None else 2

    owners = {}
    index = 0
    while index < len(queue):
        _qosha_owned_check(state)
        chain = [queue[index]]
        index += 1
        status[chain[0]] = "owned"
        while True:
            _qosha_owned_check(state)
            parent = facts[chain[-1]]
            candidates = []
            for child in sorted(children.get(chain[-1], ())):
                _qosha_owned_check(state)
                if child in status:
                    continue
                row = facts[child]
                if not row["config_valid"]:
                    status[child] = "damage"
                    continue
                if row["has_delegate"] or row["source"] == "tool":
                    exclude(child)
                    continue
                legacy_branch = (parent["end_reason"] == "branched"
                                 and parent["ended_at"] is not None
                                 and row["started_at"] is not None
                                 and row["started_at"] >= parent["ended_at"])
                legacy_reset = parent["end_reason"] in reset_reasons and bool(row["same_key"])
                if row["has_branch"] or row["has_reset"] or legacy_branch or legacy_reset:
                    if row["hidden"]:
                        exclude(child)
                    else:
                        status[child] = "seed"
                        queue.append(child)
                elif parent["end_reason"] == "compression":
                    candidates.append(child)
                else:
                    exclude(child)
            if not candidates:
                break
            candidates.sort(key=preference, reverse=True)
            candidates.sort(key=rank)
            for loser in candidates[1:]:
                exclude(loser)
            status[candidates[0]] = "owned"
            chain.append(candidates[0])
        owners[chain[-1]] = chain
    pending = []
    for sid in sorted(facts):
        _qosha_owned_check(state)
        if sid not in status:
            pending.append(sid)
    for sid in pending:
        _qosha_owned_check(state)
        row = facts[sid]
        if sid not in status and (row["hidden"] or row["source"] == "tool"
                                  or (row["config_valid"] and row["has_delegate"])):
            exclude(sid)
    damage = set()
    for sid in facts:
        _qosha_owned_check(state)
        if status.get(sid, "damage") == "damage":
            damage.add(sid)
    return owners, damage


def _qosha_owned_display(db, rows, state):
    """Native display history for one segment from rows already read.

    Mirrors ``SessionDB.get_messages(include_compacted=True)`` (compaction
    epoch dedupe preferring the live row then the newest generation, then
    decoding) and the messages route's compaction display projection.
    ``db`` is the ``SessionDB`` class: only its static/class decoders are used.
    Returns ``(projected_rows, visible_texts)``; hidden rows are kept in
    ``projected_rows`` but contribute no visible text.
    """
    from agent.compaction_display import project_compaction_message_for_display
    from agent.context_compressor import (
        is_compaction_summary_message,
        split_user_originated_turn,
    )

    seen = {}
    for row in rows:
        _qosha_owned_check(state)
        dedupe_content = row["content"]
        if row["role"] == "user":
            candidate = {
                "role": "user",
                "content": db._decode_content(row["content"]),
                "display_kind": row["display_kind"],
                "display_metadata": db._decode_display_metadata(row["display_metadata"]),
            }
            handoff, live_view = split_user_originated_turn(candidate)
            if handoff is not None and live_view is not None:
                dedupe_content = db._encode_content(live_view.get("content"))
        key = (row["role"], dedupe_content, row["timestamp"], row["tool_call_id"],
               row["tool_calls"], row["tool_name"])
        current = seen.get(key)
        if current is None or (row["active"], row["id"]) > (current["active"], current["id"]):
            seen[key] = row
    projected, texts = [], []
    for row in sorted(seen.values(), key=lambda item: item["id"]):
        _qosha_owned_check(state)
        msg = dict(row)
        if msg.pop("_compressed_summary", 0):
            msg["_compressed_summary"] = True
        if "content" in msg:
            msg["content"] = db._decode_content(msg["content"])
        if msg.get("tool_calls"):
            try:
                msg["tool_calls"] = json.loads(msg["tool_calls"])
            except (json.JSONDecodeError, TypeError):
                msg["tool_calls"] = []
        if msg.get("display_metadata") is not None:
            msg["display_metadata"] = db._decode_display_metadata(msg["display_metadata"])
        if is_compaction_summary_message(msg):
            view = project_compaction_message_for_display(msg)
            msg = msg.copy()
            if view is None:
                if not msg.get("display_kind"):
                    msg["display_kind"] = "hidden"
            else:
                msg["display_content"] = view.get("content")
                msg.pop("display_kind", None)
        projected.append(msg)
        if msg.get("display_kind") == "hidden":
            continue
        visible = msg["display_content"] if "display_content" in msg else msg.get("content")
        if isinstance(visible, str):
            texts.append(visible)
        elif isinstance(visible, list):
            for part in visible:
                if isinstance(part, dict) and isinstance(part.get("text"), str):
                    texts.append(part["text"])
    return projected, texts


def _qosha_owned_revision(scope, chain, facts, history):
    """Owner ROW (canonical tip metadata, separate seed identity) + revision.

    The revision binds version, store scope, seed/tip/ordered segments, the
    display metadata and the full projected display history of every owned
    segment. It never includes raw configs, session keys or wall-clock time.
    """
    tip, seed = facts[chain[-1]], facts[chain[0]]
    row = {"id": chain[-1], "owner_id": chain[-1], "seed_id": chain[0],
           "segment_ids": list(chain), "title": tip["title"],
           "pinned": bool(tip["pinned"]), "archived": bool(tip["archived"]),
           "started_at": tip["started_at"], "last_active": tip["last_active"],
           "seed_started_at": seed["started_at"]}
    segments = []
    for sid in chain:
        segments.append([sid, history.get(sid, [])])
    row["owner_revision"] = _qosha_owned_digest(
        {"protocol": "owned-v1", "scope": scope, "owner": dict(row), "history": segments})
    return row


def _qosha_owned_page(db, conn, kind, params, scope, state):
    """List/search: complete owned projection, match, order, fingerprint, page."""
    message_rows = _qosha_owned_facts(conn, state, "messages")
    facts = _qosha_owned_facts(conn, state, "sessions")
    # Every read of this request has completed; only Python work follows.
    owners, damage = _qosha_owned_projection(facts, state)
    if damage:
        return {"status": 503, "code": "incomplete_history"}
    owned = set()
    for chain in owners.values():
        for sid in chain:
            _qosha_owned_check(state)
            owned.add(sid)
    grouped = {}
    for row in message_rows:
        _qosha_owned_check(state)
        if row["session_id"] in owned:
            grouped.setdefault(row["session_id"], []).append(row)
    history, texts = {}, {}
    for sid in sorted(grouped):
        _qosha_owned_check(state)
        history[sid], texts[sid] = _qosha_owned_display(db, grouped[sid], state)
    q, archived, limit = params["q"], params["archived"], params["limit"]
    # Exact literal: no trimming of a nonempty query; whitespace-only is empty.
    needle = q.casefold() if kind == "search" and q.strip() else None
    matched = []
    for tip in sorted(owners):
        _qosha_owned_check(state)
        chain = owners[tip]
        flag = bool(facts[tip]["archived"])
        if (archived == "exclude" and flag) or (archived == "only" and not flag):
            continue
        if kind == "search":
            if needle is None:
                continue
            title = facts[tip]["title"]
            hit = needle in tip.casefold() or (isinstance(title, str) and needle in title.casefold())
            for sid in chain:
                if hit:
                    break
                for text in texts.get(sid, ()):
                    _qosha_owned_check(state)
                    if needle in text.casefold():
                        hit = True
                        break
            if not hit:
                continue
        matched.append(_qosha_owned_revision(scope, chain, facts, history))

    def order(row):
        return (row["pinned"],
                (row["last_active"] is not None, row["last_active"] or 0),
                (row["started_at"] is not None, row["started_at"] or 0),
                row["id"])

    matched.sort(key=order, reverse=True)
    fingerprint = _qosha_owned_digest({
        "protocol": "owned-v1", "scope": scope, "kind": kind, "q": q,
        "archived": archived, "order": "recent", "limit": limit,
        "complete": True, "rows": matched})
    total = len(matched)
    offset = 0
    cursor = params["cursor"]
    if cursor is not None:
        if cursor["kind"] != kind or cursor["limit"] != limit or cursor["fingerprint"] != fingerprint:
            return {"status": 409, "code": "projection_changed"}
        if cursor["offset"] > total:
            return {"status": 400, "code": "invalid_request",
                    "message": "The cursor offset is beyond the current result."}
        offset = cursor["offset"]
    page = matched[offset:offset + limit]
    end = offset + len(page)
    next_cursor = None
    if end < total:
        next_cursor = _qosha_owned_cursor(kind=kind, offset=end, limit=limit, fingerprint=fingerprint)
    return {"status": 200, "body": {
        "protocol": "owned-v1", "complete": True,
        "sessions" if kind == "list" else "results": page,
        "total": total, "limit": limit, "offset": offset,
        "fingerprint": fingerprint, "next_cursor": next_cursor}}


def _qosha_owned_messages(db, conn, params, scope, state):
    """One canonical owner's current-segment page, bound to its revision."""
    sid = params["session_id"]
    rows = list(_qosha_owned_facts(conn, state, "messages", [sid]))
    facts = _qosha_owned_facts(conn, state, "sessions")
    if sid not in facts:
        return {"status": 404}
    owners, damage = _qosha_owned_projection(facts, state)
    if sid in damage:
        return {"status": 503, "code": "incomplete_history"}
    chain = owners.get(sid)
    if chain is None:
        # A real ID that is not (or no longer) a canonical owner tip.
        return {"status": 409, "code": "projection_changed"}
    segments = set(chain)
    for bad in sorted(damage):
        _qosha_owned_check(state)
        if facts[bad]["parent_id"] in segments:
            # An unclassifiable child of this owner could change its tip.
            return {"status": 503, "code": "incomplete_history"}
    others = []
    for segment in chain:
        if segment != sid:
            others.append(segment)
    if others:
        rows.extend(_qosha_owned_facts(conn, state, "messages", others))
    # Every read of this request has completed; only Python work follows.
    grouped = {}
    for row in rows:
        _qosha_owned_check(state)
        grouped.setdefault(row["session_id"], []).append(row)
    history = {}
    for segment in chain:
        _qosha_owned_check(state)
        history[segment] = _qosha_owned_display(db, grouped.get(segment, []), state)[0]
    owner = _qosha_owned_revision(scope, chain, facts, history)
    if owner["owner_revision"] != params["revision"]:
        return {"status": 409, "code": "projection_changed"}
    projected = history[sid]
    limit, offset, order = params["limit"], params["offset"], params["order"]
    if order == "latest":
        # Native latest paging: offset counts back from the newest row and the
        # page stays chronological.
        stop = len(projected) - offset
        page = projected[max(0, stop - limit):stop] if stop > 0 else []
    else:
        page = projected[offset:offset + limit]
    return {"status": 200, "body": {
        "session_id": sid, "messages": page,
        "pagination": {"limit": limit, "offset": offset, "order": order, "returned": len(page)},
        "protocol": "owned-v1", "complete": True,
        "owner_id": sid, "owner_revision": owner["owner_revision"]}}


def _qosha_owned_read(kind, params, state):
    """Worker body: one read-only connection and one explicit snapshot.

    SQLite work is interruptible through a progress handler and every Python
    loop checks ``state``; after a stop only ROLLBACK runs. Never raises:
    returns a result dict for ``_qosha_owned_response`` to render.
    """
    import os
    import sqlite3

    from hermes_state import SessionDB, _connect_tracked_db, _default_db_path

    conn = None
    began = False
    try:
        _qosha_owned_check(state)
        # The default store, opened exactly as SessionDB's read-only mode does
        # (tracked URI ``mode=ro``, autocommit) but without its constructor's
        # schema probes: no statement reads this store before BEGIN below.
        path = _default_db_path()
        conn = _connect_tracked_db(
            f"file:{path}?mode=ro",
            tracking_path=path,
            uri=True,
            check_same_thread=False,
            timeout=1.0,
            isolation_level=None,
        )
        conn.row_factory = sqlite3.Row

        def progress():
            if state["stop"].is_set() or time.monotonic() >= state["deadline"]:
                return 1
            return 0

        conn.set_progress_handler(progress, 100)
        _qosha_owned_check(state)
        conn.execute("BEGIN")
        began = True
        scope = _qosha_owned_digest({"store": os.path.realpath(str(path))})
        if kind == "messages":
            result = _qosha_owned_messages(SessionDB, conn, params, scope, state)
        else:
            result = _qosha_owned_page(SessionDB, conn, kind, params, scope, state)
        if "body" in result:
            result["body"] = jsonable_encoder(result["body"])
        return result
    except BaseException as exc:
        if state["stop"].is_set():
            return {"status": 503, "code": "read_timeout", "stopped": True}
        if isinstance(exc, TimeoutError) or time.monotonic() >= state["deadline"]:
            return {"status": 503, "code": "read_timeout"}
        _log.warning("owned-v1 session read failed (%s)", type(exc).__name__)
        return {"status": 503, "code": "read_failed"}
    finally:
        if conn is not None:
            try:
                conn.set_progress_handler(None, 0)
            except Exception:
                pass
            if began:
                try:
                    conn.execute("ROLLBACK")
                except Exception:
                    pass
            try:
                conn.close()
            except Exception:
                _log.warning("owned-v1 session reader close failed")


def _qosha_owned_response(request, kind, limit, offset=0, session_id=None):
    """Validate an owned-v1 request and return the response that serves it.

    Invalid requests get an immediate 400 without touching the store. Valid
    ones get a request-owned ASGI response: it runs ``_qosha_owned_read`` on a
    worker thread, keeps the event loop free, stops the worker on client
    disconnect or task cancellation (then still awaits it before re-raising),
    and enforces a monotonic budget under 30 seconds from handler entry.
    """
    from starlette.responses import JSONResponse, Response

    key = {"list": "sessions", "search": "results", "messages": "messages"}[kind]
    messages = {
        "invalid_request": "The owned-v1 request is invalid.",
        "projection_changed": "Conversation history changed since it was read; reload from the beginning.",
        "incomplete_history": "Conversation history could not be completely verified, so nothing was returned.",
        "read_failed": "Conversation history could not be read; try again.",
        "read_timeout": "Conversation history did not finish loading in time; try again.",
    }

    def render(result):
        status = result["status"]
        if status == 200:
            return JSONResponse(result["body"])
        if status == 404:
            return JSONResponse({"detail": "Session not found"}, status_code=404)
        code = result["code"]
        return JSONResponse({
            "protocol": "owned-v1", "complete": False,
            "error": {"code": code, "retryable": status != 400,
                      "message": (result.get("message") or messages[code])[:240]},
            key: [],
        }, status_code=status)

    params, failure = _qosha_owned_query(request, kind, limit, offset, session_id)
    if failure is not None:
        return render(failure)
    state = {"stop": threading.Event(), "deadline": time.monotonic() + 29.5}

    class _QoshaOwnedResponse(Response):
        async def __call__(self, scope, receive, send):
            loop = asyncio.get_running_loop()
            finished = threading.Event()
            box = {}
            current = []

            class Waiter(asyncio.Future):
                # Cancelling a task cancels the future it awaits right away,
                # so the worker sees the stop signal before this coroutine
                # resumes (a middleware cancel scope may resume it turns later).
                def cancel(self, msg=None):
                    state["stop"].set()
                    return super().cancel(msg)

            def wake():
                if current and not current[0].done():
                    current[0].set_result(None)

            def work():
                try:
                    box["result"] = _qosha_owned_read(kind, params, state)
                finally:
                    finished.set()
                    try:
                        loop.call_soon_threadsafe(wake)
                    except RuntimeError:
                        pass  # The loop is gone; nothing is waiting any more.

            async def watch():
                while True:
                    message = await receive()
                    if message.get("type") == "http.disconnect":
                        box["disconnected"] = True
                        state["stop"].set()
                        wake()
                        return

            def settle(task):
                if not task.cancelled():
                    task.exception()

            worker = threading.Thread(target=work, name="qosha-owned-read", daemon=True)
            worker.start()
            watcher = loop.create_task(watch())
            watcher.add_done_callback(settle)
            cancelled = False
            # The worker enforces the budget itself; this outer bound only
            # covers a worker that cannot reach a stop point: past it the stop
            # signal is set and the worker gets a further 5 seconds to finish.
            limit, grace = state["deadline"] + 0.5, False
            try:
                while not finished.is_set():
                    remaining = limit - time.monotonic()
                    if remaining <= 0:
                        state["stop"].set()
                        if grace:
                            break
                        limit, grace = time.monotonic() + 5, True
                        continue
                    waiter = Waiter(loop=loop)
                    current[:] = [waiter]
                    timer = loop.call_later(remaining, wake)
                    try:
                        await waiter
                    except asyncio.CancelledError:
                        cancelled = True
                        state["stop"].set()
                    finally:
                        timer.cancel()
            finally:
                if not watcher.done():
                    watcher.cancel()
            if cancelled:
                raise asyncio.CancelledError()
            result = box.get("result") if finished.is_set() else None
            if result is None or result.get("stopped"):
                result = {"status": 503, "code": "read_timeout"}
            # Sent even after a client disconnect: the worker is already joined
            # and a server discards output for a closed transport, while
            # middleware may require every request to produce a response.
            await render(result)(scope, receive, send)

    return _QoshaOwnedResponse()
