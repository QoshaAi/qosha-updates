"""Set up a per-user Qosha home (Windows or Mac), the way lab/qoshalab.py sets up the Mac lab home, without the lab's
sandbox or launchd parts. Run with the engine's own Python:

    <engine python> -I setup_home.py --engine <engine dir> --home <home dir> [--port 9219]

<engine dir> holds src/hermes-6eb531c (the pinned engine with its built screens). This file's folder (the "layer")
holds candidate/ (plugin + native-extension from candidates/m2-c18), overlay/ (askaccess.py) and qoshalab.py.
Idempotent: run again to update Qosha's layer; config.yaml, SOUL.md and .env the person changed are kept.
"""
import argparse
import hashlib
import importlib.util
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

LAYER = Path(__file__).resolve().parent
PIN_NAME = 'hermes-6eb531c'
ROUTE = 'hermes_cli/web_routers/sessions.py'
WIN = os.name == 'nt'
ENGINE = Path('.')


def say(m):
    print(m, flush=True)


def die(m):
    say('FAILED: ' + m)
    raise SystemExit(2)


def lab():
    spec = importlib.util.spec_from_file_location('qoshalab_layer', LAYER / 'qoshalab.py')
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def sub(text, old, new, what, count=1):
    if old not in text:
        die('patch point not found: %s' % what)
    return text.replace(old, new, count)


def port_text(text):
    """POSIX-only spellings in Qosha's layer that stop it importing on Windows (the features using dir_fd stay
    unavailable there; see REPORT.md)."""
    for flag in ('O_NOFOLLOW', 'O_DIRECTORY', 'O_NONBLOCK', 'O_CLOEXEC'):
        text = re.sub(r'\bos\.%s\b' % flag, 'getattr(os, "%s", 0)' % flag, text)
    text = text.replace('getattr(getattr(os, ', 'getattr(getattr(os, ')
    text = text.replace('os.getuid()', 'getattr(os, "getuid", lambda: 0)()')
    text = text.replace('_F_GETPATH = getattr(__import__("fcntl"), "F_GETPATH", None)',
                        'try:\n    _F_GETPATH = getattr(__import__("fcntl"), "F_GETPATH", None)\nexcept ImportError:\n'
                        '    _F_GETPATH = None')
    text = re.sub(r'^import fcntl$', 'try:\n    import fcntl\nexcept ImportError:  # Windows\n    fcntl = None',
                  text, flags=re.M)
    return text


OTHER_ALWAYS = re.compile(r"QoshaLab|\.svc\b|cluster\.local|qosha-box|\.internal\b")
OTHER_IF_MISSING = re.compile(r"(?:^|[\s=:\"'])(/(?:opt|app|data|home|root|srv|var|usr|etc|Users)/[^\s\"']*)")
LOCAL_URL = re.compile(r"^[a-z]+://(127\.0\.0\.1|localhost|0\.0\.0\.0)(:\d+)?(/|$)", re.I)


def clean_imported_config(data, home):
    """Settings brought over from another Qosha (a cloud box, a Mac lab) that name things only that machine or that
    old home has: a speech model at /opt/..., the box's own Google connector on a local port, programs and folders
    under ~/QoshaLab. Left in place they fail at every start (HFValidationError; "qosha_google" cannot connect).
    Done ONCE, right after an import (mark: <home>/.qosha-import-cleaned), so a person's own later settings are
    never touched. Rules:
      - a value is "the other machine's" when it is a local-port address, names QoshaLab or a cluster host, or is a
        system-style path (/opt/..., /usr/..., /Users/...) that does not exist on this computer;
      - the `files` tool server is REWRITTEN, so the Files tool keeps working: its program folder is copied to
        <home>/tools/qosha-mcp when the source still exists, its folder argument becomes <home>/files; it is dropped
        only when the program cannot be found;
      - a path under an old home's models folder becomes <home>/models/... when that folder exists here;
      - mcp_servers.qosha_google (the box's Google connector) and any other tool server that still points at the
        other machine are dropped; stt.local.model is dropped (this computer's own speech model is used);
      - every other such value: the key is dropped (the engine's default applies).
    Returns the key names rewritten or dropped (names only, never values); None when there is nothing to do."""
    mark = home / '.qosha-import-cleaned'
    if not (home / '.qosha-imported-from').exists() or mark.exists():
        return None
    notes = []

    def other(v):
        if not isinstance(v, str) or not v:
            return False
        if LOCAL_URL.search(v) or OTHER_ALWAYS.search(v):
            return True
        return any(not os.path.exists(m) for m in OTHER_IF_MISSING.findall(v))

    def any_other(v):
        if isinstance(v, dict):
            return any(any_other(x) for x in v.values())
        if isinstance(v, (list, tuple)):
            return any(any_other(x) for x in v)
        return other(v)

    def models(v):
        """<old home>/models/<rest> -> <home>/models/<rest>, when this home has a models folder"""
        m = re.match(r"^(.*?)[\\/]models((?:[\\/].*)?)$", v) if isinstance(v, str) else None
        if m and other(v) and (home / 'models').is_dir():
            return str(home / 'models') + m.group(2).replace('/', os.sep)
        return None

    ms = data.get('mcp_servers')
    if isinstance(ms, dict):
        for name in list(ms):
            srv = ms[name]
            if name == 'files' and isinstance(srv, dict) and isinstance(srv.get('args'), list) and any_other(srv):
                args, done = list(srv['args']), False
                for i, a in enumerate(args):
                    if isinstance(a, str) and re.search(r"[\\/]node_modules[\\/]", a) and os.path.exists(a):
                        src_root = re.split(r"[\\/]node_modules[\\/]", a, 1)[0]
                        dst_root = home / 'tools' / 'qosha-mcp'
                        try:
                            if not dst_root.exists():
                                shutil.copytree(src_root, dst_root, symlinks=True)
                            args[i] = str(dst_root) + a[len(src_root):]
                            done = True
                        except OSError:
                            done = False
                if done:
                    args = [str(home / 'files') if (isinstance(a, str) and re.search(r"[\\/]files[\\/]?$", a) and other(a)) else a for a in args]
                    srv['args'] = args
                    if isinstance(srv.get('command'), str) and other(srv['command']) and shutil.which('node'):
                        srv['command'] = shutil.which('node')
                    if not any_other(srv):
                        notes.append('mcp_servers.files (rewritten: program copied to this home, folder set to this home\'s files)')
                        continue
                del ms[name]
                notes.append('mcp_servers.files (dropped: its program was not found on this computer)')
            elif name == 'qosha_google' or any_other(srv):
                del ms[name]
                notes.append('mcp_servers.%s (dropped: it belongs to the other machine)' % name)
    stt_local = (data.get('stt') or {}).get('local') if isinstance(data.get('stt'), dict) else None
    if isinstance(stt_local, dict) and isinstance(stt_local.get('model'), str):
        m = stt_local['model']
        if other(m) or (re.search(r'[\\/]', m) and not os.path.exists(m)):
            new = models(m)
            if new and os.path.exists(new):
                stt_local['model'] = new
                notes.append('stt.local.model (rewritten to this home\'s models folder)')
            else:
                del stt_local['model']
                notes.append('stt.local.model (dropped: this computer uses its own speech model)')

    def sweep(d, path):
        if isinstance(d, dict):
            for k in list(d):
                v = d[k]
                kp = '%s.%s' % (path, k) if path else str(k)
                if isinstance(v, (dict, list)):
                    sweep(v, kp)
                elif other(v):
                    new = models(v)
                    if new:
                        d[k] = new
                        notes.append('%s (rewritten to this home\'s models folder)' % kp)
                    else:
                        del d[k]
                        notes.append('%s (dropped: a path, port or host of the other machine)' % kp)
        elif isinstance(d, list):
            keep = [x for x in d if isinstance(x, (dict, list)) or not other(x)]
            if len(keep) != len(d):
                notes.append('%s (%d list entries dropped)' % (path, len(d) - len(keep)))
                d[:] = keep
            for x in d:
                if isinstance(x, (dict, list)):
                    sweep(x, path + '[]')
    sweep(data, '')
    try:
        mark.write_text('\n'.join(notes) + '\n', encoding='utf-8')
    except OSError:
        pass
    return notes


def init_store(home):
    """A new install has no conversation store until the first chat is sent, and the engine's list of conversations
    answers 503 without one: the Conversations page (and Home's and Chat's lists) opened with a red "Something went
    wrong (error 503)" on the very first start. The empty store is made here with the engine's own class."""
    db = home / 'state.db'
    try:
        if db.exists() and db.stat().st_size > 0:
            return 'conversation store already there'
        from hermes_state import SessionDB
        s = SessionDB(db)
        try:
            s.close()
        except Exception:
            pass
        return 'conversation store made (empty)' if db.exists() and db.stat().st_size > 0 else '! conversation store NOT made'
    except Exception as exc:
        return '! conversation store not made: %s' % type(exc).__name__


def google_skill_fix(home):
    """The Qosha library's google-workspace skill wants its Google packages at exact older versions and, when the
    engine's own (newer) ones are there instead, tries `pip install`: a per-user install has neither pip nor uv on the
    PATH, so Connect Google stopped right there ("Failed to install dependencies"). The engine already carries these
    packages; the check now accepts any installed version. Applied after the skill library is copied."""
    n = 0
    for rel in ('skills/productivity/google-workspace/scripts/setup.py', 'skills/qosha-library/google-workspace/scripts/setup.py'):
        f = home / rel
        if not f.is_file():
            continue
        t = f.read_text(encoding='utf-8')
        t2 = t.replace('            if _distribution_version(name) != wanted:\n',
                       '            if not _distribution_version(name):   # Qosha: the engine\'s own version is fine\n')
        if t2 != t:
            f.write_text(t2, encoding='utf-8')
            n += 1
    return 'Google skill uses the engine\'s own Google packages (%d files)' % n


def install_plugin(home):
    src = LAYER / 'candidate' / 'plugin'
    dest = home / 'plugins' / 'qosha'
    if dest.exists():
        old = home / 'plugins' / ('.qosha-old-%d' % int(time.time()))
        os.replace(dest, old)
        shutil.rmtree(old, ignore_errors=True)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(src, dest, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    init = dest / '__init__.py'
    t = init.read_text(encoding='utf-8')
    if (dest / 'qosha_guard' / 'ask.py').exists():
        say('  ask-first rule: the plugin\'s own (qosha_guard/ask.py)')
    else:
      shutil.copy2(LAYER / 'overlay' / 'qosha_guard' / 'askaccess.py', dest / 'qosha_guard' / 'askaccess.py')
      t = sub(t, '    ctx.register_hook("pre_tool_call", pre_tool_call)\n',
            '    # per-user installs: file and command tools ask the person (askaccess.py); everything else: the guard\n'
            '    from .qosha_guard import askaccess as _askaccess\n'
            '    _guard = _askaccess.wrap(pre_tool_call) if _askaccess.enabled() else pre_tool_call\n'
            '    ctx.register_hook("pre_tool_call", _guard)\n', 'register guard')
      t = sub(t, '        pre_tool_call.__qosha_guard_ready__ = True\n',
              '        pre_tool_call.__qosha_guard_ready__ = True\n        _guard.__qosha_guard_ready__ = True\n',
              'guard ready mark')
    init.write_text(t, encoding='utf-8')
    if WIN:
        n = 0
        for f in dest.rglob('*.py'):
            t0 = f.read_text(encoding='utf-8')
            t1 = port_text(t0)
            if t1 != t0:
                f.write_text(t1, encoding='utf-8')
                n += 1
        say('  Windows: %d plugin files adjusted' % n)
    # "Always allow" next to "Allow once" / "Deny" in Qosha's chat (the engine already understands the answer)
    chat = dest / 'dashboard' / 'pages' / 'chat.html'
    t = chat.read_text(encoding='utf-8')
    if 'Always allow' not in t:
      t = sub(t, "'Allow once'),\n",
            "'Allow once'),\n      el('button', {class: 'btn sm ghost', type: 'button', onclick: function () { "
            "done('always', 'You allowed this always (what it covers is written above).'); }}, 'Always allow'),\n",
            'chat page buttons')
    chat.write_text(t, encoding='utf-8')
    idx = dest / 'dashboard' / 'index.html'
    t = idx.read_text(encoding='utf-8')
    if 'x.always' not in t and 'Always allow' not in t:
      t = sub(t, '>Allow once</button>',
            '>Allow once</button><button class="mini ghost" type="button" onClick="{{x.always}}">Always allow</button>',
            'home chat buttons')
      t = sub(t, "allow:() => this.chatAnswer(a.request_id, 'once'),",
            "allow:() => this.chatAnswer(a.request_id, 'once'), always:() => this.chatAnswer(a.request_id, 'always'),",
            'home chat always')
    idx.write_text(t, encoding='utf-8')
    say('OK Qosha plugin installed (approval guard, screens, ask-for-access)')


def write_config(home, files):
    """Qosha's settings merged into the engine's config.yaml (the upstream installer writes its own first: its model
    defaults stay; Qosha adds its plugin, the approval prompt mode, its files folder and quiet background features)."""
    try:
        from ruamel.yaml import YAML          # the engine's own YAML library (keeps the file's comments)
        y = YAML()
        load = lambda s: y.load(s)

        def dump(d):
            import io
            buf = io.StringIO()
            y.dump(d, buf)
            return buf.getvalue()
    except ImportError:
        import yaml
        load = yaml.safe_load
        dump = lambda d: yaml.safe_dump(d, sort_keys=False, allow_unicode=True)
    cfg = home / 'config.yaml'
    data = {}
    if cfg.exists():
        data = load(cfg.read_text(encoding='utf-8')) or {}
        if not (home / 'config.yaml.before-qosha').exists():
            shutil.copyfile(cfg, home / 'config.yaml.before-qosha')
    cleaned = clean_imported_config(data, home)
    if cleaned is not None:
        say('  imported settings checked: %d changed%s' % (len(cleaned), ''.join('\n    - ' + c for c in cleaned)))
    plugins = data.setdefault('plugins', {}) or {}
    data['plugins'] = plugins
    en = list(plugins.get('enabled') or [])
    if 'qosha' not in en:
        en.append('qosha')
    plugins['enabled'] = en
    plugins['disabled'] = [p for p in (plugins.get('disabled') or []) if p != 'qosha']
    plugins.setdefault('entries', {}).setdefault('qosha', {})['allow_tool_override'] = True
    data.setdefault('approvals', {})['mode'] = 'manual'
    data.setdefault('terminal', {})['cwd'] = str(files)
    data.setdefault('agent', {}).setdefault('reasoning_effort', 'medium')
    data['kanban'] = dict(data.get('kanban') or {}, dispatch_in_gateway=False, review_dispatch=False,
                          auto_decompose=False, default_assignee='', auto_subscribe_on_create=False)
    data.setdefault('curator', {})['enabled'] = False
    data.setdefault('updates', {})['check'] = False            # engine versions come only with Qosha
    data.setdefault('stt', {}).setdefault('local', {})['initial_prompt'] = 'Qosha'
    br = data.setdefault('browser', {})
    args = list(br.get('chromium_args') or [])
    for a in ('--mute-audio', '--disable-audio-output'):       # Qosha's own browser never plays sound
        if a not in args:
            args.append(a)
    br['chromium_args'] = args
    # Ren, 17 Nov 2026: the browser opens where the person can see it; 'Do it in the background' is their switch.
    # Set once per home; a later choice (Settings, or Qosha changing it when asked) is kept.
    if not br.get('qosha_visible_default'):
        br['headed'] = True
        br['qosha_visible_default'] = 1
    # Google through the Workspace MCP in its own environment beside the engine (only when it was installed)
    gws = ENGINE / 'gws-venv' / ('Scripts/workspace-mcp.exe' if WIN else 'bin/workspace-mcp')
    if gws.exists():
        ms = data.get('mcp_servers')
        if not isinstance(ms, dict):
            ms = {}
        ms['google'] = {'command': str(gws),
                        'args': ['--single-user', '--tools', 'gmail', 'calendar', 'drive', 'docs', 'sheets', 'contacts',
                                 'tasks', '--tool-tier', 'complete'],
                        'env': {'GOOGLE_CLIENT_SECRET_PATH': str(home / 'google_client_secret.json'),
                                'WORKSPACE_MCP_CREDENTIALS_DIR': str(home / 'google_workspace_mcp' / 'credentials'),
                                'WORKSPACE_MCP_TRANSPORT': 'stdio',
                                # Drive uploads from this computer (Ren, 17 Nov 2026: "Usual folders, no question"): the
                                # connector reads local files only inside these folders; its own blocks still apply
                                'ALLOWED_FILE_DIRS': os.pathsep.join(str(d) for d in (Path.home() / 'Downloads', Path.home() / 'Desktop',
                                                     Path.home() / 'Documents', home / 'files'))}}
        data['mcp_servers'] = ms
    # Gemini on the person's Google subscription, only where Google's own command-line tool is installed
    gm = home / 'plugins' / 'qosha' / 'qosha_guard' / 'gemini_mcp.py'
    agy_win = Path(os.environ.get('LOCALAPPDATA') or '.') / 'Programs' / 'agy' / 'agy.exe'      # where Qosha's Windows installer puts it
    if gm.is_file() and (shutil.which('agy') or shutil.which('gemini') or (WIN and agy_win.is_file())):
        ms = data.get('mcp_servers')
        if not isinstance(ms, dict):
            ms = {}
        ms['gemini'] = {'command': sys.executable, 'args': [str(gm)]}
        data['mcp_servers'] = ms
    if (LAYER / 'brand' / 'qosha.yaml').is_file():
        data.setdefault('display', {})['skin'] = 'qosha'
    try:   # no sharing of usage numbers with the engine's maker, and no question about it on Qosha's screens
        from hermes_cli.observability.shared_metrics_consent import set_answer
        set_answer(data, False, False)
    except Exception:
        sm = data.setdefault('telemetry', {}).setdefault('shared_metrics', {})
        sm['enabled'] = False
        sm['send'] = False
    data['sessions'] = dict(data.get('sessions') or {}, auto_archive=False, auto_prune=False)
    tmp = cfg.with_name('.config.yaml.qosha-tmp')
    tmp.write_text(dump(data), encoding='utf-8')
    os.replace(tmp, cfg)
    say('OK config.yaml: Qosha plugin on, approvals asked in the chat')


def brand_web(src, home, L):
    dist = src / 'hermes_cli' / 'web_dist'
    icons = home / 'plugins' / 'qosha' / 'dashboard' / 'assets' / 'brand' / 'icons'
    names = L.QOSHA_ICON_FILES
    if not (dist / 'index.html').is_file() or not all((icons / n).is_file() for n in names):
        die('the built screens or the plugin icons are missing')
    data = {n: (icons / n).read_bytes() for n in names}
    ver = hashlib.sha256(b''.join(data[n] for n in names)).hexdigest()[:12]
    out = dist / 'qosha-icons'
    out.mkdir(exist_ok=True)
    for n in names:
        (out / n).write_bytes(data[n])
    (dist / 'favicon.ico').write_bytes(data['favicon.ico'])
    (dist / 'apple-touch-icon.png').write_bytes(data['apple-touch-icon.png'])
    html = (dist / 'index.html').read_text(encoding='utf-8')
    html = re.sub(r'\s*<!-- qosha-icons -->.*?<!-- /qosha-icons -->', '', html, flags=re.S)
    html = re.sub(r'\s*<link rel="(?:icon|shortcut icon|apple-touch-icon|manifest)"[^>]*>', '', html)
    block = ('<!-- qosha-icons -->\n'
             '    <link rel="icon" type="image/svg+xml" href="/qosha-icons/qosha-icon.svg?v=%(v)s" />\n'
             '    <link rel="icon" type="image/x-icon" sizes="16x16 32x32 48x48" href="/favicon.ico?v=%(v)s" />\n'
             '    <link rel="apple-touch-icon" sizes="180x180" href="/qosha-icons/apple-touch-icon.png?v=%(v)s" />\n'
             '    <link rel="manifest" href="/qosha-icons/site.webmanifest?v=%(v)s" />\n'
             '    <meta name="theme-color" content="#0B3326" />\n'
             '    <!-- /qosha-icons -->') % {'v': ver}
    html, n = re.subn(r'(<meta charset="UTF-8" />)', lambda m: m.group(1) + '\n    ' + block, html, count=1, flags=re.I)
    if not n:
        html = html.replace('<head>', '<head>\n    ' + block, 1)
    html = re.sub(r'<title>[^<]*</title>', '<title>Qosha</title>', html, count=1)
    fp_code = home / 'plugins' / 'qosha' / 'dashboard' / 'first_paint.py'
    fp_block = fp_code.with_name('first-paint.html')
    if fp_code.is_file() and fp_block.is_file():
        spec = importlib.util.spec_from_file_location('qosha_first_paint', fp_code)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        html = mod.apply(html, fp_block.read_text(encoding='utf-8'))
    (dist / 'index.html').write_text(html, encoding='utf-8')
    say('OK screens branded Qosha (title, icons, first paint)')


def narrow_google(src, L):
    n = 0
    for rel in L.GOOGLE_SCRIPTS:
        p = src / rel
        if not p.is_file():
            continue
        t = p.read_text(encoding='utf-8')
        t2 = L.narrow_google_text(t)
        if t2 != t:
            p.write_text(t2, encoding='utf-8')
            n += 1
    say('OK Google scripts use the 4 pilot scopes (%d changed)' % n)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--engine', required=True)
    ap.add_argument('--home', required=True)
    ap.add_argument('--src', help='the engine source folder (default: <engine>/src/%s)' % PIN_NAME)
    a = ap.parse_args()
    global ENGINE
    engine, home = Path(a.engine).resolve(), Path(a.home).resolve()
    ENGINE = engine
    src = Path(a.src).resolve() if a.src else engine / 'src' / PIN_NAME
    if not (src / 'hermes_cli').is_dir():
        die('no engine source at %s' % src)
    L = lab()
    home.mkdir(parents=True, exist_ok=True)
    files = home / 'files'
    files.mkdir(exist_ok=True)
    port = LAYER / 'port' / 'sessions.py'      # Qosha's sessions route ported to the newer engine
    shutil.copyfile(port if (src / 'hermes_state_common.py').exists() and port.exists() else
                    LAYER / 'candidate' / 'native-extension' / ROUTE, src / ROUTE)
    say('OK sessions route from the Qosha candidate')
    narrow_google(src, L)
    install_plugin(home)
    write_config(home, files)
    soul = home / 'SOUL.md'
    if soul.exists() and 'Qosha' not in soul.read_text(encoding='utf-8', errors='replace'):
        os.replace(soul, home / 'SOUL.md.before-qosha')   # the engine's default persona, kept aside
    if not soul.exists():
        s = L.QOSHA_SOUL.replace(
            "(python, node, shell) in Qosha's code sandbox, which works on Your files;",
            "(python, shell) on this computer: Qosha asks the person first (Allow once / Always allow / Deny), and the "
            "same for files outside Your files, so just go ahead and use the tool;")
        s = re.sub(r"The Mac's live screen isn't visible to you \(macOS would have to ask the person for Screen "
                   r"Recording permission\)", "This computer's live screen isn't visible to you", s)
        s = s.replace('this Mac', 'this computer').replace('This Mac', 'This computer')
        soul.write_text(s, encoding='utf-8')
        say('OK SOUL.md: Qosha')
    env = home / '.env'
    if not env.exists():
        env.write_text('# Qosha secrets (sign-ins are added by Qosha\'s sign-in steps; never copied from elsewhere)\n',
                       encoding='utf-8')
    brand_web(src, home, L)
    bd = LAYER / 'brand' / 'brand_dashboard.py'      # the features tree's own title/icon step, when it has one
    if bd.is_file():
        r = subprocess.run([sys.executable, '-I', str(bd), str(src), str(home / 'plugins' / 'qosha')],
                           capture_output=True, text=True)
        say('OK page title and icon at the source' if r.returncode == 0 else '! brand_dashboard.py failed: ' + (r.stderr or '')[-200:])
    sp = [p for p in sys.path if p.rstrip('/\\').endswith('site-packages') and os.path.isdir(p)]
    target = next((p for p in sp if 'installs' in p or 'venv' in p), sp[-1] if sp else None)
    if not target:
        die('no site-packages for the engine environment')
    os.environ.update(HERMES_HOME=str(home), HERMES_KANBAN_HOME=str(home))
    # Qosha's name in the engine's chat error texts (qosha_names.py), loaded at every engine start
    pat = 'installs/*/environments/*/venv/' + ('Lib/site-packages' if WIN else 'lib/python*/site-packages')
    targets = sorted({str(p) for p in home.glob(pat)} | {target})      # every environment the engine has made
    for tg in targets:
        shutil.copyfile(LAYER / 'qosha_names.py', os.path.join(tg, 'qosha_names.py'))
        with open(os.path.join(tg, 'qosha_names.pth'), 'w') as fh:
            fh.write('import qosha_names\n')
    # and from the plugin itself, so an environment the engine rebuilds later still gets it
    pl = home / 'plugins' / 'qosha'
    shutil.copyfile(LAYER / 'qosha_names.py', pl / 'qosha_names.py')
    it = (pl / '__init__.py').read_text(encoding='utf-8')
    if 'qosha_names' not in it:
        (pl / '__init__.py').write_text(it + '\n\ntry:\n    from . import qosha_names as _qosha_names  # noqa: F401  (engine error texts say Qosha)\nexcept Exception:\n    pass\n', encoding='utf-8')
    say('OK engine error texts say Qosha')
    for tg in targets:
        shutil.copyfile(home / 'plugins' / 'qosha' / 'qosha_guard' / 'startup_barrier.py',
                        os.path.join(tg, 'qosha_startup_barrier.py'))
        with open(os.path.join(tg, 'qosha_startup_barrier.pth'), 'w') as fh:
            fh.write('import qosha_startup_barrier\n')
    say('  engine environments set up: %d' % len(targets))
    import qosha_startup_barrier  # noqa: F401  (as the .pth does at every start)
    import hermes_cli.plugins as hp
    ok = getattr(hp._get_pre_tool_call_directive_details, '__qosha_barrier__', False)
    say('OK startup barrier active' if ok else '! startup barrier NOT active')
    # Qosha's skill library
    inst = LAYER / 'candidate' / 'skills' / 'install_skills.py'
    if inst.is_file():
        r = subprocess.run([sys.executable, '-I', str(inst), '--home', str(home), '--backups', str(home.parent / 'backups')],
                           capture_output=True, text=True)
        tail = ((r.stdout or '') + (r.stderr or '')).strip().splitlines()[-1:] or ['']
        if r.returncode == 0:
            say('OK skill library: ' + tail[0][:200])
        else:   # the library's own installer needs a package this environment lacks: plain copy of the library
            lib = LAYER / 'candidate' / 'skills' / 'qosha-library'
            dst = home / 'skills' / 'qosha-library'
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(lib, dst)
            man = LAYER / 'candidate' / 'skills' / 'SKILLS-MANIFEST.json'
            if man.is_file():
                shutil.copyfile(man, dst / 'SKILLS-MANIFEST.json')
            say('OK skill library copied (%d skills; its own installer could not run: %s)'
                % (sum(1 for _ in dst.rglob('SKILL.md')), tail[0][:80]))
    # the engine's own string overlay and skin with Qosha's wording and colours (features/brand)
    if WIN:
        say('  Windows: ' + google_skill_fix(home))
    # a home imported from a Mac lab still names the lab's folders in its memories, skills and notes (17 Nov: Qosha
    # reached for ~/QoshaLab/home/skills/.../google_api.py); point them at this home, once, with backups
    fx = LAYER / 'fix_lab_paths.py'
    if (home / '.qosha-imported-from').exists() and not (home / '.qosha-lab-paths-fixed').exists() and fx.is_file():
        r = subprocess.run([sys.executable, '-I', str(fx), '--home', str(home), '--apply'], capture_output=True, text=True)
        last = ((r.stdout or '').strip().splitlines() or [''])[-1]
        if r.returncode == 0:
            (home / '.qosha-lab-paths-fixed').write_text(last + '\n', encoding='utf-8')
            say('OK lab paths: ' + last[:200])
        else:
            say('! lab paths not fixed: ' + (last or (r.stderr or '')[-200:]))
    brand = LAYER / 'brand'
    if (brand / 'locales').is_dir():
        (home / 'locales').mkdir(exist_ok=True)
        for f in (brand / 'locales').glob('*.yaml'):
            shutil.copyfile(f, home / 'locales' / f.name)
        say('OK engine wording overlay: %s' % ', '.join(sorted(f.name for f in (brand / 'locales').glob('*.yaml'))))
    if (brand / 'qosha.yaml').is_file():
        (home / 'skins').mkdir(exist_ok=True)
        shutil.copyfile(brand / 'qosha.yaml', home / 'skins' / 'qosha.yaml')
    try:
        from hermes_cli import kanban_db as kb
        kb.create_board(L.BOARD, name=L.BOARD)
        say('OK task board ' + L.BOARD)
    except Exception as exc:
        say('! task board not created: %s' % exc)
    say('  ' + init_store(home))   # Mac and Windows alike: a fresh install must open Conversations without a 503
    sys.path.insert(0, str(home / 'plugins'))
    try:
        import qosha  # noqa: F401
        from qosha.qosha_guard import policy as p
        v = p.classify("send_message", {"action": "send", "target": "x", "message": "self-check"})
        say('guard self-check: GUARD %s' % v.action)
        if (home / 'plugins' / 'qosha' / 'qosha_guard' / 'ask.py').exists():
            from qosha.qosha_guard import ask
            r = ask.pre_tool_call(tool_name='send_message', args={'action': 'send', 'target': 'x', 'message': 'hi'})
            say('ask-first self-check (a send): %s' % (r or {}).get('action'))
    except Exception as exc:
        import traceback
        traceback.print_exc()
        die('Qosha\'s approval guard does not load here: %s' % exc)
    # Qosha updates (17 Nov 2026): the person's own changes are put back after every (re)install, and the engine's
    # own self-update stays switched off from the first start
    try:
        from qosha.qosha_guard import updater as u
        u.apply_customizations(home)
        u.patch_engine_update_gate(src)
        say('OK updates: customisations kept, engine self-update off')
    except Exception as exc:
        say('! updates step: %s' % type(exc).__name__)
    say('SETUP HOME DONE')


if __name__ == '__main__':
    main()
