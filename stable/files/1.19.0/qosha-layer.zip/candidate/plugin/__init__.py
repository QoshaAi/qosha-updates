"""Qosha agent plugin: registers the approval guard on every tool call (INTERFACES.md §4.1), and the file viewer's
version observers (night job 4: they only read the file a write_file / patch is about to change or just changed),
Qosha's own identity in place of the engine's (qosha_guard/identity.py), and Claude seat-first with the API key as
fallback (qosha_guard/seatfirst.py), and Qosha's browser tools on Qosha's own Chrome (qosha_guard/browser_tools.py), and the council (qosha_council/),
and Gemini as a full chat model through Qosha's relay (qosha_guard/gemini_chat.py, CONTRACT G1)."""
from .qosha_guard.hook import pre_tool_call
from .qosha_guard import browser_tools, identity, seatfirst, versions


def _local() -> bool:
    """The person's own computer (no Qosha connector, not a cloud box): the engine's own behavior, plus ask-first."""
    import os
    return not os.environ.get("QOSHA_CONNECTOR_URL") and not os.environ.get("QOSHA_BOX") and not os.environ.get("QOSHA_LAB")


def register(ctx) -> None:
    if _local():
        # Ren, 17 Nov: no walls; only sends, payments, deletions, sharing and calendar changes are asked first through
        # the engine's own prompt (Allow once / Always allow). Qosha's extras that stock lacks stay.
        from .qosha_guard import ask
        # the startup barrier (startup_barrier.py, installed beside the engine) blocks every tool until this hook is
        # registered and has confirmed itself: a send must come back as an ask
        if (ask.pre_tool_call("send_message", {"target": "x", "message": "self-check"}) or {}).get("action") == "approve":
            ask.pre_tool_call.__qosha_guard_ready__ = True
        ctx.register_hook("pre_tool_call", ask.pre_tool_call)
        for _hook in ("pre_approval_request", "post_approval_response", "post_tool_call", "transform_tool_result"):   # Home shows what waits in a chat; one card per step
            try:
                ctx.register_hook(_hook, getattr(ask, _hook))
            except Exception:
                pass
        try:
            from .qosha_guard import updater as _updater
            _updater.register(ctx)   # "check for updates" in the chat; the engine's own /update answers with Qosha's line
        except Exception as exc:
            import logging
            logging.getLogger("qosha").warning("Qosha updates not set up in the chat: %s", type(exc).__name__)
        for extra in ("google", "council", "identity"):
            try:
                if extra == "google":
                    from .qosha_guard import google_connect
                    google_connect.register(ctx)   # one-step Google sign-in (no copy-paste)
                elif extra == "council":
                    from .qosha_council import load as _council_load
                    _council_load().register(ctx)
                else:
                    identity.apply()
            except Exception as exc:
                import logging
                logging.getLogger("qosha").warning("Qosha %s not set up: %s", extra, type(exc).__name__)
        try:
            from .qosha_guard import handoff
            handoff.register(ctx)   # automatic model hand-off for pictures (roadmap item 9)
        except Exception as exc:
            import logging
            logging.getLogger("qosha").warning("Qosha hand-off not set up: %s", type(exc).__name__)
        return
    ctx.register_hook("pre_tool_call", pre_tool_call)
    # GUARDFIX message 1: the startup barrier (qosha_guard/startup_barrier.py) lets tools run only once this guard is
    # registered AND has confirmed itself: a direct send must come back refused
    from .qosha_guard import policy as _policy
    if _policy.classify("send_message", {"action": "send", "target": "x", "message": "self-check"}).action == _policy.DENY:
        pre_tool_call.__qosha_guard_ready__ = True
    # GUARDFIX2: on the Mac lab the assistant's terminal and code start inside its own OS sandbox (confine.py); if
    # this fails the guard refuses those tools there
    try:
        from .qosha_guard import confine
        confine.apply()
    except Exception as exc:
        import logging
        logging.getLogger("qosha.confine").error("Qosha's sandbox for the assistant was not set up: %s", type(exc).__name__)
    ctx.register_hook("pre_tool_call", versions.pre_tool_call)
    ctx.register_hook("post_tool_call", versions.post_tool_call)
    ctx.register_hook("pre_llm_call", seatfirst.pre_llm_call)
    ctx.register_hook("post_llm_call", browser_tools.post_llm_call)   # Qosha's tab closes when the turn ends
    try:
        browser_tools.register(ctx)   # Qosha's own Chrome through the connector (BROWSERCHROME), when switched on
    except Exception as exc:
        # fail-safe: the guard still refuses the engine's page-code tools (browser_tools.classify)
        import logging
        logging.getLogger("qosha.browser").warning("Qosha's browser tools were not registered: %s", type(exc).__name__)
    try:
        from .qosha_guard import selftools
        selftools.register(ctx)       # CAPFIX: Qosha's own screens (read-only) and settings (an Approve card)
    except Exception as exc:
        import logging
        logging.getLogger("qosha.selftools").warning("Qosha's self tools were not registered: %s", type(exc).__name__)
    try:
        from .qosha_council import load as _council_load
        _council_load().register(ctx)  # P0 council: "All", plain words and the qosha_council tool (qosha_council/)
    except Exception as exc:
        import logging
        logging.getLogger("qosha.council").warning("Qosha's council was not registered: %s", type(exc).__name__)
    try:
        identity.apply()
    except Exception:
        pass   # fail-open: the guard above is what must always be registered
    try:
        seatfirst.apply()
    except Exception:
        pass   # fail-open: without it the engine still answers, it just fails over late
    try:
        # CONTRACT G1: Gemini as a full chat model through Qosha's relay (qosha_guard/gemini_chat.py). Only in a box
        # that names the relay; elsewhere it touches nothing.
        from .qosha_guard import gemini_chat
        ctx.register_hook("pre_llm_call", gemini_chat.pre_llm_call)
        gemini_chat.apply()
    except Exception as exc:
        # fail-safe: the screens offer Gemini as a chat model only when gemini_chat.ready() says yes
        import logging
        logging.getLogger("qosha.gemini_chat").warning("Gemini chat was not set up: %s", type(exc).__name__)
