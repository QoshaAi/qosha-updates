"""Connect Google in one step (Ren, 17 Nov 2026: "the person just sees Connected, no copy-paste").

The engine's bundled google-workspace skill signs in with a redirect to http://localhost:1, so the person must copy the
browser's address back into the chat. This helper uses the same skill (its scopes, client file and token format, so
google_api.py works unchanged) but catches Google's redirect on a loopback port of this computer, so the person only
signs in to Google and sees "Connected".

Tool: qosha_connect_google. Python: connect(timeout=300) -> dict.
The Google OAuth client comes from <home>/google_client_secret.json (the skill's place); if it is missing, a Qosha
install may ship one as <plugin>/google_client.json (Desktop-app client, no secret values in this repo).
"""
from __future__ import annotations

import html
import importlib.util
import json
import os
import shutil
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict
from urllib.parse import parse_qs, urlparse


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes"))


def _skill_setup():
    """The bundled skill's setup.py, loaded as a module (home copy first, then the engine's)."""
    cands = [_home() / "skills" / "productivity" / "google-workspace" / "scripts" / "setup.py"]
    try:
        import hermes_constants
        cands.append(Path(hermes_constants.__file__).resolve().parent / "skills" / "productivity" / "google-workspace"
                     / "scripts" / "setup.py")
    except Exception:
        pass
    for p in cands:
        if p.is_file():
            import sys
            if str(p.parent) not in sys.path:
                sys.path.insert(0, str(p.parent))
            spec = importlib.util.spec_from_file_location("qosha_gws_setup", p)
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)
            return m
    raise RuntimeError("the google-workspace skill is not installed")


# Google Workspace MCP (taylorwilsdon/google_workspace_mcp 2.5.0; Ren 02:20: full tool set for Gmail, Calendar, Drive,
# Docs, Sheets, Contacts, Tasks): one sign-in feeds both it and the bundled skill. Its scopes for those services:
WORKSPACE_MCP_SCOPES = [
    "https://www.googleapis.com/auth/" + x for x in (
        "calendar", "calendar.events", "calendar.readonly", "contacts", "contacts.readonly", "documents",
        "documents.readonly", "drive", "drive.file", "drive.readonly", "gmail.compose", "gmail.labels", "gmail.modify",
        "gmail.readonly", "gmail.send", "gmail.settings.basic", "spreadsheets", "spreadsheets.readonly", "tasks",
        "tasks.readonly", "userinfo.email", "userinfo.profile")] + ["openid"]


def workspace_mcp_dir() -> Path:
    return _home() / "google_workspace_mcp" / "credentials"


def _write_workspace_mcp(creds, email: str, granted) -> str:
    """The same sign-in in the Workspace MCP's own credential format (auth/credential_store.py, file per account)."""
    if not email:
        return "skipped: no account email"
    from urllib.parse import quote
    d = workspace_mcp_dir()
    d.mkdir(parents=True, exist_ok=True)
    data = {"token": creds.token, "refresh_token": creds.refresh_token, "token_uri": creds.token_uri,
            "client_id": creds.client_id, "client_secret": creds.client_secret, "scopes": list(granted or creds.scopes or []),
            "expiry": creds.expiry.isoformat() if getattr(creds, "expiry", None) else None}
    path = d / (quote(email, safe="@._-") + ".json")
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(data, f, indent=2)
    return "written"


PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Qosha</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#F5F4F0;color:#0B0B0B;
font-family:"Google Sans Flex","Helvetica Neue",Arial,sans-serif}.c{background:#fff;border:1px solid #E2E1DB;border-radius:20px;
padding:32px 40px;max-width:440px;box-shadow:0 1px 2px rgba(11,11,11,.04),0 8px 28px rgba(11,11,11,.05)}
h1{margin:0 0 8px;font-size:22px;font-weight:500;color:#0B3326}p{margin:0;color:#3E4B45;line-height:22px}
.bar{height:4px;width:48px;background:#B8955A;border-radius:2px;margin-bottom:16px}</style></head>
<body><div class="c"><div class="bar"></div><h1>%s</h1><p>%s</p></div></body></html>"""


def connect(timeout: int = 300, open_browser: bool = True) -> Dict[str, Any]:
    s = _skill_setup()
    secret = Path(s.CLIENT_SECRET_PATH)
    if not secret.exists():
        shipped = Path(__file__).resolve().parent.parent / "google_client.json"
        if shipped.is_file():
            shutil.copyfile(shipped, secret)
            os.chmod(secret, 0o600)
        else:
            return {"ok": False, "error": "no_client", "plain": (
                "Qosha has no Google sign-in app set up on this computer yet (google_client_secret.json). Ask the "
                "person for their Google OAuth client file (Desktop app), or follow the google-workspace skill's Step 2.")}
    # The Google packages are the engine's own (its "google" extra). The skill's own check wants exact older versions
    # and runs pip when they differ; a person's computer has no pip (Windows, a client Mac), so it is not used here.
    try:
        from google_auth_oauthlib.flow import Flow
        import googleapiclient.discovery  # noqa: F401
        import google.oauth2.credentials  # noqa: F401
    except Exception:
        return {"ok": False, "error": "no_google_packages", "plain": (
            "The Google parts of Qosha are missing on this computer, so the sign-in could not start. Reinstall Qosha.")}

    got: Dict[str, str] = {}
    want: Dict[str, str] = {}
    done = threading.Event()

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            q = parse_qs(urlparse(self.path).query)
            if "code" not in q and "error" not in q:
                self.send_response(404); self.end_headers(); return
            got.update({k: v[0] for k, v in q.items()})
            ok = "code" in q and q.get("state", [""])[0] == want.get("state")
            body = PAGE % (("Connected", "Google is connected to Qosha. You can close this tab and go back to Qosha.")
                           if ok else ("Not connected", "Google said: %s. Go back to Qosha and try again."
                                       % html.escape(q.get("error", ["cancelled"])[0])))
            data = body.encode("utf-8")
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)
            done.set()

    srv = HTTPServer(("127.0.0.1", 0), H)
    redirect = "http://127.0.0.1:%d/" % srv.server_address[1]
    flow = Flow.from_client_secrets_file(str(secret), scopes=sorted(set(s.SCOPES) | set(WORKSPACE_MCP_SCOPES)), redirect_uri=redirect,
                                         autogenerate_code_verifier=True)
    url, state = flow.authorization_url(access_type="offline", prompt="consent")
    want["state"] = state
    t = threading.Thread(target=lambda: [srv.handle_request() for _ in range(20) if not done.is_set()], daemon=True)
    t.start()
    opened = False
    if open_browser:
        try:
            opened = webbrowser.open(url)
        except Exception:
            opened = False
    if not done.wait(timeout):
        srv.server_close()
        return {"ok": False, "error": "timeout", "auth_url": url, "plain": "The Google sign-in was not finished in time."}
    srv.server_close()
    if "error" in got or got.get("state") != state:
        return {"ok": False, "error": got.get("error") or "state_mismatch", "plain": "Google did not connect."}
    os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"
    flow.fetch_token(code=got["code"])
    creds = flow.credentials
    payload = s._normalize_authorized_user_payload(json.loads(creds.to_json()))
    granted = list(getattr(creds, "granted_scopes", None) or []) or got.get("scope", "").split()
    if granted:
        payload["scopes"] = granted
    s.write_private_json(s.TOKEN_PATH, payload)
    email = ""
    try:
        from googleapiclient.discovery import build
        email = build("gmail", "v1", credentials=creds).users().getProfile(userId="me").execute().get("emailAddress", "")
    except Exception:
        pass
    mcp = _write_workspace_mcp(creds, email, granted)
    return {"ok": True, "email": email, "scopes": granted, "browser_opened": opened, "workspace_mcp": mcp,
            "plain": "Google is connected%s." % (" as " + email if email else "")}


SCHEMA = {"name": "qosha_connect_google",
          "description": ("Connect the person's Google account (Gmail, Calendar, Drive, Docs, Sheets, Contacts) to Qosha "
                          "in one step: opens Google's sign-in page in their browser and waits until they finish; they "
                          "see 'Connected' and need to copy nothing. Use this instead of the google-workspace skill's "
                          "manual --auth-url/--auth-code steps. Afterwards use the google-workspace skill's google_api.py."),
          "parameters": {"type": "object", "properties": {}, "required": []}}


def _handler(args, **kw) -> str:
    try:
        r = connect()
    except Exception as exc:
        r = {"ok": False, "error": type(exc).__name__, "plain": "Google could not be connected: %s" % exc}
    return json.dumps(r)


def register(ctx) -> None:
    ctx.register_tool(name="qosha_connect_google", toolset="qosha", schema=SCHEMA, handler=_handler,
                      check_fn=lambda: True, description=SCHEMA["description"], emoji="🔗")


if __name__ == "__main__":
    import sys
    print(json.dumps(connect(open_browser="--no-browser" not in sys.argv), indent=2))
