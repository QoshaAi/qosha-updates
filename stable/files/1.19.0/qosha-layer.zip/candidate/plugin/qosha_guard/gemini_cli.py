"""Gemini on the person's own Google subscription, through Google's own command-line tool (Ren, 17 Nov 2026:
"subscriptions, not API keys"; never by driving the Gemini web page).

Google ships two command-line tools that sign in with the person's Google account: Antigravity's `agy` and the
`gemini` CLI. This module finds one, asks it a question (text in, text out) and tells whether it is signed in. The
sign-in itself is the tool's own: it opens Google's sign-in in the person's browser. Qosha reads no credential file.

How a question is asked (the same way as Qosha's Gemini seat on the Mac lab and the boxes):
- the question goes in on standard input, never on the command line (other programs can read command lines);
- no shell; fixed flags only; the tool's own sandbox flag on; never its "skip permissions" flag;
- the working folder is a fresh empty folder, removed afterwards, so the tool has no files to act on;
- a time limit ends the whole process group.
Used by: the "Connect your AI" panel (signin_api.py), Ask Gemini / the Gemini choice in Chat (assistants_api.py) and
the MCP tool ask_gemini (gemini_mcp.py), which lets Qosha itself ask Gemini inside a chat.
"""
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

TIMEOUT = 150
WIN = os.name == "nt"


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes"))


def find() -> Tuple[str, str]:
    """("agy" | "gemini" | "", path): Google's command-line tool on this computer, agy first."""
    local = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
    places = {"agy": [Path.home() / ".local" / "bin" / "agy", local / "agy" / "bin" / "agy.exe",   # Google's default place on Windows
                      local / "Programs" / "agy" / "agy.exe"],
              "gemini": [Path("/opt/homebrew/bin/gemini"), Path("/usr/local/bin/gemini")]}
    if WIN:   # the Windows installer puts Google's tool beside the engine: <install>\\engine\\gemini-cli\\gemini.cmd
        places["gemini"].insert(0, _home().parent / "engine" / "gemini-cli" / "gemini.cmd")
    for name in ("agy", "gemini"):
        hit = shutil.which(name) or next((str(p) for p in places[name] if p.is_file()), "")
        if hit:
            return name, hit
    return "", ""


def _kill(proc) -> None:
    try:
        if WIN:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True, timeout=10)
        else:
            os.killpg(proc.pid, signal.SIGKILL)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def _envelope(out: str) -> dict:
    out = (out or "").strip()
    for cand in [out] + [ln for ln in reversed(out.splitlines()) if ln.strip().startswith("{")]:
        try:
            obj = json.loads(cand)
            if isinstance(obj, dict):
                return obj
        except Exception:
            continue
    return {}


def ask(question: str, timeout: int = TIMEOUT) -> Dict[str, Any]:
    """{"ok": True, "answer", "tool"} or {"ok": False, "error", "plain"}."""
    name, path = find()
    if not name:
        return {"ok": False, "error": "not_installed", "plain": "Google's command-line tool (agy or gemini) is not installed on this computer."}
    question = str(question or "").strip()
    if not question:
        return {"ok": False, "error": "empty", "plain": "There was nothing to ask."}
    if name == "agy":
        argv = [path, "--output-format", "json", "--print-timeout", "120s", "--sandbox"]
    else:
        argv = [path, "-p", "Answer the request given on standard input, in plain text.", "-o", "json", "--approval-mode", "plan"]
    work = tempfile.mkdtemp(prefix="qosha-gemini-")
    try:
        kw = {"creationflags": getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)} if WIN else {"start_new_session": True}
        proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                                errors="replace", cwd=work, shell=False, **kw)
        try:
            out, err = proc.communicate(question, timeout=timeout)
        except subprocess.TimeoutExpired:
            _kill(proc)
            return {"ok": False, "error": "timeout", "plain": "Gemini took too long to answer."}
    except OSError as exc:
        return {"ok": False, "error": "start", "plain": "Google's command-line tool could not start (%s)." % type(exc).__name__}
    finally:
        shutil.rmtree(work, ignore_errors=True)
    env = _envelope(out)
    text = str(env.get("response") or env.get("result") or "").strip()
    low = ((err or "") + " " + (out or "")).lower()
    if not text or env.get("is_error") or env.get("error"):
        # Google refusing the TOOL (seen 17 Nov with gemini-cli 0.68.0: the sign-in is fine, the client is turned away)
        # is not "signed out": checked before the sign-in words, because Google's message also says "auth".
        if "ineligibletier" in low.replace(" ", "").replace("_", "") or "no longer supported" in low:
            return {"ok": False, "error": "tool_refused", "plain": (
                "Google no longer lets this tool use a personal Gemini plan. Qosha needs Google's newer tool; "
                "ask Qosha to set it up.")}
        if any(w in low for w in ("sign in", "signin", "log in", "login", "unauthenticated", "not authenticated", "auth", "credential")):
            return {"ok": False, "error": "signed_out", "plain": "Gemini is not signed in on this computer yet."}
        return {"ok": False, "error": "no_answer", "plain": "Gemini gave no answer just now."}
    return {"ok": True, "answer": text[:20000], "tool": name}


def _marker() -> Path:
    d = _home() / "qosha"
    d.mkdir(parents=True, exist_ok=True)
    return d / "gemini_cli.json"


def connected() -> bool:
    """What the last check found (no call to Google here)."""
    try:
        return json.loads(_marker().read_text(encoding="utf-8")).get("ok") is True and bool(find()[0])
    except Exception:
        return False


def check() -> Dict[str, Any]:
    """One very short question through the tool: it answers only when the person's Google sign-in works."""
    name, _ = find()
    r = ask("Reply with the single word: OK", timeout=90) if name else {"ok": False, "error": "not_installed",
                                                                         "plain": "Google's command-line tool is not installed yet."}
    try:
        _marker().write_text(json.dumps({"ok": bool(r.get("ok")), "tool": name, "at": time.time()}), encoding="utf-8")
    except OSError:
        pass
    return {"ok": bool(r.get("ok")), "tool": name, "error": r.get("error") or "", "plain": r.get("plain") or ""}


def forget() -> None:
    """Disconnect in Qosha: Qosha stops using the tool (the tool's own Google sign-in is the person's and stays)."""
    try:
        _marker().write_text(json.dumps({"ok": False, "at": time.time()}), encoding="utf-8")
    except OSError:
        pass


def open_signin() -> Dict[str, Any]:
    """Opens the tool in a terminal window of the person's own, where its first run shows Google's sign-in (it opens
    their browser). Qosha types nothing there."""
    name, path = find()
    if not name:
        return {"ok": False, "error": "not_installed", "plain": "Google's command-line tool is not installed yet."}
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["/usr/bin/open", "-a", "Terminal", path])
        elif WIN:
            subprocess.Popen(["cmd", "/c", "start", "Sign in to Gemini", path], shell=False)
        else:
            return {"ok": False, "error": "manual", "plain": "Open a terminal and run: %s" % name}
    except OSError as exc:
        return {"ok": False, "error": "open", "plain": "The sign-in window could not be opened (%s)." % type(exc).__name__}
    return {"ok": True, "tool": name}
