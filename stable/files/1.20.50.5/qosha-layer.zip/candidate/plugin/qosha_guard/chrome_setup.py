"""Connect Qosha to the person's own Chrome (mc21): the files Chrome needs, on macOS and Windows.

* The Qosha extension's files: shipped in the plugin (plugin/chrome/extension), copied to <home>/qosha/chrome-extension,
  the folder the person picks in Chrome's "Load unpacked". Only Qosha's own file names are written there.
* Qosha's native host: a launcher (<home>/qosha/chrome/qosha-chrome-host[.bat]) that runs plugin/chrome/
  qosha_chrome_host.py with Qosha's own Python, and its registration for Chrome (name ai.qosha.chrome; only Qosha's
  extension may start it):
  - macOS: ~/Library/Application Support/Google/Chrome/NativeMessagingHosts/ai.qosha.chrome.json
  - Windows: the per-user registry value HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\ai.qosha.chrome (no admin)
  A throwaway Chrome started with --user-data-dir=<dir> (tests) reads <dir>/NativeMessagingHosts on macOS instead.
Nothing here reads Chrome's own files, cookies or passwords. Every function is safe to run again (it rewrites the same
bytes); the launcher is rewritten at every start, because Qosha's Python moves with updates.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sys
from pathlib import Path
from typing import Dict, Optional

HOST_NAME = "ai.qosha.chrome"
EXT_ID = "ccnlbpfeglcmgfbhlppinokahnjcbcmb"
EXT_ORIGIN = "chrome-extension://%s/" % EXT_ID
# The Chrome Web Store copy (store-ID slice, 27 Nov 2026; Item ID from Ren's draft upload ~15:00 MST). The store gives it
# its own ID (Qosha has no private key for ccnlbp...), so Qosha's link to Chrome accepts both.
STORE_ID = "nicpbbikchnobjpfdkileifdfbphoncm"
EXT_IDS = (EXT_ID, STORE_ID)
EXT_ORIGINS = tuple("chrome-extension://%s/" % i for i in EXT_IDS)
# The store builds this Qosha knows (each one's baked code digest; chrome-store/package/build_store_zip.py --bake). The
# store updates Chrome by itself, so a store build is added HERE, in a Qosha release, before it is submitted; one Qosha
# doesn't know stays cut off (fail closed).
STORE_DIGESTS = (
    "c62359b9773260a73da57f0fbcb602e7e73af915827c82fc0f6072abbc52cad0",   # 1.0.1 (the popup extension of 1.20.50.x, canonical manifest)
)
PLUGIN = Path(__file__).resolve().parent.parent
EXT_SRC = PLUGIN / "chrome" / "extension"
HOST_PY = PLUGIN / "chrome" / "qosha_chrome_host.py"
WIN_KEY = r"Software\Google\Chrome\NativeMessagingHosts\%s" % HOST_NAME


def _home() -> Path:
    try:
        from . import store
        return Path(store.engine_home())
    except ImportError:
        try:
            import importlib.util as _u
            spec = _u.spec_from_file_location("qosha_chrome_store", os.path.join(os.path.dirname(__file__), "store.py"))
            m = _u.module_from_spec(spec)
            spec.loader.exec_module(m)
            return Path(m.engine_home())
        except Exception:
            return Path(os.environ.get("HERMES_HOME") or "~/.hermes").expanduser()
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or "~/.hermes").expanduser()


def ext_dir(home: Optional[Path] = None) -> Path:
    return (home or _home()) / "qosha" / "chrome-extension"


def host_dir(home: Optional[Path] = None) -> Path:
    return (home or _home()) / "qosha" / "chrome"


def _write(path: Path, data: bytes, mode: int = 0o600) -> bool:
    """Write when different; True when the file changed."""
    try:
        if path.is_file() and not path.is_symlink() and path.read_bytes() == data:
            return False
    except OSError:
        pass
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        path.unlink()
    tmp = path.with_name(path.name + ".qosha-tmp")
    tmp.write_bytes(data)
    try:
        os.chmod(tmp, mode)
    except OSError:
        pass
    os.replace(tmp, path)
    return True


CODE_FILES = ("manifest.json", "sw.js", "banner.js", "popup.html", "popup.js")
_UNBAKED = b"const CODE = '__QOSHA_CODE__';"
_BAKED = re.compile(rb"const CODE = '[0-9a-f]{64}';")


def canon_manifest(b: bytes) -> bytes:
    """manifest.json as the digest sees it (store-ID review r1, Gemini H1): the Chrome Web Store rewrites the installed
    manifest (adds "update_url" and "key", reformats it), so the digest is of its parsed content without those two
    fields, keys sorted, written compactly. Every other field (permissions, scripts, hosts...) still counts."""
    m = json.loads(b.decode("utf-8"))
    if isinstance(m, dict):
        m.pop("key", None)
        m.pop("update_url", None)
    return json.dumps(m, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def code_hash(folder: Optional[Path] = None) -> str:
    """The digest the extension reports of its own code (sw.js CODE / filesHash): its files, with sw.js's baked CODE
    line put back to the placeholder. Of the shipped files (EXT_SRC) by default. "" when unreadable."""
    import hashlib
    try:
        d = Path(folder) if folder else EXT_SRC
        lines = ""
        for f in CODE_FILES:
            b = (d / f).read_bytes()
            if f == "sw.js":
                b = _BAKED.sub(lambda m: _UNBAKED, b, count=1)
            elif f == "manifest.json":
                b = canon_manifest(b)
            lines += "%s:%s\n" % (f, hashlib.sha256(b).hexdigest())
        return hashlib.sha256(lines.encode()).hexdigest()
    except Exception:
        return ""


def known_codes() -> set:
    """The code digests Qosha's relay accepts: the copy this Qosha ships, and the store builds it knows."""
    return {c for c in {code_hash()} | set(STORE_DIGESTS) if c}


def copy_extension(home: Optional[Path] = None) -> Dict[str, object]:
    """Copy the extension's files (only names the plugin ships) into the folder Chrome loads. sw.js gets the digest of
    the shipped files written into it, so the code Chrome runs can say which code it is (a cached older worker can't)."""
    dst = ext_dir(home)
    changed = []
    code = code_hash(EXT_SRC)
    if not code:
        raise RuntimeError("Qosha's extension files are missing.")
    for src in sorted(EXT_SRC.rglob("*")):
        if not src.is_file() or src.name.startswith(".") or "__pycache__" in src.parts:
            continue
        rel = src.relative_to(EXT_SRC)
        data = src.read_bytes()
        if str(rel) == "sw.js":
            if data.count(_UNBAKED) != 1:
                raise RuntimeError("Qosha's extension worker has no code marker.")
            data = data.replace(_UNBAKED, b"const CODE = '" + code.encode() + b"';", 1)
        if _write(dst / rel, data, 0o644):
            changed.append(str(rel))
    return {"folder": str(dst), "changed": changed}


def launcher(home: Optional[Path] = None, python: Optional[str] = None) -> Path:
    """The program Chrome starts: Qosha's Python on the host script, with the home baked in."""
    home = home or _home()
    py = python or sys.executable
    d = host_dir(home)
    if os.name == "nt":
        path = d / "qosha-chrome-host.bat"
        body = '@echo off\r\n"%s" -I -B "%s" --home "%s" %%*\r\n' % (py, HOST_PY, home)
        _write(path, body.encode("utf-8"), 0o700)
    else:
        path = d / "qosha-chrome-host"
        q = lambda s: "'" + str(s).replace("'", "'\"'\"'") + "'"
        body = "#!/bin/sh\nexec %s -I -B %s --home %s \"$@\"\n" % (q(py), q(HOST_PY), q(home))
        _write(path, body.encode("utf-8"), 0o700)
    return path


def manifest(path_to_launcher: Path) -> bytes:
    return (json.dumps({"name": HOST_NAME, "description": "Qosha", "path": str(path_to_launcher), "type": "stdio",
                        "allowed_origins": list(EXT_ORIGINS)}, indent=2) + "\n").encode("utf-8")


def mac_hosts_dir(user_data_dir: Optional[str] = None) -> Path:
    if user_data_dir:
        return Path(user_data_dir) / "NativeMessagingHosts"
    return Path("~/Library/Application Support/Google/Chrome/NativeMessagingHosts").expanduser()


def register_host(home: Optional[Path] = None, user_data_dir: Optional[str] = None, python: Optional[str] = None,
                  winreg_mod=None) -> Dict[str, object]:
    """Write the launcher and Chrome's registration of Qosha's host. Returns what was written."""
    home = home or _home()
    lp = launcher(home, python)
    data = manifest(lp)
    own = host_dir(home) / (HOST_NAME + ".json")
    _write(own, data, 0o644)
    out: Dict[str, object] = {"launcher": str(lp), "manifest": str(own)}
    if os.name == "nt" and not user_data_dir:
        wr = winreg_mod
        if wr is None:
            import winreg as wr  # type: ignore
        k = wr.CreateKey(wr.HKEY_CURRENT_USER, WIN_KEY)
        try:
            wr.SetValueEx(k, "", 0, wr.REG_SZ, str(own))
        finally:
            wr.CloseKey(k)
        out["registry"] = "HKCU\\" + WIN_KEY
    else:
        reg = mac_hosts_dir(user_data_dir) / (HOST_NAME + ".json")
        _write(reg, data, 0o644)
        out["registration"] = str(reg)
    return out


def ensure(home: Optional[Path] = None) -> Optional[Dict[str, object]]:
    """At every start, for a person who connected Chrome before: refresh the launcher and the extension files."""
    home = home or _home()
    if not (host_dir(home) / (HOST_NAME + ".json")).is_file():
        return None
    try:
        return {"host": register_host(home), "extension": copy_extension(home)}
    except Exception as e:
        return {"error": type(e).__name__}


def setup(home: Optional[Path] = None) -> Dict[str, object]:
    """Qosha's one-time setup step: everything Qosha can do itself before the person loads the extension."""
    home = home or _home()
    ext = copy_extension(home)
    host = register_host(home)
    return {"extension_folder": ext["folder"], "host": host}


def open_extensions_page() -> bool:
    """Open Chrome's Extensions page in the person's Chrome (they turn on Developer mode and press Load unpacked)."""
    import subprocess
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", "-a", "Google Chrome", "chrome://extensions"], stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
            return True
        if os.name == "nt":
            from .ask import chrome_path
            exe = chrome_path()
            if exe:
                subprocess.Popen([exe, "chrome://extensions"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
    except Exception:
        pass
    return False


def show_folder(home: Optional[Path] = None) -> bool:
    import subprocess
    d = ext_dir(home)
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", str(d)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        if os.name == "nt":
            os.startfile(str(d))  # type: ignore[attr-defined]
            return True
    except Exception:
        pass
    return False


def remove(home: Optional[Path] = None, user_data_dir: Optional[str] = None, winreg_mod=None) -> None:
    """Take Qosha's link to Chrome away (the extension itself is removed in chrome://extensions by the person)."""
    home = home or _home()
    own = host_dir(home) / (HOST_NAME + ".json")
    if os.name == "nt" and not user_data_dir:
        wr = winreg_mod
        if wr is None:
            import winreg as wr  # type: ignore
        try:
            wr.DeleteKey(wr.HKEY_CURRENT_USER, WIN_KEY)
        except OSError:
            pass
    else:
        reg = mac_hosts_dir(user_data_dir) / (HOST_NAME + ".json")
        try:
            if reg.is_file() and json.loads(reg.read_text(encoding="utf-8")).get("path", "").startswith(str(host_dir(home))):
                reg.unlink()
        except (OSError, ValueError):
            pass
    for p in (own, host_dir(home) / "qosha-chrome-host", host_dir(home) / "qosha-chrome-host.bat"):
        try:
            p.unlink()
        except OSError:
            pass
