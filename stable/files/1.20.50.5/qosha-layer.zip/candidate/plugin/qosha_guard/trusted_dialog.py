"""Qosha's trusted approval window: every Allow card is shown by the dashboard process itself as a small native window
(Ren, cards 23 Nov 2026 ~19:00 MST: "Go (Recommended)", "Keep Always allow (Recommended)"; council option B).

Why: a card drawn inside the app's pages can be pressed, hidden or reworded by any script those pages run, so every
page edit needed a card. A window the dashboard opens itself, answered over a pipe only the dashboard holds, can't be
reached by a page at all.

How (threats T4-T7, council H1/H3 in features/trusted-surface/DESIGN.md):
- Mac: /usr/bin/osascript -l JavaScript, script from this file's constant (-e), the card as JSON on stdin.
  Windows: %SystemRoot%\\System32\\WindowsPowerShell\\v1.0\\powershell.exe -NoProfile -NoLogo -NonInteractive with the
  script from this file (-EncodedCommand), the card as JSON on stdin. Both with a minimal environment.
- The title, the button words and the fact labels come from this file's constants; only the step's own text and the
  facts' values come from the caller, shown as plain text with control and direction characters made visible.
- Facts (recipient, amount, target, length) are pinned ABOVE the scrolling text. Over the size cap there is no Allow
  (the text is never cut while Allow is offered).
- Buttons: Decline (the default: Enter and Esc decline), Allow this time, Always allow for this kind (only when the
  caller says the kind may have it). Allow buttons wake up after ~1 s.
- The answer is the child's one stdout line, carrying the card's one-time nonce; anything else (no line, two lines,
  another nonce, a non-zero exit, a timeout, no screen) is Decline. The returned Answer is bound to the nonce and the
  sha256 of the exact payload the caller will run (H1): the executor checks both.
- One window at a time (a process-wide lock); pending() tells the desktop-control tools to pause (H6) and the updater
  to wait (T11).
"""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import re
import secrets
import subprocess
import sys
import threading
import time
import unicodedata
from dataclasses import dataclass, field
from typing import Optional, Sequence

log = logging.getLogger("qosha.trusted_dialog")

SHOW_MAX = 100_000        # UTF-16 units (what the pages counted); above it there is no Allow (refused, never cut)
SHOW_HEAD = 4_000         # what an over-cap window still shows, so the person sees what was refused
FACT_MAX = 2000           # one critical pinned fact; a longer one means no Allow (a fact is never cut)
PIN_MAX = 10           # pinned facts shown in the window's fixed area; more: listed first in the scrolling text
PIN_UNITS = 1200       # ... or more than this many characters in all (about ten lines on any screen: TS-R2 G-09)
FACTS_MAX = 8
ROW_MAX = 120             # a pinned row that is not a critical fact: one short line, the rest in the text below
# ask.py's row labels that are critical facts (pinned first, never cut)
_CRITICAL = {"to": "to", "recipient": "to", "recipients": "to", "cc": "to", "bcc": "to", "amount": "amount",
             "total": "amount", "target": "target", "file": "target", "path": "target", "website": "target",
             "from": "from", "account": "account", "chat": "chat", "para": "to", "valor": "amount"}
TIMEOUT_S = 30 * 60       # no answer in 30 minutes = Decline
WAKE_S = 1.0              # Allow buttons wake up after this
CHOICES = ("decline", "once", "always")

# ---- words (server constants; a caller picks a kind, never writes the title or the buttons) -----------------------
_WORDS = {
    "en": {
        "buttons": ("Decline", "Allow this time", "Always allow this kind (also in scheduled runs)"),
        "window": "Qosha approval",
        "too_long": ("This step is {n:,} characters long, above what Qosha can show for approval ({cap:,}). It can't "
                     "be allowed from here: choose Decline, then ask Qosha to break it into smaller steps. The "
                     "beginning is shown below."),
        "fact_too_long": "A detail of this step is too long to show in full, so it can't be allowed from here.",
        "all_listed": "All {n} are listed first in the text below. Scroll to check each one.",
        "length": "Length",
        "continues": "(continues in the text below)",
        "chars": "{n:,} characters",
        "kinds": {
            "send": "Qosha wants to send something",
            "pay": "Qosha wants to make a payment",
            "delete": "Qosha wants to delete something",
            "share": "Qosha wants to share something",
            "run": "Qosha wants to run a step on this computer",
            "self": "Qosha wants to change its own safety code or approval settings",
            "browser_profile": "Qosha wants to use your own Chrome profile",
            "settings": "Qosha wants to change what it may do without asking",
            "trust_on": "Turn on Trust mode (Qosha does what you ask without asking first)",
            "desktop": "Qosha wants to control this computer's screen",
            "chrome": "Qosha wants to change how it uses your Chrome",
            "other": "Qosha is asking for your approval",
        },
        "labels": {"action": "Action", "to": "To", "cc": "Cc", "bcc": "Bcc", "guests": "Guests",
                   "shared_with": "Shared with", "forward_to": "Forward to", "channel": "Channel", "amount": "Amount",
                   "target": "Target", "object": "Item", "from": "From", "account": "Account", "chat": "Chat"},
    },
    "pt-br": {
        "buttons": ("Recusar", "Permitir desta vez", "Sempre permitir este tipo (também em tarefas agendadas)"),
        "window": "Aprovação do Qosha",
        "too_long": ("Esta etapa tem {n:,} caracteres, acima do que o Qosha consegue mostrar para aprovação ({cap:,}). "
                     "Ela não pode ser permitida aqui: escolha Recusar e peça ao Qosha para dividi-la em etapas menores. "
                     "O começo aparece abaixo."),
        "fact_too_long": "Um detalhe desta etapa é longo demais para aparecer inteiro, então ela não pode ser permitida aqui.",
        "all_listed": "Todos os {n} estão listados primeiro no texto abaixo. Role para conferir cada um.",
        "length": "Tamanho",
        "continues": "(continua no texto abaixo)",
        "chars": "{n:,} caracteres",
        "kinds": {
            "send": "O Qosha quer enviar algo",
            "pay": "O Qosha quer fazer um pagamento",
            "delete": "O Qosha quer apagar algo",
            "share": "O Qosha quer compartilhar algo",
            "run": "O Qosha quer executar uma etapa neste computador",
            "self": "O Qosha quer mudar seu próprio código de segurança ou as configurações de aprovação",
            "browser_profile": "O Qosha quer usar o seu próprio perfil do Chrome",
            "settings": "O Qosha quer mudar o que pode fazer sem perguntar",
            "trust_on": "Ligar o modo Confiança (o Qosha faz o que você pede sem perguntar antes)",
            "desktop": "O Qosha quer controlar a tela deste computador",
            "chrome": "O Qosha quer mudar como usa o seu Chrome",
            "other": "O Qosha está pedindo sua aprovação",
        },
        "labels": {"action": "Ação", "to": "Para", "cc": "Cc", "bcc": "Cco", "guests": "Convidados",
                   "shared_with": "Compartilhado com", "forward_to": "Encaminhar para", "channel": "Canal",
                   "amount": "Valor", "target": "Alvo", "object": "Item", "from": "De", "account": "Conta", "chat": "Conversa"},
    },
}
# the roles pinned first, never cut, never limited in number (a "To 2 · Cc 1 · Bcc 40" line above them: council RC1)
ROLE_LABELS = ("to", "cc", "bcc", "guests", "shared_with", "forward_to", "channel", "chat", "amount", "target", "object", "from",
               "account")
_PEOPLE = ("to", "cc", "bcc", "guests", "shared_with", "forward_to")
NEVER_ALWAYS = frozenset({"self", "settings", "trust_on", "chrome"})   # safety code and approval settings: every time


def units(text: str) -> int:
    """Length as the pages counted it (UTF-16 code units)."""
    return len(text.encode("utf-16-le", "surrogatepass")) // 2


def visible(text) -> str:
    """Plain text with nothing hidden: control, format (bidi overrides, zero-width), separator, private-use,
    unassigned and unpaired surrogate characters become a visible escape such as <U+202E>; tabs and newlines stay
    (CR LF -> LF)."""
    text = str(text).replace("\r\n", "\n")
    out = []
    for ch in text:
        o = ord(ch)
        if ch in "\n\t":
            out.append(ch)
        elif 0xD800 <= o <= 0xDFFF or unicodedata.category(ch) in ("Cc", "Cf", "Zl", "Zp", "Co", "Cn", "Cs"):
            out.append("<U+%04X>" % o)
        else:
            out.append(ch)
    return "".join(out)


def payload_sha(payload) -> str:
    """sha256 of the exact payload the caller will run (canonical JSON for dicts/lists, the bytes for bytes)."""
    if isinstance(payload, (bytes, bytearray)):
        raw = bytes(payload)
    elif isinstance(payload, str):
        raw = payload.encode("utf-8", "surrogatepass")
    else:
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8",
                                                                                                   "surrogatepass")
    return hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True)
class Answer:
    choice: str                   # "decline" | "once" | "always"
    nonce: str
    sha256: str                   # the payload this answer is for
    kind: str
    reason: str = ""              # why it is a decline when nobody chose it (no screen, timeout, bad output ...)
    at: float = field(default_factory=time.time)

    @property
    def allowed(self) -> bool:
        return self.choice in ("once", "always")


# ---- the window programs (constants; never read from a file) ------------------------------------------------------
# The marker comments /*QOSHA-TEST-HOOK*/ and #QOSHA-TEST-HOOK are only comments here; the background test harness
# replaces them in its own copy (invisible window, no activation, scripted clicks). Nothing in the product reads them.
_JXA = r"""
ObjC.import('Cocoa');
function rd(){var d=$.NSFileHandle.fileHandleWithStandardInput.readDataToEndOfFile;
 return $.NSString.alloc.initWithDataEncoding(d,$.NSUTF8StringEncoding).js;}
function wr(o){var s=$(JSON.stringify(o)+"\n");
 $.NSFileHandle.fileHandleWithStandardOutput.writeData(s.dataUsingEncoding($.NSUTF8StringEncoding));}
function run(argv){
 var c=JSON.parse(rd()); var ACTIVATE=true; var app=$.NSApplication.sharedApplication;
 app.setActivationPolicy($.NSApplicationActivationPolicyAccessory);
 var a=$.NSAlert.alloc.init; a.messageText=c.title; a.informativeText=c.facts; a.alertStyle=$.NSAlertStyleWarning;
 var bd=a.addButtonWithTitle(c.buttons[0]); bd.keyEquivalent="\r";
 var bs=[];
 if(c.allow){var b1=a.addButtonWithTitle(c.buttons[1]); b1.keyEquivalent=""; bs.push(b1);
  if(c.always){var b2=a.addButtonWithTitle(c.buttons[2]); b2.keyEquivalent=""; bs.push(b2);}}
 for(var i=0;i<bs.length;i++){bs[i].enabled=false;}
 var W=620,H=340; var sv=$.NSScrollView.alloc.initWithFrame($.NSMakeRect(0,0,W,H));
 sv.hasVerticalScroller=true; sv.hasHorizontalScroller=false; sv.borderType=$.NSBezelBorder;
 var tv=$.NSTextView.alloc.initWithFrame($.NSMakeRect(0,0,W,H));
 tv.editable=false; tv.selectable=true; tv.richText=false; tv.importsGraphics=false;
 tv.verticallyResizable=true; tv.horizontallyResizable=false; tv.minSize=$.NSMakeSize(0,H);
 tv.maxSize=$.NSMakeSize(1e7,1e7); tv.textContainer.containerSize=$.NSMakeSize(W,1e7);
 tv.textContainer.widthTracksTextView=true; tv.font=$.NSFont.userFixedPitchFontOfSize(12); tv.string=c.text;
 sv.documentView=tv; a.accessoryView=sv; a.window.title=c.window; a.layout;
 a.window.level=$.NSModalPanelWindowLevel;
 var wake=$.NSTimer.timerWithTimeIntervalRepeatsBlock(c.wake,false,function(t){
  for(var i=0;i<bs.length;i++){bs[i].enabled=true;}});
 $.NSRunLoop.currentRunLoop.addTimerForMode(wake,$.NSModalPanelRunLoopMode);
 /*QOSHA-TEST-HOOK*/
 if(ACTIVATE){app.activateIgnoringOtherApps(true);}
 var r=a.runModal; var ch="decline";
 if(c.allow&&r==1001){ch="once";} else if(c.allow&&c.always&&r==1002){ch="always";}
 wr({nonce:c.nonce,choice:ch}); return "";
}
"""

_PS = r"""
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$si=[Console]::OpenStandardInput(); $ms=New-Object IO.MemoryStream; $si.CopyTo($ms)
$c=[Text.Encoding]::UTF8.GetString($ms.ToArray()) | ConvertFrom-Json
[Windows.Forms.Application]::EnableVisualStyles()
$f=New-Object Windows.Forms.Form; $f.Text=$c.window; $f.Width=760; $f.Height=600; $f.TopMost=$true
$f.StartPosition='CenterScreen'; $f.MinimizeBox=$false; $f.MaximizeBox=$false; $f.ShowInTaskbar=$true
$t=New-Object Windows.Forms.Label; $t.Text=$c.title; $t.Dock='Top'; $t.Height=34; $t.AutoEllipsis=$false
$t.Font=New-Object Drawing.Font('Segoe UI',11,[Drawing.FontStyle]::Bold); $t.Padding=New-Object Windows.Forms.Padding(8,8,8,0)
$p=New-Object Windows.Forms.TextBox; $p.Multiline=$true; $p.ReadOnly=$true; $p.Dock='Top'
$wl=0; foreach($ln in ($c.facts -split "`n")){ $wl += [Math]::Max(1, [Math]::Ceiling($ln.Length / 95)) }
$p.Height=[Math]::Min(420, [Math]::Max(96, 20 * ($wl + 1)))
$p.ScrollBars='Vertical'; $p.MaxLength=0; $p.Text=$c.facts.Replace("`n","`r`n"); $p.TabStop=$false
$b=New-Object Windows.Forms.TextBox; $b.Multiline=$true; $b.ReadOnly=$true; $b.Dock='Fill'; $b.ScrollBars='Both'
$b.WordWrap=$true; $b.MaxLength=0; $b.Font=New-Object Drawing.Font('Consolas',10); $b.Text=$c.text.Replace("`n","`r`n")
$b.TabStop=$false
$r=New-Object Windows.Forms.FlowLayoutPanel; $r.Dock='Bottom'; $r.Height=48; $r.FlowDirection='RightToLeft'
$script:ch='decline'
$bd=New-Object Windows.Forms.Button; $bd.Text=$c.buttons[0]; $bd.AutoSize=$true
$bd.Add_Click({$script:ch='decline'; $f.Close()}); $r.Controls.Add($bd)
$bs=@()
if($c.allow){
 $b1=New-Object Windows.Forms.Button; $b1.Text=$c.buttons[1]; $b1.AutoSize=$true; $b1.Enabled=$false
 $b1.Add_Click({$script:ch='once'; $f.Close()}); $r.Controls.Add($b1); $bs+=$b1
 if($c.always){$b2=New-Object Windows.Forms.Button; $b2.Text=$c.buttons[2]; $b2.AutoSize=$true; $b2.Enabled=$false
  $b2.Add_Click({$script:ch='always'; $f.Close()}); $r.Controls.Add($b2); $bs+=$b2}}
$f.Controls.Add($b); $f.Controls.Add($p); $f.Controls.Add($t); $f.Controls.Add($r)
$f.AcceptButton=$bd; $f.CancelButton=$bd
$w=New-Object Windows.Forms.Timer; $w.Interval=[int]($c.wake*1000)
$w.Add_Tick({$w.Stop(); foreach($x in $bs){$x.Enabled=$true}})
$f.Add_Shown({$bd.Focus(); $w.Start(); $f.Activate()})
#QOSHA-TEST-HOOK
[void]$f.ShowDialog()
$o=@{nonce=[string]$c.nonce; choice=[string]$script:ch} | ConvertTo-Json -Compress
[Console]::Out.Write($o + "`n")
"""


def _sysroot() -> str:
    """The Windows folder as the OS reports it (never the inherited SystemRoot variable: TS-G-13)."""
    try:
        import ctypes
        buf = ctypes.create_unicode_buffer(520)
        n = ctypes.windll.kernel32.GetSystemWindowsDirectoryW(buf, 520)
        if 0 < n < 520 and os.path.isdir(buf.value):
            return buf.value
    except Exception:
        pass
    return r"C:\Windows"


def _ps_exe() -> str:
    return os.path.join(_sysroot(), "System32", "WindowsPowerShell", "v1.0", "powershell.exe")


def _argv(platform: Optional[str] = None, script: Optional[str] = None) -> list:
    """The window program's command line: the module's own constant program (`script` only for bring_forward's
    one-line helper, never a caller's)."""
    platform = platform or sys.platform
    if platform == "darwin":
        return ["/usr/bin/osascript", "-l", "JavaScript", "-e", _JXA if script is None else script]
    if platform.startswith("win"):
        enc = base64.b64encode((_PS if script is None else script).encode("utf-16-le")).decode("ascii")
        return [_ps_exe(), "-NoProfile", "-NoLogo", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                "-EncodedCommand", enc]
    raise OSError("Qosha's approval window is available on Mac and Windows only")


def _env(platform: Optional[str] = None) -> dict:
    """A minimal environment: nothing the assistant could have set reaches the window program (no PATH tricks, no
    PowerShell module path, no profile)."""
    platform = platform or sys.platform
    keep = {}
    if platform.startswith("win"):
        root = _sysroot()
        for k in ("SystemRoot", "SystemDrive", "USERPROFILE", "HOMEDRIVE", "HOMEPATH", "USERNAME", "USERDOMAIN",
                  "LOCALAPPDATA", "APPDATA", "TEMP", "TMP", "COMPUTERNAME", "NUMBER_OF_PROCESSORS",
                  "PROCESSOR_ARCHITECTURE", "OS"):
            if os.environ.get(k):
                keep[k] = os.environ[k]
        keep["SystemRoot"] = root
        keep["PATH"] = os.path.join(root, "System32") + ";" + root
        keep["PSModulePath"] = os.path.join(root, "System32", "WindowsPowerShell", "v1.0", "Modules")
        keep["PSExecutionPolicyPreference"] = "Bypass"
    else:
        for k in ("HOME", "USER", "LOGNAME", "TMPDIR", "__CF_USER_TEXT_ENCODING"):
            if os.environ.get(k):
                keep[k] = os.environ[k]
        keep["PATH"] = "/usr/bin:/bin:/usr/sbin:/sbin"
        keep["LANG"] = "en_US.UTF-8"
    return keep


def _words(lang: Optional[str]) -> dict:
    lang = (lang or "en").lower()
    return _WORDS["pt-br" if lang.startswith("pt") else "en"]


def build_card(kind: str, text: str, facts: Sequence = (), *, always: bool = False, lang: str = "en",
               nonce: str = "", allow: bool = True) -> dict:
    """The JSON the window program reads. Title, buttons and labels from the constants above; values made visible."""
    w = _words(lang)
    kind = kind if kind in w["kinds"] else "other"
    text = "" if text is None else str(text)
    n = units(text)
    allow, notice = bool(allow), ""
    crit, other, details, counts = [], [], [], {}
    for item in list(facts):
        try:
            label, value = item
        except (TypeError, ValueError):
            continue
        label, value = str(label), visible(value)
        key = _CRITICAL.get(label[1:].strip().lower()) if label.startswith("@") else label
        if key in w["labels"] and key != "action":
            # where it goes / what it moves: pinned, never cut, no count limit; one value over the limit = no Allow
            if units(value) > FACT_MAX or "\n" in value:
                allow, notice = False, w["fact_too_long"]
                value = value.replace("\n", " ")[:FACT_MAX] + " ..."
            crit.append("%s: %s" % (w["labels"][key], value))
            n_here = (len([x for x in re.split(r"[,;]", value) if x.strip()]) or 1) if key in _PEOPLE else 1
            counts[key] = counts.get(key, 0) + n_here
        elif label.startswith("@"):
            if len(other) >= FACTS_MAX:
                details.append("%s: %s" % (visible(label[1:])[:60], value))
                continue                                  # extra rows go to the text, never a reason to refuse
            lab = visible(label[1:])[:60]
            flat = value.replace("\n", " \u23ce ")
            if units(flat) > ROW_MAX:
                details.append("%s: %s" % (lab, value))
                flat = flat[:ROW_MAX] + " " + w["continues"]
            other.append("%s: %s" % (lab, flat))
        # unknown plain labels are never shown: never caller words
    banner = " \u00b7 ".join("%s %d" % (w["labels"][k], counts[k]) for k in ROLE_LABELS if k in counts)
    if banner:
        crit.insert(0, banner)
    pinned = crit[1:] if banner else crit
    listed = []
    if len(pinned) > PIN_MAX:
        # too many to pin on any screen (TS-R-G-09 / TS-R-3): the counts stay fixed at the top, and every one of them
        # is listed first in the scrolling text, in the order given
        listed, pinned = pinned, [w["all_listed"].format(n=len(pinned))]
    elif units("\n".join(pinned)) > PIN_UNITS:
        # too long to pin (TS-R2 G-09): the long ones are listed first in the scrolling text, the short ones stay
        listed = [x for x in pinned if units(x) > ROW_MAX]
        pinned = [x for x in pinned if units(x) <= ROW_MAX] + [w["all_listed"].format(n=len(listed))]
    lines = crit[:1] + sorted(pinned, key=len) + other if banner else sorted(pinned, key=len) + other
    lines.append("%s: %s" % (w["length"], w["chars"].format(n=n)))
    body = visible(text)
    if details:
        body = "\n".join(details) + "\n\n----\n" + body
    if listed:
        body = "\n".join(listed) + "\n\n----\n" + body
    if n > SHOW_MAX or units(body) + units("\n".join(crit[:1] + pinned + other if banner else pinned + other)) > SHOW_MAX:   # each once
        allow, notice = False, w["too_long"].format(n=n, cap=SHOW_MAX)
        body = visible(text[:SHOW_HEAD]) + "\n..."
    if notice:
        lines.insert(0, notice)
    return {"title": w["kinds"][kind], "window": w["window"], "facts": "\n".join(lines), "text": body,
            "buttons": list(w["buttons"]), "allow": allow, "always": bool(allow and always and kind not in NEVER_ALWAYS),
            "wake": WAKE_S, "nonce": nonce}


# ---- one window at a time (this process and every other Qosha process on this computer) -------------------------
# one state per process, however many times this file is loaded (by path and as a package: TS-M-08)
_SHARED = sys.modules.get("_qosha_trusted_dialog_state")
if _SHARED is None:
    import types as _types
    _SHARED = _types.ModuleType("_qosha_trusted_dialog_state")
    _SHARED.one, _SHARED.plock = threading.Lock(), threading.Lock()
    _SHARED.pending, _SHARED.child, _SHARED.shown = {"n": 0}, {"p": None}, {"at": 0.0}
    sys.modules["_qosha_trusted_dialog_state"] = _SHARED
_one, _plock, _pending, _child = _SHARED.one, _SHARED.plock, _SHARED.pending, _SHARED.child


def _root() -> str:
    """The default home (profiles live under it): one window at a time for every profile on this computer."""
    try:
        from hermes_constants import get_default_hermes_root
        return str(get_default_hermes_root())
    except Exception:
        return os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")


def _dir() -> str:
    d = os.path.join(_root(), "qosha", "approval-window")
    os.makedirs(d, exist_ok=True)
    return d


def pending() -> int:
    """Approval windows open or waiting in this process (nothing outside it can lower it), plus 1 when another
    process holds the window's lock exclusively (a window is open there). Read from the lock itself, never from files
    anyone could write or delete (council RC2). Can't tell = 1 (pause rather than act)."""
    with _plock:
        n = _pending["n"]
    try:
        probe = _CrossLock(shared=True)
        if probe.acquire(0):
            probe.release()
        else:
            n += 1
    except Exception:
        n += 1
    return n


def _win_lock(fh, exclusive: bool = False, unlock: bool = False) -> None:
    """Windows LockFileEx / UnlockFileEx on the file's first byte, never waiting: many SHARED holders together, one
    EXCLUSIVE holder alone (msvcrt.locking is exclusive only). Raises OSError when it can't be taken."""
    import ctypes
    import msvcrt
    from ctypes import wintypes

    class _OVERLAPPED(ctypes.Structure):
        _fields_ = [("Internal", ctypes.c_void_p), ("InternalHigh", ctypes.c_void_p), ("Offset", wintypes.DWORD),
                    ("OffsetHigh", wintypes.DWORD), ("hEvent", wintypes.HANDLE)]

    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    h = wintypes.HANDLE(msvcrt.get_osfhandle(fh.fileno()))
    ov = _OVERLAPPED()
    if unlock:
        k32.UnlockFileEx.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
                                     ctypes.POINTER(_OVERLAPPED)]
        ok = k32.UnlockFileEx(h, 0, 1, 0, ctypes.byref(ov))
    else:
        k32.LockFileEx.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
                                   ctypes.POINTER(_OVERLAPPED)]
        flags = 0x1 | (0x2 if exclusive else 0)     # LOCKFILE_FAIL_IMMEDIATELY | LOCKFILE_EXCLUSIVE_LOCK
        ok = k32.LockFileEx(h, flags, 0, 1, 0, ctypes.byref(ov))
    if not ok:
        raise OSError(ctypes.get_last_error(), "lock not taken")


class _CrossLock:
    # the window holds it EXCLUSIVE for its whole life; each desktop input step holds it SHARED (council RC2)
    """A lock file shared by every Qosha process: one approval window on the screen at a time."""

    def __init__(self, shared: bool = False):
        self.fh = None
        self.shared = shared

    def acquire(self, timeout: float) -> bool:
        end = time.monotonic() + timeout
        path = os.path.join(_dir(), "window.lock")
        while True:
            try:
                fh = open(path, "a+b")                     # not inherited by child programs (PEP 446)
                try:
                    if os.name == "nt":
                        _win_lock(fh, exclusive=not self.shared)   # shared / exclusive like flock (TS-R-G-10)
                    else:
                        import fcntl
                        fcntl.flock(fh.fileno(), (fcntl.LOCK_SH if self.shared else fcntl.LOCK_EX) | fcntl.LOCK_NB)
                    self.fh = fh
                    return True
                except OSError:
                    fh.close()
            except OSError:
                return False
            if time.monotonic() >= end:
                return False
            time.sleep(0.25)

    def release(self) -> None:
        fh, self.fh = self.fh, None
        if fh is None:
            return
        try:
            if os.name == "nt":
                _win_lock(fh, unlock=True)
            else:
                import fcntl
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        except OSError:
            pass
        fh.close()


def _exchange(argv: list, env: dict, data: bytes, timeout: float, cancel=None) -> tuple:
    """Run the window program; (exit code, stdout bytes, reason). Killed on timeout or when `cancel` is set (the card
    was withdrawn)."""
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = 0x08000000          # CREATE_NO_WINDOW: no console flashes; the form still shows
    try:
        p = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env,
                             cwd=os.path.dirname(argv[0]) or None, close_fds=True, **kw)
    except OSError as e:
        return None, b"", "start failed: %s" % e.__class__.__name__
    _child["p"] = p
    try:
        end = time.monotonic() + timeout
        if cancel is None:
            cancel = threading.Event()
        def feed():
            try:
                p.stdin.write(data)
                p.stdin.close()
            except Exception:
                pass
        threading.Thread(target=feed, daemon=True).start()   # a child that stops reading can't hold the deadline
        box = {}
        reader = threading.Thread(target=lambda: box.update(out=p.stdout.read()), daemon=True)
        reader.start()
        threading.Thread(target=lambda: box.update(err=p.stderr.read()), daemon=True).start()
        while p.poll() is None:
            if cancel.is_set():
                p.kill()
                p.wait(10)
                return None, b"", "withdrawn"
            if time.monotonic() >= end:
                raise subprocess.TimeoutExpired(argv[0], timeout)
            time.sleep(0.2)
        reader.join(10)
        return p.returncode, box.get("out", b""), ""
    except subprocess.TimeoutExpired:
        p.kill()
        try:
            p.communicate(timeout=10)
        except Exception:
            pass
        return None, b"", "timeout"
    finally:
        _child["p"] = None
        try:
            if p.poll() is None:
                p.kill()
                p.wait(10)
        except Exception:
            pass


def _parse(rc, out: bytes, nonce: str, allow: bool, always: bool) -> tuple:
    if rc != 0:
        return "decline", "the window program ended with %r" % (rc,)
    lines = [ln for ln in out.decode("utf-8", "replace").splitlines() if ln.strip()]
    if len(lines) != 1:
        return "decline", "unexpected output (%d lines)" % len(lines)
    def pairs(items):
        if len({k for k, _v in items}) != len(items):
            raise ValueError("duplicate key")
        return dict(items)
    try:
        d = json.loads(lines[0], object_pairs_hook=pairs)
    except ValueError:
        return "decline", "unreadable output"
    if not isinstance(d, dict) or set(d) != {"nonce", "choice"}:
        return "decline", "unexpected answer shape"
    if not secrets.compare_digest(str(d.get("nonce")), nonce):
        return "decline", "answer for another card"
    ch = d.get("choice")
    if ch not in CHOICES or (ch != "decline" and not allow) or (ch == "always" and not always):
        return "decline", "choice not offered"
    return ch, ""


def gui_available(platform: Optional[str] = None) -> bool:
    """A screen the person can see: Mac, this process in the person's window session; Windows, an interactive
    desktop (not a service or an SSH session)."""
    platform = platform or sys.platform
    try:
        if platform == "darwin":
            r = subprocess.run(["/bin/launchctl", "managername"], capture_output=True, timeout=5,
                               env={"PATH": "/usr/bin:/bin"})
            return r.stdout.strip() == b"Aqua"
        if platform.startswith("win"):
            import ctypes
            user32 = ctypes.windll.user32
            user32.GetProcessWindowStation.restype = ctypes.c_void_p
            user32.GetUserObjectInformationW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p,
                                                         ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong)]
            h = user32.GetProcessWindowStation()
            if not h:
                return False
            buf = ctypes.create_unicode_buffer(256)
            need = ctypes.c_ulong(0)
            if not user32.GetUserObjectInformationW(h, 2, buf, ctypes.sizeof(buf), ctypes.byref(need)):
                return False
            if buf.value.lower() != "winsta0":
                return False
            sid = ctypes.c_ulong(0)                                # session 0 is the services' session: no person
            if ctypes.windll.kernel32.ProcessIdToSessionId(os.getpid(), ctypes.byref(sid)) and sid.value == 0:
                return False
            return True
    except Exception:
        return False
    return False


def ask(kind: str, text: str, payload, *, facts: Sequence = (), always: bool = False, lang: str = "en",
        timeout: float = TIMEOUT_S, cancel=None, allow: bool = True) -> Answer:
    """Show one approval window and wait for the person (or Decline). Never raises; any failure is a Decline with a
    reason. `payload` is what the caller will run if allowed: the answer carries its sha256 (H1).
    The window program is always this module's own constant."""
    sha = payload_sha(payload)
    nonce = secrets.token_hex(16)
    card = build_card(kind, text, facts, always=always, lang=lang, nonce=nonce, allow=allow)
    kind = kind if kind in _WORDS["en"]["kinds"] else "other"
    cross = _CrossLock()
    counted = False
    try:
        with _plock:
            _pending["n"] += 1
            counted = True
            pass
        deadline = time.monotonic() + timeout
        if not _one.acquire(timeout=max(0.0, timeout)):
            return Answer("decline", nonce, sha, kind, "another approval window stayed open")
        try:
            if not cross.acquire(max(0.0, deadline - time.monotonic())):
                return Answer("decline", nonce, sha, kind, "another approval window stayed open")
            if not gui_available():
                return Answer("decline", nonce, sha, kind, "no screen to show the approval window on")
            data = json.dumps(card, ensure_ascii=False).encode("utf-8", "replace")
            if cancel is not None and cancel.is_set():
                return Answer("decline", nonce, sha, kind, "withdrawn")
            rc, out, why = _exchange(_argv(), _env(), data, max(1.0, deadline - time.monotonic()), cancel)
            if why:
                ch, reason = "decline", why
            else:
                ch, reason = _parse(rc, out, nonce, card["allow"], card["always"])
            if reason:
                log.warning("approval window: declined (%s)", reason)
            return Answer(ch, nonce, sha, kind, reason)
        finally:
            cross.release()
            _one.release()
    except Exception as e:                                       # never an approval by accident
        log.warning("approval window: declined (%s)", e.__class__.__name__)
        return Answer("decline", nonce, sha, kind, "error: %s" % e.__class__.__name__)
    finally:
        if counted:
            with _plock:
                _pending["n"] = max(0, _pending["n"] - 1)
                pass


def bring_forward() -> bool:
    """"Show it again": bring this process's open approval window to the front (harmless if a page fakes the ask)."""
    p = _child.get("p")
    if p is None or p.poll() is not None:
        return False
    with _plock:                                         # at most once a second, however many pages ask
        if time.monotonic() - _SHARED.shown["at"] < 1.0:
            return True
        _SHARED.shown["at"] = time.monotonic()
    pid = int(p.pid)
    try:
        if sys.platform == "darwin":
            js = ("ObjC.import('AppKit'); var a=$.NSRunningApplication.runningApplicationWithProcessIdentifier(%d);"
                  " if(a){a.activateWithOptions(3);} ''" % pid)
            subprocess.run(["/usr/bin/osascript", "-l", "JavaScript", "-e", js], env=_env(), timeout=10,
                           capture_output=True)
            return True
        if os.name == "nt":
            ps = "$null=(New-Object -ComObject WScript.Shell).AppActivate(%d)" % pid
            subprocess.run(_argv(script=ps), env=_env(), timeout=20, capture_output=True, creationflags=0x08000000)
            return True
    except Exception:
        return False
    return False


def close_open_window() -> bool:
    """Close the open window as a Decline (the dashboard stopping, Decline all)."""
    p = _child.get("p")
    if p is None:
        return False
    try:
        p.kill()
        return True
    except Exception:
        return False
