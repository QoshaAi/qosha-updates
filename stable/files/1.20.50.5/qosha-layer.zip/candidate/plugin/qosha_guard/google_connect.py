"""Connect Google in one step (Ren, 17 Nov 2026: "the person just sees Connected, no copy-paste").

The engine's bundled google-workspace skill signs in with a redirect to http://localhost:1, so the person must copy the
browser's address back into the chat. This helper uses the same skill (its scopes, client file and token format, so
google_api.py works unchanged) but catches Google's redirect on a loopback port of this computer, so the person only
signs in to Google and sees "Connected".

Tool: qosha_connect_google. Python: start_flow() -> dict (returns at once), flow_status(id), cancel_flow(),
open_in_browser(id), connect(timeout=300) -> dict (waits; kept for scripts).
The Google OAuth client comes from <home>/google_client_secret.json (the skill's place); if it is missing, a Qosha
install may ship one as <plugin>/google_client.json (Desktop-app client, no secret values in this repo).

17 Nov 2026 evening (Windows, real client): the sign-in used to be opened only by the hidden dashboard process
(webbrowser.open) while the page waited up to 300 s with no address. On Windows a hidden background process may not
bring a window forward while the person is using another one (foreground lock), so Google's page opened BEHIND the
Qosha window and nothing visible happened. Now the flow starts and the address comes back at once; the PAGE opens it
(the window the person is using may bring the browser forward) and shows a link; the loopback server waits in the
background for up to 10 minutes, one flow at a time, state checked, PKCE kept; the page polls flow_status().
"""
from __future__ import annotations

import hashlib
import hmac
import html
import importlib.util
import contextlib
import json
import logging
import re
import os
import secrets
import shutil
import sys
import threading
import time
import types
import urllib.error
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import parse_qs, quote, urlparse

try:   # pt-BR v1: the person's language for the sentences below (qosha_guard/i18n.py); English is byte for byte 1.20.27's
    from .i18n import tr
except ImportError:  # loaded by path, not as part of the qosha_guard package
    def tr(key, **kw):
        m = sys.modules.get("qosha_guard_i18n_file")
        if m is None:
            spec = importlib.util.spec_from_file_location("qosha_guard_i18n_file",
                                                          os.path.join(os.path.dirname(os.path.abspath(__file__)), "i18n.py"))
            m = importlib.util.module_from_spec(spec)
            sys.modules["qosha_guard_i18n_file"] = m
            spec.loader.exec_module(m)
        return m.tr(key, **kw)


def _or_key(key: str, english: str) -> str:
    """The catalog's text for `key`, or the English when the catalog has none."""
    t = tr(key)
    return english if t == key else t


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes"))


def _skill_setup():
    """The bundled skill's setup.py, loaded as a module (home copy first, then the engine's)."""
    cands = [_home() / "skills" / "productivity" / "google-workspace" / "scripts" / "setup.py"]
    try:
        import hermes_constants
        cands.append(Path(hermes_constants.__file__).resolve().parent / "skills" / "productivity" / "google-workspace"
                     / "scripts" / "setup.py")
    except Exception:
        pass
    for p in cands:
        if p.is_file():
            import sys
            if str(p.parent) not in sys.path:
                sys.path.insert(0, str(p.parent))
            spec = importlib.util.spec_from_file_location("qosha_gws_setup", p)
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)
            return m
    raise RuntimeError("the google-workspace skill is not installed")


# Google Workspace MCP (taylorwilsdon/google_workspace_mcp 2.5.0; Ren 02:20: full tool set for Gmail, Calendar, Drive,
# Docs, Sheets, Contacts, Tasks): one sign-in feeds both it and the bundled skill. Its scopes for those services:
WORKSPACE_MCP_SCOPES = [
    "https://www.googleapis.com/auth/" + x for x in (
        "calendar", "calendar.events", "calendar.readonly", "contacts", "contacts.readonly", "documents",
        "documents.readonly", "drive", "drive.file", "drive.readonly", "gmail.compose", "gmail.labels", "gmail.modify",
        "gmail.readonly", "gmail.send", "gmail.settings.basic", "spreadsheets", "spreadsheets.readonly", "tasks",
        "tasks.readonly", "userinfo.email", "userinfo.profile")] + ["openid"]


# 1.20.9 (contract CONTRACT-GEXEC, Ren 21 Nov 2026: "the AI's Google access becomes read-only"): the one sign-in Qosha
# keeps on disk can only read. Writes get their own short grant from Qosha's executor, held in memory only (G3).
SIGNIN_SCOPES = ["https://www.googleapis.com/auth/" + x for x in (
    "gmail.readonly", "calendar.readonly", "drive.readonly", "documents.readonly", "spreadsheets.readonly",
    "contacts.readonly", "tasks.readonly", "userinfo.email", "userinfo.profile")] + ["openid"]
_READ_SCOPE_OK = set(SIGNIN_SCOPES) | {"email", "profile", "https://www.googleapis.com/auth/calendar.events.readonly",
                                       "https://www.googleapis.com/auth/gmail.metadata"}


_PLAIN = {"gmail.readonly": "Gmail reading", "calendar.readonly": "Calendar reading", "drive.readonly": "Drive reading",
          "documents.readonly": "Docs reading", "spreadsheets.readonly": "Sheets reading",
          "contacts.readonly": "Contacts reading", "tasks.readonly": "Tasks reading"}


class Unticked(Exception):
    """Google's page came back without some read permissions (every box there starts unticked)."""
    def __init__(self, missing, revoked=True, dropped=False):
        super().__init__(", ".join(missing))
        self.missing, self.revoked, self.dropped = list(missing), bool(revoked) and not dropped, bool(dropped)


class Stopped(Exception):
    """The sign-in was cancelled before Qosha could refuse it: nothing is kept and nothing is revoked (a revoke would end
    the same account's sign-in on the person's other computers; 22 Nov, live breach)."""


def _revoke_if_live(flow, creds) -> bool:
    """A refused sign-in is taken back only while it is still the live one (not cancelled): checked and revoked under
    the sign-in's own lock, so a Cancel lands either before (nothing revoked) or after (already refused)."""
    lock = getattr(flow, "_lock", None)
    if not (hasattr(lock, "__enter__") and hasattr(lock, "__exit__")):
        lock = None
    with (lock if lock is not None else contextlib.nullcontext()):
        status = getattr(flow, "status", "waiting")
        if isinstance(status, str) and status != "waiting":
            _drop(flow, creds)
            raise Stopped()
        with _quiet_oauth():
            ok = _revoke_sure(creds)
        try:                                       # which account was given back, before memory is cleared (S4)
            flow._refused_email = str(_id_claims(creds).get("email") or "")
        except Exception:  # noqa: BLE001
            pass
        _drop(flow, creds)                         # given back: nothing of it stays in memory (GPT v H2)
        return ok


class Refused(Exception):
    """A sign-in Qosha won't keep, with the plain sentence both screens show (final pass r2 H5)."""
    def __init__(self, plain, revoked=True, dropped=False):
        super().__init__(plain)
        self.revoked, self.dropped = bool(revoked) and not dropped, bool(dropped)
        self.plain = plain + ("" if revoked or dropped else _NOT_TAKEN_BACK)


def _drop(flow, creds) -> None:
    """A refused sign-in is dropped on this computer, never revoked: Google ends the WHOLE read grant of an account when
    any of its tokens is revoked, so a revoke here would sign the same account out on the person's other computers
    (22 Nov 2026, orchestrator: an unticked box on one install must leave another install's sign-in working). Nothing
    is written; the tokens are cleared from memory here (never logged)."""
    sess = getattr(getattr(flow, "flow", None), "oauth2session", None)
    for obj in (creds, sess, getattr(sess, "_client", None)):
        for attr in ("token", "refresh_token", "_refresh_token", "id_token", "_id_token", "access_token"):
            try:
                if obj is not None and not callable(getattr(obj, attr, None)) and hasattr(obj, attr):
                    setattr(obj, attr, None if attr != "token" or obj is creds else {})
            except Exception:  # noqa: BLE001
                pass


def _tokeninfo_scopes(creds) -> Optional[list]:
    """What Google says a fresh access token can do, when Google's answer left the permissions out (RFC 6749 5.1
    allows that; final pass r2 H6). None when Google can't be asked. The token goes in the body, never the address."""
    import urllib.parse
    import urllib.request
    try:
        body = urllib.parse.urlencode({"access_token": str(getattr(creds, "token", "") or "")}).encode()
        with urllib.request.urlopen(urllib.request.Request("https://oauth2.googleapis.com/tokeninfo", data=body),
                                    timeout=15) as r:
            got = json.loads(r.read().decode("utf-8"))
        return str(got.get("scope") or "").split()
    except Exception:  # noqa: BLE001
        return None


_NOT_TAKEN_BACK = (" Qosha couldn\u2019t confirm Google took that sign-in back: you can remove \u201cQosha\u201d at "
                   "myaccount.google.com/permissions.")


def _revoke_sure(creds) -> bool:
    """Revoke, tried twice (final pass H4). True when Google confirmed."""
    tok = str(getattr(creds, "refresh_token", "") or getattr(creds, "token", "") or "")
    for _i in range(2):
        try:
            if tok and _revoke(tok):
                return True
        except Exception:  # noqa: BLE001
            pass
    return False


def _below_warning(record) -> bool:
    return record.levelno >= logging.WARNING


for _n in ("requests_oauthlib", "requests_oauthlib.oauth2_session", "oauthlib", "google_auth_oauthlib", "google.auth",
           "google.auth.transport.requests"):
    _lg = logging.getLogger(_n)
    if not any(getattr(f, "__name__", "") == "_below_warning" for f in _lg.filters):
        _lg.addFilter(_below_warning)      # token answers are logged at DEBUG: never, at any time (as google_write)


@contextlib.contextmanager
def _quiet_oauth():
    """The OAuth libraries log whole token answers at DEBUG: never while a grant is exchanged, refused or revoked
    (GPT HIGH 6; P0 final pass H3). One counted guard for the whole process (the sign-in and the write module share
    it, even when loaded twice), covering every logger under those names; the person's levels come back when the
    last exchange ends."""
    import logging
    import types
    st = sys.modules.get("qosha_oauth_quiet_state")
    if st is None:
        st = sys.modules.setdefault("qosha_oauth_quiet_state", types.ModuleType("qosha_oauth_quiet_state"))
    if not hasattr(st, "lock"):
        st.lock, st.depth, st.saved = threading.Lock(), 0, {}
    names = ("requests_oauthlib", "oauthlib", "google_auth_oauthlib", "google.auth", "urllib3")
    with st.lock:
        if st.depth == 0:
            every = [n for n in list(logging.root.manager.loggerDict)
                     if any(n == p or n.startswith(p + ".") for p in names)]
            st.saved = {n: (logging.getLogger(n).level, logging.getLogger(n).propagate) for n in set(every) | set(names)}
            for n in st.saved:
                logging.getLogger(n).setLevel(logging.WARNING)
                logging.getLogger(n).propagate = False
        st.depth += 1
    try:
        yield
    finally:
        with st.lock:
            st.depth -= 1
            if st.depth == 0:
                for n, (lvl, prop) in st.saved.items():
                    logging.getLogger(n).setLevel(lvl)
                    logging.getLogger(n).propagate = prop
                st.saved = {}


def unticked_message(exc) -> str:
    miss = [_or_key("google.perm." + m.split(" ")[0].lower(), m) for m in list(getattr(exc, "missing", []) or [])]
    what = ((", ".join(miss[:-1]) + " " + _or_key("google.list_and", "and") + " " + miss[-1]) if len(miss) > 1
            else (miss[0] if miss else _or_key("google.some_items", "some items")))
    return (tr("google.unticked.one" if len(miss) == 1 else "google.unticked.many", what=what)
            + ("" if getattr(exc, "revoked", True) or getattr(exc, "dropped", False)
               else " " + _or_key("google.not_taken_back", _NOT_TAKEN_BACK.strip())))


def _id_claims(creds) -> dict:
    """The claims of the ID token Google just returned over its own TLS connection (email, hd)."""
    import base64
    tok = str(getattr(creds, "id_token", "") or "")
    try:
        part = tok.split(".")[1]
        return json.loads(base64.urlsafe_b64decode(part + "=" * (-len(part) % 4)).decode("utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def _revoke(token: str) -> bool:
    """Ask Google to forget a grant (the refresh token and everything granted with it). True when Google said so."""
    import urllib.parse
    import urllib.request
    try:
        req = urllib.request.Request("https://oauth2.googleapis.com/revoke",
                                     data=urllib.parse.urlencode({"token": token}).encode(),
                                     headers={"Content-Type": "application/x-www-form-urlencoded"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return 200 <= r.status < 300
    except Exception:
        return False


_TEMP = re.compile(r"\.tmp\.\d+\.[0-9a-f]{8}$")


def _is_temp_name(name: str) -> bool:
    """The old writer's exact temp name (<name>.tmp.<pid>.<8 hex>), never an account address that contains ".tmp."."""
    return bool(_TEMP.search(name))


def _sign_in_files(h: Path) -> list:
    """Every file that may hold a Google sign-in: the skill's token, the old writer's leftover temp files, and the
    Workspace tools' copies (GPT r1209 r2 HIGH 6)."""
    c = h / "google_workspace_mcp" / "credentials"
    return ([h / "google_token.json"] + sorted(p for p in h.glob("google_token.tmp.*") if _is_temp_name(p.name)) +
            (sorted(c.glob("*.json")) + sorted(p for p in c.glob("*.tmp.*") if _is_temp_name(p.name)) if c.is_dir() else []))


def _scopes_of(data: Any) -> list:
    if not isinstance(data, dict):
        return []
    s = data.get("scopes") or data.get("scope") or []
    return s.split() if isinstance(s, str) else [str(x) for x in s] if isinstance(s, list) else []


def _complete(scopes) -> bool:
    """All seven reading permissions are there (every box ticked)."""
    have = set(scopes or [])
    return all("https://www.googleapis.com/auth/" + s in have for s in _PLAIN)


def _read_only(data: Any) -> bool:
    s = _scopes_of(data)
    return bool(s) and all(x in _READ_SCOPE_OK for x in s)     # unknown scopes count as more than reading


_REVOKED_SEEN: set = set()      # grant marks Google answered invalid_grant for in this process (never a token)


def _granted_scopes(data: Any) -> Optional[list]:
    """What Google says this sign-in can do (a fresh access token's tokeninfo), or None when that can't be asked
    (offline, no client): local labels are only a hint (GPT r1209 r2 HIGH 8). Never logs a token."""
    import urllib.parse
    import urllib.request
    try:
        if not isinstance(data, dict) or not data.get("refresh_token") or not data.get("client_id"):
            return None
        body = urllib.parse.urlencode({"client_id": data["client_id"], "client_secret": data.get("client_secret", ""),
                                       "refresh_token": data["refresh_token"], "grant_type": "refresh_token"}).encode()
        try:
            with urllib.request.urlopen(urllib.request.Request("https://oauth2.googleapis.com/token", data=body),
                                        timeout=15) as r:
                at = json.loads(r.read().decode()).get("access_token")
        except urllib.error.HTTPError as exc:
            try:
                err = json.loads(exc.read().decode("utf-8", "replace")).get("error")
            except Exception:  # noqa: BLE001
                err = ""
            if exc.code == 400 and err == "invalid_grant":
                _REVOKED_SEEN.add(_rt_mark(str(data["refresh_token"])))   # Google ended it (r4 H4)
            return None
        if not at:
            return None
        with urllib.request.urlopen("https://oauth2.googleapis.com/tokeninfo?access_token=" + urllib.parse.quote(at), timeout=15) as r:
            return str(json.loads(r.read().decode()).get("scope") or "").split()
    except Exception:
        return None


def _revoke_once(data: Any, done: set) -> bool:
    if not isinstance(data, dict):
        return False
    for k in ("refresh_token", "token"):
        tok = data.get(k)
        if tok:
            mark = hashlib.sha256(str(tok).encode()).hexdigest()
            if mark in done:
                return True
            ok = _revoke(str(tok))
            if ok:
                done.add(mark)
            return ok
    return False


def _revoked_marks(h: Path) -> set:
    try:
        return set(json.loads((h / "google_revoked.json").read_text(encoding="utf-8")).get("marks", []))
    except Exception:
        return set()


def _update_running(h: Path) -> bool:
    """The updater is replacing Qosha right now (its health check compares the sign-in files before and after)."""
    try:
        s = json.loads((h / "qosha" / "updates.json").read_text(encoding="utf-8"))
        return isinstance(s, dict) and bool(s.get("applying"))
    except Exception:
        return False


def _zip_sign_ins(z: Path, done: set, known: Optional[dict] = None) -> bool:
    """An older daily backup: its sign-in entries are revoked when they could do more than read, and taken out of the
    archive either way (the rest stays). True when the archive was rewritten (GPT r1209 r2 HIGH 5)."""
    import zipfile
    try:
        with zipfile.ZipFile(str(z)) as zf:
            names = zf.namelist()
            gone = [n for n in names if _is_sign_in_name(n)]
            if not gone:
                return False
            for n in gone:
                try:
                    data = json.loads(zf.read(n).decode("utf-8"))
                except Exception:
                    data = None
                rt = str(data.get("refresh_token") or "") if isinstance(data, dict) else ""
                if rt and known and rt in known:
                    keep, missing = known[rt]      # Google's own answer for this grant decides, not the backup's label
                    if not keep and not missing:   # (shrink verify GPT 5): only a grant that can do more than read
                        _revoke_once(data, done)
                elif not _read_only(data):
                    _revoke_once(data, done)
            tmp = z.with_name(z.name + ".qosha-tmp")
            with zipfile.ZipFile(str(tmp), "w", compression=zipfile.ZIP_DEFLATED) as out:
                for info in zf.infolist():
                    if info.filename not in gone:
                        out.writestr(info, zf.read(info.filename))
        try:
            os.chmod(str(tmp), 0o600)
        except OSError:
            pass
        os.replace(str(tmp), str(z))
        return True
    except Exception:
        return False


def _is_sign_in_name(n: str) -> bool:
    b = n.replace("\\", "/")
    leaf = b.rsplit("/", 1)[-1]
    return (leaf in ("google_token.json", "google_oauth_pending.json") or leaf.startswith("google_token.tmp.")
            or "google_workspace_mcp/credentials/" in b)


SIGNED_OUT = "google_signed_out.json"


def _rt_mark(rt: str) -> str:
    return hashlib.sha256(("qosha-signed-out:" + rt).encode()).hexdigest()[:16]


def _stored_rt(h: Path) -> str:
    try:
        d = json.loads((h / "google_token.json").read_text(encoding="utf-8"))
        return str(d.get("refresh_token") or "") if isinstance(d, dict) else ""
    except Exception:  # noqa: BLE001
        return ""


def grant_of(refresh_token: str) -> str:
    """A sign-in's mark from its own refresh token (a hash, never the token)."""
    return _rt_mark(refresh_token) if refresh_token else ""


def current_grant(home=None) -> str:
    """The stored sign-in's mark (a hash, never the token), or "" when none is stored."""
    rt = _stored_rt(Path(home) if home else _home())
    return _rt_mark(rt) if rt else ""


def mark_signed_out(home=None, grant=None) -> bool:
    """Google ended the stored sign-in (invalid_grant / revoked; a revoke ends the whole grant for the account, e.g. a
    Disconnect on another computer). Connections and Home then say "Reconnect" instead of "Connected" or an error
    code. Tied to that exact grant: a new Connect makes it void. Never stores or logs a token."""
    h = Path(home) if home else _home()
    rt = _stored_rt(h)
    if not rt:
        return False
    if grant is not None and grant != _rt_mark(rt):
        return False          # the failure was for an older sign-in; a Reconnect since then stays usable (r4 H1)
    try:
        _private_json(h / SIGNED_OUT, {"grant": _rt_mark(rt), "at": time.strftime("%Y-%m-%dT%H:%M:%S%z")})
        return True
    except Exception:  # noqa: BLE001
        return False


def signed_out(home=None) -> bool:
    """True when Google signed Qosha out of the sign-in stored now."""
    h = Path(home) if home else _home()
    try:
        m = json.loads((h / SIGNED_OUT).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return False
    rt = _stored_rt(h)
    return bool(rt) and isinstance(m, dict) and m.get("grant") == _rt_mark(rt)


def is_revoked_error(exc) -> bool:
    """Google's answer when a refresh token no longer works: invalid_grant ("Token has been expired or revoked")."""
    if type(exc).__name__ != "RefreshError":      # only the OAuth refresh's own error, never a resource error (r4 H5)
        return False
    args = getattr(exc, "args", ()) or ()
    info = args[1] if len(args) > 1 and isinstance(args[1], dict) else {}
    if info.get("error") == "invalid_grant":
        return True
    return str(args[0] if args else exc).strip().lower().startswith("invalid_grant")


def _signed_out_after_refusal(h: Path, email: str) -> None:
    """A refused sign-in was revoked at Google; for the same account that ends the stored grant too (r3 H3)."""
    rt = _stored_rt(h)
    if not rt or not email:
        return                                   # no verified identity: leave the stored sign-in alone (r4 H2)
    active = ""
    try:
        from urllib.parse import unquote
        for f in workspace_mcp_dir().glob("*.json"):
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                continue
            if isinstance(d, dict) and d.get("refresh_token") == rt:
                active = unquote(f.stem).lower()  # the account the ACTIVE grant belongs to
                break
    except Exception:  # noqa: BLE001
        active = ""
    if active and active == email.lower():
        mark_signed_out(h, grant=_rt_mark(rt))


def retire_write_grant(home=None) -> Dict[str, Any]:
    """Every Google sign-in file that can do more than read (made before 1.20.9) is revoked at Google and removed,
    each on its own (any account, the old writer's temp files too); when online Google itself says what each can do.
    A sign-in waiting in the skill's manual setup is dropped. Older daily backups lose their sign-in entries. The
    person is asked once to connect again. Never raises; never logs a token."""
    h = Path(home) if home else _home()
    done, retired, revoked = _revoked_marks(h), 0, True
    incomplete, asked = False, {}
    write_labelled = set()                 # grants any copy of which says it can do more than read (r4 H3)
    for f in _sign_in_files(h):
        try:
            d0 = json.loads(f.read_bytes().decode("utf-8")) if f.exists() else None
        except Exception:  # noqa: BLE001
            d0 = None
        if isinstance(d0, dict) and d0.get("refresh_token") and not _read_only(d0):
            write_labelled.add(str(d0["refresh_token"]))
    for f in _sign_in_files(h):
        try:
            if not f.exists():
                continue
            raw = f.read_bytes()
            try:
                data = json.loads(raw.decode("utf-8"))
            except Exception:
                data = None
            rt = str(data.get("refresh_token") or "") if isinstance(data, dict) else ""
            if rt and rt in asked:
                keep, missing = asked[rt]          # the same grant in another file: one decision for every copy (r2 H1, r3 H1)
            else:
                # Google is asked once per grant; the files' labels decide only when it can't answer (r5 H2)
                real = _granted_scopes(data) if rt else None
                if real is not None:
                    keep = all(x in _READ_SCOPE_OK for x in real)
                else:
                    keep = _read_only(data) and rt not in write_labelled
                have = real if real is not None else _scopes_of(data)
                missing = []
                if keep and not _complete(have):
                    keep = False                   # some boxes were left unticked (a 1.20.18 sign-in; final pass H2)
                    missing = [plain for s, plain in _PLAIN.items() if "https://www.googleapis.com/auth/" + s not in have]
                if rt:
                    asked[rt] = (keep, missing)
            if missing:
                incomplete = missing
            temp = _is_temp_name(f.name)
            if keep and not temp:
                continue
            if not keep and not missing:       # only a grant that can do more than read is revoked (1.20.9); an
                revoked = _revoke_once(data, done) and revoked   # incomplete read-only one is dropped here: a revoke
            try:                                                  # would sign the account out elsewhere (22 Nov)
                if f.read_bytes() != raw:
                    continue                   # a new Connect wrote it meanwhile: not the one classified (verif. HIGH 10)
            except FileNotFoundError:
                continue
            f.unlink()
            retired += 0 if (keep and temp) else 1
        except Exception:
            revoked = False
    g = current_grant(h)
    if g and g in _REVOKED_SEEN:
        mark_signed_out(h, grant=g)       # Google answered invalid_grant for the kept sign-in: Reconnect (r4 H4)
    try:
        (h / "google_oauth_pending.json").unlink()
    except OSError:
        pass
    try:
        for z in sorted((h / "backups").glob("*.zip")) if (h / "backups").is_dir() else []:
            _zip_sign_ins(z, done, asked)
    except Exception:
        pass
    try:
        _private_json(h / "google_revoked.json", {"marks": sorted(done)})
        if retired:
            _private_json(h / "google_reconnect.json", {
                "why": (unticked_message(Unticked(incomplete)).replace("Google isn\u2019t connected yet", "Google needs connecting once more")
                        if incomplete else
                        "Qosha now keeps a read-only Google sign-in; connect Google once more."), "revoked": revoked,
                "at": time.strftime("%Y-%m-%dT%H:%M:%S%z")})
    except Exception:
        pass
    if retired:
        return {"status": "retired", "revoked": revoked, "removed": retired}
    return {"status": "read-only" if (h / "google_token.json").exists() else "none"}


def retire_later(home=None, limit: float = 1200.0) -> None:
    """In the background: once no update is being applied (the updater compares the sign-in files around its health
    check), at most after `limit` seconds (GPT r1209 r2 HIGH 4)."""
    def go():
        t0 = time.monotonic()
        h = Path(home) if home else _home()
        while _update_running(h) and time.monotonic() - t0 < limit:
            time.sleep(10)
        retire_write_grant(h)
    threading.Thread(target=go, daemon=True, name="qosha-google-read-only").start()


def _commit_lock():
    """One sign-in commit or Disconnect at a time in this process, shared by every copy of this module (C1, 25 Nov
    2026): a Disconnect never deletes the files of a sign-in that finishes meanwhile."""
    lock = getattr(_REG, "commit_lock", None)
    if lock is None:
        with _REG.lock:
            lock = getattr(_REG, "commit_lock", None)
            if lock is None:
                lock = _REG.commit_lock = threading.RLock()
    return lock


def _rt_in(raw) -> str:
    """The refresh token in a sign-in file's bytes, or ""."""
    try:
        d = json.loads(raw.decode("utf-8")) if raw else None
    except Exception:  # noqa: BLE001
        return ""
    return str(d.get("refresh_token") or "") if isinstance(d, dict) else ""


def _account_of(h: Path, rt: str) -> str:
    """The account whose Workspace copy holds this grant, or ""."""
    c = h / "google_workspace_mcp" / "credentials"
    if not rt or not c.is_dir():
        return ""
    from urllib.parse import unquote
    for f in sorted(c.glob("*.json")):
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            continue
        if isinstance(d, dict) and d.get("refresh_token") == rt:
            return unquote(f.stem)
    return ""


def shown_account(home=None) -> str:
    """The account Connections shows: the Workspace copy that holds the stored sign-in's grant (never simply the newest
    file, which a put-back or an older account's copy can be; GPT r3, Gemini). "" when no copy holds it. Never returns
    or logs a token."""
    h = Path(home) if home else _home()
    return _account_of(h, _stored_rt(h))


def _refused_changed() -> Dict[str, Any]:
    return {"removed": 0, "revoked": 0, "refused": "account_changed", "plain": tr("google.account_changed")}


def forget_all(home=None, shown=None, cancel=None) -> Dict[str, Any]:
    """Disconnect: every Google sign-in this computer holds is revoked at Google (each distinct one) and removed.
    The stored sign-in is read ONCE, under the commit lock; that grant is the one revoked, and the account shown on the
    page is checked against that same grant (GPT r4).
    shown (the Connections page): the account the page showed when Disconnect was pressed; if it is not the stored
    grant's account, nothing is revoked, removed or stopped (GPT r3).
    cancel (the page: cancel_flow): stops a waiting sign-in only when Disconnect went through under the lock (account
    matched, nothing left in place), so a refused Disconnect never stops it (GPT r4/r5). While a sign-in is being saved (it holds the lock), a Disconnect
    whose first check matched stops it before waiting, so the save puts its files back (GPT r1 #1)."""
    h = Path(home) if home else _home()
    lock = _commit_lock()
    if not lock.acquire(blocking=False):       # a sign-in is being saved (it holds the lock)
        if shown is not None and str(shown).strip().lower() != _account_of(h, _stored_rt(h)).lower():
            return _refused_changed()          # refused before anything is stopped
        if cancel is not None:                 # matched: the save is stopped and puts its files back (GPT r1 #1)
            try:
                cancel()
            except Exception:  # noqa: BLE001
                pass
            cancel = None
        lock.acquire()
    try:                                       # never in the middle of a sign-in's commit (C1)
        try:
            raw_tok = (h / "google_token.json").read_bytes()
        except OSError:
            raw_tok = None
        rt = _rt_in(raw_tok)
        if shown is not None and str(shown).strip().lower() != _account_of(h, rt).lower():
            return _refused_changed()
        # Google is asked to revoke only a grant whose own Workspace copy names an account (positively identified; GPT
        # r6): a token nobody can be shown (e.g. recreated by an older writer after a Disconnect) goes on this computer
        # only, and the answer says so
        named = _account_of(h, rt)
        r = _forget_all(h, rt, raw_tok, remote=bool(named))
        if not r.get("kept"):                  # a Disconnect that left another sign-in in place is refused by the page:
            r["write"] = _forget_write_grant(h, named)   # then the change permission stays too (review r1, GK-F4)
        if rt and not named:
            r["local_only"] = True
        if cancel is not None and not r.get("kept"):   # still under the lock: a waiting sign-in can't commit before this
            try:
                cancel()
            except Exception:  # noqa: BLE001
                pass
        return r
    finally:
        lock.release()


# gkeep (26 Nov 2026): Qosha's kept Google CHANGE permission ("Qosha Writes" project) is one file in Qosha's own folder
# of the engine's token folder (google_write.KEPT_FILE; the same path here because the dashboard loads this file on its
# own). Not one of _sign_in_files: the read-only retirement must never revoke it. Permissions Qosha stopped using but
# Google may still accept are held in memory (google_write._kept_reg, found through sys.modules). Disconnect revokes
# and removes all of it (_forget_write_grant: the one function here the wall build replaces).
WRITE_GRANT = "mcp-tokens/qosha-google/write.json"


# grant-wall slice 1 (26 Nov 2026, Ren: "Seal now, true wall next"; mechanism chosen by the council after round 1 of
# the blind reviews): the file above never holds the token itself, only who/what/when and a "seal" that opens on this
# computer, for this person, only for the account, app, Connect mark and permissions written next to it.
# Mac: the token is encrypted (AES-GCM) with ONE key per person, kept in their login Keychain: made once (by Qosha
# itself, with macOS dialogs switched off), never changed or deleted (it opens nothing without a file), readable by any
# program without a prompt. Windows: Windows' own encryption (DPAPI) for this person over a layer for this computer only.
# A copied file is useless anywhere else. A program running as the person here can still open it (accepted risk GK-A1,
# until the true wall). Any doubt = "can't open" = no kept permission; never an error, never a prompt, never a plain token.
SEAL_SERVICE = "qosha-google-change"           # the Keychain item's service (google_write's name hook refuses it too)
_SEAL_ITEM = "qosha-google-change-key"
_SEAL_V = 2


class SealError(Exception):
    """The permission could not be sealed here (it is then never written)."""


def _seal_keychain() -> str:
    """The person's login keychain (named, so a changed default keychain never moves the item). Tests replace this."""
    return str(Path.home() / "Library" / "Keychains" / "login.keychain-db")


def _binding(rec: Dict[str, Any]) -> bytes:
    """What a seal is tied to besides the computer: the account, Qosha's change app, the Connect mark and the
    permissions written next to it (editing any of them makes it unopenable)."""
    sc = rec.get("scopes")
    return json.dumps(["qosha-google-change", _SEAL_V, str(rec.get("account") or "").lower(), str(rec.get("client_id") or ""),
                       str(rec.get("mark") or ""), sorted(str(x) for x in sc) if isinstance(sc, list) else None],
                      separators=(",", ":")).encode("utf-8")


def _aead():
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM   # in the engine's own packages (Mac and Windows)
    return AESGCM


_SEC: Dict[str, Any] = {}


def _fw():
    """Security.framework and CoreFoundation through ctypes, with the signatures this file uses."""
    if "AttrList" in _SEC:
        return _SEC
    with _REG.lock:
        return _fw_init()


def _fw_init():
    if "AttrList" not in _SEC:
        import ctypes
        V = ctypes.c_void_p
        sec = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/Security.framework/Security")
        cf = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")
        for o, name, args, res in (
                (cf, "CFRelease", [V], None), (cf, "CFStringCreateWithCString", [V, ctypes.c_char_p, ctypes.c_uint32], V),
                (cf, "CFArrayCreate", [V, V, ctypes.c_long, V], V), (cf, "CFArrayGetCount", [V], ctypes.c_long),
                (cf, "CFArrayGetValueAtIndex", [V, ctypes.c_long], V),
                (sec, "SecKeychainOpen", [ctypes.c_char_p, ctypes.POINTER(V)], ctypes.c_int32),
                (sec, "SecKeychainGetStatus", [V, ctypes.POINTER(ctypes.c_uint32)], ctypes.c_int32),
                (sec, "SecKeychainGetUserInteractionAllowed", [ctypes.POINTER(ctypes.c_ubyte)], ctypes.c_int32),
                (sec, "SecKeychainSetUserInteractionAllowed", [ctypes.c_ubyte], ctypes.c_int32),
                (sec, "SecKeychainFindGenericPassword", [V, ctypes.c_uint32, ctypes.c_char_p, ctypes.c_uint32,
                                                         ctypes.c_char_p, ctypes.POINTER(ctypes.c_uint32),
                                                         ctypes.POINTER(V), V], ctypes.c_int32),
                (sec, "SecKeychainItemFreeContent", [V, V], ctypes.c_int32),
                (sec, "SecAccessCreate", [V, V, ctypes.POINTER(V)], ctypes.c_int32),
                (sec, "SecAccessCopyMatchingACLList", [V, V], V),
                (sec, "SecACLSetContents", [V, V, V, ctypes.c_uint16], ctypes.c_int32)):
            fn = getattr(o, name)
            fn.argtypes, fn.restype = args, res

        class Attr(ctypes.Structure):
            _fields_ = [("tag", ctypes.c_uint32), ("length", ctypes.c_uint32), ("data", V)]

        class AttrList(ctypes.Structure):
            _fields_ = [("count", ctypes.c_uint32), ("attr", ctypes.POINTER(Attr))]
        sec.SecKeychainItemCreateFromContent.argtypes = [ctypes.c_uint32, ctypes.POINTER(AttrList), ctypes.c_uint32, V,
                                                         V, V, ctypes.POINTER(V)]
        sec.SecKeychainItemCreateFromContent.restype = ctypes.c_int32
        _SEC.update(ct=ctypes, sec=sec, cf=cf, Attr=Attr, AttrList=AttrList)
    return _SEC


def _kc_lock():
    """One keychain call at a time in this process, shared by every loaded copy of this file: the "no dialogs" switch
    is process-wide, so it is turned off and back on around each whole call under this lock (review GW1-05, GW2-03)."""
    st = sys.modules.get("qosha_keychain_state")
    if st is None:
        st = sys.modules.setdefault("qosha_keychain_state", types.ModuleType("qosha_keychain_state"))
    if not hasattr(st, "lock"):
        with _REG.lock:
            if not hasattr(st, "lock"):
                st.lock = threading.RLock()
    return st.lock


@contextlib.contextmanager
def _no_dialogs():
    """macOS never shows a keychain dialog for Qosha's own calls while inside: a locked keychain or an item that
    would need asking just fails. Under _kc_lock; the switch is put back as it was only when the call is done."""
    with _kc_lock():
        s = _fw()
        prev = s["ct"].c_ubyte(1)
        if s["sec"].SecKeychainGetUserInteractionAllowed(s["ct"].byref(prev)) != 0:
            prev.value = 1
        if s["sec"].SecKeychainSetUserInteractionAllowed(0) != 0:
            raise SealError("dialogs could not be switched off")
        try:
            yield s
        finally:
            s["sec"].SecKeychainSetUserInteractionAllowed(prev.value)


def _kc_status() -> str:
    """"open", "locked" (there, but locked now: may open later) or "none" (no such keychain), asked without a prompt."""
    try:
        s = _fw()
        kc, st = s["ct"].c_void_p(), s["ct"].c_uint32(0)
        if s["sec"].SecKeychainOpen(_seal_keychain().encode("utf-8"), s["ct"].byref(kc)) != 0 or not kc.value:
            return "none"
        try:
            rc = s["sec"].SecKeychainGetStatus(kc, s["ct"].byref(st))
        finally:
            s["cf"].CFRelease(kc)
        if rc != 0:
            return "none"
        return "open" if (st.value & 3) == 3 else "locked"
    except Exception:  # noqa: BLE001
        return "none"


def _kc_key(make: bool, out: Optional[Dict[str, Any]] = None) -> bytes:
    """The person's sealing key, or b"". make: add it when there is none: a new item that any program may read without
    asking (so there is never a prompt, also after a Qosha update changes its own programs), added by Qosha itself
    with dialogs off. Two Qosha processes adding at once: one add fails as a duplicate, both read the same key."""
    try:
        with _no_dialogs() as s:
            ct, sec, cf = s["ct"], s["sec"], s["cf"]
            V = ct.c_void_p
            kc = V()
            if sec.SecKeychainOpen(_seal_keychain().encode("utf-8"), ct.byref(kc)) != 0 or not kc.value:
                return b""
            try:
                svc, acct = SEAL_SERVICE.encode(), _SEAL_ITEM.encode()

                def read() -> bytes:
                    n, data = ct.c_uint32(0), V()
                    rc = sec.SecKeychainFindGenericPassword(kc, len(svc), svc, len(acct), acct, ct.byref(n),
                                                            ct.byref(data), None)
                    try:
                        raw = ct.string_at(data.value, n.value) if rc == 0 and data.value else b""
                    finally:
                        if data.value:
                            sec.SecKeychainItemFreeContent(None, data)
                    if out is not None:
                        out["rc"] = rc
                    return bytes.fromhex(raw.decode("ascii")) if re.fullmatch(rb"[0-9a-f]{64}", raw) else b""
                k = read()
                if k or not make:
                    return k
                desc = cf.CFStringCreateWithCString(None, SEAL_SERVICE.encode(), 0x08000100)
                empty = cf.CFArrayCreate(None, None, 0, ct.addressof(V.in_dll(cf, "kCFTypeArrayCallBacks")))
                acc, acls, item = V(), None, V()
                try:
                    if sec.SecAccessCreate(desc, empty, ct.byref(acc)) != 0:
                        return b""
                    acls = sec.SecAccessCopyMatchingACLList(acc, V.in_dll(sec, "kSecACLAuthorizationDecrypt"))
                    if not acls or cf.CFArrayGetCount(acls) < 1:
                        return b""
                    for i in range(cf.CFArrayGetCount(acls)):     # no application list = any program, never asked
                        if sec.SecACLSetContents(cf.CFArrayGetValueAtIndex(acls, i), None, desc, 0) != 0:
                            return b""
                    pw = secrets.token_hex(32).encode("ascii")
                    bs, ba, bp = (ct.create_string_buffer(x) for x in (svc, acct, pw))
                    fcc = lambda t: int.from_bytes(t.encode("ascii"), "big")   # noqa: E731
                    attrs = (s["Attr"] * 2)(s["Attr"](fcc("svce"), len(svc), ct.cast(bs, V)),
                                            s["Attr"](fcc("acct"), len(acct), ct.cast(ba, V)))
                    sec.SecKeychainItemCreateFromContent(fcc("genp"), ct.byref(s["AttrList"](2, attrs)), len(pw),
                                                         ct.cast(bp, V), kc, acc, ct.byref(item))
                finally:
                    for o in (item.value, acc.value, acls, empty, desc):
                        if o:
                            cf.CFRelease(o)
                return read()                     # ours, or the one another Qosha process added first
            finally:
                cf.CFRelease(kc)
    except Exception:  # noqa: BLE001
        return b""


def _mac_key(make: bool) -> bytes:
    """The key as the keychain holds it now (never a copy kept in memory: a keychain locked or changed meanwhile is
    seen at once; review GW2-03)."""
    return _kc_key(make) if _kc_status() == "open" else b""


_WIN: Dict[str, Any] = {}


def _win():
    """crypt32/kernel32 with one BLOB type and fixed signatures, set up once for the process (two threads never change
    them under each other; review GW2-06)."""
    if "BLOB" not in _WIN:
        with _REG.lock:
            if "BLOB" not in _WIN:
                import ctypes
                from ctypes import wintypes

                class BLOB(ctypes.Structure):
                    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
                k32 = ctypes.WinDLL("kernel32")
                k32.LocalFree.argtypes, k32.LocalFree.restype = [ctypes.c_void_p], ctypes.c_void_p
                c32 = ctypes.WinDLL("crypt32", use_last_error=True)
                for fn in (c32.CryptProtectData, c32.CryptUnprotectData):
                    fn.argtypes = [ctypes.POINTER(BLOB), ctypes.c_void_p, ctypes.POINTER(BLOB), ctypes.c_void_p,
                                   ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(BLOB)]
                    fn.restype = wintypes.BOOL
                _WIN.update(ct=ctypes, crypt32=c32, kernel32=k32)
                _WIN["BLOB"] = BLOB
    return _WIN


def _dpapi(data: bytes, seal: bool, entropy: bytes, machine: bool = False) -> bytes:
    """Windows' own encryption (CryptProtectData / CryptUnprotectData), never with a dialog. machine: the layer for this
    computer only (a roaming profile alone can't open it on another computer). Raises SealError on error."""
    w = _win()
    ctypes, BLOB = w["ct"], w["BLOB"]

    def blob(b: bytes):
        buf = ctypes.create_string_buffer(b, len(b))
        return BLOB(len(b), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf

    src, _k1 = blob(data)
    ent, _k2 = blob(entropy)
    out = BLOB()
    fn = w["crypt32"].CryptProtectData if seal else w["crypt32"].CryptUnprotectData
    flags = 0x1 | (0x4 if (seal and machine) else 0)           # UI_FORBIDDEN (+ LOCAL_MACHINE)
    if not fn(ctypes.byref(src), None, ctypes.byref(ent), None, None, flags, ctypes.byref(out)):
        err = SealError("dpapi %d" % ctypes.get_last_error())
        err.code = ctypes.get_last_error()
        raise err
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        w["kernel32"].LocalFree(ctypes.cast(out.pbData, ctypes.c_void_p))


def seal_put(h: Path, rt: str, rec: Dict[str, Any]) -> Dict[str, Any]:
    """Seals the token for this computer and person, tied to rec's account, app, mark and permissions; returns what
    goes in the file in its place. Raises when it can't (the caller then never writes the token)."""
    import base64
    if not isinstance(rt, str) or not rt:
        raise SealError("not a token")
    bind = _binding(rec)
    if sys.platform == "darwin":
        try:
            aead = _aead()
        except Exception as exc:  # noqa: BLE001
            raise SealError("no cipher") from exc
        key = _mac_key(make=True)
        if not key:
            raise SealError("keychain locked or missing")
        nonce = secrets.token_bytes(12)            # fresh for every write
        ct = aead(key).encrypt(nonce, rt.encode("utf-8"), bind)
        return {"v": _SEAL_V, "kind": "keychain", "nonce": base64.b64encode(nonce).decode("ascii"),
                "ct": base64.b64encode(ct).decode("ascii")}
    if os.name == "nt":
        inner = _dpapi(rt.encode("utf-8"), True, bind, machine=True)
        return {"v": _SEAL_V, "kind": "dpapi", "blob": base64.b64encode(_dpapi(inner, True, bind)).decode("ascii")}
    raise SealError("no sealed store on this system")


_DPAPI_NEVER = {13, 0x80090005, 0x8009000B, -2146893819, -2146893813}   # bad data / key not valid here (Windows)


def seal_state(h: Path, seal: Any, rec: Dict[str, Any]):
    """("ok", token); ("no", "") when it never opens here (the system says: wrong key or tampered, another computer's
    or person's, no such key, an unknown seal); ("later", "") for anything else (keychain locked, a library missing, an
    error that may pass): then this account's sealed one is protected (review GW1-02, verification). Never raises."""
    import base64
    try:
        if not isinstance(seal, dict) or seal.get("v") != _SEAL_V:
            return "no", ""
        bind = _binding(rec)
        if seal.get("kind") == "keychain" and sys.platform == "darwin":
            try:
                nonce = base64.b64decode(seal["nonce"], validate=True)
                ct = base64.b64decode(seal["ct"], validate=True)
            except Exception:  # noqa: BLE001
                return "no", ""
            st = _kc_status()
            if st != "open":
                return ("later" if st == "locked" else "no"), ""
            got: Dict[str, Any] = {}
            key = _kc_key(False, got)
            if not key:
                return ("no" if got.get("rc") == -25300 else "later"), ""   # -25300: no such item (another Mac)
            try:
                aead = _aead()
                from cryptography.exceptions import InvalidTag
            except Exception:  # noqa: BLE001
                return "later", ""
            try:
                raw = aead(key).decrypt(nonce, ct, bind)
            except InvalidTag:
                return "no", ""
        elif seal.get("kind") == "dpapi" and os.name == "nt":
            try:
                blob = base64.b64decode(seal["blob"], validate=True)
            except Exception:  # noqa: BLE001
                return "no", ""
            try:
                raw = _dpapi(_dpapi(blob, False, bind), False, bind)
            except SealError as exc:
                code = getattr(exc, "code", None)
                return ("no" if code in _DPAPI_NEVER else "later"), ""
        else:
            return "no", ""                        # another system's seal
        rt = raw.decode("utf-8") if raw else ""
        return ("ok", rt) if rt else ("no", "")
    except Exception:  # noqa: BLE001
        return "later", ""


def seal_open(h: Path, seal: Any, rec: Dict[str, Any]) -> str:
    """The token a seal holds, or "" when it can't be opened here now. Never raises, never prompts."""
    return seal_state(h, seal, rec)[1]


@contextlib.contextmanager
def write_lock(h: Path, create: bool = False, wait: float = 30.0, must: bool = False):
    """One Qosha process at a time changes the kept permission's file of this home (migration, keeping, dropping,
    sweeping, Disconnect), with what it checks before and after: an OS lock on <home>/mcp-tokens/qosha-google.lock
    (made only by a write: create=True), re-entrant in this process. Plain reads take no lock: a file is replaced whole,
    and the key never changes. If the OS lock can't be had (no lock file yet, an error, `wait` seconds passed): with
    must=True SealError (a writer then doesn't write); otherwise it goes ahead under the in-process lock only (a
    Disconnect or a delete is never stopped by the lock; review GW2-01, GW2-04)."""
    reg = getattr(_REG, "write_locks", None)
    if reg is None:
        with _REG.lock:
            reg = getattr(_REG, "write_locks", None)
            if reg is None:
                reg = _REG.write_locks = {}
    key = os.path.normcase(os.path.abspath(str(h)))
    with _commit_lock():
        if reg.get(key):
            reg[key] += 1
            try:
                yield
            finally:
                reg[key] -= 1
            return
        p = Path(h) / "mcp-tokens" / "qosha-google.lock"
        fd = None
        try:
            if create:
                p.parent.mkdir(parents=True, exist_ok=True)
            if not p.parent.is_dir():
                raise OSError("nothing stored in this home yet")
            fd = os.open(str(p), os.O_RDWR | os.O_CREAT, 0o600)
            end = time.monotonic() + wait
            while True:
                try:
                    if os.name == "nt":
                        import msvcrt
                        os.lseek(fd, 0, 0)
                        msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except OSError:
                    if time.monotonic() >= end:
                        raise
                    time.sleep(0.05)
        except OSError as exc:
            if fd is not None:
                os.close(fd)
            if must:
                raise SealError("the permission file's lock") from exc
            yield                              # in-process lock only
            return
        reg[key] = 1
        try:
            yield
        finally:
            reg[key] = 0
            try:
                if os.name == "nt":
                    import msvcrt
                    os.lseek(fd, 0, 0)
                    msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
            except OSError:
                pass
            os.close(fd)                       # releases the POSIX lock too


def _forget_write_grant(h: Path, named: str, tries: int = 3, pause: float = 1.0) -> str:
    """Disconnect: the kept change permission (its file, any half-written copy <name>.tmp.*, and the handles held in
    memory) is removed, and what belongs to the account being disconnected is revoked at Google: one confirmed revoke is
    enough, Google ends an account's permissions for the app together; each handle is tried up to `tries` times.
    Another account's is only removed here, as with the read sign-in. Never raises; never logs a token. Returns
      "none"     nothing was kept;
      "revoked"  gone here and Google confirmed;
      "removed"  gone here, Google did NOT confirm (or a file couldn't be read): the page says so;
      "left"     a file could not be deleted and Google did not confirm: the page says so;
      "left-revoked"  a file could not be deleted but Google confirmed: what is in it no longer works anywhere.
    A file left behind is never used again: after a new Connect its mark no longer matches (google_write._kept_creds).
    grant-wall s1: a sealed file is opened to be revoked; one that can't be opened here now (Mac keychain locked,
    another computer, edited) is removed and the answer is "removed" (Google not confirmed: the page sends the person
    to Google's own page, as after a Disconnect while offline). Done under the per-home write lock, which never stops
    it."""
    with write_lock(h):
        return _forget_write_grant_now(h, named, tries, pause)


def _forget_write_grant_now(h: Path, named: str, tries: int, pause: float) -> str:
    f = h / WRITE_GRANT
    held, unsure, left, found = [], False, False, False
    try:
        files = [f] + sorted(p for p in f.parent.glob(f.stem + ".tmp.*") if _is_temp_name(p.name))
    except OSError:
        files = [f]
        if f.parent.exists():                  # the folder is there but can't be listed: a copy may remain in it
            found = unsure = left = True
    for p in files:
        try:
            raw = p.read_bytes()
        except FileNotFoundError:
            continue
        except OSError:
            raw = None
        found = True
        try:
            d = json.loads(raw.decode("utf-8")) if raw else None
        except Exception:  # noqa: BLE001
            d = None
        toks = []
        if isinstance(d, dict):
            # a file from before the seal (plain), a sealed one (grant-wall slice 1), or one holding both: every token
            # in it is opened here to be revoked; the account is the one the seal is tied to (an edited one won't open)
            plain = d["refresh_token"] if isinstance(d.get("refresh_token"), str) else ""
            if "seal" in d:
                t = seal_open(h, d.get("seal"), d)
                toks.append(t) if t else None
                unsure = unsure or not t       # a seal that won't open here now: can't be revoked from here
                if plain and plain != t:       # a plain one next to a seal: whose it is isn't known (GW1-09)
                    held.append({"account": "", "refresh_token": plain})
                    unsure = True
            elif plain:
                toks.append(plain)             # a file from before the seal
        held += [{"account": str(d.get("account") or "").lower(), "refresh_token": t} for t in toks
                 if isinstance(d, dict)]
        if not toks:
            unsure = True                      # unreadable, cut short, or a seal that won't open here: can't be revoked
        gone = False
        for _i in range(3):
            try:
                p.unlink()
                gone = True
                break
            except FileNotFoundError:
                gone = True
                break
            except OSError:
                time.sleep(0.2)
        left = left or not gone
    reg = sys.modules.get("qosha_google_write_kept")
    spare, lock = getattr(reg, "spare", None), getattr(reg, "lock", None)
    if isinstance(spare, dict) and lock is not None:
        with lock:
            held += [e for e in spare.pop(os.path.normcase(os.path.abspath(str(h))), [])
                     if isinstance(e, dict) and e.get("refresh_token")]
    if not found and not held:
        return "none"
    mine = [str(e["refresh_token"]) for e in held if named and str(e.get("account") or "").lower() == named.lower()]
    unsure = unsure or any(str(e["refresh_token"]) not in mine for e in held)   # the same handle twice counts once
    if mine:
        ended = False
        for rt in dict.fromkeys(mine):
            for i in range(max(1, tries)):
                try:
                    ended = bool(_revoke(rt))
                except Exception:  # noqa: BLE001
                    ended = False
                if ended:
                    break
                if i + 1 < tries:
                    time.sleep(pause)
            if ended:
                break
        unsure = unsure or not ended
    try:
        f.parent.rmdir()                       # Qosha's own folder, when empty
    except OSError:
        pass
    if left:
        return "left" if unsure else "left-revoked"
    return "removed" if unsure else "revoked"


def _forget_all(h: Path, active_rt: str, raw_tok, remote: bool = True) -> Dict[str, Any]:
    done, n, kept, other = set(), 0, [], ""
    tok = h / "google_token.json"
    active_rt_remote = active_rt if remote else ""   # not remote: removed here, never revoked at Google (GPT r6)
    if active_rt_remote:                       # the grant being disconnected, captured once (GPT r4)
        try:
            _revoke_once(json.loads(raw_tok.decode("utf-8")), done)
        except Exception:  # noqa: BLE001
            pass
    for f in _sign_in_files(h) + [h / "google_oauth_pending.json"]:
        try:
            raw = f.read_bytes()
        except FileNotFoundError:
            continue
        except OSError:
            raw = None
        if f == tok and _rt_in(raw) != active_rt:
            # another grant was written here meanwhile (a writer older than r5's refresh check): it is left, with the
            # Workspace copy that names it, so the page names that account; nothing of it is revoked; the caller says so.
            # The same grant rewritten by a refresh (new access token) is the same sign-in and goes (GPT r5)
            other = _rt_in(raw)
            kept.append(f.name)
            continue
        try:
            data = json.loads(raw.decode("utf-8")) if raw is not None else {}
        except Exception:
            data = {}
        if other and isinstance(data, dict) and str(data.get("refresh_token") or "") == other:
            kept.append(f.name)
            continue
        # Google ends the WHOLE grant of an account when any of its tokens is revoked: only the account being
        # disconnected is revoked; another account's stored copy is removed here and never revoked (22 Nov, live breach)
        if isinstance(data, dict) and active_rt_remote and str(data.get("refresh_token") or "") == active_rt_remote:
            _revoke_once(data, done)               # bound to the token captured above, never to a file name (GPT v H1)
        try:
            if f == tok:
                now = _rt_in(f.read_bytes())
                if now != active_rt:
                    other = now
                    kept.append(f.name)
                    continue
            f.unlink()
            n += 1
        except OSError:
            pass
    return {"removed": n, "revoked": len(done), "kept": kept}


def workspace_mcp_dir() -> Path:
    return _home() / "google_workspace_mcp" / "credentials"


def _private_json(path, payload) -> None:
    """Writes the sign-in file readable only by this user: Qosha's own writer, the same behaviour as the engine's
    skills/productivity/google-workspace/scripts/_secure_storage.py write_private_json (JSON, indent 2, utf-8, mode 0600
    from creation, fsync, atomic replace). Qosha never calls the skill script's helpers for this (18 Nov 2026: the
    install's older Qosha-library copy of that script had no write_private_json, so Connect Google on a fresh Mac failed
    at the very end and the sign-in was lost; council GPT + Gemini: "own token writing directly")."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp.%d.%s" % (os.getpid(), secrets.token_hex(4)))
    created = False
    try:
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        created = True                   # only a temp file this call made is ever removed below
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(str(tmp), str(path))
    finally:
        if created:
            try:
                tmp.unlink()
            except OSError:
                pass


def _write_workspace_mcp(creds, email: str, granted) -> str:
    """The same sign-in in the Workspace MCP's own credential format (auth/credential_store.py, file per account)."""
    if not email:
        return "skipped: no account email"
    from urllib.parse import quote
    d = workspace_mcp_dir()
    d.mkdir(parents=True, exist_ok=True)
    data = {"token": creds.token, "refresh_token": creds.refresh_token, "token_uri": creds.token_uri,
            "client_id": creds.client_id, "client_secret": creds.client_secret, "scopes": list(granted or creds.scopes or []),
            "expiry": creds.expiry.isoformat() if getattr(creds, "expiry", None) else None}
    path = d / (quote(email, safe="@._-") + ".json")
    tmp = d / ("%s.tmp.%d.%s" % (path.name, os.getpid(), secrets.token_hex(4)))
    try:                                   # whole or not at all: a failed write leaves no token bytes (r2 H2)
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(str(tmp), str(path))
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise
    return "written"


def _read_back(path: Path):
    """A file's bytes and times before a sign-in replaces it (None: no file), for _put_back. Only a missing file counts
    as none; any other error ends the save before anything is written (GPT r3 MEDIUM)."""
    try:
        st = path.stat()
        return path.read_bytes(), st.st_atime_ns, st.st_mtime_ns
    except FileNotFoundError:
        return None


def _put_back(path: Path, prev, times: bool = True) -> None:
    """1.20.44's undo for a sign-in that can't finish: the previous file is written back, or the new one is removed; if
    the previous one can't be written back, the new one is removed anyway (1.20.23's behaviour, carried C4). times: a
    Workspace copy also gets its old file times back (best effort; it never decides anything: GPT r2 NEW-1, r3);
    the skill's token never does, so a refused time change can't remove it (GPT r3 MEDIUM). Never raises."""
    try:
        if prev is None:
            path.unlink()
        else:
            _private_json(path, json.loads(prev[0].decode("utf-8")))
    except Exception:  # noqa: BLE001
        try:
            path.unlink()
        except OSError:
            pass
        return
    if times and prev is not None:
        try:
            os.utime(str(path), ns=(prev[1], prev[2]))
        except OSError:
            pass


PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Qosha</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#F5F4F0;color:#0B0B0B;
font-family:"Google Sans Flex","Helvetica Neue",Arial,sans-serif}.c{background:#fff;border:1px solid #E2E1DB;border-radius:20px;
padding:32px 40px;max-width:440px;box-shadow:0 1px 2px rgba(11,11,11,.04),0 8px 28px rgba(11,11,11,.05)}
h1{margin:0 0 8px;font-size:22px;font-weight:500;color:#0B3326}p{margin:0;color:#3E4B45;line-height:22px}
.bar{height:4px;width:48px;background:#B8955A;border-radius:2px;margin-bottom:16px}</style></head>
<body><div class="c"><div class="bar"></div><h1>%s</h1><p>%s</p></div></body></html>"""


FLOW_TTL = 600   # seconds a started sign-in waits for Google's answer (10 minutes)

# No domain lock by default (P0, 22 Nov 2026): any Google account may connect; Google's own test-user list for Qosha's
# app is the gate. A client that wants one Google Workspace only sets QOSHA_GOOGLE_DOMAIN: then hd= offers only that
# domain's accounts, the screens say which account to use, and an account from elsewhere is refused (_check_domain).
def account_domain() -> str:
    d = os.environ.get("QOSHA_GOOGLE_DOMAIN")
    return "" if d is None else d.strip().lstrip("@")


def account_line() -> str:
    d = account_domain()
    return ("Use your @%s Google account; other accounts are refused for now." % d) if d else ""


def waiting_line() -> str:
    """What Qosha shows while Google's sign-in waits in the browser (Ren 17 Nov 18:40: Renato's tab opened, but the
    app never told him it was waiting for him)."""
    d = account_domain()
    return tr("google.waiting.domain", domain=d) if d else tr("google.waiting.any")


# one registry per process, shared by every copy of this module (the chat tool and the Connections page load it under
# different names): one sign-in at a time on this computer
_REG = sys.modules.get("qosha_google_flow_registry")
if _REG is None:
    _REG = types.ModuleType("qosha_google_flow_registry")
    _REG.lock = threading.Lock()
    _REG.current = None
    sys.modules["qosha_google_flow_registry"] = _REG


def _now() -> float:
    return time.time()


class _GoogleFlow:
    """One sign-in: a loopback server on 127.0.0.1:<free port> served by a background thread until Google answers with
    this flow's state, the flow is cancelled, or FLOW_TTL passes."""

    def __init__(self, setup_mod, secret: Path, ttl: int):
        from google_auth_oauthlib.flow import Flow
        self.s = setup_mod
        self.id = "g" + secrets.token_urlsafe(18)
        self.started = _now()
        self.deadline = self.started + ttl
        self.status = "waiting"           # waiting | connected | failed | timeout | cancelled
        self.email = ""
        self.scopes: list = []
        self.workspace_mcp = ""
        self.error = ""
        self.plain = ""
        self.refused = 0                  # callbacks refused (wrong or missing state)
        self.browser_opened = None        # None: not tried; True/False: webbrowser.open's answer
        self._done = threading.Event()
        self._lock = threading.Lock()
        flow_ref = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _page(self, code: int, title: str, text: str):
                data = (PAGE % (html.escape(title), html.escape(text))).encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                flow_ref._callback(self)

        self.srv = HTTPServer(("127.0.0.1", 0), H)
        self.srv.timeout = 0.5
        self.redirect = "http://127.0.0.1:%d/" % self.srv.server_address[1]
        self.flow = Flow.from_client_secrets_file(
            str(secret), scopes=sorted(SIGNIN_SCOPES), redirect_uri=self.redirect,
            autogenerate_code_verifier=True)   # PKCE: the verifier stays in this process
        extra = {"hd": account_domain()} if account_domain() else {}
        self.url, self.state = self.flow.authorization_url(access_type="offline", prompt="consent", **extra)
        self.thread = threading.Thread(target=self._serve, daemon=True, name="qosha-google-signin")

    # ---- the loopback server -------------------------------------------------------------------------------------
    def _serve(self):
        try:
            while not self._done.is_set() and _now() < self.deadline:
                self.srv.handle_request()     # returns after 0.5 s without a request
        except Exception as exc:              # never leave the flow "waiting" if the server breaks
            self._finish("failed", "server_" + type(exc).__name__, tr("google.not_connected_retry"))
        finally:
            if self.status == "waiting":
                self._finish("timeout", "timeout", _timeout_plain())
            try:
                self.srv.server_close()
            except Exception:
                pass

    def _finish(self, status: str, error: str = "", plain: str = "") -> bool:
        with self._lock:
            if self.status != "waiting":
                return False
            self.status, self.error, self.plain = status, error, plain
            self._done.set()
            return True

    def _callback(self, h):
        u = urlparse(h.path)
        q = parse_qs(u.query)
        if u.path != "/" or ("code" not in q and "error" not in q):
            h.send_response(404); h.send_header("Content-Length", "0"); h.end_headers(); return
        got_state = q.get("state", [""])[0]
        if self.status != "waiting":
            h._page(410, tr("google.page.finished_title"), tr("google.page.finished"))
            return
        if not got_state or not hmac.compare_digest(got_state.encode(), self.state.encode()):
            # not the sign-in Qosha started (a stale tab, a forged address): refused, the real one keeps waiting
            self.refused += 1
            h._page(400, tr("google.page.not_connected_title"), tr("google.wrong_state"))
            return
        if "error" in q:
            err = q.get("error", ["cancelled"])[0][:80]
            plain = ("The Google sign-in was cancelled." if err == "access_denied" else
                     "Google did not connect (Google said: %s)." % err)
            line = account_line()
            self._finish("failed", err, (plain + (" " + line if line else "") + " Press Connect Google to try again.") if line
                         else tr("google.error.access_denied") if err == "access_denied" else tr("google.error.other", code=err))
            h._page(200, tr("google.page.not_connected_title"), plain + " Go back to Qosha and try again.")
            return
        try:
            self._store(q)
        except Unticked as exc:
            self._finish("failed", "unticked", unticked_message(exc))
            h._page(200, tr("google.page.not_connected_title"), unticked_message(exc) + " " + _or_key("google.go_back", "Go back to Qosha."))
            return
        except Refused as exc:
            self._finish("failed", "refused", exc.plain)
            h._page(200, tr("google.page.not_connected_title"), exc.plain + " " + _or_key("google.go_back", "Go back to Qosha."))
            return
        except Stopped as exc:
            h._page(200, tr("google.page.not_connected_title"), tr("google.page.stopped") if getattr(exc, "at_commit", False)
                    else "This Google sign-in was stopped, so nothing was kept. Go back to Qosha.")
            return
        except Exception as exc:
            try:                         # best effort: a closed stderr must not stop the answer below
                print("qosha google sign-in: could not store the answer: %s: %s" % (type(exc).__name__, str(exc)[:200]),
                      file=sys.stderr, flush=True)
            except Exception:
                pass
            self._finish("failed", "token_" + type(exc).__name__,
                         tr("google.store_failed", error=type(exc).__name__))
            h._page(200, tr("google.page.not_connected_title"), tr("google.page.store_failed"))
            return
        if self.status != "connected" and not self._finish(
                "connected", "", tr("google.connected", email=self.email) if self.email else tr("google.connected_no_email")):
            # stopped before the commit's turn: the commit wrote nothing, so nothing is taken back here (deleting the
            # files by name here once removed the previous account's sign-in: carried C2)
            h._page(200, tr("google.page.not_connected_title"), tr("google.page.stopped"))
            return
        h._page(200, tr("google.page.connected_title"), tr("google.page.connected", email=self.email) if self.email
                else tr("google.page.connected_no_email"))

    def _store(self, q):
        """Exchanges the code (with the PKCE verifier) and writes the skill's token and the Workspace tools' copy."""
        ok = False
        try:
            r = _GoogleFlow._store_checked(self, q)
            ok = True
            return r
        except (Unticked, Refused) as exc:
            if getattr(exc, "revoked", False):
                email = str(getattr(self, "_refused_email", "") or "")
                if not email:
                    try:
                        email = str(_id_claims(self.flow.credentials).get("email") or "")
                    except Exception:  # noqa: BLE001
                        email = ""
                _signed_out_after_refusal(Path(self.s.TOKEN_PATH).parent, email)
            raise
        finally:
            if not ok:                   # failed, refused or cancelled: no token of it stays in memory (C3, C5)
                _drop(self, getattr(self, "_signin_creds", None))
            self._signin_creds = None

    def _store_checked(self, q):
        s = self.s
        os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"
        self._signin_creds = None
        with _quiet_oauth():
            self.flow.fetch_token(code=q["code"][0])
        creds = self._signin_creds = self.flow.credentials
        g = getattr(creds, "granted_scopes", None)
        # Google's token answer is what counts; the browser's callback is used only when the answer says nothing (H1)
        granted = list(g) if g is not None else q.get("scope", [""])[0].split()
        if g is None and not granted:
            with _quiet_oauth():
                asked = _tokeninfo_scopes(creds)       # neither answer named the permissions: Google is asked (r2 H6)
            if asked is None:
                _drop(self, creds)               # dropped here, never revoked (whole-grant rule)
                raise Refused(tr("google.refused.unchecked"), dropped=True)
            granted = asked
        if granted and not all(x in _READ_SCOPE_OK for x in granted):
            # Google gave more than reading: nothing is kept, the grant is taken back (1.20.9)
            ok = _revoke_if_live(self, creds)
            raise Refused(tr("google.refused.more_than_read"), ok)
        missing = [plain for s, plain in _PLAIN.items() if "https://www.googleapis.com/auth/" + s not in granted]
        if missing:
            # boxes left unticked on Google's page: not connected, nothing kept; dropped here, never revoked (a revoke
            # would sign the same account out on the person's other computers; 22 Nov, orchestrator)
            _drop(self, creds)
            if isinstance(getattr(self, "status", "waiting"), str) and getattr(self, "status", "waiting") != "waiting":
                raise Stopped()
            raise Unticked(missing, dropped=True)
        claims = _id_claims(creds)
        dom = account_domain()
        if dom and str(claims.get("hd") or "").lower() != dom.lower():
            # the opt-in Workspace: an account from elsewhere is refused (hd= only steers Google's chooser; review H1)
            _drop(self, creds)                   # another account: dropped here, never revoked (its own other computers)
            raise Refused(tr("google.refused.domain", domain=dom), dropped=True)
        email = ""
        try:
            from googleapiclient.discovery import build
            email = build("gmail", "v1", credentials=creds).users().getProfile(userId="me").execute().get("emailAddress", "")
        except Exception:
            pass
        if not email and claims.get("email_verified") is not False:
            email = str(claims.get("email") or "")   # Gmail didn't answer: the account Google's sign-in names (review M1)
        if not email:
            # no account to file the Workspace tools' copy under: half a connection is none (final pass r2 H3)
            _drop(self, creds)                   # dropped here, never revoked (whole-grant rule)
            raise Refused(tr("google.refused.no_account"), dropped=True)
        payload = s._normalize_authorized_user_payload(json.loads(creds.to_json()))
        if granted:
            payload["scopes"] = granted
        _GoogleFlow._commit(self, creds, email, granted, payload)

    def _commit(self, creds, email: str, granted, payload) -> None:
        """Writes the sign-in as one step (carried C1, C2; round 2 GPT r1 #1; shrunk after GPT r2 NEW-1/NEW-2, 25 Nov
        2026). Disconnect takes the same process lock, so the two never overlap. The files are written exactly as
        1.20.44 wrote them (the skill's token first, then the Workspace copy), so the Workspace copy is published only
        after the token is in place. The sign-in must be live (not cancelled, still the current one) before anything is
        written, again before the Workspace copy is published, and once more, under its own lock (held for nothing
        else), when it switches to connected; if it was stopped meanwhile, what it wrote is put back first. On any
        failure the new grant is dropped by _store, never revoked (whole-grant rule)."""
        lock = getattr(self, "_lock", None)
        if not (hasattr(lock, "__enter__") and hasattr(lock, "__exit__")):
            lock = None
        with _commit_lock():
            if not _GoogleFlow._live(self):
                raise _stopped_at_commit()         # cancelled, or a newer sign-in is the live one: nothing written
            plain = tr("google.connected", email=email) if email else tr("google.connected_no_email")
            tok = Path(self.s.TOKEN_PATH)
            ws_path = workspace_mcp_dir() / (quote(email, safe="@._-") + ".json")
            previous, prev_ws = _read_back(tok), _read_back(ws_path)   # the working sign-in (GPT v H3)
            _private_json(tok, payload)
            try:
                if not _GoogleFlow._live(self):    # stopped while the token was written: the Workspace copy is never
                    raise _stopped_at_commit()     # published, so no Workspace reader can load this grant (GPT r2 NEW-2)
                ws = _write_workspace_mcp(creds, email, granted)
                # the sign-in's own lock only for this check and the switch (never during file work), so a Cancel or the
                # page's Disconnect never waits behind a save and then finds the new account connected (GPT r1 #1)
                with (lock if lock is not None else contextlib.nullcontext()):
                    live = _GoogleFlow._live(self)
                    if live:
                        self.email, self.scopes, self.workspace_mcp = email, granted, ws
                    if live and lock is not None:
                        self.plain, self.error = plain, ""     # the sentence before the status (Gemini r1 #3)
                        self.status = "connected"
                        if getattr(self, "_done", None) is not None:
                            self._done.set()
                if not live:                       # stopped in between: its Workspace copy is put back too
                    _put_back(ws_path, prev_ws)
                    raise _stopped_at_commit()
            except BaseException:
                _put_back(tok, previous, times=False)   # half a connection is none (final pass H5, GPT v H3)
                raise
            try:
                (tok.parent / SIGNED_OUT).unlink()  # a fresh sign-in, fully written: no longer signed out
            except OSError:
                pass

    def _live(self) -> bool:
        """Not cancelled or ended, and no newer sign-in is the live one."""
        status = getattr(self, "status", "waiting")
        cur = _REG.current
        return not ((isinstance(status, str) and status != "waiting") or (
            cur is not None and cur is not self and getattr(cur, "status", "") == "waiting"))

    # ---- what callers see ----------------------------------------------------------------------------------------
    def wait(self, timeout: float) -> bool:
        return self._done.wait(timeout)

    def snapshot(self) -> Dict[str, Any]:
        r = {"flow_id": self.id, "status": self.status, "plain": self.plain, "error": self.error,
             "seconds_left": max(0, int(self.deadline - _now())) if self.status == "waiting" else 0,
             "refused": self.refused, "browser_opened": self.browser_opened, "account_hint": account_line()}
        if self.status == "waiting":
            r["auth_url"] = self.url
            r["waiting_line"] = waiting_line()
        if self.status == "connected":
            r.update({"email": self.email, "scopes": self.scopes, "workspace_mcp": self.workspace_mcp})
        return r


def _stopped_at_commit() -> "Stopped":
    stop = Stopped()
    stop.at_commit = True                      # the page says what 1.20.43 said for a sign-in stopped this late
    return stop


def _timeout_plain() -> str:
    return (tr("google.timeout") if not account_line() else
            "The Google sign-in was not finished within 10 minutes. "
            + (account_line() + " " if account_line() else "") + "Press Connect Google to try again.")


def _prepare():
    """(setup module, client file) or a {"ok": False, ...} answer when this computer can't start a sign-in."""
    s = _skill_setup()
    secret = Path(s.CLIENT_SECRET_PATH)
    if not secret.exists():
        shipped = Path(__file__).resolve().parent.parent / "google_client.json"
        if shipped.is_file():
            shutil.copyfile(shipped, secret)
            os.chmod(secret, 0o600)
        else:
            return None, {"ok": False, "error": "no_client", "plain": tr("google.no_client")}
    # The Google packages are the engine's own (its "google" extra). The skill's own check wants exact older versions
    # and runs pip when they differ; a person's computer has no pip (Windows, a client Mac), so it is not used here.
    try:
        from google_auth_oauthlib.flow import Flow  # noqa: F401
        import googleapiclient.discovery  # noqa: F401
        import google.oauth2.credentials  # noqa: F401
    except Exception:
        return None, {"ok": False, "error": "no_google_packages", "plain": tr("google.no_packages")}
    return (s, secret), None


def _open(flow: "_GoogleFlow") -> bool:
    try:
        flow.browser_opened = bool(webbrowser.open(flow.url))
    except Exception:
        flow.browser_opened = False
    return flow.browser_opened


def start_flow(open_browser: bool = False, ttl: int = FLOW_TTL) -> Dict[str, Any]:
    """Starts a sign-in (or returns the one already waiting: never two at once) and answers at once with Google's
    address. open_browser: also ask this computer to open it (a second path; on Windows it may open behind)."""
    with _REG.lock:
        cur = _REG.current
        if cur is not None and cur.status == "waiting" and _now() < cur.deadline:
            r = dict(cur.snapshot(), ok=True, reused=True)
        else:
            if cur is not None and cur.status == "waiting":
                cur._finish("timeout", "timeout", _timeout_plain())   # past its deadline: its late answer can't
                # connect over the next sign-in, whatever that one becomes (Gemini r1 #2)
            try:
                prep, problem = _prepare()
            except Exception as exc:
                return {"ok": False, "error": "no_skill", "plain": tr("google.no_skill", error=type(exc).__name__)}
            if problem:
                return problem
            cur = _GoogleFlow(prep[0], prep[1], ttl)
            _REG.current = cur
            cur.thread.start()
            r = dict(cur.snapshot(), ok=True, reused=False)
    if open_browser and r.get("status") == "waiting":
        r["browser_opened"] = _open(cur)
    return r


def _find(flow_id: str):
    cur = _REG.current
    if cur is not None and flow_id and hmac.compare_digest(str(flow_id).encode(), cur.id.encode()):
        return cur
    return None


def flow_status(flow_id: str) -> Dict[str, Any]:
    cur = _find(flow_id)
    if cur is None:
        return {"flow_id": flow_id, "status": "unknown", "plain": tr("google.flow_expired")}
    return cur.snapshot()


def open_in_browser(flow_id: str) -> Dict[str, Any]:
    """Opens the waiting flow's own address from this computer (the page asks when its own window.open was blocked)."""
    cur = _find(flow_id)
    if cur is None or cur.status != "waiting":
        return {"ok": False, "status": cur.status if cur else "unknown"}
    return {"ok": True, "browser_opened": _open(cur)}


def current_flow() -> Dict[str, Any]:
    cur = _REG.current
    return cur.snapshot() if cur is not None else {}


def cancel_flow(flow_id: str = "") -> bool:
    """Ends a waiting sign-in (Cancel, or Disconnect pressed meanwhile); its late answer is refused. With flow_id, only
    that sign-in is ended."""
    cur = _find(flow_id) if flow_id else _REG.current
    if cur is None or cur.status != "waiting":
        return False
    return cur._finish("cancelled", "cancelled", tr("google.stopped"))


def waiting_signin():
    """For a "waiting for you" count (waiting.py): None, or the Google sign-in that waits for the person right now:
    {"kind": "google_signin", "flow_id", "since" (epoch s), "seconds_left", "line", "auth_url"}."""
    cur = _REG.current
    if cur is None or cur.status != "waiting" or _now() >= cur.deadline:
        return None
    return {"kind": "google_signin", "flow_id": cur.id, "since": cur.started, "seconds_left": int(cur.deadline - _now()),
            "line": waiting_line(), "auth_url": cur.url}


def connect(timeout: int = 300, open_browser: bool = True) -> Dict[str, Any]:
    """Starts a sign-in and WAITS for it (scripts and older callers). The page and the chat tool use start_flow()."""
    r = start_flow(open_browser=open_browser, ttl=max(timeout, 1) + 5)
    if not r.get("ok"):
        return r
    cur = _find(r["flow_id"])
    if cur is not None and not cur.wait(timeout):
        cur._finish("timeout", "timeout", "The Google sign-in was not finished in time.")
    snap = cur.snapshot() if cur is not None else {"status": "unknown"}
    if snap["status"] == "connected":
        return {"ok": True, "email": snap.get("email", ""), "scopes": snap.get("scopes", []),
                "browser_opened": snap.get("browser_opened"), "workspace_mcp": snap.get("workspace_mcp", ""),
                "plain": snap.get("plain") or tr("google.connected_no_email")}
    return {"ok": False, "error": snap.get("error") or snap["status"], "auth_url": r.get("auth_url", ""),
            "plain": snap.get("plain") or "Google did not connect."}


SCHEMA = {"name": "qosha_connect_google",
          "description": ("Connect the person's Google account (Gmail, Calendar, Drive, Docs, Sheets, Contacts) to Qosha. "
                          "Call it once: it starts Google's sign-in, tries to open it in their browser and returns at once "
                          "with the sign-in link (auth_url). Always give the person that link as a clickable link (the "
                          "browser may open behind other windows), and say which Google account to use (account_hint). "
                          "When they say they are done, call it again with check=true to see whether Google is connected. "
                          "They copy nothing back. Use this instead of the google-workspace skill's manual "
                          "--auth-url/--auth-code steps. Afterwards use the google-workspace skill's google_api.py."),
          "parameters": {"type": "object", "properties": {
              "check": {"type": "boolean", "description": "true: only report whether the sign-in started earlier has finished."}},
              "required": []}}


def _handler(args, **kw) -> str:
    try:
        if isinstance(args, dict) and args.get("check"):
            cur = current_flow()
            if not cur:
                r = {"ok": False, "status": "none", "plain": "No Google sign-in was started. Call qosha_connect_google without check to start one."}
            else:
                r = dict(cur, ok=cur.get("status") == "connected")
                if cur.get("status") == "waiting":
                    r["plain"] = "Still waiting for the person to finish Google's sign-in. " + account_line()
        else:
            r = start_flow(open_browser=True)
            if r.get("ok") and r.get("status") == "waiting":
                r["plain"] = ("Google's sign-in has started. Give the person this link (it may also have opened in their "
                              "browser): %s\n%s%s When they are done, call qosha_connect_google with check=true."
                              % (r.get("auth_url"), (account_line() + " ") if account_line() else "", waiting_line()))
    except Exception as exc:
        r = {"ok": False, "error": type(exc).__name__, "plain": "Google could not be connected: %s" % exc}
    return json.dumps(r)


def register(ctx) -> None:
    retire_later()                             # an older write-capable sign-in never stays on disk (after any update)
    ctx.register_tool(name="qosha_connect_google", toolset="qosha", schema=SCHEMA, handler=_handler,
                      check_fn=lambda: True, description=SCHEMA["description"], emoji="🔗")


if __name__ == "__main__":
    import sys
    print(json.dumps(connect(open_browser="--no-browser" not in sys.argv), indent=2))
