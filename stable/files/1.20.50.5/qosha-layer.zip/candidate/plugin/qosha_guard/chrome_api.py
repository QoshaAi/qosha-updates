"""Qosha in the person's own Chrome (mc21): the switch, the tools, the window routes.

* The switch: config `browser.qosha_chrome: true` ("In your own Chrome", Settings > Browser). While it is on and Qosha's
  extension is connected, the engine's own browser tool is pointed at Qosha's relay (BROWSER_CDP_URL in this process;
  the browser tool's own tab marker off). Any change stops the engine's browser connection, so the next step starts
  fresh on the chosen browser (fail closed: a dead or changed address never keeps a stale connection).
* "Do it in the background": the same setting as for Qosha's own browser (`browser.headed: false`).
* Tools: `qosha_chrome_setup` (one-time card: Qosha writes its link to Chrome, opens Chrome's Extensions page and shows
  the folder to load) and `qosha_browser_confirm` (the person's Allow for one held step; the card is ask.py's).
* Routes under /api/plugins/qosha/chrome: status and stop for any Qosha page; continue, setup, mode, open-extensions and
  show-folder only from the Qosha app window (approval_gate + checked here again).
"""
from __future__ import annotations

import json
import os
import re
import sys
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Optional

def _sib(name: str):
    """A sibling module of Qosha's guard, the same one whether this file was imported as part of the plugin or loaded by
    file path from the dashboard (all state lives in one place per process: sys._qosha_chrome_shared)."""
    import importlib
    import importlib.util
    import os as _os
    import sys as _sys
    pkg = __name__.rpartition(".")[0]
    if pkg:
        try:
            return importlib.import_module(pkg + "." + name)
        except ImportError:
            pass
    for n, m in list(_sys.modules.items()):
        if n.endswith("qosha_guard." + name) or n == "qosha_chrome_" + name:
            return m
    spec = importlib.util.spec_from_file_location("qosha_chrome_" + name, _os.path.join(_os.path.dirname(__file__), name + ".py"))
    mod = importlib.util.module_from_spec(spec)
    _sys.modules["qosha_chrome_" + name] = mod
    spec.loader.exec_module(mod)
    return mod


chrome_judge, chrome_relay, chrome_setup = _sib("chrome_judge"), _sib("chrome_relay"), _sib("chrome_setup")
_SHARED = sys.__dict__.setdefault("_qosha_chrome_shared", {})
_ENV_SET = _SHARED.setdefault("env", {"url": None})
_lock = _SHARED.setdefault("api_rlock", threading.RLock())   # one decision at a time: setting, pending setup, env (final pass F7)
_USED: Dict[str, float] = _SHARED.setdefault("used", {})   # sessions that used the person's Chrome in this answer

SETUP_TITLE = "Qosha wants to connect to your Chrome"
SETUP_ROWS = [
    ("What happens", "Qosha writes its link to Chrome on this computer (only Qosha's extension can use it), copies its "
                     "Chrome extension to a folder, and opens Chrome's Extensions page."),
    ("What you do", "In Chrome, turn on Developer mode (top right), press Load unpacked and choose the folder Qosha shows "
                    "you. Then turn on \"In your own Chrome\" in Settings > Browser."),
    ("Then", "Qosha browses in your Chrome from then on (Settings > Browser switches back): only in its own green Qosha "
             "tab group, or a tab you hand over, signed in as you. It leaves Send, Pay, Delete, Share and Submit for you to "
             "press yourself."),
]
_LOCK_HOLD = threading.local()


@contextmanager
def _settings_lock():
    """One writer at a time for Qosha's Chrome settings, across threads AND processes (the Qosha app window, the agent, a
    second Qosha): the engine's own cross-process file lock (fcntl / msvcrt) on a lock file of Qosha's, held from the read
    to the write, so no Qosha writer saves over another's change (SWITCH-STALE-SAVE). No lock = nothing is written."""
    from hermes_cli.auth import _file_lock
    path = Path(chrome_judge._state_path()).with_name("chrome-state.lock")
    with _lock, _file_lock(path, _LOCK_HOLD, 20.0, "Qosha's Chrome settings are busy"):
        yield


def _state_edit(change) -> Dict[str, Any]:
    """Qosha's own record (chrome-state.json): read, change, write back whole. Call under _settings_lock."""
    path = Path(chrome_judge._state_path())
    d = chrome_judge.state()
    change(d)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name("%s.%d.tmp" % (path.name, os.getpid()))
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(d, f)
    for i in range(40):                        # Windows refuses the swap while another process has the file open to read
        try:
            os.replace(tmp, path)
            break
        except PermissionError:
            if i == 39:
                raise
            time.sleep(0.05)
    return d


def _cfg() -> Dict[str, Any]:
    try:
        from hermes_cli.config import load_config
        return dict((load_config() or {}).get("browser") or {})
    except Exception:
        return {}


def enabled() -> bool:
    """On only when the setting says so AND Qosha's own record does: the record is written only by set_mode, so a stale
    copy of the settings saved by anything else can never switch Chrome mode back on (SWITCH-STALE-SAVE)."""
    return _cfg().get("qosha_chrome") is True and chrome_judge.state().get("on") is True


def front() -> bool:
    return str(_cfg().get("headed", True)).strip().lower() not in ("false", "0", "no", "off")


def set_mode(on: bool) -> Dict[str, Any]:
    import contextlib
    import io
    from hermes_cli.config import set_config_value
    lost = []

    def write():
        if not on:                             # Qosha's own record first: off holds whatever is saved after it
            try:
                _state_edit(lambda d: d.update(on=False))
            except Exception:                  # the record can't be rewritten: without it Chrome mode is off as well
                try:                           # so it is removed (fail closed)
                    os.remove(chrome_judge._state_path())
                except FileNotFoundError:
                    pass
                except Exception:
                    lost.append(1)
            import secrets as _sec             # the marker, then the setting: any process sees it (final-D F7)
            set_config_value("browser.qosha_chrome_off_at", "%.3f-%s" % (time.time(), _sec.token_hex(4)), force=True)
        set_config_value("browser.qosha_chrome", "true" if on else "false", force=True)
        if not on:
            set_config_value("browser.qosha_chrome_pending", "false", force=True)   # r2 GPT F11
        else:
            _state_edit(lambda d: d.update(on=True))
    with _lock, contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        try:
            with _settings_lock():             # every Qosha writer of these settings, in any process, one at a time
                write()
        except TimeoutError:
            if on:
                raise                          # switching on waits its turn or fails
            write()                            # switching OFF never waits on a stuck writer
        if not on:
            chrome_judge.void_held(None, "off")  # steps waiting for an Allow end with the switch-off
        apply_mode()
    if lost:                                   # off in the settings, but an old copy of them could bring it back: say so
        raise OSError("Qosha could not save the switch-off in its own record")
    return status()


def _stop_engine_browser() -> None:
    try:
        from tools.browser_use_cli import stop_harness_daemons
        stop_harness_daemons()
    except Exception:
        pass
    try:
        from tools import browser_session_cloud as cloud
        cloud.reset_caches()
    except Exception:
        pass


def apply_mode() -> Optional[str]:
    """Point the engine at the relay (or away from it). Returns the address in use, or None. Never raises."""
    try:
        with _lock:                              # one decision at a time, from reading the setting to the env (pass A F7)
            want = None
            if enabled():
                r = chrome_relay.relay()
                chrome_judge.set_front(front())
                if r is not None and r.connected() and not r.stopped:
                    want = r.cdp_url()
            r = chrome_relay.relay(start=False)
            mode = "front" if front() else "background"
            if want and r is not None and _ENV_SET.get("mode") != mode:
                try:                                   # Settings' "Do it in the background" reaches Chrome (r1 GPT 14)
                    got = r.call_ext("config", timeout=10, mode=mode) or {}
                    if got.get("mode") == mode:
                        _ENV_SET["mode"] = mode
                except Exception:
                    pass
                if _ENV_SET.get("mode") != mode:       # Chrome did not take it: not used until it does (verify F7)
                    want = None
            cur = os.environ.get("BROWSER_CDP_URL")
            owned = _ENV_SET.setdefault("owned", [])   # every relay address Qosha itself set (pass 2 F7)
            if want:
                if want not in owned:
                    owned.append(want)
                    del owned[:-20]
                if want != _ENV_SET["url"] or cur != want:
                    os.environ["BROWSER_CDP_URL"] = want
                    os.environ["BH_TAB_MARKER"] = "0"
                    _ENV_SET["url"] = want
                    _stop_engine_browser()
            else:
                if cur and cur in owned:               # Qosha's own address, whatever the cache says: taken back
                    os.environ.pop("BROWSER_CDP_URL", None)
                    _stop_engine_browser()
                elif _ENV_SET["url"] is not None:
                    _stop_engine_browser()
                _ENV_SET["url"] = None
        return want
    except Exception:
        return None


def ready() -> Optional[str]:
    """None when the person's Chrome can be used now; else a plain refusal (fail closed)."""
    r = chrome_relay.relay(start=False)
    if r is None or not r.connected():
        return ("Qosha is not connected to your Chrome right now (Chrome is closed, or its Qosha extension is off). "
                "Nothing was opened. Ask the person to open Chrome, or to switch Settings > Browser back to Qosha's own "
                "browser.")
    if (r.ext_info or {}).get("mismatch"):
        return "The Qosha extension in Chrome is not the one this Qosha ships; ask the person to load it again (Settings > Browser)."
    if r.stopped:
        return ("The person pressed Stop: Qosha does nothing in Chrome until they let it continue in the Qosha app.")
    want = apply_mode()
    if want is None:
        return "Qosha could not connect the browser tool to your Chrome. Nothing was opened."
    try:                       # the address the engine will really use must be the relay's (review r1 GPT 01)
        from tools.browser_session_cdp import get_cdp_override_raw, live_cdp_override
        if os.environ.get("BU_CDP_WS") or os.environ.get("BU_CDP_URL") or live_cdp_override() \
                or get_cdp_override_raw() != want:
            return ("Another browser connection is set for Qosha's browser tool, so Qosha won't use your Chrome until it "
                    "is removed (Settings > Browser). Nothing was opened.")
    except ImportError:
        pass
    return None


def note_used(session_id: str) -> None:
    import time
    _USED[str(session_id or "")] = time.time()


def used(session_id: str) -> bool:
    return str(session_id or "") in _USED


def end_answer(session_id: str = "", **_kw) -> None:
    """post_llm_call: this chat's held steps end; Qosha's tabs go idle (background: its own tabs close; handed tabs go
    back). Other chats' holds and network cards are left alone (review r1 GPT 10)."""
    chrome_judge.end_answer(session_id)
    if not chrome_judge.last_driver_ends(session_id):
        return                                # another chat still works in Chrome: every tab stays (r2 GPT F8, verify F8)
    r = chrome_relay.relay(start=False)
    if r is not None and r.connected():
        try:
            r.call_ext("end", timeout=10, background=not front())
        except Exception:
            pass


def _num(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _pending_mode(on: bool, since: str = "") -> None:
    import contextlib
    import io
    from hermes_cli.config import set_config_value
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()), _settings_lock():
        set_config_value("browser.qosha_chrome_pending", "true" if on else "false", force=True)
        if on:                                 # the switch-off marker this setup started under (final-D F7)
            set_config_value("browser.qosha_chrome_pending_at", str(since), force=True)


def on_connected() -> None:
    """Chrome connected with Qosha's own extension: a setup the person asked for now switches browsing to their Chrome;
    the background/front setting is sent again (a restarted Chrome starts in front; r2 GPT F7)."""
    _ENV_SET.pop("mode", None)
    _ENV_SET["url"] = None
    # (final-E) a connection never switches Qosha's browsing to Chrome by itself; the setup card did, or Settings does


def status() -> Dict[str, Any]:
    r = chrome_relay.relay(start=False)
    st = r.status() if r is not None else {"connected": False, "stopped": False, "paused": False, "extension": {}}
    linked = (chrome_setup.host_dir() / (chrome_setup.HOST_NAME + ".json")).is_file()
    return {"enabled": enabled(), "front": front(), "linked": linked, "folder": str(chrome_setup.ext_dir()),
            "connected": bool(st.get("connected")), "stopped": bool(st.get("stopped")), "paused": bool(st.get("paused")),
            "mismatch": bool((st.get("extension") or {}).get("mismatch")),
            # store-ID review r1/r2: when a second copy of the extension was last turned away (seconds ago, or None), and
            # whether the copy that linked is the Chrome Web Store one (then "out of date" means: update Qosha)
            "another_copy_ago": st.get("another_copy_ago") if isinstance(st.get("another_copy_ago"), int) else None,
            "store_copy": str(st.get("origin") or "") in tuple(getattr(chrome_setup, "EXT_ORIGINS", ())[1:]),
            "chrome": str((st.get("extension") or {}).get("ua") or "").split("Chrome/")[-1].split(" ")[0] if st.get("connected") else "",
            "activity": activity(), "allowed": allowed_list()}


def activity() -> Dict[str, Any]:
    import time
    a = chrome_judge.LAST_ACTIVITY
    return {"active": bool(a.get("at")) and time.time() - a["at"] < 120, "site": a.get("site", "")}


def stop() -> Dict[str, Any]:
    r = chrome_relay.relay(start=False)
    if r is not None:
        r.control("stop")
    apply_mode()
    return status()


def resume() -> Dict[str, Any]:
    r = chrome_relay.relay(start=False)
    if r is not None:
        r.control("resume")
    apply_mode()
    return status()


def show() -> Dict[str, Any]:
    """Bring Qosha's tab to the front in Chrome (the bar's Show me)."""
    r = chrome_relay.relay(start=False)
    if r is not None and r.connected():
        try:
            tabs = r.call_ext("list", timeout=10) or []
            if tabs:
                r.call_ext("activate", timeout=10, tab=tabs[-1]["tab"], front=True)
        except Exception:
            pass
    return status()


def allowed_list() -> list:
    """The person's Always-allowed Chrome steps: [(rule, kind text, site)]."""
    try:
        from hermes_cli.config import load_config
        out = []
        for x in (load_config() or {}).get("command_allowlist") or []:
            m = str(x)
            if m.startswith("plugin_rule:qosha:chrome."):
                kind, _, rest = m[len("plugin_rule:qosha:"):].partition(":")
                site = rest.split(":")[0]
                if kind not in chrome_judge.HOLDABLE:     # final steps are the person's own now (mc21 shrink)
                    continue
                if m != "plugin_rule:" + chrome_judge.rule_for(kind, site):
                    continue                              # a taken-back permission's old copy: it allows nothing
                out.append({"rule": m, "what": chrome_judge.KIND_TEXT.get(kind, kind), "site": site})
        return out
    except Exception:
        return []


def forget(rule: str) -> Dict[str, Any]:
    """Take back one Always-allowed Chrome step (only Qosha's Chrome rules)."""
    rule = str(rule or "")
    m = re.fullmatch(r"plugin_rule:(qosha:chrome\.[a-z]+:[a-z0-9.-]{1,253})(?::\d+)?", rule)
    if not m:
        return {"ok": False}
    base = m.group(1)
    from hermes_cli.config import load_config, save_config

    def bump(d):
        g = d.get("gens")
        if not isinstance(g, dict):
            g = d["gens"] = {}
        g[base] = int(g.get(base) or 0) + 1
    try:
        with _settings_lock():                 # one Qosha writer at a time, across processes too (SWITCH-STALE-SAVE)
            # first, in Qosha's own record: the permission's name changes, so every copy of the old one, whoever saves
            # it again (the engine's own "Always allow" writer doesn't take this lock), matches nothing (TAKEBACK-RESTORED)
            _state_edit(bump)
            pre = "plugin_rule:" + base
            keep = [x for x in (load_config().get("command_allowlist") or [])
                    if not (str(x) == pre or str(x).startswith(pre + ":"))]
            # only this one setting is written, merged into the file as it is now: an older copy of the other settings
            # (the Chrome switch among them) is never saved back
            save_config({"command_allowlist": keep}, merge_existing=True)
    except (Exception, SystemExit):            # could not lock or save: say so, nothing half-done is reported as done
        return {"ok": False, "allowed": allowed_list()}
    return {"ok": True, "allowed": allowed_list()}


def setup() -> Dict[str, Any]:
    out = chrome_setup.setup()
    chrome_relay.relay()
    opened = chrome_setup.open_extensions_page()
    shown = chrome_setup.show_folder()
    return {"ok": True, "folder": out["extension_folder"], "opened_extensions_page": opened, "showed_folder": shown,
            "say": ("Done on Qosha's side. In Chrome: turn on Developer mode (top right of the Extensions page), press "
                    "Load unpacked and choose the folder %s. Then switch Settings > Browser to \"In your own Chrome\"."
                    % out["extension_folder"])}


# ---- "Connect Qosha to your Chrome": the Home notice and the guide (27 Nov 2026; pages/qosha-chrome-guide.js) ----------
# Offered when this Qosha has its extension files and Google Chrome is installed (Mac or Windows), Chrome has never
# connected and "In your own Chrome" is off; Not now hides it 3 days, Don't show again for good; one desktop
# notification ever. The guide's record is its own file (chrome-guide.json), never the switch's chrome-state.json.
GUIDE_SNOOZE_S = 3 * 86400
_GUIDE_LOCK = _SHARED.setdefault("guide_lock", threading.Lock())   # its own: never waits on Chrome


def _guide_path() -> Path:
    return Path(chrome_judge._state_path()).with_name("chrome-guide.json")


def _guide_read() -> Dict[str, Any]:
    """The guide's record. No file or damaged JSON: {} (nothing recorded). A file that can't be read right now (Windows
    sharing, permissions) raises, so nothing is written over it (review r1: Don't show again must survive)."""
    try:
        with open(_guide_path(), encoding="utf-8") as f:
            raw = f.read()
    except FileNotFoundError:
        return {}
    try:
        d = json.loads(raw)
    except ValueError:
        return {}
    return d if isinstance(d, dict) else {}


def _guide() -> Dict[str, Any]:
    try:
        return _guide_read()
    except Exception:
        return {}


def _guide_set(only_if_unset: str = "", **kv) -> bool:
    """Write the guide's record with these keys changed, under the guide's own lock. Never raises; False when it could
    not be written, or when only_if_unset names a key that is already recorded (claimed once)."""
    with _GUIDE_LOCK:
        path = _guide_path()
        tmp = path.with_name("%s.%d.%d.tmp" % (path.name, os.getpid(), threading.get_ident()))
        try:
            d = _guide_read()
            if only_if_unset and d.get(only_if_unset):
                return False
            d.update(kv)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(d, f)
            for i in range(40):                # Windows refuses the swap while another process reads the file
                try:
                    os.replace(tmp, path)
                    return True
                except PermissionError:
                    if i == 39:
                        raise
                    time.sleep(0.05)
        except Exception:
            try:
                tmp.unlink()
            except Exception:
                pass
        return False


def _system() -> str:
    return "mac" if sys.platform == "darwin" else "windows" if os.name == "nt" else "other"


def _chrome_exe() -> str:
    """The installed Google Chrome's program, or "" (the same places as ask.chrome_path, which the dashboard can't
    import when it loads these files by path)."""
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        places = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                  home + "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    elif os.name == "nt":
        places = [os.path.join(os.environ.get(v) or "", "Google", "Chrome", "Application", "chrome.exe")
                  for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA") if os.environ.get(v)]
    else:
        places = []
    return next((x for x in places if os.path.isfile(x)), "")


def _open_extensions() -> bool:
    """Chrome's Extensions page in the person's Chrome: the setup helper's own way first (Mac: open -a "Google Chrome"
    chrome://extensions); on Windows, when it can't find Chrome from here, Chrome's program itself with that page."""
    if chrome_setup.open_extensions_page():
        return True
    if _system() != "windows":
        return False
    exe = _chrome_exe()
    if not exe:
        return False
    try:
        import subprocess
        subprocess.Popen([exe, "chrome://extensions"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def guide_status() -> Dict[str, Any]:
    st = status()
    g = _guide()
    now = time.time()
    if st.get("connected") and not g.get("connected_at"):
        _guide_set(connected_at=now)          # connected once: the notice never comes back
        g = dict(g, connected_at=now)
    system = _system()
    ready = system in ("mac", "windows") and bool(chrome_setup.code_hash()) and bool(_chrome_exe())
    done = bool(st.get("connected") or st.get("enabled") or g.get("connected_at"))
    offer = bool(ready and not done and g.get("never") is not True and now >= _num(g.get("snooze_until")))
    return {"offer": offer, "notify": bool(offer and not g.get("notified_at")), "connected": bool(st.get("connected")),
            "enabled": bool(st.get("enabled")), "linked": bool(st.get("linked")), "system": system,
            "folder": str(st.get("folder") or "")}   # the page copies it at the press, before Chrome takes the focus


def guide_start() -> Dict[str, Any]:
    """Set it up: every step Qosha can do itself (its link to Chrome, the extension's folder, listening for Chrome,
    Chrome's Extensions page). Nothing is switched on: the guide asks the person once Chrome connects."""
    out = chrome_setup.setup()
    chrome_relay.relay()
    opened = _open_extensions()
    return {"ok": True, "folder": out["extension_folder"], "opened": bool(opened), "system": _system()}


def guide_dismiss(forever: bool = False) -> Dict[str, Any]:
    ok = _guide_set(never=True) if forever else _guide_set(snooze_until=time.time() + GUIDE_SNOOZE_S)
    return {"ok": ok}


def guide_notified() -> Dict[str, Any]:
    """The one desktop notification is claimed here first; a second claim is refused (review r1 H3)."""
    return {"ok": _guide_set(only_if_unset="notified_at", notified_at=time.time())}


# ---- tools ---------------------------------------------------------------------------------------------------------
SETUP_SCHEMA = {
    "name": "qosha_chrome_setup",
    "description": ("Connect Qosha to the person's own Chrome (signed in as them): Qosha writes its link to Chrome, copies "
                    "its extension and opens Chrome's Extensions page; the person then loads the extension. Use only "
                    "when the person asks to use their own Chrome. It asks them first."),
    "parameters": {"type": "object", "properties": {
        "turn_off": {"type": "boolean", "description": "true: go back to Qosha's own browser (no card)."}}, "required": []},
}
CONFIRM_SCHEMA = {
    "name": "qosha_browser_confirm",
    "description": ("Ask the person to allow a step Qosha held in their own Chrome: opening an address on another website "
                    "(or one that looks like it may carry what Qosha read), or the first typing or click on a website. "
                    "Pass the id from the browser tool's message. If they allow it, exactly that step is done once (that "
                    "address opened, that text typed, or that button clicked, if it is still the same); \"Always allow\" "
                    "covers that kind of step on that website from then on. Qosha never presses keys in their Chrome and "
                    "never clicks Send, Pay, Delete, Share or Submit: the person presses those."),
    "parameters": {"type": "object", "properties": {"id": {"type": "string", "description": "The held step's id."}},
                   "required": ["id"]},
}


def _setup_handler(args=None, **_kw) -> str:
    try:
        if isinstance(args, dict) and args.get("turn_off"):
            set_mode(False)
            return json.dumps({"ok": True, "say": "Qosha browses in its own browser again; your Chrome is left alone."})
        out = setup()                          # nothing is switched on here: the person does it in Settings (22:00 cut)
        return json.dumps(out)
    except Exception as e:
        return json.dumps({"ok": False, "say": "Setting up the link to Chrome didn't work (%s)." % type(e).__name__})


CONFIRM_DEADLINE = 30.0


def _confirm_handler(args=None, **_kw) -> str:
    hid = str((args or {}).get("id") or "") if isinstance(args, dict) else ""
    if not enabled():                          # switched off since the step was held (in any Qosha process): nothing runs
        return json.dumps({"ok": False, "error": "\"In your own Chrome\" is switched off; nothing was done."})
    h = chrome_judge.take(hid)
    if not h:
        return json.dumps({"ok": False, "error": "That step is no longer waiting (it ran, changed or expired). Take a new look."})
    r = chrome_relay.relay(start=False)
    if r is None or not r.connected():
        return json.dumps({"ok": False, "error": "Qosha is not connected to your Chrome; nothing was done."})
    import asyncio

    import time as _time
    deadline = _time.time() + CONFIRM_DEADLINE
    h["deadline"] = _time.monotonic() + CONFIRM_DEADLINE   # perform re-checks it right before Chrome acts (verify F5)

    async def locked():                       # the same one-at-a-time lock as every other command in that tab (r1 Gemini F5)
        lock = r.tab_locks.setdefault(str(h["tab"]), asyncio.Lock())
        async with lock:
            if _time.time() > deadline:       # queued too long: the caller was already told it failed (r2 GPT F5)
                return {"ok": False, "error": "Chrome was busy too long; nothing was done."}
            return await chrome_judge.perform(r, h)
    try:
        res = asyncio.run_coroutine_threadsafe(locked(), r.loop).result(40)
    except Exception as e:                    # it may have happened: say so (verify F5)
        res = {"ok": False, "error": "Chrome did not answer in time (%s); the step may or may not have happened. Take a new "
                                     "look before trying again." % type(e).__name__}
    return json.dumps(res)


def boot() -> None:
    """At start (the dashboard's routes and the agent plugin both call it; the relay's lock keeps one per computer): a
    person who connected Chrome before gets the launcher and extension files refreshed and the relay listening, so Chrome
    can connect before the first chat."""
    try:
        chrome_setup.ensure()
        if enabled() or (chrome_setup.host_dir() / (chrome_setup.HOST_NAME + ".json")).is_file():
            chrome_relay.relay()
            t = threading.Timer(5.0, apply_mode)
            t.daemon = True
            t.start()
    except Exception:
        pass


def register(ctx) -> None:
    boot()
    ctx.register_tool(name="qosha_chrome_setup", toolset="qosha", schema=SETUP_SCHEMA, handler=_setup_handler,
                      description=SETUP_SCHEMA["description"], emoji="🌐")
    ctx.register_tool(name="qosha_browser_confirm", toolset="qosha", schema=CONFIRM_SCHEMA, handler=_confirm_handler,
                      check_fn=enabled, description=CONFIRM_SCHEMA["description"], emoji="🌐")
    ctx.register_hook("post_llm_call", end_answer)


# ---- routes ---------------------------------------------------------------------------------------------------------
def _gate():
    try:
        from . import approval_gate as g
        return g
    except ImportError:
        import importlib.util as _ilu
        mod = sys.modules.get("qosha_approval_gate_for_chrome")
        if mod is None:
            spec = _ilu.spec_from_file_location("qosha_approval_gate_for_chrome",
                                                os.path.join(os.path.dirname(__file__), "approval_gate.py"))
            mod = _ilu.module_from_spec(spec)
            sys.modules["qosha_approval_gate_for_chrome"] = mod
            spec.loader.exec_module(mod)
        return mod


def from_window(scope) -> bool:
    try:
        return bool(_gate().from_qosha_window(scope))
    except Exception:
        return False


WINDOW_ONLY = {"ok": False, "say": "Open the Qosha app to do this: only the Qosha app window can change how Qosha uses "
                                   "your Chrome."}

try:
    from fastapi import APIRouter, Request
    from fastapi.responses import JSONResponse
    router = APIRouter()

    @router.get("/status")
    def _status():
        return status()

    @router.post("/stop")
    def _stop():
        return stop()

    @router.post("/show")
    def _show():
        return show()

    @router.post("/forget")
    async def _forget(request: Request):
        if not from_window(request.scope):
            return JSONResponse(WINDOW_ONLY, status_code=403)
        try:
            body = await request.json()
        except Exception:
            body = {}
        return forget(str((body or {}).get("rule") or ""))

    @router.post("/continue")
    def _continue(request: Request):
        if not from_window(request.scope):
            return JSONResponse(WINDOW_ONLY, status_code=403)
        return resume()

    @router.post("/setup")
    def _setup(request: Request):
        if not from_window(request.scope):
            return JSONResponse(WINDOW_ONLY, status_code=403)
        return setup()

    @router.post("/mode")
    async def _mode(request: Request):
        if not from_window(request.scope):
            return JSONResponse(WINDOW_ONLY, status_code=403)
        try:
            body = await request.json()
        except Exception:
            body = {}
        return set_mode(bool((body or {}).get("on")))

    @router.post("/open-extensions")
    def _open_ext(request: Request):
        if not from_window(request.scope):
            return JSONResponse(WINDOW_ONLY, status_code=403)
        return {"ok": chrome_setup.open_extensions_page()}

    @router.post("/show-folder")
    def _show_folder(request: Request):
        if not from_window(request.scope):
            return JSONResponse(WINDOW_ONLY, status_code=403)
        chrome_setup.copy_extension()
        return {"ok": chrome_setup.show_folder(), "folder": str(chrome_setup.ext_dir())}
    @router.get("/guide")
    def _guide_status():
        return guide_status()

    @router.post("/guide/start")
    def _guide_start(request: Request):
        if not from_window(request.scope):
            return JSONResponse(WINDOW_ONLY, status_code=403)
        return guide_start()

    @router.post("/guide/open")
    def _guide_open(request: Request):
        if not from_window(request.scope):
            return JSONResponse(WINDOW_ONLY, status_code=403)
        return {"ok": _open_extensions()}

    @router.post("/guide/dismiss")
    async def _guide_dismiss(request: Request):
        try:
            body = await request.json()
        except Exception:
            body = {}
        from starlette.concurrency import run_in_threadpool
        return await run_in_threadpool(guide_dismiss, isinstance(body, dict) and body.get("forever") is True)

    @router.post("/guide/notified")
    def _guide_notified(request: Request):
        if not from_window(request.scope):     # a browser tab never uses up the app's one notification (review r1 H3)
            return JSONResponse(WINDOW_ONLY, status_code=403)
        return guide_notified()
except Exception:  # pragma: no cover - no web framework in this process
    router = None
