"""The assistant's main brain (UAT 2 Nov). Mounted at /api/plugins/qosha/brain.

GET  /   the engine's main model setting in plain words, and what can be chosen:
         {"provider", "model", "effort", "label", "providers": [{"id", "name", "models": [{"id", "label",
         "efforts": [{"id", "label"}]}]}], "defaults": {"anthropic": {...}, "openai-codex": {...}}, "note"}
POST /   {"provider", "model", "effort"}: saves it as the engine's main model (model.provider/model.default, the
         engine's own assignment helpers) and its reasoning effort (agent.reasoning_effort). New chats, the home's
         main ask, projects and automations use it; a chat already open keeps its model.

Only Claude (provider anthropic) and ChatGPT (provider openai-codex) can be the main brain, and only when the
engine lists that provider as signed in on this computer; models are the ones the engine's own catalogue lists for that
account. Gemini answers in Ask Gemini and Ask All only (text only, no tools). Whatever the brain, every
tool step still goes through the same approval guard (pre_tool_call hook): this route only picks the model.
Nothing else in the config changes. The save works on the raw config file (the engine's own write-back primitives):
the whole expected file is computed first, the file must still be as it was read (else 409, someone else changed it),
it is written with the engine's comment-preserving atomic writer, read back and compared as a whole; any difference or
error, also while reading the result back, puts the previous bytes (or the absence of the file) back, unless someone
else has written the file after us (then nothing is put over their change and the person is told); the restore itself
is checked. The engine has no lock shared by its config writers (its Models page and chat gateway write the same way),
so a write landing in the instant between our last check and our atomic rename can be lost, exactly as between the
engine's own writers; every other interleaving is refused or rolled back.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import re
import stat
import sys
import threading
from pathlib import Path

from fastapi import APIRouter, Body
from fastapi.responses import JSONResponse

router = APIRouter()
_LOCK = threading.Lock()

NAMES = {"anthropic": "Claude", "openai-codex": "ChatGPT"}
# Gemini as a full assistant on the person's own computer (gemini-full; Ren, 27 Nov 2026: "qosha needs to able to
# select it as its own brain"): the engine's provider qosha_guard/gemini_provider registers. Local installs only.
GEMINI = "qosha-gemini"
EFFORT_NAMES = {"low": "Low", "medium": "Medium", "high": "High", "xhigh": "Extra high", "max": "Max"}
EFFORT_ORDER = ("low", "medium", "high", "xhigh", "max")
# Qosha's default model when the person has chosen none (Ren, 26 Nov 2026): ChatGPT follows the provider's newest,
# the top of the account's verified catalogue (qosha_guard/model_newest.py; its safe fallback when none is verified
# here), never the picker list's first entry, which can be a saved or locally declared model (review F03/F04). Claude
# stays on Opus 5.5 (Ren's choice, 26 Nov 2026: "Keep Opus 5.5"), a dated exception in gates/models_current.py.
# Other providers: the first of their list, as before. The person's own choice always wins.
PREFERRED = {"anthropic": "claude-opus-5-5"}
FOLLOW_NEWEST = ("openai-codex",)
_NEWEST = []


def _newest(pid: str) -> str:
    """qosha_guard/model_newest.py, loaded by path once (this file is loaded by path in the dashboard)."""
    if not _NEWEST:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "qosha_model_newest", Path(__file__).resolve().parent.parent / "qosha_guard" / "model_newest.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _NEWEST.append(mod)
    return _NEWEST[0].newest(pid)
DEFAULT_EFFORT = "medium"   # the engine's own default when agent.reasoning_effort is unset
NOTE = "Gemini answers questions in Ask Gemini and Ask All, but it can’t take actions for you (like reading your email or adding a task), so it can’t be the main assistant."
_FAMILY = {"fable": 0, "opus": 1, "sonnet": 2, "haiku": 3}


def model_label(provider: str, model: str) -> str:
    """Plain model names: claude-opus-5-5 → "Opus 5.5", gpt-6.1-sol → "GPT-6.1 Sol", gpt-5.6-sol-900k → "GPT-5.6 Sol (900K)"."""
    m = str(model or "")
    if provider == "anthropic":
        r = re.match(r"^claude-([a-z]+)-(\d+)(?:-(\d{1,2}))?(?:-\d{8})?$", m)
        if r:
            return "%s %s%s" % (r.group(1).title(), r.group(2), "." + r.group(3) if r.group(3) else "")
    if provider == GEMINI:
        r = re.match(r"^gemini-(\d+(?:\.\d+)?)((?:-[a-z0-9]+)*)$", m)
        if r:
            return " ".join(["Gemini", r.group(1)] + [w.title() for w in r.group(2).split("-") if w])
    if provider == "openai-codex":
        r = re.match(r"^gpt-(\d+(?:\.\d+)?)(?:-([a-z]+))?(?:-(\d+k))?$", m)
        if r:
            return "GPT-%s%s%s" % (r.group(1), " " + r.group(2).title() if r.group(2) else "",
                                   " (%s)" % r.group(3).upper() if r.group(3) else "")
    return m


def _claude_key(model: str):
    r = re.match(r"^claude-([a-z]+)-(\d+)(?:-(\d{1,2}))?(?:-\d{8})?$", model)
    if not r:
        return (1, 0, 0, 9, model)
    return (0, -int(r.group(2)), -int(r.group(3) or 0), _FAMILY.get(r.group(1), 9), model)


def qosha_default(pid: str, models: list) -> str:
    """What Qosha picks for a provider when the person has chosen nothing: PREFERRED while it is offered; for ChatGPT
    the provider's newest (verified here, else the safe fallback, also on a cold start when the picker shows the
    engine's curated list: review F04); else the first of the list (Claude's sorted newest version first)."""
    models = [m for m in (models or []) if isinstance(m, str) and m]
    if PREFERRED.get(pid) in models:
        return PREFERRED[pid]
    if pid in FOLLOW_NEWEST:
        try:
            n = _newest(pid)
        except Exception:
            n = ""
        return n or OFFERED[pid][0]
    return models[0] if models else ""


def efforts_for(provider: str, model: str) -> list:
    """Effort levels the engine sends for this model (from the engine's own helpers); none if they can't be read."""
    ids = ["low", "medium", "high"]
    try:
        if provider == "openai-codex":
            from agent.reasoning_effort import codex_supported_efforts
            ids = [e for e in EFFORT_ORDER if e in codex_supported_efforts(model)]
        elif provider == "anthropic":
            from agent import anthropic_adapter as aa
            if aa._supports_xhigh_effort(model):
                ids.append("xhigh")
            if aa._supports_adaptive_thinking(model):
                ids.append("max")
    except Exception:
        return []
    return [{"id": e, "label": EFFORT_NAMES[e]} for e in EFFORT_ORDER if e in ids]


# The models offered are a fixed, local list (c18 final gate: building the engine's live catalogue made it look for
# credentials and reach the network). These are models the lab's own accounts served on 2 Nov 2026 (the engine's
# catalogue, read once by hand); the model already in the config is always offered too.
# Refreshed 23 Nov 2026 (P0: Renato's picker fell back to this list and Fable was missing): today's models, as the
# engine's own catalogue lists them on Ren's Mac that day.
OFFERED = {"anthropic": ["claude-fable-5-2", "claude-fable-5-1", "claude-fable-5", "claude-opus-5-5", "claude-sonnet-5-5",
                         "claude-haiku-5-5"],
           "openai-codex": ["gpt-6.2-sol", "gpt-6.2-astra", "gpt-6.1-sol"]}


def _chatgpt_signed_in() -> bool:
    """The lab's own ChatGPT sign-in exists in its auth store (a local file read; no lookup, no network)."""
    try:
        from hermes_constants import get_hermes_home
        store = json.loads((Path(get_hermes_home()) / "auth.json").read_text(encoding="utf-8"))
    except Exception:
        return False
    pool = (store.get("credential_pool") or {}).get("openai-codex") or []
    tokens = ((store.get("providers") or {}).get("openai-codex") or {}).get("tokens") or {}
    return bool(pool) or bool(tokens.get("access_token") or tokens.get("refresh_token"))


def _engine_catalogue() -> dict:
    """{"providers": [...]} from the fixed list (Claude always; ChatGPT when signed in on this computer). Tests point
    QOSHA_BRAIN_CATALOG_FILE at a fixed catalogue instead."""
    fixture = os.environ.get("QOSHA_BRAIN_CATALOG_FILE", "").strip()
    # test runs only: never in the lab (qoshalab sets QOSHA_LAB=1 for every lab process)
    if fixture and os.environ.get("QOSHA_BRAIN_TEST") == "1" and os.environ.get("QOSHA_LAB") != "1":
        return json.loads(Path(fixture).read_text(encoding="utf-8"))
    cur = current()
    providers = []
    for pid in ("anthropic", "openai-codex"):
        models = list(OFFERED[pid])
        if cur["provider"] == pid and cur["model"] and cur["model"] not in models:
            models.insert(0, cur["model"])
        providers.append({"slug": pid, "authenticated": True if pid == "anthropic" else _chatgpt_signed_in(), "models": models})
    return {"providers": providers}


_LIVE_NAMES: dict = {}   # provider slug -> its name, from the engine's own picker (local installs)


def _local() -> bool:
    return not os.environ.get("QOSHA_BOX") and not os.environ.get("QOSHA_LAB")


def _live_catalogue() -> dict:
    """Local installs (Ren, 17 Nov: "everything our chatbox offers working"; OpenRouter on as in the engine): every
    provider the engine's own model picker lists as signed in, with the engine's full model list for each."""
    return _signed_in_lists(include_unconfigured=False)


def _engine_listed() -> dict:
    """The engine's own list with unconfigured providers included (as GET /api/model/options?include_unconfigured):
    still only the providers the engine itself says are signed in (P0, 23 Nov 2026)."""
    return _signed_in_lists(include_unconfigured=True)


def _signed_in_lists(include_unconfigured: bool) -> dict:
    from hermes_cli.inventory import build_model_options_payload, load_picker_context
    payload = build_model_options_payload(load_picker_context(), explicit_only=False,
                                          include_unconfigured=include_unconfigured, refresh=False)
    out = {}
    for p in payload.get("providers") or []:
        slug = str(p.get("slug") or "")
        models = [m if isinstance(m, str) else str((m or {}).get("id") or "") for m in (p.get("models") or [])]
        models = [m for m in models if m]
        if slug and p.get("authenticated") and models:
            out[slug] = models
            _LIVE_NAMES[slug] = str(p.get("name") or slug)
    return out


_BRANCH = [None]


def _blog(msg: str) -> None:
    try:
        import logging
        logging.getLogger("qosha.brain").warning("Qosha model list: %s", msg)
    except Exception:
        pass


def _branch(name: str, why: str = "") -> None:
    """Which list the picker shows, logged when it changes (P0 23 Nov: Renato's fell back and nothing said so)."""
    if _BRANCH[0] != name:
        _BRANCH[0] = name
        _blog("showing %s%s" % (name, (" (" + why + ")") if why else ""))


def _gemini():
    """The Gemini provider plugin the engine registered (gemini_provider/__init__.py), or None where there is none."""
    try:
        from providers import get_provider_profile
        prof = get_provider_profile(GEMINI)
        return sys.modules.get(type(prof).__module__) if prof is not None else None
    except Exception:
        return None


def _gemini_switched_off() -> bool:
    """The person (or Qosha for them) switched Gemini off in the engine's settings: providers.qosha-gemini.enabled
    false, or qosha-gemini in model_catalog.excluded_providers (review GB05: never added back)."""
    try:
        cfg = _load() or {}
        prov = (cfg.get("providers") or {}).get(GEMINI) if isinstance(cfg.get("providers"), dict) else None
        if isinstance(prov, dict) and prov.get("enabled") is False:
            return True
        mc = cfg.get("model_catalog") if isinstance(cfg.get("model_catalog"), dict) else {}
        ex = mc.get("excluded_providers") or []
        return isinstance(ex, list) and GEMINI in [str(x).strip().lower() for x in ex]
    except Exception:
        return False


def _gemini_models(g) -> list:
    """Google's list for Gemini: the provider's models_first (the saved list, or one shared agy read with a bounded
    wait when this computer never had one: 1.20.50.1 on Ren's Pro, 27 Nov 2026); models_known on an older provider."""
    first = getattr(g, "models_first", None)
    return list((first() if callable(first) else g.models_known()) or [])


def _gemini_pending(cat: dict) -> bool:
    """Gemini can answer but is not in this answer: its list is still being read, or it landed just after this read
    stopped waiting (round 2, MEDIUM). The page asks again shortly (review finding 1)."""
    g = _gemini()
    try:
        cached = getattr(g, "models_cached", lambda: [])
        later = bool(getattr(g, "models_pending", lambda: False)()) or any(g.allowed_model(m) for m in (cached() or []))
        return g is not None and GEMINI not in cat and later and g.ready() and not _gemini_switched_off()
    except Exception:
        return False


def _with_gemini(cat: dict) -> dict:
    """Local installs, applied to the list already chosen (live, the engine's own, or the fixed one; review GB04).
    Gemini is offered only while Qosha says it can answer as a full assistant (connected and its safety setup ready:
    the same check as the status read's), whatever the engine's row says (review GB02), and never when switched off
    (GB05). Its models are Google's last list on this computer, in Google's order (the engine's own refresh writes it),
    Gemini's own models only (GB03); the engine's row, filtered the same way, only when no such list exists here. This
    also covers the first read after a start, when the engine's row has no models yet. Only when this computer never
    had Google's list is agy asked for it (_gemini_models). Without the Gemini provider (a cloud box, an older install)
    the list is left as it is."""
    g = _gemini()
    if g is None:
        return cat
    row = cat.pop(GEMINI, None)
    try:
        if not g.ready() or _gemini_switched_off():
            return cat
        own = g.allowed_model
        ids = [m for m in _gemini_models(g) if own(m)] or [m for m in (row or []) if own(m)]
        if ids and (not g.ready() or _gemini_switched_off()):     # switched off or disconnected during the wait (finding 4)
            return cat
    except Exception:
        return cat
    if ids:
        cat[GEMINI] = ids
    return cat


def _sorted(cat: dict) -> dict:
    if "anthropic" in cat:
        cat["anthropic"] = sorted(cat["anthropic"], key=_claude_key)
    return cat


def name_of(pid: str) -> str:
    return NAMES.get(pid) or _LIVE_NAMES.get(pid) or ("Gemini" if pid == GEMINI else pid)


def catalogue() -> dict:
    """{provider: [model ids]}: on a local install, every provider signed in there (the engine's own list); on the
    lab and boxes, Claude and ChatGPT only, as before."""
    if _local():
        why = ""
        try:
            live = _live_catalogue()
            live = _with_gemini(_sorted(live)) if live else live   # a Gemini row Qosha won't offer leaves nothing: next list (GB2-01)
            if live:
                _branch("the engine's live list")
                return live
            why = "the engine's live list came back empty"
        except Exception as exc:          # never silent (P0 23 Nov 2026)
            why = "the engine's live list could not be read: %s: %s" % (type(exc).__name__, str(exc)[:160])
        try:
            listed = _engine_listed()
            listed = _with_gemini(_sorted(listed)) if listed else listed
            if listed:
                _branch("the engine's own list, unconfigured providers included", why)
                return listed
            why += "; the engine's own list is empty too"
        except Exception as exc:
            why += "; the engine's own list could not be read: %s: %s" % (type(exc).__name__, str(exc)[:160])
        _branch("the fixed list", why)
    else:
        _branch("the fixed list", "a cloud box or the lab: QOSHA_BOX or QOSHA_LAB is set")
    out = {}
    for p in (_engine_catalogue() or {}).get("providers") or []:
        slug = str((p or {}).get("slug") or "")
        if slug not in NAMES or not p.get("authenticated"):
            continue
        models = [m for m in (p.get("models") or []) if isinstance(m, str) and m]
        if slug == "anthropic":
            models = sorted(models, key=_claude_key)
        if models:
            out[slug] = models
    return _with_gemini(out) if _local() else out


def _load():
    from hermes_cli.config import load_config
    return load_config()


def current() -> dict:
    cfg = _load()
    mc = cfg.get("model")
    provider = str(mc.get("provider") or "") if isinstance(mc, dict) else ""
    model = str((mc.get("default") or mc.get("name") or "") if isinstance(mc, dict) else (mc or ""))
    agent = cfg.get("agent") if isinstance(cfg.get("agent"), dict) else {}
    effort = agent.get("reasoning_effort")
    effort = str(effort).strip().lower() if isinstance(effort, str) and effort.strip() else DEFAULT_EFFORT
    return {"provider": provider, "model": model, "effort": effort}


def _order(cat: dict) -> list:
    first = [p for p in ("anthropic", "openai-codex", GEMINI, "openrouter") if p in cat]
    return first + sorted(p for p in cat if p not in first)


def label(provider: str, model: str, effort: str) -> str:
    if (provider in _LIVE_NAMES or provider == GEMINI) and provider not in NAMES:   # Gemini named also on a first read (GB09)
        return "%s · %s · %s" % (name_of(provider), model_label(provider, model), EFFORT_NAMES.get(effort, effort.title()))
    if provider not in NAMES:
        return "Another model (%s)" % model if model else "Not chosen yet"
    return "%s · %s · %s" % (NAMES[provider], model_label(provider, model), EFFORT_NAMES.get(effort, effort.title()))


def _defaults(cur: dict, cat: dict) -> tuple:
    """(defaults, qosha_defaults) for Claude and ChatGPT: the person's own choice where they made one; Qosha's own
    pick otherwise. `cat` is the model list per provider; a provider missing from it gets the fixed fallback list."""
    defaults, qosha = {}, {}
    for pid in NAMES:
        models = cat.get(pid) or (sorted(OFFERED[pid], key=_claude_key) if pid == "anthropic" else list(OFFERED[pid]))
        qosha[pid] = qosha_default(pid, models)
        defaults[pid] = {"model": cur["model"], "effort": cur["effort"]} if cur["provider"] == pid and cur["model"] \
            else {"model": qosha[pid], "effort": None}
    return defaults, qosha


def summary() -> dict:
    """The setting in plain words, from config.yaml only (no model list, no lookups): for the home page's status read.
    Qosha's own defaults here come from the fixed fallback list; home() replaces them from the live list."""
    cur = current()
    defaults, _ = _defaults(cur, {})
    return dict(cur, label=label(cur["provider"], cur["model"], cur["effort"]), defaults=defaults)


# How each assistant is signed in on this lab, in the Provider picker's words (2 Nov: "Provider shows how it
# is signed in"). Claude and ChatGPT use subscription sign-ins, not paid API keys; ChatGPT was signed in to
# the Qosha AI workspace (10:30); Gemini answers through the connector's signed-in Gemini, text only (D17/D18).
SIGNIN = {"anthropic": "Claude subscription", "openai-codex": "ChatGPT · Qosha AI workspace",
          "gemini": "Gemini · Google sign-in on this computer", GEMINI: "Gemini · Google sign-in on this computer"}


def home() -> dict:
    """For the Home composer, inside the page's own status read (no extra request on load): the setting in plain words
    plus the choices its pickers offer. The choices are the fixed local list (no lookups, no network)."""
    d = summary()
    d["qosha_defaults"] = _defaults(d, {})[1]   # from the fallback list until the live list is read (review F09)
    try:
        cat = catalogue()
        d["providers"] = [{"id": pid, "name": name_of(pid), "signin": SIGNIN.get(pid, name_of(pid)),
                           "models": [{"id": m, "label": model_label(pid, m), "efforts": efforts_for(pid, m)} for m in cat[pid]]}
                          for pid in _order(cat)]
        d["defaults"], d["qosha_defaults"] = _defaults(d, cat)   # the newest from the live list (Ren, 26 Nov 2026)
    except Exception:
        d["providers"] = None   # the pickers show the setting only; nothing is offered that can't be checked
    d["signin"] = dict(SIGNIN)
    if os.environ.get("QOSHA_BOX") == "1":   # the cloud box: Gemini is Qosha's own (Vertex AI, council D38)
        d["signin"]["gemini"] = "Gemini · provided by Qosha"
    return d


def state() -> dict:
    cur = current()
    cat = catalogue()
    providers = [{"id": pid, "name": name_of(pid),
                  "models": [{"id": m, "label": model_label(pid, m), "efforts": efforts_for(pid, m)} for m in cat[pid]]}
                 for pid in _order(cat)]
    defaults, qosha = {}, {}
    for pid, models in cat.items():
        qosha[pid] = qosha_default(pid, models)
        if cur["provider"] == pid and cur["model"] in models:
            defaults[pid] = {"model": cur["model"], "effort": cur["effort"]}
        else:
            defaults[pid] = {"model": qosha[pid], "effort": None}
    return dict(cur, label=label(cur["provider"], cur["model"], cur["effort"]), providers=providers,
                defaults=defaults, qosha_defaults=qosha, note="" if _local() else NOTE,   # Gemini can be the brain locally
                pending=[GEMINI] if _local() and _gemini_pending(cat) else [])


@router.get("")
@router.get("/")
def get_brain():
    try:
        return state()
    except Exception:
        return JSONResponse({"error": "brain_unavailable", "message": "The assistant's settings could not be read."}, status_code=503)


def _canon(d) -> str:
    return json.dumps(d, sort_keys=True, default=str)


def _put_back(path: Path, before, mode) -> None:
    """The file exactly as it was: its bytes and mode, or no file at all."""
    if before is None:
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        return
    tmp = path.with_name("." + path.name + ".qosha-restore-%d" % os.getpid())
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode or 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(before)
        os.fchmod(f.fileno(), mode or 0o600)
    os.replace(tmp, path)


def _read(path: Path):
    try:
        return path.read_bytes()
    except FileNotFoundError:
        return None


@router.post("")
@router.post("/")
def set_brain(body: dict = Body(...)):
    body = body if isinstance(body, dict) else {}
    provider = str(body.get("provider") or "")
    model = str(body.get("model") or "")
    effort = str(body.get("effort") or "").lower()
    if provider not in NAMES and not _local():
        return JSONResponse({"error": "provider_not_allowed",
                             "message": "Only Claude or ChatGPT can be the main assistant. " + NOTE}, status_code=400)
    try:
        cat = catalogue()
    except Exception:
        return JSONResponse({"error": "catalogue_unavailable", "message": "The list of models could not be read."}, status_code=503)
    if provider not in cat:
        return JSONResponse({"error": "not_signed_in", "message": name_of(provider) + " is not signed in on this computer."}, status_code=409)
    if model not in cat[provider]:
        return JSONResponse({"error": "model_not_offered", "message": "That model isn’t offered for this account."}, status_code=400)
    if effort not in [e["id"] for e in efforts_for(provider, model)]:
        return JSONResponse({"error": "effort_not_offered", "message": "That effort level isn’t offered for this model."}, status_code=400)
    if _local() and not hasattr(__import__("hermes_cli.web_server", fromlist=["x"]), "_apply_main_model_assignment"):
        # engine v0.22+: its own main-model save (POST /api/model/set's code), then the effort through its config writer
        try:
            import asyncio
            from hermes_cli.web_models import ModelAssignment
            from hermes_cli.web_routers.models import set_model_assignment
            r = asyncio.run(set_model_assignment(ModelAssignment(scope="main", provider=provider, model=model,
                                                                 reasoning_effort=effort, confirm_expensive_model=True)))
            if isinstance(r, dict) and r.get("ok") is False:
                return JSONResponse({"error": "not_saved", "message": "Not saved: " + str(r.get("confirm_message") or r.get("error") or "")[:200]}, status_code=409)
            got = current()
            if (got["provider"], got["model"]) != (provider, model):
                return JSONResponse({"error": "not_saved", "message": "Not saved: the engine kept another model."}, status_code=500)
            if got["effort"] != effort:
                # engine v0.23's main assignment keeps the old effort (it takes one only for helper models): write it
                from hermes_cli.config import get_config_path
                from hermes_cli.config_backend import write_config_key
                write_config_key(get_config_path(), "agent.reasoning_effort", effort)
                if current()["effort"] != effort:
                    return JSONResponse({"error": "not_saved", "message": "Not saved: the effort level stayed the same."}, status_code=500)
            return state()
        except Exception as exc:
            return JSONResponse({"error": "not_saved", "message": "Not saved (%s)." % type(exc).__name__}, status_code=500)
    try:
        from hermes_cli.config import get_config_path, read_user_config_raw
        from utils import atomic_roundtrip_yaml_save
        import hermes_cli.web_server as ws   # the engine's own main-model assignment helpers (its Models page path)
    except Exception:
        return JSONResponse({"error": "not_saved", "message": "Not saved: the assistant's settings can’t be changed right now."}, status_code=503)
    with _LOCK:
        path = Path(get_config_path())
        before = _read(path)
        mode = stat.S_IMODE(os.stat(path).st_mode) if before is not None else None
        try:
            raw = read_user_config_raw(path) if before is not None else {}
            expected = copy.deepcopy(raw)
            provider_n, model_n = ws._normalize_main_model_assignment(provider, model)
            if (provider_n, model_n) != (provider, model):
                return JSONResponse({"error": "model_not_offered", "message": "That model isn’t offered for this account."}, status_code=400)
            expected["model"] = ws._apply_main_model_assignment(copy.deepcopy(raw.get("model") or {}), provider_n, model_n)
            agent = copy.deepcopy(raw.get("agent")) if isinstance(raw.get("agent"), dict) else {}
            agent["reasoning_effort"] = effort
            expected["agent"] = agent
        except Exception:
            return JSONResponse({"error": "not_saved", "message": "Not saved: the assistant's settings can’t be changed right now."}, status_code=500)
        # the new file is prepared beside the real one first, so its exact bytes are known before it is published
        tmp = path.with_name("." + path.name + ".qosha-new-%d" % os.getpid())
        try:
            if os.path.lexists(tmp):
                os.unlink(tmp)
            if before is not None:
                fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode or 0o600)
                with os.fdopen(fd, "wb") as f:
                    f.write(before)
            atomic_roundtrip_yaml_save(tmp, expected)
            if before is not None:
                os.chmod(tmp, mode)
            candidate = tmp.read_bytes()
            if _canon(read_user_config_raw(tmp)) != _canon(expected):
                raise ValueError("the prepared file holds more than the change")
        except Exception:
            _drop(tmp)
            return JSONResponse({"error": "not_saved", "message": "Not saved: the new settings could not be prepared. Nothing was changed."}, status_code=500)
        published = False
        try:
            if _read(path) != before:
                return JSONResponse({"error": "conflict", "message": "Not saved: the settings changed meanwhile. Try again."}, status_code=409)
            os.replace(tmp, path)
            published = True
        except Exception:
            return JSONResponse({"error": "not_saved", "message": "Not saved: the settings file could not be replaced. Nothing was changed."}, status_code=500)
        finally:
            if not published:
                _drop(tmp)
        try:
            if _read(path) != candidate:
                raise ValueError("someone else wrote the file after us")
            if _canon(read_user_config_raw(path)) != _canon(expected):
                raise ValueError("the file holds more than the change")
            got = current()
            if (got["provider"], got["model"], got["effort"]) != (provider, model, effort):
                raise ValueError("read back something else")
            # which file this save replaced and which it wrote (sha256), so a caller can later tell its own write apart
            return dict(state(), revision={"before": hashlib.sha256(before).hexdigest() if before is not None else None,
                                           "after": hashlib.sha256(candidate).hexdigest()})
        except Exception:
            return _undo(path, before, mode, candidate)


def _drop(tmp: Path) -> None:
    try:
        os.unlink(tmp)
    except OSError:
        pass


def _undo(path: Path, before, mode, candidate: bytes):
    """Put the previous file back, but only if what is there now is exactly the file this save published: a write by
    someone else after ours is never overwritten (then the person is told). If that can't be checked, or the restore
    fails, the file is left as it is and the answer says so. The result is checked."""
    try:
        now = _read(path)
    except Exception:
        return JSONResponse({"error": "not_restored", "message": "Not saved, and the settings file could not be checked or put back. Open Settings → Config to check the main model."}, status_code=500)
    if now != candidate:
        return JSONResponse({"error": "conflict", "message": "Not saved: the settings were changed by something else at the same time; nothing was put back over that change. Check the main assistant and try again."}, status_code=409)
    try:
        _put_back(path, before, mode)
        if _read(path) != before:
            raise OSError("restore check failed")
    except Exception:
        return JSONResponse({"error": "not_restored", "message": "Not saved, and the settings file could not be put back as it was. Open Settings → Config to check the main model."}, status_code=500)
    return JSONResponse({"error": "not_saved", "message": "Not saved: the settings file would have changed in other places, so it was put back as it was."}, status_code=500)
