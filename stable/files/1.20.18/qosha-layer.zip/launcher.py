"""Starts Qosha for this person (Windows: at sign-in from the per-user Run key; Mac: from a LaunchAgent).
    <engine python> -I launcher.py --root <Qosha folder> [--port 9219] [--open] [--once]
Keeps Qosha's dashboard running on 127.0.0.1:<port> (restarts it if it stops), logs in <root>/logs. If Qosha already
answers on the port, it does nothing (one copy per person). --open: also opens the Qosha app (or the browser).
--once: start it and return (no watching), for scripts."""
import argparse
import contextlib
import io
import os
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

WIN = os.name == 'nt'


def up(port):
    try:
        with urllib.request.urlopen('http://127.0.0.1:%d/api/status' % port, timeout=3) as r:
            return r.status == 200
    except Exception:
        return False


def port_busy(port):
    s = socket.socket()
    try:
        s.settimeout(1)
        return s.connect_ex(('127.0.0.1', port)) == 0
    finally:
        s.close()


def env_for(root, port):
    home = root / 'home'
    e = {k: v for k, v in os.environ.items() if not k.upper().startswith(('PYTHON', 'HERMES_', 'PIP_'))}
    e.update({'HERMES_HOME': str(home), 'HERMES_KANBAN_HOME': str(home), 'HERMES_DESKTOP': '0',
              'HERMES_DASHBOARD_FILES_ROOT': str(home / 'files'), 'QOSHA_ASK_ACCESS': '1', 'QOSHA_LOCAL': '1',
              'PYTHONUTF8': '1', 'PYTHONIOENCODING': 'utf-8'})
    return e


def log(root, msg):
    """One line in <root>/logs/launcher.log; the file is capped (1 MB, then kept as launcher.log.1). Never raises."""
    try:
        (root / 'logs').mkdir(exist_ok=True)
        f = root / 'logs' / 'launcher.log'
        if f.is_file() and f.stat().st_size > 1_000_000:
            os.replace(f, f.with_name('launcher.log.1'))
        with open(f, 'a', encoding='utf-8', errors='replace') as h:
            h.write('%s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), msg))
    except Exception:
        pass


_SETUP = {}                    # the layer's setup_home, loaded by path; reloaded when the file changes (Gemini sh16 F5)
_BACKOFF = {'next': 0.0, 'step': 0}
_DELAYS = (300, 900, 3600)     # after a failed heal: try again in 5 min, 15 min, then hourly (F6)


def _setup_home(root):
    """The layer's setup_home, compiled from its current source bytes (no cached bytecode; GPT sh16 F5), again only
    when those bytes change."""
    import hashlib
    import types
    p = root / 'layer' / 'setup_home.py'
    data = p.read_bytes()
    key = (str(p), hashlib.sha256(data).hexdigest())
    if _SETUP.get('key') != key:
        m = types.ModuleType('qosha_setup_home_heal')
        m.__file__ = str(p)
        exec(compile(data, str(p), 'exec'), m.__dict__)
        _SETUP.update(key=key, mod=m)
    return _SETUP['mod']


def _pid_alive(pid):
    if pid <= 0:
        return False
    if WIN:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x1000, False, pid)          # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        try:
            code = ctypes.c_ulong()
            return bool(k.GetExitCodeProcess(h, ctypes.byref(code))) and code.value == 259   # STILL_ACTIVE
        finally:
            k.CloseHandle(h)
    try:
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True
    except OSError:
        return False


def _update_running(root):
    """An update holds run/update.lock (its own setup brands the screens): only while the process that wrote it is
    alive (a killed updater's marker never stops a heal; GPT sh16 F4) and for at most a day."""
    lk = root / 'run' / 'update.lock'
    try:
        if time.time() - lk.stat().st_mtime > 86400:
            return False
        return _pid_alive(int(lk.read_text(encoding='utf-8', errors='replace').strip() or 0))
    except (OSError, ValueError):
        return False


def _try_lock(path):
    """A lock no one waits for: None if another heal holds it (Gemini sh16 F4)."""
    fd = os.open(str(path), os.O_RDWR | os.O_CREAT, 0o600)
    try:
        if WIN:
            import msvcrt
            os.lseek(fd, 0, 0)
            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return fd
    except OSError:
        os.close(fd)
        return None


def _unlock(fd):
    try:
        if WIN:
            import msvcrt
            os.lseek(fd, 0, 0)
            msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
    except OSError:
        pass
    os.close(fd)


def heal(root, when):
    """Qosha's screens from the first frame (P0, 22 Nov 2026): if the engine's built screens are no longer Qosha's
    (rebuilt or replaced after setup), brand them again with the installer's own steps and log it. Never stops Qosha
    from starting. Skipped while an update runs (its own setup brands them) or another heal holds the lock; after a
    failure the minute check backs off. Returns None (nothing to do), True (healed) or False (could not)."""
    out = io.StringIO()
    fd = None
    try:
        if _update_running(root):
            return None
        if when == 'while running' and time.time() < _BACKOFF['next']:
            return None
        sh = _setup_home(root)
        src = root / 'engine'
        if sh.screens_branded(src, root / 'home'):
            _BACKOFF.update(next=0.0, step=0)
            return None
        (root / 'run').mkdir(exist_ok=True)
        fd = _try_lock(root / 'run' / 'heal.lock')
        if fd is None:
            return None
        with contextlib.redirect_stdout(out):
            ok = sh.heal_screens(src, root / 'home')
        if ok is None:                 # another heal finished first
            return None
        log(root, "screens were not Qosha's (%s): branded again: %s | %s" % (
            when, 'OK' if ok else 'FAILED', ' / '.join(l for l in out.getvalue().splitlines() if l)[-300:]))
        if ok:
            _BACKOFF.update(next=0.0, step=0)
            return True
    except (Exception, SystemExit) as e:
        log(root, "screens were not Qosha's (%s): could not brand them again (%s: %s) | %s" % (
            when, type(e).__name__, str(e)[:200], ' / '.join(l for l in out.getvalue().splitlines() if l)[-300:]))
    finally:
        if fd is not None:
            _unlock(fd)
    if when == 'while running':          # only the minute check backs off; start-time tries don't move it (GPT F6)
        _BACKOFF['next'] = time.time() + _DELAYS[min(_BACKOFF['step'], len(_DELAYS) - 1)]
        _BACKOFF['step'] += 1
    return False


def wait_up(port, p, tries=240):
    for _ in range(tries):
        if up(port):
            return True
        if p.poll() is not None:
            return False
        time.sleep(0.5)
    return False


def start(root, port, py):
    logs = root / 'logs'
    logs.mkdir(exist_ok=True)
    out = open(logs / 'dashboard.log', 'ab')
    out.write(('\n=== start %s ===\n' % time.strftime('%Y-%m-%d %H:%M:%S')).encode())
    out.flush()
    kw = {'creationflags': 0x08000000} if WIN else {'start_new_session': True}
    here = str(Path(__file__).resolve().parent)
    if here not in sys.path:
        sys.path.insert(0, here)
    import engine_exec          # the engine's own start command, run with its Python directly
    p = subprocess.Popen(engine_exec.command(root, ['dashboard', '--host', '127.0.0.1', '--port', str(port),
                                                    '--skip-build', '--isolated', '--no-open']),
                         cwd=str(root / 'home'), env=env_for(root, port), stdout=out, stderr=subprocess.STDOUT,
                         stdin=subprocess.DEVNULL, **kw)
    (root / 'run').mkdir(exist_ok=True)
    (root / 'run' / 'dashboard.pid').write_text(str(p.pid))
    return p


def open_app(port, root, apps=None):
    url = 'http://127.0.0.1:%d/' % port
    # the app's own profile folder inside Qosha's: its window settings stay with this install, and it never meets
    # another copy of the app (Qosha Setup) that may be open
    args = ['--qosha-home=' + url, '--qosha-profile=' + str(root / 'app-profile')]
    if WIN:
        app = Path(os.environ.get('LOCALAPPDATA', '')) / 'Programs' / 'Qosha' / 'Qosha.exe'
        if app.is_file():
            subprocess.Popen([str(app)] + args, creationflags=0x00000008)   # DETACHED_PROCESS
        else:
            os.startfile(url)
    else:
        app = next((p for p in ([Path(apps) / 'Qosha.app'] if apps else [Path.home() / 'Applications' / 'Qosha.app', Path('/Applications/Qosha.app')])
                    if p.exists()), None)
        subprocess.Popen(['open', '-n', str(app), '--args'] + args if app else ['open', url])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--port', type=int, default=9219)
    ap.add_argument('--open', action='store_true')
    ap.add_argument('--once', action='store_true')
    ap.add_argument('--apps', help='Mac: the folder holding Qosha.app (default ~/Applications, then /Applications)')
    a = ap.parse_args()
    root = Path(a.root).resolve()
    py = Path(sys.executable)
    if WIN and py.name.lower() == 'pythonw.exe':
        py = py.with_name('python.exe')
    if up(a.port) or port_busy(a.port):
        heal(root, 'already running')
        if a.open:
            open_app(a.port, root, a.apps)
        return 0
    heal(root, 'before start')
    p = start(root, a.port, py)
    t0 = time.time()                     # the child's life is counted from its start (GPT sh16 N4)
    if not a.once:                       # the updater finds this launcher from the start (Gemini sh16 F7)
        (root / 'run' / 'launcher.pid').write_text(str(os.getpid()))
    if wait_up(a.port, p):
        heal(root, 'after start')        # a recovery build during the engine's start would show up here
    if a.open:
        open_app(a.port, root, a.apps)
    if a.once:
        return 0 if up(a.port) else 1
    quick = 0
    while True:
        while True:
            try:
                p.wait(timeout=60)
                break
            except subprocess.TimeoutExpired:
                heal(root, 'while running')   # anything that rebuilds the screens while Qosha runs
        quick = quick + 1 if time.time() - t0 < 60 else 0
        if quick >= 5:
            return 1                       # stops crashing in a loop; the log says why
        time.sleep(10)
        if up(a.port) or port_busy(a.port):
            return 0
        heal(root, 'before restart')
        p = start(root, a.port, py)
        t0 = time.time()
        if wait_up(a.port, p):
            heal(root, 'after start')


if __name__ == '__main__':
    raise SystemExit(main())
