"""Qosha's name on the pages the engine renders itself, outside the built screens (P0, 22 Nov 2026; council sv17,
GPT SV04 / Gemini D7): the sign-in pages at /login ("Sign in — Hermes Agent", the maker's wordmark, a link to the
engine's docs) and the page shown when the screens can't be read ("Hermes is unavailable").
Installed beside the engine (a .pth in its environment imports it at every start, before the dashboard imports these
modules) and from the plugin as a fallback. Only active in a Qosha home (HERMES_HOME/plugins/qosha exists).
What a person types and the forms' behavior (fields, actions, redirects, status codes, headers) are never changed:
only the words on the page. Only the engine's own template text is rewritten, never a page after request values were
put into it (a path prefix, a next= path or an OAuth state may contain any word; GPT ep18-01); two fixed engine
sentences that are built at render time are swapped by their exact text.
Active only while the running layer ships this module (<root>/layer/qosha_pages.py): a rollback to a release
without it turns it off (GPT ep18-08)."""
import importlib.abc
import os
import re
import sys

LOGIN = "hermes_cli.dashboard_auth.login_page"
SERVE = "hermes_cli.web_server_dashboard"

_SWAPS = [
    (re.compile(r'Nous<span class="dot"></span>Research'), 'Qosha<span class="dot"></span>AI'),
    (re.compile(r'(?is)<a\b[^>]*\bhref=["\']https?://[^"\']*nousresearch\.com[^"\']*["\'][^>]*>(.*?)</a>'), r'\1'),   # the engine's docs link
    (re.compile(r'\bHermes Agent\b'), 'Qosha'),
    (re.compile(r'\bNous Research\b'), 'Qosha AI'),
    (re.compile(r'e\.g\. Hermes Desktop'), 'e.g. a desktop app'),
    (re.compile(r'\bHermes\b'), 'Qosha'),
]


def _qosha_home() -> bool:
    home = os.environ.get("HERMES_HOME") or ""
    if not home:
        return False
    home = os.path.abspath(os.path.expanduser(home))      # Gemini ep18 r2-03
    parent = os.path.dirname(home)
    if os.path.basename(parent) == "profiles":            # <root>/home/profiles/<name>
        home = os.path.dirname(parent)
    if not os.path.isdir(os.path.join(home, "plugins", "qosha")):
        return False
    return os.path.isfile(os.path.join(os.path.dirname(home), "layer", "qosha_pages.py"))


def words(html_text):
    """The page's words say Qosha; markup, URLs other than the engine's docs, and identifiers are left alone
    (`__HERMES_*`, `/hermes` path prefixes and `hermes-…` font or class names are not matched: case and word
    boundaries)."""
    if not isinstance(html_text, str):
        return html_text
    for rx, repl in _SWAPS:
        html_text = rx.sub(repl, html_text)
    return html_text


# fixed engine sentences built at render time (not in the templates): exact text only
_RENDERED = [("e.g. Hermes Desktop&rsquo;s", "e.g. a desktop app&rsquo;s"),
             # the maker's own sign-in provider: the button says what it really is, an outside account (GPT ep18-02)
             (">Sign in with Nous Research</a>", ">Sign in with your external account</a>")]


def rendered(html_text):
    if not isinstance(html_text, str):
        return html_text
    for old, new in _RENDERED:
        html_text = html_text.replace(old, new)
    return html_text


def _wrap(fn):
    if getattr(fn, "__qosha_pages__", False):
        return fn

    def wrapped(*a, **kw):
        return rendered(fn(*a, **kw))
    wrapped.__qosha_pages__ = True
    wrapped.__wrapped__ = fn
    wrapped.__name__ = getattr(fn, "__name__", "wrapped")
    return wrapped


def patch_login(mod) -> None:
    if not _qosha_home():
        return
    try:
        for name in ("_LOGIN_HTML_TEMPLATE", "_EMPTY_HTML", "_TOKEN_MODE_HTML"):
            if isinstance(getattr(mod, name, None), str):
                setattr(mod, name, words(getattr(mod, name)))
        for name in ("render_login_html", "render_native_provider_choice_html", "_render_password_form"):
            if callable(getattr(mod, name, None)):
                setattr(mod, name, _wrap(getattr(mod, name)))
        # a module that already took the function by name (routes.py imports it at its own import)
        r = sys.modules.get("hermes_cli.dashboard_auth.routes")
        if r is not None:
            for name in ("render_login_html", "render_native_provider_choice_html"):
                if callable(getattr(r, name, None)):
                    setattr(r, name, _wrap(getattr(r, name)))
    except Exception:
        pass


_UNAVAILABLE_HTML = (
    '<!doctype html><html lang="en"><head><meta charset="utf-8">'
    '<meta name="viewport" content="width=device-width, initial-scale=1">'
    "<title>Qosha</title><style>"
    "body{font-family:system-ui,sans-serif;max-width:36rem;margin:15vh auto;padding:0 1rem;"
    "line-height:1.5;color:#0B3326;background:#fff}"
    "@media (prefers-color-scheme:dark){body{color:#EAF2EC;background:#041810}}"
    "</style></head><body><h1>Qosha can't show this page right now</h1>"
    "<p>Close Qosha and open it again. If this page keeps coming back, Qosha's set-up needs a repair: "
    "ask Qosha to fix itself, or contact your Qosha helper.</p>"
    "</body></html>")


def patch_serve(mod) -> None:
    if not _qosha_home():
        return
    try:
        orig = getattr(mod, "_bundle_unavailable", None)
        if orig is None or getattr(orig, "__qosha_pages__", False):
            return
        no_store = getattr(mod, "_NO_STORE", {"Cache-Control": "no-store, no-cache, must-revalidate"})

        def _bundle_unavailable(request, message, status_code):
            """Same status codes, no-store and content negotiation as the engine's; Qosha's words, never the engine's
            message (it names engine commands)."""
            json_response = getattr(mod, "JSONResponse", None)
            html_response = getattr(mod, "HTMLResponse", None)
            if json_response is None or html_response is None:
                from starlette.responses import HTMLResponse as html_response, JSONResponse as json_response
            if "text/html" not in request.headers.get("accept", ""):
                return json_response({"error": "Qosha's screens are not available"}, status_code=status_code,
                                     headers=no_store)
            from hermes_cli.webapp_page_policy import page_headers     # as the engine's: an error here is the engine's
            return html_response(_UNAVAILABLE_HTML, status_code=status_code,
                                 headers=page_headers(request, _UNAVAILABLE_HTML, no_store))
        _bundle_unavailable.__qosha_pages__ = True
        _bundle_unavailable.__wrapped__ = orig
        mod._bundle_unavailable = _bundle_unavailable
    except Exception:
        pass


PATCHES = {LOGIN: patch_login, SERVE: patch_serve}


class _Loader(importlib.abc.Loader):
    def __init__(self, inner):
        self.inner = inner

    def create_module(self, spec):
        cm = getattr(self.inner, "create_module", None)
        return cm(spec) if cm else None

    def __getattr__(self, name):          # get_source, get_code, path, ... (inspect, linecache; Gemini ep18 F6)
        return getattr(self.inner, name)

    def exec_module(self, module):
        self.inner.exec_module(module)
        PATCHES[module.__name__](module)


class _Finder(importlib.abc.MetaPathFinder):
    _qosha_pages_finder = 2

    def find_spec(self, name, path=None, target=None):
        if name not in PATCHES:
            return None
        for f in sys.meta_path:
            if f is self or getattr(f, "_qosha_pages_finder", False) or not hasattr(f, "find_spec"):
                continue
            spec = f.find_spec(name, path, target)
            if spec is not None:
                if spec.loader is not None:
                    spec.loader = _Loader(spec.loader)
                return spec
        return None


for _name, _fn in PATCHES.items():
    if _name in sys.modules:
        _fn(sys.modules[_name])
for _f in [f for f in sys.meta_path if 0 < getattr(f, "_qosha_pages_finder", 0) < _Finder._qosha_pages_finder]:
    sys.meta_path.remove(_f)           # an older copy (the environment's from before an update) gives way
if not any(getattr(f, "_qosha_pages_finder", 0) == _Finder._qosha_pages_finder for f in sys.meta_path):
    sys.meta_path.insert(0, _Finder())
