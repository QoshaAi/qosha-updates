"""Closed until proven open: on a local install, Qosha's approvals stay refused until its approval gate is confirmed
installed on the dashboard's own app (1.20.8 open item 1; orchestrator, 22 Nov 2026: "if the gate fails to install,
Qosha must refuse approvals and say so, not only log it"; review round 1: GPT FO-1..16, Gemini FO-1..9).

engage() runs in the dashboard process before the gate is mounted; only plugin_api's check that the gate really sits
on the app calls release(). While engaged:
- the engine refuses every step that needs approval at its one decision point (_run_approval_gate), with MESSAGE, so
  no card is raised and nothing can be granted by any route, transport, unattended policy or worker in this process;
  the bypass readers (yolo, session yolo, mode "off") read as off; answering a card takes only the canonical "deny";
- a front-door middleware treats every caller as untrusted: reads, chat, declining and the updater pass; every other
  write is refused (503, code approval_check_down) and the chat socket passes only chat's own methods;
- Qosha's decisions can't be approved, and no connector approve address is handed out;
- the window route (added by plugin_api when the gate is down) says so, and the pages show MESSAGE.
In the gateway process, if the gate's code can't load, the two ticket kinds that can answer cards are refused.
Self-contained on purpose (nothing imported from approval_gate): it has to work when that file can't.
"""
from __future__ import annotations

import json
import logging
import os
import re
import sys
from pathlib import Path

log = logging.getLogger("qosha.approval_gate")
MESSAGE = ("Qosha's approval check didn't start, so nothing can be approved right now (declining still works). "
           "Restart Qosha; if this keeps happening, ask Qosha in chat to check it.")
CODE = "approval_check_down"
# one state per process, shared by every copy of this module (a re-import after a failed mount uses the same one:
# review FO2-12). failed: the reason while engaged; patched: engine hook -> in place; gateway_down: the gateway side.
import types as _types
_STATE = sys.modules.setdefault("qosha_gate_failsafe_state",
                                _types.SimpleNamespace(failed=None, patched={}, gateway_down=None))
PATCHED = _STATE.patched


def local_install() -> bool:
    """The Qosha app is installed on this computer (decided from the disk, never from the environment)."""
    if os.name == "nt":
        la = os.environ.get("LOCALAPPDATA", "")
        roots = [os.path.join(la, "Programs", "Qosha")] if la else []
    else:
        roots = [str(Path.home() / "Applications" / "Qosha.app"), "/Applications/Qosha.app"]
    return any(os.path.isdir(r) for r in roots)


def in_dashboard() -> bool:
    return "dashboard" in [str(a).lower() for a in sys.argv]


# ---- the engine ------------------------------------------------------------------------------------------------
def _deny_only(fn):
    if getattr(fn, "qosha_failsafe", False):
        return fn

    def guarded(session_key, choice, *a, **kw):
        if _STATE.failed and choice != "deny":            # only the canonical "deny" settles anything while down (FO-12)
            raise PermissionError(MESSAGE)
        return fn(session_key, choice, *a, **kw)
    guarded.qosha_failsafe = True
    guarded.__wrapped__ = fn
    return guarded


def _swap(ap, name, new_for):
    orig = getattr(ap, name, None)
    if orig is None or getattr(orig, "qosha_failsafe", False):
        return orig is not None
    new = new_for(orig)
    setattr(ap, name, new)
    for mod in list(sys.modules.values()):              # copies imported by name before this ran
        try:
            if mod is not ap and getattr(mod, name, None) is orig:
                setattr(mod, name, new)
        except Exception:
            pass
    return True


def _patch_engine() -> None:
    try:
        from tools import approval as ap
    except Exception as exc:
        log.error("Qosha approval check: the engine's approval code didn't load (%s); chat turns are refused too",
                  type(exc).__name__)
        return
    try:
        from tools import approval_context as ac
    except Exception:
        ac = None

    def gate_for(orig):
        def _run_approval_gate(*a, **kw):
            if _STATE.failed:                                   # nothing is asked, nothing is granted, Qosha says why
                return {"approved": False, "message": MESSAGE, "pattern_key": kw.get("pattern_key", ""),
                        "description": kw.get("description", ""), "outcome": "blocked", "user_consent": False,
                        "user_summary": MESSAGE}
            return orig(*a, **kw)
        _run_approval_gate.qosha_failsafe = True
        _run_approval_gate.__wrapped__ = orig
        return _run_approval_gate

    def off_while_down(orig):
        def reader(*a, **kw):
            return False if _STATE.failed else orig(*a, **kw)
        reader.qosha_failsafe = True
        reader.__wrapped__ = orig
        return reader

    def manual_while_down(orig):
        def mode(*a, **kw):
            m = orig(*a, **kw)
            return "manual" if _STATE.failed and m != "manual" else m
        mode.qosha_failsafe = True
        mode.__wrapped__ = orig
        return mode

    PATCHED["gate"] = _swap(ap, "_run_approval_gate", gate_for)
    for name in ("resolve_gateway_approval", "resolve_gateway_approval_card"):
        PATCHED[name] = _swap(ap, name, _deny_only)
    for name in ("_yolo_active", "is_approval_bypass_active", "is_approval_bypass_active_for_session"):
        PATCHED[name] = _swap(ap, name, off_while_down)
    PATCHED["mode"] = _swap(ac, "_get_approval_mode", manual_while_down) if ac is not None else False

    def blocked_for(orig):         # the terminal / script guards' own human step and unattended policy: refused
        def refuse(*a, **kw):
            if _STATE.failed:
                return {"approved": False, "message": MESSAGE, "outcome": "blocked", "user_consent": False,
                        "user_summary": MESSAGE, "pattern_key": kw.get("pattern_key", ""),
                        "description": kw.get("description", "")}
            return orig(*a, **kw)
        refuse.qosha_failsafe = True
        refuse.__wrapped__ = orig
        return refuse
    PATCHED["human"] = _swap(ap, "_human_decision", blocked_for)
    PATCHED["unattended"] = _swap(ap, "_unattended_deny", blocked_for)

    def wait_for(orig):            # the shared wait other features use without the central gate (write guards, the
        def _await_gateway_decision(*a, **kw):   # local editor, prompts): declined at once, with Qosha's sentence
            if _STATE.failed:
                return {"resolved": True, "choice": "deny", "reason": MESSAGE}
            return orig(*a, **kw)
        _await_gateway_decision.qosha_failsafe = True
        _await_gateway_decision.__wrapped__ = orig
        return _await_gateway_decision
    try:
        from tools import approval_gateway_wait as gw
        PATCHED["wait"] = _swap(gw, "_await_gateway_decision", wait_for)
    except Exception:
        PATCHED["wait"] = False


# ---- the front door (the dashboard app) -------------------------------------------------------------------------
_READ = ("GET", "HEAD", "OPTIONS")
_OPEN_WRITES = [re.compile(r"^/api/plugins/qosha/decisions/[^/]+/decline/?$"),
                re.compile(r"^/api/plugins/qosha/updates/(check|apply|activity)/?$")]   # declining; repairing by update
_OPEN_SOCKETS = re.compile(r"^/api/(events|audio/(transcribe|speak)-stream|plugins/[^/]+/events)/?$")
_CHAT = frozenset({"ping", "client.capabilities", "session.create", "session.resume", "session.close",
                   "session.interrupt", "session.set_hidden", "prompt.submit", "file.attach", "image.attach",
                   "image.attach_bytes", "pdf.attach", "image.detach", "clarify.respond", "sudo.respond",
                   "secret.respond", "config.set", "approval.respond"})
_PROMPT_FIELDS = frozenset({"session_id", "text", "queued", "interrupted", "display_kind", "title_preview",
                            "voice_turn", "voice_context"})
_CREATE_FIELDS = frozenset({"source", "close_on_disconnect", "title", "provider", "model", "reasoning_effort", "cwd",
                            "cols", "rows"})


def _frame_ok(f) -> bool:
    if not isinstance(f, dict):
        return False
    if "method" not in f:                                  # an answer the engine asked for: never a grant (FO2-6)
        if "result" not in f:
            return isinstance(f.get("error"), dict)            # declining a question (sudo / secret) is fine
        res = f.get("result")
        if not isinstance(res, dict) or not res:              # an empty answer would settle a card as declined (FO2-18)
            return False
        if "choice" in res and res.get("choice") != "deny":
            return False
        return not any(k in res for k in ("approved", "allow", "allowed", "decision", "accept", "accepted",
                                          "confirmed", "grant", "granted", "consent"))
    m, p = str(f.get("method") or ""), f.get("params") if isinstance(f.get("params"), dict) else {}
    if m not in _CHAT:
        return False
    if m == "session.create" and not set(p) <= _CREATE_FIELDS:
        return False
    if m == "config.set" and str(p.get("key") or "") not in ("reasoning", "model"):
        return False
    if m == "approval.respond" and p.get("choice") != "deny":
        return False
    if m == "prompt.submit" and not set(p) <= _PROMPT_FIELDS:   # no transcript rewind or other consent fields (FO2-14)
        return False
    if m == "prompt.submit" and not PATCHED.get("gate"):   # without the engine refusal, no turn may run (FO2-4)
        _patch_engine()
        if not PATCHED.get("gate"):
            return False
    return not (m == "prompt.submit" and "_turn_author" in p)


def _ticketed(scope) -> bool:
    from urllib.parse import parse_qs
    qs = scope.get("query_string") or b""
    q = parse_qs(qs.decode("latin-1") if isinstance(qs, bytes) else str(qs), keep_blank_values=True)
    hdrs = {bytes(k).lower() for k, _v in (scope.get("headers") or [])}
    if "token" in q or b"x-hermes-session-token" in hdrs:
        return False
    return any(v and v[0] for v in (q.get("internal"), q.get("ticket")))


class DownGate:
    """While engaged, every caller is untrusted (no window check is possible without the gate)."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if not _STATE.failed:
            return await self.app(scope, receive, send)
        kind, path = scope.get("type"), scope.get("path") or ""
        if kind == "http" and path.startswith("/api/") and scope.get("method", "GET").upper() not in _READ:
            if not any(rx.match(path) for rx in _OPEN_WRITES):
                body = json.dumps({"detail": {"error": CODE, "plain": MESSAGE}}).encode("utf-8")
                await send({"type": "http.response.start", "status": 503,
                            "headers": [(b"content-type", b"application/json"),
                                        (b"content-length", str(len(body)).encode())]})
                await send({"type": "http.response.body", "body": body})
                return
        elif kind == "websocket" and path.startswith("/api/"):      # tickets too: nothing skips it while down (FO2-1)
            if path.rstrip("/") == "/api/ws":
                return await self.app(scope, self._filtered(receive, send), send)
            if not _OPEN_SOCKETS.match(path):
                await send({"type": "websocket.close", "code": 4403, "reason": "Qosha's approval check didn't start"})
                return
        return await self.app(scope, receive, send)

    @staticmethod
    def _filtered(receive, send):
        async def filtered():
            while True:
                msg = await receive()
                if msg.get("type") == "websocket.receive" and _STATE.failed:
                    text = msg.get("text")
                    if text is None and msg.get("bytes") is not None:
                        text = msg["bytes"].decode("utf-8", "replace")
                    try:
                        frame = json.loads(text or "")
                    except Exception:
                        frame = None
                    if isinstance(frame, dict) and frame.get("method") == "config.set" and \
                            isinstance(frame.get("params"), dict) and "confirm_expensive_model" in frame["params"]:
                        frame["params"].pop("confirm_expensive_model", None)   # the person confirms a costly model (FO2-13)
                        msg = dict(msg, text=json.dumps(frame))
                        msg.pop("bytes", None)
                    if not _frame_ok(frame):
                        fid = frame.get("id") if isinstance(frame, dict) and "method" in frame else None
                        if fid is not None:
                            await send({"type": "websocket.send", "text": json.dumps(
                                {"jsonrpc": "2.0", "id": fid, "error": {"code": -32002, "message": MESSAGE}})})
                        continue
                return msg
        return filtered


def _install_door() -> bool:
    app = getattr(sys.modules.get("hermes_cli.web_server"), "app", None)
    if app is None:
        return False
    if getattr(app, "_qosha_down_gate", False):
        return True
    stack = getattr(app, "middleware_stack", None)
    if stack is None:
        app.add_middleware(DownGate)
    else:
        app.middleware_stack = DownGate(stack)
    app._qosha_down_gate = True
    return True


# ---- state ------------------------------------------------------------------------------------------------------
def engage(reason: str) -> dict:
    """Close now (idempotent; never raises). Returns what is in place."""
    _STATE.failed = str(reason or "unknown")[:200]
    out = {"door": False, "engine": False}
    try:
        out["door"] = _install_door()
    except Exception:
        log.error("Qosha approval check: the front-door refusal could not be installed")
    try:
        _patch_engine()
        out["engine"] = bool(PATCHED.get("gate"))
    except Exception:
        log.error("Qosha approval check: the engine refusal could not be installed")
    return out


def release() -> None:
    """The gate is confirmed on the dashboard's app: approvals work normally again."""
    _STATE.failed = None


def report_down(reason: str, router=None) -> None:
    """The gate didn't install: stay closed, log it, and let the pages say so (and put back anything that didn't take
    at startup: FO2-4)."""
    if not _STATE.failed:
        engage(reason)
    else:
        _STATE.failed = str(reason or _STATE.failed)[:200]
        try:
            _install_door()
        except Exception:
            pass
        if not PATCHED.get("gate"):
            try:
                _patch_engine()
            except Exception:
                pass
    log.error("Qosha approval check did not start (%s): approvals are refused until Qosha restarts", reason)
    if router is not None:
        try:
            @router.get("/approval-gate/window")
            def _window():
                return {"window": None, "down": MESSAGE}
        except Exception:
            pass


def check_decision(approve: bool):
    """For Qosha's decisions routes: None, or the refusal to return (approving while the check is down)."""
    if _STATE.failed and approve:
        return {"error": CODE, "plain": MESSAGE}
    return None


# ---- the gateway process ----------------------------------------------------------------------------------------


def refuse_gateway_tickets(reason: str = "starting") -> bool:
    """Closed until proven open in the gateway: the two ticket kinds that can answer cards or change settings (any
    spelling, or none given) are refused to everyone until release_gateway() runs after the gate registered
    (review FO-4, FO2-2)."""
    _STATE.gateway_down = str(reason or "starting")[:200]
    try:
        from gateway.control_socket import GatewayControlServer as G
    except Exception:
        return False
    orig = getattr(G, "_session_ticket", None)
    if orig is None:
        return False
    if getattr(orig, "qosha_failsafe", False):
        return True

    def _session_ticket(self, req, subject, *a, **kw):
        if _STATE.gateway_down:
            params = (req or {}).get("params") if isinstance(req, dict) else None
            purpose = str((params or {}).get("purpose") or "").strip().lower() if isinstance(params, dict) else ""
            if purpose in ("", "interactive", "native-http", "native_http"):
                raise PermissionError(MESSAGE)
        return orig(self, req, subject, *a, **kw)
    _session_ticket.qosha_failsafe = True
    _session_ticket.__wrapped__ = orig
    G._session_ticket = _session_ticket
    return True


def release_gateway() -> None:
    _STATE.gateway_down = None
