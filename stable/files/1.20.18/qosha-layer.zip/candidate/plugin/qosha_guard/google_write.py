"""Qosha's Google write tool (1.20.9, CONTRACT-GEXEC + the 12-hour plan, 21 Nov 2026).

The Google sign-in Qosha keeps on disk can only read (google_connect.SIGNIN_SCOPES). A change in the person's Google
account (send an email, add/change/delete a calendar event, move a Drive file to the trash, share it) runs only here,
inside the engine's own process, after the person pressed Allow on its card:
  1. the request is checked against the fields each operation takes (nothing else gets through);
  2. Google's sign-in opens in the person's browser for that one operation's permission (a separate Cloud project,
     "Qosha Writes", so its grant never mixes with the read sign-in), for the account that is connected;
  3. the grant is kept in memory only, checked to be for that account, used for exactly the approved request, once;
  4. then it is revoked at Google (REVOKE_AFTER_USE, option A), so the next write needs the person's click on
     Google's page again. Nothing is written to disk at any step.
"""
from __future__ import annotations

import contextlib
import urllib.error
import hashlib
import json
import logging
import os
import re
import threading
import time
import webbrowser
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

REVOKE_AFTER_USE = True     # option A (orchestrator 22:06: B lets any same-user program get a write grant with no click)
WAIT_SECONDS = 300
_G = "https://www.googleapis.com/auth/"
_ID = ["openid", _G + "userinfo.email"]
_EVENT = ("summary", "start", "end", "location", "description", "attendees", "calendar_id")
OPS = {   # operation: (Google permission, the card's kind, required fields, optional fields)
    "gmail.send": (_G + "gmail.send", "email.send", ("to", "subject", "body"), ("cc", "bcc", "thread_id", "in_reply_to")),
    "calendar.create": (_G + "calendar.events", "calendar.change", ("summary", "start", "end"), _EVENT),
    "calendar.update": (_G + "calendar.events", "calendar.change", ("event_id",), _EVENT),
    "calendar.delete": (_G + "calendar.events", "calendar.change", ("event_id",), ("calendar_id",)),
    "drive.trash": (_G + "drive", "delete", ("file_id",), ()),
    "drive.share": (_G + "drive", "share", ("file_id", "email", "role"), ()),
}
_ROLES = ("reader", "commenter", "writer")


class GrantError(Exception):
    pass


class OutcomeUnknown(Exception):
    """The request may have reached Google but its answer was lost: never sent again (GPT r1209 r2 HIGH 1)."""


# The "Qosha Writes" app (Google Cloud project qosha-writes-7213, made 21 Nov 2026 22:10–22:22 MST): pinned, so no other
# app's file can stand in for it (a revoke in the read project would end the read sign-in) (GPT r2 HIGH 10)
PINNED_CLIENT_ID = "406638105175-o9d4dhig58b0rbfc578q331k3cdim08s.apps.googleusercontent.com"
PINNED_AUTH = "https://accounts.google.com/o/oauth2/auth"
PINNED_TOKEN = "https://oauth2.googleapis.com/token"


def _below_warning(record) -> bool:
    return record.levelno >= logging.WARNING


for _n in ("requests_oauthlib", "requests_oauthlib.oauth2_session", "oauthlib", "google_auth_oauthlib", "google.auth",
           "google.auth.transport.requests"):
    _lg = logging.getLogger(_n)
    if _below_warning not in _lg.filters:
        _lg.addFilter(_below_warning)      # token answers are logged at DEBUG: never, at any time (GPT r2 HIGH 12)


# The "Qosha Writes" sign-in app file travels inside the public update locked (Ren, 22:45 MST: "Locked in the update"):
# its key comes from the read sign-in app file every install already holds, so the public page shows nothing readable
# or scannable. It is opened in memory only. (A Desktop app's secret is not confidential to Google; this keeps it out
# of public view and out of secret scanners.)
LOCKED_FILE = Path(__file__).resolve().parent / "google_write_client.locked"


def _lock_key(read_client: Dict[str, Any]) -> bytes:
    r = list(read_client.values())[0] if read_client else {}
    return hashlib.sha256(b"qosha-write-client-v1\0" + str(r.get("client_id", "")).encode() + b"\0" +
                          str(r.get("client_secret", "")).encode()).digest()


def _stream(key: bytes, salt: bytes, n: int) -> bytes:
    out, i = bytearray(), 0
    while len(out) < n:
        out += hashlib.sha256(key + salt + i.to_bytes(8, "big")).digest()
        i += 1
    return bytes(out[:n])


def lock(write_client: Dict[str, Any], read_client: Dict[str, Any]) -> str:
    import base64
    import hmac
    key = _lock_key(read_client)
    salt = os.urandom(16)
    plain = json.dumps(write_client, sort_keys=True).encode()
    data = bytes(a ^ b for a, b in zip(plain, _stream(key, salt, len(plain))))
    mac = hmac.new(key, salt + data, hashlib.sha256).hexdigest()
    return json.dumps({"v": 1, "salt": base64.b64encode(salt).decode(), "data": base64.b64encode(data).decode(), "mac": mac})


def unlock(blob: str, read_client: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    import base64
    import hmac
    try:
        d = json.loads(blob)
        key = _lock_key(read_client)
        salt, data = base64.b64decode(d["salt"]), base64.b64decode(d["data"])
        if not hmac.compare_digest(hmac.new(key, salt + data, hashlib.sha256).hexdigest(), str(d["mac"])):
            return None
        return json.loads(bytes(a ^ b for a, b in zip(data, _stream(key, salt, len(data)))).decode())
    except Exception:
        return None


def _client_config(h: Path) -> Tuple[Optional[Dict[str, Any]], str]:
    """The "Qosha Writes" app: the plain file a new install carries, else the locked one in the update (in memory)."""
    plain = h / "google_write_client_secret.json"
    if plain.exists():
        try:
            return json.loads(plain.read_text(encoding="utf-8")), ""
        except Exception:
            return None, "Qosha's Google change sign-in file can't be read"
    if not LOCKED_FILE.exists():
        return None, "Qosha's Google change sign-in isn't set up on this computer yet"
    try:
        read = json.loads((h / "google_client_secret.json").read_text(encoding="utf-8"))
    except Exception:
        return None, "reconnect Google in Qosha to finish the update (Settings → Connections)"
    cfg = unlock(LOCKED_FILE.read_text(encoding="utf-8"), read)
    if cfg is None:
        return None, "reconnect Google in Qosha to finish the update (Settings → Connections)"
    return cfg, ""


# A request becomes runnable only when the person allowed its card: pre_tool_call records it as pending for that tool
# call (with the Google account the card named); the engine's post_approval_response with a consenting choice makes it
# runnable; each runs once. All in the engine's own memory: a program the agent starts has its own empty copy, and
# with approvals switched off nothing is ever consented, so nothing runs (GPT r1209 HIGH 8; r2 HIGH 2, 3).
_PENDING: Dict[str, Tuple[str, str, float]] = {}
_EXPECTED: Dict[str, Tuple[str, float]] = {}
_EXP_LOCK = threading.Lock()
_EXPECT_FOR = 900


def _key(args: Any) -> str:
    return hashlib.sha256(json.dumps(args if isinstance(args, dict) else {}, sort_keys=True, default=str).encode()).hexdigest()


def _prune(now: float) -> None:
    for d in (_PENDING, _EXPECTED):
        for k in [k for k, v in d.items() if now - v[-1] > _EXPECT_FOR]:
            d.pop(k, None)


def pending(tool_call_id: str, args: Any, account_: str) -> None:
    if not tool_call_id:
        return
    with _EXP_LOCK:
        now = time.monotonic()
        _prune(now)
        _PENDING[str(tool_call_id)] = (_key(args), str(account_ or "").lower(), now)


def consent(tool_call_id: str, allowed: bool) -> None:
    with _EXP_LOCK:
        p = _PENDING.pop(str(tool_call_id or ""), None)
        if p and allowed:
            _EXPECTED[p[0]] = (p[1], time.monotonic())


def _take(args: Any) -> Optional[str]:
    """The account the person allowed this exact request for, or None (not allowed, already done, or too old)."""
    with _EXP_LOCK:
        v = _EXPECTED.pop(_key(args), None)
        if v is None or time.monotonic() - v[1] > _EXPECT_FOR:
            return None
        return v[0]


@contextlib.contextmanager
def _quiet_oauth():
    """The OAuth libraries log whole token answers at DEBUG: never while a write grant is exchanged (GPT HIGH 6)."""
    names = ("requests_oauthlib", "oauthlib", "google_auth_oauthlib", "google.auth", "urllib3")
    old = {n: logging.getLogger(n).level for n in names}
    try:
        for n in names:
            logging.getLogger(n).setLevel(logging.WARNING)
        yield
    finally:
        for n, lv in old.items():
            logging.getLogger(n).setLevel(lv)


def _event_id(op: str, clean: Dict[str, Any]) -> str:
    """A stable event id for an approved create (base32hex), so a repeated request can't make a second event."""
    d = hashlib.sha256((op + json.dumps(clean, sort_keys=True)).encode()).digest()
    alpha = "0123456789abcdefghijklmnopqrstuv"
    n = int.from_bytes(d[:20], "big")
    return "".join(alpha[(n >> (5 * i)) & 31] for i in range(32))


def _home() -> Path:
    try:
        from .google_connect import _home as gc_home   # the engine's profile-aware home, as Connect uses
        return Path(gc_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or (Path.home() / ".hermes"))


def account(home: Path) -> str:
    """The connected Google account: the read sign-in's credentials file is named after it."""
    files = sorted((home / "google_workspace_mcp" / "credentials").glob("*.json"))
    return files[0].stem if len(files) == 1 else ""


def validate(args: Any) -> Tuple[str, Dict[str, Any]]:
    a = args if isinstance(args, dict) else {}
    op = str(a.get("operation") or "")
    if op not in OPS:
        raise ValueError("Qosha can't do '%s' in Google yet. It can send an email, add, change or delete a calendar "
                         "event, move a Drive file to the trash, or share it." % op[:40])
    _scope, _kind, need, opt = OPS[op]
    extra = [k for k in a if k not in ("operation",) + need + opt]
    if extra:
        raise ValueError("Not done: %s is not something Qosha passes to Google for %s." % (", ".join(sorted(extra))[:120], op))
    missing = [k for k in need if a.get(k) in (None, "", [])]
    if missing:
        raise ValueError("Not done: %s needs %s." % (op, ", ".join(missing)))
    clean = {k: a[k] for k in need + opt if a.get(k) not in (None, "", [])}
    if op == "calendar.update" and "summary" in a and a["summary"] == "":
        raise ValueError("Not done: clearing an event's title isn't offered; give the new title.")
    if op == "calendar.update":
        for k, empty in (("attendees", []), ("location", ""), ("description", "")):
            if k in a and a[k] == empty:
                clean[k] = empty               # an explicit empty value clears it (GPT HIGH 11; r2 HIGH 13)
    for k, v in clean.items():
        if k == "attendees":
            if not (isinstance(v, list) and all(isinstance(x, str) for x in v)):
                raise ValueError("Not done: attendees must be a list of email addresses.")
        elif not isinstance(v, str):
            raise ValueError("Not done: %s must be text." % k)
    if op == "drive.share" and clean["role"] not in _ROLES:
        raise ValueError("Not done: role must be reader, commenter or writer.")
    return op, clean


class Google:
    """The real Google side. Every method keeps tokens in memory only."""

    def obtain(self, client_config: Dict[str, Any], scopes: list, login_hint: str, timeout: int) -> Any:
        from http.server import BaseHTTPRequestHandler, HTTPServer
        from google_auth_oauthlib.flow import Flow
        got: Dict[str, Any] = {}
        done = threading.Event()

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                from urllib.parse import parse_qs, urlparse
                q = parse_qs(urlparse(self.path).query)
                if "state" in q or "error" in q:
                    got.update({k: v[0] for k, v in q.items()})
                    done.set()
                body = b"<p>Qosha got Google's answer. You can close this tab.</p>"
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        srv = HTTPServer(("127.0.0.1", 0), H)
        srv.timeout = 0.5
        try:
            flow = Flow.from_client_config(client_config, scopes=scopes,
                                                 redirect_uri="http://127.0.0.1:%d/" % srv.server_address[1],
                                                 autogenerate_code_verifier=True)   # PKCE: the verifier stays here
            url, state = flow.authorization_url(login_hint=login_hint, prompt="consent")
            webbrowser.open(url)
            end = time.monotonic() + timeout
            while not done.is_set() and time.monotonic() < end:
                srv.handle_request()
        finally:
            srv.server_close()
        if not done.is_set():
            raise GrantError("timeout")
        if got.get("error") or got.get("state") != state or not got.get("code"):
            raise GrantError("refused")
        os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"
        with _quiet_oauth():
            flow.fetch_token(code=got["code"])
        return flow.credentials

    def who(self, creds) -> str:
        import urllib.request
        req = urllib.request.Request("https://openidconnect.googleapis.com/v1/userinfo",
                                     headers={"Authorization": "Bearer " + creds.token})
        with urllib.request.urlopen(req, timeout=15) as r:
            return str(json.loads(r.read().decode("utf-8")).get("email") or "")

    _open = None

    def _call(self, creds, method: str, url: str, body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """One HTTPS request, sent once: no library retry or reconnect can send a change twice (GPT r2 HIGH 1)."""
        import urllib.request
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method=method,
                                     headers={"Authorization": "Bearer " + str(getattr(creds, "token", "")),
                                              "Content-Type": "application/json"})
        opener = self._open or urllib.request.urlopen
        try:
            with opener(req, timeout=60) as r:
                raw = r.read()
        except urllib.error.HTTPError as exc:
            raise RuntimeError("Google said %s" % exc.code) from None
        except Exception:
            raise OutcomeUnknown() from None
        return json.loads(raw.decode("utf-8")) if raw else {}

    def perform(self, op: str, c: Dict[str, Any], creds) -> Dict[str, Any]:
        import urllib.error  # noqa: F401  (used in _call)
        from urllib.parse import quote
        if op == "gmail.send":
            import base64
            from email.mime.text import MIMEText
            m = MIMEText(c["body"], "plain", "utf-8")
            m["To"], m["Subject"] = c["to"], c["subject"]
            for k, h in (("cc", "Cc"), ("bcc", "Bcc"), ("in_reply_to", "In-Reply-To")):
                if c.get(k):
                    m[h] = c[k]
            if c.get("in_reply_to"):
                m["References"] = c["in_reply_to"]
            body = {"raw": base64.urlsafe_b64encode(m.as_bytes()).decode()}
            if c.get("thread_id"):
                body["threadId"] = c["thread_id"]
            r = self._call(creds, "POST", "https://gmail.googleapis.com/gmail/v1/users/me/messages/send", body)
            return {"id": r.get("id")}
        if op.startswith("calendar."):
            cal = quote(c.get("calendar_id") or "primary", safe="")
            base = "https://www.googleapis.com/calendar/v3/calendars/%s/events" % cal
            if op == "calendar.delete":
                self._call(creds, "DELETE", base + "/" + quote(c["event_id"], safe=""))
                return {"deleted": c["event_id"]}
            body = {k: c[k] for k in ("summary", "location", "description") if k in c}
            for k in ("start", "end"):
                if k in c:
                    body[k] = {"dateTime": c[k]}
            if "attendees" in c:
                body["attendees"] = [{"email": x} for x in c["attendees"]]
            if op == "calendar.create":
                body["id"] = _event_id(op, c)
                return {"id": self._call(creds, "POST", base, body).get("id")}
            return {"id": self._call(creds, "PATCH", base + "/" + quote(c["event_id"], safe=""), body).get("id")}
        f = "https://www.googleapis.com/drive/v3/files/" + quote(c["file_id"], safe="")
        if op == "drive.trash":
            self._call(creds, "PATCH", f + "?supportsAllDrives=true", {"trashed": True})
            return {"trashed": c["file_id"]}
        r = self._call(creds, "POST", f + "/permissions?sendNotificationEmail=false&supportsAllDrives=true",
                       {"type": "user", "role": c["role"], "emailAddress": c["email"]})
        return {"permission": r.get("id")}

    def revoke(self, creds) -> bool:
        from .google_connect import _revoke
        tok = getattr(creds, "refresh_token", None) or getattr(creds, "token", None)
        return bool(tok) and _revoke(str(tok))


def _client_ok(h: Path, cfg: Dict[str, Any]) -> str:
    """Only the pinned "Qosha Writes" app, with Google's own endpoints, as the file's one and only entry (the sign-in
    library would prefer any "web" entry beside it) (GPT r1209 HIGH 7; r2 HIGH 10; verification HIGH 6)."""
    if not isinstance(cfg, dict) or list(cfg) != ["installed"]:
        return "Qosha's Google change sign-in is set up wrongly (it must be Qosha's own Google change app)"
    w = cfg["installed"] if isinstance(cfg.get("installed"), dict) else {}
    if w.get("client_id") != PINNED_CLIENT_ID or w.get("token_uri") != PINNED_TOKEN or w.get("auth_uri") != PINNED_AUTH:
        return "Qosha's Google change sign-in is set up wrongly (it must be Qosha's own Google change app)"
    return ""


_LEFT_GRANTS: list = []          # grants Google didn't confirm withdrawn: no new write until they are (GPT r2 HIGH 11)


def _withdraw(g, creds, tries: int, pause: float) -> bool:
    for _i in range(tries):
        try:
            if g.revoke(creds):
                return True
        except Exception:  # noqa: BLE001
            pass
        time.sleep(pause)
    return False


def run(args: Any, home: Optional[Path] = None, google: Optional[Any] = None) -> Dict[str, Any]:
    """Does one change the person allowed. Never raises; never writes a file; never logs a token."""
    before = len(_LEFT_GRANTS)
    r = _run(args, home, google)
    return _note_left(r) if len(_LEFT_GRANTS) > before else r


def _run(args: Any, home: Optional[Path] = None, google: Optional[Any] = None) -> Dict[str, Any]:
    g = google or Google()
    pause = 0 if google is not None else 1
    for creds in list(_LEFT_GRANTS):           # first, any grant still out there from an earlier change
        if _withdraw(g, creds, 2, pause):
            _LEFT_GRANTS.remove(creds)
    if _LEFT_GRANTS:
        return {"ok": False, "message": "Not done: Google still holds the permission from the last change and Qosha "
                "couldn't withdraw it yet. Try again in a minute, or remove it at myaccount.google.com/permissions "
                "(Qosha Writes)."}
    h = Path(home) if home else _home()
    try:
        op, clean = validate(args)
    except ValueError as exc:
        return {"ok": False, "message": str(exc)}
    allowed_for = _take(args)
    if allowed_for is None:
        return {"ok": False, "message": "Not done: this change wasn't allowed on Qosha's card (or was already done)."}
    who = account(h)
    cfg, bad = _client_config(h)
    bad = bad or _client_ok(h, cfg)
    if bad:
        return {"ok": False, "message": "Not done: %s." % bad}
    if not who:
        return {"ok": False, "message": "Not done: connect Google in Qosha first (Settings → Connections)."}
    if allowed_for != who.lower():           # exact: a card shown with no account never covers one (verification HIGH 8)
        return {"ok": False, "message": "Not done: the card was for %s, but Google is now connected as %s." % (allowed_for, who)}
    creds = None
    try:
        creds = g.obtain({"installed": dict(cfg["installed"])}, sorted(set([OPS[op][0]] + _ID)), who, WAIT_SECONDS)
        if str(g.who(creds)).lower() != who.lower():
            return {"ok": False, "message": "Not done: Google's page was finished for another account. Use %s." % who}
        if account(h).lower() != who.lower():
            return {"ok": False, "message": "Not done: Google was disconnected or changed in Qosha meanwhile."}
        out = g.perform(op, clean, creds)
        return {"ok": True, "message": "Done in Google (%s)." % op, "result": out}
    except OutcomeUnknown:
        return {"ok": False, "message": "Outcome unknown: Google's answer was lost, so it may or may not have been done. "
                "Check in Google before trying again (Qosha won't repeat it on its own)."}
    except GrantError as exc:
        return {"ok": False, "message": "Not done: Google's page wasn't finished%s, so nothing was changed." %
                (" in time" if str(exc) == "timeout" else "")}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "message": "Not done: Google answered with an error (%s); nothing more was tried." % type(exc).__name__}
    finally:
        if creds is not None and REVOKE_AFTER_USE and not _withdraw(g, creds, 3, pause):
            _LEFT_GRANTS.append(creds)          # kept in memory only, to withdraw before any next write
        creds = None


def _note_left(r: Dict[str, Any]) -> Dict[str, Any]:
    if _LEFT_GRANTS:
        r = dict(r)
        r["message"] = (r.get("message", "") + " Qosha could not withdraw Google's permission for this change "
                        "afterwards; it will try again before the next change. The person can also remove it at "
                        "myaccount.google.com/permissions (Qosha Writes).")
    return r


SCHEMA = {"name": "qosha_google_change",
          "description": ("Change something in the person's Google account: send an email (gmail.send), add, change or "
                          "delete a calendar event (calendar.create/update/delete), move a Drive file to the trash "
                          "(drive.trash) or share it (drive.share). The person approves it on Qosha's card, then confirms "
                          "on Google's page in their browser. Google reads go through the google tools (search, get, list)."),
          "parameters": {"type": "object", "properties": {
              "operation": {"type": "string", "enum": sorted(OPS)},
              "to": {"type": "string"}, "cc": {"type": "string"}, "bcc": {"type": "string"},
              "subject": {"type": "string"}, "body": {"type": "string", "description": "plain text"},
              "thread_id": {"type": "string"}, "in_reply_to": {"type": "string"},
              "event_id": {"type": "string"}, "calendar_id": {"type": "string"},
              "summary": {"type": "string"}, "start": {"type": "string", "description": "RFC 3339 with time zone"},
              "end": {"type": "string"}, "location": {"type": "string"}, "description": {"type": "string"},
              "attendees": {"type": "array", "items": {"type": "string"}},
              "file_id": {"type": "string"}, "email": {"type": "string"},
              "role": {"type": "string", "enum": list(_ROLES)}},
              "required": ["operation"]}}


def _handler(args, **_kw) -> str:
    return json.dumps(run(args))


def register(ctx) -> None:
    ctx.register_tool(name="qosha_google_change", toolset="qosha", schema=SCHEMA, handler=_handler,
                      check_fn=lambda: True, description=SCHEMA["description"], emoji="✉️")
