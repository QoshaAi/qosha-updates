"""Turning on pay-per-use AI is the person's call (Ren, card, 21 Nov 2026 ~19:15 MST: "Ship now, fix the switch next";
review CL-40). A step of the assistant that switches on "Use my API key" or "Use a paid backup AI" is put to the person
on Qosha's approval card, as its own kind ("Always allow" for payments never covers it). Editing the backup chain itself
never asks: while this computer has a Claude subscription a pay-per-use backup is only used with the second switch on
(claude_limit.py), so the switch is the one place consent is given (review PB-9, PB-10, PB-12). Read with the rest of the ask-first rule (ask.py); judged on the step's own text, like every
other kind there. Switching paid use OFF never asks.
"""
from __future__ import annotations

import json
import re
from typing import Any, Optional

KIND = "ai.paid"
KIND_TEXT = "turn on pay-per-use AI (your Anthropic API key or a paid backup AI)"
NOTE = ("It stays on until you switch it off in Settings > Claude usage limit. Pay-per-use AI is charged for every "
        "request, on top of your subscription.")
MIXED = ("Not run: this step changes whether Qosha may use pay-per-use AI and also does something else that needs the "
         "person's OK. Do the AI setting on its own, as one step, so the person sees exactly what changes. Nothing ran.")

_CHOICE = re.compile(r"(claude_key_on_limit|paid_backup_on_limit)", re.I)
# pieces of the setting's name next to Qosha's settings block: a name built from parts (best effort; review round 2)
_PIECES = re.compile(r"(key|backup)_?on_?limit|_on_limit", re.I)
_BLOCK = re.compile(r"qosha_ai", re.I)
# a value written right after the setting's name that is really OFF: the value must end there (not "False or True")
_OFF = re.compile(r"""^(?:\\?["'`]|\s|[:=,\]\[]|\\n)*(?:false|no|off|0|null|none)(?=\s*(?:$|[\r\n,}\])#;"'`]|\\[nr"']))""", re.I)
# only steps that can change something are judged (a message or a note that mentions the setting is not a change)
_CHANGERS = {"terminal", "process", "process_manage", "execute_code", "write_file", "patch", "browser_exec"}
_CHANGER_WORDS = ("write", "patch", "edit", "replace", "create", "update", "set", "save", "put", "apply", "exec",
                  "run", "shell", "script", "command", "code")
# keys that hold the text being REPLACED in an edit (the old side never turns anything on)
_OLD_KEYS = {"old_string", "old_str", "old", "old_text", "search", "find"}
# a shell step that only reads: every part of a pipeline is a reader; no redirection, no in-place edit, no second
# command (; & && || newline), no command run inside (`...`, $(...), <(...), >(...), rg --pre, sort --compress-program)
_READERS = ("cat", "type", "less", "more", "head", "tail", "grep", "rg", "ls", "dir", "wc", "stat", "file",
            "get-content", "select-string", "findstr", "cut", "jq", "gc", "sls", "where-object")   # sort/uniq/yq can write
_WRITE_SIGNS = re.compile(r">|\btee\b|\b(?:sed|perl|ruby)\b[^|;&\n]*\s-i|--in-place|\bsponge\b|;|&|`|\$\(|<\(|"
                          r"--pre\b|--compress-program|-Encoding\s+\w+\s+-Value|\bset-content\b|\bout-file\b|[\r\n]",
                          re.I)
_CONFIG_READ = re.compile(r"^\S*(?:hermes|qosha)(?:\.exe)?\s+config\s+(?:get|show|list|path|check)\b", re.I)


def _strip_old(v: Any) -> Any:
    """Drop what an edit takes away: old-side keys, and the removed lines of a patch or diff."""
    if isinstance(v, dict):
        return {k: _strip_old(x) for k, x in v.items() if str(k).lower() not in _OLD_KEYS}
    if isinstance(v, list):
        return [_strip_old(x) for x in v]
    if isinstance(v, str) and re.search(r"^(\*\*\* |@@|--- |\+\+\+ )", v, re.M):
        return "\n".join(l for l in v.splitlines() if not (l.startswith("-") and not l.startswith("---")))
    return v


def _flat(args: Any) -> str:
    args = _strip_old(args)
    if isinstance(args, str):
        return args
    try:
        return json.dumps(args, ensure_ascii=False, default=str)
    except Exception:
        return str(args)


def _changer(tool: str) -> bool:
    low = tool.lower()
    base = low.rsplit("__", 1)[-1] if low.startswith("mcp__") else low
    return base in _CHANGERS or any(w in base for w in _CHANGER_WORDS)


def _plain_read(tool: str, args: Any) -> bool:
    """A shell step that only reads: Qosha's/the engine's `config get|show|list`, or a pipeline of readers only."""
    if tool not in ("terminal", "process", "process_manage"):
        return False
    cmd = str((args or {}).get("command") or "") if isinstance(args, dict) else str(args or "")
    cmd = cmd.strip()
    if not cmd or _WRITE_SIGNS.search(cmd):
        return False
    parts = cmd.split("|")
    if _CONFIG_READ.match(parts[0].strip()):
        parts = parts[1:]                          # `config get ... | rg ...`: a read into readers
        if not parts:
            return True
    for part in parts:
        w = part.strip().split()
        if not w:
            return False
        prog = re.sub(r"\.(exe|cmd|bat|ps1)$", "", re.split(r"[\\/]", w[0].strip("\"'"))[-1].lower())
        if prog not in _READERS:
            return False
    return True


def _unwrap(tool: str, args: Any):
    a = args if isinstance(args, dict) else {}
    for _ in range(3):
        if tool != "tool_call":
            break
        inner = a.get("arguments")
        if isinstance(inner, str):
            try:
                inner = json.loads(inner)
            except Exception:
                inner = {"raw": inner}
        tool, a = str(a.get("name") or ""), inner if isinstance(inner, dict) else {}
    return tool, a


def paid_change(tool: str, args: Any) -> Optional[str]:
    """Plain words for the card when this step could turn on pay-per-use AI, else None."""
    tool, a = _unwrap(str(tool or ""), args)
    if not _changer(tool):
        return None
    text = _flat(a)
    # quotes, backslashes and string joins folded away, so "claude_key_" + "on_limit" or claude_key_on\_limit match too
    folded = re.sub(r"\\[nr]", "\n", text)                   # escaped line breaks stay line breaks
    folded = re.sub(r"[\"'`\\]", "", re.sub(r"""\\?[\"'`]\s*\+\s*\\?[\"'`]""", "", folded))
    on = [m for t in (text, folded) for m in _CHOICE.finditer(t) if not _OFF.match(t[m.end():m.end() + 40])]
    pieces = not on and not _CHOICE.search(folded) and _PIECES.search(folded) and _BLOCK.search(folded)
    if not (on or pieces) or _plain_read(tool, a):
        return None
    if pieces:
        return ("Change Settings > Claude usage limit (Qosha couldn't read exactly which choice), which may let Qosha "
                "use pay-per-use AI.")
    names = {"backup" if "backup" in m.group(1).casefold() else "key" for m in on}     # no lookup that can fail
    which = " and ".join(t for n, t in (("key", "use your Anthropic API key (pay per use) when your Claude "
                                                "subscription can't answer"),
                                         ("backup", "switch to a paid backup AI (pay per use) when your main AI "
                                                    "can't answer")) if n in names)
    return "Change Settings > Claude usage limit so Qosha may %s." % which
