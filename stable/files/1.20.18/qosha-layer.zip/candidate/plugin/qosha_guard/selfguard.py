"""Editing Qosha's approval code or approval settings asks every time, with no "Always allow" (Ren, card, 21 Nov 2026
~21:55 MST, verbatim choice: "Yes, both (Recommended)"; the card said this is the one exception to his "no built-in
limits" rule).

A step of the assistant that changes (never one that only reads):
- Qosha's approval code: the plugin (qosha_guard/, plugins/qosha), the installed layer, the engine's approval, web,
  chat-socket and gateway files, the Qosha app (Qosha.app, Programs\\Qosha, app.asar);
- approval settings: approvals (mode), the allowlists, yolo, hooks, the plugin list, Qosha's paid-AI switches, or runs
  the engine with --yolo;
gets Qosha's card, one time only. Judged on the step's own text like every other kind (paid_ai.py has the helpers);
a name built at run time is not seen (known limit, on the list).
"""
from __future__ import annotations

import re
from typing import Any, Optional

from . import paid_ai

KIND = "approval.self"
TITLE = "Qosha wants to change its own approval code or approval settings"
NOTE = ("Qosha asks every time for this (no \"Always allow\"): these are the parts that decide what Qosha must ask you "
        "first.")
MIXED = ("Not run: this step changes Qosha's approval code or settings and also does something else that needs the "
         "person's OK. Do the change on its own, as one step, so the person sees exactly what changes. Nothing ran.")

_QOSHA_HOME = r"(?:application support[\\/]+qosha|appdata[\\/]+local[\\/]+qosha|localappdata%?[\\/]+qosha|\.hermes)"
_CODE = re.compile(r"qosha_guard|plugins[\\/]+qosha(?:[\\/]|\b)|qosha[\\/]+(?:layer|engine|custom|run)[\\/]"
                   r"|home[\\/]+(?:plugins|qosha[\\/]+custom|installs|tools)[\\/]|\.hermes[\\/]+(?:plugins|hermes-agent)[\\/]"
                   r"|qosha[^\n]*site-packages|qosha_names|sitecustomize"
                   r"|qosha\.app\b|programs[\\/]+qosha\b|app\.asar|tools[\\/]+approval\w*\.py|web_server\w*\.py"
                   r"|web_routers[\\/]|tui_gateway[\\/]|hermes_cli[\\/]+(?:plugins|config\w*)\.py"
                   r"|gateway[\\/]+(?:control_socket|session_authority|session_pending_controls|session_controls"
                   r"|runtime_bootstrap|approval\w*)\.py|shell_hooks\.py|startup_barrier"
                   r"|decisions\.sqlite|-pending\.json|-approved\.json|shell-hooks-allowlist"
                   r"|(?:^|[\s\\/'\"=])\.env\b",                       # the engine loads home/.env into its environment
                   re.I)
# a file in Qosha's home named by a shell pattern (conf*, config.y*): the text can't tell which file changes
_HOME_GLOB = re.compile(_QOSHA_HOME + r"[^\n;&|]*[*?\[]", re.I)
# the engine's own commands that turn the guard off or approve on the person's behalf (review round 2, AG-7, AG-8)
_GUARD_CMDS = re.compile(r"\b(?:hermes|qosha)(?:\.exe)?\b[^\n;&|]*\b(?:plugins?\s+(?:disable|remove|uninstall|reset)"
                         r"|pairing\s+(?:approve|accept)|config\s+(?:set|unset)\s+security)\b", re.I)
# the engine's settings file itself: any change to it asks (a key can be changed without naming it, e.g. sed on a value)
_CONFIG_FILE = re.compile(r"config\.ya?ml\b", re.I)
_CONFIG_CONTEXT = re.compile(r"config\.ya?ml|\bconfig\s+(?:set|unset|edit|reset)\b|/api/config|save_config|"
                             r"load_config|set_config_value|config_set", re.I)
_CONFIG_KEYS = re.compile(r"(?<![\w-])(?:approvals?(?:\.\w+)?|command_allowlist|permanent_allowlist|yolo|hooks|hooks_auto_accept|security(?:\.\w+)?|protected_instruction_files|"
                          r"plugins(?:\.\w+)?)(?![\w-])", re.I)
_YOLO_RUN = re.compile(r"--yolo\b|HERMES_YOLO|\byolo_mode\b|--accept-hooks\b|HERMES_ACCEPT_HOOKS|\b(?:hermes|qosha)(?:\.exe)?\b[^\n;&|]*\s(?:-z|--oneshot)(?![\w-])",
                       re.I)


def check(tool: str, args: Any) -> Optional[str]:
    """Plain words for the card when this step could change Qosha's approval code or settings, else None."""
    tool, a = paid_ai._unwrap(str(tool or ""), args)
    if not paid_ai._changer(tool) or paid_ai._plain_read(tool, a):
        return None
    text = paid_ai._flat(a)
    folded = re.sub(r"[\"'`\\]", "", re.sub(r"\\[nr]", "\n", text))
    what = []
    if _CODE.search(text) or _CODE.search(folded) or _HOME_GLOB.search(folded) or _GUARD_CMDS.search(folded):
        what.append("change Qosha's approval code or the Qosha app")
    if (_CONFIG_FILE.search(folded) or (_CONFIG_CONTEXT.search(folded) and _CONFIG_KEYS.search(folded))
            or _YOLO_RUN.search(folded)):
        what.append("change what Qosha may do without asking (approval settings)")
    paid = paid_ai.paid_change(tool, args)
    if paid:
        what.append("turn on pay-per-use AI (" + paid.rstrip(".") + ")")
    if not what:
        return None
    return "This step would " + "; and ".join(what) + "."


def only_config_file(tool: str, args: Any) -> bool:
    """The step's only reason for a card is that it writes the settings file (no approval key, code path, paid switch
    or yolo run named): another one-time card for that setting may then stand on its own."""
    tool, a = paid_ai._unwrap(str(tool or ""), args)
    text = paid_ai._flat(a)
    folded = re.sub(r"[\"'`\\]", "", re.sub(r"\\[nr]", "\n", text))
    return bool(_CONFIG_FILE.search(folded)) and not (
        _CODE.search(text) or _CODE.search(folded) or _HOME_GLOB.search(folded) or _GUARD_CMDS.search(folded)
        or _CONFIG_KEYS.search(folded) or _YOLO_RUN.search(folded) or paid_ai.paid_change(tool, args))


def card(what: str) -> str:
    return "%s\nWhat happens: %s\nNote from Qosha: %s\n(\"Always allow\" is not offered for this step.)" % (TITLE, what, NOTE)
