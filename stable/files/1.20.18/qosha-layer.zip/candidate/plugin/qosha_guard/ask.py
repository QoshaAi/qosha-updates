"""Qosha's ask-first rule on the person's own computer (Ren, 16-17 Nov 2026).

No built-in walls: the assistant may read and change anything, including its own code, settings and skills, and run
commands, like the engine does. Only an action that SENDS, PAYS, DELETES, SHARES/PUBLISHES or changes a calendar is
put to the person first, through the engine's own approval prompt (Allow once / Always allow / Deny). The rule_key is
the KIND of action, so one "Always allow" covers that whole kind from then on (the engine keeps it in its allowlist;
the person can ask Qosha to undo it, and Qosha can edit that setting itself).
Everything else returns None: the engine's own behavior (including its own dangerous-command prompts) applies.
"""
from __future__ import annotations

import json
import re
from typing import Any, Dict, Optional, Tuple

KIND_TEXT = {
    "email.send": "send an email",
    "message.send": "send a message",
    "message.edit": "edit a message you already sent",
    "calendar.change": "change your calendar",
    "delete": "delete something",
    "pay": "pay, buy or move money",
    "share": "share or publish something",
    "web.post": "send data to a website",
    "web.act": "do a final step on a website (send, buy, delete, confirm, sign in, upload)",
    "google.change": "change something in your Google account (Drive, Gmail, Calendar, Docs, Sheets)",
    "ai.paid": "turn on pay-per-use AI (your Anthropic API key or a paid backup AI)",
    "browser.profile": "let Qosha's browser use your own Chrome profile, where you are signed in",
}

# commands, by what they do (checked on the whole command text, case-insensitive)
# A rule must match what the command DOES, never a word that only appears in a file name or in data (Ren, 17 Nov:
# attaching a file and Qosha reading it must never ask). So: programs are matched where a program stands (start of the
# command or after ; & | or sudo/xargs), and payment and mail by their real services and calls, not by plain words.
_AT = r"(?:^|[;&|\n]\s*|\$\(\s*|`\s*)(?:sudo\s+|xargs\s+(?:-\S+\s+)*|env\s+(?:\w+=\S+\s+)*)?"
_GITV = r"(?:'[^']*'|\"[^\"]*\"|\S+)"
_GITW = (r"git(?:\s+(?:-C\s*" + _GITV + r"|-c\s*" + _GITV + r"|"
         r"--(?:git-dir|work-tree|namespace|exec-path|super-prefix|config-env|attr-source)(?:=|\s+)" + _GITV + r"|"
         r"--(?:no-pager|paginate|bare|no-replace-objects|literal-pathspecs|glob-pathspecs|noglob-pathspecs|"
         r"icase-pathspecs|no-optional-locks|no-lazy-fetch|no-advice|exec-path)|-[pP]))*\s+")   # r1210 (r2: attached, quoted)   # git's global options (r1210)
_CMD_RULES = [
    ("email.send", r"(google_api\.py|\$GAPI|\bgws)\b.*\bgmail\s+(send|reply|forward|drafts?[-_ ]?send|\+send|\+reply|\+forward)(?![\w-])"),
    # Gmail's own API forms, by the wrapper's gws call or straight to Google (GPT vqa/r11913e rshw3 HIGH 5): refused below
    ("email.send", r"\bgmail\s+users\s+(messages|drafts)\s+send\b|\busers\.(messages|drafts)\.send\b|gmail\.googleapis\.com\S*/(messages|drafts)/send"),
    ("message.send", r"slack\.com/api/chat\.(postMessage|postEphemeral|scheduleMessage)|\bchat\.postMessage\b"),
    ("email.send", _AT + r"himalaya\b[^;&|\n]*\b(send|reply|forward)\b"),
    ("email.send", _AT + r"(sendmail|msmtp|mutt|mailx?)\s"),
    ("calendar.change", r"(google_api\.py|\$GAPI|\bgws)\b.*\bcalendar\s+(create|update|delete|add|\+insert|events\s+(insert|patch|update|delete))\b"),
    # deleting something online is a DELETE, not a share (17 Nov: `gh repo delete` was filed as share)
    ("delete", r"(google_api\.py|\$GAPI)\b[^;&|\n]*\bdrive\s+delete\b|"
               + _AT + r"(gh|glab)\s+[a-z-]+\s+delete\b|" + _AT + r"gh\s+api\b[^;&|\n]*(-X\s*|--method[\s=]+)DELETE\b|"
               + _AT + _GITW + r"push\b[^;&|\n]*(\s--delete\b|\s-d\b|\s\+?:[^\s;&|]+)"),
    ("share", r"google_api\.py\b.*\bdrive\s+(share|upload)\b"),
    ("share", _AT + r"(" + _GITW + r"push\b|gh\s+(pr|issue|release|repo|gist)\s+(create|merge|comment|edit)\b|npm\s+publish\b|twine\s+upload\b)"),
    ("pay", r"api\.stripe\.com|" + _AT + r"stripe\s+(charges|payment_intents|payouts|refunds|transfers)\b|api(-m)?\.(sandbox\.)?paypal\.com"),
    ("delete", _AT + r"(rm|rmdir|shred|unlink|trash|del|erase|rd|Remove-Item)(\s|$)|\bfind\b[^;&|\n]*\s-delete\b|"
               + _AT + _GITW + r"(clean\b|reset\b[^;&|\n]*\s--hard\b)|\bdrop\s+(table|database)\s|\bdelete\s+from\s"),
    ("web.post", _AT + r"curl\b[^;&|\n]*(\s-X\s*(POST|PUT|PATCH|DELETE)\b|\s(-d|--data\S*|-F|--form)\s)|Invoke-(WebRequest|RestMethod)[^;&|\n]*-Method\s+(Post|Put|Patch|Delete)"),
]
# code the assistant runs (execute_code): by the calls that act, not by words
_CODE_RULES = [
    ("email.send", r"smtplib\.SMTP|\.sendmail\(|\.send_message\(|\.(messages|drafts)\(\)\.send\(|gmail\.googleapis\.com\S*/(messages|drafts)/send|\bgmail\s+(users\s+messages\s+)?send\b"),
    ("message.send", r"slack\.com/api/chat\.(postMessage|postEphemeral|scheduleMessage)|\bchat[._]post_?[Mm]essage\("),
    ("delete", r"\bos\.(remove|unlink|rmdir|removedirs)\(|\bshutil\.rmtree\(|\.unlink\(\s*(missing_ok\s*=\s*\w+)?\s*\)|\.rmdir\(\)|\bfs\.(rm|unlink|rmdir)(Sync)?\("),
    ("pay", r"api\.stripe\.com|\bstripe\.(Charge|PaymentIntent|Payout|Refund|Transfer)\b|api(-m)?\.(sandbox\.)?paypal\.com"),
    ("web.post", r"\brequests\.(post|put|patch|delete)\(|\bhttpx\.(post|put|patch|delete)\(|method\s*[:=]\s*[\"'](POST|PUT|PATCH|DELETE)[\"']"),
    ("share", r"subprocess[^\n]*git[\"',\s]+push"),
]

# tool names (MCP and connector tools are named <server>_<action> or similar)
_TOOL_RULES = [
    ("email.send", r"(gmail|mail|email|outlook).*(send|reply|forward)|(send|reply|forward).*(mail|email)"),
    ("calendar.change", r"(calendar|event).*(create|update|delete|insert|patch|move)|(create|update|delete).*(event|calendar)"),
    ("pay", r"pay|checkout|purchase|charge|refund|transfer|invoice_send|buy"),
    ("delete", r"delete|remove|trash|destroy|purge|erase"),
    # a chat or message send, before the generic share rule (GPT vqa/r11913e rshw3 HIGH 5: Slack chat_postMessage was
    # filed as a share, and its card showed neither the channel nor the text)
    ("message.send", r"chat[_.]?post|post_?message|add_message|send_?message|message_create|(^|_)send_(dm|sms|text|chat)\b"),
    ("share", r"share|publish|(^|_)post|tweet|upload|invite|permission"),
    ("message.send", r"(^|_)send|message_create|chat_post|reply"),
]
# engine tools that never send/pay/delete on their own (reads, notes, its own UI)
_QUIET = {"read_file", "search_files", "web_search", "web_extract", "vision_analyze", "video_analyze", "skill_view",
          "skills_list", "todo", "todo_list", "memory", "session_search", "clarify", "browser_navigate",
          "browser_snapshot", "browser_scroll", "browser_back", "browser_close", "browser_vision", "set_theme",
          "delegate_task", "write_file", "image_generate", "text_to_speech", "tool_search"}


def _text(v: Any, n: int = 500) -> str:
    s = v if isinstance(v, str) else json.dumps(v, ensure_ascii=False, default=str)
    return s if len(s) <= n else s[:n] + " ..."


# The Google MCP (workspace-mcp 2.5.0, --tool-tier complete): the tools that only read, pinned by name and checked by
# what each one does, not by its name (1.20.8; candidates/gexec/S0-FINDINGS.md 4). get_gmail_attachment_content and
# get_drive_file_download_url write files; get_gmail_message_content writes them with full. Every other tool of the
# server, a new one in a later version included, gets a card.
_GOOGLE_MCP_READS = frozenset((
    "search_gmail_messages", "get_gmail_message_content", "get_gmail_messages_content_batch", "get_gmail_thread_content",
    "get_gmail_threads_content_batch", "list_gmail_labels", "list_gmail_filters", "list_calendars", "get_events",
    "query_freebusy", "search_drive_files", "get_drive_file_content", "list_drive_items", "get_drive_file_permissions",
    "check_drive_file_public_access", "get_drive_shareable_link", "get_doc_content", "search_docs",
    "list_docs_in_folder", "inspect_doc_structure", "debug_table_structure", "get_doc_as_markdown",
    "list_document_comments", "read_sheet_values", "get_spreadsheet_info", "list_spreadsheets", "list_sheet_tables",
    "list_spreadsheet_comments", "list_contacts", "get_contact", "search_contacts", "list_contact_groups",
    "get_contact_group", "list_task_lists", "get_task_list", "list_tasks", "get_task"))


def _google_mcp_read(base: str, a: Dict[str, Any]) -> bool:
    if base not in _GOOGLE_MCP_READS:
        return False
    if base == "get_gmail_message_content":
        # any spelling of the key (the server folds camelCase and case: core/camel_case_middleware.py), and the value
        # as the server reads a yes/no: only a clear "no" is a read; anything else asks (1.20.8 round 3)
        fulls = [v for k, v in a.items() if re.sub(r"[^a-z]", "", str(k).lower()) == "full"]
        return all(v in (None, False, 0) or (isinstance(v, str) and v.strip().lower() in ("", "false", "f", "0", "no", "n", "off", "none"))
                   for v in fulls)
    return True


_PROFILE_TOOLS = ("write_file", "patch", "terminal", "execute_code", "process", "process_manage", "browser_exec")


def _turns_on_real_profile(tool_name: str, args: Any) -> bool:
    """A step that edits settings or runs a command and turns browser.use_real_profile on (the person's own signed-in
    Chrome profile). A line a patch removes, or a value set to off, doesn't count (1.20.8 round 2)."""
    tool, a = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
    if tool not in _PROFILE_TOOLS:
        return False
    text = "\n".join(str(a.get(k) or "") for k in ("content", "patch", "command", "code", "input", "data"))
    if tool == "patch":
        text = "\n".join(ln for ln in text.splitlines() if not ln.startswith("-"))
    # turned on: the key followed by a yes value (yaml "key: true", "key=1", "config set browser.use_real_profile true");
    # a title or a search that only names it is not a settings change (1.20.8 round 3)
    return bool(re.search(r"use_real_profile[\"']?\s*[:=]?\s*[\"']?(true|yes|on|1)\b", text, re.I))


def _google_mcp(tool_name: str, args: Any) -> bool:
    t = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})[0].lower()
    return t.startswith("mcp__google__") or t == "qosha_google_change"   # Qosha's own Google write tool too (1.20.9)


def kind_of(tool: str, args: Any, task_id: str = "") -> Optional[Tuple[str, str]]:
    """(kind, what to show the person), or None when the call just runs. A shell step that only deletes things that
    are already gone is None too (pre_tool_call then stops it with a plain note: there is nothing to ask about)."""
    tool = (tool or "").strip()
    a = args if isinstance(args, dict) else {}
    # engine v0.22+: rarely used tools (MCP tools among them) are called through the "tool_call" meta-tool; the hook
    # then sees tool_call, so the real tool and its arguments are judged
    for _ in range(3):
        if tool != "tool_call":
            break
        inner = a.get("arguments") if isinstance(a.get("arguments"), dict) else {}
        if isinstance(a.get("arguments"), str):
            try:
                inner = json.loads(a["arguments"])
            except Exception:
                inner = {}
        tool, a = str(a.get("name") or "").strip(), inner if isinstance(inner, dict) else {}
    if tool in ("terminal", "execute_code", "process", "process_manage"):
        text = str(a.get("command") or a.get("code") or a.get("input") or "")
        if _engine_cli_send(a):
            return "message.send", _text(text)
        found = _step_kinds(tool, a, task_id)
        return (found[0], _text(text)) if found else None
    if tool == "browser_exec":
        # the engine's browser runs Python helpers; reading and moving between pages never asks, acting on a page does
        code = str(a.get("code") or "")
        return ("web.act", _text(code)) if web_plain(code)[3] else None
    if tool == "browser_cdp":
        # raw browser commands: a mouse press, the Enter key or a file given to the page cannot be told apart from a
        # final step, so they ask; everything else (reading, moving about) runs
        method = str(a.get("method") or "")
        params = a.get("params")
        if isinstance(params, str):            # the engine turns a JSON string into the object the browser gets (r1210 r2)
            try:
                params = json.loads(params)
            except Exception:
                params = {"type": "", "key": "Enter"} if re.search(r"Enter|Return|mouse|File", params) else {}
        params = params if isinstance(params, dict) else {}
        pseudo = 'cdp("%s", key="%s")' % (method, str(params.get("key") or "")) if re.fullmatch(r"[A-Za-z.]{1,60}", method) else ""
        if pseudo and re.search(r"Input\.dispatchMouseEvent|DOM\.setFileInputFiles", method) and str(params.get("type") or "mousePressed") in ("mousePressed", "", "mouseReleased"):
            return "web.act", pseudo
        if pseudo and method == "Input.dispatchKeyEvent" and str(params.get("key") or "") in ("Enter", "Return", "NumpadEnter") and str(params.get("type") or "") in ("keyDown", "rawKeyDown", ""):
            return "web.act", pseudo
        return None
    if tool == "patch" and re.search(r"^\*\*\* Delete File:", str(a.get("patch") or ""), re.M):
        return None if _deletes_only_gone(tool, a, task_id) else ("delete", _text(a.get("patch")))
    if tool == "qosha_google_change":
        # Qosha's Google write tool (1.20.9): its operation names the card's kind; an unknown one still asks; the card
        # names the Google account it acts on (rows_for)
        op = str(a.get("operation") or "")
        kind = {"gmail.send": "email.send", "calendar.create": "calendar.change", "calendar.update": "calendar.change",
                "calendar.delete": "calendar.change", "drive.trash": "delete", "drive.share": "share"}.get(op, "google.change")
        return kind, "%s %s" % (tool, _text(a))
    if tool == "send_message":
        if str(a.get("action") or "send").lower() in ("list", "targets"):
            return None
        return "message.send", "to %s: %s" % (a.get("target") or "?", _text(a.get("message") or a))
    if tool in _QUIET:
        return None
    low = tool.lower()
    # the engine names MCP tools mcp__<server>__<tool>
    base = low.rsplit("__", 1)[-1] if low.startswith("mcp__") else low
    act = str(a.get("action") or a.get("operation") or a.get("op") or "").lower()
    google = low.startswith("mcp__google__")
    if google and _google_mcp_read(base, a):
        return None
    # Google Workspace MCP (and similar): reads never ask; actions are judged by what they do
    if not google and re.match(r"^(get|list|search|read|check|query|find|fetch|describe)_", base):
        return None
    if act in ("delete", "remove", "trash", "clear", "destroy", "batch_delete"):
        return "delete", "%s %s" % (tool, _text(a))
    if re.search(r"(^|_)(manage_)?event", base) and act in ("create", "update", "rsvp", "respond", "move", "patch", "insert", "quick_add"):
        return "calendar.change", "%s %s" % (tool, _text(a))
    if re.search(r"access|permission|shar", base):
        return "share", "%s %s" % (tool, _text(a))
    if base.startswith("draft_") and not google:
        return None
    for kind, rx in _TOOL_RULES:
        if re.search(rx, base):
            return kind, "%s %s" % (tool, _text(a))
    if google:
        return "google.change", "%s %s" % (tool, _text(a))   # fail closed: any other Google tool is asked (1.20.8)
    return None


# the engine's command or its own sender function; "send" anywhere (send_message, send_message_tool...)
_ENGINE_WORD = re.compile(r"\b(?:hermes|hermes_cli|qosha|send_message_tool|gateway\.outbound)\b", re.I)


# Google's command-line tools (1.20.4, human approval; reproduced by the pt-BR session on 1.19.13: `gws drive files
# delete` and `gws gmail users messages trash` ran with no card): gws (Google Workspace CLI), workspace-cli (the Google
# MCP's own command line, in the engine's gws-venv) and Qosha's Google helper (google_api.py, $GAPI).
# STRICT, after six review rounds found shell forms past every text classifier: a Google program runs only as ONE
# plain command on its own (read with the guard's own shell reader, _segments): a plain read runs, anything else gets a
# card filed from its own command words (one-time, except the helper's and gws calendar-event commands the 1.20.3 table
# already filed), a send is refused like every shell send. Everything else that names a Google program (code, wrappers,
# loops, VAR= prefixes, $(...), redirections first, two Google calls, a Google call next to another protected action)
# is refused with GOOGLE_MIXED. Its name inside a title (gh issue create) or a file a plain reader reads is ignored.
_GPROG = re.compile(r"(?<![\w.-])(gws_bridge\.py|gws|workspace-cli|google_api\.py|\$\{?GAPI\}?)"
                    r"(?:\.(?:exe|cmd|bat|ps1))?(?![\w.-])", re.I)
_GWS_READ = {"list", "get", "export", "search", "query"}
_GWS_READ_HELPERS = {"+triage", "+agenda"}
_GWS_DELETE = {"delete", "trash", "emptytrash", "batchdelete", "remove", "clear", "purge", "destroy", "+delete",
               "+trash"}
_GWS_SEND = {"send", "reply", "forward", "+send", "+reply", "+reply-all", "+forward"}
_GAPI_READ = {("gmail", "search"), ("gmail", "get"), ("gmail", "labels"), ("calendar", "list"), ("drive", "search"),
              ("drive", "get"), ("drive", "download"), ("contacts", "list"), ("sheets", "get"), ("docs", "get")}
# the helper's own commands the 1.20.3 table already filed (their cards and reusable rules stay as they were)
_GAPI_KNOWN = {("gmail", "send"): "email.send", ("gmail", "reply"): "email.send", ("gmail", "forward"): "email.send",
               ("calendar", "create"): "calendar.change", ("calendar", "update"): "calendar.change",
               ("calendar", "delete"): "calendar.change", ("drive", "delete"): "delete", ("drive", "share"): "share",
               ("drive", "upload"): "share"}
_CLI_READ_VERB = {"list", "get", "search", "read", "query", "find", "fetch", "show", "view", "download", "export",
                  "status", "info", "check"}
_CLI_WRITE_WORDS = ("delete", "remove", "trash", "send", "share", "create", "update", "modify", "manage", "set", "add",
                    "move", "copy", "upload", "write", "replace", "insert", "batch", "reply", "forward", "draft", "post")
_READERS = {"cat", "type", "ls", "dir", "head", "tail", "grep", "rg", "wc", "stat", "file", "which",
            "where", "get-content", "select-string", "get-childitem"}
_IDENT = re.compile(r"^[A-Za-z][A-Za-z0-9]*$")
GOOGLE_MIXED = ("Not run: a Google step (gws, workspace-cli or the Google helper) runs only as one plain command on its "
                "own: no other actions, wrappers, loops, variables or code around it, so the person sees exactly what "
                "it does. Run it that way and ask again.")


def _unq(word: str) -> str:
    return re.sub(r"[\"'`\\]", "", word)


def _prog_name(word: str) -> str:
    """The program a command word names: its last path part, lower case, without quotes or .exe/.cmd/.bat/.ps1."""
    if re.search(r"[=<>()]", word) or re.match(r"\d+[<>]", word):
        return ""                              # r1205 #3: FOO=/cat, </tmp/cat, (gws ... are not a program named cat or gws
    w = re.split(r"[\\/]", word.strip("\"'`"))[-1].lower()
    return re.sub(r"\.(?:exe|cmd|bat|ps1)$", "", _unq(w))


_GMODNAME = re.compile(r"(?:(?<![\w-])|(?<=-m))(?:google_api|gws_bridge)(?![\w-])", re.I)   # scripts.google_api too
_GMODONLY = re.compile(r"(?:(?<![\w/\\-])|(?<=-m))(?:google_api|gws_bridge)(?![\w-])(?!\.py\b)", re.I)   # not a path  # a module, not the script   # as a Python module (python -m, import)
_PYWORD = re.compile(r"(?<![\w.-])(?:python[0-9.]*|pythonw|py)(?:\.exe)?(?![\w.-])", re.I)


def _escapes(text: str) -> str:
    """Every \\xHH, \\uHHHH, \\UHHHHHHHH and \\NNN decoded wherever it is (bash's $'...' does it; anywhere else
    decoding only makes the mention check broader) (Gemini on 56053283, HIGH 3)."""
    def one(m):
        try:
            return chr((int(m.group(1), 8) & 0xFF) if m.group(1) else int(m.group(2) or m.group(3) or m.group(4), 16))
        except (ValueError, OverflowError):
            return m.group(0)
    return re.sub(r"\\([0-7]{1,3})|\\x([0-9a-fA-F]{1,2})|\\u([0-9a-fA-F]{1,4})|\\U([0-9a-fA-F]{1,8})", one, text)


def _mentions_google(raw: str) -> bool:
    """Any mention of a Google program, however it is quoted, escaped or split (r1205 round 2): the step is then held to
    _plain_shell. Broad on purpose; whether a Google program RUNS is decided per command afterwards."""
    flat = _escapes(raw)
    flat = re.sub(r"\\\r?\n", "", flat)
    flat = re.sub(r"[\"'`\\${},]", "", flat)
    # a skeleton: letters and digits only, lower case, words kept apart, so quotes, braces, $(), escapes and capitals
    # can't hide a name (Gemini on 352a51d6, HIGH 1-3, 6)
    def skel(text):
        return re.sub(r"[^a-z0-9\s]", "", re.sub(r"\\\r?\n", "", text).lower())
    # bash's $'...': escapes decoded, \c@ is NUL, and a NUL ends the quoted text (Gemini on b51e6a47, HIGH 3)
    ansi = re.sub(r"\$'((?:[^'\\]|\\.)*)'",
                  lambda m: _escapes(m.group(1).replace("\\c@", "\\0")).split("\x00", 1)[0], raw)
    # an expansion that adds nothing: $(...), `...`, ${...}, $NAME (Gemini on b51e6a47, HIGH 2)
    nosub = re.sub(r"\$\([^)]*\)|`[^`]*`|\$\{[^}]*\}|\$[A-Za-z_]\w*", "", raw)
    sks = [skel(_escapes(raw)), skel(ansi), skel(_escapes(nosub)), skel(re.sub(r"\$\([^)]*\)|`[^`]*`|\$\{[^}]*\}|"
                                                                            r"\$[A-Za-z_]\w*", "", ansi))]
    return bool(_names_google(raw) or _GPROG.search(flat) or _GMODNAME.search(flat) or
                any(re.search(r"gws|googleapi|workspacecli", s) for s in sks))


_BARE_BAD = set("$`\\(){}#!*?[]")
_DQ_BAD = set("$`\\!")


def _plain_shell(cmd: str) -> bool:
    """Plain bash text, read the same way by every reader (r1205 round 2). Outside quotes: no $ (except $GAPI), backtick,
    backslash, ( ) { } # ! * ? [ ]; inside double quotes: no $ (except $GAPI), backtick, backslash, !; single-quoted
    text is data. The engine runs bash on Mac and Windows (Git Bash), so this holds on both."""
    cmd = re.sub(r"\$\{GAPI\}|\$GAPI(?![\w{])", "GAPI", cmd)
    i, n = 0, len(cmd)
    while i < n:
        c = cmd[i]
        if c in "'\"":
            j = cmd.find(c, i + 1)
            if j < 0 or (c == '"' and any(ch in _DQ_BAD for ch in cmd[i + 1:j])):
                return False
            i = j + 1
            continue
        if c in _BARE_BAD or cmd.startswith("<<", i):
            return False                       # a heredoc's text is not shell quoting (Gemini on b51e6a47, HIGH 1)
        i += 1
    return True


def _names_google(word: str) -> bool:
    word = word.replace("\\\r\n", "").replace("\\\n", "")       # r1205 #5: g\<newline>ws is gws to the shell
    return bool(_GPROG.search(word) or _GPROG.search(_unq(word)) or _GPROG.search(re.sub(r"[\"'`\\]", " ", word)))


def _is_python(word: str) -> bool:
    return bool(re.fullmatch(r"(?:pythonw?|pypy|ipython|jython|graalpy|micropython)[0-9.]*[a-z0-9_-]*|py", _prog_name(word)))


def _is_helper(word: str) -> bool:
    return _prog_name(word) == "google_api.py" or bool(re.fullmatch(r"\$\{?GAPI\}?", word.strip("\"'")))


def _is_bridge(word: str) -> bool:
    return _prog_name(word) in ("gws_bridge.py", "gws_bridge")


def _gws_kind(rest: list) -> Tuple[str, bool]:
    """(kind, reusable) of a plain gws call, from its own command words; ("read", ...) for a plain read."""
    if rest in (["--help"], ["-h"], ["--version"]):
        return "read", False
    if rest and rest[0].startswith("-"):
        return "refuse", False                 # options before the service: can't be read safely
    sub = []
    for w in rest:
        if w.startswith("-"):
            break
        sub.append(w)
    low = [w.lower() for w in sub]
    args = " ".join(rest[len(sub):])
    if low and low[0] == "schema":
        return "read", False
    helpers = [w for w in low if w.startswith("+")]
    if not helpers and 2 <= len(sub) <= 5 and all(_IDENT.match(w) for w in sub) and low[-1] in _GWS_READ:
        return "read", False
    if helpers and all(h in _GWS_READ_HELPERS for h in helpers) and all(_IDENT.match(w) or w in _GWS_READ_HELPERS for w in low):
        return "read", False
    if set(low) & _GWS_SEND or (low and low[0] == "chat" and set(low) & {"create", "patch", "update", "send"}):
        return ("message.send" if low and low[0] == "chat" else "email.send"), False
    if low and low[0] == "calendar":
        if "acl" in low:
            return "share", False
        if "events" in low and low[-1] in ("insert", "patch", "update", "delete"):
            return "calendar.change", True     # exactly the 1.20.3 table's own calendar rule
        if "events" in low and low[-1] in ("import", "move", "quickadd"):
            return "calendar.change", False    # moving or importing: one-time
        if low[-1] in ("+insert", "+create"):
            return "calendar.change", True
        if set(low) & {"clear", "delete"}:
            return "delete", False
        return "google.change", False
    if set(low) & _GWS_DELETE:
        return "delete", False
    if low[-2:] == ["files", "update"] and re.search(r"\btrashed\W{0,4}(?:true|1)\b", args, re.I):
        return "delete", False
    if set(low) & {"permissions", "+share", "+upload", "share", "publish", "+publish"}:
        return "share", False
    return "google.change", False


def _wcli_kind(rest: list) -> Tuple[str, bool]:
    while rest and rest[0].lower().startswith("--url"):
        url = rest[0].split("=", 1)[1] if "=" in rest[0] else (rest[1] if len(rest) > 1 else "")
        if not re.match(r"^https?://(?:127\.0\.0\.1|localhost|\[::1\])(?::\d+)?(?:/|$)", url.strip("\"'")):
            return "refuse", False             # another server would receive what is asked (a search included)
        rest = rest[1:] if "=" in rest[0] else rest[2:]
    if rest in (["list"], ["--help"], ["-h"]):
        return "read", False
    if len(rest) < 2 or rest[0] != "call" or rest[1].startswith("-"):
        return "refuse", False
    name = rest[1].lower()
    for kind, rx in _TOOL_RULES:
        if kind in ("email.send", "message.send") and re.search(rx, name, re.I):
            return kind, False
    if name.split("_")[0] in _CLI_READ_VERB and not any(w in name for w in _CLI_WRITE_WORDS):
        return "read", False
    if re.search(r"(?:^|_)(?:delete|trash|remove|purge|destroy)(?:_|$)", name):
        return "delete", False
    if re.search(r"share|access|permission", name):
        return "share", False
    return "google.change", False


_GAPI_OPTS = {"--add-labels", "--attendees", "--body", "--calendar", "--cc", "--description", "--domain", "--email",
              "--end", "--export-mime", "--from", "--html", "--location", "--max", "--mime-type", "--name", "--notify",
              "--output", "--parent", "--permanent", "--raw-query", "--remove-labels", "--role", "--sheet-name",
              "--start", "--subject", "--summary", "--text", "--thread-id", "--title", "--to", "--type", "--values",
              "-h", "--help"}


def _gapi_kind(rest: list) -> Tuple[str, bool]:
    if not rest or rest[0].startswith("-"):
        return "refuse", False
    if any(x.startswith("-") and len(x) > 1 and not re.fullmatch(r"-\d+(?:\.\d+)?", x) and x not in _GAPI_OPTS
           for x in rest):
        return "refuse", False                 # an abbreviated (--perm) or name=value option: the card reads exact names (r1205)
    w = tuple(x.lower() for x in rest[:2])
    if w in _GAPI_READ:
        return "read", False
    if w == ("drive", "share") and any(x.lower().startswith("--n") for x in rest):
        return "share", False                  # it also emails the person: never covered by a saved grant
    if w in _GAPI_KNOWN:
        return _GAPI_KNOWN[w], True
    return "google.change", False


_MOD_RUNNERS = {"uv", "uvx", "pipx", "poetry", "pdm", "hatch", "rye", "pixi", "conda", "mamba", "micromamba", "run",
                "exec", "runpy", "import", "importlib", "bash", "sh", "zsh", "dash", "ksh", "fish", "pwsh", "powershell",
                "cmd", "env", "xargs", "eval", "source", "nohup", "timeout", "sudo", "nice", "watch"}   # anything that can run a Python module (r1205 final pass 4: uv run -m google_api)
_SAFE_NEIGHBOURS = _READERS | {"cd", "pwd", "echo", "jq", "sort", "uniq", "mkdir", "true"}


def _runs_program(argv: list) -> bool:
    """A reader option that runs another program (rg --pre, rg -z runs decompressors) (r1205 final pass 3)."""
    p = _prog_name(argv[0])
    return any(w.startswith(("--pre", "--search-z")) or (p == "rg" and re.fullmatch(r"-[A-Za-z]*z[A-Za-z]*", w)) or
               (p == "sort" and w.startswith("--comp")) for w in argv[1:])   # sort --compress-program runs one too


def _plain_git(argv: list) -> bool:
    """git with nothing that runs a program (no -c, --exec-path, --upload-pack, --receive-pack, --config ...)."""
    return _prog_name(argv[0]) == "git" and not any(
        w.startswith(("-c", "--exec-path", "--upload-pack", "--receive-pack", "--config", "--git-dir", "--work-tree",
                      "--namespace", "--super-prefix")) or w in ("-C",) for w in argv[1:])


def _safe_neighbour(argv: list) -> bool:
    """A plain command that runs nothing it reads: a reader, cd, echo ..., or gh posting text."""
    p = _prog_name(argv[0])
    if _runs_program(argv):
        return False
    return p in _SAFE_NEIGHBOURS or (p == "gh" and len(argv) > 2 and argv[1] in ("issue", "pr", "release", "gist")
                                     and argv[2] in ("create", "comment", "edit", "view", "list"))


def kind_words_quoted(cmd: str, prog_word: str, rest: list) -> bool:
    """The program, its command words and option names must appear in the text exactly as bash reads them (unquoted):
    the card reads them from the text."""
    raw = set(w.split("=", 1)[0] for w in cmd.split())
    words, lead = [prog_word], True
    for w in rest:
        if w.startswith("-"):
            words.append(w.split("=", 1)[0])   # every option name
            lead = False
        elif lead and len(words) < 6 and re.fullmatch(r"\+?[A-Za-z][\w.-]*", w):
            words.append(w)                    # the command words before any value with a blank or an option
        else:
            lead = False
    return any(w not in raw for w in words)


def google_verdict(tool_name: str, args: Any) -> Optional[Tuple[str, str, bool]]:
    """What a shell or code step does with Google's command-line tools (1.20.4, fail closed):
    None: no Google program runs in it (at most its name inside a title, or a file a plain reader reads);
    ("read", "", False): one plain call that only reads; ("card", kind, reusable): one plain call that changes
    something (a send is filed as a send and refused like every shell send); ("refuse", "", False): anything else that
    names a Google program (code, wrappers, loops, VAR= prefixes, $(...), redirections first, several Google calls, or a
    Google call next to another protected action)."""
    tool, a = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
    if tool not in ("terminal", "execute_code", "process", "process_manage"):
        return None
    raw = " ".join(str(a.get(k) or "") for k in ("command", "code", "input", "data"))
    if not _mentions_google(raw):
        return None
    cmd = str(a.get("command") or a.get("input") or "")
    if a.get("code") or tool in ("execute_code", "process", "process_manage") or a.get("data") or not cmd \
            or not _plain_shell(cmd):          # text sent to a running process is not one plain command (HIGH 6)
        return "refuse", "", False             # code, or shell text that readers could read differently (r1205)
    segs = _segments(cmd, posix=True)          # bash, on Mac and Windows alike
    if not segs:
        return "refuse", "", False
    calls, others, named_text, has_mod, has_runner, written = [], [], False, False, False, []
    for argv, _sep in segs:
        if not argv:
            continue
        parts = [x for w in argv for x in re.split(r"[^\w.+/-]+", _unq(w)) if x]   # also inside one quoted word, any separator
        runner = any(_is_python(x) or _prog_name(x) in _MOD_RUNNERS or x.startswith("-m") for x in parts)
        names = any(_names_google(w) for w in argv) or (runner and any(_GMODNAME.search(x) for x in parts))
        p = _prog_name(argv[0])     # python -m google_api / gws_bridge, import ...: refused below (run the script)
        has_mod = has_mod or any(_GMODONLY.search(x) for x in parts)
        is_call = p in ("gws", "workspace-cli") or _is_helper(argv[0]) or _is_bridge(argv[0]) or (
            _is_python(argv[0]) and len(argv) > 1 and (_is_helper(argv[1]) or _is_bridge(argv[1])))
        has_runner = has_runner or (not is_call and runner)
        if p in ("gws", "workspace-cli") or _is_helper(argv[0]) or _is_bridge(argv[0]):
            calls.append(("bridge" if _is_bridge(argv[0]) else p if p in ("gws", "workspace-cli") else "helper", argv[1:]))
            written.append(argv[0])
            continue
        if _is_python(argv[0]) and len(argv) > 1 and (_is_helper(argv[1]) or _is_bridge(argv[1])):
            calls.append(("bridge" if _is_bridge(argv[1]) else "helper", argv[2:]))
            written.append(argv[1])
            continue
        if names:
            ok_text = not _runs_program(argv) and (p in _READERS or (
                p == "gh" and len(argv) > 2 and argv[1] in ("issue", "pr", "release", "gist")
                and argv[2] in ("create", "comment", "edit", "view", "list")))
            if not ok_text:
                return "refuse", "", False     # a wrapper, an interpreter, a prefix, a loop ... naming a Google program
            named_text = True
        others.append(" ".join(argv))
    if has_mod and has_runner:
        return "refuse", "", False             # a module name and a Python runner anywhere in the step (Gemini HIGH 2)
    if has_mod and not calls and not all(not argv or _safe_neighbour(argv) or _plain_git(argv) for argv, _sep in segs):
        return "refuse", "", False             # a module name next to anything that could run it (Gemini b51e6a47 HIGH 4)
    if not calls:
        if named_text and any(argv and not _safe_neighbour(argv) for argv, _sep in segs):
            return "refuse", "", False         # a Google name in a reader's text, piped or passed on to a runner (r1205)
        return None
    if len(calls) > 1:
        return "refuse", "", False
    other = " ; ".join(others)
    if other and any(re.search(rx, other, re.I | re.M) for _k, rx in _CMD_RULES):
        return "refuse", "", False             # a Google step next to another protected action
    if kind_words_quoted(cmd, written[0], calls[0][1]):
        return "refuse", "", False             # quoted command words: the card reads them as written (b51e6a47 HIGH 5)
    base = re.split(r"[\\/]", written[0])[-1]
    if base != base.lower() and not re.fullmatch(r"\$\{?GAPI\}?", written[0].strip("\"'")):
        return "refuse", "", False             # GOOGLE_API.PY, GWS: the card reads the usual spelling (Gemini HIGH 6)
    prog, rest = calls[0]
    kind, reusable = (_gws_kind if prog in ("gws", "bridge") else _wcli_kind if prog == "workspace-cli" else _gapi_kind)(rest)
    reusable = reusable and prog != "bridge"   # the skill's bridge forwards anything: never a saved grant (r1205 final)
    if kind == "refuse":
        return "refuse", "", False
    if kind != "read" and re.search(r"[<>]", re.sub(r"'[^']*'|\"[^\"]*\"", "", cmd)):
        return "refuse", "", False             # a redirection glued to a word hides what the call gets (Gemini HIGH 5)
    for argv, _sep in segs:                    # around a Google call only plain commands that run nothing; around one
        if not argv or _prog_name(argv[0]) in ("gws", "workspace-cli") or _is_helper(argv[0]) or _is_bridge(argv[0]) \
                or (_is_python(argv[0]) and len(argv) > 1 and (_is_helper(argv[1]) or _is_bridge(argv[1]))):
            continue                           # that gets a card nothing at all: the card reads flags
        if kind == "read" and _prog_name(argv[0]) in _SAFE_NEIGHBOURS and not _runs_program(argv):   # from the
            continue                           # whole text (r1205 final pass 3); a read gets no card, gh posts are not reads
        return "refuse", "", False             # a card's Google call stands alone, not even a cd (Gemini HIGH 7)
    if kind == "read":
        return "read", "", False
    return "card", kind, reusable


def google_mixed(tool_name: str, args: Any, task_id: str = "") -> bool:
    try:
        v = google_verdict(tool_name, args)
    except Exception:
        return True
    return bool(v) and v[0] == "refuse"


def google_step(tool_name: str, args: Any) -> bool:
    """A card filed by the Google reader that is not one of the 1.20.3 table's own: one-time."""
    try:
        v = google_verdict(tool_name, args)
    except Exception:
        return True
    return bool(v) and (v[0] == "refuse" or (v[0] == "card" and not v[2]))


def _step_kinds(tool: str, a: Dict[str, Any], task_id: str = "") -> list:
    """Every protected kind a shell or code step does, the card's kind first. A step with a Google program call is
    filed from that call alone (its arguments are never read as other actions); every other step as in 1.20.3."""
    v = google_verdict(tool, a)
    if v:
        return [] if v[0] == "read" else [v[1] or "google.change"]
    text = str(a.get("command") or a.get("code") or a.get("input") or "")
    rules = _CODE_RULES if tool == "execute_code" else _CMD_RULES
    kinds = []
    for kind, rx in rules:
        if re.search(rx, text, re.I | re.M):
            if kind == "delete" and _deletes_only_gone(tool, a, task_id):
                continue   # what it would delete is not there: no card (17 Nov)
            if kind not in kinds:
                kinds.append(kind)
    return kinds


def mixed_step(tool_name: str, args: Any, task_id: str = "") -> bool:
    """A shell or code step that does more than one protected kind of thing (a calendar change and a post, a refund
    and a spreadsheet change, ...): its card is a one-time one, so no saved grant for one kind covers the other
    (verification 1.20.4 #4). Pre-1.20.4 the first kind's grant covered the whole step."""
    try:
        tool, a = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
        if tool not in ("terminal", "execute_code", "process", "process_manage"):
            return False
        return len(_step_kinds(tool, a, task_id)) > 1
    except Exception:
        return True


def _engine_cli_send(a: Dict[str, Any]) -> bool:
    """A shell or code step that names the engine's command (hermes, hermes_cli, qosha) and the word "send" anywhere,
    read with quotes, backslash-newlines and backslashes removed: treated as a send (refused in _unseen). No parsing of
    how it is written (verification vqa/allowc r6: quoting, flags, line breaks and argv lists all got past a shape
    check). A step that only mentions both words is refused too; that is accepted (orchestrator, 20 Nov 2026)."""
    raw = " ".join(str(a.get(k) or "") for k in ("command", "code", "input", "data"))
    # read two ways, either counts (verification vqa/b1202 r7): quotes and backslashes deleted (h"ermes" s\end is
    # hermes send to the shell), and the same replaced by a space (C:\bin\hermes.exe, r"hermes" keep their word)
    joined = re.sub(r"[\"'`\\]", "", raw.replace("\\\r\n", "").replace("\\\n", ""))
    spaced = re.sub(r"[\"'`\\]", " ", raw)
    return any(_ENGINE_WORD.search(t) for t in (joined, spaced)) and any("send" in t.lower() for t in (joined, spaced))


def _flag_args(text: str) -> Dict[str, str]:
    """--to X --subject "Y" ... from a command line (the Google skill's script); {} when it can't be read."""
    import shlex
    try:
        words = shlex.split(text)
    except ValueError:
        return {}
    out, i = {}, 0
    while i < len(words):
        w = words[i]
        if w.startswith("--") and len(w) > 2:
            if "=" in w:
                k, v = w[2:].split("=", 1)
                out[k] = v
            elif i + 1 < len(words) and not words[i + 1].startswith("--"):
                out[w[2:]] = words[i + 1]
                i += 1
            else:
                out[w[2:]] = "yes"
        i += 1
    return out


def _unwrap(tool: str, a: Dict[str, Any]):
    for _ in range(3):
        if tool != "tool_call":
            break
        inner = a.get("arguments")
        if isinstance(inner, str):
            try:
                inner = json.loads(inner)
            except Exception:
                inner = {}
        tool, a = str(a.get("name") or "").strip(), inner if isinstance(inner, dict) else {}
    return tool, a


def rows_for(kind: str, tool: str, args: Any, what: str, task_id: str = "") -> list:
    rows = _rows_for(kind, tool, args, what, task_id)
    t, a = _unwrap((tool or "").strip(), args if isinstance(args, dict) else {})
    if kind == "email.send" and (t.lower().startswith("mcp__google__") or t == "qosha_google_change"):
        # Gmail's send tool: its own rows, then every value it is given (from_name, body_format ...) (1.20.8 round 2)
        # the values the email rows already show, by their key (never by an equal value under another key)
        shown = {"to": "To", "cc": "Cc", "bcc": "Bcc", "subject": "Subject", "body": "Body", "thread_id": "In thread",
                 "in_reply_to": "Replying to message"}
        labels = {lab for lab, _v in rows}
        rows = rows + _arg_rows("Google tool", t, {k: v for k, v in a.items() if shown.get(k) not in labels})
    return rows


def _shown_value(v: Any) -> str:
    """An argument as the card shows it: text as is, unless it has a control character the card would lose (a carriage
    return, a tab ...): then written out with escapes, so two different values never look the same (1.20.8 round 3)."""
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False) if re.search(r"[\x00-\x09\x0b-\x1f\x7f\u2028\u2029]", v) else v
    return json.dumps(v, ensure_ascii=False, sort_keys=True, default=str)


def _arg_rows(label: str, tool: str, a: Dict[str, Any], skip: tuple = ()) -> list:
    out = [(label, tool.rsplit("__", 1)[-1].replace("_", " "))]
    for k, v in a.items():
        if k == "_qosha_account":
            continue                           # Qosha's own note for the card (the account row), not an argument
        val = _shown_value(v)
        if val in skip:
            continue                           # already on the card as it is
        out.append((str(k).replace("_", " ").capitalize(), _text(val, 10 ** 9)))
    return out


def _rows_for(kind: str, tool: str, args: Any, what: str, task_id: str = "") -> list:
    """What the person sees on the card, as labelled rows (like the cloud Decision card): [(label, value), ...].
    Plain words only (Ren, 17 Nov): never a command line, code, a flag or a script."""
    tool, a = _unwrap((tool or "").strip(), args if isinstance(args, dict) else {})
    cmd = str(a.get("command") or a.get("code") or "")
    f = _flag_args(cmd) if tool in ("terminal", "execute_code") else {}
    g = lambda *ks: next((str(v) for v in ((a.get(k) if a.get(k) not in (None, "", [], {}) else f.get(k)) for k in ks) if v not in (None, "")), "")
    rows = []
    # an email or message is shown in full (every recipient, every file, the whole body): what is sent is what the
    # person saw (Renato, 19 Nov 2026); a card the page cannot show in full is refused in pre_tool_call (CARD_SHOWS)
    cap = 10 ** 9 if kind in ("email.send", "message.send") else 1500
    add = lambda k, v: rows.append((k, _text(v, cap))) if v not in (None, "", [], {}) else None
    def google_args():
        out = _arg_rows("Google tool", tool, a)
        base = tool.lower().rsplit("__", 1)[-1]
        if base == "manage_drive_access" and str(a.get("action") or "").lower() in ("grant", "grant_batch") \
                and not any(re.sub(r"[^a-z]", "", str(k).lower()) == "sendnotification" for k in a):
            out.append(("Email", "Google emails the person about the share (the tool's default)"))
        return out
    if tool == "qosha_google_change":
        rows.append(("Google account", str(a.get("_qosha_account") or "") or "(not connected)"))
    if (tool.lower().startswith("mcp__google__") or tool == "qosha_google_change") and kind != "email.send":
        # a Google tool's card: the tool and every value it is given, in full (1.20.8; round 2: every kind)
        if kind == "calendar.change":
            ch = str(a.get("action") or "").lower()
            rows.append(("Change", {"create": "Add an event", "insert": "Add an event", "update": "Change an event",
                                    "patch": "Change an event", "delete": "Delete an event", "move": "Move an event",
                                    "rsvp": "Answer an invitation", "respond": "Answer an invitation"}.get(ch, "Change your calendar")))
        return rows + google_args()
    if kind == "browser.profile":
        return [("What happens", "Qosha's browser would use a copy of your own Chrome profile, where you are signed in "
                                 "to your accounts (Gmail, banks, everything). Websites would see it as you.")] + \
            _arg_rows("Step", tool, a)
    if kind in ("email.send", "message.send"):
        add("To", g("to", "target", "recipient", "recipients") or
            (g("channel", "channel_id", "channel_name", "conversation_id", "chat_id", "user_id", "space_id") if kind == "message.send" else ""))
        base = tool.lower().rsplit("__", 1)[-1]
        fwd = a.get("forward_message_id") or (a.get("message_id") if "forward" in tool.lower() else None)
        # Gmail's own send tool takes the forward path alone when it forwards: no thread, no reply, no reply all
        # (workspace_mcp send_gmail_message: "Threading, reply, and signature options do not apply when forwarding")
        gmail_fwd = kind == "email.send" and base == "send_gmail_message" and bool(fwd)
        engine_send = kind == "message.send" and _engine_send(tool, a)
        if engine_send:
            # the engine's own tool reads only `target` and `message` (gateway/outbound/send.py): the card shows those two
            # and nothing else the step carries (GPT allowc r1 #1: a `to` or `attachments` it does not use was shown)
            del rows[:]
            add("To", a.get("target") if isinstance(a.get("target"), str) else "")
            if isinstance(a.get("message"), str):
                add("Body", a["message"])
            elif a.get("message") is not None:
                rows.append(("Body", _NOT_TEXT))
            rows.extend(_chat_where(tool, a)[0])
            return rows
        if kind == "message.send":
            rows.extend(_chat_where(tool, a)[0])   # a thread, the whole channel, one person, an edit (Ren, 20 Nov)
        add("Cc", g("cc")); add("Bcc", g("bcc"))
        add("From", g("from", "from_email"))
        add("Subject", g("subject"))
        if tool in ("terminal", "execute_code", "process", "process_manage"):
            # a send from a command or code is refused in pre_tool_call (_unseen); no text is ever assumed for it
            add("Body", g("body", "message", "text", "html_body"))
        else:
            # every text the tool is given is shown, each under its own label (GPT/Gemini vqa/r11913e: html_body was
            # hidden when body was given too); text that is not plain text is marked and refused (_unseen)
            plain = 0
            for bk in _BODY_KEYS:
                bv = a.get(bk)
                if bv is None:
                    continue
                if not isinstance(bv, str):
                    rows.append(("Body", _NOT_TEXT))
                elif bv != "":
                    lab = "HTML body" if bk in ("html_body", "html", "body_html") else ("Body" if not plain else "Body (%s)" % bk)
                    plain += lab != "HTML body"
                    add(lab, bv)
            if kind == "message.send" and a.get("attachments") not in (None, "", [], {}):
                rows.append(("Body", _NOT_TEXT))   # legacy attachments: the card cannot show what the chat would show
            if kind == "message.send" and a.get("blocks") not in (None, "", [], {}):
                # blocks made only of text are shown as the chat would show them, in order; anything else (a button, an
                # image, a field list) is not text the card can show (Ren, 20 Nov: "ask me instead" where Qosha can show it)
                shown = _blocks_text(a.get("blocks"))
                if not shown or not shown.strip():
                    rows.append(("Body", _NOT_TEXT))
                else:
                    add("Body (as blocks)", shown)
                    if texts_given(a):
                        add("Note from Qosha", "The chat shows the blocks; the Body above is the text used in notifications "
                                               "and where blocks can't be shown.")
            texts = [lab for lab, _v in rows if lab.startswith("Body") or lab == "HTML body"]
            if kind == "email.send" and not texts and (any(lab in ("To", "Cc", "Bcc") for lab, _v in rows) or fwd or _truthy(a.get("reply_all"))):
                rows.append(("Body", NO_TEXT))   # no text given: an empty email (or a forward with no note), shown as such
            # what Gmail itself adds after the card (GPT vqa/r11913e rshw3 HIGH 1): said on the card
            adds = []
            if fwd:
                keep = str(a.get("include_forwarded_attachments")).strip().lower() not in ("false", "0", "no", "off")
                adds.append(("Forwards the original email and its attachments" if keep else
                             "Forwards the original email, without its attachments") + " (message %s)" % fwd)
            if gmail_fwd and (a.get("thread_id") or a.get("in_reply_to") or _truthy(a.get("reply_all")) or _truthy(a.get("quote_original"))):
                # what Gmail's send tool really does with a forward that also carries reply fields: the forward only
                left = [x for x in ("thread %s" % a.get("thread_id") if a.get("thread_id") else "",
                                    "reply to message %s" % a.get("in_reply_to") if a.get("in_reply_to") else "",
                                    "reply all" if _truthy(a.get("reply_all")) else "",
                                    "quote the original" if _truthy(a.get("quote_original")) else "") if x]
                adds.append("It goes as a new email that forwards message %s. Gmail's send tool does not use these reply "
                            "settings when it forwards: %s." % (fwd, ", ".join(left)))
            if _truthy(a.get("reply_all")) and not gmail_fwd:
                # no claim about who exactly (GPT vqa/r11913g r5 #2: which of the original To/Cc are kept depends on the
                # other fields); the addresses are not known here
                adds.append("Reply all: Gmail may also send it to the original email's Reply-To address and to other people "
                            "on the original email; they are not listed here.")
            if _truthy(a.get("quote_original")) and a.get("thread_id") and not gmail_fwd:
                adds.append("The email it answers is quoted below the text")
            if kind == "email.send" and base == "send_gmail_message" and not fwd and a.get("include_signature") is False:
                adds.append("Your Gmail signature is not added")
            add("Gmail adds", "\n".join(adds))
        # both, when both are given: the thread, and the message in it that this answers (GPT vqa/r11913f rshw4 HIGH 5)
        if not gmail_fwd and kind == "email.send":
            add("In thread", g("thread_id"))
        if not gmail_fwd:
            add("Replying to message", g("in_reply_to") or ("" if "forward" in tool.lower() else g("message_id")))
        add("Attachments", g("attachments", "attach"))
        if not rows:
            add("What happens", "Send %s (Qosha could not read who it goes to from this step)" % ("an email" if kind == "email.send" else "a message"))
    elif kind == "calendar.change":
        ch = (g("action") or (re.search(r"calendar\s+(?:events\s+)?\+?(\w+)", cmd) or [0, ""])[1]).lower()
        add("Change", {"create": "Add an event", "insert": "Add an event", "add": "Add an event", "quick_add": "Add an event",
                       "update": "Change an event", "patch": "Change an event", "move": "Move an event",
                       "delete": "Delete an event", "rsvp": "Answer an invitation", "respond": "Answer an invitation"}.get(ch, "Change your calendar"))
        add("Event", g("summary", "title", "event_id"))
        add("Answer", g("response", "rsvp"))
        add("When", " to ".join(x for x in (g("start", "start_time"), g("end", "end_time")) if x))
        add("Where", g("location"))
        add("Guests", g("attendees"))
        add("Calendar", g("calendar_id", "calendar"))
    elif kind in ("delete", "share", "pay"):
        steps, gone, notes = plain_acts(kind, tool, a, task_id)
        if not steps:
            steps = [_not_understood(kind, tool)]
        if len(steps) > 1:
            add("Steps", "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(steps[:12])))
        else:
            add("What happens", steps[0])
        add("Already gone", ", ".join(gone[:12]) + (" and %d more" % (len(gone) - 12) if len(gone) > 12 else ""))
        add("Note from Qosha", " ".join(notes))
    elif kind == "ai.paid":
        from .paid_ai import NOTE
        add("What happens", what)
        add("Note from Qosha", NOTE)
    elif kind in ("web.act", "web.post"):
        # plain words only (Ren, 17 Nov): the person never sees the browser code, a selector or a command
        site, steps, note, _final = web_plain(cmd or what, kind)
        add("Website", site)
        add("Note from Qosha", note)
        add("Steps" if len(steps) > 1 else "What happens", "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(steps)) if len(steps) > 1 else steps[0])
    if not rows:
        add("What happens", _not_understood(kind, tool))
    return rows   # the command or code itself is never added (Ren, 17 Nov)


# ---- delete / share / pay in plain words (Ren, 17 Nov: the card says what will happen; a command is never shown) ----
# Seen on Ren's Mac: a delete card showed `rm "/Users/.../Qosha-Setup.exe"`, a share card a long script. Each step is
# now read like the person would say it: what, which file or folder (by name) and where. What cannot be read is said
# so plainly ("Qosha could not ..."), and the person is still asked. Nothing here runs anything; files are only looked at.
_ZERO_DEC = {"bif", "clp", "djf", "gnf", "jpy", "kmf", "krw", "mga", "pyg", "rwf", "ugx", "vnd", "vuv", "xaf", "xof", "xpf"}
_ROLE = {"reader": "can view", "viewer": "can view", "commenter": "can comment", "writer": "can edit", "editor": "can edit",
         "fileorganizer": "can organize", "organizer": "can organize", "owner": "as the new owner"}
_KNOWN_DIRS = {"downloads": "in Downloads", "desktop": "on the Desktop", "documents": "in Documents", "pictures": "in Pictures",
               "movies": "in Movies", "videos": "in Videos", "music": "in Music", "onedrive": "in OneDrive"}
_SCRATCH = {"cache", "tmp", "temp", "scratch", "sandboxes", "audio_cache", "image_cache", "pending", "attachments", "composer-pastes"}
_DEL_CMDS = {"rm", "unlink", "del", "erase", "remove-item", "ri", "rd", "rmdir", "shred", "trash", "srm"}


def _homes() -> Tuple[str, str]:
    import os
    home = os.path.expanduser("~")
    try:
        from hermes_constants import get_hermes_home
        qh = str(get_hermes_home())
    except Exception:
        qh = os.environ.get("HERMES_HOME") or ""
    return home, qh


def _real(p: str) -> str:
    import os
    try:
        return os.path.normcase(os.path.realpath(p))
    except Exception:
        return os.path.normcase(os.path.abspath(p))


def _under(p: str, root: str) -> bool:
    import os
    if not root:
        return False
    rp, rr = _real(p), _real(root)
    return rp == rr or rp.startswith(rr.rstrip(os.sep) + os.sep)


_OWN_PHRASES = ("your files", "this project", "your home folder", "qosha's own folder", "qosha's scratch folder",
                "downloads", "desktop", "documents", "pictures", "movies", "videos", "music", "onedrive")


def _literal_name(folder: str) -> str:
    """A folder's own name; when it reads like one of Qosha's own phrases ("Your files" ...), in quotes with where it is,
    so the person can tell it from Qosha's own folder (r1210; pt-BR ptb8 H7-5)."""
    import os
    name = os.path.basename(folder.rstrip("/\\")) or folder
    if name.strip().lower() in _OWN_PHRASES:
        home, _qh = _homes()
        shown = folder.rstrip("/\\")
        if home and _under(shown, home):         # where it really is (a link is followed), from the home folder
            rel = os.path.relpath(os.path.realpath(shown), os.path.realpath(home))
            shown = "~" if rel == "." else "~" + os.sep + rel
        return '"%s" (%s)' % (name, shown)
    return name


def _label(folder: str) -> str:
    """A folder as the person knows it: "Downloads", "Your files", "your home folder", or its own name."""
    import os
    home, qh = _homes()
    if qh and _real(folder) == _real(os.path.join(qh, "files")):
        return "Your files"
    if _real(folder) == _real(home):
        return "your home folder"
    if _under(folder, home) and _real(os.path.dirname(folder.rstrip("/\\"))) == _real(home) and os.path.basename(folder.rstrip("/\\")).lower() in _KNOWN_DIRS:
        return os.path.basename(folder.rstrip("/\\"))
    return _literal_name(folder)


def _where(path: str) -> str:
    """Where a file or folder lies, in a few words: "in Downloads", "in Qosha's scratch folder", ..."""
    import os
    import tempfile
    parent = os.path.dirname(path.rstrip("/\\")) or path
    home, qh = _homes()
    if qh and _under(parent, qh):
        rel = os.path.relpath(_real(parent), _real(qh))
        top = rel.split(os.sep)[0].lower() if rel != "." else ""
        if top == "files":
            return "in Your files" if rel == "files" else "in the folder %s (in Your files)" % _literal_name(parent)
        return "in Qosha's scratch folder" if top in _SCRATCH else "in Qosha's own folder"
    if _under(parent, home):
        rel = os.path.relpath(_real(parent), _real(home))
        if rel == ".":
            return "in your home folder"
        parts = rel.split(os.sep)
        top = parts[0].lower()
        if top in _KNOWN_DIRS:
            return _KNOWN_DIRS[top] if len(parts) == 1 else "in the folder %s (%s)" % (_literal_name(parent), _KNOWN_DIRS[top])
        return "in the folder %s (in your home folder)" % _literal_name(parent)
    if any(_under(parent, t) for t in {tempfile.gettempdir(), "/tmp", "/var/tmp", "/private/tmp"}):
        return "in the computer's temporary folder"
    return ("in the folder %s" % _literal_name(parent)) if _literal_name(parent) else "at the top of the disk"


def _count_files(folder: str, cap: int = 5000) -> int:
    import os
    n = 0
    for _r, _d, fs in os.walk(folder):
        n += len(fs)
        if n > cap:
            break
    return n


def _expand(t: str, cwd: str) -> Tuple[Optional[str], str]:
    """(full path or None when it cannot be known before the step runs, why). Only the home and temp folder names are
    filled in; any other $NAME, %NAME% or `...` is only known when the step runs."""
    import os
    import tempfile
    home = os.path.expanduser("~")
    s = t
    s = re.sub(r"^~(?=$|[/\\])", lambda m: home, s)
    s = re.sub(r"\$\{?HOME\}?|%USERPROFILE%|\$env:(USERPROFILE|HOME)", lambda m: home, s, flags=re.I)
    s = re.sub(r"\$\{?TMPDIR\}?|%TEMP%|%TMP%|\$env:(TEMP|TMP)", lambda m: tempfile.gettempdir(), s, flags=re.I)
    if re.search(r"[$`]|%\w+%", s):
        return None, "unknown"
    if re.match(r"^[A-Za-z]:[\\/]", s) and os.name != "nt":
        return None, "windows"          # a Windows path seen on a Mac: its name is known, the file cannot be looked at
    if not os.path.isabs(s):
        if not cwd:
            return None, "relative"
        s = os.path.join(cwd, s)
    return os.path.normpath(s), ""


def _cwd(a: Dict[str, Any], task_id: str = "") -> str:
    """The folder a shell step runs in, as the engine picks it (its workdir, the session's folder, its setting)."""
    import os
    w = str(a.get("workdir") or a.get("cwd") or "")
    if w:
        p, _why = _expand(w, "")
        if p:
            return p
    try:
        from tools.terminal_tool import get_session_cwd, resolve_task_overrides
        for c in ((resolve_task_overrides(task_id) or {}).get("cwd") if task_id else None, get_session_cwd(task_id) if task_id else None):
            if c and os.path.isabs(str(c)):
                return str(c)
    except Exception:
        pass
    try:
        from hermes_cli.config import load_config
        c = str(((load_config() or {}).get("terminal") or {}).get("cwd") or "")
        if c and os.path.isabs(c) and os.path.isdir(c):
            return c
    except Exception:
        pass
    return ""


def _segments(cmd: str, posix: bool = False) -> Optional[list]:
    """The simple commands of a shell text, as word lists, in order (quotes respected). None if it cannot be read."""
    import os
    import shlex
    win = not posix and (os.name == "nt" or bool(re.search(r"(?<![\w$])[A-Za-z]:\\", cmd)))
    text, out_q, i = [], None, 0
    while i < len(cmd):            # line breaks outside quotes end a command, like ;
        c = cmd[i]
        if c == "\\" and not win and out_q != "'" and i + 1 < len(cmd):   # r1205 #6: literal inside '...'
            text.append(" " if cmd[i + 1] == "\n" else c + cmd[i + 1])
            i += 2
            continue
        if out_q:
            out_q = None if c == out_q else out_q
        elif c in "'\"":
            out_q = c
        elif c == "\n":
            c = " ; "
        elif c == "#" and (not text or text[-1] in (" ", "\t", ";", " ; ")):   # not after an escaped one (r1205)
            j = cmd.find("\n", i)       # a comment: to the end of the line
            i = len(cmd) if j < 0 else j
            continue
        text.append(c)
        i += 1
    try:
        lex = shlex.shlex("".join(text), posix=not win, punctuation_chars=";&|")
        lex.whitespace_split = True
        lex.commenters = ""
        toks = list(lex)
    except ValueError:
        return None
    if win:     # cmd and PowerShell join a word with a quoted part in the middle (C:/x/"Your files"): so do we (r1210 r2)
        merged, acc = [], None
        for t in toks:
            if acc is not None:
                acc += " " + t
                if t.count('"') % 2:
                    merged.append(acc)
                    acc = None
                continue
            if t.count('"') % 2 and not (set(t) <= set(";&|")):
                acc = t
                continue
            merged.append(t)
        if acc is not None:
            return None                      # a quote never closed: cannot be read
        toks = [x.replace('"', "") if '"' in x[1:-1] and not (x[0] == x[-1] == '"' and x.count('"') == 2) else x
                for x in merged]
    segs, cur = [], []
    for t in toks:
        if t and set(t) <= set(";&|"):
            if cur:
                segs.append((cur, t))
            cur = []
            continue
        if win and len(t) >= 2 and t[0] == t[-1] and t[0] in "'\"":
            t = t[1:-1]
        cur.append(t)
    if cur:
        segs.append((cur, ""))
    # the separator BEFORE each command matters for "xargs" (its names come from the command before the pipe)
    return [(w, (segs[k - 1][1] if k else "")) for k, (w, _sep) in enumerate(segs)]


def _strip_prefix(w: list) -> Tuple[list, bool]:
    """sudo / env / nohup / time / VAR=value in front of a command are not the command; xargs reads its names from the
    command before it."""
    xargs = False
    while w:
        h = w[0].lower()
        if h in ("sudo", "nohup", "time", "command", "exec", "builtin", "nice"):
            w = w[1:]
            while w and w[0].startswith("-"):
                w = w[1:]
        elif h == "env" or re.fullmatch(r"[A-Za-z_]\w*=.*", w[0]):
            w = w[1:]
            while w and (re.fullmatch(r"[A-Za-z_]\w*=.*", w[0]) or w[0].startswith("-")):
                w = w[1:]
        elif h == "xargs":
            xargs = True
            w = w[1:]
            while w and w[0].startswith("-"):
                w = w[1:]
        else:
            break
    return w, xargs


def _item(t: str, cwd: str) -> Dict[str, Any]:
    """One named target: its name, where it is, whether it is there (True/False/None = cannot tell) and a folder."""
    import ntpath
    import os
    p, why = _expand(t, cwd)
    if p is None:
        name = ntpath.basename(t.rstrip("/\\")) if why == "windows" else os.path.basename(t.rstrip("/\\"))
        where = ""
        if why == "windows":
            par = ntpath.basename(ntpath.dirname(t.rstrip("/\\")))
            where = "in the folder %s" % par if par else ""
        elif why == "relative":
            where = "in the folder Qosha is working in"
        return {"name": name, "where": where, "exists": None, "dir": None, "unknown": why == "unknown", "path": ""}
    there = os.path.lexists(p)
    return {"name": _literal_name(p) if p.rstrip("/\\") else p, "where": _where(p), "exists": there,
            "dir": os.path.isdir(p) if there else None, "unknown": False, "path": p}


def _thing_word(it: Dict[str, Any]) -> str:
    if it["dir"]:
        return "folder"
    if it["dir"] is False:
        return "file"
    return "file" if re.search(r"\.\w{1,8}$", it["name"]) else "item"


def _names(items: list, n: int = 6) -> str:
    names = [i["name"] for i in items]
    return ", ".join(names[:n]) + (" and %d more" % (len(names) - n) if len(names) > n else "")


def _delete_sentences(verb: str, items: list, recursive: bool) -> list:
    """Sentences for one delete command's targets (items that are there, or that cannot be checked)."""
    out = []
    files = [i for i in items if _thing_word(i) == "file"]
    same_where = len({i["where"] for i in items}) == 1
    if len(items) > 1 and len(files) == len(items) and same_where and verb in ("delete", "trash"):
        w = items[0]["where"]
        if verb == "trash":
            return ["Move %d files %s to the Trash: %s" % (len(items), w, _names(items))]
        return ["Delete %d files %s: %s" % (len(items), w, _names(items))]
    import os
    home, qh = _homes()
    for i in items:
        kindw, where = _thing_word(i), i["where"]
        if i["path"] and i["exists"]:
            special = ("everything on the computer's disk" if os.path.dirname(i["path"].rstrip("/\\") or i["path"]) == (i["path"].rstrip("/\\") or i["path"]) or _real(i["path"]) in ("/", _real("/")) else
                       "your whole home folder" if _real(i["path"]) == _real(home) else
                       "Qosha's whole home folder (its chats, settings and sign-ins)" if qh and _real(i["path"]) == _real(qh) else "")
            if special:
                out.append(("Move %s to the Trash" if verb == "trash" else "Delete %s") % special)
                continue
        par = " (%s)" % where if where else ""
        if verb == "trash":
            out.append("Move the %s %s%s to the Trash" % (kindw, i["name"], par))
        elif verb == "shred":
            out.append("Destroy the file %s%s so it cannot be recovered" % (i["name"], par))
        elif kindw == "folder" and verb == "rmdir":
            out.append("Delete the empty folder %s%s" % (i["name"], par))
        elif kindw == "folder" and (recursive or verb == "tree"):
            n = _count_files(i["path"]) if i["path"] and i["exists"] else -1
            size = "" if n < 0 else ("it is empty, " if n == 0 else ("more than 5000 files, " if n > 5000 else "%d file%s, " % (n, "" if n == 1 else "s")))
            out.append("Delete the folder %s and everything in it (%s%s)" % (i["name"], size, where) if where or size else
                       "Delete the folder %s and everything in it" % i["name"])
        else:
            out.append("Delete the %s %s%s" % (kindw, i["name"], par))
    return out


def _seg_delete(w: list, xargs: bool, cwd: str, trust: bool = True) -> Optional[Tuple[list, list, bool]]:
    """(sentences, names already gone, could not check something) for a delete command; None if it is not one.
    trust=False: an earlier part of the same step may create or move things, so "not there now" proves nothing: such
    names are asked about like any other."""
    import glob
    import os
    head = w[0].lower() if w else ""
    head = head[:-4] if head.endswith(".exe") else head
    if head not in _DEL_CMDS:
        return None
    win_style = head in ("del", "erase", "rd") or os.name == "nt"
    recursive, targets, value_next, after_dd = False, [], None, False
    verb = {"shred": "shred", "srm": "shred", "trash": "trash", "rmdir": "rmdir", "rd": "rmdir"}.get(head, "delete")
    for t in w[1:]:
        if re.fullmatch(r"\d*[<>]{1,2}&?", t):      # a redirection: the next word is where output goes, not a target
            value_next = "redirect"
            continue
        if re.match(r"\d*[<>]", t):
            continue
        if value_next:
            if value_next in ("-path", "-literalpath"):
                targets.append(t)
            value_next = None
            continue
        low = t.lower()
        if not after_dd and t == "--":
            after_dd = True
            continue
        if not after_dd and low in ("-path", "-literalpath", "-include", "-exclude", "-filter"):
            value_next = low
            continue
        if not after_dd and win_style and re.fullmatch(r"/[a-z]", low):
            recursive = recursive or low == "/s"
            continue
        if not after_dd and t.startswith("-") and len(t) > 1:
            # rm -r / -rf / -R / --recursive; PowerShell -Recurse (and its short forms). -Force is not recursive.
            if low in ("--recursive", "-recurse", "-recurs", "-recur", "-recu", "-rec") or (head in ("rm", "srm") and re.fullmatch(r"-[a-z]{1,4}", low) and "r" in low):
                recursive = True
            continue
        targets.append(t)
    if recursive and verb == "rmdir":
        verb = "tree"
    if xargs:
        return ["Delete files listed by an earlier part of the step (Qosha could not list them in advance)"], [], True
    items, gone, unknown = [], [], False
    for t in targets:
        if re.search(r"[*?\[]", t):
            p, why = _expand(t, cwd)
            if p is None:
                unknown = True
                continue
            hits = sorted(glob.glob(p))
            if not hits and trust:
                gone.append(os.path.basename(p))
            elif not hits:
                items.append({"name": os.path.basename(p), "where": _where(p), "exists": None, "dir": None, "unknown": False, "path": ""})
            items += [_item(h, "") for h in hits]
            continue
        it = _item(t, cwd)
        if it["unknown"]:
            unknown = True
        elif it["exists"] is False and trust:
            gone.append(it["name"])
        else:
            if it["exists"] is False:
                it.update(exists=None, dir=None, path="")
            items.append(it)
    out = _delete_sentences(verb if verb != "tree" else "delete", items, recursive or verb == "tree")
    if unknown:
        out.append("Delete something whose name is only known when the step runs (Qosha could not check it)")
    if not targets and not xargs:
        out.append("Delete something on this computer (Qosha could not tell what)")
        unknown = True
    cannot_check = unknown or any(i["exists"] is None for i in items)
    return out, gone, cannot_check


def _gapi(w: list) -> Optional[Tuple[str, list, Dict[str, str], list]]:
    """The Google skill's script: (service, action words, --flags, plain words after the action)."""
    for k, t in enumerate(w):
        if t.endswith("google_api.py") or t in ("$GAPI", "${GAPI}"):
            rest = w[k + 1:]
            if len(rest) < 2:
                return None
            flags = _flag_args(" ".join(_q(x) for x in rest))
            pos, skip = [], False
            for x in rest[2:]:
                if skip:
                    skip = False
                    continue
                if x.startswith("--"):
                    skip = "=" not in x
                    continue
                pos.append(x)
            return rest[0].lower(), [rest[1].lower()], flags, pos
    return None


def _q(s: str) -> str:
    import shlex
    return shlex.quote(s)


def _gh_thing(noun: str, arg: str, host: str) -> str:
    names = {"release": "the release %s", "gist": "the gist %s", "issue": "issue %s", "label": "the label %s",
             "secret": "the secret %s", "variable": "the setting %s", "run": "the workflow run %s", "cache": "the saved cache %s",
             "ssh-key": "the key %s", "gpg-key": "the key %s", "codespace": "the codespace %s", "project": "the project %s",
             "ruleset": "the rule set %s", "environment": "the environment %s", "snippet": "the snippet %s", "mr": "merge request %s",
             "deploy-key": "the key %s"}
    return (names.get(noun, "the " + noun.replace("-", " ") + " %s") % arg).strip() + " on " + host


def _money(amount: str, currency: str) -> str:
    cur = (currency or "").lower()
    try:
        n = int(str(amount).strip())
    except ValueError:
        return ""
    if cur in _ZERO_DEC:
        return "%d %s" % (n, cur.upper())
    v = "%d.%02d" % (n // 100, n % 100)
    return "%s %s" % (v, cur.upper()) if cur else "%s in the account's currency" % v


def _stripe(obj: str, data: Dict[str, str]) -> str:
    obj = obj.lower().replace("-", "_")
    amt = _money(data.get("amount", ""), data.get("currency", "")) if data.get("amount") else ""
    who = data.get("destination") or data.get("customer") or data.get("receipt_email") or ""
    if obj.startswith("transfer"):
        return ("Send %s to %s (Stripe)" % (amt, who) if who else "Send %s (Stripe)" % amt) if amt else "Send money through Stripe (Qosha could not tell the amount or who gets it)"
    if obj.startswith("refund"):
        return "Refund %s (Stripe)" % amt if amt else "Make a refund through Stripe (Qosha could not tell the amount)"
    if obj.startswith("payout"):
        return "Pay out %s to the bank account (Stripe)" % amt if amt else "Make a payout through Stripe (Qosha could not tell the amount or who gets it)"
    if obj.startswith("charge") or obj.startswith("payment_intent"):
        return ("Charge %s to %s (Stripe)" % (amt, who) if who else "Charge %s (Stripe)" % amt) if amt else "Take a payment through Stripe (Qosha could not tell the amount or from whom)"
    return "Make a payment through Stripe (Qosha could not tell the amount or who gets it)"


def _curl_parts(w: list) -> Tuple[str, Dict[str, str], str]:
    """(address, form fields, raw body) of a curl command."""
    url, data, raw, nxt = "", {}, "", None
    for t in w[1:]:
        if nxt:
            if nxt == "data":
                if t.lstrip().startswith("{"):
                    raw += t
                else:
                    for kv in t.split("&"):
                        if "=" in kv:
                            k, v = kv.split("=", 1)
                            data[k.strip()] = v.strip()
            nxt = None
            continue
        if t in ("-d", "--data", "--data-raw", "--data-urlencode", "--data-binary", "-F", "--form"):
            nxt = "data"
        elif t.startswith("-") and t in ("-u", "-H", "-X", "--user", "--header", "--request", "-o", "--output", "-A", "-e"):
            nxt = "skip"
        elif re.match(r"https?://", t) and not url:
            url = t
    return url, data, raw


def _paypal(raw: str) -> str:
    try:
        body = json.loads(raw)
    except Exception:
        body = None
    amt, who = "", ""

    def walk(x):
        nonlocal amt, who
        if isinstance(x, dict):
            if "value" in x and "currency_code" in x and not amt:
                amt = "%s %s" % (x["value"], str(x["currency_code"]).upper())
            for k in ("email_address", "receiver", "email"):
                if isinstance(x.get(k), str) and not who:
                    who = x[k]
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
    walk(body)
    if amt:
        return "Pay %s to %s (PayPal)" % (amt, who) if who else "Pay %s (PayPal)" % amt
    return "Make a payment through PayPal (Qosha could not tell the amount or who gets it)"


def _shell_acts(cmd: str, cwd: str, trust: bool = True) -> Tuple[list, list, bool, bool]:
    """(acts as (kind, sentence), names already gone, something could not be checked, every command is a delete or a
    change of folder) for a shell text. Commands that only read or prepare are left out: the card is about what acts."""
    import os
    segs = _segments(cmd, posix=_mentions_google(cmd))   # a Google step: the same bash reading as google_verdict
    if segs is None:
        return [], [], True, False
    acts, gone, unknown, only_del = [], [], False, trust
    for words, sep in segs:
        w, xargs = _strip_prefix(list(words))
        # (xargs: its names come from elsewhere; never checked)
        if not w:
            continue
        h = w[0].lower()
        if h in ("bash", "sh", "zsh") and len(w) >= 3 and w[1] == "-c":
            a2, g2, u2, o2 = _shell_acts(w[2], cwd, only_del)
            acts += a2
            gone += g2
            unknown = unknown or u2
            only_del = only_del and o2
            continue
        if h in ("cd", "pushd", "set-location", "sl", "chdir"):
            dest = next((x for x in w[1:] if not re.fullmatch(r"/d|-\w+", x, re.I)), "~")
            p, _why = _expand(dest, cwd)
            cwd = p if p else ""
            continue
        d = _seg_delete(w, xargs, cwd, trust=only_del)
        if d is not None:
            acts += [("delete", s) for s in d[0]]
            gone += d[1]
            unknown = unknown or d[2]
            continue
        only_del = False
        g = _gapi(w)
        if g:
            svc, (act,), fl, pos = g
            if svc == "drive" and act == "delete":
                acts.append(("delete", "Delete a file in your Google Drive for good" if "permanent" in fl else "Move a file in your Google Drive to its trash"))
            elif svc == "drive" and act == "upload":
                it = _item(pos[0], cwd) if pos else None
                where = (" (%s)" % it["where"]) if it and it["where"] else ""
                name = it["name"] if it else "a file"
                as_name = fl.get("name") if fl.get("name") and it and fl.get("name") != it["name"] else ""
                acts.append(("share", "Upload the file %s%s to your Google Drive%s" % (name, where, (" as %s" % as_name) if as_name else "") if it else "Upload a file to your Google Drive"))
            elif svc == "drive" and act == "share":
                typ = (fl.get("type") or "user").lower()
                who = {"anyone": "anyone who has the link", "domain": "everyone at %s" % fl.get("domain", "a domain")}.get(typ, fl.get("email") or "someone Qosha could not read")
                acts.append(("share", "Share a Google Drive file with %s (%s)" % (who, _ROLE.get((fl.get("role") or "reader").lower(), "access: " + fl.get("role", "")))))
            elif svc == "gmail" and act in ("send", "reply", "forward"):
                acts.append(("email.send", "Send an email%s%s" % ((" to " + fl["to"]) if fl.get("to") else "", (": “%s”" % _say(fl["subject"])) if fl.get("subject") else "")))
            elif svc == "calendar" and act in ("create", "update", "delete"):
                acts.append(("calendar.change", {"create": "Add the event", "update": "Change the event", "delete": "Delete an event"}[act] + ((" “%s”" % _say(fl["summary"])) if fl.get("summary") else "")))
            continue
        if h in ("gh", "glab") and len(w) >= 3:
            host = "GitHub" if h == "gh" else "GitLab"
            noun, verb = w[1].lower(), w[2].lower()
            fl = _flag_args(" ".join(_q(x) for x in w[3:]))
            pos = [x for x in w[3:] if not x.startswith("-")]
            arg = pos[0] if pos else ""
            title = fl.get("title") or fl.get("t") or ""
            if noun == "api":
                if re.search(r"(-X\s*|--method[\s=]+)DELETE\b", " ".join(w), re.I):
                    acts.append(("delete", "Delete something on %s (Qosha could not tell exactly what)" % host))
                continue
            if verb == "delete":
                if noun == "repo":
                    acts.append(("delete", ("Delete the %s repository %s and everything in it" % (host, arg)) if arg else "Delete this project's %s repository and everything in it" % host))
                else:
                    acts.append(("delete", "Delete " + _gh_thing(noun, arg, host)))
            elif noun in ("pr", "mr") and verb == "create":
                acts.append(("share", "Propose code changes on %s: “%s”" % (host, _say(title)) if title else "Propose code changes on %s (a pull request)" % host))
            elif noun == "issue" and verb == "create":
                acts.append(("share", "Post a new issue on %s: “%s”" % (host, _say(title)) if title else "Post a new issue on %s" % host))
            elif noun == "release" and verb == "create":
                acts.append(("share", "Publish the release %s on %s" % (arg, host) if arg else "Publish a release on %s" % host))
            elif noun == "repo" and verb == "create":
                vis = " (public: anyone can see it)" if "public" in fl else " (private)" if "private" in fl else ""
                acts.append(("share", ("Create the %s repository %s%s" % (host, arg, vis)) if arg else "Create a %s repository%s" % (host, vis)))
            elif noun == "gist" and verb == "create":
                acts.append(("share", "Publish a snippet on %s (%s)" % (host, "public: anyone can see it" if "public" in fl or "p" in fl else "anyone with the link can see it")))
            elif verb == "merge":
                acts.append(("share", "Merge the pull request %s on %s" % (arg, host) if arg else "Merge a pull request on %s" % host))
            elif verb == "comment":
                body = fl.get("body") or fl.get("b") or ""
                acts.append(("share", "Post a comment on %s: “%s”" % (host, _say(body)) if body else "Post a comment on %s" % host))
            elif verb == "edit":
                acts.append(("share", "Change %s %s on %s" % ({"pr": "the pull request", "issue": "issue", "release": "the release", "repo": "the repository settings of", "gist": "the gist"}.get(noun, "the " + noun), arg, host)))
            continue
        if h == "git":
            k, proj, gcwd = 1, _label(cwd) if cwd else "this project", cwd
            while k < len(w) and w[k].startswith("-"):
                o = w[k]
                if o.startswith("-C"):
                    d = o[2:] if len(o) > 2 else (w[k + 1] if k + 1 < len(w) else "")
                    p, _why = _expand(d, gcwd)          # each -C is taken from the previous one, as git does
                    proj = _label(p) if p else _literal_name(d)
                    gcwd = p if p else None
                    k += 1 if len(o) == 2 else 0
                elif o == "-c" or (o.startswith("--") and "=" not in o and o[2:] in (
                        "git-dir", "work-tree", "namespace", "super-prefix", "config-env", "attr-source")):
                    k += 1                              # its value is the next word, never the subcommand
                k += 1
            sub = w[k].lower() if k < len(w) else ""
            rest = w[k + 1:]
            if sub == "push":
                pos = [x for x in rest if not x.startswith("-")]
                dels = [x.lstrip("+:") for x in pos[1:] if x.lstrip("+").startswith(":")]
                if any(x in ("--delete", "-d") for x in rest):
                    dels += pos[1:]
                if dels:
                    acts.append(("delete", "Delete the branch%s %s from the online copy of %s" % ("es" if len(dels) > 1 else "", ", ".join(dels), proj)))
                else:
                    acts.append(("share", "Upload the saved code changes in %s to its online copy" % proj))
                    if any(x in ("--force", "-f", "--force-with-lease") or x.startswith("--force") or x.startswith("+") for x in rest):
                        acts.append(("note", "This replaces the online copy: changes there that are not on this computer will be lost."))
            elif sub == "clean":
                acts.append(("delete", "Delete the files in %s that are not part of its saved history" % proj))
            elif sub == "reset" and "--hard" in rest:
                acts.append(("delete", "Throw away the unsaved changes in %s (they cannot be brought back)" % proj))
            continue
        if h == "find" and "-delete" in w:
            roots = [x for x in w[1:] if not x.startswith("-") and not x.startswith("(")][:1] or ["."]
            p, _why = _expand(roots[0], cwd)
            acts.append(("delete", "Delete the files inside %s that a search picks (Qosha could not list them in advance)" % (_label(p) if p else _literal_name(roots[0]))))
            unknown = True
            continue
        if h == "npm" and len(w) > 1 and w[1] == "publish":
            acts.append(("share", "Publish this package on npm, where anyone can download it"))
            continue
        if h == "twine" and len(w) > 1 and w[1] == "upload":
            acts.append(("share", "Publish this package on PyPI, where anyone can download it"))
            continue
        if h == "stripe" and len(w) >= 3:
            fl = _flag_args(" ".join(_q(x) for x in w[3:]))
            acts.append(("pay", _stripe(w[1], fl)))
            continue
        if h == "curl" or h.startswith("invoke-"):
            url, data, raw = _curl_parts(w)
            m = re.match(r"https?://api\.stripe\.com/v\d+/([a-z_]+)", url)
            if m:
                acts.append(("pay", _stripe(m.group(1), data)))
            elif re.match(r"https?://api(-m)?\.(sandbox\.)?paypal\.com", url):
                acts.append(("pay", _paypal(raw)))
            continue
        if re.search(r"\b(drop\s+(table|database)|delete\s+from)\b", " ".join(w), re.I):
            db = next((os.path.basename(x) for x in w[1:] if re.search(r"\.(db|sqlite3?)$", x)), "")
            acts.append(("delete", "Delete data from the database %s" % db if db else "Delete data from a database (Qosha could not tell exactly which)"))
    return acts, gone, unknown, only_del


def _code_acts(code: str) -> Tuple[list, list, bool]:
    """Deletes in code the assistant runs: a name written in the code is looked at; anything else is said plainly."""
    acts, gone, unknown = [], [], False
    # "not there now" counts only when the code does nothing but delete (no line that could make or move a file first)
    trust = all(re.match(r"\s*($|#|import\s|from\s+\S+\s+import\s|(os\.(remove|unlink|rmdir|removedirs)|shutil\.rmtree|fs\.(rm|unlink|rmdir)(Sync)?|Path)\()", ln)
                for ln in code.split("\n"))
    lit = r"\s*(?:r|f)?(?P<q>['\"])(?P<name>[^'\"\n]+)(?P=q)\s*"
    found = False
    for m in re.finditer(r"\b(?P<fn>os\.(?:remove|unlink|rmdir|removedirs)|shutil\.rmtree|fs\.(?:rm|unlink|rmdir)(?:Sync)?)\((?:" + lit + r"[,)])?", code):
        found = True
        name = m.group("name")
        fn = m.group("fn")
        tree = fn == "shutil.rmtree" or fn in ("fs.rm", "fs.rmSync")
        if not name or "{" in name:
            unknown = True
            continue
        it = _item(name, "")
        if it["exists"] is False and trust:
            gone.append(it["name"])
            continue
        acts += [("delete", s) for s in _delete_sentences("delete", [it], tree)]
    for m in re.finditer(r"Path\(" + lit + r"\)\.(?P<m>unlink|rmdir)\(", code):
        found = True
        it = _item(m.group("name"), "")
        if it["exists"] is False and trust:
            gone.append(it["name"])
        else:
            acts += [("delete", s) for s in _delete_sentences("rmdir" if m.group("m") == "rmdir" else "delete", [it], False)]
    if re.search(r"\.unlink\(|\.rmdir\(\)", code) and not found:
        unknown = True
    if unknown or (not acts and not gone):
        acts.append(("delete", "Delete something on this computer whose name the code works out while it runs (Qosha could not check it)"))
        unknown = True
    return acts, gone, unknown


def _code_pay(code: str) -> list:
    m = re.search(r"stripe\.(Charge|PaymentIntent|Payout|Refund|Transfer)\.create\(([^)]*)\)", code)
    if m:
        data = {k: v for k, v in re.findall(r"(\w+)\s*=\s*['\"]?([\w.@-]+)", m.group(2))}
        return [("pay", _stripe({"PaymentIntent": "payment_intents"}.get(m.group(1), m.group(1).lower() + "s"), data))]
    if re.search(r"paypal\.com", code):
        return [("pay", "Make a payment through PayPal (Qosha could not tell the amount or who gets it)")]
    return [("pay", "Make a payment through Stripe (Qosha could not tell the amount or who gets it)")] if re.search(r"stripe", code, re.I) else []


def _service(tool: str) -> str:
    low = tool.lower()
    server = low.split("__")[1] if low.startswith("mcp__") and low.count("__") >= 2 else ""
    base = low.rsplit("__", 1)[-1]
    if server == "google" or re.search(r"drive|gmail|calendar|docs?_|sheet", base):
        for k, v in (("drive", "Google Drive"), ("gmail", "Gmail"), ("calendar", "Google Calendar"), ("doc", "Google Docs"),
                     ("sheet", "Google Sheets"), ("contact", "Google Contacts"), ("task", "Google Tasks"), ("form", "Google Forms"),
                     ("slide", "Google Slides")):
            if k in base:
                return v
        return "Google"
    return server.replace("_", " ").replace("-", " ").title() if server else ""


def _tool_acts(kind: str, tool: str, a: Dict[str, Any]) -> list:
    """Plain words for a connector's own tool (Google Drive, payment apps, ...), from its named arguments."""
    svc = _service(tool)
    base = tool.lower().rsplit("__", 1)[-1]
    get = lambda *ks: next((str(a[k]) for k in ks if a.get(k) not in (None, "", [], {})), "")
    in_svc = (" in %s" % svc) if svc else ""
    if kind == "share":
        act = get("action").lower()
        role = _ROLE.get(get("role").lower(), ("access: " + get("role")) if get("role") else "")
        typ = get("share_type", "type").lower()
        who = "anyone who has the link" if typ == "anyone" else ("everyone at %s" % get("share_with", "domain") if typ == "domain" else
                                                                 get("share_with", "email", "email_address", "user", "recipient"))
        if not who and isinstance(a.get("recipients"), list):
            who = ", ".join(str((r or {}).get("email") or (r or {}).get("email_address") or "") for r in a["recipients"] if isinstance(r, dict))
        what = ("the file %s" % get("file_name", "name", "title")) if get("file_name", "name", "title") else ("a %s file" % svc if svc else "a file")
        if act == "revoke":
            return ["Stop sharing %s with %s" % (what, who or "someone")]
        if act == "transfer_owner":
            return ["Make %s the owner of %s" % (get("new_owner_email") or who or "someone", what)]
        if act == "update":
            return ["Change what %s can do with %s%s" % (who or "someone", what, (" (%s)" % role) if role else "")]
        if re.search(r"upload|create", base):
            return ["Upload %s%s" % (("the file " + get("file_name", "name", "title")) if get("file_name", "name", "title") else "a file", (" to %s" % svc) if svc else "")]
        if who:
            return ["Share %s with %s%s" % (what, who, (" (%s)" % role) if role else "")]
        return ["Share or publish something%s (Qosha could not tell with whom)" % in_svc]
    if kind == "delete":
        name = get("file_name", "name", "title", "path", "summary", "subject")
        obj = re.sub(r"^(batch_)?(delete|remove|trash|destroy|purge|erase|manage)_?", "", base).replace("_", " ").strip() or "item"
        return [("Delete the %s %s%s" % (obj, name, in_svc)) if name else ("Delete a %s%s" % (obj, in_svc))]
    if kind == "pay":
        amt = get("amount", "total", "price", "value")
        who = get("to", "recipient", "payee", "email", "destination", "customer")
        cur = get("currency").upper()
        if amt:
            return ["Pay %s%s%s%s" % (amt, (" " + cur) if cur else "", (" to " + who) if who else "", (" (%s)" % svc) if svc else "")]
        return ["Make a payment%s (Qosha could not tell the amount or who gets it)" % ((" with " + svc) if svc else "")]
    return []


def plain_acts(kind: str, tool: str, a: Dict[str, Any], task_id: str = "") -> Tuple[list, list, list]:
    """(sentences, names already gone, notes) for a delete, share or pay card. The sentences cover every act of the
    step that would be asked about (a script that uploads and then shares shows both), in order."""
    import os
    if tool == "terminal":
        acts, gone, _u, _o = _shell_acts(str(a.get("command") or ""), _cwd(a, task_id))
    elif tool == "execute_code":
        code = str(a.get("code") or "")
        acts, gone = (_code_pay(code), []) if kind == "pay" else (_code_acts(code)[:2] if kind == "delete" else ([], []))
    elif tool == "patch":
        acts, gone = [], []
        cwd = _cwd(a, task_id)
        trust = not re.search(r"^\*\*\* (Add File|Move to):", str(a.get("patch") or ""), re.M)
        for m in re.finditer(r"^\*\*\* Delete File:\s*(.+?)\s*$", str(a.get("patch") or ""), re.M):
            it = _item(m.group(1), cwd)
            if it["exists"] is False and trust:
                gone.append(it["name"])
            else:
                acts += [("delete", s) for s in _delete_sentences("delete", [it], False)]
    else:
        acts, gone = [(kind, s) for s in _tool_acts(kind, tool, a)], []
    notes = [s for k, s in acts if k == "note"]
    steps = [s for k, s in acts if k in ("delete", "share", "pay", "email.send", "calendar.change")]
    return steps, gone, notes


def _not_understood(kind: str, tool: str) -> str:
    svc = _service(tool or "")
    return "Qosha could not put this step into plain words. It may %s%s." % (KIND_TEXT.get(kind, "act"), (" (in %s)" % svc) if svc else "")


def _deletes_only_gone(tool: str, a: Dict[str, Any], task_id: str = "") -> bool:
    """True when every thing the step would delete is checked and already gone (nothing else it does is asked)."""
    try:
        if tool == "terminal":
            acts, gone, unknown, _o = _shell_acts(str(a.get("command") or ""), _cwd(a, task_id))
            return bool(gone) and not unknown and not any(k == "delete" for k, _s in acts)
        if tool == "execute_code":
            acts, gone, unknown = _code_acts(str(a.get("code") or ""))
            return bool(gone) and not unknown and not acts
        if tool == "patch":
            steps, gone, _n = plain_acts("delete", "patch", a, task_id)
            return bool(gone) and not steps
    except Exception:
        return False
    return False


def _gone_only_names(a: Dict[str, Any], task_id: str = "") -> list:
    """For a shell step that does nothing but delete (and change folder), the names when ALL of them are already gone;
    [] otherwise (then the step runs or is asked as usual)."""
    acts, gone, unknown, only_del = _shell_acts(str(a.get("command") or ""), _cwd(a, task_id))
    if gone and not unknown and only_del and not acts:
        return gone
    return []


# ---- website actions in plain words (Ren, 17 Nov: "say what will happen in plain words only; the code is never shown") ----
# The steps are worked out from the code itself, in the order they appear. A step that cannot be put in words is said
# so honestly; nothing is guessed. The model's own first "# comment" may be shown as a note when it is plain language,
# but it never replaces the steps: code that clicks shows "Click ..." whatever its comment says.
_URL = r"https?://[^\s'\"<>)\\]+"
_STR = r"(?:'((?:[^'\\]|\\.)*)'|\"((?:[^\"\\]|\\.)*)\")"
_WEB_TRIGGER = r"click|press|submit|keyboard|Input\.dispatch|send_keys|upload|setFileInputFiles|fetch\([^)]*method"


def _host(url: str) -> str:
    h = re.sub(r"^https?://", "", url or "", flags=re.I).split("/")[0].split("?")[0].split("#")[0].split("@")[-1].split(":")[0].lower()
    return h   # as written: www.example.com is shown as www.example.com


def _say(t: str, n: int = 60) -> str:
    """A piece of page text as the person would read it: one line, no code characters left over, cut short."""
    t = re.sub(r"\\[nrt]", " ", t or "")
    t = re.sub(r"\\(.)", r"\1", t)
    t = re.sub(r"\s+", " ", t).strip(" '\"`")
    return t if len(t) <= n else t[: n - 1].rstrip() + "…"


def _thing(sel: str, default: str = "something on the page") -> str:
    """What a selector points at, in a word or two. Never the selector itself."""
    low = (sel or "").lower()
    if re.search(r"type\s*=\s*[\"']?submit|\[type=submit\]", low):
        return "the form's send button"
    if re.search(r"type\s*=\s*[\"']?password|password|passwd", low):
        return "the password box"
    if re.search(r"type\s*=\s*[\"']?email|e-?mail", low):
        return "the email box"
    if re.search(r"search|name\s*=\s*[\"']?q\b|\[name=q\]|#q\b", low):
        return "the search box"
    if re.search(r"type\s*=\s*[\"']?checkbox", low):
        return "a tick box"
    if re.search(r"type\s*=\s*[\"']?file", low):
        return "a file field"
    if re.search(r"user(name)?|login", low) and re.search(r"input|#|\[", low):
        return "the user name box"
    if re.search(r"(^|[\s>,(])textarea\b|comment|message", low):
        return "the message box"
    if re.search(r"(^|[\s>,(])select\b", low):
        return "a list of choices"
    if re.search(r"(^|[\s>,(])(button)\b|\.btn\b|role\s*=\s*[\"']?button", low):
        return "a button"
    if re.search(r"(^|[\s>,(])a(\b|\[|\.|#|:)|href", low):
        return "a link"
    if re.search(r"(^|[\s>,(])input\b", low):
        return "a box on the page"
    if re.search(r"(^|[\s>,(])form\b", low):
        return "a form"
    return default


def _plain_note(code: str) -> str:
    """The code's own first comment, only when it reads as ordinary language (letters and plain punctuation)."""
    m = re.match(r"\s*#\s*(.+)", code or "")
    if not m:
        return ""
    t = m.group(1).strip()
    if not (8 <= len(t) <= 140) or re.search(r"[(){}\[\]=;<>`$\\|_]|https?:|\.\w+\(|querySelector|\bjs\b", t) or len(t.split()) < 2:
        return ""
    # a note that plays the action down ("just read", "only look") is not shown next to steps that act: the steps
    # alone speak. It must itself name an action to be shown.
    if re.search(r"\b(just|only|merely|simply|read|reads|reading|look|looks|check|checks|view|views|see|nothing|harmless|safe)\b", t, re.I):
        return ""
    if not re.search(r"\b(click|press|type|fill|enter|send|submit|sign|log ?in|upload|choose|select|pick|tick|buy|order|book|post|open)", t, re.I):
        return ""
    return t


# "Only before final actions" (Ren, 17 Nov ~13:10): opening pages, reading, clicking links, typing and moving about
# never ask. A card comes only before a final step: sending or submitting a form, posting, buying or paying, deleting,
# confirming, signing in or up, uploading a file, accepting terms. When the code presses something and it cannot be
# told that it is NOT such a control, it counts as final (asked, in plain words).
_FINAL_WORDS = (
    r"send|submit|post|publish|share|buy|purchase|pay|order|check ?out|place|delete|remove|erase|confirm|sign ?in|log ?in|"
    r"sign ?up|register|create account|accept|agree|consent|save|subscribe|unsubscribe|book|reserve|donate|transfer|apply|"
    r"enviar|publicar|comprar|pagar|finalizar|pedir|excluir|apagar|remover|deletar|confirmar|entrar|acessar|cadastrar|"
    r"criar conta|aceitar|aceito|concordo|salvar|assinar|reservar|doar|transferir|"
    r"eliminar|borrar|quitar|iniciar sesi[oó]n|acceder|registrar|crear cuenta|aceptar|acepto|guardar|suscribir")
_SAFE_WORDS = (
    r"search|find|show|more|less|next|previous|prev|back|menu|open|close|expand|collapse|details|view|filter|sort|tab|"
    r"load|dismiss|cancel|skip|read|learn|about|help|home|"
    r"buscar|pesquisar|procurar|mostrar|ver|mais|menos|pr[oó]xim[oa]|anterior|voltar|abrir|fechar|detalhes|filtrar|ordenar|"
    r"cancelar|pular|ajuda|in[ií]cio|siguiente|volver|cerrar|detalles|ayuda")


def _is_final_word(text: str) -> bool:
    return bool(re.search(r"(?<![a-zà-ú])(%s)" % _FINAL_WORDS, (text or "").lower()))


def _is_safe_word(text: str) -> bool:
    return bool(re.search(r"(?<![a-zà-ú])(%s)" % _SAFE_WORDS, (text or "").lower())) and not _is_final_word(text)


def web_plain(code: str, kind: str = "web.act") -> Tuple[str, list, str, bool]:
    """(site, steps, note, final) for a website action: host only, short human steps in the code's order, an optional
    plain note, and whether any step is a final one (only then is the person asked)."""
    code = str(code or "")
    note = _plain_note(code)
    body = "\n".join(ln for ln in code.split("\n") if not ln.lstrip().startswith("#"))   # comments never count as actions
    urls = re.findall(_URL, body)
    site = _host(urls[0]) if urls else ""
    where = site or "the page that is open"
    found = []     # (position, end, sentence, final)
    covered = []   # more of the code that a step above already accounts for

    def hit(m, text, final=False):
        found.append((m.start(), m.end(), text, final))

    if kind == "web.post":
        verb = "Send data to"
        if re.search(r"\b(DELETE)\b|\.delete\(|-Method\s+Delete", body, re.I):
            verb = "Ask to delete something on"
        elif re.search(r"\b(PUT|PATCH)\b|\.(put|patch)\(|-Method\s+(Put|Patch)", body, re.I):
            verb = "Change data on"
        return site, ["%s %s" % (verb, where)], note, True
    for m in re.finditer(r"\b(new_tab|goto_url|goto|navigate|open_url)\(\s*" + _STR, body):
        u = m.group(2) or m.group(3) or ""
        h = _host(u)
        if h:
            path = re.sub(r"^https?://[^/]+", "", u).split("?")[0].split("#")[0].rstrip("/")
            hit(m, "Open %s%s" % (h, (" (the page %s)" % _say(path, 40)) if path else ""))
    boxes = []     # what was typed into, to judge a later Enter
    for m in re.finditer(r"\bfill_input\(\s*" + _STR + r"\s*,\s*" + _STR, body):
        sel, txt = m.group(1) or m.group(2) or "", m.group(3) or m.group(4) or ""
        box = _thing(sel, "a box on the page")
        boxes.append(box)
        if box == "the password box":
            hit(m, "Type a password into the password box")
        else:
            hit(m, "Type “%s” into %s" % (_say(txt), box) if txt.strip() else "Type into %s" % box)
    for m in re.finditer(r"\bfill_input\(\s*(?!['\"])[^)]*\)", body):
        boxes.append("a box on the page")
        hit(m, "Type into a box on the page")
    for m in re.finditer(r"\bclick_at_xy\([^)]*\)|Input\.dispatchMouseEvent", body):
        hit(m, "Click a spot on %s that Qosha could not identify" % where, True)
    for m in re.finditer(r"\.click\(\s*\)", body):
        stmt_start = max(body.rfind("\n", 0, m.start()), body.rfind("js(", 0, m.start()) - 1, 0)
        stmt = body[stmt_start:m.start()].replace("\\'", "'").replace('\\"', '"')   # quotes escaped inside the js("...") string read as plain quotes
        label = re.search(r"(?:textContent|innerText|ariaLabel|aria-label|title|value)[^'\"\n]{0,40}(?:includes\(|===?|==|indexOf\(|startsWith\(|contains\()\s*\\?" + _STR, stmt) \
            or re.search(r"(?:getByText|getByRole|:contains|has-text)\(?\s*\\?" + _STR, stmt) \
            or re.search(r"aria-label\s*[*^$]?=\s*\\?[\"']?([^\"'\]\\]{2,60})", stmt)
        sels = re.findall(r"querySelector(?:All)?\(\s*\\?" + _STR, stmt) or re.findall(r"getElementById\(\s*\\?" + _STR, stmt)
        sel = " ".join(x for pair in sels[-1:] for x in pair if x) if sels else ""
        what = _thing(sel)
        words = _say(next(g for g in label.groups() if g)) if label else ""
        link = what == "a link"
        if what == "the form's send button":
            text, final = ("Press the button “%s” (it sends the form)" % words if words else "Send the form"), True
        elif words and _is_final_word(words):
            text, final = "Press the %s “%s”" % ("link" if link else "button", words), True
        elif words and (link or _is_safe_word(words)):
            text, final = "Click the %s “%s”" % ("link" if link else "button", words), False
        elif words:
            text, final = "Press the button “%s”" % words, True          # a named control that is not known to be harmless
        elif link and not _is_final_word(sel):
            text, final = "Click a link", False
        elif _is_final_word(sel):
            text, final = "Press a button on %s (its name in the page suggests a final step)" % where, True
        else:
            text, final = "Press a button on %s that Qosha could not identify" % where, True
        found.append((m.start(), m.end(), text, final))
        covered.append((stmt_start, m.end()))   # the words that picked the element belong to this step
    for m in re.finditer(r"\.(?:requestSubmit|submit)\(\s*\)", body):
        hit(m, "Send the form", True)
    vals = list(re.finditer(r"\.value\s*=\s*(?!=)", body))
    if vals:
        pw = sum(1 for m in vals if re.search(r"passw", body[max(0, m.start() - 160):m.start()], re.I))
        text = "Fill %d field%s of a form" % (len(vals), "" if len(vals) == 1 else "s") + (" (one is a password)" if pw else "")
        found.append((vals[0].start(), vals[-1].end(), text, False))
        boxes.append("a form")
    for m in re.finditer(r"\.checked\s*=\s*(true|false|True|False)", body):
        near = body[max(0, m.start() - 200):m.start()]
        terms = bool(re.search(r"terms|agree|accept|consent|policy|termos|aceit|concord|t[eé]rminos|acept", near, re.I))
        hit(m, ("Tick the box that accepts the terms" if terms else "Tick a box") if m.group(1).lower() == "true" else "Untick a box", terms and m.group(1).lower() == "true")
    for m in re.finditer(r"\.selectedIndex\s*=|\.selected\s*=\s*true", body):
        hit(m, "Pick a choice from a list")
    for m in re.finditer(r"setFileInputFiles|\bupload\w*\(|input\[type=.?file", body, re.I):
        hit(m, "Upload a file", True)
    # Enter in a form sends it. The one exception is a plain search: the only thing typed into is a search box, so
    # Enter just shows results (moving about, like a link). Anything else typed, or nothing known: it is final.
    only_search = bool(boxes) and all(b == "the search box" for b in boxes)
    for m in re.finditer(r"(?:\bpress\(|\bsend_keys\(|key\s*[:=]\s*|code\s*[:=]\s*)\s*" + _STR, body):
        key = (m.group(1) or m.group(2) or "").strip()
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9+ ]{0,20}", key):
            continue
        key = {"Return": "Enter", "NumpadEnter": "Enter"}.get(key, key)
        if key == "Enter":
            hit(m, "Press Enter to search" if only_search else "Press Enter (it sends what was typed)", not only_search)
        else:
            hit(m, "Press the %s key" % key)
    for m in re.finditer(r"Input\.insertText|\.type\(\s*" + _STR + r"?|keyboard\.type", body):
        hit(m, "Type on the page")
    for m in re.finditer(r"fetch\([^)]{0,200}method\s*:\s*['\"](POST|PUT|PATCH|DELETE)['\"]", body, re.I | re.S):
        hit(m, "Send data to %s" % where, True)
    found.sort()
    steps, final = [], False
    # the website the card names (and "Always allow" is for) is the one the final step happens on: the page opened
    # last before it, not just the first address in the code
    opened = [(m.start(), _host(m.group(2) or m.group(3) or "")) for m in re.finditer(r"\b(new_tab|goto_url|goto|navigate|open_url)\(\s*" + _STR, body)]
    first_final = next((pos for pos, _e, _t, fin in found if fin), None)
    if first_final is not None:
        before = [h for pos, h in opened if pos < first_final and h]
        if before:
            site = before[-1]
    for _s, _e, t, fin in found:
        final = final or fin
        if not steps or steps[-1] != t:          # the same step twice in a row is said once
            steps.append(t)
    # anything that acts on the page and was not put in words above is said honestly, and counts as final
    rest = list(body)
    for s0, e0 in [(a0, b0) for a0, b0, _t, _f in found] + covered:
        for i in range(s0, min(e0, len(rest))):
            rest[i] = " "
    rest = "".join(rest)
    rest = re.sub(r"Input\.dispatchKeyEvent|keyboard", " ", rest) if any(t.startswith(("Press ", "Type on")) for t in steps) else rest
    if re.search(_WEB_TRIGGER, rest, re.I):
        final = True
        steps.append(("And something more on %s" if [t for t in steps if not t.startswith("Open ")] else "Do something on %s") % where
                     + " that Qosha could not describe in plain words")
    return site, steps[:12], note, final


def _asks_path():
    import os
    try:
        from hermes_constants import get_hermes_home
        home = str(get_hermes_home())
    except Exception:
        home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    d = os.path.join(home, "qosha")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "asks.json")


def _asks_edit(fn) -> list:
    """Read-modify-write of the small list of questions waiting in a chat (Home shows them)."""
    import os, time
    path = _asks_path()
    try:
        cur = json.loads(open(path, encoding="utf-8").read())
    except Exception:
        cur = []
    cur = [x for x in cur if isinstance(x, dict) and time.time() - float(x.get("at") or 0) < 3600]
    new = fn(cur)
    if new is not None and new != cur:
        tmp = path + ".tmp%d" % os.getpid()
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(new, fh)
        os.replace(tmp, path)
        cur = new
    return cur


def pending_asks() -> list:
    return _asks_edit(lambda cur: None)


_LAST: Dict[str, Dict[str, Any]] = {}   # message text -> what was asked (this process), for the approval hooks


def pre_approval_request(description: str = "", pattern_key: str = "", session_key: str = "", **_: Any) -> None:
    import time
    if not str(pattern_key).startswith("plugin_rule:qosha:"):
        return
    info = _LAST.get(description) or {}
    item = {"id": "ask-%d" % int(time.time() * 1000), "at": time.time(), "kind": str(pattern_key).split("qosha:", 1)[-1],
            "title": info.get("title") or description.split("\n", 1)[0], "rows": info.get("rows") or [],
            "session": info.get("session") or "", "session_key": session_key, "text": description}
    _asks_edit(lambda cur: [x for x in cur if not (x.get("session_key") == session_key and x.get("text") == description)] + [item])


def post_approval_response(description: str = "", pattern_key: str = "", session_key: str = "", **_: Any) -> None:
    if str(pattern_key) == "plugin_rule:" + _FRONT_RULE:
        try:
            if _browser_cfg().get("qosha_stay_behind") is True:
                _stay_behind_watch()
        except Exception:
            pass
        return
    if not str(pattern_key).startswith("plugin_rule:qosha:"):
        return
    try:
        from . import google_write
        google_write.consent(str(_.get("tool_call_id") or ""), _consented(_.get("choice")))   # Qosha's Google write tool
    except Exception:
        pass
    try:
        # the person allowed the step on Qosha's card: the engine's own check is not asked again for this same step
        call = str(_.get("tool_call_id") or "")
        keys = _CALL_GRANTS.get(call) or (_LAST.get(description) or {}).get("grant") or []
        if keys and _consented(_.get("choice")):
            from . import engine_ask
            if engine_ask.grant(list(keys), call, session_key) and call:
                _GRANT_WHY[call] = "now"
    except Exception:
        pass
    _asks_edit(lambda cur: [x for x in cur if not (x.get("session_key") == session_key and x.get("text") == description)])


def _consented(choice: Any) -> bool:
    try:
        from tools.approval import CONSENT_ANSWERS, canonical_approval_choice
        return canonical_approval_choice(choice) in CONSENT_ANSWERS
    except Exception:
        return str(choice or "").lower() in ("once", "session", "always")


# Website steps no longer use rule_for (see sends_to_web below); its website keys are kept only so older code reads.
WEB_KINDS = ("web.act", "web.post")

# No "Always allow" for a step that sends data to a website (Ren, 19 Nov 2026: "No 'Always allow' for websites"). Such a
# step, and any step that also does one (an email + a POST, a delete + a POST, a payment made with curl), gets "Allow
# this time" only: its rule key is new for every call, so no "always" answer from any screen can ever cover another
# step, and every grant saved before (a website, a www or bare form, "step-...", the old all-websites key) matches
# nothing. Any web client named anywhere in a shell step or code counts, so when unsure the step asks.
_WEB_SEND = re.compile(
    r"(?<![\w.-])(?:curl|wget2?|Invoke-WebRequest|Invoke-RestMethod|Start-BitsTransfer)\b"
    r"|(?:^|[;&|(\n`]|\$\()\s*(?:sudo\s+|env\s+|\w+=\S*\s+)*(?:iwr|irm|https?|xh|httpie|aria2c)\s"
    r"|\b(?:requests|httpx|urllib3|aiohttp|pycurl|httplib2)\s*\.\s*\w+\s*\(|\burllib\.request\b|\bhttp\.client\b"
    r"|\b(?:from|import)\s+(?:requests|httpx|urllib|urllib3|aiohttp|pycurl|httplib2|http\.client)\b"
    r"|\bfetch\s*\(|XMLHttpRequest|sendBeacon|\bWebSocket\b", re.I | re.M)


def sends_to_web(kind: str, tool: str, args: Any) -> bool:
    if kind in WEB_KINDS:
        return True
    tool, a = _unwrap((tool or "").strip(), args if isinstance(args, dict) else {})
    if tool.startswith("browser"):
        return True   # a browser step that asks acts on a website (an upload, a press, a final step)
    if tool not in ("terminal", "execute_code", "process", "process_manage"):
        return False
    return bool(_WEB_SEND.search(" ".join(str(a.get(k) or "") for k in ("command", "code", "input"))))


def _once(kind: str) -> str:
    import secrets
    return "qosha:%s:once-%s" % (kind, secrets.token_hex(8))


def rule_for(kind: str, rows: list, code: str) -> str:
    if kind not in WEB_KINDS:
        return "qosha:" + kind
    site = next((str(v) for lab, v in rows if lab == "Website"), "")
    if site and re.fullmatch(r"[a-z0-9.-]{1,253}", site):
        return "qosha:%s:%s" % (kind, site)
    import hashlib
    return "qosha:%s:step-%s" % (kind, hashlib.sha256(str(code).encode("utf-8")).hexdigest()[:16])   # the code itself: only the very same step


# ---- Qosha's own browser on a person's computer (Ren, 17 Nov 13:21 and 13:42) ------------------------------------
# * It runs in the Google Chrome already on the computer when there is one (a separate, empty profile inside Qosha's
#   home; never the person's everyday profile), else in the bundled browser. Looked for before every browser step, so
#   a Chrome installed later is picked up, and one that was removed is dropped.
# * Visible or in the background: `browser.headed` (Settings > Browser "Do it in the background").
# * In front (the default) or behind: `browser.qosha_stay_behind` (Settings > Browser, or by telling Qosha).
# The engine reads its browser settings once per run; when one of them changed, its kept values are dropped and its
# running browser is closed, so the very next step starts a browser as chosen. Nothing here may raise.
FRONT_TITLE = "Qosha is about to open its browser window"
_FRONT_RULE = "qosha:browser.window"


def chrome_path() -> str:
    """The installed Google Chrome's program on this computer, or "" when there is none."""
    import os
    import sys
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        places = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                  home + "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    elif os.name == "nt":
        places = [os.path.join(os.environ.get(v) or "", "Google", "Chrome", "Application", "chrome.exe")
                  for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA") if os.environ.get(v)]
    else:
        places = ["/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/opt/google/chrome/chrome"]
    return next((x for x in places if os.path.isfile(x)), "")


def _is_chrome_program(path: str) -> bool:
    low = (path or "").replace("\\", "/").lower()
    return low.endswith("/google chrome.app/contents/macos/google chrome") or low.endswith("/google/chrome/application/chrome.exe") \
        or low in ("/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/opt/google/chrome/chrome")


def _browser_cfg() -> dict:
    try:
        from hermes_cli.config import load_config
        return dict((load_config() or {}).get("browser") or {})
    except Exception:
        return {}


def _set_cfg(key: str, value: str) -> None:
    import contextlib
    import io
    from hermes_cli.config import set_config_value
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        set_config_value(key, value, force=True)


def _truthy(v) -> bool:
    return str(v).strip().lower() in ("true", "1", "yes", "on")


_SEEN = {"exe": None, "args": None}


def _browser_sync() -> dict:
    """Bring the engine in line with the settings before a browser step; returns the browser settings as they are now."""
    br = _browser_cfg()
    changed = False
    try:
        # which browser: the installed Chrome unless the person named another program themselves
        cur = str(br.get("executable_path") or "")
        if br.get("qosha_use_chrome", True) is not False and (cur == "" or _is_chrome_program(cur)):
            found = chrome_path()
            if cur != found:
                _set_cfg("browser.executable_path", found)
                br["executable_path"] = found
                changed = True
        # the installed Chrome keeps its passwords in the system's store; Qosha's empty profile must never ask for it
        # or touch it: its own profile uses a plain store of its own (these two flags only concern that profile)
        try:
            from tools import browser_session_cloud as cloud
            if bool(cloud.is_headed_mode()) != _truthy(br.get("headed")):
                changed = True
        except Exception:
            cloud = None
        exe = str(br.get("executable_path") or "")
        if _SEEN["exe"] is not None and _SEEN["exe"] != exe:
            changed = True
        _SEEN["exe"] = exe
        if changed and cloud is not None:
            cloud.reset_caches()
            try:
                from tools.browser_use_cli import stop_harness_daemons
                stop_harness_daemons()
            except Exception:
                pass
            try:
                from tools.browser_launcher import stop_all_browsers
                stop_all_browsers()
            except Exception:
                pass
    except Exception:
        pass
    return br


def _front_app() -> Tuple[str, int]:
    """macOS: (bundle path, process id) of the app in front, or ("", 0)."""
    import subprocess
    try:
        asn = subprocess.run(["lsappinfo", "front"], capture_output=True, text=True, timeout=3).stdout.strip()
        out = subprocess.run(["lsappinfo", "info", "-only", "bundlepath", "-only", "pid", asn], capture_output=True, text=True, timeout=3).stdout
        m = re.search(r'"LSBundlePath"="([^"]+)"', out)
        n = re.search(r'"pid"\s*=\s*(\d+)', out)
        return (m.group(1) if m else ""), (int(n.group(1)) if n else 0)
    except Exception:
        return "", 0


def _is_qoshas_browser(pid: int) -> bool:
    """True only for a browser Qosha started: its profile folder lies inside Qosha's own home. The person's own
    Chrome (same program, their profile) is never touched."""
    import subprocess
    if not pid:
        return False
    try:
        from hermes_constants import get_hermes_home
        home = str(get_hermes_home())
        cmd = subprocess.run(["ps", "-o", "command=", "-p", str(pid)], capture_output=True, text=True, timeout=3).stdout
        import os
        return ("--user-data-dir=" + home) in cmd or ("--user-data-dir=" + os.path.realpath(home)) in cmd
    except Exception:
        return False


def _stay_behind_watch(seconds: float = 25.0) -> None:
    """ "Stay behind": macOS always puts a newly started app in front and the engine starts the browser itself, so the
    window cannot be started behind. The nearest thing: for the next seconds, the moment Qosha's browser takes the
    front, the front is handed straight back to the app the person was in (a brief flash, then their window again)."""
    import sys
    import threading
    if sys.platform != "darwin":
        return   # Windows: the window is started minimized instead (see _window_args)
    was, _was_pid = _front_app()
    if not was:
        return

    def run():
        import subprocess
        import time
        end = time.time() + seconds
        gave = 0
        while time.time() < end and gave < 3:
            time.sleep(0.15)
            now, pid = _front_app()
            if now and pid != _was_pid and _is_qoshas_browser(pid):   # only Qosha's own browser, never the person's Chrome
                try:
                    subprocess.run(["open", "-a", was], capture_output=True, timeout=5)   # brings the person's app back; starts nothing new
                    gave += 1
                except Exception:
                    return
    threading.Thread(target=run, name="qosha-browser-behind", daemon=True).start()


def _window_args(br: dict) -> None:
    """Keep the browser flags in line with the choices: Qosha's own empty profile never uses the system's password
    store; on Windows "stay behind" starts the window minimized."""
    import os
    try:
        args = [str(x) for x in (br.get("chromium_args") or [])]
        want = list(args)
        for flag in ("--mute-audio", "--disable-audio-output"):
            if flag not in want:
                want.append(flag)
        chrome = _is_chrome_program(str(br.get("executable_path") or ""))
        for flag in ("--password-store=basic", "--use-mock-keychain"):
            if chrome and flag not in want:
                want.append(flag)
            if not chrome and flag in want:
                want.remove(flag)   # the bundled browser gets them from the engine itself
        mini = os.name == "nt" and _truthy(br.get("headed")) and br.get("qosha_stay_behind") is True
        if mini and "--start-minimized" not in want:
            want.append("--start-minimized")
        if not mini and "--start-minimized" in want:
            want.remove("--start-minimized")
        if want != args:
            from hermes_cli.config import load_config, save_config
            cfg = load_config()
            cfg.setdefault("browser", {})["chromium_args"] = want
            save_config(cfg)
            br["chromium_args"] = want
    except Exception:
        pass


def _before_browser_step(final: bool) -> Optional[Dict[str, str]]:
    """Settings in line before a browser step; when the person chose "stay behind", the front is handed back to them."""
    br = _browser_sync()
    _window_args(br)
    if not _truthy(br.get("headed")):
        return None
    # Ren, 17 Nov 15:36: the window comes to the FRONT by default and nobody is asked; a person it bothers switches
    # "Keep the browser window behind my other windows" on in Settings > Browser, or tells Qosha in the chat.
    if br.get("qosha_stay_behind") is True:
        _stay_behind_watch()
    return None


GUARD_FORMAT = 20261122      # the startup barrier uses a fallback copy of this file only from this version on (r1210)
ISSUED: Dict[str, bool] = {}               # rule keys Qosha itself gave (r1210 r2, Gemini 1)
VERDICTS: Dict[str, Tuple[str, Any]] = {}   # tool call -> (arguments' key, answer), read once by the startup barrier


def pre_tool_call(tool_name: str = "", args: Any = None, session_id: str = "", task_id: str = "", tool_call_id: str = "",
                  **kw: Any) -> Optional[Dict[str, str]]:
    """Qosha's answer for a step; recorded per tool call so the startup barrier can check it against the arguments that
    actually run (r1210, group 4)."""
    import copy
    import hashlib
    snap = copy.deepcopy(args)         # one private copy is hashed, and judged (r1210 r2, GPT 2) ...
    judged = copy.deepcopy(snap)
    try:                               # ... in the form the tool will get it (the engine's own coercion; GPT 1)
        from tools.arg_coercion import coerce_tool_args
        judged = coerce_tool_args(tool_name, judged) if isinstance(judged, dict) else judged
    except Exception:
        pass
    r = _pre_tool_call(tool_name, judged, session_id=session_id, task_id=task_id, tool_call_id=tool_call_id, **kw)
    try:
        key = hashlib.sha256(json.dumps([tool_name or "", snap if isinstance(snap, dict) else {}], sort_keys=True,
                                        default=str).encode()).hexdigest()
        # by tool call, or by the arguments when the engine gives no id (code-execution calls; GPT 4)
        VERDICTS[str(tool_call_id) if tool_call_id else "args:" + key] = (key, r)
        while len(VERDICTS) > 500:
            VERDICTS.pop(next(iter(VERDICTS)))
        if isinstance(r, dict) and r.get("rule_key"):
            ISSUED[str(r["rule_key"])] = True    # Qosha's own rule keys, so the barrier can tell them from a copy
            while len(ISSUED) > 500:
                ISSUED.pop(next(iter(ISSUED)))
    except Exception:
        pass
    return r


def _pre_tool_call(tool_name: str = "", args: Any = None, session_id: str = "", task_id: str = "", tool_call_id: str = "",
                   **_: Any) -> Optional[Dict[str, str]]:
    try:
        from . import engine_ask
    except Exception:
        engine_ask = None
    if engine_ask is not None:
        engine_ask.revoke(keep_call=tool_call_id)   # a grant given for an earlier step ends when the next one starts
    is_browser = "browser" in str(tool_name) or (tool_name == "tool_call" and "browser" in str((args or {}).get("name") if isinstance(args, dict) else ""))
    try:
        k = kind_of(tool_name, args, task_id)
    except Exception:
        return {"action": "approve", "rule_key": _once("unclear"),
                "message": "Qosha could not tell what this step does. Allow it?\n"
                           "(\"Always allow\" is not offered for this step: Qosha could not tell what it does.)"}
    try:
        profile = _turns_on_real_profile(tool_name, args)
    except Exception:
        profile = True
    if profile:
        if k:
            return {"action": "block", "message": "Not run: this step turns on Qosha's browser use of your own Chrome "
                    "profile and also does something else. Run the setting change on its own; Qosha will then ask."}
        k = ("browser.profile", _text(args))
    # Qosha's approval code and approval settings (the paid-AI switches among them): asked every time, never "Always
    # allow" (Ren, card 21 Nov 2026 ~21:55 MST, "Yes, both"; qosha_guard/selfguard.py, paid_ai.py)
    sg = None
    try:
        from . import selfguard as sg
        guarded = sg.check(tool_name, args)
    except Exception:
        guarded = "Qosha could not check whether this step changes its approval code or settings."
    if guarded and k and k[0] == "browser.profile" and sg is not None:
        try:               # that setting's own one-time card shows this change, when nothing else is touched
            if sg.only_config_file(tool_name, args):
                guarded = None
        except Exception:
            pass
    if guarded:
        if k:      # a step already known as another kind: refused, so that kind's own refusals are never skipped
            return {"action": "block", "message": getattr(sg, "MIXED", "Not run: Qosha could not check this step. "
                                                          "Do it as separate steps.")}
        text = sg.card(guarded) if sg else ("Qosha wants to do a step it could not check\nWhat happens: %s\n"
                                            "(\"Always allow\" is not offered for this step.)" % guarded)
        return {"action": "approve", "rule_key": _once("approval.self"), "message": text}
    if k:
        try:
            if google_mixed(tool_name, args, task_id):
                return {"action": "block", "message": GOOGLE_MIXED}
        except Exception:
            return {"action": "block", "message": GOOGLE_MIXED}
    if not k and tool_name == "terminal":
        # a shell step that ONLY deletes things that are already gone: no card, and nothing runs (the engine would
        # otherwise put its own question about a recursive delete); Qosha is told plainly and carries on
        try:
            gone = _gone_only_names(args if isinstance(args, dict) else {}, task_id)
        except Exception:
            gone = []
        if gone:
            return {"action": "block", "message": "Nothing to delete: %s %s already gone, so this step was skipped and "
                    "nothing ran. Carry on without it." % (", ".join(gone[:8]) + (" and more" if len(gone) > 8 else ""),
                                                           "is" if len(gone) == 1 else "are")}
    if is_browser:
        try:
            ask_window = _before_browser_step(bool(k))
        except Exception:
            ask_window = None
        if ask_window and not k:
            return ask_window
    # what the engine's own safety check would ask about for this same shell command (17 Nov 16:41, Ren's Mac: after
    # "Allow this time" on Qosha's card a second, technical card "delete in root path" came up). Qosha's one card
    # says it too, in plain words, and the engine's check is then not asked again for this step.
    eng, risks = [], []
    if engine_ask is not None and tool_name == "terminal" and isinstance(args, dict):
        eng = engine_ask.findings(str(args.get("command") or ""), bool(args.get("background"))) or []   # what it would ask
        if eng or k:
            risks = engine_ask.all_risks(str(args.get("command") or ""), bool(args.get("background")))  # what the card says
        for ek, ed in eng:
            if ek not in [r[0] for r in risks]:
                risks.append((ek, ed))
    gw_account = None
    if not k and not eng:
        return None
    if k:
        kind, what = k
        # a Google Chat edit is its own kind (Ren, 20 Nov, card: "Separate"): Always allow for sends never covers edits
        shown = "message.edit" if kind == "message.send" and _gchat_edit(tool_name, args) else kind
        title = "Qosha wants to %s" % KIND_TEXT.get(shown, shown)
        if _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})[0] == "qosha_google_change":
            from . import google_write
            gw_account = google_write.account(google_write._home())     # one lookup for the card and the approval
            if not gw_account:
                return {"action": "block", "message": "Not done: connect Google in Qosha first (Settings → Connections), "
                        "then ask again."}
        try:
            if gw_account:
                # unwrapped once: the real tool and its own arguments, plus the account (Gemini verification HIGH 1)
                u_tool, u_args = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
                rows = rows_for(kind, u_tool, dict(u_args, _qosha_account=gw_account), what, task_id)
            else:
                rows = rows_for(kind, tool_name, args, what, task_id)
        except Exception:
            if kind in ("email.send", "message.send"):
                # an email or message whose card can't be built is not sent (GPT allowc r1 #10, fail closed)
                return {"action": "block", "message": "Not sent: Qosha could not build the card for this %s, and Qosha only "
                        "sends what the person can see. Nothing was sent. Tell the person plainly, and offer to try again "
                        "with the recipients and text written out." % ("email" if kind == "email.send" else "message")}
            rows = [("What happens", _not_understood(kind, tool_name))]
        extra = [(ek, ed) for ek, ed in risks if engine_ask.plain(ed)[0] != kind]   # what Qosha's own kind does not cover
    else:
        kind, what, extra = "engine", "", []
        title = "Qosha wants to do a step that could be hard to undo"
        said = []
        for _ek, ed in risks:
            t = engine_ask.plain(ed)[1]
            if t not in said:
                said.append(t)
        rows = [("Steps", "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(said)))] if len(said) > 1 else [("What happens", said[0])]
    if extra:
        said = []
        for _ek, ed in extra:
            t = engine_ask.plain(ed)[1]
            if t not in said:
                said.append(t)
        rows.append(("Also", "\n".join(said)))
    # one labelled row per line; a value's own line breaks are indented so the card can tell them from a new row
    # a lone carriage return is a line break too (GPT vqa/rshw #4: "First\rSecond" must not show as "FirstSecond")
    lines = ["%s: %s" % (lab, re.sub(r"\r\n?", "\n", str(val)).replace("\n", "\n    ")) for lab, val in rows]
    try:
        web = sends_to_web(kind, tool_name, args)
    except Exception:
        web = True
    gmcp = _google_mcp(tool_name, args)   # every Google tool's card is for this one request only (1.20.8 round 2)
    if web:
        tail = '("Always allow" is not offered for this step: it sends data to a website.)'
    elif kind == "browser.profile":
        tail = '("Always allow" is not offered for this step: it gives Qosha\'s browser your signed-in accounts.)'
    elif gmcp:
        tail = '("Always allow" is not offered for this step: each Google change like this one is asked on its own.)'
    elif kind == "google.change" or google_step(tool_name, args):
        tail = '("Always allow" is not offered for this step: Qosha can\'t show exactly what it changes in your Google account.)'
    elif mixed_step(tool_name, args, task_id):
        tail = '("Always allow" is not offered for this step: it does more than one kind of thing.)'
    elif kind == "engine" or extra:
        tail = '("Always allow" covers this kind of step from now on.)'
    else:
        tail = '("Always allow" covers every future action of this kind: %s.)' % KIND_TEXT.get(shown, shown)
    if web or gmcp or kind in ("google.change", "browser.profile") or google_step(tool_name, args) or mixed_step(tool_name, args, task_id):
        rule = _once(kind)      # a Google change Qosha can't name exactly, or a step of several kinds: never covered later
    elif kind == "engine" or extra:
        # the person's "Always allow" is then for exactly these kinds of risk (and Qosha's own kind, if any)
        rule = "qosha:engine:" + "+".join(([kind] if kind != "engine" else []) + sorted({ek for ek, _ed in (extra or risks)}))
    else:
        rule = rule_for(shown, rows, what)
    message = "%s\n%s\n%s" % (title, "\n".join(lines), tail)
    if kind in ("email.send", "message.send"):
        # An email or message goes only as the person sees it on the card. These refusals come BEFORE any saved
        # approval is looked at: Always allow covers the kind of action, never an email the card cannot show
        # (GPT vqa/rshw #1, #3, #5).
        why = _unseen(tool_name, args, rows, message, kind)
        if why:
            return {"action": "block", "message": why}
    elif gmcp or kind == "browser.profile":
        why = _google_unseen(message)          # a Google card the page would cut or mask (1.20.8 round 2)
        if why:
            return {"action": "block", "message": why}
    grant_keys = [ek for ek, _ed in eng]
    _LAST[message] = {"title": title, "rows": [list(r) for r in rows], "session": session_id or "", "grant": grant_keys}
    if grant_keys and tool_call_id:
        _CALL_GRANTS[tool_call_id] = grant_keys
        for store in (_CALL_GRANTS, _GRANT_WHY):
            if len(store) > 200:
                for key in list(store)[:100]:
                    store.pop(key, None)
        if engine_ask.is_allowed(rule):
            # "Always allow" (or this session) was already chosen for this card: the engine lets it through without
            # asking, and its own check must not ask either
            if engine_ask.grant(grant_keys, tool_call_id):
                _GRANT_WHY[tool_call_id] = "always"
    if len(_LAST) > 200:
        for key in list(_LAST)[:100]:
            _LAST.pop(key, None)
    if gw_account is not None:
        from . import google_write
        # pending until the person's Allow (post_approval_response); bound to the account the card named
        google_write.pending(tool_call_id, _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})[1],
                             gw_account)
    return {"action": "approve", "rule_key": rule, "message": message}


CARD_SHOWS = 6000   # UTF-16 units of an approval the chat page shows (chat.html, function approval: whole.slice(0, 6000))


def _google_unseen(message: str) -> str:
    """Why a Google tool's card can't be approved as shown: too long for the page, or a value the page would mask."""
    no = ("Not done: %s, and Qosha only does in your Google account what the person can see. Nothing was changed. Tell "
          "the person plainly, and offer to %s.")
    try:
        shown = len(message.encode("utf-16-le")) // 2
        disp = _as_shown(message)
        if disp is None:
            return no % ("Qosha could not check how this card would look", "try again in a moment")
        shown = max(shown, len(disp.encode("utf-16-le")) // 2)
    except UnicodeError:
        return no % ("a value has a broken character the card cannot show", "write it again without that character")
    if shown > CARD_SHOWS:
        return no % ("this step is too long for Qosha's card to show in full (%d characters; the card shows %d)"
                     % (shown, CARD_SHOWS), "do it in smaller steps")
    masked = _secret_masked(message)
    if masked is None or masked:
        return no % ("a value would show masked on the card (it looks like a secret)", "do it without that value")
    return ""


def _unseen(tool_name: str, args: Any, rows: list, message: str, kind: str = "email.send") -> str:
    """Why this email or message cannot be sent as the card shows it: the refusal for the model, or "" when it can."""
    tool, _a = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
    what = "email" if kind == "email.send" else "message"
    if tool in ("terminal", "execute_code", "process", "process_manage"):
        # a command or code is never read for what it would send (orchestrator, 20 Nov 2026, fail closed: the shell
        # can add text, files and recipients in more ways than a card can show; GPT and Gemini vqa/r11913e). The send
        # tool shows the person its card, so approval is always there that way.
        how = ("Send it with the Gmail send tool instead (send_gmail_message, with the recipients, subject, text and "
               "any files written out); Qosha will show the Allow card." if what == "email" else
               "Send it with the messaging tool for that service instead (send_message, or that app's send tool), "
               "with where it goes and the text written out; Qosha will show the Allow card.")
        return ("Not sent: Qosha does not send %s from a terminal command or from code, because its card cannot show "
                "exactly what such a step would send. Nothing was sent. %s" % ("an email" if what == "email" else "a message", how))
    refuse = lambda why, offer: ("Not sent: %s, and Qosha only sends what the person can see. Nothing was sent. Tell "
                                 "the person plainly, and offer to %s." % (why, offer))
    try:
        shown = len(message.encode("utf-16-le")) // 2   # as the page counts it (JavaScript strings: an emoji is 2)
        # the page is handed the engine's display form, where a hidden character (zero-width, bidi) is written out
        # as \u200b and so is longer (GPT vqa/r11913f rshw4 HIGH 8): the longer of the two counts
        disp = _as_shown(message)
        if disp is None:
            # the engine's display form could not be made: the card's length can't be checked, so nothing is sent
            # (GPT vqa/r11913g r5 #4, fail closed)
            return refuse("Qosha could not check how this %s's card would look" % what, "try again in a moment")
        shown = max(shown, len(disp.encode("utf-16-le")) // 2)
    except UnicodeError:
        # a broken character (an unpaired surrogate): the card cannot show it reliably (GPT vqa/rshw #5)
        return refuse("this %s contains a broken character that Qosha's card cannot show reliably" % what,
                      "write it again without that character")
    if shown > CARD_SHOWS:
        return refuse("this %s is too long for Qosha's card to show in full (%d characters; the card shows %d)" % (what, shown, CARD_SHOWS),
                      "shorten it, split it into several messages, or put the long part in an attached file")
    masked = _secret_masked(message)
    if masked is None:
        return refuse("Qosha could not check this %s for secrets" % what, "try again in a moment")
    if masked:
        # the card would show the secret masked, so two different texts could look the same (verification vqa/allowc #2)
        return ("Not sent: this %s contains a secret; Qosha won't send secrets. Nothing was sent. Tell the person "
                "plainly, and offer to send it without the secret." % what)
    base = tool.lower().rsplit("__", 1)[-1]
    fwd0 = _a.get("forward_message_id") or (_a.get("message_id") if "forward" in tool.lower() else None)
    if kind == "email.send" and base == "send_gmail_message" and not fwd0 and _a.get("include_signature") is not False:
        # Gmail adds the saved signature unless told not to, and the card can't show it (verification vqa/allowc #3)
        return ("Not sent: Gmail would add the saved signature, which Qosha's card can't show. Nothing was sent. Send it "
                "again with include_signature set to false (put any sign-off in the text itself); Qosha will then show "
                "the Allow card.")
    if any(v == _NOT_TEXT for _lab, v in rows):
        return refuse("this %s's text is given in a form Qosha's card cannot show as it would arrive (not plain text)" % what,
                      "send it with the text written out as plain text")
    a = _a
    if kind == "message.send":
        # a thread, the whole channel or one person is shown on the card when its meaning is certain; otherwise the
        # message is refused with the reason (Ren, 20 Nov: "ask me instead"; GPT vqa/r11913g r5 #1)
        try:
            why = _chat_where(tool, a)[1]
        except Exception:
            why = "Qosha could not check where this message would go"
        if why:
            return refuse(why, "send it with plain values (a channel, the thread's message id, true or false), or post it "
                               "to the channel")
    fwd = a.get("forward_message_id") or (a.get("message_id") if "forward" in tool.lower() else None)
    if kind == "email.send" and fwd and (a.get("thread_id") or a.get("in_reply_to")):
        # a forward mixed with a reply stays refused, as on 1.19.13: the card can't show the forwarded email's own text
        # and files (GPT allowc r2 H9; GPT vqa/r11913g r5 #3)
        return refuse("this email mixes a forward with a reply; Gmail would send only the forward, and the card can't "
                      "show the forwarded email's own text and files", "send it either as a forward or as a reply")
    if kind == "message.send" and not (any(lab == "To" for lab, _v in rows) and any(lab.startswith("Body") for lab, _v in rows)):
        # a message is shown with where it goes and its text, or not sent (GPT vqa/r11913e rshw3 HIGH 5)
        return refuse("Qosha could not read where this message goes and its text from the step",
                      "send it with where it goes (the channel or person) and the text written out")
    return ""


def _secret_masked(message: str) -> Optional[bool]:
    """True when the engine's secret masking (as the card is shown: force=True) changes the card's text, None when it
    can't be checked (the send is then refused: fail closed)."""
    try:
        from agent.redact import redact_sensitive_text
        return str(redact_sensitive_text(message, force=True)) != message
    except Exception:
        return None


def _gchat_edit(tool_name: str, args: Any) -> bool:
    """A Google Chat step that edits a message already sent (message_name given)."""
    try:
        tool, a = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
        return tool != "send_message" and tool.lower().rsplit("__", 1)[-1] == "send_message" and _given(a.get("message_name"))
    except Exception:
        return False


def _as_shown(message: str) -> Optional[str]:
    """The card's text as the engine hands it to the page (gateway: redact_approval_display), or None when the engine's
    function is not there or fails (the send is then refused: fail closed)."""
    try:
        from agent.redact import redact_approval_display
        return str(redact_approval_display(message, force=True))
    except Exception:
        return None


def _engine_send(tool: str, a: Dict[str, Any]) -> bool:
    """The engine's own send_message tool (gateway/outbound/send.py), which reads only action, target and message. Known by
    its exact name (an MCP tool is always mcp__<server>__<tool>); its arguments never change which tool it is (GPT allowc r1 #2)."""
    return tool == "send_message"


_GCHAT_KEYS = {"user_google_email", "space_id", "message_text", "thread_key", "thread_name", "message_name"}


def _given(v: Any) -> bool:
    """A Google Chat optional value as the tool reads it (_none_if_blank): None, "null"/"None" or blank = not given."""
    return isinstance(v, str) and v.strip() != "" and v.strip().lower() not in ("null", "none")


def texts_given(a: Dict[str, Any]) -> bool:
    return any(isinstance(a.get(k), str) and a.get(k) != "" for k in _BODY_KEYS)


_TS = re.compile(r"[0-9]{1,12}(\.[0-9]{1,9})?")
_KEY = re.compile(r"[A-Za-z][A-Za-z0-9_]{0,39}")


def _chat_where(tool: str, a: Dict[str, Any]) -> Tuple[list, str]:
    """Where a chat message goes beyond its channel, as card rows (a thread, the whole channel too, one person, an edit),
    and why the card can't show it ("" when it can). Ren, 20 Nov 2026 ("Yes, ask me instead"): what Qosha can show
    exactly gets the Allow card; a value whose meaning is not certain is refused with the reason. What each value does:
    Google Chat = workspace_mcp gchat send_message; Slack = Slack's own Web API meanings (chat.postMessage thread_ts and
    reply_broadcast, chat.postEphemeral user); the engine's send_message reads only its target and message."""
    rows: list = []
    has = lambda k: a.get(k) not in (None, "", [], {})
    base = tool.lower().rsplit("__", 1)[-1]
    if _engine_send(tool, a):
        notes = []
        t = a.get("target")
        if isinstance(t, str) and t.strip() and not t.partition(":")[2].strip():
            # no channel given: the engine uses that app's home channel, and its home thread when one is set
            notes.append("It goes to your home channel on %s (and into its home thread, if one is set); this card can't "
                         "show which channel that is." % t.partition(":")[0].strip())
        unused = sorted(str(k) for k in a if k not in ("action", "target", "message") and a.get(k) not in (None, "", [], {}, False))
        if unused:
            named = [k for k in unused if _KEY.fullmatch(str(k))][:8]
            notes.append("This tool uses only the place and the text above; it does not use %s." %
                         (", ".join(named) + (" or other settings given" if len(named) < len(unused) else "") if named else "the other settings given"))
        if notes:
            rows.append(("Note from Qosha", " ".join(notes)))
        return rows, ""
    gchat_keys = any(k in a for k in ("space_id", "message_text", "thread_name", "thread_key", "message_name"))
    if base == "send_message" and gchat_keys:
        # Google Chat takes only its own fields; any other one could be shown on the card in place of the space or the
        # text and then be dropped by the tool (Gemini allowc r1 #5, r2 HIGH-1)
        if any(k not in _GCHAT_KEYS for k in a):
            return rows, "this Google Chat step carries fields Google Chat doesn't use, so Qosha can't show exactly where it would go"
        if not (isinstance(a.get("space_id"), str) and a["space_id"].strip() and isinstance(a.get("message_text"), str)
                and a["message_text"].strip()):
            return rows, "Qosha can't read this Google Chat step's space and text"
        # Google Chat: a thread by name or by key (a new thread when it isn't found), or an edit of a message already sent.
        # Each value is read the way the tool reads it (blank or "null" = not given), and shown in full (GPT allowc r1 #5, #6)
        for k in ("thread_name", "thread_key", "message_name"):
            if a.get(k) is not None and not isinstance(a.get(k), str):
                return rows, "Qosha can't read the Google Chat %s given (it is not plain text)" % k.replace("_", " ")
        mn = a.get("message_name")
        if isinstance(mn, str) and not mn.strip():
            # the tool reads a blank message_name as an edit id and fails it (Gemini allowc r2 M1)
            return rows, "this Google Chat step gives an empty message to edit"
        edit = _given(mn)
        if edit and (_given(a.get("thread_name")) or _given(a.get("thread_key"))):
            return rows, "this step both edits a Google Chat message and replies in a thread, which Google Chat does not do"
        if edit:
            rows.append(("Edits your message", "%s (its text is replaced by the Body below)" % a["message_name"]))
        if _given(a.get("thread_name")):
            rows.append(("In thread", "%s (if Google Chat can't find that thread, it starts a new thread)" % a["thread_name"]))
        elif _given(a.get("thread_key")):
            rows.append(("In thread", "the thread with key %s (Google Chat starts a new thread if none has this key)" % a["thread_key"]))
        return rows, ""
    if has("thread_id"):
        # which thread a chat tool's thread_id means is not known here; Slack's own field is thread_ts (GPT allowc r1 #7)
        return rows, "Qosha can't tell how this app reads thread_id, so it can't show where the reply would go"
    rb = a.get("reply_broadcast")
    if rb is not None and not isinstance(rb, bool):
        return rows, "Qosha can't tell whether this reply would also be posted to the whole channel (reply_broadcast is not true or false)"
    if rb is True and a.get("thread_ts") is None:
        return rows, "this message asks to be posted to the whole channel without a thread, which Qosha can't show exactly"
    if a.get("thread_ts") is not None:
        ts = a["thread_ts"]
        if not isinstance(ts, str) or not _TS.fullmatch(ts):
            return rows, "Qosha can't read which thread this reply goes to (thread_ts is not a message time stamp written as text)"
        rows.append(("In thread", "reply under message %s%s" % (ts, "" if rb is True else " (seen in the thread only)")))
        if rb is True:
            rows.append(("Also posted to the whole channel", "yes, the reply also shows in the channel"))
    if "ephemeral" in base:
        u = a.get("user")
        if not isinstance(u, str) or not u.strip() or u != u.strip() or a.get("user_id") not in (None, u):
            return rows, "Qosha can't tell who would see this message (a message only one person sees needs that person)"
        if rb is True:
            return rows, "this message is both for one person only and posted to the whole channel, which can't both be shown"
        rows.append(("Only seen by", "%s (nobody else in the channel sees it)" % u))
    elif has("user"):
        return rows, "Qosha can't tell whether 'user' makes this a direct message or a message only that person sees"
    return rows, ""


_TEXT_KEYS = {"plain_text": {"type", "text", "emoji"}, "mrkdwn": {"type", "text", "verbatim"}}
# no "style" (bold, strike...): the card can't show it (GPT allowc r1 #8)
_RICH_KEYS = {"text": ({"type", "text"}, "text"), "link": ({"type", "url", "text"}, "url"),
              "emoji": ({"type", "name", "unicode"}, "name"), "user": ({"type", "user_id"}, "user_id"),
              "channel": ({"type", "channel_id"}, "channel_id")}


def _blocks_text(blocks: Any) -> Optional[str]:
    """Slack blocks made only of text, as the chat would show them (one line per block, in order); None when any block
    is something else (a button, an image, a field list, @here...), which the card can't show."""
    try:
        if isinstance(blocks, str):
            blocks = json.loads(blocks)
        if not isinstance(blocks, list) or not blocks or len(blocks) > 50:
            return None

        def txt(o, kinds=("plain_text", "mrkdwn")):
            if isinstance(o, dict) and o.get("type") in kinds and isinstance(o.get("text"), str) and set(o) <= _TEXT_KEYS[o["type"]]:
                return o["text"]
            return None

        def rich(els):
            parts = []
            if not isinstance(els, list):
                return None
            for e in els:
                spec = _RICH_KEYS.get(e.get("type")) if isinstance(e, dict) else None
                if not spec or not set(e) <= spec[0] or not isinstance(e.get(spec[1]), str):
                    return None
                t = e["type"]
                if t == "text":
                    parts.append(e["text"])
                elif t == "link":
                    if e.get("text") is not None and not isinstance(e.get("text"), str):
                        return None   # Gemini allowc r2 M3
                    label = e.get("text") or ""
                    parts.append("%s (%s)" % (label, e["url"]) if label else e["url"])
                elif t == "emoji":
                    parts.append(":%s:" % e["name"])
                else:
                    parts.append(("<@%s>" if t == "user" else "<#%s>") % e[spec[1]])
            return "".join(parts)

        out = []
        for b in blocks:
            if not isinstance(b, dict):
                return None
            t, extra = b.get("type"), set(b) - {"type", "block_id"}
            v = None
            if t == "header" and extra == {"text"}:
                v = txt(b["text"], ("plain_text",))
            elif t == "section" and extra == {"text"}:
                v = txt(b["text"])
            elif t == "divider" and not extra:
                v = "———"
            elif t == "context" and extra == {"elements"} and isinstance(b["elements"], list) and b["elements"]:
                parts = [txt(e) for e in b["elements"]]
                v = None if None in parts else "  ".join(parts)
            elif t == "rich_text" and extra == {"elements"} and isinstance(b["elements"], list) and b["elements"]:
                lines = []
                for sct in b["elements"]:
                    st = sct.get("type") if isinstance(sct, dict) else None
                    if st in ("rich_text_section", "rich_text_preformatted", "rich_text_quote") and set(sct) <= {"type", "elements", "border"}:
                        r = rich(sct.get("elements"))
                        if r is None:
                            return None
                        lines.append("> " + r if st == "rich_text_quote" else r)
                    elif st == "rich_text_list" and set(sct) <= {"type", "elements", "style", "border"} and isinstance(sct.get("elements"), list) and sct["elements"]:
                        for i, item in enumerate(sct["elements"]):
                            if not isinstance(item, dict) or item.get("type") != "rich_text_section" or not set(item) <= {"type", "elements"}:
                                return None
                            r = rich(item.get("elements"))
                            if r is None:
                                return None
                            lines.append(("%d. " % (i + 1) if sct.get("style") == "ordered" else "• ") + r)
                    else:
                        return None
                v = "\n".join(lines)
            if v is None:
                return None
            out.append(v)
        whole = "\n".join(out)
        # a special mention (<!channel>, <!here>, <!everyone>, <!subteam...>) notifies people the card doesn't name
        return None if "<!" in whole else whole
    except Exception:
        return None


_BODY_KEYS = ("body", "message", "text", "content", "markdown_text", "message_text", "html_body", "html", "body_html")
_NOT_TEXT = "(text Qosha cannot show)"
NO_TEXT = "(no message text)"
_CALL_GRANTS: Dict[str, list] = {}   # tool call -> the engine's findings to grant once the person allows that step
_GRANT_WHY: Dict[str, str] = {}      # tool call -> "now" (allowed on Qosha's card for this step) or "always"
_NOTE = re.compile(r"Command was flagged \([^\"\n]*?\) and auto-approved by [^\"\n]*?\.")


def transform_tool_result(tool_name: str = "", result: Any = None, tool_call_id: str = "", **_: Any) -> Optional[str]:
    """The engine notes on a shell step's result that its own check was "auto-approved by an approval the user gave
    earlier in this session", and Qosha repeated that to the person (17 Nov: "it went through without asking you"),
    when the person had just allowed that very step on Qosha's card. For the steps Qosha granted, the note says what
    really happened. Every other result is left as it is."""
    why = _GRANT_WHY.pop(str(tool_call_id or ""), "")
    if not why or tool_name != "terminal" or not isinstance(result, str) or not _NOTE.search(result):
        return None
    text = ("The person allowed this exact step on Qosha's approval card just now." if why == "now" else
            "The person chose Always allow for this kind of step on Qosha's approval card earlier.")
    return _NOTE.sub(text, result, count=1)


def post_tool_call(tool_name: str = "", tool_call_id: str = "", **_: Any) -> None:
    """The step is over: the engine's grant given for it ends now (also ended at the start of the next step)."""
    try:
        from . import engine_ask
        engine_ask.revoke()
    except Exception:
        pass
