"""Qosha decisions routes (INTERFACES.md §4.3), mounted by plugin_api.py under /api/plugins/qosha/decisions.

A person sees each held action in full and approves or declines it. Approve carries the payload hash the person was
shown; the executor sends exactly that payload once (or records it as approved-not-sent while sending is off).
Emails and calendar changes (D26, one Approve): the person's browser sends Approve straight to the Qosha connector
(`approve_url`); these routes only read its outcome back (`sync`, and on every list).
"""
from __future__ import annotations

import importlib.util
import json
import os
import re
import sys
from pathlib import Path

from fastapi import APIRouter, Body, HTTPException, Query

_GUARD_DIR = Path(__file__).resolve().parent.parent / "qosha_guard"


def _load_guard():
    """Import the guard package by path as `qosha_guard` (the dashboard loads this file outside any package)."""
    mod = sys.modules.get("qosha_guard")
    if mod is not None and Path(getattr(mod, "__file__", "")).resolve().parent == _GUARD_DIR:
        return mod
    spec = importlib.util.spec_from_file_location("qosha_guard", _GUARD_DIR / "__init__.py",
                                                  submodule_search_locations=[str(_GUARD_DIR)])
    mod = importlib.util.module_from_spec(spec)
    sys.modules["qosha_guard"] = mod
    spec.loader.exec_module(mod)
    return mod


_load_guard()
from qosha_guard import executor, store  # noqa: E402  (loaded by path above)

router = APIRouter()
_ID = re.compile(r"^d_[0-9a-f]{12}$")
_SHA = re.compile(r"^[0-9a-f]{64}$")


def _check_id(decision_id: str) -> None:
    if not _ID.match(decision_id):
        raise HTTPException(status_code=404, detail={"error": "not_found"})


def _error(exc: "store.StoreError"):
    status = {"not_found": 404, "not_pending": 409, "payload_changed": 409, "approve_at_connector": 409,
              "already_approved": 409, "decline_unconfirmed": 503}.get(exc.code, 500)
    raise HTTPException(status_code=status, detail={"error": exc.code, "plain": executor.plain(exc.code)})


_ADDR = re.compile(r"[A-Za-z0-9._%+'-]+@[A-Za-z0-9.-]+")


def _addresses(d: dict) -> list:
    p = d.get("payload") or {}
    return [a.lower() for a in _ADDR.findall("%s,%s" % (p.get("to", ""), p.get("cc", "")))]


def _first_time(rows: list, home) -> None:
    """A plain note on the card: addresses Qosha has never emailed before (D26 mitigation)."""
    known = set()
    for d in store.list_decisions("sent", 500, home):
        if d["kind"] in ("email.send", "email.reply"):
            known.update(_addresses(d))
    for d in rows:
        if d["kind"] in ("email.send", "email.reply") and d["status"] in ("pending", "sending"):
            d["first_time"] = sorted({a for a in _addresses(d) if a not in known})


def _sync_open(home) -> None:
    """The connector's outcome for Google decisions still open here (approved in the browser, or cut off midway)."""
    # declined too: an Approve that reached the connector first is shown as what it was (GPT R-email1 #3)
    open_ids = [d["id"] for d in store.list_decisions("pending", 50, home) + store.list_decisions("sending", 50, home)
                + store.list_decisions("declined", 20, home) + store.list_decisions("failed", 20, home)
                if executor.via_connector(d)]
    if open_ids:
        executor.sync(open_ids, home)


_RECONNECT_KIND = {"send": "email.send", "calendar": "calendar.create", "drafts": "email.draft_save", "connect": "email.send"}


def _resolve_reconnects(home) -> None:
    """SENDFIX: a waiting "Reconnect Google" card closes by itself once the connector's sign-in allows what it was for."""
    rows = [d for d in store.list_decisions("pending", 50, home) if d["kind"] == "google.reconnect"]
    if not rows or not executor.connector_mode():
        return
    from qosha_guard import connector_client
    st = connector_client.status()
    can = st.get("can") if isinstance(st.get("can"), dict) else {}
    for d in rows:
        if st.get("connected") and can.get(_RECONNECT_KIND.get((d.get("payload") or {}).get("need"), "email.send")):
            store.resolve_reconnect(d["id"], home)


def google_connect_url() -> str:
    """Where the card's Reconnect Google button goes: the box's Connect Google page; "" on the Mac (signed in by setup)."""
    url = os.environ.get("QOSHA_GOOGLE_CONNECT_URL", "")
    return url if url == "/qosha-box/google" else ""


@router.get("")
@router.get("/")
def list_decisions(status: str = Query("pending"), session: str = Query("")):
    if status not in ("pending", "all"):
        raise HTTPException(status_code=400, detail={"error": "bad_request", "detail": "status must be pending or all"})
    home = store.engine_home()
    _sync_open(home)
    _resolve_reconnects(home)
    rows = store.list_decisions(status, 50 if not session else 200, home)
    if session:
        rows = [d for d in rows if (d.get("source") or {}).get("session_id") == session]
    _first_time(rows, home)
    if not session:
        rows = _chat_asks() + rows
    return {"decisions": rows, "counts": store.counts(home), "sending_enabled": executor.live_send_enabled(home),
            "approve_url": _approve_url(home), "send_limit": {"per_hour": 20},
            "google_connect_url": google_connect_url(),
            "browser_connect_url": _browser_connect_url(home),
            "browser_ui_url": _browser_connect_url(home, "/v1/browser-ui")}


def _chat_asks() -> list:
    """Local installs: the questions waiting in a chat right now (Allow this time / Always allow / Decline), listed for
    Home with a link to that chat. They are answered in the chat, never here."""
    import datetime
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("qosha_ask_read", Path(__file__).resolve().parent.parent / "qosha_guard" / "ask.py")
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        items = m.pending_asks()
    except Exception:
        return []
    out = []
    for x in items:
        at = datetime.datetime.fromtimestamp(float(x.get("at") or 0)).astimezone().isoformat()
        out.append({"id": str(x.get("id")), "kind": "ask.chat", "status": "pending", "created_at": at,
                    "summary": str(x.get("title") or "Qosha asks before a step"),
                    "payload": {"rows": x.get("rows") or [], "session": str(x.get("session") or "")},
                    "source": {"session_id": str(x.get("session") or "")}})
    return out


def _browser_connect_url(home: Path, path: str = "/v1/browser-connect") -> str:
    """BROWSERCHROME: where Connections' "Connect browser" asks the connector (its approval port, which the assistant's
    sandbox can't reach: only the person's press opens Qosha's Chrome on the screen). "" when Qosha's browser is off.
    MYCHROME (Ren, 9 Nov): the same port's /v1/browser-ui is where the person's own pages show, hide, pause and stop
    Qosha's tabs in their Chrome and change Settings > Browser."""
    if not executor.connector_mode():
        return ""
    try:
        on = json.loads((home / "qosha" / "browser.json").read_text()).get("enabled") is True
    except Exception:
        on = False
    url = os.environ.get("QOSHA_APPROVE_URL", "http://127.0.0.1:9240/v1/approve")
    if not on or not url.startswith(("http://127.0.0.1:", "http://localhost:")) or not url.endswith("/v1/approve"):
        return ""
    return url[:-len("/v1/approve")] + path


@router.get("/{decision_id}")
def get_decision(decision_id: str):
    _check_id(decision_id)
    home = store.engine_home()
    executor.sync([decision_id], home)
    d = store.get(decision_id, home)
    if d is None:
        raise HTTPException(status_code=404, detail={"error": "not_found"})
    _first_time([d], home)
    return {"decision": d, "approve_url": _approve_url(home)}


@router.post("/{decision_id}/sync")
def sync(decision_id: str):
    """After the person's Approve at the connector: its outcome, into this decision and Recent activity."""
    return get_decision(decision_id)


def _approve_url(home):
    """The connector's approve address, none while the approval check is down (review GPT FO-15)."""
    _fs = sys.modules.get("qosha_gate_failsafe")
    _chk = getattr(_fs, "check_decision", None)
    return "" if callable(_chk) and _chk(True) else executor.approve_url(home)


@router.post("/{decision_id}/approve")
def approve(decision_id: str, body: dict = Body(...)):
    _check_id(decision_id)
    if _access_gate():                  # CONTRACT-ACCESS: a waiting action is kept, never carried out, while access has ended
        raise HTTPException(status_code=403, detail={"error": "access_ended", "detail": "Your access to Qosha has ended."})
    _fs = sys.modules.get("qosha_gate_failsafe")   # the approval check didn't start: nothing is approved (declining works)
    _chk = getattr(_fs, "check_decision", None)
    _down = _chk(True) if callable(_chk) else None
    if _down:
        raise HTTPException(status_code=503, detail=_down)
    sha = body.get("payload_sha256") if isinstance(body, dict) else None
    if not isinstance(sha, str) or not _SHA.match(sha):
        raise HTTPException(status_code=400, detail={"error": "bad_request", "detail": "payload_sha256 required"})
    try:
        return {"decision": executor.approve(decision_id, sha, store.engine_home())}
    except store.StoreError as exc:
        _error(exc)


@router.post("/{decision_id}/decline")
def decline(decision_id: str):
    _check_id(decision_id)
    try:
        return {"decision": executor.decline(decision_id, store.engine_home())}
    except store.StoreError as exc:
        _error(exc)


def _access_gate():
    """CONTRACT-ACCESS: True when Qosha's access has ended or can't be confirmed (qosha_guard/access.py, loaded by path
    once). Fails closed."""
    import importlib.util as _ilu, sys as _sys
    from pathlib import Path as _P
    try:
        m = _sys.modules.get("qosha_access_gate")
        if m is None:
            p = _P(__file__).resolve().parent.parent / "qosha_guard" / "access.py"
            spec = _ilu.spec_from_file_location("qosha_access_gate", str(p))
            m = _ilu.module_from_spec(spec)
            spec.loader.exec_module(m)
            _sys.modules["qosha_access_gate"] = m
        return bool(m.admit_stopped())      # the same freshness check as a chat message
    except Exception:
        return True
