"""Qosha from the first byte (P0, 3 Nov 21:45 MST): the dashboard's index.html (every page: Home, Chat, Files, Skills,
Connections, Settings and the engine's own pages share it) gets Qosha's critical CSS, loading screen and readiness
script before any engine script or stylesheet. The engine's shell stays hidden until index.js marks the page
data-qosha-ready; the loading screen is all that can paint before that. Used by the lab (qoshalab.py brand_web) on
the built screens and by the first-paint gate (tests/c18_first_paint_gate.py) on its throwaway copy. Pure text in,
text out; run again after every web build (it replaces its own earlier block)."""
import os
import re
import tempfile
import time
from pathlib import Path

HEAD = ('<!-- qosha-first-paint -->', '<!-- /qosha-first-paint -->')
BODY = ('<!-- qosha-splash -->', '<!-- /qosha-splash -->')
SPLIT = '<!-- qosha-first-paint:body -->'
BLOCK_FILE = Path(__file__).resolve().parent / 'first-paint.html'


def strip(html):
    """The page without Qosha's first-paint block (as the engine built it, apart from the icons)."""
    for a, b in (HEAD, BODY):
        html = re.sub(r'[ \t]*' + re.escape(a) + r'.*?' + re.escape(b) + r'\n?', '', html, flags=re.S)
    return html


def apply(html, block=None):
    """Qosha's block at the top of <head> (right after the charset) and its loading screen at the top of <body>."""
    block = BLOCK_FILE.read_text(encoding='utf-8') if block is None else block
    head, body = block.split(SPLIT, 1)
    head, body = head.strip(), body.strip()
    if not (head.startswith(HEAD[0]) and head.endswith(HEAD[1]) and body.startswith(BODY[0]) and body.endswith(BODY[1])):
        raise ValueError('first-paint block is not marked')
    html = strip(html)
    html, n = re.subn(r'(<meta charset="[^"]*"\s*/?>)', lambda m: m.group(1) + '\n    ' + head, html, count=1, flags=re.I)
    if not n:
        html, n = re.subn(r'(<head[^>]*>)', lambda m: m.group(1) + '\n    ' + head, html, count=1, flags=re.I)
    html, m = re.subn(r'(<body[^>]*>)', lambda x: x.group(1) + '\n    ' + body, html, count=1, flags=re.I)
    if not n or not m:
        raise ValueError('index.html has no <head> or <body>')
    # nothing of the engine's may come before it: no script, stylesheet or preload above Qosha's block
    top = html[:html.index(HEAD[0])]
    if re.search(r'<script|<link[^>]+rel="(?:stylesheet|modulepreload|preload)"|<style', top, flags=re.I):
        raise ValueError('an engine script or stylesheet sits above the first-paint block')
    return html


# The engine's built screens name it in places that can reach the page before Qosha's own words load (hidden behind the
# loading screen, but in the page): the brand string in every language (app.brand "Hermes Agent"), the sidebar logo
# ("Hermes" / "Agent" on two lines), the default theme's name and description, the shared-metrics banner, the side
# panel's update button. Swapped in the shipped copy at install (orchestrator, 22 Nov 2026: "the first byte served is
# already Qosha ... no 'Hermes' in the title, the DOM or the screenshot text"). Any of the three JS quotes (Gemini
# fp15 F3); each pattern anchored to its own key or shape (F10). Idempotent; a missing file or pattern is skipped (a
# later engine may have changed them). Text a person reads later on other pages stays index.js's job (its sweep).
_Q = r'([`"\'])'
_K = r'(?<![\w$])'          # a whole property name, not the end of a longer one (GPT fp15 r2 F10)
ASSET_SWAPS = [
    (re.compile(_K + r'(app:\{brand:)' + _Q + r'Hermes Agent\2(,brandShort:)\2HA\2'), r'\1\2Qosha\2\3\2Q\2'),
    (re.compile(_Q + r'Hermes\1,(\(0,[\w$]+\.jsx\)\(\1br\1,\{\}\)),\1Agent\1'), r'\1Qosha\1,\2,\1\1'),
    (re.compile(_K + r'((?:label|description):)' + _Q + r'Hermes Teal'), r'\1\2Qosha Teal'),
    (re.compile(_K + r'(description:)' + _Q + r'Classic dark teal \u2014 the canonical Hermes look\2'),
     '\\1\\2Classic dark teal \u2014 the canonical Qosha look\\2'),
    # (1.20.14 and earlier installs already say "Help improve Qosha?": the same title for them; GPT ep18-05)
    (re.compile(_K + r'((?:sharedMetricsTitle:|sharedMetricsTitle\?\?))' + _Q + r'Help improve (?:Hermes|Qosha)\?\2'), r'\1\2Help improve the AI engine Qosha runs on?\2'),
    # the side panel's update button, in every language: the engine's name wherever it sits in the value (GPT r2 F3)
    (re.compile(_K + r'((?:updateHermes|updateHermesConfirmTitle|updatingHermes):)' + _Q + r'((?:\\.|(?!\2)[^\\])*?)Hermes'),
     r'\1\2\3Qosha'),
    # the name a new Telegram bot gets from the Channels page (shown to the person in Telegram)
    (re.compile(_K + r'(bot_name:)' + _Q + r'Hermes Agent\2'), r'\1\2Qosha\2'),
    # the engine maker's credit in the side panel's footer, every language (orchestrator, 22 Nov 2026: P0)
    (re.compile(_K + r'(footer:\{org:)' + _Q + r'Nous Research\2'), r'\1\2Qosha AI\2'),
    # 22 Nov 2026, the council (Gemini D12): the maker's name elsewhere in the screens. The metrics banner tells the
    # truth about who receives the counts (the engine's makers), without their name.
    (re.compile(_K + r'(label:)' + _Q + r'Nous Blue\2'), r'\1\2Qosha Blue\2'),
    (re.compile(_K + r'(description:)' + _Q + r'Light mode \u2014 vivid Nous-blue accents'), '\\1\\2Light mode \u2014 vivid blue accents'),
    (re.compile(_K + r'((?:sharedMetricsShare:|sharedMetricsShare\?\?))' + _Q + r'Share with Nous\2'), r'\1\2Share with the engine makers\2'),
    (re.compile(_K + r'((?:sharedMetricsBody:|sharedMetricsBody\?\?))' + _Q + r'((?:\\.|(?!\2)[^\\])*?)Sharing sends them to Nous once a day\.'),
     r'\1\2\3Sharing sends them once a day to the makers of the AI engine Qosha runs on.'),
    (re.compile(_K + r'((?:restartGatewayConfirmMessage:|restartGatewayConfirmMessage\?\?))' + _Q + r'This restarts the Hermes gateway process\.'),
     r'\1\2This restarts the Qosha background service.'),
    (re.compile(_K + r'((?:catalogHint:|catalogHint\?\?))' + _Q + r'Curated, Nous-reviewed plugins'), r'\1\2Curated, reviewed plugins'),
    (re.compile(_K + r'(children:)' + _Q + r'Browse Nous-approved MCP servers'), r'\1\2Browse approved MCP servers'),
    # links to the engine's docs and its maker's site (the metrics banner's "Details", the docs and plugin links;
    # Gemini ep18 F3): no destination that shows the engine's or maker's name. The maker's AI provider portal
    # (portal.nousresearch.com) is left for the open provider decision.
    # about:blank, not "#": the same address feeds the Docs page's iframe, and "#" opened another dashboard (GPT/Gemini r2)
    (re.compile(_Q + r'https?://(?:hermes-agent\.)?nousresearch\.com(?:/[^`"\'\s]*)?\1'), r'\1about:blank\1'),
    # the achievements' share text, every language: the engine's name and its symbol
    (re.compile(_K + r'(tweet_text:)' + _Q + r'((?:\\.|(?!\2)[^\\])*?)Hermes Agent(?: \u2624)?'), r'\1\2\3Qosha'),
]


def _write_atomic(f, text):
    """The new text in a fresh, exclusively created sibling temp file (mkstemp: no fixed name another writer or a
    planted link could share; GPT fp15 r2 F11/R2-2), then swapped in (os.replace): a reader never sees a half-written
    file, a failed write leaves the old file whole (Gemini fp15 F2). A file held open on Windows gets a few retries."""
    try:
        fd, tmp = tempfile.mkstemp(dir=str(f.parent), prefix='.%s.' % f.name, suffix='.qosha-tmp')
    except OSError:
        return False
    tmp = Path(tmp)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='') as h:
            h.write(text)
            h.flush()
            os.fsync(h.fileno())
        for i in range(5):
            try:
                os.replace(tmp, f)
                return True
            except PermissionError:
                time.sleep(0.2 * (i + 1))
        return False
    except OSError:
        return False
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass


def brand_assets(dist):
    """Swap the engine's brand words in the built screens (assets/*.js). Returns how many swaps were written. Never
    raises: a file it cannot read or replace is left exactly as it was (the page's title and loading screen come from
    index.html, which the installer writes either way)."""
    n = 0
    try:
        files = sorted((Path(dist) / 'assets').glob('*.js'))
    except OSError:
        return 0
    for f in files:
        try:
            if f.is_symlink() or not f.is_file():
                continue
            with open(f, encoding='utf-8', newline='') as h:   # bytes kept as they are (no line-end change on Windows)
                text = h.read()
        except (OSError, UnicodeDecodeError):
            continue
        new, k = text, 0
        for rx, repl in ASSET_SWAPS:
            new, c = rx.subn(repl, new)
            k += c
        if new != text and _write_atomic(f, new):
            n += k
    return n
