/* Qosha access (CONTRACT-ACCESS v2, Ren 20 Nov 2026: "I just want them to loose access immediately").
   On Home and every Qosha page except Settings: while Qosha's access has ended (revoked) or can't be confirmed (no
   connection for more than an hour), the page is covered by one card in Qosha's look, with Check again, Export my
   chats and Open my Qosha folder. It reads /api/plugins/qosha/access/status every 20 seconds (a local read; the
   dashboard checks the published list every 2 minutes). Text only; nothing of the person's is touched. */
(function () {
  'use strict';
  if (window.__qoshaAccess) return;
  window.__qoshaAccess = true;
  // 1.20.2: typing, a click or tap (a suggested prompt, the microphone), and an open microphone are activity:
  // automatic updates wait until Qosha hasn't been used for 10 minutes. One small local request a minute at most,
  // with no content; something inside that minute gets one trailing request when the minute ends (review MEDIUM).
  var lastPing = 0, trail = null;
  function ping() {
    var t = Date.now();
    if (t - lastPing < 60000) {
      if (!trail) trail = setTimeout(function () { trail = null; ping(); }, 60000 - (t - lastPing) + 50);
      return;
    }
    lastPing = t;
    try { fetch('/api/plugins/qosha/updates/activity', {method: 'POST', headers: {'X-Hermes-Session-Token': tok()}, credentials: 'same-origin', cache: 'no-store'}).catch(function () {}); } catch (e) { /* best effort */ }
  }
  ['keydown', 'pointerdown', 'input'].forEach(function (ev) { document.addEventListener(ev, ping, true); });
  // a voice message or Live voice: activity for as long as the microphone is open (review #3)
  try {
    var md = navigator.mediaDevices, open = [];
    if (md && typeof md.getUserMedia === 'function' && !md.__qoshaActivity) {
      var gum = md.getUserMedia.bind(md);
      md.__qoshaActivity = true;
      md.getUserMedia = function (c) { ping(); return gum(c).then(function (st) { open.push(st); ping(); return st; }); };
      setInterval(function () {
        open = open.filter(function (st) { try { return st.getTracks().some(function (k) { return k.readyState === 'live'; }); } catch (e) { return false; } });
        if (open.length) ping();
      }, 30000);
    }
  } catch (e) { /* best effort */ }
  if (/\/settings\.html$/.test(window.location.pathname)) return;      // Settings stays open
  var B = '/api/plugins/qosha/access/', layer = null, shownKey = '', busy = false;
  function tok() {
    try { var f = window; if (typeof f.__HERMES_SESSION_TOKEN__ === 'string') return f.__HERMES_SESSION_TOKEN__;
      while (f.parent && f.parent !== f) { f = f.parent; if (typeof f.__HERMES_SESSION_TOKEN__ === 'string') return f.__HERMES_SESSION_TOKEN__; } } catch (e) {}
    return '';
  }
  function api(m, path) {
    return fetch(B + path, {method: m, headers: {'X-Hermes-Session-Token': tok()}, credentials: 'same-origin', cache: 'no-store'})
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (d) { if (!r.ok) throw new Error(d.error || ('HTTP ' + r.status)); return d; }); });
  }
  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) { if (k === 'onclick') n.addEventListener('click', attrs[k]); else if (k === 'text') n.textContent = attrs[k]; else n.setAttribute(k, attrs[k]); });
    (kids || []).forEach(function (c) { if (c) n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return n;
  }
  function when(t) {
    if (!t) return '';
    var d = new Date(t * 1000), today = new Date().toDateString() === d.toDateString();
    return (today ? 'today at ' : d.toLocaleDateString([], {month: 'short', day: 'numeric'}) + ', ') + d.toLocaleTimeString([], {hour: 'numeric', minute: '2-digit'});
  }
  var CSS = '.qa-layer{position:fixed;inset:0;z-index:2147483000;background:rgba(248,247,243,.97);display:flex;align-items:center;justify-content:center;padding:24px;overflow:auto;font-family:"Google Sans Flex","Google Sans","Helvetica Neue",sans-serif;color:#0B0B0B;-webkit-font-smoothing:antialiased}' +
    '.qa-card{width:100%;max-width:560px;background:#FFFFFF;border:1px solid #E2E1DB;border-radius:20px;box-shadow:0 1px 2px rgba(11,11,11,.04),0 8px 28px rgba(11,11,11,.05);padding:40px 44px 32px;box-sizing:border-box}' +
    '.qa-tile{width:52px;height:52px;border-radius:14px;display:block;margin-bottom:22px}' +
    '.qa-card h1{font-size:26px;line-height:32px;font-weight:600;margin:0 0 12px}' +
    '.qa-card p{margin:0 0 14px;color:#3D3D3A;font-size:15px;line-height:23px}' +
    '.qa-safe{background:#E3EEE7;color:#0B3326;border-radius:12px;padding:12px 14px;margin:18px 0 16px;font-size:14px;line-height:20px}' +
    '.qa-msg{border-left:3px solid #B8955A;padding:4px 0 4px 14px;margin:6px 0 20px;font-size:14px}' +
    '.qa-msg small{display:block;color:#5E5D59;font-size:12px;margin-bottom:2px}' +
    '.qa-btns{display:flex;gap:10px;flex-wrap:wrap;margin-top:8px}' +
    '.qa-b{height:40px;padding:0 18px;border-radius:10px;border:1px solid #E2E1DB;background:#FFFFFF;color:#0B0B0B;font:inherit;font-weight:500;cursor:pointer}' +
    '.qa-b.pri{background:#0B3326;border-color:#0B3326;color:#FFFFFF}.qa-b[disabled]{opacity:.55;cursor:default}' +
    '.qa-b:focus-visible{outline:2px solid #0B3326;outline-offset:2px}' +
    '.qa-note{margin-top:14px;font-size:13px;color:#3D3D3A;min-height:18px}' +
    '.qa-meta{margin-top:24px;padding-top:16px;border-top:1px solid #E2E1DB;color:#5E5D59;font-size:12px;line-height:18px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}' +
    '.qa-mono{font-family:"Google Sans Code",ui-monospace,Menlo,monospace;color:#0B0B0B}';
  function hide() { if (layer) { layer.remove(); layer = null; shownKey = ''; } }
  function show(st) {
    var key = [st.state, st.message || '', st.checked_at || 0].join('|');
    if (layer && key === shownKey) return;
    var keepNote = layer ? layer.querySelector('.qa-note').textContent : '';
    hide(); shownKey = key;
    if (!document.getElementById('qa-css')) document.head.appendChild(el('style', {id: 'qa-css', text: CSS}));
    var revoked = st.state === 'revoked';
    var note = el('p', {class: 'qa-note', role: 'status', 'aria-live': 'polite', text: keepNote});
    function btn(text, pri, fn) { return el('button', {class: 'qa-b' + (pri ? ' pri' : ''), type: 'button', text: text, onclick: fn}); }
    var again = btn('Check again', true, function () {
      if (busy) return; busy = true; again.disabled = true; note.textContent = 'Checking…';
      api('POST', 'check').then(function (d) {
        busy = false; again.disabled = false;
        if (!d.stopped) { note.textContent = ''; hide(); window.location.reload(); return; }
        note.textContent = d.result === 'unreachable' ? 'Qosha still can’t reach the internet.' : 'Your access hasn’t been restored yet.';
        shownKey = ''; show(d);
      }, function () { busy = false; again.disabled = false; note.textContent = 'Qosha couldn’t check just now. Please try again.'; });
    });
    var exp = btn('Export my chats', false, function () {
      if (busy) return; busy = true; exp.disabled = true; note.textContent = 'Saving your chats…';
      api('POST', 'export').then(function (d) {
        busy = false; exp.disabled = false;
        var name = String(d.folder || '').split(/[\\/]/).pop();
        note.textContent = d.ok ? ('Saved ' + d.chats + ' chat' + (d.chats === 1 ? '' : 's') + ' to Downloads › ' + name + '.')
          : ('Saved what Qosha could to Downloads › ' + name + '.');
      }, function () { busy = false; exp.disabled = false; note.textContent = 'Qosha couldn’t save your chats just now. Please try again.'; });
    });
    var open = btn('Open my Qosha folder', false, function () { api('POST', 'open-folder').catch(function () {}); });
    var sets = btn('Settings', false, function () { hide(); (window.top || window).location.href = '/?view=settings'; });
    var tile = el('img', {class: 'qa-tile', alt: '', src: '/dashboard-plugins/qosha/assets/brand/icons/qosha-icon.svg'});
    var kids = [tile,
      el('h1', {id: 'qa-title', text: revoked ? 'Your access to Qosha has ended' : 'Qosha can’t confirm your access'}),
      el('p', {text: revoked ? 'Qosha has stopped answering on this computer.'
        : 'Qosha hasn’t been able to reach the internet for more than an hour, so it has paused. It comes back by itself within two minutes of the connection returning, or press Check again.'}),
      el('div', {class: 'qa-safe', text: 'Your chats, files, memories and settings are still on this computer, untouched. Nothing was deleted or sent anywhere.'})];
    if (revoked && st.message) kids.push(el('div', {class: 'qa-msg'}, [el('small', {text: 'Message from Qosha'}), st.message]));
    kids.push(el('div', {class: 'qa-btns'}, [again, exp, open, sets]), note,
      el('div', {class: 'qa-meta'}, [el('span', {text: revoked ? (st.checked_at ? 'Checked ' + when(st.checked_at) : '') : (st.confirmed_at ? 'Last confirmed ' + when(st.confirmed_at) : '')})]));
    layer = el('div', {class: 'qa-layer', role: 'alertdialog', 'aria-modal': 'true', 'aria-labelledby': 'qa-title'}, [el('div', {class: 'qa-card'}, kids)]);
    document.body.appendChild(layer);
    again.focus();
  }
  function settingsOpen() {
    // Settings stays reachable: Home shows it in place at /?view=settings, so the card steps aside there
    try { var t = (window.top || window).location; return t.pathname === '/' && /(?:^|[?&])view=settings(?:&|$)/.test(t.search); } catch (e) { return false; }
  }
  function load() {
    if (busy) return;
    if (settingsOpen()) { hide(); return; }
    api('GET', 'status').then(function (st) { if (st && st.stopped) show(st); else if (st && st.stopped === false) hide(); }, function () {});
  }
  function start() { load(); setInterval(load, 20 * 1000); try { (window.top || window).addEventListener('popstate', load); } catch (e) {} setInterval(function () { if (layer && settingsOpen()) hide(); }, 1000); }
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
  window.qoshaAccess = {reload: load};
})();
