"""Updates keep the person's own changes to Qosha's program files (contract KEEPEDITS, signed by Ren 18 Nov 2026).

Three versions of every file under <home>/plugins/qosha:
  BASE = what this computer's release installed (the record below), MINE = the live file, NEW = the incoming release's.
- MINE == BASE                      -> NEW is installed (the person did not change it).
- MINE != BASE, NEW == BASE         -> MINE is kept byte for byte.
- MINE != BASE, NEW != BASE         -> line-based three-way merge (merge3). Clean -> the merged file; any overlap ->
                                       MINE is kept and NEW is saved beside it as <file>.qosha-<version>.new.
- A file the person added (not in BASE) is kept; a file the release removes but the person changed is kept.
- Where the release puts a folder (or a link) where the person has a file, or a file where the person's file needs a
  folder, the release's entry is moved aside as <name>.qosha-<version>.new and MINE is kept: reported as a conflict.
- Files the installer rewrites at every install (INSTALLER_REWRITES) are never treated as the person's changes.

The record: <home>/qosha/plugin-installed/ is a copy of <home>/plugins/qosha as it stood after the last successful
install or update (record_installed). Where that copy holds the person's own version of a file (kept, merged,
conflicted or added), the release's real BASE for that file is kept apart in <home>/qosha/plugin-base/ (index.json +
content-addressed blobs), so the next update still sees the person's change instead of taking it for Qosha's own.
Before the first record exists, BASE is the release's raw package (<root>/layer/candidate/plugin), and a live file
that equals any way the installer itself writes that package file (as copied; with Windows line endings; for *.py the
Windows port of setup_home.py's port_text(); for chat.html its "Always allow" button) is not the person's change.
Every other difference, *.py included, is.

Standard library only; the same file runs on Mac and Windows, inside the plugin and as the updater's copy in <root>/run.
"""
from __future__ import annotations

import difflib
import fnmatch
import hashlib
import json
import os
import re
import shutil
import time
from pathlib import Path

# Files setup_home.py (fast/layer/setup_home.py) writes into <home>/plugins/qosha at every install, on top of the
# release's copy: install_plugin() rewrites __init__.py (ask-for-access hook) and dashboard/index.html ("Always allow"
# button), and copies qosha_guard/askaccess.py from the layer when the plugin has no ask.py; main() copies
# qosha_names.py from the layer and appends its import to __init__.py. They are never "the person's change": the
# release's version is installed and the installer's own rewrite runs on it as before.
# (setup_home.py also re-saves dashboard/pages/chat.html and, on Windows, ports every *.py: both are covered by comparing
# against the record, which is taken AFTER the install, and before the first record by _renditions() below.)
# of those, the screens a person (or Qosha for them) edits: kept once the installed record exists
KEPT_ONCE_RECORDED = frozenset({"dashboard/index.html"})
INSTALLER_REWRITES = frozenset({
    "__init__.py",
    "dashboard/index.html",
    "qosha_names.py",
    "qosha_guard/askaccess.py",
})

_NEW_PAT = "*.qosha-*.new"
_SKIP_NAMES = ("*.pyc", _NEW_PAT, ".*.qosha-tmp")


# --- places -----------------------------------------------------------------------------------------------------------
def _live(home: Path) -> Path:
    return Path(home) / "plugins" / "qosha"


def installed_dir(home: Path) -> Path:
    """The plugin exactly as it stood after the last install or update."""
    return Path(home) / "qosha" / "plugin-installed"


def _base_dir(home: Path) -> Path:
    return Path(home) / "qosha" / "plugin-base"


def _skip_dir(name: str) -> bool:
    return name == "__pycache__" or fnmatch.fnmatchcase(name, _NEW_PAT)


def _skip(rel: str) -> bool:
    parts = rel.split("/")
    if any(_skip_dir(x) for x in parts[:-1]):
        return True
    name = parts[-1]
    return any(fnmatch.fnmatchcase(name, pat) for pat in _SKIP_NAMES)


def _files(top: Path):
    """(rel_posix, path) of every regular file under top (no symlinks followed or reported), sorted."""
    out = []
    top = Path(top)
    if not top.is_dir():
        return out
    for dirpath, dirnames, filenames in os.walk(top, followlinks=False):
        d = Path(dirpath)
        dirnames[:] = sorted(n for n in dirnames if not _skip_dir(n) and not (d / n).is_symlink())
        for n in filenames:
            p = d / n
            if p.is_symlink() or not p.is_file():
                continue
            rel = p.relative_to(top).as_posix()
            if not _skip(rel):
                out.append((rel, p))
    out.sort()
    return out


# --- the three-way merge ----------------------------------------------------------------------------------------------
def _text_ok(b) -> bool:
    if not isinstance(b, (bytes, bytearray)) or b"\x00" in b:
        return False
    try:
        bytes(b).decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def _hunks(base: list, side: list) -> list:
    """The side's changes as (base_start, base_end, replacement_lines, block_start, block_end), in base line numbers.
    A block of n lines replaced by n lines is split into n one-line replacements (each one can then only merge with
    the other side where that side changed none of those lines, or changed them the same way); block_start/block_end
    keep the whole block, so lines the other side inserts INSIDE it still count as touching it."""
    n, m = len(base), len(side)
    p = 0
    while p < n and p < m and base[p] == side[p]:
        p += 1
    s = 0
    while s < n - p and s < m - p and base[n - 1 - s] == side[m - 1 - s]:
        s += 1
    a, b = base[p:n - s], side[p:m - s]
    out = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag == "equal":
            continue
        if tag == "replace" and i2 - i1 == j2 - j1 and i2 - i1 > 1:
            for k in range(i2 - i1):
                out.append((p + i1 + k, p + i1 + k + 1, b[j1 + k:j1 + k + 1], p + i1, p + i2))
            continue
        out.append((p + i1, p + i2, b[j1:j2], p + i1, p + i2))
    return out


def _touch(x, y) -> bool:
    """Two changes (hunks of merge3: start, end, lines, side, block_start, block_end) cannot both be applied on their
    own: they replace a common base line; or both insert lines at the same place (the order would be a guess); or one
    inserts lines strictly inside the block the other one rewrote. Changes to neighbouring lines, and lines inserted
    just before or just after the other side's change, do not touch: both are applied."""
    x1, x2, y1, y2 = x[0], x[1], y[0], y[1]
    if x1 == x2 and y1 == y2:
        return x1 == y1
    if x1 == x2:
        return y[4] < x1 < y[5]
    if y1 == y2:
        return x[4] < y1 < x[5]
    return x1 < y2 and y1 < x2


def merge3(base: bytes, mine: bytes, new: bytes):
    """Line-based three-way merge. Changes on one side only are taken; the same change on both sides is taken once;
    changes that touch (see _touch: the same base lines, the same insertion point, or an insertion inside the other
    side's rewritten block) and differ -> None. Changes to neighbouring lines are both taken. Lines keep their own
    endings byte for byte (CRLF stays CRLF). Anything that is not UTF-8 text (or holds a NUL byte) -> None: never a
    half-merged file."""
    if not (_text_ok(base) and _text_ok(mine) and _text_ok(new)):
        return None
    base, mine, new = bytes(base), bytes(mine), bytes(new)
    if mine == new:
        return mine
    if mine == base:
        return new
    if new == base:
        return mine
    bl = base.splitlines(keepends=True)
    hs = [(i1, i2, rep, 0, o1, o2) for i1, i2, rep, o1, o2 in _hunks(bl, mine.splitlines(keepends=True))]
    hs += [(i1, i2, rep, 1, o1, o2) for i1, i2, rep, o1, o2 in _hunks(bl, new.splitlines(keepends=True))]
    hs.sort(key=lambda h: (h[0], h[1], h[3]))
    groups = []                 # [start, end, hunks]: hunks that touch (see _touch) form one group
    for h in hs:
        if groups and any(_touch(h, g) for g in groups[-1][2]):
            groups[-1][1] = max(groups[-1][1], h[1])
            groups[-1][2].append(h)
        else:
            groups.append([h[0], h[1], [h]])
    out, pos = [], 0
    for gs, ge, hh in groups:
        if gs < pos:
            return None                         # cannot happen with the grouping above; never guess
        out.extend(bl[pos:gs])
        sides = {h[3] for h in hh}
        regions = []
        for sd in (0, 1):
            r, p = [], gs
            for i1, i2, rep, s, _o1, _o2 in hh:
                if s != sd:
                    continue
                r.extend(bl[p:i1])
                r.extend(rep)
                p = i2
            r.extend(bl[p:ge])
            regions.append(r)
        if len(sides) == 2 and regions[0] != regions[1]:
            return None                         # both sides changed the same place differently
        out.extend(regions[0] if 0 in sides else regions[1])
        pos = ge
    out.extend(bl[pos:])
    res = b"".join(out)
    return res if _text_ok(res) else None


# --- the record of what was installed ---------------------------------------------------------------------------------
def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


_ABSENT = object()


def _read_bases(home: Path) -> dict:
    """{rel: bytes or None} for files whose real BASE is not the record's copy (see the module notes)."""
    d = _base_dir(home)
    try:
        idx = json.loads((d / "index.json").read_text(encoding="utf-8"))
        files = idx.get("files") if isinstance(idx, dict) else None
    except (OSError, ValueError):
        return {}
    out = {}
    for rel, sha in (files or {}).items() if isinstance(files, dict) else ():
        if not isinstance(rel, str):
            continue
        if sha is None:
            out[rel] = None
            continue
        if not (isinstance(sha, str) and len(sha) == 64 and all(c in "0123456789abcdef" for c in sha)):
            continue
        try:
            data = (d / "blobs" / sha).read_bytes()
        except OSError:
            continue                            # unreadable: that file falls back to the record's copy
        if _sha(data) == sha:
            out[rel] = data
    return out


def _write_bases(home: Path, bases: dict | None) -> None:
    d = _base_dir(home)
    tmp = d.with_name(d.name + ".new")
    if tmp.exists():
        shutil.rmtree(tmp)
    (tmp / "blobs").mkdir(parents=True)
    files = {}
    for rel, data in sorted((bases or {}).items()):
        if data is None:
            files[rel] = None
            continue
        sha = _sha(data)
        (tmp / "blobs" / sha).write_bytes(data)
        files[rel] = sha
    (tmp / "index.json").write_text(json.dumps({"files": files, "at": int(time.time())}, indent=1, sort_keys=True),
                                    encoding="utf-8")
    old = d.with_name(d.name + ".old")
    if old.exists():
        shutil.rmtree(old)
    if d.exists():
        os.replace(d, old)
    os.replace(tmp, d)
    shutil.rmtree(old, ignore_errors=True)


def record_installed(home: Path, bases: dict | None = None) -> None:
    """Replaces installed_dir(home) with a copy of <home>/plugins/qosha (no __pycache__, *.pyc or *.qosha-*.new).
    bases: {rel: bytes or None} the real BASE of every file whose live copy is the person's own version (restore()
    fills it); without it, every recorded file counts as Qosha's own."""
    home = Path(home)
    dst = installed_dir(home)
    tmp = dst.with_name(dst.name + ".new")
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    for rel, p in _files(_live(home)):
        t = tmp.joinpath(*rel.split("/"))
        t.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, t)
    old = dst.with_name(dst.name + ".old")
    if old.exists():
        shutil.rmtree(old)
    if dst.exists():
        os.replace(dst, old)
    os.replace(tmp, dst)
    shutil.rmtree(old, ignore_errors=True)
    _write_bases(home, bases)


# --- what the installer itself makes of a package file (used only before the first record exists) ---------------------
def _port_text(text: str) -> str:
    """setup_home.py's port_text() (fast/layer/setup_home.py), byte for byte the same rewrite: the Windows install
    applies it to every *.py of the plugin."""
    for flag in ("O_NOFOLLOW", "O_DIRECTORY", "O_NONBLOCK", "O_CLOEXEC"):
        text = re.sub(r"\bos\.%s\b" % flag, 'getattr(os, "%s", 0)' % flag, text)
    text = text.replace("getattr(getattr(os, ", "getattr(getattr(os, ")
    text = text.replace("os.getuid()", 'getattr(os, "getuid", lambda: 0)()')
    text = text.replace('_F_GETPATH = getattr(__import__("fcntl"), "F_GETPATH", None)',
                        'try:\n    _F_GETPATH = getattr(__import__("fcntl"), "F_GETPATH", None)\nexcept ImportError:\n'
                        "    _F_GETPATH = None")
    text = re.sub(r"^import fcntl$", "try:\n    import fcntl\nexcept ImportError:  # Windows\n    fcntl = None",
                  text, flags=re.M)
    return text


_ALWAYS_OLD = "'Allow once'),\n"
_ALWAYS_NEW = ("'Allow once'),\n      el('button', {class: 'btn sm ghost', type: 'button', onclick: function () { "
               "done('always', 'You allowed this always (what it covers is written above).'); }}, 'Always allow'),\n")


def _always_allow(text: str) -> str:
    """setup_home.py's chat.html step: the "Always allow" button, when the page does not carry it yet."""
    if "Always allow" not in text and _ALWAYS_OLD in text:
        return text.replace(_ALWAYS_OLD, _ALWAYS_NEW, 1)
    return text


def _renditions(rel: str, raw: bytes) -> list:
    """Every way the install could have written this package file, this computer's own way first: copied as is; read
    as text and written back with Windows line endings; for *.py ported (Windows); for chat.html with its button."""
    try:
        norm = raw.decode("utf-8").replace("\r\n", "\n").replace("\r", "\n")
    except UnicodeDecodeError:
        return [raw]

    def crlf(s: str) -> bytes:
        return s.replace("\n", "\r\n").encode("utf-8")
    texts = [norm]
    primary_mac, primary_win = raw, raw
    if rel.endswith(".py"):
        ported = _port_text(norm)
        if ported != norm:
            texts.append(ported)
            primary_win = crlf(ported)
    if rel == "dashboard/pages/chat.html":
        a = _always_allow(norm)
        if a != norm:
            texts.append(a)
        primary_mac, primary_win = a.encode("utf-8"), crlf(a)
    out = [primary_win if os.name == "nt" else primary_mac, raw]
    for t in texts:
        out += [t.encode("utf-8"), crlf(t)]
    seen, uniq = set(), []
    for b in out:
        if b not in seen:
            seen.add(b)
            uniq.append(b)
    return uniq


def _closest(cands: list, mine: bytes) -> bytes:
    """The candidate BASE most like the person's file (first one on a tie)."""
    ml = mine.splitlines(keepends=True)
    best, score = cands[0], -1.0
    for c in cands:
        r = difflib.SequenceMatcher(None, c.splitlines(keepends=True), ml, autojunk=False).ratio()
        if r > score:
            best, score = c, r
    return best


# --- before and after an update ---------------------------------------------------------------------------------------
def capture(home: Path, fallback_base: Path) -> dict:
    """The person's changes in <home>/plugins/qosha before an update: {rel_posix: {"mine": bytes, "base": bytes or
    None}} for every regular file that differs from BASE or that BASE does not have."""
    home = Path(home)
    rec = installed_dir(home)
    have_record = rec.is_dir()
    base_top = rec if have_record else Path(fallback_base)
    overrides = _read_bases(home) if have_record else {}
    out = {}
    for rel, p in _files(_live(home)):
        # the Home page is rewritten by every install, but once the record exists it holds that rewrite too, so the
        # person's own Home changes are told apart and kept like any other screen (Ren, 18 Nov 2026: "Fix it first")
        if rel in INSTALLER_REWRITES and not (have_record and rel in KEPT_ONCE_RECORDED):
            continue
        mine = p.read_bytes()
        base = overrides.get(rel, _ABSENT)
        if base is _ABSENT:
            bp = base_top.joinpath(*rel.split("/"))
            base = bp.read_bytes() if bp.is_file() and not bp.is_symlink() else None
            if base is not None and not have_record:
                cands = _renditions(rel, base)
                if mine in cands:
                    continue                    # exactly what the install made of the package: not the person's
                base = _closest(cands, mine)
        if base == mine:
            continue
        out[rel] = {"mine": mine, "base": base}
    return out


def _valid_rel(rel) -> bool:
    if not isinstance(rel, str) or not rel or rel.startswith("/") or "\\" in rel or ":" in rel or "\x00" in rel:
        return False
    return not any(x in ("", ".", "..") for x in rel.split("/"))


def _inside(live: Path, p: Path) -> bool:
    try:
        r = p.resolve()
    except OSError:
        return False
    return r == live or live in r.parents


def _aside(p: Path, live: Path, version: str) -> str:
    """Moves the entry at p (a file, folder or link; links are moved, never followed) to <name>.qosha-<version>.new
    beside it (a free name, never overwriting) and returns its new path relative to live."""
    v = _safe_version(version)
    n = 1
    while True:
        dest = p.with_name("%s.qosha-%s%s.new" % (p.name, v, "" if n == 1 else "-%d" % n))
        if not os.path.lexists(dest):
            break
        n += 1
    os.replace(p, dest)
    return dest.relative_to(live).as_posix()


def _make_room(live: Path, rel: str, version: str):
    """(target path, [moved aside]) for rel inside the live plugin: whatever is in the way (a file or link where a
    folder is needed, a folder or link where the file goes) is moved aside, not deleted. (None, []) when rel is not a
    plain relative path inside the plugin."""
    if not _valid_rel(rel):
        return None, []
    parts = rel.split("/")
    moved = []
    cur = live
    for x in parts[:-1]:
        cur = cur / x
        if cur.is_symlink() or (cur.exists() and not cur.is_dir()):
            moved.append(_aside(cur, live, version))
    t = cur / parts[-1]
    if t.is_symlink() or (t.exists() and not t.is_file()):
        moved.append(_aside(t, live, version))
    if not _inside(live, t.parent if t.parent.exists() else live):
        return None, moved
    return t, moved


def _write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = None
    try:
        mode = path.stat().st_mode & 0o777
    except OSError:
        pass
    tmp = path.with_name("." + path.name + ".qosha-tmp")
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        try:
            os.fsync(f.fileno())
        except OSError:
            pass
    if mode is not None:
        try:
            os.chmod(tmp, mode)
        except OSError:
            pass
    os.replace(tmp, path)


def _safe_version(v: str) -> str:
    s = "".join(c if (c.isalnum() and c.isascii()) or c == "." else "_" for c in str(v))[:40]
    return s or "new"


def saved_edits_dir(home: Path) -> Path:
    """Where a person's version is saved when the update's version had to be used (the Home page clash rule):
    <home>/qosha/saved-edits/, outside <home>/plugins/qosha, so no later update or install deletes it."""
    return Path(home) / "qosha" / "saved-edits"


def _save_outside(home: Path, rel: str, version: str, data: bytes) -> str | None:
    """Saves data as a NEW file in saved_edits_dir(home): one flat name per save (time, version, path with "/" as
    "__"), created exclusively (never overwrites, never follows a link). Returns the path relative to home, or None
    when it cannot be saved safely (a link or a non-folder on the way, any error): the caller then keeps the person's
    version in use instead."""
    try:
        home = Path(home)
        for d in (home / "qosha", saved_edits_dir(home)):
            if d.is_symlink() or (d.exists() and not d.is_dir()):
                return None
            d.mkdir(exist_ok=True)
        if not _valid_rel(rel):
            return None
        ver = re.sub(r"[^0-9A-Za-z._-]", "_", str(version))[:40].strip(".") or "update"
        stem = "%s-%s-%s" % (time.strftime("%Y%m%d-%H%M%S"), ver, rel.replace("/", "__"))
        top = saved_edits_dir(home)
        for n in range(1, 100):
            name = stem if n == 1 else "%s-%d" % (stem, n)
            f = top / name
            try:
                fd = os.open(str(f), os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
            except FileExistsError:
                continue
            with os.fdopen(fd, "wb") as fh:
                fh.write(data)
                fh.flush()
                os.fsync(fh.fileno())
            if f.read_bytes() != data:
                return None
            return f.relative_to(home).as_posix()
    except Exception:
        return None
    return None


def restore(home: Path, captured: dict, version: str, bases_out: dict | None = None) -> list:
    """After the new release is installed in <home>/plugins/qosha (NEW = what is there now), puts the person's changes
    back. Returns [{"file": rel, "how": "kept" | "merged" | "conflict"}] sorted by file (a conflict where the release
    had a folder or link in the way also names, under "aside", where that was moved). Writes only inside
    <home>/plugins/qosha. bases_out (optional dict) receives the real BASE of every file left as the person's own
    version, for record_installed()."""
    live = _live(home)
    if not live.is_dir():
        live.mkdir(parents=True, exist_ok=True)
    liver = live.resolve()
    report = []
    for rel in sorted(captured):
        ent = captured[rel]
        mine, base = ent.get("mine"), ent.get("base")
        if not isinstance(mine, (bytes, bytearray)):
            continue
        mine = bytes(mine)
        t, moved = _make_room(liver, rel, version)
        if t is None:
            continue                            # not a path inside the plugin (never produced by capture())
        if moved:
            # the release put a folder or link where the person's file is (or a file where it needs a folder): MINE
            # is kept in its place, the release's entry beside it
            _write(t, mine)
            report.append({"file": rel, "how": "conflict", "aside": moved})
            if bases_out is not None:
                bases_out[rel] = base
            continue
        new = t.read_bytes() if t.is_file() else None
        if new is None or new == base:
            _write(t, mine)
            report.append({"file": rel, "how": "kept"})
            if bases_out is not None:
                bases_out[rel] = base if new is None else new
            continue
        if new == mine:
            continue
        # a file the person added (no BASE) that the release now also brings: never merged against an invented empty
        # BASE (an added empty file would look "unchanged" and be silently replaced); MINE is kept, NEW saved beside it
        merged = merge3(base, mine, new) if base is not None else None
        if merged is not None:
            if merged != new:
                _write(t, merged)
                report.append({"file": rel, "how": "merged"})
                if bases_out is not None:
                    bases_out[rel] = new
            continue
        if rel in KEPT_ONCE_RECORDED:
            # the Home page, changed by both on the same lines: the update's Home stays in use (a kept old Home could
            # call code this update removed, and Home is the whole app), the person's version is saved OUTSIDE the
            # plugin folder (every install replaces that folder), never deleted (Ren, 18 Nov 2026: "Home: update
            # wins, yours saved"). If it cannot be saved safely, the person's version stays in use (conflict below).
            saved = _save_outside(home, rel, version, mine)
            if saved is not None:
                report.append({"file": rel, "how": "saved", "aside": [saved]})
                continue
        _write(t, mine)                         # the person's version first: nothing below can leave NEW in its place
        side = t.with_name("%s.qosha-%s.new" % (t.name, _safe_version(version)))
        try:
            _write(side, new)
        except OSError:
            pass                                # the release's copy is only a convenience (it is in the backup too)
        report.append({"file": rel, "how": "conflict"})
        if bases_out is not None:
            bases_out[rel] = base
    report.sort(key=lambda e: e["file"])
    return report


def put_back(home: Path, captured: dict) -> list:
    """Rollback: every captured file back exactly as it was before the update (MINE, byte for byte). Anything in the
    way is moved aside as <name>.qosha-rollback.new, never deleted."""
    live = _live(home)
    live.mkdir(parents=True, exist_ok=True)
    liver = live.resolve()
    done = []
    for rel in sorted(captured):
        mine = captured[rel].get("mine")
        if not isinstance(mine, (bytes, bytearray)):
            continue
        t, _moved = _make_room(liver, rel, "rollback")
        if t is None:
            continue
        if not t.is_file() or t.read_bytes() != bytes(mine):
            _write(t, bytes(mine))
        done.append(rel)
    return done


# --- never in the middle of a chat ------------------------------------------------------------------------------------
def wait_until_quiet(probe, sleep=time.sleep, clock=time.monotonic, max_s=1800, every_s=30) -> bool:
    """probe() -> True while a chat (or other engine work) is in progress. True as soon as probe() is False, checking
    again every every_s seconds; False once max_s has passed and it is still busy. A probe that raises counts as busy."""
    t0 = clock()
    while True:
        try:
            busy = bool(probe())
        except Exception:
            busy = True
        if not busy:
            return True
        left = max_s - (clock() - t0)
        if left <= 0:
            return False
        sleep(min(every_s, left))


# --- self-test (python3 -B keep_edits.py --selftest): cases beyond the frozen acceptance test ------------------------
def _selftest() -> int:
    import tempfile
    res = []
    tmp = Path(tempfile.mkdtemp(prefix="keepedits-self-"))

    def case(name, fn):
        try:
            fn()
            res.append(True)
            print("PASS " + name, flush=True)
        except Exception as e:
            res.append(False)
            print("FAIL %s :: %s %s" % (name, type(e).__name__, str(e)[:300]), flush=True)

    def put(top: Path, files: dict):
        for rel, data in files.items():
            p = top.joinpath(*rel.split("/"))
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)

    def home_with(name, files):
        h = tmp / name / "home"
        put(_live(h), files)
        return h

    def reinstall(h, files):
        shutil.rmtree(_live(h))
        put(_live(h), files)

    def c_adjacent():
        base = b"1\n2\n3\n4\n"
        assert merge3(base, b"1m\n2\n3\n4\n", b"1\n2n\n3\n4\n") == b"1m\n2n\n3\n4\n"
        # lines inserted just before / just after the other side's changed line: both kept
        assert merge3(base, b"1\nX\n2\n3\n4\n", b"1\n2n\n3\n4\n") == b"1\nX\n2n\n3\n4\n"
        assert merge3(base, b"1\n2\nX\n3\n4\n", b"1\n2n\n3\n4\n") == b"1\n2n\nX\n3\n4\n"
        # two different insertions at the same place: the order would be a guess -> conflict
        assert merge3(base, b"1\nX\n2\n3\n4\n", b"1\nY\n2\n3\n4\n") is None
        # an insertion inside a block the other side rewrote -> conflict
        assert merge3(base, b"1\n2\nX\n3\n4\n", b"1\nA\nB\n4\n") is None
        # a block rewritten on one side, one of its lines changed differently on the other -> conflict
        assert merge3(base, b"1\n2m\n3\n4\n", b"1\nA\nB\n4\n") is None

    def c_first_update_py():
        raw = b"import os\nx = os.getuid()\ny = 1\n"
        h = home_with("fpy", {"qosha_guard/a.py": raw + b"# mine\n", "qosha_guard/b.py": raw})
        fb = tmp / "fpy" / "candidate"
        put(fb, {"qosha_guard/a.py": raw, "qosha_guard/b.py": raw})
        cap = capture(h, fb)
        assert set(cap) == {"qosha_guard/a.py"}, cap
        new = b"import os\nx = os.getuid()\ny = 2\n"
        reinstall(h, {"qosha_guard/a.py": new, "qosha_guard/b.py": new})
        rep = restore(h, cap, "2.0")
        assert (_live(h) / "qosha_guard/a.py").read_bytes() == new + b"# mine\n"
        assert rep == [{"file": "qosha_guard/a.py", "how": "merged"}], rep

    def c_windows_port_not_captured():
        raw = b"import os\nimport fcntl\nx = os.getuid()\n"
        ported = _port_text(raw.decode()).replace("\n", "\r\n").encode()
        h = home_with("wport", {"q/a.py": ported, "q/b.py": raw.replace(b"\n", b"\r\n")})
        fb = tmp / "wport" / "candidate"
        put(fb, {"q/a.py": raw, "q/b.py": raw})
        assert capture(h, fb) == {}

    def c_dir_collision():
        h = home_with("dcol", {"p.css": b"p\n"})
        record_installed(h)
        put(_live(h), {"p.css": b"p mine\n"})
        cap = capture(h, tmp / "none")
        reinstall(h, {"p.css/inner.css": b"release\n"})
        rep = restore(h, cap, "3.0")
        assert (_live(h) / "p.css").read_bytes() == b"p mine\n"
        assert (_live(h) / "p.css.qosha-3.0.new" / "inner.css").read_bytes() == b"release\n"
        assert rep == [{"file": "p.css", "how": "conflict", "aside": ["p.css.qosha-3.0.new"]}], rep

    def c_parent_collision():
        h = home_with("pcol", {"k.css": b"k\n"})
        record_installed(h)
        put(_live(h), {"look/ren.css": b"mine\n"})
        cap = capture(h, tmp / "none")
        reinstall(h, {"k.css": b"k\n", "look": b"a file now\n"})
        rep = restore(h, cap, "3.1")
        assert (_live(h) / "look" / "ren.css").read_bytes() == b"mine\n"
        assert (_live(h) / "look.qosha-3.1.new").read_bytes() == b"a file now\n"
        assert rep and rep[0]["how"] == "conflict", rep

    def c_conflict_rollback():
        base = b"a\nb\nc\n"
        h = home_with("crb", {"s.html": base, "t.html": base})
        record_installed(h)
        put(_live(h), {"s.html": b"a\nB mine\nc\n", "t.html": b"a\nb\nc\nmine\n", "added.css": b"x\n"})
        before = {r: p.read_bytes() for r, p in _files(_live(h))}
        cap = capture(h, tmp / "none")
        reinstall(h, {"s.html": b"a\nB new\nc\n", "t.html": b"new\na\nb\nc\n"})
        rep = restore(h, cap, "4.0")
        assert [e["how"] for e in rep] == ["kept", "conflict", "merged"], rep
        reinstall(h, {"s.html": base, "t.html": base})          # the rollback puts the old release back first
        put_back(h, cap)
        assert {r: p.read_bytes() for r, p in _files(_live(h))} == before

    def c_successive():
        h = home_with("succ", {"c.html": b"1\n2\n3\n4\n5\n"})
        record_installed(h)
        put(_live(h), {"c.html": b"1\n2 mine\n3\n4\n5\n"})
        cap = capture(h, tmp / "none")
        reinstall(h, {"c.html": b"1\n2\n3\n4\n5 v2\n"})
        bases = {}
        assert restore(h, cap, "5.0", bases_out=bases) == [{"file": "c.html", "how": "merged"}]
        record_installed(h, bases=bases)
        cap2 = capture(h, tmp / "none")
        assert set(cap2) == {"c.html"}, cap2                     # still the person's change, against v2
        reinstall(h, {"c.html": b"0 v3\n1\n2\n3\n4\n5 v2\n"})
        assert restore(h, cap2, "6.0") == [{"file": "c.html", "how": "merged"}]
        assert (_live(h) / "c.html").read_bytes() == b"0 v3\n1\n2 mine\n3\n4\n5 v2\n"

    def c_added_collision():
        # files the person added (not in BASE) that the next release also brings: MINE kept byte for byte (an empty
        # one included), NEW saved beside it, a conflict reported; the rollback puts MINE back
        h = home_with("acol", {"k.css": b"k\n"})
        record_installed(h)
        put(_live(h), {"empty.css": b"", "mine.css": b".mine{color:blue}\n", "same.css": b".same{}\n"})
        before = {r: p.read_bytes() for r, p in _files(_live(h))}
        cap = capture(h, tmp / "none")
        assert set(cap) == {"empty.css", "mine.css", "same.css"}, cap
        reinstall(h, {"k.css": b"k\n", "empty.css": b".release{color:red}\n", "mine.css": b".release{color:red}\n",
                      "same.css": b".same{}\n"})
        rep = restore(h, cap, "7.0")
        assert rep == [{"file": "empty.css", "how": "conflict"}, {"file": "mine.css", "how": "conflict"}], rep
        assert (_live(h) / "empty.css").read_bytes() == b""
        assert (_live(h) / "mine.css").read_bytes() == b".mine{color:blue}\n"
        assert (_live(h) / "same.css").read_bytes() == b".same{}\n"
        assert (_live(h) / "empty.css.qosha-7.0.new").read_bytes() == b".release{color:red}\n"
        assert (_live(h) / "mine.css.qosha-7.0.new").read_bytes() == b".release{color:red}\n"
        reinstall(h, {"k.css": b"k\n"})                          # the rollback puts the old release back first
        put_back(h, cap)
        assert {r: p.read_bytes() for r, p in _files(_live(h))} == before

    case("S1 adjacent replacements merge; boundary insertions and rewritten blocks conflict", c_adjacent)
    case("S2 first update: a changed .py is captured and merged; an unchanged one is not", c_first_update_py)
    case("S3 first update: the Windows port and CRLF of a .py are not the person's change", c_windows_port_not_captured)
    case("S4 a folder where the person's file was: MINE kept, folder moved aside, conflict", c_dir_collision)
    case("S5 a file where the person's file needs a folder: moved aside, MINE kept", c_parent_collision)
    case("S6 kept, merged and conflict files are put back byte for byte by the rollback", c_conflict_rollback)
    case("S7 successive updates: the person's change is still theirs at the next update", c_successive)
    case("S8 an added file (empty included) the release also brings: MINE kept, NEW beside, conflict", c_added_collision)
    shutil.rmtree(tmp, ignore_errors=True)
    n, ok = len(res), sum(res)
    print("KEEP_EDITS SELFTEST %s %d/%d" % ("PASS" if ok == n else "FAIL", ok if ok == n else n - ok, n))
    return 0 if ok == n else 1


if __name__ == "__main__":
    import sys
    raise SystemExit(_selftest() if "--selftest" in sys.argv[1:] else 2)
