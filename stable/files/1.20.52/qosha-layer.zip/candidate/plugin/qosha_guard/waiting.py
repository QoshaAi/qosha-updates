"""Qosha never waits on the person in silence (Ren, 17 Nov 2026 evening, Renato's Windows PC: "qosha sent renato a
sign in tab, but never alerted him on the app that the tab was waiting for his action").

After every step in Qosha's browser (the engine's `browser_exec` tool) the page is looked at once more, with the
engine's own browser helpers (one short extra run of the same tool: nothing in the engine is changed). When it shows a
sign-in (a password field, a known sign-in site such as accounts.google.com, a "Sign in" page with a name or email
field), a sign-in code prompt or a "prove you are a person" check:
1. the step's result tells the model to stop and to say, in plain words: "<site> wants you to sign in. I opened it in
   the browser window: sign in there, then tell me 'done'." Until the person answers, every further browser step in
   that turn is refused with the same instruction, so Qosha cannot carry on as if nothing happened;
2. the browser window and that tab are brought to the front (unless the person chose "keep the browser window behind
   my other windows"); a browser working in the background (no window) is said plainly instead;
3. a "waiting for you" item is listed beside the questions waiting in a chat (the same small list Home reads:
   qosha/asks.json): Home shows "1 waiting for you · Finish signing in to <site>" with "Open chat".
It is cleared when the person writes anything in that chat (their reply goes to the model with a note: check the page
again and carry on, or stop if they cancelled), when a later step finds the page moved on, or from GET/POST /waiting.
Qosha never types a password or a sign-in code itself: a browser step that would is refused here.
Nothing here may raise into the engine; every part fails open (the step's own result is kept)."""
from __future__ import annotations

import json
import os
import re
import sys
import threading
import time
from typing import Any, Dict, Optional
from urllib.parse import urlsplit

try:
    from .i18n import tr
except ImportError:   # loaded as a single file (the dashboard's plugin_api.py loads it by its path)
    def tr(key, **kw):
        try:
            import importlib.util
            m = sys.modules.get("qosha_guard_i18n_file")
            if m is None:
                spec = importlib.util.spec_from_file_location(
                    "qosha_guard_i18n_file", os.path.join(os.path.dirname(os.path.abspath(__file__)), "i18n.py"))
                m = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(m)
                sys.modules["qosha_guard_i18n_file"] = m
            return m.tr(key, **kw)
        except Exception:   # the English text itself, straight from the catalog
            try:
                with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "locales", "en.json"), encoding="utf-8") as fh:
                    t = json.load(fh).get(key, key)
                return re.sub(r"\{(\w+)\}", lambda mm: str(kw.get(mm.group(1), mm.group(0))), t)
            except Exception:
                return str(key)

# The chat page can show a Continue button beside this message (see the report for chat.html); when it does, set True
# and the sentence also says "(or press Continue)".
CONTINUE_IN_CHAT = True
WAIT_MAX_S = 20 * 60          # a wait older than this no longer blocks browser steps (it still shows on Home)
PROBE_TIMEOUT_S = 20

# known sign-in sites: host -> the name said to the person
IDP = {
    "accounts.google.com": "Google", "login.microsoftonline.com": "Microsoft", "login.live.com": "Microsoft",
    "login.microsoft.com": "Microsoft", "appleid.apple.com": "Apple", "idmsa.apple.com": "Apple",
    "signin.aws.amazon.com": "Amazon Web Services", "login.yahoo.com": "Yahoo", "id.atlassian.com": "Atlassian",
    "login.salesforce.com": "Salesforce", "auth.openai.com": "OpenAI", "claude.ai/login": "Claude",
    "login.xero.com": "Xero", "accounts.intuit.com": "Intuit", "accounts.zoho.com": "Zoho",
    "login.mailchimp.com": "Mailchimp", "accounts.shopify.com": "Shopify", "app.hubspot.com/login": "HubSpot",
}
IDP_SUFFIX = {".okta.com": "Okta", ".auth0.com": "Auth0", ".onelogin.com": "OneLogin"}
_SIGNIN_PATH = re.compile(r"/(log-?in|sign-?in|signin|session|sso|auth(?:orize)?|oauth2?|ap/signin|account/login|"
                          r"users/sign_in|identifier|challenge)(?:[/?#._-]|$)", re.I)

# typing a password or a sign-in code: refused (Qosha's rule; the person signs in themselves). Matched on what the code
# types INTO (a password or code field), never on a word in a comment or in text typed elsewhere.
_SECRET_FIELD = re.compile(r"passw(?:or)?d|passwd|passcode|\bpwd\b|one-time-code|\botp\b|\btotp|\b2fa\b|\bmfa\b|"
                           r"verification|security[-_ ]?code|sms[-_ ]?code|\bpin\b|\botc\b", re.I)
_FILL = re.compile(r"fill_input\s*\(\s*(?:selector\s*=\s*)?([rRbBuU]?)(['\"])(.*?)\2", re.S)
_SECRET_INPUT = re.compile(r"type\s*=\s*\\?['\"]?password|autocomplete\s*=\s*\\?['\"]?one-time-code", re.I)
_TYPING = re.compile(r"type_text\s*\(|insert_?text|Input\.insertText|Input\.dispatchKeyEvent|send_keys\s*\(|"
                     r"\.value\s*=(?!=)|press_key\s*\(", re.I)
NEVER_TYPE = ("Qosha never types passwords or sign-in codes, so this step was not run. Do not try another way. "
              "Bring the sign-in page up in the browser window and tell the person, in plain words, to sign in there "
              "themselves and then tell you 'done'; end your turn there.")

_PROBE_JS = r"""(() => {
 const vis = (e) => { try { const r = e.getBoundingClientRect(); if (r.width < 4 || r.height < 4) return false;
   const s = getComputedStyle(e); return s.visibility !== 'hidden' && s.display !== 'none' && parseFloat(s.opacity || '1') > 0.05; } catch (x) { return false; } };
 const all = (sel) => { try { return Array.from(document.querySelectorAll(sel)).filter(vis); } catch (x) { return []; } };
 const typed = (e) => !/^(hidden|checkbox|radio|submit|button|image|file|reset|search)$/i.test(e.type || '');
 const pw = all('input[type=password]').length;
 const otp = all('input[autocomplete="one-time-code"],input[name*="otp" i],input[id*="otp" i],input[name*="totp" i],input[id*="totp" i],input[name*="mfa" i],input[name*="2fa" i],input[name*="verification" i],input[id*="verification" i],input[name="code"],input[id="code"],input[name="pin"],input[id="totpPin"],input[name="otc"]').filter(typed).length;
 const user = all('input[type=email],input[autocomplete~="username"],input[autocomplete~="email"],input[name*="user" i],input[name*="login" i],input[name*="email" i],input[id*="user" i],input[id*="login" i],input[id*="email" i],input[name="identifier"],input[id="identifierId"],input[name="loginfmt"]').filter(typed).length;
 const frames = Array.from(document.querySelectorAll('iframe')).filter(vis).map((f) => String(f.src || ''));
 const cap = frames.filter((s) => (/recaptcha\/(api2|enterprise)\/(anchor|bframe)/.test(s) && !/size=invisible/.test(s)) || /hcaptcha\.com/.test(s) || /challenges\.cloudflare\.com/.test(s)).length
   + all('.g-recaptcha:not([data-size=invisible]),.h-captcha,.cf-turnstile,#challenge-form,#cf-challenge-running').length;
 const body = String((document.body && document.body.innerText) || '').slice(0, 5000).toLowerCase();
 const heads = Array.from(document.querySelectorAll('h1,h2,legend,[role=heading]')).filter(vis).slice(0, 5).map((e) => String(e.innerText || '').trim().slice(0, 80)).join(' | ');
 const top = (String(document.title || '') + ' | ' + heads).toLowerCase();
 return JSON.stringify({u: location.href, t: String(document.title || '').slice(0, 120), h: heads.slice(0, 200), pw, otp, user, cap, len: body.length,
   human: /verify you are (a )?human|i'?m not a robot|are you a robot|checking (if the site connection is secure|your browser)|press (and|&) hold/.test(body) ? 1 : 0,
   code: /verification code|security code|2-step verification|two-step|two-factor|one-time (pass)?code|enter (the|your) code|we (just )?(sent|texted|emailed) (you )?(a|an|the) (\d-digit )?code|authenticator app/.test(body + ' ' + top) ? 1 : 0,
   signin: /\b(sign in|log in|login|sign-in|log-in|signin|logon|log on)\b/.test(top) ? 1 : 0});
})()"""

PROBE_CODE = (
    "# Checking the page\n"
    "import json as _qj\n"
    "_qd = False\n"
    "try:\n"
    "    _qd = 'dialog' in (page_info() or {})\n"
    "except Exception:\n"
    "    _qd = False\n"
    "_qp = None\n"
    "if not _qd:\n"
    "    try:\n"
    "        _qp = js(" + repr(_PROBE_JS) + ")\n"
    "    except Exception:\n"
    "        _qp = None\n"
    "_qt = []\n"
    "try:\n"
    "    for _x in (cdp('Target.getTargets') or {}).get('targetInfos', []):\n"
    "        if _x.get('type') == 'page':\n"
    "            _qt.append({'id': str(_x.get('targetId') or ''), 'u': str(_x.get('url') or '')[:400]})\n"
    "except Exception:\n"
    "    pass\n"
    "_qc = ''\n"
    "try:\n"
    "    _qc = str(current_tab().get('targetId') or '')\n"
    "except Exception:\n"
    "    pass\n"
    "print('QOSHA_PROBE ' + _qj.dumps({'page': _qp, 'tabs': _qt[:20], 'cur': _qc, 'dialog': bool(_qd)}))\n"
)


def _front_code(target: str) -> str:
    return ("# Showing the sign-in page\n"
            "try:\n"
            "    cdp('Target.activateTarget', targetId=%r)\n"
            "except Exception:\n"
            "    pass\n"
            "try:\n"
            "    cdp('Page.bringToFront')\n"
            "except Exception:\n"
            "    pass\n"
            "print('ok')\n") % (target,)


# ---- what the page shows -----------------------------------------------------------------------------------------
def _host(url: str) -> str:
    try:
        h = (urlsplit(url).hostname or "").lower()
    except Exception:
        return ""
    return h[4:] if h.startswith("www.") else h


def _idp(url: str) -> str:
    h = _host(url)
    if not h:
        return ""
    try:
        path = urlsplit(url).path or "/"
    except Exception:
        path = "/"
    for key, name in IDP.items():
        if "/" in key:
            kh, kp = key.split("/", 1)
            if h == kh and path.lstrip("/").startswith(kp):
                return name
        elif h == key:
            return name
    for suf, name in IDP_SUFFIX.items():
        if h.endswith(suf):
            return name
    return ""


def site_name(url: str) -> str:
    return _idp(url) or _host(url) or "This website"


def classify(facts: Any) -> Optional[Dict[str, str]]:
    """facts = what the probe saw. Returns {"why": signin|code|captcha, "site", "url"} when the person is needed."""
    if not isinstance(facts, dict):
        return None
    page = facts.get("page")
    if isinstance(page, str):
        try:
            page = json.loads(page)
        except Exception:
            page = None
    hit = None
    if isinstance(page, dict):
        url = str(page.get("u") or "")
        if url.startswith(("http://", "https://")):
            n = lambda k: int(page.get(k) or 0)   # noqa: E731
            try:
                path = urlsplit(url).path or "/"
            except Exception:
                path = "/"
            signin_path = bool(_SIGNIN_PATH.search(path))
            title = str(page.get("t") or "").lower()
            gate = any(w in title for w in ("just a moment", "attention required", "access denied", "are you a robot",
                                            "security check", "verify you are human"))
            why = ""
            if n("cap") > 0 or (n("human") > 0 and (gate or n("len") < 1500)):
                why = "captcha"
            elif n("otp") > 0 or (n("code") > 0 and (signin_path or _idp(url) or n("signin") > 0)):
                why = "code"
            elif n("pw") > 0:
                why = "signin"
            elif _idp(url):
                why = "signin"
            elif n("user") > 0 and (signin_path or n("signin") > 0):
                why = "signin"
            if why:
                hit = {"why": why, "site": site_name(url), "url": url, "target": str(facts.get("cur") or "")}
    if hit is None:
        # a sign-in opened in another tab or a pop-up (for example "Continue with Google")
        for t in facts.get("tabs") or []:
            u = str((t or {}).get("u") or "") if isinstance(t, dict) else str(t or "")
            if u.startswith("https://") and _idp(u):
                hit = {"why": "signin", "site": site_name(u), "url": u, "target": str((t or {}).get("id") or "") if isinstance(t, dict) else ""}
                break
    return hit


def sentence(hit: Dict[str, str], headed: bool = True) -> str:
    site = hit.get("site") or tr("wait.this_website")
    tail = tr("wait.or_continue") if CONTINUE_IN_CHAT else ""
    if not headed:
        return tr("wait.sentence.background", site=site)
    if hit.get("why") == "code":
        return tr("wait.sentence.code", site=site, tail=tail)
    if hit.get("why") == "captcha":
        return tr("wait.sentence.captcha", site=site, tail=tail)
    return tr("wait.sentence.signin", site=site, tail=tail)


def title_for(hit: Dict[str, str]) -> str:
    site = hit.get("site") or tr("wait.a_website")
    return {"code": tr("wait.title.code"), "captcha": tr("wait.title.captcha")}.get(
        hit.get("why") or "", tr("wait.title.signin")) % site


def stop_note(hit: Dict[str, str], headed: bool = True) -> str:
    what = {"code": "asks for a sign-in code", "captcha": "shows a check that the visitor is a person"}.get(
        hit.get("why") or "", "is a sign-in page")
    after = ("When they say they are done, look at the page again and carry on with the task; if it still asks to "
             "sign in, say so plainly and wait again." if headed else
             "When they ask for the window, set browser.headed to true in your settings yourself, open the page "
             "again and wait for them to sign in.")
    return ("STOP: the page in Qosha's browser %s (%s). The person must do this themselves. Never type a password, a "
            "code or a check answer, and do not guess or work around it. Call no more tools in this turn. End your "
            "turn now by telling the person, in their language, exactly: \"%s\" %s"
            % (what, hit.get("site") or "the website", sentence(hit, headed), after))


# ---- the list Home reads (qosha/asks.json, shared with ask.py) ---------------------------------------------------
_LOCK = threading.Lock()


def _ask_mod():
    try:
        from . import ask as m   # inside the plugin
        return m
    except Exception:
        pass
    m = sys.modules.get("qosha_ask_read_waiting")
    if m is not None:
        return m
    import importlib.util
    from pathlib import Path
    spec = importlib.util.spec_from_file_location("qosha_ask_read_waiting", Path(__file__).resolve().with_name("ask.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    sys.modules["qosha_ask_read_waiting"] = m
    return m


def _edit(fn) -> list:
    with _LOCK:
        return _ask_mod()._asks_edit(fn)


def pending(session: str = "") -> list:
    """The "waiting for you" items (only these: not the questions on approval cards)."""
    try:
        items = _edit(lambda cur: None)
    except Exception:
        return []
    return [x for x in items if str(x.get("id") or "").startswith("wait-") and (not session or x.get("session") == session)]


def open_wait(session: str, hit: Dict[str, str], headed: bool = True) -> dict:
    now = time.time()
    url = str(hit.get("url") or "")
    try:
        p = urlsplit(url)
        bare = "%s://%s%s" % (p.scheme, p.netloc, p.path)   # no query: sign-in links carry tokens
    except Exception:
        bare = ""
    item = {"id": "wait-%d" % int(now * 1000), "at": now, "kind": "wait." + (hit.get("why") or "signin"),
            "title": title_for(hit), "site": hit.get("site") or "", "why": hit.get("why") or "signin", "url": bare[:300],
            "rows": [[tr("wait.row.where"), tr("wait.where.window") if headed else tr("wait.where.background")],
                     [tr("wait.row.what"), sentence(hit, headed)],
                     [tr("wait.row.why"), tr("wait.why")]],
            "session": session or "", "session_key": "qosha-wait:" + (session or ""), "text": "wait:" + (session or ""),
            "pid": os.getpid()}

    def put(cur):
        same = [x for x in cur if str(x.get("id") or "").startswith("wait-") and x.get("session") == (session or "")
                and x.get("site") == item["site"] and x.get("why") == item["why"]]
        if same:   # already listed: keep its id and time
            return None
        return [x for x in cur if not (str(x.get("id") or "").startswith("wait-") and x.get("session") == (session or ""))] + [item]
    try:
        _edit(put)
    except Exception:
        pass
    return item


def clear(session: Optional[str] = None, wid: str = "") -> list:
    """Remove waits (of one chat, or one by id). Returns what was removed."""
    gone: list = []

    def drop(cur):
        keep = []
        for x in cur:
            mine = str(x.get("id") or "").startswith("wait-")
            if mine and ((wid and x.get("id") == wid) or (not wid and session is not None and x.get("session") == session)):
                gone.append(x)
            else:
                keep.append(x)
        return keep if gone else None
    try:
        after = _edit(drop)
    except Exception:
        return []
    still = {x.get("id") for x in (after or []) if isinstance(x, dict)}
    return [x for x in gone if x.get("id") not in still]      # only what really left the list (GPT asks-verify HIGH 1)


# ---- the browser ---------------------------------------------------------------------------------------------------
def _browser_cfg() -> dict:
    try:
        from hermes_cli.config import load_config
        return dict((load_config() or {}).get("browser") or {})
    except Exception:
        return {}


def _truthy(v) -> bool:
    return str(v).strip().lower() in ("true", "1", "yes", "on")


def enabled() -> bool:
    return _browser_cfg().get("qosha_signin_wait", True) is not False and not os.environ.get("QOSHA_NO_SIGNIN_WAIT")


def _run_exec(code: str, args: dict, task_id: str) -> Optional[dict]:
    from tools.browser_use_cli import browser_exec
    raw = browser_exec(code=code, session=str((args or {}).get("session") or ""), timeout_s=PROBE_TIMEOUT_S,
                       task_id=task_id or None, local=bool((args or {}).get("local", False)))
    try:
        return json.loads(raw) if isinstance(raw, str) else (raw if isinstance(raw, dict) else None)
    except Exception:
        return None


def probe(args: dict, task_id: str = "") -> Optional[dict]:
    out = _run_exec(PROBE_CODE, args, task_id)
    text = str((out or {}).get("output") or "")
    m = re.search(r"^QOSHA_PROBE (\{.*\})\s*$", text, re.M)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except Exception:
        return None


def _qosha_browser_pid() -> int:
    """The main process of the browser Qosha started (its profile lies inside Qosha's home); 0 when not found."""
    import subprocess
    try:
        from hermes_constants import get_hermes_home
        home = str(get_hermes_home())
    except Exception:
        return 0
    homes = {home, os.path.realpath(home)}
    try:
        if os.name == "nt":
            ps = ("Get-CimInstance Win32_Process -Filter \"Name='chrome.exe' OR Name='msedge.exe' OR Name='chromium.exe'\" | "
                  "ForEach-Object { \"$($_.ProcessId)`t$($_.CommandLine)\" }")
            txt = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True,
                                 text=True, timeout=15, creationflags=0x08000000).stdout
        else:
            txt = subprocess.run(["ps", "-axo", "pid=,command="], capture_output=True, text=True, timeout=5).stdout
            txt = "\n".join(l.strip().replace(" ", "\t", 1) for l in txt.splitlines())
    except Exception:
        return 0
    for line in txt.splitlines():
        pid, _, cmd = line.partition("\t")
        if "--type=" in cmd:
            continue
        low = cmd.replace("\\", "/").lower()
        if any(("--user-data-dir=" + h.replace("\\", "/").lower()) in low or ('--user-data-dir="' + h.replace("\\", "/").lower()) in low
               for h in homes):
            try:
                return int(pid.strip())
            except Exception:
                continue
    return 0


def _os_front(pid: int) -> bool:
    """Bring the browser's window in front of the other apps; asks the system for nothing new (no permission)."""
    import subprocess
    if not pid:
        return False
    try:
        if sys.platform == "darwin":
            js = "ObjC.import('AppKit'); var a = $.NSRunningApplication.runningApplicationWithProcessIdentifier(%d); a ? a.activateWithOptions(3) : false" % pid
            r = subprocess.run(["osascript", "-l", "JavaScript", "-e", js], capture_output=True, text=True, timeout=5)
            return r.returncode == 0
        if os.name == "nt":
            ps = "Add-Type -AssemblyName Microsoft.VisualBasic; [Microsoft.VisualBasic.Interaction]::AppActivate(%d)" % pid
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True,
                               text=True, timeout=15, creationflags=0x08000000)
            return r.returncode == 0
    except Exception:
        return False
    return False


def bring_front(args: dict, task_id: str, hit: Dict[str, str], br: dict) -> None:
    try:
        _run_exec(_front_code(hit.get("target") or ""), args, task_id)   # that tab, in front inside the browser
    except Exception:
        pass
    if br.get("qosha_stay_behind") is True:
        return   # the person chose "keep the browser window behind my other windows": the chat and Home tell them

    def later():
        try:
            _os_front(_qosha_browser_pid())
        except Exception:
            pass
    threading.Thread(target=later, name="qosha-signin-front", daemon=True).start()


def _log():
    import logging
    return logging.getLogger("qosha.waiting")


# ---- hooks ---------------------------------------------------------------------------------------------------------
def _browser_tool(tool_name: str, args: Any) -> str:
    name = str(tool_name or "")
    if name == "tool_call" and isinstance(args, dict):
        name = str(args.get("name") or "")
    return name if name.startswith("browser") else ""


def _code(tool_name: str, args: Any) -> str:
    if not isinstance(args, dict):
        return ""
    if tool_name == "tool_call":
        args = args.get("arguments") if isinstance(args.get("arguments"), dict) else args
    try:
        return args.get("code") if isinstance(args.get("code"), str) else json.dumps(args)[:20000]
    except Exception:
        return ""


def types_secret(code: str) -> bool:
    """True when the code types into a password or sign-in code field."""
    if not code:
        return False
    body = "\n".join(l for l in code.splitlines() if not l.lstrip().startswith("#"))
    if any(_SECRET_FIELD.search(m.group(3)) for m in _FILL.finditer(body)):
        return True
    return bool(_SECRET_INPUT.search(body)) and bool(_TYPING.search(body))


def pre_tool_call(tool_name: str = "", args: Any = None, session_id: str = "", **_: Any) -> Optional[Dict[str, str]]:
    try:
        if not _browser_tool(tool_name, args):
            return None
        if _browser_tool(tool_name, args) == "browser_vault":
            return None   # the engine's own password-manager fill, set up by the person themselves
        if types_secret(_code(tool_name, args)):
            return {"action": "block", "message": NEVER_TYPE}   # always, also with the sign-in wait switched off
        if not enabled():
            return None
        for w in pending(session_id or ""):
            if time.time() - float(w.get("at") or 0) < WAIT_MAX_S and int(w.get("pid") or 0) == os.getpid():
                hit = {"why": w.get("why") or "signin", "site": w.get("site") or ""}
                return {"action": "block", "message": stop_note(hit, _truthy(_browser_cfg().get("headed", True)))}
    except Exception:
        return None
    return None


def transform_tool_result(tool_name: str = "", args: Any = None, result: Any = None, session_id: str = "",
                          task_id: str = "", **_: Any) -> Optional[str]:
    if tool_name != "browser_exec" or not isinstance(args, dict):
        return None
    try:
        if not enabled():
            return None
        if isinstance(result, str):
            try:
                parsed = json.loads(result)
            except Exception:
                parsed = None
            if isinstance(parsed, dict) and "exit_code" not in parsed:
                return None   # the step itself could not run (no browser, timed out): nothing to look at
        t0 = time.time()
        facts = probe(args, task_id)
        hit = classify(facts)
        _log().info("sign-in check after a browser step: %s in %d ms", (hit or {}).get("why") or ("none" if facts is not None else "no answer"),
                    int((time.time() - t0) * 1000))
        if not hit:
            if facts is not None:
                clear(session_id or "")   # the page moved on: nothing waits any more
            return None
        br = _browser_cfg()
        headed = _truthy(br.get("headed", True))
        open_wait(session_id or "", hit, headed)
        if headed:
            bring_front(args, task_id, hit, br)
        note = stop_note(hit, headed)
        if isinstance(result, str):
            try:
                parsed = json.loads(result)
                if isinstance(parsed, dict):
                    parsed["qosha_waiting_for_person"] = note
                    return json.dumps(parsed, ensure_ascii=False)
            except Exception:
                pass
            return result + "\n\n" + note
        return None   # a picture result: the next browser step is refused with the same note
    except Exception:
        return None


def pre_llm_call(session_id: str = "", user_message: str = "", **_: Any) -> Optional[Dict[str, str]]:
    """The person wrote in that chat: the wait is over (done, cancelled or something else); the model is told."""
    try:
        gone = clear(session_id or "")
    except Exception:
        gone = []
    if not gone:
        return None
    w = gone[-1]
    what = {"code": "enter a sign-in code on", "captcha": "finish a check on"}.get(w.get("why") or "", "sign in to")
    return {"context": ("Qosha note: you had stopped and asked the person to %s %s in the browser window. Their message "
                        "is their answer. If they say they are done (or pressed Continue), look at the page again and "
                        "carry on with the task; if it still asks for them, say so in one plain sentence and wait again. "
                        "If they want to stop or cancel, stop that task. Never type passwords or codes yourself."
                        % (what, w.get("site") or "the website"))}


def register(ctx) -> None:
    for name in ("pre_tool_call", "transform_tool_result", "pre_llm_call"):
        try:
            ctx.register_hook(name, globals()[name])
        except Exception:
            pass


# ---- the small API (mounted at /api/plugins/qosha/waiting; see the report for the plugin_api.py lines) --------------
try:
    from fastapi import APIRouter
    from fastapi.responses import JSONResponse

    router = APIRouter()

    def _j(content, status=200):
        return JSONResponse(status_code=status, content=content, headers={"Cache-Control": "no-store"})

    @router.get("")
    @router.get("/")
    def list_waiting(session: str = ""):
        """Everything waiting for the person: the sign-in waits (items) and the count of all questions waiting in a
        chat plus these (count), for the page title."""
        try:
            allx = _edit(lambda cur: None)
        except Exception:
            allx = []
        waits = [x for x in allx if str(x.get("id") or "").startswith("wait-") and (not session or x.get("session") == session)]
        keep = ("id", "at", "kind", "title", "site", "why", "session", "rows")
        return _j({"items": [{k: x.get(k) for k in keep} for x in waits], "count": len(allx)})

    @router.post("/{wid}/clear")
    def clear_one(wid: str):
        if not re.fullmatch(r"wait-\d{1,16}", wid or ""):
            return _j({"error": "bad_request"}, 400)
        return _j({"cleared": len(clear(None, wid))})
except Exception:   # no web framework here (the agent's own process): the hooks above still work
    router = None
