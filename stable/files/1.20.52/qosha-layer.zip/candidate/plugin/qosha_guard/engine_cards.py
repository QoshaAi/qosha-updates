"""Every engine approval card is answered in Qosha's trusted approval window (trusted_dialog.py), never by a page.

Ren's cards, 23 Nov 2026 ~19:00 MST ("Go (Recommended)", "Keep Always allow (Recommended)"), council option B, H1/H5.

The engine asks a person through one door: tools.approval._await_gateway_decision enqueues the card, calls the
session's notify callback (the chat page's socket) and waits until resolve_gateway_approval commits an answer. With the
trusted surface on, in every Qosha engine process:
- the notify callback first opens the approval window on a worker thread; the page still hears about the card (so it
  can say "answer in the Qosha approval window"), but nothing it sends can answer;
- resolve_gateway_approval commits an answer only from that worker (a capability object only this module holds, set in
  a context variable for the worker's own call). approval.respond, a page's answer frame, a messaging /approve, a card
  tap: all resolve nothing;
- "Always allow for this kind" is offered where Ren's rule allows it (never safety code, unreadable commands, one-run
  keys or a key the engine says can't be kept); an "always" answer is written to the grant record (grants.py) with
  the surface "trusted-dialog" before it is committed (H5: a saved Always allow counts only with its record).
"""
from __future__ import annotations

import contextvars
import os
import logging
import re
import threading
from typing import Any, Optional

from . import trusted_dialog as td

def _floor_marker() -> bool:
    """The native floor (council RC6): once this install answered approvals only in Qosha's approval window, the
    marker keeps it so in every later build that honours it (a rollback to N included), without patching any file."""
    try:
        from hermes_constants import get_default_hermes_root
        root = str(get_default_hermes_root())
    except Exception:
        root = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    try:
        return os.path.exists(os.path.join(root, "qosha", "native-approval.json"))
    except Exception:
        return True


log = logging.getLogger("qosha.engine_cards")

ON = False                    # slice 6 turns the trusted surface on (until then: unchanged behavior)
# Pages free of the self-change card: a separate switch, OFF until every plugin route a page can call is audited
# (verification on the switch-on candidate, TS-C-1/C-2: a page's script can call routes that relied on the page's own
# confirmation, e.g. Files delete, Ask Gemini). With ON alone, pages still ask exactly as on 1.20.39.
PAGES_FREE = False
_CAP = object()               # only this module's worker holds it
def _ready() -> dict:
    """One readiness per process, shared with approval_gate/window_gate (default: not ready until register() set
    every hook) (TS-M2-03)."""
    import sys
    import types
    st = sys.modules.get("_qosha_window_gate_state")
    if st is None:
        st = types.ModuleType("_qosha_window_gate_state")
        st.allowed, st.ready = object(), {"ok": False}
        sys.modules["_qosha_window_gate_state"] = st
    return st.ready


READY = _ready()              # set by approval_gate.register: every approval hook of this process is in place
_answering = contextvars.ContextVar("qosha_trusted_answer", default=None)
NOT_HERE = ("Qosha's approvals are answered in the Qosha approval window on this computer, not here. Look for the "
            "window titled \"Qosha approval\" (or open the Qosha app and choose Show the approval window).")
_NO_ALWAYS = ("approval.self", "unread", ":once-", "screen.read")
# preference questions the page asks and answers itself (not an approval of an action): the browser window's place
PAGE_QUESTIONS = frozenset({"plugin_rule:qosha:browser.window"})


def _page_question(data_or_key) -> bool:
    if isinstance(data_or_key, dict):
        keys = [data_or_key.get("pattern_key")] + list(data_or_key.get("pattern_keys") or [])
    else:
        keys = [data_or_key]
    keys = [str(k) for k in keys if k]
    return bool(keys) and all(k in PAGE_QUESTIONS for k in keys)


def _entry_data(session_key, request_id) -> dict:
    """The live entry's own data (all its keys), or {} (TS-G-09: one predicate everywhere: every key a page question)."""
    try:
        from tools import approval as ap
        with ap._lock:
            for e in ap._gateway_queues.get(session_key, []):
                if request_id and e.data.get("request_id") == request_id:
                    return dict(e.data)
    except Exception:
        pass
    return {}


NATIVE_FLOOR = True           # this build honours the native floor marker (an updater may install it after the marker)


def enabled() -> bool:
    return bool(ON) or _floor_marker()


def mark_native(home=None) -> bool:
    """H4: record (once) that this install answers approvals only in the window; the updater then refuses any release
    that would bring page-answered approvals back. Never removed by Qosha."""
    import json
    import os
    import time
    try:
        if home is None:
            try:
                from hermes_constants import get_default_hermes_root      # the main home (the updater reads it)
                home = get_default_hermes_root()
            except Exception:
                home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
        d = os.path.join(str(home), "qosha")
        p = os.path.join(d, "native-approval.json")
        if os.path.exists(p):
            return True
        os.makedirs(d, exist_ok=True)
        with open(p, "w", encoding="utf-8") as fh:
            json.dump({"since": time.time(), "why": "approvals are answered only in Qosha's approval window"}, fh)
        return True
    except Exception:
        return False


def kind_of(pattern_key: str) -> str:
    """The window's kind (its title) from the card's rule key; anything unknown is a generic approval."""
    k = str(pattern_key or "")
    q = k.split("plugin_rule:qosha:", 1)[1] if k.startswith("plugin_rule:qosha:") else ""
    if not q:
        return "run"                                   # the engine's own command / code cards
    if q.startswith("approval.self"):
        return "self"
    if q.startswith("browser.profile"):
        return "browser_profile"
    if q.startswith("desktop") or q.startswith("screen"):
        return "desktop"
    if q.startswith("v2:"):
        q = q[3:]                                      # Ren's per-kind keys (qosha:v2:<kind>)
    base = q.split(":", 1)[0].lower()
    for word, kind in (("pay", "pay"), ("purchase", "pay"), ("delete", "delete"), ("trash", "delete"),
                       ("remove", "delete"), ("share", "share"), ("send", "send"), ("reply", "send"),
                       ("forward", "send"), ("post", "send"), ("message", "send")):
        if word in base:
            return kind
    if base.startswith("engine") or base in ("unclear", "run", "shell", "terminal"):
        return "run"
    return "other"


def may_always(data: dict) -> bool:
    """Always allow only for Qosha's own per-kind keys (whose saved grant needs the window's record); never for the
    engine's generic command keys, safety code, unreadable commands or one-run keys (TS-G-10)."""
    keys = [str(data.get("pattern_key") or "")] + [str(k) for k in (data.get("pattern_keys") or [])]
    keys = [k for k in keys if k]
    if data.get("allow_permanent") is False or data.get("smart_denied") or not keys:
        return False
    if not all(k.startswith("plugin_rule:qosha:") for k in keys):
        return False
    return not any(bad in k for k in keys for bad in _NO_ALWAYS)


CARD_ID = re.compile(r"^\[\[qosha:card (c_[0-9a-f]{24})\]\] ")
# rows Qosha's cards use for where a step goes or what it moves: pinned first, each with its own role, never cut
ROLE_OF = {"to": "to", "recipient": "to", "recipients": "to", "cc": "cc", "bcc": "bcc", "attendees": "guests",
           "guests": "guests", "invite": "guests", "share with": "shared_with", "shared with": "shared_with",
           "email": "shared_with", "grantee": "shared_with", "forward to": "forward_to", "channel": "channel",
           "chat": "chat", "amount": "amount", "total": "amount", "file": "target", "path": "target",
           "target": "target", "website": "target", "account": "account", "google account": "account",
           "from": "from", "para": "to", "valor": "amount",
           # what a delete / change acts on (TS-R-G-06): a file, an event, a message
           # what a delete / change acts on: a file, an event, a message (an object, never a payee or grantee)
           "file id": "object", "name": "object", "event": "object", "event id": "object", "message id": "object",
           "payee": "to", "pay to": "to"}
# no "link access" / "audience" role: such row labels come from any tool's argument names, and no reading of their
# words is safe ("No public access"); Qosha's own share tool always names a person (its "Email" row). A share card
# that names no person stays Decline only (slice 7 verification, 24 Nov 2026)
_NEEDS_ROLE = ("send", "pay", "delete", "share")
# the facts each kind must pin before Allow (Account / From never count: they say who acts, not where it goes)
# each kind: every group must have one pinned fact (a share names who gets it; a payment its amount AND its payee)
_DEST = {"send": [("to", "cc", "bcc", "guests", "forward_to", "channel", "chat")], "share": [("shared_with", "to")],
         "delete": [("target", "object")], "pay": [("amount",), ("to",)]}


def _role_of(label: str):
    """A row's role from its label, in English or in the person's language (ask.row_label's own translation)."""
    lab = label.strip().lower()
    if lab in ROLE_OF:
        return ROLE_OF[lab]
    for m in _ask_modules():
        rl = getattr(m, "row_label", None)
        if rl is None:
            continue
        for en, role in ROLE_OF.items():
            for form in dict.fromkeys((en.capitalize(), en.title(), en)):     # "File id", "Share With", "to"
                try:
                    if str(rl(form)).strip().lower() == lab:
                        return role
                except Exception:
                    continue
    return None


def _take_card(cid: str):
    """Pop the card's record (used once) from whichever loaded copy of ask.py issued it."""
    for mod in _ask_modules():
        cards = getattr(mod, "_CARDS", None)
        if isinstance(cards, dict) and cid in cards:
            return cards.pop(cid)
    return None


def _same_card(record: dict, description: str) -> bool:
    """The engine shows a cleaned copy of the card's message: it must be the cleaned copy of THIS record's message."""
    msg = str(record.get("message") or "")
    if msg == description:
        return True
    try:
        from agent.redact import redact_approval_display
        return redact_approval_display(msg) == description
    except Exception:
        return False


def _facts_and_text(data: dict) -> tuple:
    """(facts, text, blind) for the window. Facts come from the card's own record, found by the id Qosha put at the
    start of the card (never by searching text: TS-C2-5): every recipient / amount / target row pinned with its role,
    the title as the action; every other row in the scrolling text. No record, or a record that is not this card:
    the card offers no Allow (blind)."""
    desc, cmd = str(data.get("description") or ""), str(data.get("command") or "")
    text = desc if not cmd or cmd == desc else (desc + "\n\n----\n" + cmd)
    m = CARD_ID.match(desc)
    key = str(data.get("pattern_key") or "")
    if not m:
        if key.startswith("plugin_rule:qosha:") and kind_of(key) in _NEEDS_ROLE:
            return [("@Action", NO_RECORD)], text, True
        return [], text, False                          # the engine's own command cards: the text is the step
    record = _take_card(m.group(1))
    if not record or not _same_card(record, desc):
        return [("@Action", NO_RECORD)], text, True
    facts, others = [("@Action", str(record.get("title") or ""))], []
    for row in record.get("rows") or []:
        if len(row) < 2:
            continue
        label, value = str(row[0]), row[1]
        role = _role_of(label)
        if role:
            values = value if isinstance(value, (list, tuple)) else [value]
            for v in values:
                v = " ".join(str(v).split())                  # newlines / controls collapsed (council RC1)
                if v:
                    facts.append((role, v))
        else:
            others.append("%s: %s" % (label, value))
    need = _DEST.get(kind_of(key)) or []
    if any(not any(k in group and v for k, v in facts) for group in need):
        return [("@Action", NO_RECORD)], text, True     # a send/pay/delete/share card must say where it goes (G-06)
    # what the person reads, once (TS-R-G-08): no internal marks, and a row already in the card's text not repeated
    shown = desc[m.end():]                       # shown exactly as written: no line is ever removed (TS-S7-1)
    extra = [o for o in others if o not in shown]
    text = shown if not cmd or cmd == desc else (shown + "\n\n----\n" + cmd)
    if extra:
        text = "\n".join(extra) + "\n\n----\n" + text
    return facts, text, False


# only Qosha's own reason lines: at the start of a line, a code and an identifier-like argument; never text a person
# or the AI wrote (a "[[qosha:x Please wire ...]]" line stays visible: TS-R2-1)
_MARKS = re.compile(r"(?m)^\[\[qosha:reason [a-z_]+(?: [A-Za-z0-9_.:+-]{0,80})?\]\]\n?")


NO_RECORD = "Qosha could not show this step's details reliably. Decline, then ask Qosha again."


def _ask_modules() -> list:
    """Loaded copies of ask.py (its card records live there), found by file next to this one."""
    import os
    import sys
    here = os.path.join(os.path.dirname(os.path.realpath(__file__)), "ask.py")
    out = []
    for m in list(sys.modules.values()):
        try:
            if m is not None and os.path.realpath(getattr(m, "__file__", "") or "") == here:
                out.append(m)
        except Exception:
            continue
    return out


def _lang() -> str:
    try:
        from . import i18n
        return str(i18n.lang() or "en")
    except Exception:
        return "en"


# ---- how each card ended, for the page (P0 27 Nov 2026: a card always shows a final state, never grey buttons) --------
_OUTCOMES: dict = {}          # engine request id -> "once" | "always" | "deny" | "withdrawn"
_outlock = threading.Lock()


def _record_outcome(rid: str, decision, keys=None) -> None:
    if not rid:
        return
    d = decision if isinstance(decision, dict) else {}
    ch = str(d.get("choice") or "")
    if d.get("resolved") and not d.get("cancelled") and ch in ("once", "session", "always", "deny"):
        state = ch                                        # "session": allowed for this chat (never understated)
        if ch == "always" and keys is not None:
            try:      # with the window on, an Always counts only once its grant is saved: else it was this time only
                from . import grants
                if not any(grants.has(k) for k in keys):
                    state = "once"
            except Exception:
                state = "once"
    else:
        state = "withdrawn"                               # timed out, stopped, the chat closed: nothing was allowed
    with _outlock:
        _OUTCOMES[rid] = state
        while len(_OUTCOMES) > 500:
            _OUTCOMES.pop(next(iter(_OUTCOMES)))


def outcome(rid: str) -> str:
    """How the card with this engine request id ended: once / always / deny / withdrawn, "pending" while it still
    waits, "unknown" when this process never saw it."""
    rid = str(rid or "")
    if not rid:
        return "unknown"
    with _outlock:
        got = _OUTCOMES.get(rid)
    if got:
        return got
    try:
        from tools import approval as ap
        with ap._lock:
            if any(str((e.data or {}).get("request_id") or "") == rid for q in ap._gateway_queues.values() for e in q):
                return "pending"
    except Exception:
        pass
    return "unknown"


def _ask_and_resolve(session_key: str, data: dict, resolve, seen: Optional[dict] = None) -> None:
    """The window worker: never leaves a card hanging (any error = a decline for this request: TS-G-15)."""
    try:
        return _ask_and_resolve_inner(session_key, data, resolve, seen)
    except Exception as e:
        log.warning("approval window: declined (%s)", e.__class__.__name__)
        rid = str((data or {}).get("request_id") or "")
        if rid:
            try:
                resolve(session_key, "deny", request_id=rid)
            except Exception:
                pass


def _ask_and_resolve_inner(session_key: str, data: dict, resolve, seen: Optional[dict] = None) -> None:
    rid = str(data.get("request_id") or "")
    kind = kind_of(data.get("pattern_key"))
    always = may_always(data)
    facts, text, blind = _facts_and_text(data)
    cancel = threading.Event()
    watch = threading.Thread(target=_watch_entry, args=(session_key, rid, cancel), daemon=True)
    watch.start()
    try:
        ans = td.ask(kind, text, {"request": rid, "command": data.get("command"), "keys": data.get("pattern_keys")},
                     facts=facts, always=always and not blind, lang=_lang(), cancel=cancel, allow=not blind)
    finally:
        cancel.set()
    choice = ans.choice if ans.choice in ("once", "always") else "deny"
    if not rid:
        choice = "deny"                                  # an answer must name its request (TS-G-07)
    keys = [k for k in (data.get("pattern_keys") or [data.get("pattern_key")]) if k]
    if choice == "always":
        try:
            from . import grants
            if not grants.can_record():
                choice = "once"                          # no grant could be recorded: this time only
        except Exception:
            choice = "once"
    if seen is not None:
        seen["by"] = choice                          # read by the waiting agent thread after the wait ends
    tok = _answering.set(_CAP)
    try:
        n = resolve(session_key, choice, request_id=rid or None) if rid else 0
    finally:
        _answering.reset(tok)
    if n and choice == "always":                     # recorded only once the live card was really answered (TS-G-08)
        saved = False
        try:
            from . import grants
            saved = grants.record_always(keys, kind, surface="trusted-dialog", nonce=ans.nonce) is True
        except Exception:
            saved = False
        if not saved:
            log.warning("approval window: the Always allow could not be recorded; Qosha will ask again next time")
        # how it ended, after the save: the engine's waiter may have noted it before the save finished (P0 review r2)
        try:
            _record_outcome(rid, {"resolved": True, "choice": "always" if saved else "once"})
        except Exception:
            pass
    log.info("approval window: %s for %s (%s)", choice, kind, "resolved" if n else "nothing pending any more")


def _watch_entry(session_key: str, rid: str, cancel: threading.Event) -> None:
    """Close the window when its card is withdrawn (turn stopped, session closed, timed out)."""
    try:
        from tools import approval as ap
    except Exception:
        return
    while not cancel.wait(1.0):
        with ap._lock:
            live = any(e.data.get("request_id") == rid for e in ap._gateway_queues.get(session_key, []))
        if not live:
            cancel.set()
            return


def patch() -> bool:
    """Make the window the only answer to engine cards in this process (idempotent). The wrappers read enabled() on
    every call, so turning the surface on needs no restart."""
    try:
        import sys
        from tools import approval as ap
        from tools import approval_gateway_wait as gw
    except Exception:
        return False
    owait, oresolve = getattr(gw, "_await_gateway_decision", None), getattr(ap, "resolve_gateway_approval", None)
    if owait is None or oresolve is None:
        return False
    if getattr(owait, "qosha_window", False):
        return True

    def resolve_gateway_approval(session_key, choice, *a, **kw):
        """A decline may come from anywhere (Stop, a closed chat, a page's Decline); a consent only from the window."""
        if enabled() and _answering.get() is not _CAP and str(choice or "").strip().lower() not in ("deny", "no", "n") \
                and not (kw.get("request_id") and not kw.get("resolve_all")
                         and _page_question(_entry_data(session_key, kw.get("request_id")) or {"pattern_key": ""})):
            log.warning("approval: a consent that did not come from the Qosha approval window was refused")
            return 0
        return oresolve(session_key, choice, *a, **kw)

    def _await_gateway_decision(session_key, notify_cb, approval_data, *a, **kw):
        if _page_question(approval_data):
            return owait(session_key, notify_cb, approval_data, *a, **kw)
        if not enabled():           # as released; only how the card ended is noted, after the engine's own wait
            got = {}

            def tell(data):
                if isinstance(data, dict):
                    got["rid"] = str(data.get("request_id") or "")
                notify_cb(data)
            decision = owait(session_key, tell if notify_cb is not None else None, approval_data, *a, **kw)
            try:
                _record_outcome(got.get("rid", ""), decision)
            except Exception:
                pass
            return decision
        approval_data = dict(approval_data or {}, qosha_window=True)   # in the engine's own entry: a reconnect keeps it
        if not READY["ok"]:                    # a hook is missing in this process: nothing is approved (TS-G2-05)
            log.warning("approval: the approval window is not fully set up here; the card is declined")
            return {"resolved": True, "choice": "deny", "reason": None}
        seen = {}

        def notify(data):
            seen["rid"] = str((data or {}).get("request_id") or "")
            threading.Thread(target=_ask_and_resolve, args=(session_key, dict(data), oresolve, seen), daemon=True,
                             name="qosha-approval-window").start()
            if notify_cb is not None:
                try:
                    notify_cb(dict(data, qosha_window=True))   # the page shows "answer in the approval window"
                except Exception as e:                         # no page: the window is the surface
                    log.info("approval window: page not told (%s)", e.__class__.__name__)
        decision = owait(session_key, notify, approval_data, *a, **kw)
        ch = str((decision or {}).get("choice") or "")
        if (decision or {}).get("resolved") and ch not in ("", "deny") and seen.get("by") != ch:
            log.warning("approval: an answer the Qosha approval window did not give was turned into a decline")
            decision = dict(decision, choice="deny")
        try:
            if str((decision or {}).get("choice") or "") != "always" or not (decision or {}).get("resolved"):
                _record_outcome(seen.get("rid", ""), decision,
                                keys=[k for k in (approval_data.get("pattern_keys") or [approval_data.get("pattern_key")]) if k])
            # a window Always: the window worker alone records it, after its own save (P0 review r3)
        except Exception:
            pass
        return decision

    try:
        from tools import approval_prompt as apr
        from tools import approval_context as actx
    except Exception:
        apr = actx = None
    oprompt = getattr(apr, "prompt_dangerous_approval", None)
    otrans = getattr(actx, "_get_approval_transport_config", None)

    def prompt_dangerous_approval(command, description, timeout_seconds=None, allow_permanent=True,
                                  approval_callback=None, *a, **kw):
        """The engine's terminal prompt (a chat run in a terminal): the window answers it too, never typed keys."""
        if not enabled() or oprompt is None:
            return oprompt(command, description, timeout_seconds, allow_permanent, approval_callback, *a, **kw)
        # a chat run inside a terminal (the AI's own terminal can start one): no rule key and no record reach this
        # prompt, so the person could not see what they approve. Declined; Qosha's chats are in the app (TS-V-03)
        log.warning("approval: a card from a terminal chat was declined (answer cards in the Qosha app)")
        return "deny"

    def _get_approval_transport_config(*a, **kw):
        """A plugin approval transport would replace the window: never while the surface is on."""
        if enabled():
            return "builtin", None
        return otrans(*a, **kw)

    if oprompt is None or otrans is None:
        return False                     # every door must be covered, or none counts as set up (TS-G-06)
    pairs = [(resolve_gateway_approval, oresolve), (_await_gateway_decision, owait),
             (prompt_dangerous_approval, oprompt), (_get_approval_transport_config, otrans)]
    apr.prompt_dangerous_approval = prompt_dangerous_approval
    actx._get_approval_transport_config = _get_approval_transport_config
    for fn, orig in pairs:
        fn.qosha_window = True
        fn.__wrapped__ = orig
    gw._await_gateway_decision = _await_gateway_decision
    ap.resolve_gateway_approval = resolve_gateway_approval
    for name, mod in list(sys.modules.items()):     # modules that imported the names before this patch
        if mod is None:
            continue
        for attr, orig, new in [(o.__name__, o, n) for n, o in pairs]:
            try:
                if getattr(mod, attr, None) is orig:
                    setattr(mod, attr, new)
            except Exception:
                continue
    return True
