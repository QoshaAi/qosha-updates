"""Set up a per-user Qosha home (Windows or Mac), the way lab/qoshalab.py sets up the Mac lab home, without the lab's
sandbox or launchd parts. Run with the engine's own Python:

    <engine python> -I setup_home.py --engine <engine dir> --home <home dir> [--port 9219]

<engine dir> holds src/hermes-6eb531c (the pinned engine with its built screens). This file's folder (the "layer")
holds candidate/ (plugin + native-extension from candidates/m2-c18), overlay/ (askaccess.py) and qoshalab.py.
Idempotent: run again to update Qosha's layer; config.yaml, SOUL.md and .env the person changed are kept.
"""
import argparse
import hashlib
import importlib.util
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
from pathlib import Path

LAYER = Path(__file__).resolve().parent
PIN_NAME = 'hermes-6eb531c'
ROUTE = 'hermes_cli/web_routers/sessions.py'
WIN = os.name == 'nt'
ENGINE = Path('.')


def say(m):
    print(m, flush=True)


def die(m):
    say('FAILED: ' + m)
    raise SystemExit(2)


def lab():
    spec = importlib.util.spec_from_file_location('qoshalab_layer', LAYER / 'qoshalab.py')
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def sub(text, old, new, what, count=1):
    if old not in text:
        die('patch point not found: %s' % what)
    return text.replace(old, new, count)


def port_text(text):
    """POSIX-only spellings in Qosha's layer that stop it importing on Windows (the features using dir_fd stay
    unavailable there; see REPORT.md)."""
    for flag in ('O_NOFOLLOW', 'O_DIRECTORY', 'O_NONBLOCK', 'O_CLOEXEC'):
        text = re.sub(r'\bos\.%s\b' % flag, 'getattr(os, "%s", 0)' % flag, text)
    text = text.replace('getattr(getattr(os, ', 'getattr(getattr(os, ')
    text = text.replace('os.getuid()', 'getattr(os, "getuid", lambda: 0)()')
    text = text.replace('_F_GETPATH = getattr(__import__("fcntl"), "F_GETPATH", None)',
                        'try:\n    _F_GETPATH = getattr(__import__("fcntl"), "F_GETPATH", None)\nexcept ImportError:\n'
                        '    _F_GETPATH = None')
    text = re.sub(r'^import fcntl$', 'try:\n    import fcntl\nexcept ImportError:  # Windows\n    fcntl = None',
                  text, flags=re.M)
    return text


OTHER_ALWAYS = re.compile(r"QoshaLab|\.svc\b|cluster\.local|qosha-box|\.internal\b")
OTHER_IF_MISSING = re.compile(r"(?:^|[\s=:\"'])(/(?:opt|app|data|home|root|srv|var|usr|etc|Users)/[^\s\"']*)")
LOCAL_URL = re.compile(r"^[a-z]+://(127\.0\.0\.1|localhost|0\.0\.0\.0)(:\d+)?(/|$)", re.I)


def clean_imported_config(data, home):
    """Settings brought over from another Qosha (a cloud box, a Mac lab) that name things only that machine or that
    old home has: a speech model at /opt/..., the box's own Google connector on a local port, programs and folders
    under ~/QoshaLab. Left in place they fail at every start (HFValidationError; "qosha_google" cannot connect).
    Done ONCE, right after an import (mark: <home>/.qosha-import-cleaned), so a person's own later settings are
    never touched. Rules:
      - a value is "the other machine's" when it is a local-port address, names QoshaLab or a cluster host, or is a
        system-style path (/opt/..., /usr/..., /Users/...) that does not exist on this computer;
      - the `files` tool server is REWRITTEN, so the Files tool keeps working: its program folder is copied to
        <home>/tools/qosha-mcp when the source still exists, its folder argument becomes <home>/files; it is dropped
        only when the program cannot be found;
      - a path under an old home's models folder becomes <home>/models/... when that folder exists here;
      - mcp_servers.qosha_google (the box's Google connector) and any other tool server that still points at the
        other machine are dropped; stt.local.model is dropped (this computer's own speech model is used);
      - every other such value: the key is dropped (the engine's default applies).
    Returns the key names rewritten or dropped (names only, never values); None when there is nothing to do."""
    mark = home / '.qosha-import-cleaned'
    if not (home / '.qosha-imported-from').exists() or mark.exists():
        return None
    notes = []

    def other(v):
        if not isinstance(v, str) or not v:
            return False
        if LOCAL_URL.search(v) or OTHER_ALWAYS.search(v):
            return True
        return any(not os.path.exists(m) for m in OTHER_IF_MISSING.findall(v))

    def any_other(v):
        if isinstance(v, dict):
            return any(any_other(x) for x in v.values())
        if isinstance(v, (list, tuple)):
            return any(any_other(x) for x in v)
        return other(v)

    def models(v):
        """<old home>/models/<rest> -> <home>/models/<rest>, when this home has a models folder"""
        m = re.match(r"^(.*?)[\\/]models((?:[\\/].*)?)$", v) if isinstance(v, str) else None
        if m and other(v) and (home / 'models').is_dir():
            return str(home / 'models') + m.group(2).replace('/', os.sep)
        return None

    ms = data.get('mcp_servers')
    if isinstance(ms, dict):
        for name in list(ms):
            srv = ms[name]
            if name == 'files' and isinstance(srv, dict) and isinstance(srv.get('args'), list) and any_other(srv):
                args, done = list(srv['args']), False
                for i, a in enumerate(args):
                    if isinstance(a, str) and re.search(r"[\\/]node_modules[\\/]", a) and os.path.exists(a):
                        src_root = re.split(r"[\\/]node_modules[\\/]", a, 1)[0]
                        dst_root = home / 'tools' / 'qosha-mcp'
                        try:
                            if not dst_root.exists():
                                shutil.copytree(src_root, dst_root, symlinks=True)
                            args[i] = str(dst_root) + a[len(src_root):]
                            done = True
                        except OSError:
                            done = False
                if done:
                    args = [str(home / 'files') if (isinstance(a, str) and re.search(r"[\\/]files[\\/]?$", a) and other(a)) else a for a in args]
                    srv['args'] = args
                    if isinstance(srv.get('command'), str) and other(srv['command']) and shutil.which('node'):
                        srv['command'] = shutil.which('node')
                    if not any_other(srv):
                        notes.append('mcp_servers.files (rewritten: program copied to this home, folder set to this home\'s files)')
                        continue
                del ms[name]
                notes.append('mcp_servers.files (dropped: its program was not found on this computer)')
            elif name == 'qosha_google' or any_other(srv):
                del ms[name]
                notes.append('mcp_servers.%s (dropped: it belongs to the other machine)' % name)
    stt_local = (data.get('stt') or {}).get('local') if isinstance(data.get('stt'), dict) else None
    if isinstance(stt_local, dict) and isinstance(stt_local.get('model'), str):
        m = stt_local['model']
        if other(m) or (re.search(r'[\\/]', m) and not os.path.exists(m)):
            new = models(m)
            if new and os.path.exists(new):
                stt_local['model'] = new
                notes.append('stt.local.model (rewritten to this home\'s models folder)')
            else:
                del stt_local['model']
                notes.append('stt.local.model (dropped: this computer uses its own speech model)')

    def sweep(d, path):
        if isinstance(d, dict):
            for k in list(d):
                v = d[k]
                kp = '%s.%s' % (path, k) if path else str(k)
                if isinstance(v, (dict, list)):
                    sweep(v, kp)
                elif other(v):
                    new = models(v)
                    if new:
                        d[k] = new
                        notes.append('%s (rewritten to this home\'s models folder)' % kp)
                    else:
                        del d[k]
                        notes.append('%s (dropped: a path, port or host of the other machine)' % kp)
        elif isinstance(d, list):
            keep = [x for x in d if isinstance(x, (dict, list)) or not other(x)]
            if len(keep) != len(d):
                notes.append('%s (%d list entries dropped)' % (path, len(d) - len(keep)))
                d[:] = keep
            for x in d:
                if isinstance(x, (dict, list)):
                    sweep(x, path + '[]')
    sweep(data, '')
    try:
        mark.write_text('\n'.join(notes) + '\n', encoding='utf-8')
    except OSError:
        pass
    return notes


def init_store(home):
    """A new install has no conversation store until the first chat is sent, and the engine's list of conversations
    answers 503 without one: the Conversations page (and Home's and Chat's lists) opened with a red "Something went
    wrong (error 503)" on the very first start. The empty store is made here with the engine's own class."""
    db = home / 'state.db'
    try:
        if db.exists() and db.stat().st_size > 0:
            return 'conversation store already there'
        from hermes_state import SessionDB
        s = SessionDB(db)
        try:
            s.close()
        except Exception:
            pass
        return 'conversation store made (empty)' if db.exists() and db.stat().st_size > 0 else '! conversation store NOT made'
    except Exception as exc:
        return '! conversation store not made: %s' % type(exc).__name__


def google_skill_fix(home):
    """The Qosha library's google-workspace skill wants its Google packages at exact older versions and, when the
    engine's own (newer) ones are there instead, tries `pip install`: a per-user install has neither pip nor uv on the
    PATH, so Connect Google stopped right there ("Failed to install dependencies"). The engine already carries these
    packages; the check now accepts any installed version. Applied after the skill library is copied."""
    n = 0
    for rel in ('skills/productivity/google-workspace/scripts/setup.py', 'skills/qosha-library/google-workspace/scripts/setup.py'):
        f = home / rel
        if not f.is_file():
            continue
        t = f.read_text(encoding='utf-8')
        t2 = t.replace('            if _distribution_version(name) != wanted:\n',
                       '            if not _distribution_version(name):   # Qosha: the engine\'s own version is fine\n')
        if t2 != t:
            f.write_text(t2, encoding='utf-8')
            n += 1
    return 'Google skill uses the engine\'s own Google packages (%d files)' % n


def install_plugin(home):
    src = LAYER / 'candidate' / 'plugin'
    dest = home / 'plugins' / 'qosha'
    if dest.exists():
        old = home / 'plugins' / ('.qosha-old-%d' % int(time.time()))
        os.replace(dest, old)
        shutil.rmtree(old, ignore_errors=True)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(src, dest, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    init = dest / '__init__.py'
    t = init.read_text(encoding='utf-8')
    if (dest / 'qosha_guard' / 'ask.py').exists():
        say('  ask-first rule: the plugin\'s own (qosha_guard/ask.py)')
    else:
      shutil.copy2(LAYER / 'overlay' / 'qosha_guard' / 'askaccess.py', dest / 'qosha_guard' / 'askaccess.py')
      t = sub(t, '    ctx.register_hook("pre_tool_call", pre_tool_call)\n',
            '    # per-user installs: file and command tools ask the person (askaccess.py); everything else: the guard\n'
            '    from .qosha_guard import askaccess as _askaccess\n'
            '    _guard = _askaccess.wrap(pre_tool_call) if _askaccess.enabled() else pre_tool_call\n'
            '    ctx.register_hook("pre_tool_call", _guard)\n', 'register guard')
      t = sub(t, '        pre_tool_call.__qosha_guard_ready__ = True\n',
              '        pre_tool_call.__qosha_guard_ready__ = True\n        _guard.__qosha_guard_ready__ = True\n',
              'guard ready mark')
    init.write_text(t, encoding='utf-8')
    if WIN:
        n = 0
        for f in dest.rglob('*.py'):
            t0 = f.read_text(encoding='utf-8')
            t1 = port_text(t0)
            if t1 != t0:
                f.write_text(t1, encoding='utf-8')
                n += 1
        say('  Windows: %d plugin files adjusted' % n)
    # "Always allow" next to "Allow once" / "Deny" in Qosha's chat (the engine already understands the answer)
    chat = dest / 'dashboard' / 'pages' / 'chat.html'
    t = chat.read_text(encoding='utf-8')
    if 'Always allow' not in t:
      t = sub(t, "'Allow once'),\n",
            "'Allow once'),\n      el('button', {class: 'btn sm ghost', type: 'button', onclick: function () { "
            "done('always', 'You allowed this always (what it covers is written above).'); }}, 'Always allow'),\n",
            'chat page buttons')
    chat.write_text(t, encoding='utf-8')
    idx = dest / 'dashboard' / 'index.html'
    t = idx.read_text(encoding='utf-8')
    if 'x.always' not in t and 'Always allow' not in t:
      t = sub(t, '>Allow once</button>',
            '>Allow once</button><button class="mini ghost" type="button" onClick="{{x.always}}">Always allow</button>',
            'home chat buttons')
      t = sub(t, "allow:() => this.chatAnswer(a.request_id, 'once'),",
            "allow:() => this.chatAnswer(a.request_id, 'once'), always:() => this.chatAnswer(a.request_id, 'always'),",
            'home chat always')
    idx.write_text(t, encoding='utf-8')
    say('OK Qosha plugin installed (approval guard, screens, ask-for-access)')


def write_config(home, files):
    """Qosha's settings merged into the engine's config.yaml (the upstream installer writes its own first: its model
    defaults stay; Qosha adds its plugin, the approval prompt mode, its files folder and quiet background features)."""
    try:
        from ruamel.yaml import YAML          # the engine's own YAML library (keeps the file's comments)
        y = YAML()
        load = lambda s: y.load(s)

        def dump(d):
            import io
            buf = io.StringIO()
            y.dump(d, buf)
            return buf.getvalue()
    except ImportError:
        import yaml
        load = yaml.safe_load
        dump = lambda d: yaml.safe_dump(d, sort_keys=False, allow_unicode=True)
    cfg = home / 'config.yaml'
    data = {}
    if cfg.exists():
        data = load(cfg.read_text(encoding='utf-8')) or {}
        if not (home / 'config.yaml.before-qosha').exists():
            shutil.copyfile(cfg, home / 'config.yaml.before-qosha')
    cleaned = clean_imported_config(data, home)
    if cleaned is not None:
        say('  imported settings checked: %d changed%s' % (len(cleaned), ''.join('\n    - ' + c for c in cleaned)))
    plugins = data.setdefault('plugins', {}) or {}
    data['plugins'] = plugins
    en = list(plugins.get('enabled') or [])
    if 'qosha' not in en:
        en.append('qosha')
    plugins['enabled'] = en
    plugins['disabled'] = [p for p in (plugins.get('disabled') or []) if p != 'qosha']
    plugins.setdefault('entries', {}).setdefault('qosha', {})['allow_tool_override'] = True
    data.setdefault('approvals', {})['mode'] = 'manual'
    data.setdefault('terminal', {})['cwd'] = str(files)
    data.setdefault('agent', {}).setdefault('reasoning_effort', 'medium')
    data['kanban'] = dict(data.get('kanban') or {}, dispatch_in_gateway=False, review_dispatch=False,
                          auto_decompose=False, default_assignee='', auto_subscribe_on_create=False)
    data.setdefault('curator', {})['enabled'] = False
    data.setdefault('updates', {})['check'] = False            # engine versions come only with Qosha
    data.setdefault('stt', {}).setdefault('local', {})['initial_prompt'] = 'Qosha'
    qosha_wake(data)
    br = data.setdefault('browser', {})
    args = list(br.get('chromium_args') or [])
    for a in ('--mute-audio', '--disable-audio-output'):       # Qosha's own browser never plays sound
        if a not in args:
            args.append(a)
    br['chromium_args'] = args
    # Ren, 17 Nov 2026: the browser opens where the person can see it; 'Do it in the background' is their switch.
    # Set once per home; a later choice (Settings, or Qosha changing it when asked) is kept.
    if not br.get('qosha_visible_default'):
        br['headed'] = True
        br['qosha_visible_default'] = 1
    # Google through the Workspace MCP in its own environment beside the engine (only when it was installed)
    gws = ENGINE / 'gws-venv' / ('Scripts/workspace-mcp.exe' if WIN else 'bin/workspace-mcp')
    if gws.exists():
        ms = data.get('mcp_servers')
        if not isinstance(ms, dict):
            ms = {}
        ms['google'] = {'command': str(gws),
                        'args': ['--single-user', '--tools', 'gmail', 'calendar', 'drive', 'docs', 'sheets', 'contacts',
                                 'tasks', '--tool-tier', 'complete', '--read-only'],   # 1.20.9: reads only
                        'env': {'GOOGLE_CLIENT_SECRET_PATH': str(home / 'google_client_secret.json'),
                                'WORKSPACE_MCP_CREDENTIALS_DIR': str(home / 'google_workspace_mcp' / 'credentials'),
                                'WORKSPACE_MCP_TRANSPORT': 'stdio',
                                # Drive uploads from this computer (Ren, 17 Nov 2026: "Usual folders, no question"): the
                                # connector reads local files only inside these folders; its own blocks still apply
                                'ALLOWED_FILE_DIRS': os.pathsep.join(str(d) for d in (Path.home() / 'Downloads', Path.home() / 'Desktop',
                                                     Path.home() / 'Documents', home / 'files'))}}
        data['mcp_servers'] = ms
    # Gemini on the person's Google subscription, only where Google's own command-line tool is installed
    gm = home / 'plugins' / 'qosha' / 'qosha_guard' / 'gemini_mcp.py'
    agy_win = Path(os.environ.get('LOCALAPPDATA') or '.') / 'Programs' / 'agy' / 'agy.exe'      # where Qosha's Windows installer puts it
    if gm.is_file() and (shutil.which('agy') or shutil.which('gemini') or (WIN and agy_win.is_file())):
        ms = data.get('mcp_servers')
        if not isinstance(ms, dict):
            ms = {}
        ms['gemini'] = {'command': sys.executable, 'args': [str(gm)]}
        data['mcp_servers'] = ms
    if (LAYER / 'brand' / 'qosha.yaml').is_file():
        data.setdefault('display', {})['skin'] = 'qosha'
    try:   # no sharing of usage numbers with the engine's maker, and no question about it on Qosha's screens
        from hermes_cli.observability.shared_metrics_consent import set_answer
        set_answer(data, False, False)
    except Exception:
        sm = data.setdefault('telemetry', {}).setdefault('shared_metrics', {})
        sm['enabled'] = False
        sm['send'] = False
    data['sessions'] = dict(data.get('sessions') or {}, auto_archive=False, auto_prune=False)
    tmp = cfg.with_name('.config.yaml.qosha-tmp')
    tmp.write_text(dump(data), encoding='utf-8')
    os.replace(tmp, cfg)
    say('OK config.yaml: Qosha plugin on, approvals asked in the chat')


# 1.20.3: the wake word is "Hey Qosha", never the engine's shipped "hey hermes". The engine's own open-vocabulary
# detector (sherpa) listens for exactly the phrase written in wake_word.phrase, so what "/wake status" shows is what it
# hears. It is spelled the way it sounds: the detector's word pieces for "qosha" (a Q) never matched a spoken "Hey
# Qosha" (tests/wake_detect_probe.py, 3 voices); "kosha" matched all of them and not "Hey Hermes" or other speech.
# A detector the person chose is kept (r1 review #6, r2 #10): a Porcupine keyword or a custom openWakeWord model keeps
# its provider and gets its own word as the label; openWakeWord chosen with its own model is left alone; a phrase they
# typed is kept as it is. Named profiles are not edited here (r2 #6-#12): in a Qosha home the engine's own defaults are
# Qosha's at run time (qosha_names.py), and Qosha's wording comes with the plugin every profile runs.
_ENGINE_PHRASE = ('', 'hey hermes')
_ENGINE_OWW = ('', 'hey_hermes', 'hey hermes', 'hermes')
_SHERPA = ('sherpa', 'sherpa-onnx', 'kws', 'open')


def qosha_wake(data):
    ww = data.get('wake_word')
    if ww is not None and not isinstance(ww, dict):
        return False                                 # not Qosha's to rewrite
    ww = dict(ww or {})
    phrase = ww.get('phrase')
    if not (phrase is None or (isinstance(phrase, str) and phrase.strip().lower() in _ENGINE_PHRASE)):
        return False                                 # the person's own phrase
    prov = str(ww.get('provider') or 'auto').strip().lower()
    oww = ww.get('openwakeword') if isinstance(ww.get('openwakeword'), dict) else {}
    model = str(oww.get('model') or '').strip()
    por = ww.get('porcupine') if isinstance(ww.get('porcupine'), dict) else {}
    if prov == 'porcupine' and str(por.get('keyword') or '').strip():
        ww['phrase'] = str(por['keyword']).strip()   # Porcupine listens for its keyword; the label says that word
    elif prov in ('auto', 'openwakeword', 'oww', 'local') and model.lower() not in _ENGINE_OWW:
        ww['phrase'] = Path(model).stem.replace('_', ' ')  # a custom model: its own name, never the engine's
    elif prov == 'auto' or prov in _SHERPA:
        ww['phrase'] = 'hey kosha'
        ww['provider'] = 'sherpa'
    else:
        return False        # a detector the person chose on purpose (openWakeWord's own model, ...): kept as it is
                            # (r2 review #10); /wake status names it without the engine's name (qosha_names.py)
    data['wake_word'] = ww
    return True


def _atomic_write(path, data):
    """Bytes into place in one step (the self-heal writes while the dashboard serves these files; Gemini sh16 F1): a
    fresh sibling temp file, fsync, os.replace with a few retries for a file held open on Windows. A reader sees the
    old file or the new one, never a half-written one; a failure leaves the old file as it was and raises OSError."""
    path = Path(path)
    try:
        mode = stat.S_IMODE(os.stat(str(path)).st_mode)       # the file keeps its permissions (GPT sh16 N5)
    except OSError:
        mode = None
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix='.%s.' % path.name, suffix='.qosha-tmp')
    try:
        with os.fdopen(fd, 'wb') as h:
            h.write(data)
            h.flush()
            os.fsync(h.fileno())
        if mode is not None:
            os.chmod(tmp, mode)
        for i in range(6):
            try:
                os.replace(tmp, str(path))
                return
            except PermissionError:
                if i == 5:
                    raise
                time.sleep(0.25 * (i + 1))
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


def brand_web(src, home, L):
    dist = src / 'hermes_cli' / 'web_dist'
    icons = home / 'plugins' / 'qosha' / 'dashboard' / 'assets' / 'brand' / 'icons'
    names = L.QOSHA_ICON_FILES
    if not (dist / 'index.html').is_file() or not all((icons / n).is_file() for n in names):
        die('the built screens or the plugin icons are missing')
    data = {n: (icons / n).read_bytes() for n in names}
    ver = hashlib.sha256(b''.join(data[n] for n in names)).hexdigest()[:12]
    out = dist / 'qosha-icons'
    out.mkdir(exist_ok=True)
    for n in names:
        if not (out / n).is_file() or (out / n).read_bytes() != data[n]:
            _atomic_write(out / n, data[n])
    for n, key in (('favicon.ico', 'favicon.ico'), ('apple-touch-icon.png', 'apple-touch-icon.png')):
        if not (dist / n).is_file() or (dist / n).read_bytes() != data[key]:
            _atomic_write(dist / n, data[key])
    html = (dist / 'index.html').read_text(encoding='utf-8', errors='surrogateescape')   # bytes kept (GPT sh16 N7)
    html = re.sub(r'\s*<!-- qosha-icons -->.*?<!-- /qosha-icons -->', '', html, flags=re.S)
    html = re.sub(r'\s*<link rel="(?:icon|shortcut icon|apple-touch-icon|manifest)"[^>]*>', '', html)
    block = ('<!-- qosha-icons -->\n'
             '    <link rel="icon" type="image/svg+xml" href="/qosha-icons/qosha-icon.svg?v=%(v)s" />\n'
             '    <link rel="icon" type="image/x-icon" sizes="16x16 32x32 48x48" href="/favicon.ico?v=%(v)s" />\n'
             '    <link rel="apple-touch-icon" sizes="180x180" href="/qosha-icons/apple-touch-icon.png?v=%(v)s" />\n'
             '    <link rel="manifest" href="/qosha-icons/site.webmanifest?v=%(v)s" />\n'
             '    <meta name="theme-color" content="#0B3326" />\n'
             '    <!-- /qosha-icons -->') % {'v': ver}
    html, n = re.subn(r'(<meta charset="UTF-8" />)', lambda m: m.group(1) + '\n    ' + block, html, count=1, flags=re.I)
    if not n:                         # any <head ...> spelling (GPT sh16 F6)
        html = re.sub(r'(<head\b[^>]*>)', lambda m: m.group(1) + '\n    ' + block, html, count=1, flags=re.I)
    html, n = re.subn(r'<title\b[^>]*>[^<]*</title>', '<title>Qosha</title>', html, count=1, flags=re.I)
    if not n:                         # no title at all: Qosha's goes in right after the icons (Gemini sh16 F6)
        html = html.replace('<!-- /qosha-icons -->', '<!-- /qosha-icons -->\n    <title>Qosha</title>', 1)
    fp_code = home / 'plugins' / 'qosha' / 'dashboard' / 'first_paint.py'
    fp_block = fp_code.with_name('first-paint.html')
    if fp_code.is_file() and fp_block.is_file():
        spec = importlib.util.spec_from_file_location('qosha_first_paint', fp_code)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        html = mod.apply(html, fp_block.read_text(encoding='utf-8'))
        if hasattr(mod, 'brand_assets'):   # the engine's brand words in the built screens (22 Nov 2026)
            try:                           # never in the way of index.html below (Gemini fp15 F2)
                say('OK %d brand word(s) in the built screens say Qosha' % mod.brand_assets(dist))
            except Exception as e:
                say('WARN the built screens kept some engine words (%s)' % type(e).__name__)
    _atomic_write(dist / 'index.html', html.encode('utf-8', 'surrogateescape'))
    say('OK screens branded Qosha (title, icons, first paint)')


_BRAND_LEFT = re.compile(r'app:\{brand:[`"\']Hermes Agent')
_INDEX_MARKS = ('<title>Qosha</title>', '<style id="qosha-first-paint">', 'body > :not(#qosha-splash){visibility:hidden',
                'id="qosha-splash"', '<!-- qosha-icons -->')
_BUNDLE_CLEAN = {}             # files the whole-bundle scan found clean: path -> (size, mtime_ns)
_CLEAN = {}                    # scripts already checked clean: path -> (size, mtime_ns) (GPT sh16 N8)


def _swap_rules(home):
    """The plugin's own swap patterns (first_paint.ASSET_SWAPS): what the repair fixes is what the check looks for
    (GPT sh16 F2). Without the plugin, the brand string alone."""
    rules = [_BRAND_LEFT]
    if home is not None:
        fp = Path(home) / 'plugins' / 'qosha' / 'dashboard' / 'first_paint.py'
        try:
            spec = importlib.util.spec_from_file_location('qosha_first_paint_check', fp)
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)
            rules += [rx for rx, _ in getattr(m, 'ASSET_SWAPS', [])]
        except Exception:
            pass
    return rules


def screens_branded(src, home=None):
    """The served screens are Qosha's: index.html carries Qosha's title, icons block, first-paint style (with its
    hiding rule) and loading screen; the favicon is Qosha's; no built script matches a swap the installer makes; the
    chat terminal's two texts are Qosha's (Gemini sh16 F2, F9; GPT F2, F9). No index.html at all counts as branded
    (the engine's own start reports a missing dist); any other read or listing error counts as not branded (F3, N6).
    Scripts already found clean are not read again until their size or time changes (N8)."""
    src = Path(src)
    dist = src / 'hermes_cli' / 'web_dist'
    try:
        t = (dist / 'index.html').read_text(encoding='utf-8', errors='replace')
    except FileNotFoundError:
        return True
    except OSError:
        return False
    if not all(k in t for k in _INDEX_MARKS):
        return False
    try:
        if home is not None:
            ico = Path(home) / 'plugins' / 'qosha' / 'dashboard' / 'assets' / 'brand' / 'icons' / 'favicon.ico'
            if ico.is_file() and (dist / 'favicon.ico').read_bytes() != ico.read_bytes():
                return False
        rules = None
        with os.scandir(str(dist / 'assets')) as it:          # a listing error is raised, not hidden (N6)
            entries = [e for e in it if e.name.endswith('.js')]
        for e in entries:
            st = e.stat()
            key = (st.st_size, st.st_mtime_ns)
            if _CLEAN.get(e.path) == key:
                continue
            rules = rules or _swap_rules(home)
            text = Path(e.path).read_text(encoding='utf-8', errors='replace')
            if any(rx.search(text) for rx in rules):
                return False
            _CLEAN[e.path] = key
        en = src / 'ui-tui' / 'dist' / 'entry.js'
        et = en.read_text(encoding='utf-8', errors='replace') if en.is_file() else ''
        if bundle_names(src, _BUNDLE_CLEAN):          # the whole bundle, not just the known spots (orchestrator)
            return False
    except OSError:
        return False
    return not any(old in et or old.replace('\n', '\r\n') in et for rel, old, new in ENGINE_TEXT)


def heal_screens(src, home):
    """Self-heal (P0, 22 Nov 2026): when something rebuilt or replaced the engine's built screens after Qosha branded
    them (an engine rebuild, a test run from this folder, a copy), the engine's own page would flash before Qosha's.
    Brands them again with the installer's own steps. Returns None if they were already Qosha's, else True/False for
    the result. Raises SystemExit (die) if the plugin's icons are missing: the caller logs it and goes on."""
    src, home = Path(src), Path(home)
    if screens_branded(src, home):
        return None
    brand_web(src, home, lab())
    engine_wording(src)
    return screens_branded(src, home)


# 1.20.4: the two strings in the engine's built chat terminal (Advanced > chat) that name it outside its string
# catalog: the /wake help line and the terminal title before a model is chosen. A plain text swap in the shipped copy,
# idempotent, nothing else touched; a missing file or text is skipped (a later engine may have changed them).
ENGINE_TEXT = [('ui-tui/dist/entry.js', "toggle the 'Hey Hermes' wake word listener", "toggle the 'Hey Qosha' wake word listener"),
               ('ui-tui/dist/entry.js', '} : "Hermes"\n', '} : "Qosha"\n'),
               # 22 Nov 2026 (orchestrator, P0: no engine name or maker anywhere a person can read): the chat terminal's
               # brand, credits and update help. The two payment-consent sentences name whoever really charges the
               # card (the provider's portal), so they say "the provider", never Qosha.
               ('ui-tui/dist/entry.js', 'name: "Hermes Agent",', 'name: "Qosha",'),
               ('ui-tui/dist/entry.js', 'icon: "\\u2624",', 'icon: "Q",'),
               ('ui-tui/dist/entry.js', 'tagFull: "Nous Research \\xB7 Messenger of the Digital Gods"', 'tagFull: "Qosha AI"'),
               ('ui-tui/dist/entry.js', 'TAG_TINY = "Nous Research";', 'TAG_TINY = "Qosha AI";'),
               ('ui-tui/dist/entry.js', 'children: " \\xB7 Nous Research" }', 'children: " \\xB7 Qosha AI" }'),
               ('ui-tui/dist/entry.js', 'help: "update Hermes Agent to the latest version (exits TUI)"',
                'help: "update Qosha to the latest version (exits TUI)"'),
               ('ui-tui/dist/entry.js', "from the portal's Hermes Agent page.", "from the portal's agent page."),
               ('ui-tui/dist/entry.js', 'you allow Nous Research to charge your card.', 'you allow the provider to charge your card.'),
               ('ui-tui/dist/entry.js', 'you authorize Nous Research to charge ${card}', 'you authorize the provider to charge ${card}')]
# what must never be left in anything the screens or the chat terminal show (the engine's internal __HERMES_*
# identifiers don't match these)
FORBIDDEN = re.compile(r'Hermes Agent|Nous Research|HERMES AGENT|Hermes Teal')


def bundle_names(src, cache=None):
    """Every file of the built screens (web_dist) and the chat terminal (ui-tui/dist) that still holds the engine's name
    or its maker's: [(relative path, the text)]. A listing or read error is raised. With a cache dict, files already
    found clean are not read again until their size or time changes."""
    src, hits = Path(src), []
    for top in (src / 'hermes_cli' / 'web_dist', src / 'ui-tui' / 'dist'):
        if not top.is_dir():
            continue
        def boom(e):
            raise e
        for dp, dns, fns in os.walk(str(top), onerror=boom):
            for fn in fns:
                p = os.path.join(dp, fn)
                st = os.stat(p)
                key = (st.st_size, st.st_mtime_ns)
                if cache is not None and cache.get(p) == key:
                    continue
                with open(p, 'rb') as h:
                    m = FORBIDDEN.search(h.read().decode('utf-8', 'ignore'))
                if m:
                    hits.append((os.path.relpath(p, str(src)), m.group(0)))
                elif cache is not None:
                    cache[p] = key
    return hits


def engine_wording(src):
    n = 0
    for rel, old, new in ENGINE_TEXT:
        f = Path(src) / rel
        try:
            with open(f, encoding='utf-8', newline='') as h:     # bytes kept as they are
                t = h.read()
        except (OSError, UnicodeDecodeError):
            continue
        for o, nw in ((old, new), (old.replace('\n', '\r\n'), new.replace('\n', '\r\n'))):
            if o in t:
                try:
                    _atomic_write(f, t.replace(o, nw).encode('utf-8'))
                    n += 1
                except OSError:
                    pass
                break
    return n


def narrow_google(src, L):
    n = 0
    for rel in L.GOOGLE_SCRIPTS:
        p = src / rel
        if not p.is_file():
            continue
        t = p.read_text(encoding='utf-8')
        t2 = L.narrow_google_text(t)
        if t2 != t:
            p.write_text(t2, encoding='utf-8')
            n += 1
    say('OK Google scripts use the 4 pilot scopes (%d changed)' % n)


# Qosha's identity in SOUL.md (Ren, 18 Nov 2026 ~23:5x MST: "qosha should be able to say the word hermes, it should not
# think it is hermes. it needs to know it is an evolution based of it, so it understands the context when I need to do
# upgrades to it"). Qosha's screens, installer and error texts still never show the upstream name (qosha_names.py).
# The shipped texts (qoshalab.QOSHA_SOUL and its earlier versions) open with one line that carries one of these
# sentences; when SOUL.md's first line is exactly such a shipped line, the sentence is replaced there, at every install
# and update, Mac and Windows alike (the sentence has no "this Mac" in it). Anything else in the file is the person's.
SOUL_IDENTITY_OLD = (
    "Always call yourself Qosha. Never name, as yourself or as what you run on, any other assistant, agent framework or "
    "its maker, and never point the person to another assistant's commands, folders, website or docs: for setup and "
    "settings, point to Qosha's Settings.",
    "Never call yourself Hermes and never mention Nous Research.",
)
SOUL_IDENTITY = (
    "Always call yourself Qosha; you are not Hermes. Qosha is built on, and evolved from, the open-source Hermes Agent "
    "engine, which Qosha's own code extends: when the person brings up the engine, or a task needs it (its versions, "
    "logs, code or an upgrade), talk about it and use its name freely; don't bring the name up with people who didn't "
    "ask. For setup and settings, point to Qosha's Settings, not to another assistant's commands, folders, website or "
    "docs.")
SOUL_NOTE_KEY = "a Qosha update did not add its new identity sentence"      # how the note is recognised in memory
SOUL_IDENTITY_NOTE = ("This person reworded Qosha's SOUL.md, so " + SOUL_NOTE_KEY + " there. Offer once to add it "
                      "(only with their OK): \"" + SOUL_IDENTITY + "\"")
MEMORY_DELIMITER = "\n§\n"     # the engine's MEMORY.md entry separator (tools/memory_tool_store.ENTRY_DELIMITER)


def qosha_soul_text(s):
    """SOUL.md as setup_home writes it from qoshalab.QOSHA_SOUL (the same words on a Mac and on Windows)."""
    s = s.replace(
        "(python, node, shell) in Qosha's code sandbox, which works on Your files;",
        "(python, shell) on this computer: Qosha asks the person first (Allow once / Always allow / Deny), and the "
        "same for files outside Your files, so just go ahead and use the tool;")
    s = re.sub(r"The Mac's live screen isn't visible to you \(macOS would have to ask the person for Screen "
               r"Recording permission\)", "This computer's live screen isn't visible to you", s)
    return s.replace('this Mac', 'this computer').replace('This Mac', 'This computer')


class _Changed(Exception):
    """The file changed (or became a link) while the step was working: it is left as it now is."""


def _swap_in(path, before, data):
    """Put data at path in one step, only if path still holds exactly `before` (None: path must not exist) and is no
    link. The new bytes go through a temp file created exclusively in the same folder (never an existing file or a
    link), with path's permissions; the temp file is gone afterwards whatever happens."""
    import stat
    import tempfile
    fd, tmp = tempfile.mkstemp(prefix='.' + path.name + '.', suffix='.qosha-tmp', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'wb') as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        if before is not None:
            try:
                os.chmod(tmp, stat.S_IMODE(os.lstat(path).st_mode))
            except OSError:
                pass
        now = None if not (path.exists() or path.is_symlink()) else (None if path.is_symlink() else path.read_bytes())
        if path.is_symlink() or now != before:
            raise _Changed()
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


class _MemoryLock:
    """The engine's own lock on memories/MEMORY.md (MEMORY.md.lock, as tools/memory_tool_store takes it). Never waits:
    a lock held by someone else raises BlockingIOError and the note is skipped this time."""

    def __init__(self, mem):
        self.path = mem.with_name(mem.name + '.lock')
        self.fd = None

    def __enter__(self):
        if self.path.is_symlink():
            raise _Changed()
        self.fd = os.open(str(self.path), os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        try:
            try:
                import fcntl
            except ImportError:      # Windows
                fcntl = None
            if fcntl is not None:
                fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            else:
                import msvcrt
                os.lseek(self.fd, 0, 0)
                try:
                    msvcrt.locking(self.fd, msvcrt.LK_NBLCK, 1)
                except OSError:
                    raise BlockingIOError('memory is locked')
        except BaseException:
            os.close(self.fd)
            raise
        return self

    def __exit__(self, *exc):
        try:
            try:
                import fcntl
                fcntl.flock(self.fd, fcntl.LOCK_UN)
            except ImportError:
                import msvcrt
                os.lseek(self.fd, 0, 0)
                msvcrt.locking(self.fd, msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
        finally:
            os.close(self.fd)
        return False


def soul_identity(home, stocks=()):
    """Replace the stock identity sentence in <home>/SOUL.md with SOUL_IDENTITY, only where the file's first line is
    exactly a shipped first line (`stocks`: every shipped SOUL text, as written on a Mac or by setup_home). Otherwise
    SOUL.md keeps every byte, and Qosha's memory gets one note to offer the change (once, only while memory stays
    under its limit). Links, unreadable files and anything changed meanwhile are left alone. This step is optional:
    it never raises, so it can never fail setup or an update. Returns what it did."""
    try:
        return _soul_identity(Path(home), stocks)
    except _Changed:
        return 'skipped: a file changed or is a link (left as it is)'
    except BlockingIOError:
        return 'skipped: memory in use (left as it is)'
    except Exception as e:
        return 'skipped: %s (files left as they are)' % type(e).__name__


def _soul_identity(home, stocks):
    soul = home / 'SOUL.md'
    if soul.is_symlink():
        return 'kept: a link'
    if not soul.is_file():
        return 'no SOUL.md'
    try:
        raw = soul.read_bytes()
        text = raw.decode('utf-8')
    except (OSError, UnicodeDecodeError):
        return 'kept: unreadable'
    if SOUL_IDENTITY in text:
        return 'current'
    line, nl, rest = text.partition('\n')
    cr = '\r' if line.endswith('\r') else ''
    line = line[:len(line) - len(cr)]
    shipped = {t.partition('\n')[0] for s in stocks if isinstance(s, str) for t in (s, qosha_soul_text(s))}
    old = next((o for o in SOUL_IDENTITY_OLD if o in line), None) if line in shipped else None
    if old is not None:
        _swap_in(soul, raw, (line.replace(old, SOUL_IDENTITY, 1) + cr + nl + rest).encode('utf-8'))
        return 'updated'
    mark = home / '.qosha-soul-identity-offered'
    if mark.exists() or mark.is_symlink():
        return 'kept: reworded (already noted)'
    mem = home / 'memories' / 'MEMORY.md'
    if mem.parent.is_symlink() or mem.is_symlink():
        return 'kept: reworded (memory is a link, not noted)'
    mem.parent.mkdir(parents=True, exist_ok=True)
    with _MemoryLock(mem):
        before = mem.read_bytes() if mem.exists() else None
        cur = (before or b'').decode('utf-8')
        if SOUL_NOTE_KEY in cur:
            _mark(mark)
            return 'kept: reworded (already noted)'
        entries = [e for e in (x.strip() for x in cur.split(MEMORY_DELIMITER)) if e]
        limit = 2200                                   # the engine's default memory_char_limit
        try:
            m = re.search(r'^\s*memory_char_limit:\s*(\d+)\s*$', (home / 'config.yaml').read_text(encoding='utf-8'), re.M)
            if m:
                limit = int(m.group(1))
        except (OSError, UnicodeDecodeError):
            pass
        if len(MEMORY_DELIMITER.join(entries + [SOUL_IDENTITY_NOTE])) > limit:
            return 'kept: reworded (memory full, not noted)'
        _swap_in(mem, before, ((cur.rstrip('\n') + MEMORY_DELIMITER) if cur.strip() else '').encode('utf-8')
                 + SOUL_IDENTITY_NOTE.encode('utf-8'))
    _mark(mark)
    return 'kept: reworded (noted in memory)'


def _mark(mark):
    """The 'already offered' marker; created new (never through a link or over a file). Best effort: the note in
    memory is what counts, the marker only saves a read."""
    try:
        os.close(os.open(str(mark), os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600))
    except OSError:
        pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--engine', required=True)
    ap.add_argument('--home', required=True)
    ap.add_argument('--src', help='the engine source folder (default: <engine>/src/%s)' % PIN_NAME)
    a = ap.parse_args()
    global ENGINE
    engine, home = Path(a.engine).resolve(), Path(a.home).resolve()
    ENGINE = engine
    src = Path(a.src).resolve() if a.src else engine / 'src' / PIN_NAME
    if not (src / 'hermes_cli').is_dir():
        die('no engine source at %s' % src)
    L = lab()
    home.mkdir(parents=True, exist_ok=True)
    files = home / 'files'
    files.mkdir(exist_ok=True)
    port = LAYER / 'port' / 'sessions.py'      # Qosha's sessions route ported to the newer engine
    shutil.copyfile(port if (src / 'hermes_state_common.py').exists() and port.exists() else
                    LAYER / 'candidate' / 'native-extension' / ROUTE, src / ROUTE)
    say('OK sessions route from the Qosha candidate')
    narrow_google(src, L)
    install_plugin(home)
    write_config(home, files)
    soul = home / 'SOUL.md'
    if soul.exists() and 'Qosha' not in soul.read_text(encoding='utf-8', errors='replace'):
        os.replace(soul, home / 'SOUL.md.before-qosha')   # the engine's default persona, kept aside
    if not soul.exists():
        soul.write_text(qosha_soul_text(L.QOSHA_SOUL), encoding='utf-8')
        say('OK SOUL.md: Qosha')
    say('OK SOUL.md identity: ' + soul_identity(home, [L.QOSHA_SOUL] + list(getattr(L, 'QOSHA_SOUL_PREVIOUS', ()))))
    env = home / '.env'
    if not env.exists():
        env.write_text('# Qosha secrets (sign-ins are added by Qosha\'s sign-in steps; never copied from elsewhere)\n',
                       encoding='utf-8')
    brand_web(src, home, L)
    say('OK engine wording: %d text(s) in the chat terminal say Qosha' % engine_wording(src))
    bd = LAYER / 'brand' / 'brand_dashboard.py'      # the features tree's own title/icon step, when it has one
    if bd.is_file():
        r = subprocess.run([sys.executable, '-I', str(bd), str(src), str(home / 'plugins' / 'qosha')],
                           capture_output=True, text=True)
        say('OK page title and icon at the source' if r.returncode == 0 else '! brand_dashboard.py failed: ' + (r.stderr or '')[-200:])
    sp = [p for p in sys.path if p.rstrip('/\\').endswith('site-packages') and os.path.isdir(p)]
    target = next((p for p in sp if 'installs' in p or 'venv' in p), sp[-1] if sp else None)
    if not target:
        die('no site-packages for the engine environment')
    os.environ.update(HERMES_HOME=str(home), HERMES_KANBAN_HOME=str(home))
    # Qosha's name in the engine's chat error texts (qosha_names.py), loaded at every engine start
    pat = 'installs/*/environments/*/venv/' + ('Lib/site-packages' if WIN else 'lib/python*/site-packages')
    targets = sorted({str(p) for p in home.glob(pat)} | {target})      # every environment the engine has made
    for tg in targets:
        shutil.copyfile(LAYER / 'qosha_names.py', os.path.join(tg, 'qosha_names.py'))
        with open(os.path.join(tg, 'qosha_names.pth'), 'w') as fh:
            fh.write('import qosha_names\n')
    # and from the plugin itself, so an environment the engine rebuilds later still gets it
    pl = home / 'plugins' / 'qosha'
    shutil.copyfile(LAYER / 'qosha_names.py', pl / 'qosha_names.py')
    it = (pl / '__init__.py').read_text(encoding='utf-8')
    if 'qosha_names' not in it:
        (pl / '__init__.py').write_text(it + '\n\ntry:\n    from . import qosha_names as _qosha_names  # noqa: F401  (engine error texts say Qosha)\nexcept Exception:\n    pass\n', encoding='utf-8')
    say('OK engine error texts say Qosha')
    for tg in targets:
        shutil.copyfile(home / 'plugins' / 'qosha' / 'qosha_guard' / 'startup_barrier.py',
                        os.path.join(tg, 'qosha_startup_barrier.py'))
        with open(os.path.join(tg, 'qosha_startup_barrier.pth'), 'w') as fh:
            fh.write('import qosha_startup_barrier\n')
    say('  engine environments set up: %d' % len(targets))
    import qosha_startup_barrier  # noqa: F401  (as the .pth does at every start)
    import hermes_cli.plugins as hp
    ok = getattr(hp._get_pre_tool_call_directive_details, '__qosha_barrier__', False)
    say('OK startup barrier active' if ok else '! startup barrier NOT active')
    # Qosha's skill library
    inst = LAYER / 'candidate' / 'skills' / 'install_skills.py'
    if inst.is_file():
        r = subprocess.run([sys.executable, '-I', str(inst), '--home', str(home), '--backups', str(home.parent / 'backups')],
                           capture_output=True, text=True)
        tail = ((r.stdout or '') + (r.stderr or '')).strip().splitlines()[-1:] or ['']
        if r.returncode == 0:
            say('OK skill library: ' + tail[0][:200])
        else:   # the library's own installer needs a package this environment lacks: plain copy of the library
            lib = LAYER / 'candidate' / 'skills' / 'qosha-library'
            dst = home / 'skills' / 'qosha-library'
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(lib, dst)
            man = LAYER / 'candidate' / 'skills' / 'SKILLS-MANIFEST.json'
            if man.is_file():
                shutil.copyfile(man, dst / 'SKILLS-MANIFEST.json')
            say('OK skill library copied (%d skills; its own installer could not run: %s)'
                % (sum(1 for _ in dst.rglob('SKILL.md')), tail[0][:80]))
    # the engine's own string overlay and skin with Qosha's wording and colours (features/brand)
    if WIN:
        say('  Windows: ' + google_skill_fix(home))
    # a home imported from a Mac lab still names the lab's folders in its memories, skills and notes (17 Nov: Qosha
    # reached for ~/QoshaLab/home/skills/.../google_api.py); point them at this home, once, with backups
    fx = LAYER / 'fix_lab_paths.py'
    if (home / '.qosha-imported-from').exists() and not (home / '.qosha-lab-paths-fixed').exists() and fx.is_file():
        r = subprocess.run([sys.executable, '-I', str(fx), '--home', str(home), '--apply'], capture_output=True, text=True)
        last = ((r.stdout or '').strip().splitlines() or [''])[-1]
        if r.returncode == 0:
            (home / '.qosha-lab-paths-fixed').write_text(last + '\n', encoding='utf-8')
            say('OK lab paths: ' + last[:200])
        else:
            say('! lab paths not fixed: ' + (last or (r.stderr or '')[-200:]))
    brand = LAYER / 'brand'
    if (brand / 'locales').is_dir():
        (home / 'locales').mkdir(exist_ok=True)
        for f in (brand / 'locales').glob('*.yaml'):
            shutil.copyfile(f, home / 'locales' / f.name)
        say('OK engine wording overlay: %s' % ', '.join(sorted(f.name for f in (brand / 'locales').glob('*.yaml'))))
    if (brand / 'qosha.yaml').is_file():
        (home / 'skins').mkdir(exist_ok=True)
        shutil.copyfile(brand / 'qosha.yaml', home / 'skins' / 'qosha.yaml')
    try:
        from hermes_cli import kanban_db as kb
        kb.create_board(L.BOARD, name=L.BOARD)
        say('OK task board ' + L.BOARD)
    except Exception as exc:
        say('! task board not created: %s' % exc)
    say('  ' + init_store(home))   # Mac and Windows alike: a fresh install must open Conversations without a 503
    sys.path.insert(0, str(home / 'plugins'))
    try:
        import qosha  # noqa: F401
        from qosha.qosha_guard import policy as p
        v = p.classify("send_message", {"action": "send", "target": "x", "message": "self-check"})
        say('guard self-check: GUARD %s' % v.action)
        if (home / 'plugins' / 'qosha' / 'qosha_guard' / 'ask.py').exists():
            from qosha.qosha_guard import ask
            r = ask.pre_tool_call(tool_name='send_message', args={'action': 'send', 'target': 'x', 'message': 'hi'})
            say('ask-first self-check (a send): %s' % (r or {}).get('action'))
    except Exception as exc:
        import traceback
        traceback.print_exc()
        die('Qosha\'s approval guard does not load here: %s' % exc)
    # Qosha updates (17 Nov 2026): the person's own changes are put back after every (re)install, and the engine's
    # own self-update stays switched off from the first start
    try:
        from qosha.qosha_guard import updater as u
        u.apply_customizations(home)
        u.patch_engine_update_gate(src)
        say('OK updates: customisations kept, engine self-update off')
    except Exception as exc:
        say('! updates step: %s' % type(exc).__name__)
    say('SETUP HOME DONE')


if __name__ == '__main__':
    main()
