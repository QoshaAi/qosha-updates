"""Qosha Council inside the engine's gateway (P0, 8 Nov 2026): how a council request reaches core.py.

One way in (Ren, 8 Nov: design "c"): the person's explicit choice. A chat message sent with "All 3", or confirmed with
the page's "Ask all 3" button (shown whenever a message mentions the council), carries
params.qosha_council = {"mode", "request_id"} on the gateway's prompt.submit. Words alone never start the council and
the assistant has no council tool: a message without that choice is an ordinary message to Qosha.

The gateway answers a council message ITSELF (9 Nov, after GPT reviews 20-22): it never hands it to the engine's turn
runner. The person's (redacted) message and the council's report are added to the chat's history and saved in the
chat's database exactly as the engine adds its own notes (tui_gateway/server.py: _append_model_switch_marker), the page
gets the usual message.start / council.progress / message.complete events, and the chat is marked running meanwhile so
nothing else starts in it. The main model is never called for a council message, nothing is matched by text, and the
engine has no unfinished council turn to recover, continue or replay. In later turns the saved report is ordinary
history (handoff 4a: the normal untrusted-content case; any action still waits for Approve).
"""
from __future__ import annotations

import logging
import os
import re
import sys
import threading
import time
import uuid
from collections import OrderedDict
from pathlib import Path

try:
    from . import core, seats
except ImportError:   # loaded by path (tests)
    import qosha_council_core as core      # type: ignore
    import qosha_council_seats as seats    # type: ignore

log = logging.getLogger("qosha.council")

QUEUE_S = 180.0      # an accepted council that has not started by then never will (the page is told so)
CONTEXT_CHARS = 8000

_LOCK = threading.Lock()
_RECENT: "OrderedDict[str, float]" = OrderedDict()  # request ids already accepted (double-click guard)
_SECRETS: "dict[str, str]" = {}                   # the Gemini helper key, kept in this process's memory only
JOBS = core.Jobs()
ACCEPTED: "dict[str, float]" = {}                  # request ids the gateway took (status: queued until the job starts)
_RUNNING: "dict[str, dict]" = {}                   # chat (session key) -> the council answering in it now
_STARTED: "set[str]" = set()                       # request ids whose turn began (never declared "did not start")
_EXPIRED: "set[str]" = set()                       # request ids told "did not start" (never start after that)
_SETTLED: "OrderedDict[str, str]" = OrderedDict()  # request ids whose gateway turn ended -> how (complete/error/...)

FAILED_TEXT = ("**Council** — the council couldn't run this time (%s). Nothing was sent to any assistant's tools and "
               "nothing was changed. Please try again.")


def council_status(request_id: str):
    with _LOCK:
        how = _SETTLED.get(request_id)
    if how is not None:   # the gateway turn ended (saved and sent, or failed): that is the answer (GPT R25)
        st = dict(JOBS.status(request_id) or {"request_id": request_id, "answered": 0, "total": len(core.SEATS)})
        st.update({"done": True, "settled": how})
        return st
    st = JOBS.status(request_id)
    if st is not None:
        st = dict(st)
        st["done"] = False    # the seats may be done; the turn is not until its report is saved and sent
        return st
    with _LOCK:
        if request_id in _STARTED:
            return {"request_id": request_id, "done": False, "queued": True, "answered": 0, "total": len(core.SEATS)}
        t0 = ACCEPTED.get(request_id)
        if request_id in _EXPIRED or (t0 is not None and time.monotonic() - t0 > QUEUE_S):
            # accepted but never started: a final answer, and final for the worker too (it checks _EXPIRED first)
            _EXPIRED.add(request_id)
            ACCEPTED.pop(request_id, None)
            return {"request_id": request_id, "done": True, "not_started": True, "answered": 0, "total": len(core.SEATS)}
        if t0 is not None:
            return {"request_id": request_id, "done": False, "queued": True, "answered": 0, "total": len(core.SEATS)}
    return None


def _remember(request_id: str) -> bool:
    """True the first time a request id is seen (kept for the last 500)."""
    with _LOCK:
        if request_id in _RECENT:
            return False
        _RECENT[request_id] = time.time()
        while len(_RECENT) > 500:
            _RECENT.popitem(last=False)
        return True


# ---- secrets that must never reach the assistant's commands (GPT R1 #1)

_PROTECTED_ENV = ("CLAUDE_CODE_OAUTH_TOKEN", "QOSHA_GEMINI_HELPER_KEY")


def protect_env() -> bool:
    """The Gemini helper key leaves the environment (kept in memory here); the Claude seat token stays where the
    engine's credential pool reads it, and both names join the engine's list of variables it never passes to a
    command, a background process or a container it starts (tools/environments/local.py, docker.py)."""
    k = os.environ.pop("QOSHA_GEMINI_HELPER_KEY", None)
    if k:
        _SECRETS["gemini"] = k
    ok = False
    try:
        import tools.environments.local as local
        orig = local._is_hermes_internal_secret
        if not getattr(orig, "__qosha_council__", False):
            # applied by the engine on EVERY child-environment path, also when credentials are inherited
            # (hermes_subprocess_env(inherit_credentials=True)); GPT R2 #7
            def _secret(key, _orig=orig):
                return key in _PROTECTED_ENV or _orig(key)
            _secret.__qosha_council__ = True
            local._is_hermes_internal_secret = _secret
        local._ALWAYS_STRIP_KEYS = frozenset(local._ALWAYS_STRIP_KEYS) | frozenset(_PROTECTED_ENV)
        local._HERMES_PROVIDER_ENV_BLOCKLIST = frozenset(local._HERMES_PROVIDER_ENV_BLOCKLIST) | frozenset(_PROTECTED_ENV)
        ok = True
    except Exception as exc:
        log.error("council: could not protect child environments (%s)", type(exc).__name__)
    try:
        import tools.environments.docker as docker
        docker._HERMES_PROVIDER_ENV_BLOCKLIST = frozenset(docker._HERMES_PROVIDER_ENV_BLOCKLIST) | frozenset(_PROTECTED_ENV)
    except Exception:
        pass   # docker support is optional
    try:   # explicitly forwarded variables too (GPT R3 #8)
        import tools.environments.docker as docker
        for cls in [c for c in vars(docker).values() if isinstance(c, type) and hasattr(c, "_resolve_passthrough_env")]:
            fn = cls._resolve_passthrough_env
            if getattr(fn, "__qosha_council__", False):
                continue
            def _wrapped(self, _fn=fn):
                env, unset = _fn(self)
                for n in _PROTECTED_ENV:
                    env.pop(n, None)
                return env, unset
            _wrapped.__qosha_council__ = True
            cls._resolve_passthrough_env = _wrapped
    except Exception:
        pass
    if not ok:
        # fail safe: without the protection the seat token must not stay where a command could inherit it; Claude then
        # answers on the Qosha API key (the existing fallback)
        os.environ.pop("CLAUDE_CODE_OAUTH_TOKEN", None)
    return ok


def _local_title(text: str) -> str:
    words = re.sub(r"\s+", " ", core.redact(text or "")[0]).strip().split(" ")[:6]
    return ("Council: " + " ".join(words))[:60].strip() or "Council"


def gemini_helper_key() -> str:
    return _SECRETS.get("gemini") or os.environ.get("QOSHA_GEMINI_HELPER_KEY", "")


# ---------------------------------------------------------------- the gateway wrapper (prompt.submit)

def _gateway():
    import tui_gateway.server as srv
    return srv


def _sanitize(text: str) -> str:
    """The engine's own prompt sanitizer (prompt.submit runs it too)."""
    try:
        from hermes_cli.input_sanitize import sanitize_user_prompt_text
        return sanitize_user_prompt_text(text)
    except Exception:
        return text


def _history_context(session) -> str:
    """The last few visible messages before this one, as plain reference for a self-contained brief."""
    try:
        hist = list(session.get("history") or [])
    except Exception:
        return ""
    out, size = [], 0
    for msg in reversed(hist[-12:]):
        role = msg.get("role")
        content = msg.get("content")
        if role not in ("user", "assistant") or not isinstance(content, str) or not content.strip():
            continue
        line = "%s: %s" % ("Person" if role == "user" else "Qosha", content.strip())
        if size + len(line) > CONTEXT_CHARS:
            break
        out.append(line)
        size += len(line)
    return "\n\n".join(reversed(out))


_SESSION_LOCKS: "dict[str, threading.Lock]" = {}


def _session_lock(sid: str) -> threading.Lock:
    with _LOCK:
        lk = _SESSION_LOCKS.get(sid)
        if lk is None:
            lk = _SESSION_LOCKS[sid] = threading.Lock()
            if len(_SESSION_LOCKS) > 2000:
                for k in list(_SESSION_LOCKS)[:500]:
                    if not _SESSION_LOCKS[k].locked():
                        _SESSION_LOCKS.pop(k, None)
        return lk


def _chat_key(session, sid: str) -> str:
    return str((session or {}).get("session_key") or sid)


def _persist(srv, session, role: str, content: str) -> None:
    """One message into the chat's live history and its saved rows, the way the engine adds its own notes
    (tui_gateway/server.py: _append_model_switch_marker): history under its lock, then the chat's database."""
    entry = {"role": role, "content": content}
    lock = session.get("history_lock")

    def add():
        session.setdefault("history", []).append(entry)
        session["history_version"] = int(session.get("history_version", 0)) + 1
    if lock is not None:
        with lock:
            add()
    else:
        add()
    key = str(session.get("session_key") or "").strip()
    if not key:
        raise RuntimeError("chat has no key")
    # the chat's row first, always (GPT R23 #1: a built agent's database handle does not mean the row exists yet)
    srv._ensure_session_db_row(session)
    saved = False
    agent = session.get("agent")
    db = getattr(agent, "_session_db", None) if agent is not None else None
    if db is not None:
        try:
            db.append_message(session_id=key, role=role, content=content)
            saved = True
        except Exception:
            saved = False      # e.g. the agent's handle closed with the chat; the shared one below
    if not saved:
        with srv._session_db(session) as sdb:
            if sdb is None:
                raise RuntimeError("no database")
            sdb.append_message(session_id=key, role=role, content=content)
    # GPT R23 #2: the engine's own marker (run_agent._DB_PERSISTED_MARKER) so its flush never writes it again
    entry["_db_persisted"] = True


def _title_new_chat(srv, session, text: str) -> None:
    """A chat that starts with a council message gets a local title (no model is asked to name it)."""
    key = str(session.get("session_key") or "").strip()
    if not key:
        return
    try:
        import agent.title_generator as tg
        with srv._session_db(session) as sdb:
            if sdb is not None and not sdb.get_session_title(key):
                tg._persist_session_title(sdb, key, _local_title(text), source="derived", dedupe=False)
    except Exception:
        pass


TURN_S = None   # the whole gateway turn's deadline (seconds); None: the council's cap + 60 s for saving and delivery


def _release(session):
    lock = session.get("history_lock")
    if lock is not None:
        with lock:
            session["running"] = False
    else:
        session["running"] = False


def _other_live(srv, session, key: str):
    """The same chat open again in other live records (reopened, another tab), as (gateway id, record)."""
    try:
        return [(s2id, s2) for s2id, s2 in list(srv._sessions.items())
                if s2 is not session and str((s2 or {}).get("session_key") or "") == key]
    except Exception:
        return []


def _council_turn(srv, sid: str, session, key: str, text: str, mode: str, request_id: str, context: str, first: bool,
                  state=None):
    """The council's turn, in its own thread: the person's message saved, the council asked, its report saved and sent.
    One idempotent settle ends it, whoever comes first (the report, a failure, the deadline): the chat is released, every
    live copy of the chat (reopened meanwhile, another tab) gets the exchange in its history and the completion, and
    nothing is written or sent after that (GPT R24 #1, #2)."""
    with _LOCK:
        if request_id in _EXPIRED:     # told "did not start" already (GPT R23 #6): it never starts after that
            _RUNNING.pop(key, None)
            expired = True
        else:
            ACCEPTED.pop(request_id, None)
            _STARTED.add(request_id)
            if len(_STARTED) > 5000:
                _STARTED.clear()       # only ids of the last minutes matter (the page polls one request)
            expired = False
    if expired:
        _release(session)
        return
    # made at acceptance and kept for the whole turn (GPT R25 #1): a Stop or the deadline is never forgotten, and every
    # step below checks it before asking anyone or writing anything
    state = state if state is not None else {"settled": False, "stopped": False}
    slock = threading.Lock()

    def halted() -> bool:
        return bool(state.get("settled") or state.get("stopped"))

    def settle(status: str, report: str, saved: bool) -> bool:
        with slock:
            if state["settled"]:
                return False
            state["settled"] = True
        if state.get("stopped") and status == "complete":
            status = "interrupted"
        with _LOCK:
            cur = _RUNNING.get(key) or {}
            if cur.get("request_id") == request_id:
                _RUNNING.pop(key, None)
            _SETTLED[request_id] = status
            while len(_SETTLED) > 2000:
                _SETTLED.popitem(last=False)
        _release(session)
        for s2id, s2 in _other_live(srv, session, key):   # the chat open again elsewhere (reopened, another tab)
            try:
                if saved:   # the exchange joins its history (already saved: marked so)
                    lock2 = s2.get("history_lock")
                    def add(s2=s2):
                        h = s2.setdefault("history", [])
                        tail = [e for e in h[-6:] if isinstance(e, dict)]
                        if not any(e.get("role") == "user" and e.get("content") == text for e in tail):
                            h.append({"role": "user", "content": text, "_db_persisted": True})
                        if not any(e.get("role") == "assistant" and e.get("content") == report for e in tail):
                            h.append({"role": "assistant", "content": report, "_db_persisted": True})
                        s2["history_version"] = int(s2.get("history_version", 0)) + 1
                    if lock2 is not None and lock2.acquire(timeout=5):
                        try:
                            add()
                        finally:
                            lock2.release()
                    elif lock2 is None:
                        add()
                srv._emit("message.complete", s2id, {"text": report, "status": status})   # also a failure (GPT R25)
            except Exception:
                pass
        try:
            srv._emit("message.complete", sid, {"text": report, "status": status})
        except Exception:
            pass
        return True

    limit = TURN_S if TURN_S is not None else core.OVERALL_S + 60.0

    def overdue():
        JOBS.cancel(request_id)
        if settle("error", FAILED_TEXT % "it took too long", False):
            log.warning("council turn passed its deadline; settled as failed")
    timer = threading.Timer(limit, overdue)
    timer.daemon = True
    timer.start()
    report = None
    try:
        srv._emit("message.start", sid)
        _persist(srv, session, "user", text)
        if first and not halted():
            _title_new_chat(srv, session, text)
        if halted():   # Stop or the deadline came first: no seat is asked (GPT R25 #1)
            report = "**Council** — stopped before it started. Nothing was sent and nothing was changed."
        else:
            res = run(build_brief(text, context), mode, request_id, sid, should_start=lambda: not halted())
            report = res.report
    except Exception as exc:
        log.warning("council failed: %s", type(exc).__name__)
        report = ("**Council** — stopped before it started. Nothing was sent and nothing was changed." if halted()
                  else FAILED_TEXT % type(exc).__name__)
    try:
        if state["settled"]:
            return                      # past its deadline: nothing more is written or sent
        try:
            _persist(srv, session, "assistant", report)
            settle("complete", report, True)
        except Exception as exc:
            log.warning("council report not saved: %s", type(exc).__name__)
            # never "complete" for a report that is not in the chat (GPT R23 #4)
            settle("error", report + "\n\n(This answer could not be saved in the chat; copy it if you need it.)", False)
    finally:
        timer.cancel()
        if not state["settled"]:
            settle("error", report or FAILED_TEXT % "no report", False)


def _accept_council_field() -> None:
    """Engine v0.22+ checks every prompt.submit against a strict list of fields and refuses unknown ones before any
    handler runs ("Extra inputs are not permitted"). The council's request rides on prompt.submit as `qosha_council`
    ({mode, request_id}), so that one field is added to the engine's own description of the call (the running engine
    only; its files are not edited)."""
    try:
        import dataclasses
        from typing import Optional
        from tui_gateway.contracts import registry
        for table in (registry.METHODS,):
            entry = table.get("prompt.submit")
            if entry is None or "qosha_council" in getattr(entry.params, "model_fields", {}):
                continue
            params = type("PromptSubmitParams", (entry.params,), {"__annotations__": {"qosha_council": Optional[dict]},
                                                                   "qosha_council": None, "__module__": entry.params.__module__})
            table["prompt.submit"] = dataclasses.replace(entry, params=params)
    except Exception as exc:
        import logging
        logging.getLogger("qosha.council").warning("the council field was not added to prompt.submit: %s", type(exc).__name__)


def install_gateway_wrapper(import_if_missing: bool = True) -> bool:
    """Wraps the engine's prompt.submit and session.interrupt once (idempotent). Returns True when in place.

    The plugin's registration runs in every engine process (the CLI, cron, the box's approval-guard self-test) and
    passes import_if_missing=False: there the gateway module is only wrapped if that process already loaded it, never
    imported, because importing it points the whole process's stdout at stderr (tui_gateway/server.py: sys.stdout =
    sys.stderr) - which made the box's guard check fail to read its own result (8 Nov, external first paint). The
    screens' process, which hosts the gateway, imports it (plugin_api.py)."""
    if not import_if_missing and "tui_gateway.server" not in sys.modules:
        return False
    try:
        srv = _gateway()
    except Exception:
        return False
    methods = getattr(srv, "_methods", None)
    if not isinstance(methods, dict) or "prompt.submit" not in methods:
        return False
    orig = methods["prompt.submit"]
    if getattr(orig, "__qosha_council__", False):
        return True
    _accept_council_field()

    def submit(rid, params: dict):
        # every submission for one chat passes here one at a time (GPT R5 #3)
        sid0 = params.get("session_id", "") if isinstance(params, dict) else ""
        with _session_lock(sid0):
            return _submit(rid, params)

    def _submit(rid, params: dict):
        meta = params.get("qosha_council") if isinstance(params, dict) else None
        sid = params.get("session_id", "") if isinstance(params, dict) else ""
        session = srv._sessions.get(sid) if isinstance(getattr(srv, "_sessions", None), dict) else None
        if not isinstance(meta, dict):
            # an ordinary message: the engine's own, unless the council is answering in this chat right now (the
            # engine would queue it behind a turn that isn't its own; another tab can send meanwhile)
            if session is not None:
                with _LOCK:
                    busy = _chat_key(session, sid) in _RUNNING
                if busy:
                    return srv._err(rid, 4093, "The council is still answering in this chat; send this when it has finished")
            return orig(rid, params)
        request_id, claimed, key = "", False, ""
        try:
            if meta.get("mode") not in ("ask", "review"):
                return srv._err(rid, 4090, "The council got an unknown request")
            mode = meta["mode"]
            if session is None:
                return srv._err(rid, 4091, "This chat is not open any more; open it again and resend")
            request_id = re.sub(r"[^A-Za-z0-9_-]", "", str(meta.get("request_id") or ""))[:64] or uuid.uuid4().hex
            if not _remember(request_id):   # a double click or a resend of the same request joins the first
                return srv._ok(rid, {"status": "duplicate", "request_id": request_id})
            text = params.get("text", "")
            text = _sanitize(text) if isinstance(text, str) else ""
            if not text.strip():
                raise ValueError("empty")
            if len(text) > core.MAX_BRIEF_CHARS:   # refused before any scanning (GPT R13 #2)
                with _LOCK:
                    _RECENT.pop(request_id, None)
                return srv._err(rid, 4094, "This is too long for the council (over %d characters)" % core.MAX_BRIEF_CHARS)
            key = _chat_key(session, sid)
            ready = session.get("resume_history_ready")
            if ready is not None and not ready.is_set():
                # GPT R23 #5: a reopened chat still loading its history would replace it after the council answered
                with _LOCK:
                    _RECENT.pop(request_id, None)
                return srv._err(rid, 4095, "This chat is still opening; send it again in a moment")
            with _LOCK:
                other = key in _RUNNING        # GPT R23 #4: the same chat reopened while its council still answers
            if other:
                with _LOCK:
                    _RECENT.pop(request_id, None)
                return srv._err(rid, 4092, "The council is still answering in this chat; send this when it has finished")
            lock = session.get("history_lock")
            if lock is not None:
                with lock:
                    if not session.get("running"):
                        session["running"] = claimed = True
            elif not session.get("running"):
                session["running"] = claimed = True
            if not claimed:
                with _LOCK:
                    _RECENT.pop(request_id, None)
                return srv._err(rid, 4092, "Qosha is still answering; send this to the council when it has finished")
            # the saved row and the seats only ever see the redacted text (GPT R1 #3); the context is the chat before it
            clean = core.redact(text)[0]
            context = core.redact(_history_context(session))[0]
            first = not any(isinstance(m, dict) and m.get("role") in ("user", "assistant")
                            for m in (session.get("history") or []))
            turn_state = {"settled": False, "stopped": False}
            with _LOCK:
                _RUNNING[key] = {"request_id": request_id, "sid": sid, "state": turn_state}
                ACCEPTED[request_id] = time.monotonic()
                for old in [k for k, t0 in list(ACCEPTED.items()) if time.monotonic() - t0 > 600]:
                    ACCEPTED.pop(old, None)
            # D4: a reload mid-council does not tear the chat down (the page reconnects; the report is saved anyway)
            session["close_on_disconnect"] = False
            # GPT R23 #3: the events go to the tab that sent this, as the engine's own submit does
            try:
                from tui_gateway.transport import current_transport
                t = current_transport()
                if t is not None:
                    session["transport"] = t
            except Exception:
                pass
            threading.Thread(target=_council_turn, name="qosha-council",
                             args=(srv, sid, session, key, clean, mode, request_id, context, first, turn_state),
                             daemon=True).start()
            log.info("council turn started (%s)", mode)
            return srv._ok(rid, {"status": "streaming", "request_id": request_id})
        except Exception as exc:
            log.warning("council could not start: %s", type(exc).__name__)
            try:
                with _LOCK:
                    if request_id:
                        _RECENT.pop(request_id, None)
                        ACCEPTED.pop(request_id, None)
                        if (_RUNNING.get(key) or {}).get("request_id") == request_id:
                            _RUNNING.pop(key, None)
                if claimed:   # the chat is released: nothing started in it
                    session["running"] = False
            except Exception:
                pass
            try:
                return srv._err(rid, 5090, "The council could not start")
            except Exception:
                return {"jsonrpc": "2.0", "id": rid, "error": {"code": 5090, "message": "the council could not start"}}

    submit.__qosha_council__ = True
    submit.__wrapped__ = orig
    methods["prompt.submit"] = submit

    stop = methods.get("session.interrupt")
    if stop is not None and not getattr(stop, "__qosha_council__", False):
        def interrupt(rid, params: dict):
            """Stop in a chat where the council is answering stops the council (its report says so)."""
            sid = params.get("session_id", "") if isinstance(params, dict) else ""
            session = srv._sessions.get(sid) if isinstance(getattr(srv, "_sessions", None), dict) else None
            if session is not None:
                with _LOCK:
                    run_ = _RUNNING.get(_chat_key(session, sid))
                if run_:
                    run_["stopped"] = True
                    if isinstance(run_.get("state"), dict):
                        run_["state"]["stopped"] = True   # kept for the whole turn, whatever ends it (GPT R25 #1)
                    JOBS.cancel(run_["request_id"])
                    return srv._ok(rid, {"status": "interrupting"})
            return stop(rid, params)
        interrupt.__qosha_council__ = True
        interrupt.__wrapped__ = stop
        methods["session.interrupt"] = interrupt
    return True


def _emit(gw_sid: str, payload: dict):
    try:
        srv = _gateway()
        srv._emit("council.progress", gw_sid, payload)
    except Exception:
        pass


# ---------------------------------------------------------------- the seats this Qosha has

def _env_box() -> bool:
    return os.environ.get("QOSHA_BOX") == "1"


def _gemini_cli_seat():
    """A local install: Gemini through Google's own command-line tool on the person's subscription
    (qosha_guard/gemini_cli.py), when the "Connect your AI" panel found it signed in. Text in, text out."""
    import importlib.util
    try:
        spec = importlib.util.spec_from_file_location("qosha_gemini_cli_council", Path(__file__).resolve().parent.parent / "qosha_guard" / "gemini_cli.py")
        g = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(g)
        if not g.connected():
            return None
    except Exception:
        return None

    def backend(prompt: bytes, timeout: float, cancel) -> core.SeatAnswer:
        # the council's stop signal goes through: Stop (or an abandoned attempt) sends nothing more to Gemini and ends
        # a running agy, the retry included (review round 2, #13)
        r = g.ask(prompt.decode("utf-8"), timeout=max(20, int(timeout) - 2), cancel=cancel)
        if not r.get("ok"):
            err = r.get("error")
            if err == "cancelled":
                raise core.SeatError(core.FATAL, "stopped")
            if err in ("signed_out", "not_installed"):
                raise core.SeatError(core.NOT_CONNECTED, "not connected")
            raise core.SeatError(core.RETRYABLE if err in ("timeout", "no_answer") else core.FATAL, str(r.get("plain") or err))
        return core.SeatAnswer(r["answer"], "Gemini (your Google subscription)")
    return backend


def _gemini_backend():
    if not _env_box() and not os.environ.get("QOSHA_LAB") and not os.environ.get("QOSHA_CONNECTOR_URL"):
        return _gemini_cli_seat()
    url = os.environ.get("QOSHA_GEMINI_HELPER_URL", "")
    if url:   # the cloud box's Gemini seat helper (its key is only in this process's environment)
        return seats.helper_seat(url, gemini_helper_key)
    if not _env_box() and os.environ.get("QOSHA_CONNECTOR_URL") and os.environ.get("QOSHA_COUNCIL_MAC_GEMINI") == "1":
        try:
            import importlib.util
            p = os.environ.get("QOSHA_GOOGLE_API_PATH", "")
            spec = importlib.util.spec_from_file_location("qosha_council_connector_client", p)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return seats.connector_seat(mod, "gemini-3.8-flash-high")
        except Exception:
            return None
    return None


def _codex_signed_in() -> bool:
    try:
        from agent.credential_pool import load_pool
        return bool(load_pool("openai-codex").entries())
    except Exception:
        return False


def seat_backends():
    return {"claude": seats.engine_seat("anthropic", seats.SEAT_MODELS["claude"]),
            "chatgpt": seats.engine_seat("openai-codex", seats.SEAT_MODELS["chatgpt"]) if _codex_signed_in() else None,
            "gemini": _gemini_backend()}


def _run_log():
    try:
        from hermes_constants import get_hermes_home
        d = Path(get_hermes_home()) / "logs"
        d.mkdir(parents=True, exist_ok=True)
        return core.jsonl_logger(d / "qosha-council.jsonl")
    except Exception:
        return None


def build_brief(text: str, context: str) -> str:
    brief = text.strip()
    if context:
        brief += ("\n\n---\nEarlier in this conversation (for reference only):\n" + context)
    return brief


def run(brief: str, mode: str, request_id: str, gw_sid: str = "", backends=None, merges=None, should_start=None):
    """One council; progress goes to the chat as council.progress events and to JOBS for a page that reconnects.
    should_start is asked inside the job, right before any seat (a Stop or the deadline that came first wins)."""
    def body(on_progress, cancel):
        if should_start is not None and not should_start():
            raise RuntimeError("stopped before it started")
        def prog(e):
            on_progress(e)
            if gw_sid:
                _emit(gw_sid, e)
        return core.run_council(brief, mode, backends if backends is not None else seat_backends(),
                                merges if merges is not None else seats.merge_backends(),
                                request_id=request_id, on_progress=prog, cancel=cancel, log=_run_log())
    job, _new = JOBS.start(request_id, body)
    ACCEPTED.pop(request_id, None)            # the job answers for it now (Gemini R2 #4)
    if not job["done"].wait(core.OVERALL_S + 5):    # GPT R1 #6: never past the cap; whatever is still running stops
        job["cancel"].set()
        raise TimeoutError("council took too long")
    res = job.get("result")
    if res is None:
        raise RuntimeError("council did not finish")
    return res


# ---------------------------------------------------------------- registration

def register(ctx) -> None:
    """The secret protection and the gateway wrapper. No middleware and no assistant tool: only the person's explicit
    choice starts the council, and the gateway answers it without the engine's turn runner (Ren, 8 Nov; 9 Nov)."""
    protect_env()
    install_gateway_wrapper(import_if_missing=False)
