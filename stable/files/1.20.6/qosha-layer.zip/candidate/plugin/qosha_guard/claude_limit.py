"""Claude subscription first; the pay-per-use API key only by the person's choice (Ren, card, 21 Nov 2026 ~13:00 MST:
"Stop and tell me"; standing rule "subscriptions, not API keys"). When the Claude subscription hits its usage limit,
Qosha stops and says the limit is reached and when it resets. ANTHROPIC_API_KEY stays where the person saved it,
untouched; Qosha just never sends it. Chat, scheduled jobs and side calls alike.

Where the engine could send the key, and what this does there (the engine's files are not edited):
- before every Claude request the engine re-reads the token and prefers an API key over a sign-in stored the way
  Qosha's Connect AI stores it (agent/anthropic_credentials.resolve_anthropic_token): that lookup now gives the
  subscription's token instead, or nothing;
- a chat that already holds the key (it began before the sign-in) is stopped with the plain message rather than
  continued on the key (client_lifecycle._try_refresh_anthropic_client_credentials);
- the credential pool never offers the key (selection, rotation after a 429, leases);
- no Claude client can be built with the key (agent/anthropic_adapter.build_anthropic_client), the backstop;
- a Claude limit longer than 2 minutes ends the retries at once, and the engine's terminal message for it (which
  names its own fallback command) becomes Qosha's plain words with the reset time the failing request carried.
The rule is on once this computer has had a Claude subscription login (remembered in a small marker file holding no
secret, so a sign-in that later breaks or is pruned never turns silently into paying) and the person has not chosen
"Use my API key" (Settings; config.yaml qosha_ai.claude_key_on_limit: true). With that choice the subscription still
goes first and the key is used only while the subscription can't answer. A computer that never had a Claude
subscription uses its key exactly as before."""
from __future__ import annotations

import hmac
import json
import logging
import os
import time
from pathlib import Path

log = logging.getLogger("qosha.claude_limit")
CFG = "qosha_ai"
CHOICE = "claude_key_on_limit"
LONG_LIMIT_S = 120     # a Claude limit longer than this ends the retries at once (shorter ones keep the engine's wait)
_cache = {"at": 0.0, "home": None, "value": False}


class ClaudeKeyRefused(PermissionError):
    """Raised instead of sending ANTHROPIC_API_KEY while the rule is on; its text is the plain message."""


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or (Path.home() / ".hermes"))


def _marker(home: Path) -> Path:
    return home / "qosha" / "claude-subscription-seen"


def key_on_limit() -> bool:
    """The person's explicit choice in Settings: the API key (pay per use) when the subscription can't answer."""
    try:
        from hermes_cli.config import read_raw_config_readonly
        q = (read_raw_config_readonly() or {}).get(CFG) or {}
        return isinstance(q, dict) and q.get(CHOICE) is True
    except Exception:
        return False


def _is_oauth(token) -> bool:
    try:
        from agent.anthropic_credentials import _is_oauth_token
        return bool(_is_oauth_token(str(token or "")))
    except Exception:
        return str(token or "").startswith(("sk-ant-oat", "eyJ", "cc-"))


def _login_entries(entries) -> str:
    """A Claude subscription login among the engine's own pool rows: "owned" (Qosha's Connect AI or a .env token, counted
    even when it stopped working, and remembered), "claude_code" (Claude Code's own command-line login: counts only
    while it works, never remembered), or "" (none)."""
    found = ""
    for e in entries or []:
        if getattr(e, "auth_type", None) != "oauth":
            continue
        if str(getattr(e, "source", "") or "") == "claude_code":
            if getattr(e, "last_status", None) != "dead":
                found = "claude_code"
            continue
        return "owned"
    return found


def _note_seen(home: Path) -> None:
    try:
        m = _marker(home)
        if not m.exists():
            m.parent.mkdir(parents=True, exist_ok=True)
            m.write_text(json.dumps({"seen": time.time()}), encoding="utf-8")
    except OSError:
        pass


def subscription_seen(entries=None, home: Path | None = None) -> bool:
    h = home or _home()
    if _marker(h).exists():
        return True
    # ANTHROPIC_TOKEN may hold a Console key: it counts only when it is a subscription token
    found = bool((os.environ.get("CLAUDE_CODE_OAUTH_TOKEN") or "").strip()) or _is_oauth(
        (os.environ.get("ANTHROPIC_TOKEN") or "").strip())
    if not found:
        try:
            if entries is None:
                from agent.credential_pool import load_pool
                entries = load_pool("anthropic").entries()
            kind = _login_entries(entries)
        except Exception:
            return True          # the login store can't be read: unknown, so the key is withheld (nothing remembered)
        if kind == "claude_code":
            return True          # counts while it works; not remembered
        found = kind == "owned"
    if found:
        _note_seen(h)
    return found


def rule_active(entries=None) -> bool:
    if key_on_limit():
        return False
    h = _home()
    if entries is None and _cache["value"] and _cache["home"] == str(h) and time.monotonic() - _cache["at"] < 5:
        return True              # only "the rule is on" is cached: a fresh sign-in is never missed
    v = subscription_seen(entries, h)
    if entries is None:
        _cache.update(at=time.monotonic(), home=str(h), value=v)
    return v


def _paid_keys() -> list:
    """The values the person saved as ANTHROPIC_API_KEY (never logged, never compared outside this process)."""
    out = []
    for getter in (lambda: os.environ.get("ANTHROPIC_API_KEY"),):
        try:
            v = (getter() or "").strip()
            if v:
                out.append(v)
        except Exception:
            pass
    try:
        from agent.credential_pool import get_env_prefer_dotenv
        v = (get_env_prefer_dotenv("ANTHROPIC_API_KEY") or "").strip()
        if v:
            out.append(v)
    except Exception:
        pass
    return out


def _is_paid(token) -> bool:
    t = str(token or "").strip()
    if not t or _is_oauth(t):
        return False
    return t.startswith("sk-ant-") or any(hmac.compare_digest(t, k) for k in _paid_keys())


def _subscription_token(model=None):
    """A subscription token the pool can use now for `model` (never the key), or None."""
    try:
        from agent.credential_pool import AUTH_TYPE_OAUTH, load_pool
        pool = load_pool("anthropic")
        with pool._lock:
            available = pool._available_entries(model=model)[0]
        for e in available:
            if getattr(e, "auth_type", None) == AUTH_TYPE_OAUTH:
                tok = e.runtime_api_key or getattr(e, "access_token", "")
                if tok:
                    return tok
    except Exception:
        pass
    return None


def stop_words(reset_seconds: float | None = None, now: float | None = None) -> str:
    """The plain message: the limit is reached (or the subscription can't answer), when it resets, no paid key."""
    now = now or time.time()
    when = " Claude didn't say when it resets."
    if reset_seconds and reset_seconds > 0:
        at = now + reset_seconds
        mins = max(1, int((reset_seconds + 59) // 60))
        wait = ("%d min" % mins) if mins < 120 else ("about %d h" % round(mins / 60))
        when = " It resets at %s (in %s)." % (time.strftime("%H:%M", time.localtime(at)), wait)
    return ("Your Claude subscription can't answer right now: it reached its usage limit, or its sign-in needs to be "
            "renewed (Connect AI)." + when + " Qosha doesn't switch to your pay-per-use API key for this; you can "
            "choose that in Settings > Claude usage limit. Your message is saved: send it again later.")


def limit_words(reset_seconds: float | None, now: float | None = None) -> str:
    now = now or time.time()
    when = " Claude didn't say when it resets."
    if reset_seconds and reset_seconds > 0:
        at = now + reset_seconds
        mins = max(1, int((reset_seconds + 59) // 60))
        wait = ("%d min" % mins) if mins < 120 else ("about %d h" % round(mins / 60))
        when = " It resets at %s (in %s)." % (time.strftime("%H:%M", time.localtime(at)), wait)
    return ("Your Claude subscription reached its usage limit." + when + " Qosha doesn't switch to your pay-per-use "
            "API key for this; you can choose that in Settings > Claude usage limit. Your message is saved: send it "
            "again after the reset.")


# --- the patches ----------------------------------------------------------------------------------------------------
def _patch_resolver() -> None:
    from agent import anthropic_credentials as ac
    orig = ac.resolve_anthropic_token
    if getattr(orig, "qosha_claude_limit", False):
        return

    def resolve_anthropic_token(*a, **kw):
        tok = orig(*a, **kw)
        try:
            if _is_paid(tok):
                model = kw.get("model")
                if rule_active():
                    return _subscription_token(model)          # the subscription, or nothing; never the key
                sub = _subscription_token(model)               # "Use my API key": still the subscription first
                if sub:
                    return sub
        except Exception:
            if rule_active():
                return None
        return tok

    resolve_anthropic_token.qosha_claude_limit = True
    resolve_anthropic_token.__wrapped__ = orig
    ac.resolve_anthropic_token = resolve_anthropic_token


def _patch_builder() -> None:
    from agent import anthropic_adapter as aa
    orig = aa.build_anthropic_client
    if getattr(orig, "qosha_claude_limit", False):
        return

    def build_anthropic_client(api_key, *a, **kw):
        if isinstance(api_key, str) and _is_paid(api_key) and rule_active():
            raise ClaudeKeyRefused(stop_words())
        return orig(api_key, *a, **kw)

    build_anthropic_client.qosha_claude_limit = True
    build_anthropic_client.__wrapped__ = orig
    aa.build_anthropic_client = build_anthropic_client


def _patch_refresh() -> None:
    from agent import client_lifecycle as cl_mod
    cls = cl_mod.ClientLifecycleMixin
    orig = cls._try_refresh_anthropic_client_credentials
    if getattr(orig, "qosha_claude_limit", False):
        return

    def _try_refresh_anthropic_client_credentials(self):
        changed = orig(self)
        if (str(getattr(self, "provider", "") or "") == "anthropic" and _is_paid(getattr(self, "_anthropic_api_key", ""))
                and rule_active()):
            raise ClaudeKeyRefused(stop_words())                # a chat still holding the key: stop, never send it
        return changed

    _try_refresh_anthropic_client_credentials.qosha_claude_limit = True
    cls._try_refresh_anthropic_client_credentials = _try_refresh_anthropic_client_credentials


def _patch_pool() -> None:
    from agent import credential_pool as cp
    cls = cp.CredentialPool
    orig = cls._available_entries
    if getattr(orig, "qosha_no_key_fallback", False):
        return

    def _available_entries(self, *a, **kw):
        # decided before the engine's own selection runs, which may prune a dead sign-in row
        try:
            rule = getattr(self, "provider", None) == "anthropic" and rule_active(list(self._entries))
        except Exception:
            rule = getattr(self, "provider", None) == "anthropic"        # unknown: withhold the key
        available, pending = orig(self, *a, **kw)
        if rule:
            available = [e for e in available if getattr(e, "auth_type", None) != cp.AUTH_TYPE_API_KEY]
        return available, pending

    _available_entries.qosha_no_key_fallback = True
    _available_entries.__wrapped__ = orig
    cls._available_entries = _available_entries


def _ends_turn(agent, api_error) -> bool:
    if str(getattr(agent, "provider", "") or "").lower() != "anthropic" or not rule_active():
        return False
    from agent.retry_utils import provider_retry_after_seconds
    cooldown = provider_retry_after_seconds(api_error)
    return cooldown is not None and cooldown > LONG_LIMIT_S


def _patch_ends_turn() -> None:
    from agent import turn_api_error as tae
    from agent import turn_recovery as tr
    orig = tr.free_tier_cooldown_ends_turn
    if getattr(orig, "qosha_claude_limit", False):
        return

    def free_tier_cooldown_ends_turn(agent, api_error, base_url, *a, **kw):
        try:
            if orig(agent, api_error, base_url, *a, **kw):
                return True
        except Exception:
            pass
        try:
            return _ends_turn(agent, api_error)
        except Exception:
            return False

    free_tier_cooldown_ends_turn.qosha_claude_limit = True
    tr.free_tier_cooldown_ends_turn = free_tier_cooldown_ends_turn
    tae.free_tier_cooldown_ends_turn = free_tier_cooldown_ends_turn


_LIMIT_REASONS = ("rate_limit", "upstream_rate_limit")


def _reset_from(error, reset_seconds):
    if reset_seconds and reset_seconds > 0:
        return reset_seconds
    try:
        from agent.retry_utils import provider_retry_after_seconds
        return provider_retry_after_seconds(error)
    except Exception:
        return None


def _patch_copy() -> None:
    from agent import turn_failure_copy as tfc
    from agent import turn_recovery as tr
    orig = tfc.exhausted_copy
    if getattr(orig, "qosha_claude_limit", False):
        return
    claude_label = tfc.provider_label_for("anthropic")

    def exhausted_copy(reason, *a, label=None, reset_seconds=None, error=None, **kw):
        try:
            if type(error).__name__ == "ClaudeKeyRefused":
                return str(error)                              # stopped instead of sending the key: Qosha's words
            if label == claude_label and str(reason) in _LIMIT_REASONS and rule_active():
                return limit_words(_reset_from(error, reset_seconds))
        except Exception:
            pass
        return orig(reason, *a, label=label, reset_seconds=reset_seconds, error=error, **kw)

    exhausted_copy.qosha_claude_limit = True
    tfc.exhausted_copy = exhausted_copy
    tr.exhausted_copy = exhausted_copy


def _patch_runtime() -> None:
    """The request after a limit (or with the sign-in gone): the engine refuses before any call with its own text,
    which names its command line. While the rule is on, that refusal says Qosha's words instead."""
    from hermes_cli import runtime_provider as rp
    from hermes_cli.auth_constants import AuthError
    orig = rp._anthropic_token_or_raise
    if getattr(orig, "qosha_no_key_fallback", False):
        return

    def _anthropic_token_or_raise(*a, model=None, **kw):
        try:
            return orig(*a, model=model, **kw)
        except AuthError as exc:
            try:
                if not rule_active():
                    raise
                at = reset_at(model)
                secs = (at - time.time()) if at else None
                words = limit_words(secs) if at else stop_words(None)
            except AuthError:
                raise
            except Exception:
                words = stop_words(None)
            raise AuthError(words, provider="anthropic", code=getattr(exc, "code", None) or "qosha_claude_limit",
                            retry_after=secs if at else None, retryable=bool(at)) from None

    _anthropic_token_or_raise.qosha_no_key_fallback = True
    _anthropic_token_or_raise.__wrapped__ = orig
    rp._anthropic_token_or_raise = _anthropic_token_or_raise


_APPLIED = {"ok": None}


def apply() -> bool:
    ok = True
    try:
        subscription_seen()      # remember an existing sign-in before any request can prune its row
    except Exception:
        pass
    for name, fn in (("token lookup", _patch_resolver), ("client builder", _patch_builder),
                     ("chat refresh", _patch_refresh), ("pool", _patch_pool), ("early stop", _patch_ends_turn), ("refusal", _patch_runtime),
                     ("message", _patch_copy)):
        try:
            fn()
        except Exception as exc:
            ok = False
            log.warning("Claude limit: %s not set up (engine changed?): %s", name, type(exc).__name__)
    _APPLIED["ok"] = ok
    return ok


def register(ctx) -> None:
    apply()


def state() -> dict:
    """For Settings: is the rule on, did the person choose the key, is a key saved (never its value)."""
    try:
        ok = _APPLIED["ok"] is not False          # setup failed: never claim the key is held back
        return {"rule": bool(ok and rule_active()), "protected": ok, "chosen": key_on_limit(),
                "key_saved": bool(_paid_keys()), "subscription": subscription_seen()}
    except Exception:
        return {"rule": None}


def reset_at(model: str | None = None, now: float | None = None) -> float | None:
    """When the subscription's limit lifts for `model`, as the engine recorded it from Claude's answer (Retry-After or
    reset); an approximation, so the watch says "about"."""
    now = now or time.time()
    try:
        from agent.credential_pool import AUTH_TYPE_OAUTH, load_pool
        times = []
        for e in load_pool("anthropic").entries():
            if getattr(e, "auth_type", None) != AUTH_TYPE_OAUTH:
                continue
            cand = [e.last_error_reset_at] + ([(e.model_cooldowns or {}).get(model)] if model else [])
            times += [x for x in cand if isinstance(x, (int, float)) and x > now]
        return min(times) if times else None
    except Exception:
        return None
