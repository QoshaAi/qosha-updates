"""Sign in to an AI subscription from Qosha's own screens (Ren, 17 Nov 2026: "sign in from the app"). Mounted at
/api/plugins/qosha/signin.

The engine does ChatGPT (and xAI, MiniMax) sign-in in the app already (device code, /api/providers/oauth/...), and the
page calls that directly. Claude's subscription sign-in exists in the engine only as a terminal command (a PKCE link,
then the code Claude shows is pasted back). These two routes run the same engine flow from the page:

POST /claude/start            -> {"id", "url"}: the person opens url, signs in to Claude, and copies the code shown
POST /claude/finish {id,code} -> {"ok": true} once the engine's own credential pool holds the new Claude sign-in
GET  /status                  -> which subscriptions are signed in (the engine's own oauth status list)

Gemini (Google's own command-line tool on the person's Google subscription, qosha_guard/gemini_cli.py):
POST /gemini/check            -> is the tool installed and signed in
POST /gemini/login/start      -> {"id", "url"}: Google's sign-in, run in the background; the page opens url
POST /gemini/login/finish {id,code} -> the code Google shows goes to the tool; {"ok": true} once Gemini answers
POST /gemini/login/cancel {id}-> ends that sign-in (it ends by itself after 10 minutes)
POST /gemini/open             -> fallback: the same sign-in in a window of its own, brought to the front
POST /gemini/repair           -> reinstalls Qosha's own pinned Google tool (agy_pin.repair) and checks it again
GET  /accounts                -> also "gemini_state"/"gemini_plain"/"gemini_version"/"gemini_checked_at": the last daily
                                 self-check of that tool (shown in "Connect your AI" and in Settings)
"""
from __future__ import annotations

import dataclasses
import secrets
import threading
import time
from typing import Any, Dict

from fastapi import APIRouter, Body, Request
from fastapi.responses import JSONResponse

router = APIRouter()
_PENDING: Dict[str, Dict[str, Any]] = {}
_LOCK = threading.Lock()
TTL = 900


def _gc() -> None:
    now = time.time()
    for k in [k for k, v in _PENDING.items() if now - v["at"] > TTL]:
        _PENDING.pop(k, None)


def _ccli():
    """Qosha's Claude route through the person's own `claude` program (qosha_guard/claude_cli.py), loaded once."""
    import importlib.util, sys
    from pathlib import Path
    mod = sys.modules.get("qosha_claude_cli") or sys.modules.get("plugins.qosha.qosha_guard.claude_cli")
    if mod is None:
        for name, m in list(sys.modules.items()):
            if name.endswith("qosha_guard.claude_cli"):
                return m
        spec = importlib.util.spec_from_file_location("qosha_claude_cli", Path(__file__).resolve().parent.parent / "qosha_guard" / "claude_cli.py")
        mod = importlib.util.module_from_spec(spec)
        sys.modules["qosha_claude_cli"] = mod
        spec.loader.exec_module(mod)
        try:
            mod.apply_route()              # the engine's Claude-login readers stay closed in this process too
        except Exception:
            pass
    return mod


def _from_app(request) -> bool:
    """The request comes from the Qosha app window itself (the approval gate's own check; fails closed): installing
    Claude's program or signing it out is the person's press in the app, never another local client (review CC-8)."""
    import importlib.util, sys
    from pathlib import Path
    try:
        gate = next((m for n, m in list(sys.modules.items()) if n.endswith("qosha_guard.approval_gate")), None)
        if gate is None:
            spec = importlib.util.spec_from_file_location("qosha_approval_gate_cc", Path(__file__).resolve().parent.parent / "qosha_guard" / "approval_gate.py")
            gate = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(gate)
        return bool(gate.from_qosha_window(request.scope))
    except Exception:
        return False


_NOT_APP = {"ok": False, "error": "not_app", "plain": "Open the Qosha app to do this."}


def _plain(r: dict, ok_code: int = 200):
    if r.get("ok"):
        return r
    code = {"not_installed": 409, "expired": 410, "bad_format": 400, "no_press": 403, "not_app": 403,
            "busy": 409}.get(r.get("error"), 502)
    return JSONResponse(dict(r, detail=r.get("plain")), status_code=code)


@router.post("/claude/start")
def claude_start():
    """Claude's own program signs in (cc19, 22 Nov 2026): {"id", "url"}; the page opens url, the person signs in to
    Claude and pastes the code Claude shows into /claude/finish. Qosha never holds the token."""
    if _access_gate():
        return JSONResponse(status_code=403, content={"error": "access_ended", "detail": "Your access to Qosha has ended."})
    return _plain(_ccli().login_start())


@router.post("/claude/finish")
def claude_finish(body: dict = Body(...)):
    if _access_gate():
        return JSONResponse(status_code=403, content={"error": "access_ended", "detail": "Your access to Qosha has ended."})
    return _plain(_ccli().login_finish(str((body or {}).get("id") or ""), str((body or {}).get("code") or "")))


@router.get("/claude/program")
def claude_program():
    """Is Claude's program installed and signed in with a subscription, and does Qosha use it (no token is read)."""
    c = _ccli()
    st = c.status(force=True)
    return {"state": st["state"], "installed": st["state"] != "not_installed", "route": c.route_on(),
            "plain": c.WORDS.get(st["state"], "") if st["state"] != "ready" else "Claude is ready."}


@router.post("/claude/press")
def claude_press(request: Request):
    """A one-time token for one press of Install Claude or Disconnect (asked for inside the click, in the app)."""
    if not _from_app(request):
        return _plain(dict(_NOT_APP))
    return {"press": _ccli().press_new()}


@router.post("/claude/install")
def claude_install(request: Request, body: dict = Body(default={})):
    if not _from_app(request):
        return _plain(dict(_NOT_APP))
    if _access_gate():
        return JSONResponse(status_code=403, content={"error": "access_ended", "detail": "Your access to Qosha has ended."})
    return _plain(_ccli().install(str((body or {}).get("press") or "")))


@router.get("/status")
async def status():
    try:
        _ccli()            # the engine's Claude-login readers are closed before its sign-in list runs (fix slice, item 4)
    except Exception:
        return {"providers": []}      # the readers might be open: the engine's list is not read at all (FS-1)
    from hermes_cli.web_routers.oauth import list_oauth_providers
    try:
        rows = await list_oauth_providers(None)
    except Exception:
        return {"providers": []}
    rows = rows.get("providers", rows) if isinstance(rows, dict) else rows
    return {"providers": [{"id": r.get("id"), "name": r.get("name"), "flow": r.get("flow"),
                           "signed_in": bool((r.get("status") or {}).get("logged_in"))} for r in rows or []]}


@router.get("/local")
def local():
    """Whether this Qosha runs on the person's own computer (not a cloud box, not the Mac lab): the screens then hide
    what a customer doesn't need (the engine's public plugin catalog)."""
    import os
    return {"local": not os.environ.get("QOSHA_BOX") and not os.environ.get("QOSHA_LAB") and not os.environ.get("QOSHA_CONNECTOR_URL")}


def _pool_count(provider: str) -> int:
    """How many sign-ins the engine's own credential pool holds for this provider (a count only; nothing is read out)."""
    try:
        from agent.credential_pool import load_pool
        return len(load_pool(provider).entries())
    except Exception:
        return 0


def _claude_rows(oauth: bool) -> int:
    try:
        from agent.credential_pool import AUTH_TYPE_OAUTH, load_pool
        return sum(1 for e in load_pool("anthropic").entries() if (getattr(e, "auth_type", None) == AUTH_TYPE_OAUTH) == oauth)
    except Exception:
        return 0


def _claude_held_rows() -> int:
    return _claude_rows(True)


def _claude_key_rows() -> int:
    return _claude_rows(False)


@router.get("/accounts")
def accounts():
    """Which AI accounts are connected on this computer, for the "Connect your AI" panel."""
    import os
    out = {"claude": False, "chatgpt": _pool_count("openai-codex") > 0, "gemini": False, "keys": []}
    try:
        c = _ccli()
        if c.route_on():                     # Claude through the person's own program: connected while it is ready
            out["claude"] = c.status()["state"] == "ready"      # (its sign-in store is never loaded: review CC-2)
            out["claude_program"] = True
        else:
            # a Claude subscription sign-in that Qosha itself holds (before cc19) no longer counts as connected: the
            # panel offers "Sign in with Claude", which moves it to the person's own program (review CC-3); an API key
            # still counts
            held = _claude_held_rows() > 0
            out["claude"] = (not held) and _claude_key_rows() > 0   # a held token asks to reconnect (review R2)
            out["claude_reconnect"] = held
    except Exception:
        out["claude"] = False             # unknown is never "connected" (fix slice, item 5)
    try:
        from hermes_cli.config import load_env
        env = load_env()
    except Exception:
        env = {}
    has = lambda k: bool(env.get(k) or os.environ.get(k))
    has = lambda k: bool(env.get(k))   # what is saved in Qosha's own key file now (not what a process started with)
    out["gemini"] = _gcli().connected()
    out["gemini_how"] = "your Google subscription" if out["gemini"] else ""
    # the last daily self-check of Qosha's own Gemini tool (updater.agy_daily_check, or a Repair): "ok", "signed_out",
    # "missing", "wrong_version", "tampered", "broken"; None where no check ran (a cloud box, a fresh install's first minute)
    chk = _agy_check()
    out["gemini_state"] = chk.get("state") if isinstance(chk.get("state"), str) else None
    out["gemini_plain"] = str(chk.get("plain") or "") if out["gemini_state"] else ""
    # for Settings' Gemini line: the tool version the check saw and when it ran (seconds since 1970)
    out["gemini_version"] = str(chk.get("version") or "") if out["gemini_state"] else ""
    out["gemini_checked_at"] = chk.get("at") if out["gemini_state"] and isinstance(chk.get("at"), int) else None
    out["keys"] = [n for k, n in (("OPENROUTER_API_KEY", "OpenRouter"), ("OPENAI_API_KEY", "OpenAI"), ("ANTHROPIC_API_KEY", "Anthropic key"),
                                  ("GOOGLE_API_KEY", "Gemini key")) if has(k)]
    return out


@router.post("/disconnect/{which}")
def disconnect(which: str, request: Request = None, body: dict = Body(default={})):
    """Remove one connected account (the engine's own clearing code for sign-ins; the key store for keys)."""
    try:
        if which == "claude" and _ccli().route_on():
            if request is None or not _from_app(request):
                return _plain(dict(_NOT_APP))
            r = _ccli().sign_out(str((body or {}).get("press") or ""))
            if not r.get("ok"):
                return _plain(r)
        elif which in ("claude", "chatgpt"):
            from hermes_cli.auth import clear_provider_auth
            clear_provider_auth("anthropic" if which == "claude" else "openai-codex")
        elif which == "gemini":
            _gcli().forget()   # Qosha stops using Google's tool; the tool's own Google sign-in is the person's and stays
        else:
            return JSONResponse({"ok": False, "plain": "Unknown account."}, status_code=404)
    except Exception as exc:
        return JSONResponse({"ok": False, "plain": "Could not disconnect (%s)." % type(exc).__name__}, status_code=500)
    return {"ok": True}


def _gcli():
    import importlib.util, sys
    from pathlib import Path
    mod = sys.modules.get("qosha_gemini_cli")
    if mod is None:
        spec = importlib.util.spec_from_file_location("qosha_gemini_cli", Path(__file__).resolve().parent.parent / "qosha_guard" / "gemini_cli.py")
        mod = importlib.util.module_from_spec(spec)
        sys.modules["qosha_gemini_cli"] = mod
        spec.loader.exec_module(mod)
    return mod


@router.post("/gemini/check")
def gemini_check():
    """Is Google's command-line tool installed and signed in with the person's Google account? (One very short
    question through it; nothing is read from its files.)"""
    g = _gcli()
    name, _ = g.find()
    r = g.check()
    return {"installed": bool(name), "tool": name, "connected": bool(r.get("ok")), "error": r.get("error") or "", "plain": r.get("plain") or ""}


@router.post("/gemini/press")
def gemini_press():
    """A one-time token for one press of a Gemini sign-in button (the panel asks for it inside a real click); a
    sign-in starts only with one (20 Nov 2026)."""
    return {"press": _gcli().press_new()}


@router.post("/gemini/login/start")
def gemini_login_start(body: dict = Body(default={})):
    """Gemini sign-in inside the panel: starts Google's tool's own sign-in in the background (no window) and returns
    the Google address for the page to open -> {"ok", "id", "url", "expires_in"}. Body {"press": token}."""
    r = _gcli().login_start(press=str((body or {}).get("press") or ""))
    return r if r.get("ok") else JSONResponse(r, status_code=200 if r.get("error") in ("no_inline", "not_installed") else 403 if r.get("error") in ("no_press", "not_installed_home") else 502)


@router.post("/gemini/login/finish")
def gemini_login_finish(body: dict = Body(...)):
    """{id, code}: the code Google showed goes to the waiting sign-in; then one short question checks Gemini answers."""
    r = _gcli().login_finish(str((body or {}).get("id") or ""), str((body or {}).get("code") or ""))
    if r.get("ok"):
        return r
    return JSONResponse(r, status_code={"expired": 410, "bad_format": 400, "refused": 400}.get(r.get("error"), 502))


@router.post("/gemini/login/cancel")
def gemini_login_cancel(body: dict = Body(default={})):
    """The panel closed or the person pressed Cancel: that sign-in ends now (it also ends by itself after 10 minutes)."""
    if (body or {}).get("terminal"):          # stop waiting for a Terminal sign-in (20 Nov 2026)
        return _gcli().terminal_cancel()
    sid = str((body or {}).get("id") or "")
    return _gcli().login_cancel(sid) if sid else {"ok": True, "ended": 0}


@router.post("/gemini/open")
def gemini_open(body: dict = Body(default={})):
    """Fallback: Google's sign-in in a window of its own ("Sign in to Gemini"), brought to the front. Body
    {"press": token} from the person's press of that button."""
    return _gcli().open_signin(press=str((body or {}).get("press") or ""))


# ---- Qosha's own Gemini tool (agy at the version Qosha tested; qosha_guard/agy_pin.py) -------------------------------
_REPAIR_LOCK = threading.Lock()


def _agy():
    import importlib.util, sys
    from pathlib import Path
    mod = sys.modules.get("qosha_agy_pin")
    if mod is None:
        spec = importlib.util.spec_from_file_location("qosha_agy_pin", Path(__file__).resolve().parent.parent / "qosha_guard" / "agy_pin.py")
        mod = importlib.util.module_from_spec(spec)
        sys.modules["qosha_agy_pin"] = mod
        spec.loader.exec_module(mod)
    return mod


def _agy_check_path():
    return _gcli()._home() / "qosha" / "agy-check.json"


def _agy_check() -> dict:
    import json
    try:
        d = json.loads(_agy_check_path().read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


@router.post("/gemini/repair")
def gemini_repair():
    """Repair: reinstalls the pinned version of Google's Gemini tool into Qosha's own folder (Google's file from
    GitHub, checked against the pinned size and sha256, as the installer does), then checks it again. Never switches
    to another tool or provider."""
    if _access_gate():                  # CONTRACT-ACCESS: nothing is installed while access has ended
        return JSONResponse(status_code=403, content={"error": "access_ended", "detail": "Your access to Qosha has ended."})
    import json
    import os
    root = _gcli()._home().parent
    if not (root / "engine").is_dir():
        return JSONResponse({"ok": False, "error": "not_local", "plain": "Gemini's tool is managed elsewhere on this computer."},
                            status_code=404)
    if not _REPAIR_LOCK.acquire(blocking=False):
        return JSONResponse({"ok": False, "error": "busy", "plain": "A repair is already running. Wait a minute."}, status_code=409)
    try:
        try:
            r = _agy().repair(root)
        except Exception as exc:
            r = {"ok": False, "state": "broken", "repaired": False,
                 "plain": "Gemini needs a repair: the repair could not run (%s)." % type(exc).__name__}
        try:
            p = _agy_check_path()
            p.parent.mkdir(parents=True, exist_ok=True)
            tmp = p.with_name("." + p.name + ".tmp")
            tmp.write_text(json.dumps(dict(r, at=int(time.time()))), encoding="utf-8")
            os.replace(tmp, p)
        except OSError:
            pass
    finally:
        _REPAIR_LOCK.release()
    return r


def _access_gate():
    """CONTRACT-ACCESS: True when Qosha's access has ended or can't be confirmed (qosha_guard/access.py, loaded by path
    once). Fails closed."""
    import importlib.util as _ilu, sys as _sys
    from pathlib import Path as _P
    try:
        m = _sys.modules.get("qosha_access_gate")
        if m is None:
            p = _P(__file__).resolve().parent.parent / "qosha_guard" / "access.py"
            spec = _ilu.spec_from_file_location("qosha_access_gate", str(p))
            m = _ilu.module_from_spec(spec)
            spec.loader.exec_module(m)
            _sys.modules["qosha_access_gate"] = m
        return bool(m.admit_stopped())      # the same freshness check as a chat message
    except Exception:
        return True
