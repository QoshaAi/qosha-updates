"""Claude subscription first; the pay-per-use API key only by the person's choice (Ren, card, 21 Nov 2026 ~13:00 MST:
"Stop and tell me"; standing rule "subscriptions, not API keys"). When the Claude subscription hits its usage limit,
Qosha stops and says the limit is reached and when it resets. ANTHROPIC_API_KEY stays where the person saved it,
untouched; Qosha just never sends it. Chat, scheduled jobs and side calls alike.

Where the engine could send the key, and what this does there (the engine's files are not edited):
- before every Claude request the engine re-reads the token and prefers an API key over a sign-in stored the way
  Qosha's Connect AI stores it (agent/anthropic_credentials.resolve_anthropic_token): that lookup now gives the
  subscription's token instead, or nothing;
- a chat that already holds the key (it began before the sign-in) is stopped with the plain message rather than
  continued on the key (client_lifecycle._try_refresh_anthropic_client_credentials);
- the credential pool never offers the key (selection, rotation after a 429, leases);
- no Claude client can be built with the key (agent/anthropic_adapter.build_anthropic_client), the backstop;
- a Claude limit longer than 2 minutes ends the retries at once, and the engine's terminal message for it (which
  names its own fallback command) becomes Qosha's plain words with the reset time the failing request carried.
The rule is on once this computer has had a Claude subscription login (remembered in a small marker file holding no
secret, so a sign-in that later breaks or is pruned never turns silently into paying) and the person has not chosen
"Use my API key" (Settings; config.yaml qosha_ai.claude_key_on_limit: true). With that choice the subscription still
goes first and the key is used only while the subscription can't answer. A computer that never had a Claude
subscription uses its key exactly as before."""
from __future__ import annotations

import hmac
import json
import logging
import os
import re
import sys
import time
from pathlib import Path

log = logging.getLogger("qosha.claude_limit")
CFG = "qosha_ai"
CHOICE = "claude_key_on_limit"
BACKUP_CHOICE = "paid_backup_on_limit"
# flat-rate sign-ins (no charge per request) and providers that run on this computer by default
FLAT_RATE = {"anthropic", "openai-codex", "xai-oauth", "qwen-oauth", "copilot", "copilot-acp"}
# routes that send to the URL written in their entry (a localhost URL there means this computer)
LOCAL_ROUTES = {"custom", "lmstudio", "lm-studio", "ollama", "openai", "openai-api", "vllm", "llamacpp", "llama-cpp",
                "localai", "jan"}
# where a flat-rate sign-in can be pointed elsewhere (besides the provider's own *_BASE_URL setting)
_URL_ENVS = {"openai-codex": ("HERMES_CODEX_BASE_URL",), "qwen-oauth": ("HERMES_QWEN_BASE_URL",),
             "anthropic": ("ANTHROPIC_BASE_URL",)}
_OWN_KEY_FIELDS = ("api_key", "key_env", "api_key_env")
LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}
CLI_PROVIDER = "claude-cli"   # Claude through the person's own `claude` program (claude_cli.py)
LONG_LIMIT_S = 120     # a Claude limit longer than this ends the retries at once (shorter ones keep the engine's wait)
_cache = {"at": 0.0, "home": None, "value": False}


class ClaudeKeyRefused(PermissionError):
    """Raised instead of sending ANTHROPIC_API_KEY while the rule is on; its text is the plain message."""


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or (Path.home() / ".hermes"))


def _marker(home: Path) -> Path:
    return home / "qosha" / "claude-subscription-seen"


def _choice(name: str) -> bool:
    try:
        from hermes_cli.config import read_raw_config_readonly
        q = (read_raw_config_readonly() or {}).get(CFG) or {}
        return isinstance(q, dict) and q.get(name) is True
    except Exception:
        return False


def key_on_limit() -> bool:
    """The person's explicit choice in Settings: the API key (pay per use) when the subscription can't answer."""
    return _choice(CHOICE)


def backup_on_limit() -> bool:
    """The person's explicit choice in Settings: a pay-per-use backup AI (OpenRouter and the like) may take over from
    the Claude subscription. Separate from the key (council, 21 Nov 2026: choosing the key is no consent to another
    provider)."""
    return _choice(BACKUP_CHOICE)


def _norm_provider(value) -> str:
    """The canonical provider id, with the engine's alias tables (providers + auth; "codex" -> "openai-codex")."""
    v = str(value or "").strip().lower()
    try:
        from hermes_cli.providers import normalize_provider
        v = str(normalize_provider(v) or v).lower()
    except Exception:
        pass
    try:
        from hermes_cli.auth import _PROVIDER_ALIASES
        v = str(_PROVIDER_ALIASES.get(v, v)).lower()
    except Exception:
        pass
    return "openai-codex" if v == "codex" else v


def _official_host(prov: str) -> str:
    from urllib.parse import urlsplit
    try:
        from hermes_cli.auth import PROVIDER_REGISTRY
        cfg = PROVIDER_REGISTRY.get(prov)
        return (urlsplit(str(getattr(cfg, "inference_base_url", "") or "")).hostname or "").lower()
    except Exception:
        return ""


def _host(url: str) -> str:
    from urllib.parse import urlsplit
    u = str(url or "").strip()
    try:
        return (urlsplit(u if "://" in u else "http://" + u).hostname or "").lower()
    except ValueError:
        return "?"


def _provider_entry(name: str):
    try:
        from hermes_cli.config import read_raw_config_readonly
        cfg = (read_raw_config_readonly() or {}).get("providers") or {}
        ent = cfg.get(name) if isinstance(cfg, dict) else None
        return ent if isinstance(ent, dict) and ent.get("enabled", True) is not False else None
    except Exception:
        return {"url": "?"}


def _named_entry(requested: str):
    """The providers: entry a custom:<name> backup resolves to, by the engine's own name matching ("Desk Two" is
    custom:desk-two). None = no such enabled entry."""
    try:
        from hermes_cli.config import read_raw_config_readonly
        from hermes_cli.providers import custom_provider_aliases
        cfg = (read_raw_config_readonly() or {}).get("providers") or {}
        req = {requested, requested.split(":", 1)[1] if ":" in requested else requested}
        for key, ent in (cfg.items() if isinstance(cfg, dict) else []):
            if not isinstance(ent, dict) or ent.get("enabled", True) is False:
                continue
            if not _entry_url(ent):
                continue                                   # the engine skips an entry with no URL, so does Qosha
            if req & set(custom_provider_aliases(str(ent.get("name", "") or key), str(key))):
                return ent
    except Exception:
        return None
    return None


def _entry_url(ent) -> str:
    """The URL an entry sends to, in the engine's own order (api, then url, then base_url)."""
    return str((ent or {}).get("api") or (ent or {}).get("url") or (ent or {}).get("base_url") or "")


def _overridden_host(prov: str) -> str:
    """Where Qosha's settings point this provider instead of its own service ('' = not redirected; '?' = its own key or
    an unreadable setting, which counts as paid)."""
    ent = _provider_entry(prov)
    if ent:
        if any(ent.get(k) for k in _OWN_KEY_FIELDS):
            return "?"
        if _entry_url(ent):
            return _host(_entry_url(ent))
    names = list(_URL_ENVS.get(prov, ()))
    try:
        from hermes_cli.auth import PROVIDER_REGISTRY
        env = getattr(PROVIDER_REGISTRY.get(prov), "base_url_env_var", "") or ""
        if env:
            names.append(env)
    except Exception:
        pass
    for n in names:
        if (os.environ.get(n) or "").strip():
            return _host(os.environ[n])
    return ""


def _default_url(prov: str) -> str:
    try:
        from hermes_cli.auth import PROVIDER_REGISTRY
        cfg = PROVIDER_REGISTRY.get(prov)
        env = getattr(cfg, "base_url_env_var", "") or ""
        return (os.environ.get(env) or "").strip() if env and (os.environ.get(env) or "").strip() else \
            str(getattr(cfg, "inference_base_url", "") or "")
    except Exception:
        return ""


def _free_backup(fb) -> bool:
    """A backup that costs nothing per request: an endpoint on this computer (exact host) for a route that sends to the
    URL in its entry (LM Studio's own default included), or a flat-rate subscription sign-in Qosha knows, on its own
    service, with no key of its own and not redirected by a setting. Anything else, unknown included, counts as pay
    per use (fail closed)."""
    fb = fb or {}
    prov = _norm_provider(fb.get("provider"))
    raw = str(fb.get("provider") or "").strip().lower()          # as written ("openai" is an alias of another route)
    local_route = prov in LOCAL_ROUTES or raw in LOCAL_ROUTES or prov.startswith("custom") or raw.startswith("custom")
    base = str(fb.get("base_url") or "").strip()
    if not base and raw.startswith("custom:"):
        named = _named_entry(raw)                                 # a named endpoint in Qosha's providers: setting
        if not named or any(named.get(k) for k in _OWN_KEY_FIELDS):
            return bool(named) and _host(_entry_url(named)) in LOCAL_HOSTS
        base = _entry_url(named)
    if not base and prov in ("lmstudio", "lm-studio"):
        base = _default_url("lmstudio")                    # stock LM Studio: 127.0.0.1:1234 unless LM_BASE_URL says otherwise
    if base:
        host = _host(base)
        if host in LOCAL_HOSTS:
            return local_route
        return (prov in FLAT_RATE and host == _official_host(prov) and not any(fb.get(k) for k in _OWN_KEY_FIELDS)
                and _overridden_host(prov) in ("", host))
    if prov not in FLAT_RATE or any(fb.get(k) for k in _OWN_KEY_FIELDS):
        return False
    moved = _overridden_host(prov)
    return moved == "" or moved == _official_host(prov) or moved in LOCAL_HOSTS


def _main_is_claude(agent=None) -> bool:
    """The chat started on Claude (its recorded main route, kept while a backup answers), or, with no chat at hand, the
    saved main AI is Claude (model.provider, or the older top-level provider). Unknown counts as Claude (fail closed)."""
    if agent is not None:
        prim = (getattr(agent, "_primary_runtime", None) or {}).get("provider") or getattr(agent, "provider", "")
        return _norm_provider(prim) in ("anthropic", CLI_PROVIDER)
    try:
        from hermes_cli.config import read_raw_config_readonly
        cfg = read_raw_config_readonly() or {}
        m = cfg.get("model")
        prov = (m.get("provider") if isinstance(m, dict) else None) or cfg.get("provider")
        return _norm_provider(prov or "anthropic") in ("anthropic", CLI_PROVIDER)
    except Exception:
        return True


def _main_is_claude_cli(agent=None) -> bool:
    """The chat (or the saved main AI) runs on the person's own `claude` program (claude_cli.py): it has no pay-per-use
    path of its own, so the rule is always on for it."""
    try:
        if agent is not None:
            prim = (getattr(agent, "_primary_runtime", None) or {}).get("provider") or getattr(agent, "provider", "")
            return _norm_provider(prim) == CLI_PROVIDER
        from hermes_cli.config import read_raw_config_readonly
        cfg = read_raw_config_readonly() or {}
        m = cfg.get("model")
        prov = _norm_provider((m.get("provider") if isinstance(m, dict) else None) or cfg.get("provider"))
        q = cfg.get(CFG) if isinstance(cfg.get(CFG), dict) else {}
        # the saved main AI is "Claude" while Qosha's Claude runs through the program (review G-CC1)
        return prov == CLI_PROVIDER or (prov in ("anthropic", "") and q.get("claude_route") == "program")
    except Exception:
        return False


def _cli_not_ready(agent=None) -> bool:
    """The chat runs on the person's `claude` program and that program is not signed in with a subscription now."""
    try:
        if not _main_is_claude_cli(agent):
            return False
        m = next((m for n, m in list(sys.modules.items()) if n.endswith("qosha_guard.claude_cli") or n == "qosha_claude_cli"), None)
        if m is None:
            return True                       # can't tell: no backup (FS-2)
        return m.status(force=True)["state"] != "ready"   # asked now, never a cached "signed in" (FS-2)
    except Exception:
        return True


def paid_backups_withheld(agent=None) -> bool:
    """A pay-per-use backup may not be used: the chat (or the saved main AI) is on the Claude subscription and the person
    hasn't chosen paid backups (Ren, card 21 Nov 2026 ~19:15 MST; council: every failure, a separate choice; round 2:
    a person whose main AI isn't Claude keeps their backup). Unknown = withheld."""
    try:
        return not backup_on_limit() and (_main_is_claude_cli(agent) or (subscription_seen() and _main_is_claude(agent)))
    except Exception:
        return True


def _is_oauth(token) -> bool:
    try:
        from agent.anthropic_credentials import _is_oauth_token
        return bool(_is_oauth_token(str(token or "")))
    except Exception:
        return str(token or "").startswith(("sk-ant-oat", "eyJ", "cc-"))


def _login_entries(entries) -> str:
    """A Claude subscription login among the engine's own pool rows: "owned" (Qosha's Connect AI or a .env token, counted
    even when it stopped working, and remembered), "claude_code" (Claude Code's own command-line login: counts only
    while it works, never remembered), or "" (none)."""
    found = ""
    for e in entries or []:
        if getattr(e, "auth_type", None) != "oauth":
            continue
        if str(getattr(e, "source", "") or "") == "claude_code":
            if getattr(e, "last_status", None) != "dead":
                found = "claude_code"
            continue
        return "owned"
    return found


def _note_seen(home: Path) -> None:
    try:
        m = _marker(home)
        if not m.exists():
            m.parent.mkdir(parents=True, exist_ok=True)
            m.write_text(json.dumps({"seen": time.time()}), encoding="utf-8")
    except OSError:
        pass


def subscription_seen(entries=None, home: Path | None = None) -> bool:
    h = home or _home()
    if _marker(h).exists():
        return True
    # ANTHROPIC_TOKEN may hold a Console key: it counts only when it is a subscription token
    found = bool((os.environ.get("CLAUDE_CODE_OAUTH_TOKEN") or "").strip()) or _is_oauth(
        (os.environ.get("ANTHROPIC_TOKEN") or "").strip())
    if not found:
        try:
            if entries is None:
                from agent.credential_pool import load_pool
                entries = load_pool("anthropic").entries()
            kind = _login_entries(entries)
        except Exception:
            return True          # the login store can't be read: unknown, so the key is withheld (nothing remembered)
        if kind == "claude_code":
            return True          # counts while it works; not remembered
        found = kind == "owned"
    if found:
        _note_seen(h)
    return found


def rule_active(entries=None) -> bool:
    if key_on_limit():
        return False
    h = _home()
    if entries is None and _cache["value"] and _cache["home"] == str(h) and time.monotonic() - _cache["at"] < 5:
        return True              # only "the rule is on" is cached: a fresh sign-in is never missed
    v = subscription_seen(entries, h)
    if entries is None:
        _cache.update(at=time.monotonic(), home=str(h), value=v)
    return v


def _paid_keys() -> list:
    """The values the person saved as ANTHROPIC_API_KEY (never logged, never compared outside this process)."""
    out = []
    for getter in (lambda: os.environ.get("ANTHROPIC_API_KEY"),):
        try:
            v = (getter() or "").strip()
            if v:
                out.append(v)
        except Exception:
            pass
    try:
        from agent.credential_pool import get_env_prefer_dotenv
        v = (get_env_prefer_dotenv("ANTHROPIC_API_KEY") or "").strip()
        if v:
            out.append(v)
    except Exception:
        pass
    return out


def _is_paid(token) -> bool:
    t = str(token or "").strip()
    if not t or _is_oauth(t):
        return False
    return t.startswith("sk-ant-") or any(hmac.compare_digest(t, k) for k in _paid_keys())


def _subscription_token(model=None):
    """A subscription token the pool can use now for `model` (never the key), or None."""
    try:
        from agent.credential_pool import AUTH_TYPE_OAUTH, load_pool
        pool = load_pool("anthropic")
        with pool._lock:
            available = pool._available_entries(model=model)[0]
        for e in available:
            if getattr(e, "auth_type", None) == AUTH_TYPE_OAUTH:
                tok = e.runtime_api_key or getattr(e, "access_token", "")
                if tok:
                    return tok
    except Exception:
        pass
    return None


def _paid_sentence() -> str:
    """What Qosha did not switch to, as the person's saved choices say (review PB-13)."""
    try:
        backup = backup_on_limit()
    except Exception:
        backup = False
    if backup:
        return (" Qosha doesn't use your pay-per-use API key for this (a paid backup AI is allowed, but none could "
                "answer); you can change this in Settings > Claude usage limit.")
    return (" Qosha doesn't switch to pay-per-use AI (your API key or a paid backup) for this; you can choose that in "
            "Settings > Claude usage limit.")


def stop_words(reset_seconds: float | None = None, now: float | None = None) -> str:
    """The plain message: the limit is reached (or the subscription can't answer), when it resets, no paid key."""
    now = now or time.time()
    when = " Claude didn't say when it resets."
    if reset_seconds and reset_seconds > 0:
        at = now + reset_seconds
        mins = max(1, int((reset_seconds + 59) // 60))
        wait = ("%d min" % mins) if mins < 120 else ("about %d h" % round(mins / 60))
        when = " It resets at %s (in %s)." % (time.strftime("%H:%M", time.localtime(at)), wait)
    return ("Your Claude subscription can't answer right now: it reached its usage limit, or its sign-in needs to be "
            "renewed (Connect AI)." + when + _paid_sentence() + " Your message is saved: send it again later.")


def limit_words(reset_seconds: float | None, now: float | None = None) -> str:
    now = now or time.time()
    when = " Claude didn't say when it resets."
    if reset_seconds and reset_seconds > 0:
        at = now + reset_seconds
        mins = max(1, int((reset_seconds + 59) // 60))
        wait = ("%d min" % mins) if mins < 120 else ("about %d h" % round(mins / 60))
        when = " It resets at %s (in %s)." % (time.strftime("%H:%M", time.localtime(at)), wait)
    return ("Your Claude subscription reached its usage limit." + when + _paid_sentence() + " Your message is saved: send "
            "it again after the reset.")


# --- the patches ----------------------------------------------------------------------------------------------------
def _patch_resolver() -> None:
    from agent import anthropic_credentials as ac
    orig = ac.resolve_anthropic_token
    if getattr(orig, "qosha_claude_limit", False):
        return

    def resolve_anthropic_token(*a, **kw):
        tok = orig(*a, **kw)
        try:
            if _is_paid(tok):
                model = kw.get("model")
                if rule_active():
                    return _subscription_token(model)          # the subscription, or nothing; never the key
                sub = _subscription_token(model)               # "Use my API key": still the subscription first
                if sub:
                    return sub
        except Exception:
            if rule_active():
                return None
        return tok

    resolve_anthropic_token.qosha_claude_limit = True
    resolve_anthropic_token.__wrapped__ = orig
    ac.resolve_anthropic_token = resolve_anthropic_token


def _patch_builder() -> None:
    from agent import anthropic_adapter as aa
    orig = aa.build_anthropic_client
    if getattr(orig, "qosha_claude_limit", False):
        return

    def build_anthropic_client(api_key, *a, **kw):
        if isinstance(api_key, str) and _is_paid(api_key) and rule_active():
            raise ClaudeKeyRefused(stop_words())
        return orig(api_key, *a, **kw)

    build_anthropic_client.qosha_claude_limit = True
    build_anthropic_client.__wrapped__ = orig
    aa.build_anthropic_client = build_anthropic_client


def _patch_refresh() -> None:
    from agent import client_lifecycle as cl_mod
    cls = cl_mod.ClientLifecycleMixin
    orig = cls._try_refresh_anthropic_client_credentials
    if getattr(orig, "qosha_claude_limit", False):
        return

    def _try_refresh_anthropic_client_credentials(self):
        changed = orig(self)
        if (str(getattr(self, "provider", "") or "") == "anthropic" and _is_paid(getattr(self, "_anthropic_api_key", ""))
                and rule_active()):
            raise ClaudeKeyRefused(stop_words())                # a chat still holding the key: stop, never send it
        return changed

    _try_refresh_anthropic_client_credentials.qosha_claude_limit = True
    cls._try_refresh_anthropic_client_credentials = _try_refresh_anthropic_client_credentials


def _patch_pool() -> None:
    from agent import credential_pool as cp
    cls = cp.CredentialPool
    orig = cls._available_entries
    if getattr(orig, "qosha_no_key_fallback", False):
        return

    def _available_entries(self, *a, **kw):
        # decided before the engine's own selection runs, which may prune a dead sign-in row
        try:
            rule = getattr(self, "provider", None) == "anthropic" and rule_active(list(self._entries))
        except Exception:
            rule = getattr(self, "provider", None) == "anthropic"        # unknown: withhold the key
        available, pending = orig(self, *a, **kw)
        if rule:
            available = [e for e in available if getattr(e, "auth_type", None) != cp.AUTH_TYPE_API_KEY]
        return available, pending

    _available_entries.qosha_no_key_fallback = True
    _available_entries.__wrapped__ = orig
    cls._available_entries = _available_entries


def _ends_turn(agent, api_error) -> bool:
    if str(getattr(agent, "provider", "") or "").lower() == CLI_PROVIDER:
        return getattr(api_error, "qosha_plain", None) is not None or type(api_error).__name__ == "ClaudeLimitReached"
    if str(getattr(agent, "provider", "") or "").lower() != "anthropic" or not rule_active():
        return False
    from agent.retry_utils import provider_retry_after_seconds
    cooldown = provider_retry_after_seconds(api_error)
    return cooldown is not None and cooldown > LONG_LIMIT_S


def _patch_ends_turn() -> None:
    from agent import turn_api_error as tae
    from agent import turn_recovery as tr
    orig = tr.free_tier_cooldown_ends_turn
    if getattr(orig, "qosha_claude_limit", False):
        return

    def free_tier_cooldown_ends_turn(agent, api_error, base_url, *a, **kw):
        try:
            if orig(agent, api_error, base_url, *a, **kw):
                return True
        except Exception:
            pass
        try:
            return _ends_turn(agent, api_error)
        except Exception:
            return False

    free_tier_cooldown_ends_turn.qosha_claude_limit = True
    tr.free_tier_cooldown_ends_turn = free_tier_cooldown_ends_turn
    tae.free_tier_cooldown_ends_turn = free_tier_cooldown_ends_turn


_LIMIT_REASONS = ("rate_limit", "upstream_rate_limit")


def _reset_from(error, reset_seconds):
    if reset_seconds and reset_seconds > 0:
        return reset_seconds
    try:
        from agent.retry_utils import provider_retry_after_seconds
        return provider_retry_after_seconds(error)
    except Exception:
        return None


_ENGINE_BACKUP_TIP = re.compile(r"\s*To avoid this in future, add a backup provider with `hermes fallback add`\.")


def _backup_tip() -> str:
    if paid_backups_withheld():
        return (" You have a pay-per-use backup AI; Qosha doesn't switch to it unless you allow it in Settings > "
                "Claude usage limit.") if _withheld_chain() else " You can ask Qosha to set up a backup AI."
    return " You can ask Qosha to set up a backup AI."


def _withheld_chain() -> bool:
    """A backup is set up but left out because it is pay per use."""
    try:
        from hermes_cli import fallback_config as fc
        from hermes_cli.config import read_raw_config_readonly
        raw = getattr(fc.get_fallback_chain, "__wrapped__", fc.get_fallback_chain)(read_raw_config_readonly() or {})
        return any(not _free_backup(e) for e in raw or [])
    except Exception:
        return False


def _no_upstream_backup_words(text):
    """The engine's exhaustion text ends with its own command for adding a backup; Qosha's words instead (the upstream
    name is never shown; review round 2: a withheld backup made this text reachable)."""
    try:
        if isinstance(text, str) and "hermes fallback add" in text:
            return _ENGINE_BACKUP_TIP.sub(_backup_tip().replace("\\", "\\\\"), text)
    except Exception:
        pass
    return text


# the engine's own commands in an automation's failure notice, in Qosha's words (the advice around them is kept)
_CMD_SUBS = [
    (re.compile(r"run `hermes gateway restart` to fix it", re.I), "restart Qosha to fix it"),
    (re.compile(r"`hermes gateway restart`", re.I), "restarting Qosha"),
    (re.compile(r"\s*\(or `hermes [^`]*` in a terminal\)", re.I), ""),
    (re.compile(r"Sign in again with /login", re.I), "Sign in again (Connect AI)"),
    (re.compile(r"then `hermes cron run [^`]*` to retry", re.I), "then run it again from Automations"),
    (re.compile(r"`hermes cron run [^`]*` tries now", re.I), "you can run it now from Automations"),
    (re.compile(r"Run logs?:\s*`hermes cron runs [^`]*`\.?", re.I), "Its log is in Automations."),
    (re.compile(r"\s+(?:with|via|using)\s+`hermes (?:fallback|auth|login|model|setup|portal)[^`]*`", re.I),
     " in Qosha (Connect AI, or Settings > Claude usage limit)"),
    (re.compile(r"\s+(?:with|via|using)\s+`hermes [^`]*`", re.I), " in Automations"),
    (re.compile(r"`hermes [^`]*`", re.I), "Automations"),
]


def _scrub_engine_commands(text):
    """An automation's failure notice names the engine's own commands (run it again, its log, edit, pause, sign in):
    Qosha's words instead, keeping the advice (the upstream name is never shown; review: withheld backups make these
    notices more frequent)."""
    if not isinstance(text, str) or "hermes" not in text.lower():
        return text
    out = text
    for rx, words in _CMD_SUBS:
        out = rx.sub(words, out)
    return out.replace("Cron '", "Automation '")


def _patch_cron_delivery() -> None:
    """The whole delivered text of a FAILED run (the scheduler adds sentences after the notice): no engine commands.
    A successful run's own output is never touched."""
    import cron.scheduler as cs
    orig = getattr(cs, "_compose_run_delivery", None)
    if orig is None or getattr(orig, "qosha_no_key_fallback", False):
        return

    def _compose_run_delivery(job, *a, success=True, **kw):
        out = orig(job, *a, success=success, **kw)
        try:
            if not success and isinstance(out, tuple) and out and isinstance(out[0], str):
                return (_scrub_engine_commands(out[0]),) + tuple(out[1:])
        except Exception:
            pass
        return out

    _compose_run_delivery.qosha_no_key_fallback = True
    _compose_run_delivery.__wrapped__ = orig
    cs._compose_run_delivery = _compose_run_delivery


def _patch_cron_notices() -> None:
    import cron.scheduler_failure_copy as sfc
    for name in [n for n in dir(sfc) if n.endswith("_notice") and callable(getattr(sfc, n))]:
        orig = getattr(sfc, name)
        if getattr(orig, "qosha_no_key_fallback", False):
            continue

        def make(o):
            def notice(*a, **kw):
                return _scrub_engine_commands(o(*a, **kw))
            notice.qosha_no_key_fallback = True
            notice.__wrapped__ = o
            return notice
        wrapped = make(orig)
        setattr(sfc, name, wrapped)
        m = sys.modules.get("cron.scheduler")
        if m is not None and getattr(m, name, None) is orig:
            setattr(m, name, wrapped)


def _patch_cron_phrase() -> None:
    """A failed automation's notice says which backups were tried; the engine's sentences name its own commands."""
    import cron.scheduler as cs
    orig = getattr(cs, "_fallback_chain_phrase", None)
    if orig is None or getattr(orig, "qosha_no_key_fallback", False):
        return

    def _fallback_chain_phrase(job=None, *a, **kw):
        text = orig(job, *a, **kw)
        pinned = job is not None and "pinned" in str(text)
        if not pinned and paid_backups_withheld() and _withheld_chain():
            return ("Qosha didn't switch to your pay-per-use backup AI; you can allow it in Settings > Claude usage "
                    "limit.")
        if "hermes" not in str(text).lower():
            return text
        if pinned:
            return "This automation uses its own AI and doesn't switch to a backup."
        return "No backup AI is set up; you can ask Qosha to set one up."

    _fallback_chain_phrase.qosha_no_key_fallback = True
    _fallback_chain_phrase.__wrapped__ = orig
    cs._fallback_chain_phrase = _fallback_chain_phrase


def _patch_copy() -> None:
    from agent import turn_failure_copy as tfc
    from agent import turn_recovery as tr
    orig = tfc.exhausted_copy
    if getattr(orig, "qosha_claude_limit", False):
        return
    claude_label = tfc.provider_label_for("anthropic")

    def exhausted_copy(reason, *a, label=None, reset_seconds=None, error=None, **kw):
        try:
            if type(error).__name__ == "ClaudeKeyRefused":
                return str(error)                              # stopped instead of sending the key: Qosha's words
            if isinstance(getattr(error, "qosha_plain", None), str):
                return error.qosha_plain                       # the claude program can't answer: Qosha's words
            if type(error).__name__ == "ClaudeLimitReached":
                return limit_words(_reset_from(error, reset_seconds) or getattr(error, "reset_seconds", None))
            if label == claude_label and str(reason) in _LIMIT_REASONS and rule_active():
                return limit_words(_reset_from(error, reset_seconds))
        except Exception:
            pass
        return _no_upstream_backup_words(orig(reason, *a, label=label, reset_seconds=reset_seconds, error=error, **kw))

    exhausted_copy.qosha_claude_limit = True
    tfc.exhausted_copy = exhausted_copy
    tr.exhausted_copy = exhausted_copy


def _patch_runtime() -> None:
    """The request after a limit (or with the sign-in gone): the engine refuses before any call with its own text,
    which names its command line. While the rule is on, that refusal says Qosha's words instead."""
    from hermes_cli import runtime_provider as rp
    from hermes_cli.auth_constants import AuthError
    orig = rp._anthropic_token_or_raise
    if getattr(orig, "qosha_no_key_fallback", False):
        return

    def _anthropic_token_or_raise(*a, model=None, **kw):
        try:
            return orig(*a, model=model, **kw)
        except AuthError as exc:
            try:
                if not rule_active():
                    raise
                at = reset_at(model)
                secs = (at - time.time()) if at else None
                words = limit_words(secs) if at else stop_words(None)
            except AuthError:
                raise
            except Exception:
                words = stop_words(None)
            refusal = AuthError(words, provider="anthropic", code=getattr(exc, "code", None) or "qosha_claude_limit",
                                retry_after=secs if at else None, retryable=bool(at))
            refusal.qosha_claude_refusal = True
            raise refusal from None

    _anthropic_token_or_raise.qosha_no_key_fallback = True
    _anthropic_token_or_raise.__wrapped__ = orig
    rp._anthropic_token_or_raise = _anthropic_token_or_raise


def _patch_fallback() -> None:
    """A pay-per-use backup never takes over from the Claude subscription without the person's choice, whatever the
    failure (Ren, card 21 Nov 2026 ~19:15 MST, "Stop and tell, same as the key"; council: every failure). The engine
    checks every chain entry here before switching; a skipped one isn't marked unavailable, so a later choice works."""
    from agent import chat_completion_helpers as cch
    orig = cch._should_skip_fallback_candidate
    if getattr(orig, "qosha_no_key_fallback", False):
        return

    def _should_skip_fallback_candidate(agent, fb, fb_key, fb_provider, fb_model, unavailable, *a, **kw):
        if orig(agent, fb, fb_key, fb_provider, fb_model, unavailable, *a, **kw):
            return True
        if _cli_not_ready(agent):
            # Claude's own program is signed out / missing: Qosha stops and tells, no backup at all (Ren, card
            # 22 Nov 2026: "No, stop and tell"; a paid backup only at the usage limit)
            log.info("Claude program not ready: no backup AI is used")
            return True
        try:
            if _free_backup(fb) or not paid_backups_withheld(agent):
                return False
        except Exception:
            pass                 # unknown: withhold the paid backup
        log.info("Claude limit: a pay-per-use backup AI (%s) is not used without the person's choice", fb_provider)
        return True

    _should_skip_fallback_candidate.qosha_no_key_fallback = True
    _should_skip_fallback_candidate.__wrapped__ = orig
    cch._should_skip_fallback_candidate = _should_skip_fallback_candidate


# the engine's own editors of the chain (they read it and write it back): they always see it whole, so nothing a person
# saved is ever dropped; every other reader routes requests and gets the chain without pay-per-use backups
# (fallback_config itself: scoped_fallback_chain must see a task's own list as declared; its RESULT is filtered below)
_CHAIN_EDITORS = ("hermes_cli.fallback_cmd", "hermes_cli.left_core_migration", "hermes_cli.fallback_check",
                  "hermes_cli.fallback_config")
_CHAIN_READERS = ("cron.scheduler", "gateway.run_config_loaders", "hermes_cli.cli_init_mixin",
                  "hermes_cli.cli_chat_turn_mixin", "hermes_cli.oneshot", "tools.process_registry_notifications")


def _patch_chain() -> None:
    """New chats (desktop, messaging gateway), automations, background tasks (titles...) and delegated work all read
    the backup chain through the engine's get_fallback_chain; they get it without pay-per-use backups while those are
    withheld (review PB-1, PB-2)."""
    from hermes_cli import fallback_config as fc
    orig = fc.get_fallback_chain
    if getattr(orig, "qosha_no_key_fallback", False):
        return

    def get_fallback_chain(config, *a, **kw):
        chain = orig(config, *a, **kw)
        try:
            caller = sys._getframe(1).f_globals.get("__name__", "")
        except Exception:
            caller = ""
        if not chain or caller in _CHAIN_EDITORS or not paid_backups_withheld():
            return chain
        kept = []
        for e in chain:
            try:
                free = _free_backup(e)
            except Exception:
                free = False
            if free:
                kept.append(e)
        if len(kept) != len(chain):
            log.info("Claude limit: %d pay-per-use backup AI(s) left out without the person's choice", len(chain) - len(kept))
        return kept

    get_fallback_chain.qosha_no_key_fallback = True
    get_fallback_chain.__wrapped__ = orig
    fc.get_fallback_chain = get_fallback_chain
    for name in _CHAIN_READERS:        # modules that bound the name before Qosha set this up
        m = sys.modules.get(name)
        if m is not None and getattr(m, "get_fallback_chain", None) is orig:
            m.get_fallback_chain = get_fallback_chain

    # a delegated task or automation with its OWN backup list: the engine first picks whose list applies; a list whose
    # every entry is pay per use then stays empty (never the parent's list instead) (review round 2, PB-19)
    sorig = fc.scoped_fallback_chain

    def scoped_fallback_chain(inherited, declared, *a, **kw):
        out = sorig(inherited, declared, *a, **kw)
        if not out or not paid_backups_withheld():
            return out
        kept = [e for e in out if _free_backup(e)]
        return kept or None

    scoped_fallback_chain.qosha_no_key_fallback = True
    scoped_fallback_chain.__wrapped__ = sorig
    fc.scoped_fallback_chain = scoped_fallback_chain
    for name in ("cron.scheduler", "tools.delegate_tool_config"):
        m = sys.modules.get(name)
        if m is not None and getattr(m, "scoped_fallback_chain", None) is sorig:
            m.scoped_fallback_chain = scoped_fallback_chain


_APPLIED = {"ok": None}


def apply() -> bool:
    ok = True
    try:
        subscription_seen()      # remember an existing sign-in before any request can prune its row
    except Exception:
        pass
    for name, fn in (("token lookup", _patch_resolver), ("client builder", _patch_builder),
                     ("chat refresh", _patch_refresh), ("pool", _patch_pool), ("early stop", _patch_ends_turn), ("refusal", _patch_runtime), ("paid backup", _patch_fallback), ("backup chain", _patch_chain), ("automation notice", _patch_cron_phrase), ("automation failure", _patch_cron_notices), ("automation delivery", _patch_cron_delivery),
                     ("message", _patch_copy)):
        try:
            fn()
        except Exception as exc:
            ok = False
            log.warning("Claude limit: %s not set up (engine changed?): %s", name, type(exc).__name__)
    _APPLIED["ok"] = ok
    return ok


def register(ctx) -> None:
    apply()


def state() -> dict:
    """For Settings: is the rule on, did the person choose the key, is a key saved (never its value)."""
    try:
        ok = _APPLIED["ok"] is not False          # setup failed: never claim the key is held back
        return {"rule": bool(ok and rule_active()), "protected": ok, "chosen": key_on_limit(), "backup_chosen": backup_on_limit(),
                "key_saved": bool(_paid_keys()), "subscription": subscription_seen()}
    except Exception:
        return {"rule": None}


def reset_at(model: str | None = None, now: float | None = None) -> float | None:
    """When the subscription's limit lifts for `model`, as the engine recorded it from Claude's answer (Retry-After or
    reset); an approximation, so the watch says "about"."""
    now = now or time.time()
    try:
        from agent.credential_pool import AUTH_TYPE_OAUTH, load_pool
        times = []
        for e in load_pool("anthropic").entries():
            if getattr(e, "auth_type", None) != AUTH_TYPE_OAUTH:
                continue
            cand = [e.last_error_reset_at] + ([(e.model_cooldowns or {}).get(model)] if model else [])
            times += [x for x in cand if isinstance(x, (int, float)) and x > now]
        return min(times) if times else None
    except Exception:
        return None
