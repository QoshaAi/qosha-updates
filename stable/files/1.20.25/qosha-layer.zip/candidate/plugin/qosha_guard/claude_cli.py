"""Claude through the person's own `claude` program (Ren, card 22 Nov 2026: "Yes, use the claude program").

Qosha never holds, stores or refreshes a Claude token on this route: each Claude request runs the person's own,
unmodified `claude` program (Claude Code), which keeps its own subscription sign-in. Built on the engine's
"external process" provider class (agent/acp_client.py): the engine's tools travel in the prompt as schemas and come
back as <tool_call>{...}</tool_call> blocks that the engine runs through its normal dispatch, so Qosha's approval
guard (pre_tool_call -> Allow card) sees every action. `claude` itself gets no tool at all.

Each run is locked (design: runs.noindex/cc19/work/DESIGN.md): --tools "" (checked in the init event), no MCP
servers, no settings/hooks/plugins/skills/slash commands, no session saved, an empty private folder, an allow-listed
environment (no API keys: never pay per use), and the program must be signed in with a Claude subscription
(`claude auth status` -> authMethod "claude.ai"; init -> apiKeySource "none"). At the usage limit the turn stops with
Qosha's words (claude_limit.py) and nothing pay-per-use takes over."""
from __future__ import annotations

import json
import os
import queue
import re
import subprocess
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any

# imported once at load: two requests importing these at the same time deadlocked on the Mac (journey 22 Nov)
from agent.acp_openai_bridge import completion_to_stream_chunks, extract_tool_calls_from_text, render_tool_bridge_sections

PROVIDER = "claude-cli"
MODELS = ("claude-opus-5-5", "claude-sonnet-5-5", "claude-haiku-5-5")
EFFORTS = ("low", "medium", "high", "xhigh", "max")
STATUS_TTL = 30.0
DEFAULT_TIMEOUT = 900.0
IDLE_S = 120.0          # a run that sends nothing this long is stopped (it sends progress events every few seconds)
MAX_IMAGES = 20
LOCKED_FLAGS = ("-p", "--input-format", "stream-json", "--output-format", "stream-json", "--verbose", "--tools", "",
                "--strict-mcp-config", "--setting-sources", "", "--safe-mode", "--disable-slash-commands",
                "--no-session-persistence")
_ENV_POSIX = ("PATH", "LANG", "LC_ALL", "LC_CTYPE", "LC_MESSAGES", "TZ", "TMPDIR", "USER", "LOGNAME", "SHELL",
              "__CF_USER_TEXT_ENCODING")
_ENV_WIN = ("PATH", "PATHEXT", "SYSTEMROOT", "SYSTEMDRIVE", "WINDIR", "COMSPEC", "APPDATA", "LOCALAPPDATA",
            "USERPROFILE", "HOMEDRIVE", "HOMEPATH", "USERNAME", "USERDOMAIN", "PROGRAMDATA", "PROGRAMFILES",
            "PROGRAMFILES(X86)", "PROGRAMW6432", "COMMONPROGRAMFILES", "COMMONPROGRAMFILES(X86)", "TEMP", "TMP",
            "NUMBER_OF_PROCESSORS", "PROCESSOR_ARCHITECTURE", "OS", "COMPUTERNAME", "TZ", "LANG")
_ENV_NET = ("HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY", "ALL_PROXY", "SSL_CERT_FILE", "NODE_EXTRA_CA_CERTS",
            "CLAUDE_CONFIG_DIR")   # where the person keeps their own `claude` sign-in, when they moved it (no secret)
_status_cache: dict[str, Any] = {"at": 0.0, "value": None}
_status_lock = threading.Lock()

# The person's words (no engine or tool names; ends with what to do).
WORDS = {
    "not_installed": "Claude isn't set up on this computer yet. Open Connect AI and press Sign in with Claude: Qosha "
                     "can install Claude's own program for you, then you sign in with your Claude account.",
    "signed_out": "Claude is signed out on this computer. Open Connect AI and press Sign in with Claude.",
    "not_subscription": "Claude on this computer is signed in with a pay-per-use account, not a Claude subscription, "
                        "so Qosha doesn't use it. Open Connect AI and sign in with your Claude account (Pro or Max).",
    "locked": "Qosha stopped this Claude request: Claude's program started with extra abilities Qosha doesn't allow "
              "(its own tools, connections or add-ons). Nothing was done. Update Claude, then try again.",
    "failed": "Claude couldn't answer this time. Try again in a minute.",
}


class ClaudeNotReady(PermissionError):
    """Claude can't answer on this computer (not installed, signed out, not a subscription, locked run). The text is
    the person's plain message; status 401 so nothing treats it as a transient server error."""
    status_code = 401

    def __init__(self, kind: str):
        super().__init__(WORDS.get(kind, WORDS["failed"]))
        self.kind = kind
        self.qosha_plain = str(self)
        self.body = {"error": {"type": "qosha_claude_cli", "message": str(self)}}


class ClaudeLimitReached(RuntimeError):
    """The subscription reached its usage limit. ``body.retry_after`` (seconds) when Claude said when it resets."""
    status_code = 429

    def __init__(self, text: str, reset_seconds: float | None):
        super().__init__("Claude usage limit reached")
        self.reset_seconds = reset_seconds
        self.body = {"error": {"type": "rate_limit_error", "message": "usage limit reached"}}
        if reset_seconds and reset_seconds > 0:
            self.body["error"]["retry_after"] = int(-(-reset_seconds // 1))   # rounded up; where the engine reads it


def _limit_module():
    """claude_limit.py whether this module was loaded as part of the plugin package or by path (review G-CC1)."""
    import importlib.util
    m = next((m for n, m in list(sys.modules.items()) if n.endswith("qosha_guard.claude_limit") or n == "qosha_claude_limit"), None)
    if m is None:
        spec = importlib.util.spec_from_file_location("qosha_claude_limit", str(Path(__file__).resolve().parent / "claude_limit.py"))
        m = importlib.util.module_from_spec(spec)
        sys.modules["qosha_claude_limit"] = m
        spec.loader.exec_module(m)
    return m


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or (Path.home() / ".hermes"))


def real_home() -> str:
    """The person's own home folder (where `claude` keeps its sign-in), never a home the engine redirected."""
    if os.name == "nt":
        return os.environ.get("USERPROFILE") or os.path.expanduser("~")
    try:
        import pwd
        return pwd.getpwuid(os.getuid()).pw_dir
    except Exception:
        return os.environ.get("HERMES_REAL_HOME") or os.path.expanduser("~")


def find() -> str | None:
    """Absolute path of the person's `claude` program, or None. The engine's own lookup (PATH, the user-local bin,
    Claude's install folders) plus the native installer's folder under the real home."""
    try:
        from hermes_cli.auth_external_process import resolve_external_process_command
        hit = resolve_external_process_command("claude")
        if hit:
            return hit
    except Exception:
        pass
    exe = "claude.exe" if os.name == "nt" else "claude"
    for p in (Path(real_home()) / ".local" / "bin" / exe, Path(real_home()) / ".claude" / "local" / exe):
        if p.is_file() and os.access(p, os.X_OK):
            return str(p)
    return None


def child_env(command: str | None = None) -> dict[str, str]:
    """An allow-listed environment: what `claude` needs to run and find its own sign-in, never a key or token
    (ANTHROPIC_*, CLAUDE_CODE_*, cloud credentials are simply not copied)."""
    names = set(_ENV_WIN if os.name == "nt" else _ENV_POSIX) | set(_ENV_NET)
    env = {k: v for k, v in os.environ.items() if k.upper() in names}
    home = real_home()
    if os.name == "nt":
        env["USERPROFILE"] = home
    else:
        env["HOME"] = home
        if not env.get("USER"):          # `claude` finds its Keychain sign-in by the user name
            try:
                import pwd
                env["USER"] = env["LOGNAME"] = pwd.getpwuid(os.getuid()).pw_name
            except Exception:
                pass
    if command:
        d = os.path.dirname(command)
        env["PATH"] = d + os.pathsep + env.get("PATH", "") if d else env.get("PATH", "")
    return env


def _run_dir() -> Path:
    d = _home() / "qosha" / "claude-cli"
    d.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(d, 0o700)
    except OSError:
        pass
    return d


def _hide() -> dict:
    if os.name == "nt":
        return {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)}
    return {"start_new_session": True}


def status(force: bool = False) -> dict:
    """{"state": "ready"|"not_installed"|"signed_out"|"not_subscription"|"unknown", "path", "email"?} from the program's
    own `claude auth status` (cached STATUS_TTL seconds; nothing is read from its files)."""
    with _status_lock:
        cached = _status_cache["value"]
        if cached is not None and not force and time.time() - _status_cache["at"] < STATUS_TTL:
            return dict(cached)
    path = find()
    if not path:
        out = {"state": "not_installed", "path": None}
    else:
        out = {"state": "unknown", "path": path}
        try:
            r = subprocess.run([path, "auth", "status"], capture_output=True, text=True, encoding="utf-8",
                               errors="replace", timeout=20, cwd=str(_run_dir()), env=child_env(path),
                               stdin=subprocess.DEVNULL, **_hide())
            data = json.loads(r.stdout)
            if not isinstance(data, dict) or "loggedIn" not in data:
                out["state"] = "unknown"           # no clear answer is never "signed out" (fix slice, item 2)
            elif data.get("loggedIn") is not True:
                out["state"] = "signed_out"
            elif data.get("authMethod") != "claude.ai":
                out["state"] = "not_subscription"
            else:
                out["state"] = "ready"
        except Exception:
            out["state"] = "unknown"
    with _status_lock:
        _status_cache.update(at=time.time(), value=dict(out))
    return out


def forget_status() -> None:
    with _status_lock:
        _status_cache.update(at=0.0, value=None)


# ---- the prompt ------------------------------------------------------------------------------------------------------
_HEADER = (
    "You are Qosha, the person's assistant. Answer as Qosha; never call yourself by another product's name.",
    "You have no tools of your own in this session. To act, use only the tools listed below: emit "
    "<tool_call>{...}</tool_call> blocks exactly as described, and Qosha runs them (some wait for the person's "
    "approval). If no tool is needed, answer normally.",
    "A tool has not run until its result appears in the conversation as \"Tool result\". After a <tool_call>, stop "
    "and wait. Never say a tool ran, what it found or what it returned before its result is there.",
)


def _text_of(content: Any, images: list, label: str) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, dict):
        content = [content]
    parts = []
    for item in content if isinstance(content, list) else [content]:
        if isinstance(item, str):
            parts.append(item)
        elif isinstance(item, dict) and item.get("type") in ("text", "input_text") and isinstance(item.get("text"), str):
            parts.append(item["text"])
        elif isinstance(item, dict) and item.get("type") in ("image_url", "input_image"):
            url = item.get("image_url")
            url = url.get("url") if isinstance(url, dict) else url
            m = re.match(r"data:(image/(?:png|jpeg|gif|webp));base64,(.+)$", str(url or ""), re.S)
            if m and label == "User":
                images.append({"type": "image", "source": {"type": "base64", "media_type": m.group(1),
                                                            "data": m.group(2).strip()}})
                parts.append("[picture %d]" % len(images))
            else:
                parts.append("[a picture]")
    return "\n".join(p.strip() for p in parts if p and p.strip())


def build_prompt(messages: list, tools: list | None, tool_choice: Any = None) -> tuple[str, list]:
    """(system text, user content blocks) for one run: the engine's system message and tool contract in the system
    text; the transcript (tool calls and results included) as text, pictures as image blocks."""
    system, lines, images = list(_HEADER), [], []
    for m in (m for m in messages or [] if isinstance(m, dict)):
        role = str(m.get("role") or "").lower()
        if role in ("system", "developer"):
            t = _text_of(m.get("content"), images, "System")
            if t:
                system.append(t)
            continue
        label = {"user": "User", "assistant": "Assistant", "tool": "Tool result"}.get(role, "Context")
        body = _text_of(m.get("content"), images, label)
        if role == "assistant":
            for tc in m.get("tool_calls") or []:
                fn = (tc.get("function") if isinstance(tc, dict) else getattr(tc, "function", None)) or {}
                get = fn.get if isinstance(fn, dict) else (lambda k, _f=fn: getattr(_f, k, None))
                cid = tc.get("id") if isinstance(tc, dict) else getattr(tc, "id", "")
                body += "\n<tool_call>%s</tool_call>" % json.dumps(
                    {"id": cid, "type": "function", "function": {"name": get("name"), "arguments": get("arguments")}})
        if role == "tool":
            label = "Tool result (%s)" % (m.get("tool_call_id") or m.get("name") or "")
        if body.strip():
            lines.append("%s:\n%s" % (label, body.strip()))
    system.extend(render_tool_bridge_sections(tools, tool_choice))
    if len(images) > MAX_IMAGES:
        images = images[-MAX_IMAGES:]
    text = "Conversation so far:\n\n" + "\n\n".join(lines) + "\n\nContinue the conversation from the latest user message."
    return "\n\n".join(s.strip() for s in system if s and s.strip()), [{"type": "text", "text": text}] + images


# ---- one run ---------------------------------------------------------------------------------------------------------
_LIMIT_RX = re.compile(r"hit your (?:\w+ )?limit|usage limit|reached your (?:\w+ )?limit|out of (?:extra )?usage|"
                       r"rate.?limit", re.I)
_AUTH_RX = re.compile(r"authenticat|not logged in|log ?in|/login|invalid api key|oauth|sign(?:ed)? ?in", re.I)


def reset_seconds_from(text: str, now: float | None = None) -> float | None:
    """Seconds until the reset Claude names: "|<epoch>", "resets 5pm", "resets at 3:30 PM", "resets in 2h 10m"."""
    now = now or time.time()
    m = re.search(r"\|(\d{10})\b", text or "")
    if m:
        return max(0.0, int(m.group(1)) - now) or None
    m = re.search(r"resets?\s+in\s+(?:(\d+)\s*h(?:ours?)?)?\s*(?:(\d+)\s*m(?:in(?:utes?)?)?)?", text or "", re.I)
    if m and (m.group(1) or m.group(2)):
        return int(m.group(1) or 0) * 3600 + int(m.group(2) or 0) * 60 or None
    m = re.search(r"resets?\s+(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*([ap])\.?m\b", text or "", re.I)
    if m:
        hour = int(m.group(1)) % 12 + (12 if m.group(3).lower() == "p" else 0)
        lt = time.localtime(now)
        at = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, hour, int(m.group(2) or 0), 0, 0, 0, -1))
        return (at if at > now else at + 86400) - now
    return None


def result_error(result: dict, texts: list | None = None) -> Exception:
    """The exception for a `result` event with is_error: limit, sign-in, or a plain failure."""
    errs = result.get("errors")
    text = " ".join([str(result.get("result") or "")] + [str(e) for e in (errs if isinstance(errs, list) else [errs] if errs else [])]
                    + list(texts or []))
    status = result.get("api_error_status")
    if status == 429 or _LIMIT_RX.search(text):
        return ClaudeLimitReached(text, reset_seconds_from(text))
    if status in (401, 403) or _AUTH_RX.search(text):
        forget_status()
        return ClaudeNotReady("signed_out")
    err = RuntimeError(WORDS["failed"])
    err.status_code = status if isinstance(status, int) and status >= 500 else 503
    return err


def _effort(kwargs: dict) -> str | None:
    eb = kwargs.get("extra_body") if isinstance(kwargs.get("extra_body"), dict) else {}
    r = kwargs.get("reasoning") or eb.get("reasoning") or {}
    e = kwargs.get("reasoning_effort") or eb.get("reasoning_effort") or (r.get("effort") if isinstance(r, dict) else None)
    e = str(e or "").strip().lower()
    if not e:     # the engine sends no effort to this kind of provider: the one the person saved in Qosha (journey)
        try:
            from hermes_cli.config import read_raw_config_readonly
            ag = (read_raw_config_readonly() or {}).get("agent") or {}
            e = str(ag.get("reasoning_effort") or "").strip().lower() if isinstance(ag, dict) else ""
        except Exception:
            e = ""
    return e if e in EFFORTS else None


class ClaudeCLIClient:
    """The minimal OpenAI-client facade the engine uses for external-process providers (as agent/acp_client.ACPClient),
    running the person's `claude` once per request."""
    HERMES_SKIP_TRANSPORT_WRAP = True
    HERMES_SKIP_ASYNC_WRAP = True

    def __init__(self, *, command: str | None = None, acp_command: str | None = None, base_url: str | None = None,
                 api_key: str | None = None, **_: Any):
        self.api_key, self.base_url = api_key or PROVIDER, base_url or "acp://claude-cli"
        self._command = command or acp_command
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self._create))
        self.is_closed = False
        self._procs: set = set()
        self._lock = threading.Lock()

    def close(self) -> None:
        with self._lock:
            procs, self._procs = tuple(self._procs), set()
        self.is_closed = True
        for p in procs:
            _kill(p)

    def _create(self, *, model: str | None = None, messages: list | None = None, tools: list | None = None,
                tool_choice: Any = None, stream: bool = False, timeout: Any = None, **kwargs: Any) -> Any:
        system, content = build_prompt(messages or [], tools, tool_choice)
        text, reasoning, usage = self.run(system, content, model=model, effort=_effort(kwargs),
                                          timeout=_seconds(timeout))
        offered = {str(((t or {}).get("function") or {}).get("name") or "") for t in tools or [] if isinstance(t, dict)}
        if offered and tool_choice != "none":
            # names are not filtered: the engine routes its deferred tools by name and checks every call itself
            tool_calls, cleaned = extract_tool_calls_from_text(text)
        else:
            tool_calls, cleaned = [], text      # no tools offered: quoted <tool_call> text stays words (G-CC6)
        msg = SimpleNamespace(content=cleaned, tool_calls=tool_calls, reasoning=reasoning or None,
                              reasoning_content=reasoning or None, reasoning_details=None)
        u = usage or {}
        prompt_t = int(u.get("input_tokens") or 0) + int(u.get("cache_read_input_tokens") or 0) + \
            int(u.get("cache_creation_input_tokens") or 0)
        done = SimpleNamespace(
            choices=[SimpleNamespace(message=msg, finish_reason="tool_calls" if tool_calls else "stop")],
            usage=SimpleNamespace(prompt_tokens=prompt_t, completion_tokens=int(u.get("output_tokens") or 0),
                                  total_tokens=prompt_t + int(u.get("output_tokens") or 0),
                                  prompt_tokens_details=SimpleNamespace(cached_tokens=int(u.get("cache_read_input_tokens") or 0))),
            model=model or PROVIDER)
        return completion_to_stream_chunks(done) if stream else done

    def run(self, system: str, content: list, *, model: str | None, effort: str | None, timeout: float) -> tuple:
        st = status()
        if st["state"] != "ready":
            raise ClaudeNotReady(st["state"] if st["state"] in WORDS else "signed_out")
        path = self._command if self._command and os.path.isabs(self._command) else st["path"]
        rd = _run_dir()
        sp = rd / ("system-%d-%d.txt" % (os.getpid(), threading.get_ident()))
        sp.write_text(system, encoding="utf-8")
        argv = [path, *LOCKED_FLAGS, "--system-prompt-file", str(sp)]
        model = str(model or "").strip()
        model = model.split("/", 1)[1] if model.startswith("anthropic/") else model
        if model and model != PROVIDER and not model.startswith("-"):
            argv += ["--model", model]
        if effort:
            argv += ["--effort", effort]
        try:
            proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    text=True, encoding="utf-8", errors="replace", bufsize=1, cwd=str(rd),
                                    env=child_env(path), **_hide())
        except OSError:
            forget_status()
            raise ClaudeNotReady("not_installed") from None
        with self._lock:
            self._procs.add(proc)
            self.is_closed = False
        try:
            return _converse(proc, content, timeout)
        finally:
            with self._lock:
                self._procs.discard(proc)
            _kill(proc)
            try:
                sp.unlink()
            except OSError:
                pass


class _AsyncChunks:
    def __init__(self, chunks):
        self._chunks = list(chunks)
        for k, v in vars(chunks).items() if hasattr(chunks, "__dict__") else ():
            setattr(self, k, v)

    def __aiter__(self):
        async def gen():
            for c in self._chunks:
                yield c
        return gen()

    def __iter__(self):
        return iter(self._chunks)


class AsyncClaudeCLIClient:
    """Async facade: the same run in a worker thread, so an event loop is never blocked and can await it."""
    HERMES_SKIP_TRANSPORT_WRAP = True
    HERMES_SKIP_ASYNC_WRAP = True

    def __init__(self, sync_client: "ClaudeCLIClient"):
        import asyncio
        self._sync = sync_client
        self.api_key, self.base_url = sync_client.api_key, sync_client.base_url

        async def create(**kw):
            out = await asyncio.to_thread(sync_client.chat.completions.create, **kw)
            return _AsyncChunks(out) if kw.get("stream") else out   # `async for` works on a streamed answer
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=create))

    @property
    def is_closed(self) -> bool:
        return self._sync.is_closed

    def close(self) -> None:
        self._sync.close()

    async def aclose(self) -> None:
        self._sync.close()


def _seconds(timeout: Any) -> float:
    if isinstance(timeout, (int, float)) and timeout > 0:
        return float(timeout)
    vals = [getattr(timeout, a, None) for a in ("read", "write", "connect", "pool", "timeout")]
    vals = [float(v) for v in vals if isinstance(v, (int, float))]
    return max(vals) if vals else DEFAULT_TIMEOUT


def _kill(proc) -> None:
    """Ends the run and whatever it started (its process group on Mac; its process tree on Windows)."""
    try:
        if proc.poll() is None:
            if os.name == "nt":
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True, timeout=10,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
            else:
                import signal
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except Exception:
                    proc.kill()
        if proc.poll() is None:
            proc.kill()
        proc.wait(timeout=5)
    except Exception:
        pass


def _converse(proc, content: list, timeout: float) -> tuple:
    """Send the one user message, read events until the result. Refuses (and kills the run) when the init event shows
    any tool, MCP server, hook or API key."""
    lines: queue.Queue = queue.Queue()
    threading.Thread(target=lambda: [lines.put(x) for x in proc.stdout] + [lines.put(None)], daemon=True).start()
    threading.Thread(target=lambda: [None for _ in proc.stderr], daemon=True).start()
    try:
        proc.stdin.write(json.dumps({"type": "user", "message": {"role": "user", "content": content}}) + "\n")
        proc.stdin.close()
    except OSError:
        raise RuntimeError(WORDS["failed"]) from None
    deadline, texts, thoughts, checked = time.monotonic() + timeout, [], [], False
    heard = time.monotonic()
    while True:
        left = deadline - time.monotonic()
        if left <= 0 or time.monotonic() - heard > IDLE_S:
            raise TimeoutError("Claude took too long to answer.")
        try:
            line = lines.get(timeout=min(left, 1.0))
        except queue.Empty:
            continue
        heard = time.monotonic()
        if line is None:
            raise RuntimeError(WORDS["failed"])
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        kind, sub = ev.get("type"), ev.get("subtype")
        if kind == "system" and sub == "init":
            # every lock must be shown in the init event itself; a missing field counts as not locked (review CC-1)
            if ev.get("tools") != [] or ev.get("mcp_servers") != []:
                raise ClaudeNotReady("locked")
            if ev.get("apiKeySource") != "none":
                raise ClaudeNotReady("not_subscription")
            checked = True
        elif kind == "system" and str(sub or "").startswith("hook"):
            raise ClaudeNotReady("locked")
        elif kind == "assistant":
            if not checked:
                raise ClaudeNotReady("locked")
            for b in (ev.get("message") or {}).get("content") or []:
                kind_b = b.get("type") if isinstance(b, dict) else None
                if kind_b == "text":
                    texts.append(str(b.get("text") or ""))
                elif kind_b == "thinking":
                    thoughts.append(str(b.get("thinking") or ""))
                elif kind_b != "redacted_thinking":
                    raise ClaudeNotReady("locked")     # only words and thinking are allowed (review G-CC4)
        elif kind == "user":
            raise ClaudeNotReady("locked")             # a tool result inside the run means a tool ran
        elif kind == "result":
            if not checked:
                raise ClaudeNotReady("locked")
            if ev.get("is_error"):
                raise result_error(ev, texts)
            out = ev.get("result")
            return (out if isinstance(out, str) and out else "".join(texts)), "".join(thoughts), ev.get("usage") or {}


# ---- the provider ----------------------------------------------------------------------------------------------------
def classify(error, **_kw):
    """The engine's per-provider error hook: a limit or a missing sign-in ends the turn (no retry loop, no fallback
    chosen here); claude_limit.py turns the end into Qosha's words."""
    if isinstance(error, ClaudeLimitReached):
        return {"reason": "rate_limit", "retryable": True, "should_fallback": False, "should_rotate_credential": False}
    if isinstance(error, ClaudeNotReady):
        return {"reason": "rate_limit", "retryable": True, "should_fallback": False, "should_rotate_credential": False}
    return None


def is_route_error(error) -> bool:
    return isinstance(error, (ClaudeLimitReached, ClaudeNotReady))


def register() -> bool:
    """Registers provider "claude-cli" (shown as "Claude"). Nothing selects it until the person's Claude choice does."""
    from providers import register_provider
    from providers.base import ProviderProfile

    class ClaudeCLIProfile(ProviderProfile):
        def create_client(self, **kw):
            return ClaudeCLIClient(**kw)

        def build_api_kwargs_extras(self, *a, reasoning_config=None, **kw):
            """The effort the person chose reaches the client (-> `claude --effort`); nothing else is added."""
            rc = reasoning_config if isinstance(reasoning_config, dict) else {}
            e = str(rc.get("effort") or "").strip().lower()
            return {}, ({"reasoning_effort": e} if rc.get("enabled") is not False and e in EFFORTS else {})

    register_provider(ClaudeCLIProfile(
        name=PROVIDER, display_name="Claude", description="Claude, with your own Claude subscription",
        auth_type="external_process", base_url="acp://claude-cli", process_command="claude",
        supports_vision=True, supports_model_listing=False, supports_health_check=False,
        fallback_models=MODELS, classify_api_error=classify,
        # pictures go to the model itself (image blocks), not through a side call that describes them (journey K3)
        model_capabilities={m: {"supports_vision": True} for m in MODELS}))
    apply_route()
    return True


# ---- slice 2: Qosha's "Claude" uses the program; sign-in, install, sign-out ------------------------------------------
CFG, ROUTE_KEY = "qosha_ai", "claude_route"
LOGIN_TTL = 900
_logins: dict[str, dict] = {}
_logins_lock = threading.Lock()
_installing = threading.Lock()
_login_start_lock = threading.Lock()
_presses: dict[str, float] = {}


def route_on() -> bool:
    """The person connected Claude through their own program (Connect AI): every "Claude" request goes to it."""
    try:
        from hermes_cli.config import read_raw_config_readonly
        q = (read_raw_config_readonly() or {}).get(CFG) or {}
        return isinstance(q, dict) and q.get(ROUTE_KEY) == "program"
    except Exception:
        return False


def _is_claude(name) -> bool:
    v = str(name or "").strip().lower()
    try:
        from hermes_cli.providers import normalize_provider
        v = str(normalize_provider(v) or v).lower()
    except Exception:
        pass
    return v in ("anthropic", "claude", "claude-code", "claude-oauth")


def apply_route() -> bool:
    """While the route is on, the engine's provider ladder (every chat, automation, model switch) and its side-call
    router resolve "anthropic" as this provider: no Claude request can use a token Qosha holds."""
    from hermes_cli import runtime_provider as rp
    from agent import auxiliary_client as ax
    orig = rp._ladder_rungs
    if not getattr(orig, "qosha_claude_cli", False):
        def _ladder_rungs(requested_provider, explicit_api_key, explicit_base_url, target_model):
            if explicit_api_key == PROVIDER:
                explicit_api_key = None                       # this route's own placeholder, never a key
            if not explicit_api_key and _is_claude(requested_provider) and route_on():
                requested_provider = PROVIDER
            auto = str(requested_provider or "").strip().lower() in ("", "auto")
            rungs = orig(requested_provider, explicit_api_key, explicit_base_url, target_model)
            while True:
                try:
                    rung = next(rungs)
                except StopIteration:
                    return
                except Exception as exc:
                    # an "auto" request whose Claude step refuses (the saved key is held back) goes to the program;
                    # any other failure is the engine's own (review R2-1)
                    refused_claude = bool(getattr(exc, "qosha_claude_refusal", False)) or \
                        type(exc).__name__ == "ClaudeKeyRefused"         # only Qosha's own refusal (fix slice, item 6)
                    if auto and refused_claude and not explicit_api_key and route_on():
                        yield next(r for r in orig(PROVIDER, None, explicit_base_url, target_model) if r)
                        return
                    raise
                # an "auto" request that lands on Claude goes to the program too (review G-CC2)
                if rung and not explicit_api_key and _is_claude((rung or {}).get("provider")) and route_on():
                    yield next(r for r in orig(PROVIDER, None, explicit_base_url, target_model) if r)
                    return
                yield rung
        _ladder_rungs.qosha_claude_cli = True
        _ladder_rungs.__wrapped__ = orig
        rp._ladder_rungs = _ladder_rungs
    orig_creds = rp.resolve_external_process_provider_credentials
    if not getattr(orig_creds, "qosha_claude_cli", False):
        def resolve_external_process_provider_credentials(provider_id, *a, **kw):
            try:
                return orig_creds(provider_id, *a, **kw)
            except Exception:
                if str(provider_id or "").lower() != PROVIDER:
                    raise
                # the program is missing: the request goes on to Qosha's client, which says so in the person's words
                return {"provider": PROVIDER, "api_key": PROVIDER, "base_url": "acp://claude-cli", "command": "claude",
                        "args": [], "source": "process"}
        resolve_external_process_provider_credentials.qosha_claude_cli = True
        resolve_external_process_provider_credentials.__wrapped__ = orig_creds
        rp.resolve_external_process_provider_credentials = resolve_external_process_provider_credentials
    from agent import anthropic_credentials as acr
    for name in ("read_claude_code_credentials", "_read_claude_code_credentials_from_keychain",
                 "_read_claude_code_credentials_from_file"):
        orig_read = getattr(acr, name, None)
        if callable(orig_read) and not getattr(orig_read, "qosha_claude_cli", False):
            def _reader(*a, _o=orig_read, **kw):
                # the engine never reads (or refreshes) the `claude` program's own sign-in: borrowing it is holding the
                # token, and two refreshers log each other out (review CC-2, round 2: also with the route off)
                return None
            _reader.qosha_claude_cli = True
            _reader.__wrapped__ = orig_read
            setattr(acr, name, _reader)
    orig_try = getattr(ax, "_try_anthropic", None)
    if callable(orig_try) and not getattr(orig_try, "qosha_claude_cli", False):
        def _try_anthropic(*a, **kw):        # explicit Claude side calls (vision) take the program too (CC-4)
            if route_on():
                return ax.resolve_provider_client(PROVIDER, kw.get("requested_model"))
            return orig_try(*a, **kw)
        _try_anthropic.qosha_claude_cli = True
        _try_anthropic.__wrapped__ = orig_try
        ax._try_anthropic = _try_anthropic
    orig_cached = ax._get_cached_client
    if not getattr(orig_cached, "qosha_claude_cli", False):
        def _get_cached_client(provider, model=None, async_mode=False, base_url=None, api_key=None, api_mode=None,
                               *a, **kw):   # the cache is keyed after the route choice (CC-5)
            if not api_key and _is_claude(provider) and route_on():
                provider, api_mode = PROVIDER, None
            _drop_cache_on_change()
            return orig_cached(provider, model, async_mode, base_url, api_key, api_mode, *a, **kw)
        _get_cached_client.qosha_claude_cli = True
        _get_cached_client.__wrapped__ = orig_cached
        ax._get_cached_client = _get_cached_client
    orig_async = ax._to_async_client
    if not getattr(orig_async, "qosha_claude_cli", False):
        def _to_async_client(sync_client, model, *a, **kw):   # an awaitable client for async callers (CC-11)
            if type(sync_client).__name__ == "ClaudeCLIClient":   # by name: the module may be loaded twice (item 8)
                return AsyncClaudeCLIClient(sync_client), model
            return orig_async(sync_client, model, *a, **kw)
        _to_async_client.qosha_claude_cli = True
        _to_async_client.__wrapped__ = orig_async
        ax._to_async_client = _to_async_client
    orig_aux = ax.resolve_provider_client
    if not getattr(orig_aux, "qosha_claude_cli", False):
        def resolve_provider_client(provider, *a, **kw):
            if kw.get("explicit_api_key") == PROVIDER:
                kw["explicit_api_key"] = None
            if not kw.get("explicit_api_key") and _is_claude(provider) and route_on():
                provider, kw["api_mode"] = PROVIDER, None
            return orig_aux(provider, *a, **kw)
        resolve_provider_client.qosha_claude_cli = True
        resolve_provider_client.__wrapped__ = orig_aux
        ax.resolve_provider_client = resolve_provider_client
    return True


_cache_state = {"seen": None}


def _drop_cache_on_change() -> None:
    """Every cached side-call client was chosen under one Claude state (route on/off, subscription marker): when that
    changes, the engine's whole side-call cache is emptied, so no client chosen before is reused (fix slice, item 1)."""
    try:
        state = (route_on(), _limit_module()._marker(_home()).exists())
    except Exception:
        state = None
    if state != _cache_state["seen"]:
        _cache_state["seen"] = state
        try:
            from agent import auxiliary_client as ax
            with ax._client_cache_lock:
                ax._client_cache.clear()
        except Exception:
            pass


def set_route(on: bool) -> None:
    from hermes_cli.config import save_config
    if on:
        # this computer has a Claude subscription: from now on a saved API key is never used for Claude unless the
        # person chooses it, also after a Disconnect (claude_limit's marker; review G-CC1)
        lm = _limit_module()
        lm._note_seen(_home())
        if not lm._marker(_home()).exists():   # never on without it (review R2-3): a saved key could otherwise be used
            raise OSError("subscription marker not written")
    if on:
        _drop_held_tokens()
        if _held_tokens_left():       # the old copies must be gone before the switch is saved (D-2)
            raise OSError("Qosha's stored Claude sign-in could not be removed")
    save_config({CFG: {ROUTE_KEY: "program" if on else "off"}}, merge_existing=True)
    _drop_cache_on_change()


def _drop_held_tokens() -> int:
    """Qosha's own stored copies of a Claude subscription sign-in (Connect AI before cc19) are removed: the program
    holds the person's sign-in now. API keys are not touched."""
    n = 0
    try:
        from agent.credential_pool import AUTH_TYPE_OAUTH, load_pool
        pool = load_pool("anthropic")
        for i in range(len(pool.entries()), 0, -1):
            if getattr(pool.entries()[i - 1], "auth_type", None) == AUTH_TYPE_OAUTH:
                pool.remove_index(i)
                n += 1
    except Exception:
        pass
    # Qosha's own stored copies elsewhere (Ren, card 22 Nov 2026: "Yes, delete them"): the subscription token in
    # Qosha's .env and Qosha's own sign-in file. An API key (sk-ant-api...) is never touched.
    try:
        from hermes_cli.config import load_env, remove_env_value
        env = load_env() or {}
        for key in ("CLAUDE_CODE_OAUTH_TOKEN", "ANTHROPIC_TOKEN"):
            val = str(env.get(key) or "")
            if val and (key == "CLAUDE_CODE_OAUTH_TOKEN" or _oauth_value(val)):
                n += 1 if remove_env_value(key) else 0
    except Exception:
        pass
    try:
        f = _home() / ".anthropic_oauth.json"
        if f.exists():
            f.unlink()
            n += 1
    except OSError:
        pass
    return n


def _oauth_value(val: str) -> bool:
    """A Claude subscription token as the engine itself recognises one (sk-ant-oat..., and its other formats); an API
    key is never one (D-1)."""
    try:
        from agent.anthropic_credentials import _is_oauth_token
        return bool(val) and bool(_is_oauth_token(val))
    except Exception:
        return str(val).startswith("sk-ant-oat")


def _held_tokens_left() -> bool:
    try:
        from hermes_cli.config import load_env
        env = load_env() or {}
        if env.get("CLAUDE_CODE_OAUTH_TOKEN") or _oauth_value(str(env.get("ANTHROPIC_TOKEN") or "")):
            return True
    except Exception:
        return True
    return (_home() / ".anthropic_oauth.json").exists()


def press_new() -> str:
    """A one-time token for one press of an install / sign-out button (asked for inside the click)."""
    import secrets
    tok = secrets.token_urlsafe(18)
    now = time.time()
    with _logins_lock:
        for k in [k for k, t in _presses.items() if now - t > 120]:
            _presses.pop(k, None)
        _presses[tok] = now
    return tok


def _press_ok(tok: str) -> bool:
    with _logins_lock:
        t = _presses.pop(str(tok or ""), None)
    return t is not None and time.time() - t <= 120


def login_start() -> dict:
    """Starts the program's own sign-in (`claude auth login --claudeai`) in the background and returns the Claude
    address the page opens; the code Claude then shows goes to login_finish. Qosha never sees a token."""
    st = status(force=True)
    if st["state"] == "not_installed":
        return {"ok": False, "error": "not_installed", "plain": WORDS["not_installed"]}
    try:                                       # no marker, no sign-in (fix slice, item 7)
        lm = _limit_module()
        lm._note_seen(_home())
        if not lm._marker(_home()).exists():
            raise OSError("marker")
    except Exception:
        return {"ok": False, "error": "not_saved", "plain": "Qosha couldn't save a setting on this computer, so Claude's "
                "sign-in didn't start. Try again."}
    if not _login_start_lock.acquire(blocking=False):
        return {"ok": False, "error": "busy", "plain": "A Claude sign-in is already starting. Wait a moment."}
    try:
        return _login_start(st)
    finally:
        _login_start_lock.release()


def _login_start(st: dict) -> dict:
    with _logins_lock:                         # one sign-in at a time: an earlier, abandoned one ends now (CC-9)
        for k in list(_logins):
            _kill(_logins.pop(k)["proc"])
    path = st["path"]
    proc = subprocess.Popen([path, "auth", "login", "--claudeai"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1,
                            cwd=str(_run_dir()), env=dict(child_env(path), BROWSER="none"), **_hide())
    out: list = []
    threading.Thread(target=lambda: [out.append(x) for x in proc.stdout], daemon=True).start()
    url, t0 = None, time.time()
    while time.time() - t0 < 20 and proc.poll() is None and not url:
        plain_out = re.sub(r"\x1b\[[0-9;?]*[ -/]*[@-~]", "", "".join(out))      # no terminal colour codes
        m = re.search(r"https://(?:[a-z0-9-]+\.)?claude\.(?:ai|com)/[^\s]*oauth/authorize\?\S+", plain_out)
        url = m.group(0) if m else None
        time.sleep(0.1)
    if not url:
        _kill(proc)
        return {"ok": False, "error": "no_url", "plain": "Claude's sign-in didn't start. Try again in a minute."}
    import secrets
    sid = secrets.token_urlsafe(12)
    with _logins_lock:
        for k in [k for k, v in _logins.items() if time.time() - v["at"] > LOGIN_TTL]:
            _kill(_logins.pop(k)["proc"])
        _logins[sid] = {"proc": proc, "at": time.time(), "out": out}

    def _expire(sid=sid):                      # an abandoned sign-in ends by itself (review R2)
        with _logins_lock:
            pend = _logins.pop(sid, None)
        if pend:
            _kill(pend["proc"])
    t = threading.Timer(LOGIN_TTL, _expire)
    t.daemon = True
    t.start()
    return {"ok": True, "id": sid, "url": url}


def login_finish(sid: str, code: str) -> dict:
    """The code Claude showed goes to the waiting sign-in; on success Qosha's "Claude" uses the program."""
    if not _login_start_lock.acquire(timeout=5):   # no new sign-in starts while this one finishes (fix slice, item 3)
        return {"ok": False, "error": "busy", "plain": "A Claude sign-in is already starting. Wait a moment."}
    try:
        return _login_finish(sid, code)
    finally:
        _login_start_lock.release()


def _login_finish(sid: str, code: str) -> dict:
    with _logins_lock:
        pend = _logins.pop(str(sid or ""), None)
    if pend and time.time() - pend["at"] > LOGIN_TTL:
        _kill(pend["proc"])
        pend = None
    if not pend:
        return {"ok": False, "error": "expired", "plain": "This sign-in expired. Press Sign in with Claude again."}
    proc, code = pend["proc"], str(code or "").strip()
    if not code or len(code) > 512 or any(ord(c) < 32 or ord(c) == 127 for c in code):
        _kill(proc)
        return {"ok": False, "error": "bad_format", "plain": "That code doesn't look right. Press Sign in with Claude again "
                                                            "and copy the whole code Claude shows."}
    rc = None
    try:
        proc.stdin.write(code + "\n")
        proc.stdin.flush()
        proc.stdin.close()
        rc = proc.wait(timeout=60)
    except Exception:
        _kill(proc)
    said = [l.strip() for l in "".join(pend.get("out") or []).splitlines() if l.strip()]
    said = said[-1][-300:] if said and "authorize?" not in said[-1] else ""   # the program's own last line (no link)
    st = status(force=True)
    if rc != 0 or st["state"] != "ready":        # the program itself must have accepted this code (CC-9)
        expired = "expired" in said.lower() or "earlier sign-in" in said.lower()
        plain = ("That code was not accepted: Claude's sign-in codes work only for a few minutes and only once. Press "
                 "Sign in with Claude again and paste the new code right away.") if expired else (
            "Claude didn't accept that code. Press Sign in with Claude again." if st["state"] == "signed_out"
            else WORDS.get(st["state"], WORDS["failed"]))
        return {"ok": False, "error": st["state"], "plain": plain, "program_said": said}
    try:
        set_route(True)
    except Exception:
        return {"ok": False, "error": "not_saved", "plain": "Claude is signed in, but Qosha couldn't save the switch on "
                "this computer, so it isn't using it yet. Try Sign in with Claude again."}
    return {"ok": True, "plain": "Claude is signed in."}


def install(press: str) -> dict:
    """Installs Claude's own program with Anthropic's official installer (only on the person's press)."""
    if not _press_ok(press):
        return {"ok": False, "error": "no_press", "plain": "Press Install Claude again."}
    if not _installing.acquire(blocking=False):
        return {"ok": False, "error": "busy", "plain": "Claude is already being installed. Wait a minute."}
    try:
        if os.name == "nt":
            argv = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", "irm https://claude.ai/install.ps1 | iex"]
        else:
            argv = ["/bin/bash", "-c", "curl -fsSL https://claude.ai/install.sh | bash"]
        env = child_env(None)
        if os.name != "nt":
            env["PATH"] = "/usr/bin:/bin:/usr/sbin:/sbin:" + env.get("PATH", "")
        r = subprocess.run(argv, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600,
                           cwd=str(_run_dir()), env=env, stdin=subprocess.DEVNULL, **_hide())
        forget_status()
        st = status(force=True)
        if st["state"] == "not_installed":
            return {"ok": False, "error": "install_failed", "plain": "Claude's installer didn't finish (code %s). Check the "
                                                                     "internet connection and try again." % r.returncode}
        return {"ok": True, "state": st["state"], "plain": "Claude is installed. Now sign in with your Claude account."}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "install_failed", "plain": "Claude's installer took too long. Try again."}
    finally:
        _installing.release()


def sign_out(press: str) -> dict:
    """Signs Claude's program out on this computer (`claude auth logout`) and Qosha stops using it."""
    if not _press_ok(press):
        return {"ok": False, "error": "no_press", "plain": "Press Disconnect again."}
    st = status(force=True)
    if st["path"]:
        try:
            subprocess.run([st["path"], "auth", "logout"], capture_output=True, timeout=30, cwd=str(_run_dir()),
                           env=child_env(st["path"]), stdin=subprocess.DEVNULL, **_hide())
        except Exception:
            pass
    forget_status()
    if status(force=True)["state"] in ("ready", "not_subscription", "unknown"):
        # still signed in: nothing changes, so Disconnect can simply be pressed again (review R2, CC-10)
        return {"ok": False, "error": "still_signed_in", "plain": "Claude's program on this computer is still signed "
                "in, so nothing changed. Try Disconnect again."}
    set_route(False)                    # only once the program is signed out
    return {"ok": True, "plain": "Claude is signed out on this computer."}
