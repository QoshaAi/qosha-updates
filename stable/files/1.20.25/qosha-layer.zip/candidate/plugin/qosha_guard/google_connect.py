"""Connect Google in one step (Ren, 17 Nov 2026: "the person just sees Connected, no copy-paste").

The engine's bundled google-workspace skill signs in with a redirect to http://localhost:1, so the person must copy the
browser's address back into the chat. This helper uses the same skill (its scopes, client file and token format, so
google_api.py works unchanged) but catches Google's redirect on a loopback port of this computer, so the person only
signs in to Google and sees "Connected".

Tool: qosha_connect_google. Python: start_flow() -> dict (returns at once), flow_status(id), cancel_flow(),
open_in_browser(id), connect(timeout=300) -> dict (waits; kept for scripts).
The Google OAuth client comes from <home>/google_client_secret.json (the skill's place); if it is missing, a Qosha
install may ship one as <plugin>/google_client.json (Desktop-app client, no secret values in this repo).

17 Nov 2026 evening (Windows, real client): the sign-in used to be opened only by the hidden dashboard process
(webbrowser.open) while the page waited up to 300 s with no address. On Windows a hidden background process may not
bring a window forward while the person is using another one (foreground lock), so Google's page opened BEHIND the
Qosha window and nothing visible happened. Now the flow starts and the address comes back at once; the PAGE opens it
(the window the person is using may bring the browser forward) and shows a link; the loopback server waits in the
background for up to 10 minutes, one flow at a time, state checked, PKCE kept; the page polls flow_status().
"""
from __future__ import annotations

import hashlib
import hmac
import html
import importlib.util
import contextlib
import json
import logging
import re
import os
import secrets
import shutil
import sys
import threading
import time
import types
import urllib.error
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import parse_qs, quote, urlparse


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes"))


def _skill_setup():
    """The bundled skill's setup.py, loaded as a module (home copy first, then the engine's)."""
    cands = [_home() / "skills" / "productivity" / "google-workspace" / "scripts" / "setup.py"]
    try:
        import hermes_constants
        cands.append(Path(hermes_constants.__file__).resolve().parent / "skills" / "productivity" / "google-workspace"
                     / "scripts" / "setup.py")
    except Exception:
        pass
    for p in cands:
        if p.is_file():
            import sys
            if str(p.parent) not in sys.path:
                sys.path.insert(0, str(p.parent))
            spec = importlib.util.spec_from_file_location("qosha_gws_setup", p)
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)
            return m
    raise RuntimeError("the google-workspace skill is not installed")


# Google Workspace MCP (taylorwilsdon/google_workspace_mcp 2.5.0; Ren 02:20: full tool set for Gmail, Calendar, Drive,
# Docs, Sheets, Contacts, Tasks): one sign-in feeds both it and the bundled skill. Its scopes for those services:
WORKSPACE_MCP_SCOPES = [
    "https://www.googleapis.com/auth/" + x for x in (
        "calendar", "calendar.events", "calendar.readonly", "contacts", "contacts.readonly", "documents",
        "documents.readonly", "drive", "drive.file", "drive.readonly", "gmail.compose", "gmail.labels", "gmail.modify",
        "gmail.readonly", "gmail.send", "gmail.settings.basic", "spreadsheets", "spreadsheets.readonly", "tasks",
        "tasks.readonly", "userinfo.email", "userinfo.profile")] + ["openid"]


# 1.20.9 (contract CONTRACT-GEXEC, Ren 21 Nov 2026: "the AI's Google access becomes read-only"): the one sign-in Qosha
# keeps on disk can only read. Writes get their own short grant from Qosha's executor, held in memory only (G3).
SIGNIN_SCOPES = ["https://www.googleapis.com/auth/" + x for x in (
    "gmail.readonly", "calendar.readonly", "drive.readonly", "documents.readonly", "spreadsheets.readonly",
    "contacts.readonly", "tasks.readonly", "userinfo.email", "userinfo.profile")] + ["openid"]
_READ_SCOPE_OK = set(SIGNIN_SCOPES) | {"email", "profile", "https://www.googleapis.com/auth/calendar.events.readonly",
                                       "https://www.googleapis.com/auth/gmail.metadata"}


_PLAIN = {"gmail.readonly": "Gmail reading", "calendar.readonly": "Calendar reading", "drive.readonly": "Drive reading",
          "documents.readonly": "Docs reading", "spreadsheets.readonly": "Sheets reading",
          "contacts.readonly": "Contacts reading", "tasks.readonly": "Tasks reading"}


class Unticked(Exception):
    """Google's page came back without some read permissions (every box there starts unticked)."""
    def __init__(self, missing, revoked=True):
        super().__init__(", ".join(missing))
        self.missing, self.revoked = list(missing), bool(revoked)


class Refused(Exception):
    """A sign-in Qosha won't keep, with the plain sentence both screens show (final pass r2 H5)."""
    def __init__(self, plain, revoked=True):
        super().__init__(plain)
        self.revoked = bool(revoked)
        self.plain = plain + ("" if revoked else _NOT_TAKEN_BACK)


def _tokeninfo_scopes(creds) -> Optional[list]:
    """What Google says a fresh access token can do, when Google's answer left the permissions out (RFC 6749 5.1
    allows that; final pass r2 H6). None when Google can't be asked. The token goes in the body, never the address."""
    import urllib.parse
    import urllib.request
    try:
        body = urllib.parse.urlencode({"access_token": str(getattr(creds, "token", "") or "")}).encode()
        with urllib.request.urlopen(urllib.request.Request("https://oauth2.googleapis.com/tokeninfo", data=body),
                                    timeout=15) as r:
            got = json.loads(r.read().decode("utf-8"))
        return str(got.get("scope") or "").split()
    except Exception:  # noqa: BLE001
        return None


_NOT_TAKEN_BACK = (" Qosha couldn\u2019t confirm Google took that sign-in back: you can remove \u201cQosha\u201d at "
                   "myaccount.google.com/permissions.")


def _revoke_sure(creds) -> bool:
    """Revoke, tried twice (final pass H4). True when Google confirmed."""
    tok = str(getattr(creds, "refresh_token", "") or getattr(creds, "token", "") or "")
    for _i in range(2):
        try:
            if tok and _revoke(tok):
                return True
        except Exception:  # noqa: BLE001
            pass
    return False


def _below_warning(record) -> bool:
    return record.levelno >= logging.WARNING


for _n in ("requests_oauthlib", "requests_oauthlib.oauth2_session", "oauthlib", "google_auth_oauthlib", "google.auth",
           "google.auth.transport.requests"):
    _lg = logging.getLogger(_n)
    if not any(getattr(f, "__name__", "") == "_below_warning" for f in _lg.filters):
        _lg.addFilter(_below_warning)      # token answers are logged at DEBUG: never, at any time (as google_write)


@contextlib.contextmanager
def _quiet_oauth():
    """The OAuth libraries log whole token answers at DEBUG: never while a grant is exchanged, refused or revoked
    (GPT HIGH 6; P0 final pass H3). One counted guard for the whole process (the sign-in and the write module share
    it, even when loaded twice), covering every logger under those names; the person's levels come back when the
    last exchange ends."""
    import logging
    import types
    st = sys.modules.get("qosha_oauth_quiet_state")
    if st is None:
        st = sys.modules.setdefault("qosha_oauth_quiet_state", types.ModuleType("qosha_oauth_quiet_state"))
    if not hasattr(st, "lock"):
        st.lock, st.depth, st.saved = threading.Lock(), 0, {}
    names = ("requests_oauthlib", "oauthlib", "google_auth_oauthlib", "google.auth", "urllib3")
    with st.lock:
        if st.depth == 0:
            every = [n for n in list(logging.root.manager.loggerDict)
                     if any(n == p or n.startswith(p + ".") for p in names)]
            st.saved = {n: (logging.getLogger(n).level, logging.getLogger(n).propagate) for n in set(every) | set(names)}
            for n in st.saved:
                logging.getLogger(n).setLevel(logging.WARNING)
                logging.getLogger(n).propagate = False
        st.depth += 1
    try:
        yield
    finally:
        with st.lock:
            st.depth -= 1
            if st.depth == 0:
                for n, (lvl, prop) in st.saved.items():
                    logging.getLogger(n).setLevel(lvl)
                    logging.getLogger(n).propagate = prop
                st.saved = {}


def unticked_message(exc) -> str:
    miss = list(getattr(exc, "missing", []) or [])
    what = (", ".join(miss[:-1]) + " and " + miss[-1]) if len(miss) > 1 else (miss[0] if miss else "some items")
    return ("Google isn\u2019t connected yet: %s %s ticked on Google\u2019s page. Press Connect Google again, then tick "
            "every box (or \u201cSelect all\u201d) and press Continue." % (what, "wasn\u2019t" if len(miss) == 1 else "weren\u2019t")
            + ("" if getattr(exc, "revoked", True) else _NOT_TAKEN_BACK))


def _id_claims(creds) -> dict:
    """The claims of the ID token Google just returned over its own TLS connection (email, hd)."""
    import base64
    tok = str(getattr(creds, "id_token", "") or "")
    try:
        part = tok.split(".")[1]
        return json.loads(base64.urlsafe_b64decode(part + "=" * (-len(part) % 4)).decode("utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def _revoke(token: str) -> bool:
    """Ask Google to forget a grant (the refresh token and everything granted with it). True when Google said so."""
    import urllib.parse
    import urllib.request
    try:
        req = urllib.request.Request("https://oauth2.googleapis.com/revoke",
                                     data=urllib.parse.urlencode({"token": token}).encode(),
                                     headers={"Content-Type": "application/x-www-form-urlencoded"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return 200 <= r.status < 300
    except Exception:
        return False


_TEMP = re.compile(r"\.tmp\.\d+\.[0-9a-f]{8}$")


def _is_temp_name(name: str) -> bool:
    """The old writer's exact temp name (<name>.tmp.<pid>.<8 hex>), never an account address that contains ".tmp."."""
    return bool(_TEMP.search(name))


def _sign_in_files(h: Path) -> list:
    """Every file that may hold a Google sign-in: the skill's token, the old writer's leftover temp files, and the
    Workspace tools' copies (GPT r1209 r2 HIGH 6)."""
    c = h / "google_workspace_mcp" / "credentials"
    return ([h / "google_token.json"] + sorted(p for p in h.glob("google_token.tmp.*") if _is_temp_name(p.name)) +
            (sorted(c.glob("*.json")) + sorted(p for p in c.glob("*.tmp.*") if _is_temp_name(p.name)) if c.is_dir() else []))


def _scopes_of(data: Any) -> list:
    if not isinstance(data, dict):
        return []
    s = data.get("scopes") or data.get("scope") or []
    return s.split() if isinstance(s, str) else [str(x) for x in s] if isinstance(s, list) else []


def _complete(scopes) -> bool:
    """All seven reading permissions are there (every box ticked)."""
    have = set(scopes or [])
    return all("https://www.googleapis.com/auth/" + s in have for s in _PLAIN)


def _read_only(data: Any) -> bool:
    s = _scopes_of(data)
    return bool(s) and all(x in _READ_SCOPE_OK for x in s)     # unknown scopes count as more than reading


_REVOKED_SEEN: set = set()      # grant marks Google answered invalid_grant for in this process (never a token)


def _granted_scopes(data: Any) -> Optional[list]:
    """What Google says this sign-in can do (a fresh access token's tokeninfo), or None when that can't be asked
    (offline, no client): local labels are only a hint (GPT r1209 r2 HIGH 8). Never logs a token."""
    import urllib.parse
    import urllib.request
    try:
        if not isinstance(data, dict) or not data.get("refresh_token") or not data.get("client_id"):
            return None
        body = urllib.parse.urlencode({"client_id": data["client_id"], "client_secret": data.get("client_secret", ""),
                                       "refresh_token": data["refresh_token"], "grant_type": "refresh_token"}).encode()
        try:
            with urllib.request.urlopen(urllib.request.Request("https://oauth2.googleapis.com/token", data=body),
                                        timeout=15) as r:
                at = json.loads(r.read().decode()).get("access_token")
        except urllib.error.HTTPError as exc:
            try:
                err = json.loads(exc.read().decode("utf-8", "replace")).get("error")
            except Exception:  # noqa: BLE001
                err = ""
            if exc.code == 400 and err == "invalid_grant":
                _REVOKED_SEEN.add(_rt_mark(str(data["refresh_token"])))   # Google ended it (r4 H4)
            return None
        if not at:
            return None
        with urllib.request.urlopen("https://oauth2.googleapis.com/tokeninfo?access_token=" + urllib.parse.quote(at), timeout=15) as r:
            return str(json.loads(r.read().decode()).get("scope") or "").split()
    except Exception:
        return None


def _revoke_once(data: Any, done: set) -> bool:
    if not isinstance(data, dict):
        return False
    for k in ("refresh_token", "token"):
        tok = data.get(k)
        if tok:
            mark = hashlib.sha256(str(tok).encode()).hexdigest()
            if mark in done:
                return True
            ok = _revoke(str(tok))
            if ok:
                done.add(mark)
            return ok
    return False


def _revoked_marks(h: Path) -> set:
    try:
        return set(json.loads((h / "google_revoked.json").read_text(encoding="utf-8")).get("marks", []))
    except Exception:
        return set()


def _update_running(h: Path) -> bool:
    """The updater is replacing Qosha right now (its health check compares the sign-in files before and after)."""
    try:
        s = json.loads((h / "qosha" / "updates.json").read_text(encoding="utf-8"))
        return isinstance(s, dict) and bool(s.get("applying"))
    except Exception:
        return False


def _zip_sign_ins(z: Path, done: set) -> bool:
    """An older daily backup: its sign-in entries are revoked when they could do more than read, and taken out of the
    archive either way (the rest stays). True when the archive was rewritten (GPT r1209 r2 HIGH 5)."""
    import zipfile
    try:
        with zipfile.ZipFile(str(z)) as zf:
            names = zf.namelist()
            gone = [n for n in names if _is_sign_in_name(n)]
            if not gone:
                return False
            for n in gone:
                try:
                    data = json.loads(zf.read(n).decode("utf-8"))
                except Exception:
                    data = None
                if not _read_only(data):
                    _revoke_once(data, done)
            tmp = z.with_name(z.name + ".qosha-tmp")
            with zipfile.ZipFile(str(tmp), "w", compression=zipfile.ZIP_DEFLATED) as out:
                for info in zf.infolist():
                    if info.filename not in gone:
                        out.writestr(info, zf.read(info.filename))
        try:
            os.chmod(str(tmp), 0o600)
        except OSError:
            pass
        os.replace(str(tmp), str(z))
        return True
    except Exception:
        return False


def _is_sign_in_name(n: str) -> bool:
    b = n.replace("\\", "/")
    leaf = b.rsplit("/", 1)[-1]
    return (leaf in ("google_token.json", "google_oauth_pending.json") or leaf.startswith("google_token.tmp.")
            or "google_workspace_mcp/credentials/" in b)


SIGNED_OUT = "google_signed_out.json"


def _rt_mark(rt: str) -> str:
    return hashlib.sha256(("qosha-signed-out:" + rt).encode()).hexdigest()[:16]


def _stored_rt(h: Path) -> str:
    try:
        d = json.loads((h / "google_token.json").read_text(encoding="utf-8"))
        return str(d.get("refresh_token") or "") if isinstance(d, dict) else ""
    except Exception:  # noqa: BLE001
        return ""


def grant_of(refresh_token: str) -> str:
    """A sign-in's mark from its own refresh token (a hash, never the token)."""
    return _rt_mark(refresh_token) if refresh_token else ""


def current_grant(home=None) -> str:
    """The stored sign-in's mark (a hash, never the token), or "" when none is stored."""
    rt = _stored_rt(Path(home) if home else _home())
    return _rt_mark(rt) if rt else ""


def mark_signed_out(home=None, grant=None) -> bool:
    """Google ended the stored sign-in (invalid_grant / revoked; a revoke ends the whole grant for the account, e.g. a
    Disconnect on another computer). Connections and Home then say "Reconnect" instead of "Connected" or an error
    code. Tied to that exact grant: a new Connect makes it void. Never stores or logs a token."""
    h = Path(home) if home else _home()
    rt = _stored_rt(h)
    if not rt:
        return False
    if grant is not None and grant != _rt_mark(rt):
        return False          # the failure was for an older sign-in; a Reconnect since then stays usable (r4 H1)
    try:
        _private_json(h / SIGNED_OUT, {"grant": _rt_mark(rt), "at": time.strftime("%Y-%m-%dT%H:%M:%S%z")})
        return True
    except Exception:  # noqa: BLE001
        return False


def signed_out(home=None) -> bool:
    """True when Google signed Qosha out of the sign-in stored now."""
    h = Path(home) if home else _home()
    try:
        m = json.loads((h / SIGNED_OUT).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return False
    rt = _stored_rt(h)
    return bool(rt) and isinstance(m, dict) and m.get("grant") == _rt_mark(rt)


def is_revoked_error(exc) -> bool:
    """Google's answer when a refresh token no longer works: invalid_grant ("Token has been expired or revoked")."""
    if type(exc).__name__ != "RefreshError":      # only the OAuth refresh's own error, never a resource error (r4 H5)
        return False
    args = getattr(exc, "args", ()) or ()
    info = args[1] if len(args) > 1 and isinstance(args[1], dict) else {}
    if info.get("error") == "invalid_grant":
        return True
    return str(args[0] if args else exc).strip().lower().startswith("invalid_grant")


def _signed_out_after_refusal(h: Path, email: str) -> None:
    """A refused sign-in was revoked at Google; for the same account that ends the stored grant too (r3 H3)."""
    rt = _stored_rt(h)
    if not rt or not email:
        return                                   # no verified identity: leave the stored sign-in alone (r4 H2)
    active = ""
    try:
        from urllib.parse import unquote
        for f in workspace_mcp_dir().glob("*.json"):
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                continue
            if isinstance(d, dict) and d.get("refresh_token") == rt:
                active = unquote(f.stem).lower()  # the account the ACTIVE grant belongs to
                break
    except Exception:  # noqa: BLE001
        active = ""
    if active and active == email.lower():
        mark_signed_out(h, grant=_rt_mark(rt))


def retire_write_grant(home=None) -> Dict[str, Any]:
    """Every Google sign-in file that can do more than read (made before 1.20.9) is revoked at Google and removed,
    each on its own (any account, the old writer's temp files too); when online Google itself says what each can do.
    A sign-in waiting in the skill's manual setup is dropped. Older daily backups lose their sign-in entries. The
    person is asked once to connect again. Never raises; never logs a token."""
    h = Path(home) if home else _home()
    done, retired, revoked = _revoked_marks(h), 0, True
    incomplete, asked = False, {}
    write_labelled = set()                 # grants any copy of which says it can do more than read (r4 H3)
    for f in _sign_in_files(h):
        try:
            d0 = json.loads(f.read_bytes().decode("utf-8")) if f.exists() else None
        except Exception:  # noqa: BLE001
            d0 = None
        if isinstance(d0, dict) and d0.get("refresh_token") and not _read_only(d0):
            write_labelled.add(str(d0["refresh_token"]))
    for f in _sign_in_files(h):
        try:
            if not f.exists():
                continue
            raw = f.read_bytes()
            try:
                data = json.loads(raw.decode("utf-8"))
            except Exception:
                data = None
            rt = str(data.get("refresh_token") or "") if isinstance(data, dict) else ""
            if rt and rt in asked:
                keep, missing = asked[rt]          # the same grant in another file: one decision for every copy (r2 H1, r3 H1)
            else:
                # Google is asked once per grant; the files' labels decide only when it can't answer (r5 H2)
                real = _granted_scopes(data) if rt else None
                if real is not None:
                    keep = all(x in _READ_SCOPE_OK for x in real)
                else:
                    keep = _read_only(data) and rt not in write_labelled
                have = real if real is not None else _scopes_of(data)
                missing = []
                if keep and not _complete(have):
                    keep = False                   # some boxes were left unticked (a 1.20.18 sign-in; final pass H2)
                    missing = [plain for s, plain in _PLAIN.items() if "https://www.googleapis.com/auth/" + s not in have]
                if rt:
                    asked[rt] = (keep, missing)
            if missing:
                incomplete = missing
            temp = _is_temp_name(f.name)
            if keep and not temp:
                continue
            if not keep:
                revoked = _revoke_once(data, done) and revoked
            try:
                if f.read_bytes() != raw:
                    continue                   # a new Connect wrote it meanwhile: not the one classified (verif. HIGH 10)
            except FileNotFoundError:
                continue
            f.unlink()
            retired += 0 if (keep and temp) else 1
        except Exception:
            revoked = False
    g = current_grant(h)
    if g and g in _REVOKED_SEEN:
        mark_signed_out(h, grant=g)       # Google answered invalid_grant for the kept sign-in: Reconnect (r4 H4)
    try:
        (h / "google_oauth_pending.json").unlink()
    except OSError:
        pass
    try:
        for z in sorted((h / "backups").glob("*.zip")) if (h / "backups").is_dir() else []:
            _zip_sign_ins(z, done)
    except Exception:
        pass
    try:
        _private_json(h / "google_revoked.json", {"marks": sorted(done)})
        if retired:
            _private_json(h / "google_reconnect.json", {
                "why": (unticked_message(Unticked(incomplete)).replace("Google isn\u2019t connected yet", "Google needs connecting once more")
                        if incomplete else
                        "Qosha now keeps a read-only Google sign-in; connect Google once more."), "revoked": revoked,
                "at": time.strftime("%Y-%m-%dT%H:%M:%S%z")})
    except Exception:
        pass
    if retired:
        return {"status": "retired", "revoked": revoked, "removed": retired}
    return {"status": "read-only" if (h / "google_token.json").exists() else "none"}


def retire_later(home=None, limit: float = 1200.0) -> None:
    """In the background: once no update is being applied (the updater compares the sign-in files around its health
    check), at most after `limit` seconds (GPT r1209 r2 HIGH 4)."""
    def go():
        t0 = time.monotonic()
        h = Path(home) if home else _home()
        while _update_running(h) and time.monotonic() - t0 < limit:
            time.sleep(10)
        retire_write_grant(h)
    threading.Thread(target=go, daemon=True, name="qosha-google-read-only").start()


def forget_all(home=None) -> Dict[str, Any]:
    """Disconnect: every Google sign-in this computer holds is revoked at Google (each distinct one) and removed."""
    h = Path(home) if home else _home()
    done, n = set(), 0
    for f in _sign_in_files(h) + [h / "google_oauth_pending.json"]:
        if not f.exists():
            continue
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            data = {}
        if isinstance(data, dict):
            _revoke_once(data, done)
        try:
            f.unlink()
            n += 1
        except OSError:
            pass
    return {"removed": n, "revoked": len(done)}


def workspace_mcp_dir() -> Path:
    return _home() / "google_workspace_mcp" / "credentials"


def _private_json(path, payload) -> None:
    """Writes the sign-in file readable only by this user: Qosha's own writer, the same behaviour as the engine's
    skills/productivity/google-workspace/scripts/_secure_storage.py write_private_json (JSON, indent 2, utf-8, mode 0600
    from creation, fsync, atomic replace). Qosha never calls the skill script's helpers for this (18 Nov 2026: the
    install's older Qosha-library copy of that script had no write_private_json, so Connect Google on a fresh Mac failed
    at the very end and the sign-in was lost; council GPT + Gemini: "own token writing directly")."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp.%d.%s" % (os.getpid(), secrets.token_hex(4)))
    created = False
    try:
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        created = True                   # only a temp file this call made is ever removed below
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(str(tmp), str(path))
    finally:
        if created:
            try:
                tmp.unlink()
            except OSError:
                pass


def _write_workspace_mcp(creds, email: str, granted) -> str:
    """The same sign-in in the Workspace MCP's own credential format (auth/credential_store.py, file per account)."""
    if not email:
        return "skipped: no account email"
    from urllib.parse import quote
    d = workspace_mcp_dir()
    d.mkdir(parents=True, exist_ok=True)
    data = {"token": creds.token, "refresh_token": creds.refresh_token, "token_uri": creds.token_uri,
            "client_id": creds.client_id, "client_secret": creds.client_secret, "scopes": list(granted or creds.scopes or []),
            "expiry": creds.expiry.isoformat() if getattr(creds, "expiry", None) else None}
    path = d / (quote(email, safe="@._-") + ".json")
    tmp = d / ("%s.tmp.%d.%s" % (path.name, os.getpid(), secrets.token_hex(4)))
    try:                                   # whole or not at all: a failed write leaves no token bytes (r2 H2)
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(str(tmp), str(path))
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise
    return "written"


PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Qosha</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#F5F4F0;color:#0B0B0B;
font-family:"Google Sans Flex","Helvetica Neue",Arial,sans-serif}.c{background:#fff;border:1px solid #E2E1DB;border-radius:20px;
padding:32px 40px;max-width:440px;box-shadow:0 1px 2px rgba(11,11,11,.04),0 8px 28px rgba(11,11,11,.05)}
h1{margin:0 0 8px;font-size:22px;font-weight:500;color:#0B3326}p{margin:0;color:#3E4B45;line-height:22px}
.bar{height:4px;width:48px;background:#B8955A;border-radius:2px;margin-bottom:16px}</style></head>
<body><div class="c"><div class="bar"></div><h1>%s</h1><p>%s</p></div></body></html>"""


FLOW_TTL = 600   # seconds a started sign-in waits for Google's answer (10 minutes)

# No domain lock by default (P0, 22 Nov 2026): any Google account may connect; Google's own test-user list for Qosha's
# app is the gate. A client that wants one Google Workspace only sets QOSHA_GOOGLE_DOMAIN: then hd= offers only that
# domain's accounts, the screens say which account to use, and an account from elsewhere is refused (_check_domain).
def account_domain() -> str:
    d = os.environ.get("QOSHA_GOOGLE_DOMAIN")
    return "" if d is None else d.strip().lstrip("@")


def account_line() -> str:
    d = account_domain()
    return ("Use your @%s Google account; other accounts are refused for now." % d) if d else ""


def waiting_line() -> str:
    """What Qosha shows while Google's sign-in waits in the browser (Ren 17 Nov 18:40: Renato's tab opened, but the
    app never told him it was waiting for him)."""
    d = account_domain()
    return ("Google\u2019s sign-in is open in your browser. Finish it there" + (", with your @%s account." % d if d else ".")
            + " If Google says the app isn\u2019t verified yet, press Continue. Then tick every box (or \u201cSelect all\u201d)"
            " and press Continue.")


# one registry per process, shared by every copy of this module (the chat tool and the Connections page load it under
# different names): one sign-in at a time on this computer
_REG = sys.modules.get("qosha_google_flow_registry")
if _REG is None:
    _REG = types.ModuleType("qosha_google_flow_registry")
    _REG.lock = threading.Lock()
    _REG.current = None
    sys.modules["qosha_google_flow_registry"] = _REG


def _now() -> float:
    return time.time()


class _GoogleFlow:
    """One sign-in: a loopback server on 127.0.0.1:<free port> served by a background thread until Google answers with
    this flow's state, the flow is cancelled, or FLOW_TTL passes."""

    def __init__(self, setup_mod, secret: Path, ttl: int):
        from google_auth_oauthlib.flow import Flow
        self.s = setup_mod
        self.id = "g" + secrets.token_urlsafe(18)
        self.started = _now()
        self.deadline = self.started + ttl
        self.status = "waiting"           # waiting | connected | failed | timeout | cancelled
        self.email = ""
        self.scopes: list = []
        self.workspace_mcp = ""
        self.error = ""
        self.plain = ""
        self.refused = 0                  # callbacks refused (wrong or missing state)
        self.browser_opened = None        # None: not tried; True/False: webbrowser.open's answer
        self._done = threading.Event()
        self._lock = threading.Lock()
        flow_ref = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _page(self, code: int, title: str, text: str):
                data = (PAGE % (html.escape(title), html.escape(text))).encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                flow_ref._callback(self)

        self.srv = HTTPServer(("127.0.0.1", 0), H)
        self.srv.timeout = 0.5
        self.redirect = "http://127.0.0.1:%d/" % self.srv.server_address[1]
        self.flow = Flow.from_client_secrets_file(
            str(secret), scopes=sorted(SIGNIN_SCOPES), redirect_uri=self.redirect,
            autogenerate_code_verifier=True)   # PKCE: the verifier stays in this process
        extra = {"hd": account_domain()} if account_domain() else {}
        self.url, self.state = self.flow.authorization_url(access_type="offline", prompt="consent", **extra)
        self.thread = threading.Thread(target=self._serve, daemon=True, name="qosha-google-signin")

    # ---- the loopback server -------------------------------------------------------------------------------------
    def _serve(self):
        try:
            while not self._done.is_set() and _now() < self.deadline:
                self.srv.handle_request()     # returns after 0.5 s without a request
        except Exception as exc:              # never leave the flow "waiting" if the server breaks
            self._finish("failed", "server_" + type(exc).__name__, "Google did not connect. Press Connect Google to try again.")
        finally:
            if self.status == "waiting":
                self._finish("timeout", "timeout", "The Google sign-in was not finished within 10 minutes. "
                             + (account_line() + " " if account_line() else "") + "Press Connect Google to try again.")
            try:
                self.srv.server_close()
            except Exception:
                pass

    def _finish(self, status: str, error: str = "", plain: str = "") -> bool:
        with self._lock:
            if self.status != "waiting":
                return False
            self.status, self.error, self.plain = status, error, plain
            self._done.set()
            return True

    def _callback(self, h):
        u = urlparse(h.path)
        q = parse_qs(u.query)
        if u.path != "/" or ("code" not in q and "error" not in q):
            h.send_response(404); h.send_header("Content-Length", "0"); h.end_headers(); return
        got_state = q.get("state", [""])[0]
        if self.status != "waiting":
            h._page(410, "Already finished", "This Google sign-in has already ended. Go back to Qosha.")
            return
        if not got_state or not hmac.compare_digest(got_state.encode(), self.state.encode()):
            # not the sign-in Qosha started (a stale tab, a forged address): refused, the real one keeps waiting
            self.refused += 1
            h._page(400, "Not connected", "This sign-in page is not the one Qosha started. Go back to Qosha and use the "
                                          "Google sign-in it opened (or press Connect Google again).")
            return
        if "error" in q:
            err = q.get("error", ["cancelled"])[0][:80]
            plain = ("The Google sign-in was cancelled." if err == "access_denied" else
                     "Google did not connect (Google said: %s)." % err)
            line = account_line()
            self._finish("failed", err, plain + (" " + line if line else "") + " Press Connect Google to try again.")
            h._page(200, "Not connected", plain + " Go back to Qosha and try again.")
            return
        try:
            self._store(q)
        except Unticked as exc:
            self._finish("failed", "unticked", unticked_message(exc))
            h._page(200, "Not connected", unticked_message(exc) + " Go back to Qosha.")
            return
        except Refused as exc:
            self._finish("failed", "refused", exc.plain)
            h._page(200, "Not connected", exc.plain + " Go back to Qosha.")
            return
        except Exception as exc:
            try:                         # best effort: a closed stderr must not stop the answer below
                print("qosha google sign-in: could not store the answer: %s: %s" % (type(exc).__name__, str(exc)[:200]),
                      file=sys.stderr, flush=True)
            except Exception:
                pass
            self._finish("failed", "token_" + type(exc).__name__,
                         "Google answered, but Qosha could not finish the sign-in (%s). Press Connect Google to try again."
                         % type(exc).__name__)
            h._page(200, "Not connected", "Qosha could not finish the sign-in. Go back to Qosha and try again.")
            return
        if not self._finish("connected", "", "Google is connected%s." % (" as " + self.email if self.email else "")):
            # stopped (Disconnect) while Google was answering: what was just written is taken back
            for f in [Path(self.s.TOKEN_PATH)] + ([workspace_mcp_dir() / (quote(self.email, safe="@._-") + ".json")]
                                                   if self.email else []):
                try:
                    f.unlink()
                except FileNotFoundError:
                    pass
            h._page(200, "Not connected", "This Google sign-in was stopped in Qosha. Go back to Qosha.")
            return
        h._page(200, "Connected", "Google is connected to Qosha%s. You can close this tab and go back to Qosha."
                % (" as " + self.email if self.email else ""))

    def _store(self, q):
        """Exchanges the code (with the PKCE verifier) and writes the skill's token and the Workspace tools' copy."""
        try:
            return _GoogleFlow._store_checked(self, q)
        except (Unticked, Refused) as exc:
            if getattr(exc, "revoked", False):
                try:
                    email = str(_id_claims(self.flow.credentials).get("email") or "")
                except Exception:  # noqa: BLE001
                    email = ""
                _signed_out_after_refusal(Path(self.s.TOKEN_PATH).parent, email)
            raise

    def _store_checked(self, q):
        s = self.s
        os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"
        with _quiet_oauth():
            self.flow.fetch_token(code=q["code"][0])
        creds = self.flow.credentials
        g = getattr(creds, "granted_scopes", None)
        # Google's token answer is what counts; the browser's callback is used only when the answer says nothing (H1)
        granted = list(g) if g is not None else q.get("scope", [""])[0].split()
        if g is None and not granted:
            with _quiet_oauth():
                asked = _tokeninfo_scopes(creds)       # neither answer named the permissions: Google is asked (r2 H6)
            if asked is None:
                with _quiet_oauth():
                    ok = _revoke_sure(creds)
                raise Refused("Qosha couldn\u2019t check what Google allowed, so nothing was kept. Press Connect Google "
                              "to try again.", ok)
            granted = asked
        if granted and not all(x in _READ_SCOPE_OK for x in granted):
            # Google gave more than reading: nothing is kept, the grant is taken back (1.20.9)
            with _quiet_oauth():
                ok = _revoke_sure(creds)
            raise Refused("Google gave Qosha more than reading, so nothing was kept. Press Connect Google to try "
                          "again.", ok)
        missing = [plain for s, plain in _PLAIN.items() if "https://www.googleapis.com/auth/" + s not in granted]
        if missing:
            # boxes left unticked on Google's page: not connected, nothing kept, the partial grant taken back (P0)
            with _quiet_oauth():
                ok = _revoke_sure(creds)
            raise Unticked(missing, ok)
        claims = _id_claims(creds)
        dom = account_domain()
        if dom and str(claims.get("hd") or "").lower() != dom.lower():
            # the opt-in Workspace: an account from elsewhere is refused (hd= only steers Google's chooser; review H1)
            with _quiet_oauth():
                ok = _revoke_sure(creds)
            raise Refused("That Google account isn\u2019t an @%s account, so nothing was kept. Press Connect Google "
                          "and choose your @%s account." % (dom, dom), ok)
        email = ""
        try:
            from googleapiclient.discovery import build
            email = build("gmail", "v1", credentials=creds).users().getProfile(userId="me").execute().get("emailAddress", "")
        except Exception:
            pass
        if not email and claims.get("email_verified") is not False:
            email = str(claims.get("email") or "")   # Gmail didn't answer: the account Google's sign-in names (review M1)
        if not email:
            # no account to file the Workspace tools' copy under: half a connection is none (final pass r2 H3)
            with _quiet_oauth():
                ok = _revoke_sure(creds)
            raise Refused("Google didn\u2019t say which account signed in, so nothing was kept. Press Connect Google "
                          "to try again.", ok)
        payload = s._normalize_authorized_user_payload(json.loads(creds.to_json()))
        if granted:
            payload["scopes"] = granted
        _private_json(s.TOKEN_PATH, payload)
        try:
            (Path(s.TOKEN_PATH).parent / SIGNED_OUT).unlink()      # a fresh sign-in: no longer signed out
        except OSError:
            pass
        self.email, self.scopes = email, granted
        try:
            self.workspace_mcp = _write_workspace_mcp(creds, email, granted)
        except Exception:
            # half a connection is none: the first copy goes, the grant is taken back (final pass H5)
            try:
                Path(s.TOKEN_PATH).unlink()
            except OSError:
                pass
            with _quiet_oauth():
                _revoke_sure(creds)
            raise

    # ---- what callers see ----------------------------------------------------------------------------------------
    def wait(self, timeout: float) -> bool:
        return self._done.wait(timeout)

    def snapshot(self) -> Dict[str, Any]:
        r = {"flow_id": self.id, "status": self.status, "plain": self.plain, "error": self.error,
             "seconds_left": max(0, int(self.deadline - _now())) if self.status == "waiting" else 0,
             "refused": self.refused, "browser_opened": self.browser_opened, "account_hint": account_line()}
        if self.status == "waiting":
            r["auth_url"] = self.url
            r["waiting_line"] = waiting_line()
        if self.status == "connected":
            r.update({"email": self.email, "scopes": self.scopes, "workspace_mcp": self.workspace_mcp})
        return r


def _prepare():
    """(setup module, client file) or a {"ok": False, ...} answer when this computer can't start a sign-in."""
    s = _skill_setup()
    secret = Path(s.CLIENT_SECRET_PATH)
    if not secret.exists():
        shipped = Path(__file__).resolve().parent.parent / "google_client.json"
        if shipped.is_file():
            shutil.copyfile(shipped, secret)
            os.chmod(secret, 0o600)
        else:
            return None, {"ok": False, "error": "no_client", "plain": (
                "Qosha has no Google sign-in app set up on this computer yet (google_client_secret.json). Ask the "
                "person for their Google OAuth client file (Desktop app), or follow the google-workspace skill's Step 2.")}
    # The Google packages are the engine's own (its "google" extra). The skill's own check wants exact older versions
    # and runs pip when they differ; a person's computer has no pip (Windows, a client Mac), so it is not used here.
    try:
        from google_auth_oauthlib.flow import Flow  # noqa: F401
        import googleapiclient.discovery  # noqa: F401
        import google.oauth2.credentials  # noqa: F401
    except Exception:
        return None, {"ok": False, "error": "no_google_packages", "plain": (
            "The Google parts of Qosha are missing on this computer, so the sign-in could not start. Reinstall Qosha.")}
    return (s, secret), None


def _open(flow: "_GoogleFlow") -> bool:
    try:
        flow.browser_opened = bool(webbrowser.open(flow.url))
    except Exception:
        flow.browser_opened = False
    return flow.browser_opened


def start_flow(open_browser: bool = False, ttl: int = FLOW_TTL) -> Dict[str, Any]:
    """Starts a sign-in (or returns the one already waiting: never two at once) and answers at once with Google's
    address. open_browser: also ask this computer to open it (a second path; on Windows it may open behind)."""
    with _REG.lock:
        cur = _REG.current
        if cur is not None and cur.status == "waiting" and _now() < cur.deadline:
            r = dict(cur.snapshot(), ok=True, reused=True)
        else:
            try:
                prep, problem = _prepare()
            except Exception as exc:
                return {"ok": False, "error": "no_skill", "plain": "Google's sign-in could not start on this computer "
                        "(%s). Reinstall Qosha." % type(exc).__name__}
            if problem:
                return problem
            cur = _GoogleFlow(prep[0], prep[1], ttl)
            _REG.current = cur
            cur.thread.start()
            r = dict(cur.snapshot(), ok=True, reused=False)
    if open_browser and r.get("status") == "waiting":
        r["browser_opened"] = _open(cur)
    return r


def _find(flow_id: str):
    cur = _REG.current
    if cur is not None and flow_id and hmac.compare_digest(str(flow_id).encode(), cur.id.encode()):
        return cur
    return None


def flow_status(flow_id: str) -> Dict[str, Any]:
    cur = _find(flow_id)
    if cur is None:
        return {"flow_id": flow_id, "status": "unknown", "plain": "This Google sign-in has expired. Press Connect Google again."}
    return cur.snapshot()


def open_in_browser(flow_id: str) -> Dict[str, Any]:
    """Opens the waiting flow's own address from this computer (the page asks when its own window.open was blocked)."""
    cur = _find(flow_id)
    if cur is None or cur.status != "waiting":
        return {"ok": False, "status": cur.status if cur else "unknown"}
    return {"ok": True, "browser_opened": _open(cur)}


def current_flow() -> Dict[str, Any]:
    cur = _REG.current
    return cur.snapshot() if cur is not None else {}


def cancel_flow(flow_id: str = "") -> bool:
    """Ends a waiting sign-in (Cancel, or Disconnect pressed meanwhile); its late answer is refused. With flow_id, only
    that sign-in is ended."""
    cur = _find(flow_id) if flow_id else _REG.current
    if cur is None or cur.status != "waiting":
        return False
    return cur._finish("cancelled", "cancelled", "The Google sign-in was stopped. Press Connect Google to start again.")


def waiting_signin():
    """For a "waiting for you" count (waiting.py): None, or the Google sign-in that waits for the person right now:
    {"kind": "google_signin", "flow_id", "since" (epoch s), "seconds_left", "line", "auth_url"}."""
    cur = _REG.current
    if cur is None or cur.status != "waiting" or _now() >= cur.deadline:
        return None
    return {"kind": "google_signin", "flow_id": cur.id, "since": cur.started, "seconds_left": int(cur.deadline - _now()),
            "line": waiting_line(), "auth_url": cur.url}


def connect(timeout: int = 300, open_browser: bool = True) -> Dict[str, Any]:
    """Starts a sign-in and WAITS for it (scripts and older callers). The page and the chat tool use start_flow()."""
    r = start_flow(open_browser=open_browser, ttl=max(timeout, 1) + 5)
    if not r.get("ok"):
        return r
    cur = _find(r["flow_id"])
    if cur is not None and not cur.wait(timeout):
        cur._finish("timeout", "timeout", "The Google sign-in was not finished in time.")
    snap = cur.snapshot() if cur is not None else {"status": "unknown"}
    if snap["status"] == "connected":
        return {"ok": True, "email": snap.get("email", ""), "scopes": snap.get("scopes", []),
                "browser_opened": snap.get("browser_opened"), "workspace_mcp": snap.get("workspace_mcp", ""),
                "plain": snap.get("plain") or "Google is connected."}
    return {"ok": False, "error": snap.get("error") or snap["status"], "auth_url": r.get("auth_url", ""),
            "plain": snap.get("plain") or "Google did not connect."}


SCHEMA = {"name": "qosha_connect_google",
          "description": ("Connect the person's Google account (Gmail, Calendar, Drive, Docs, Sheets, Contacts) to Qosha. "
                          "Call it once: it starts Google's sign-in, tries to open it in their browser and returns at once "
                          "with the sign-in link (auth_url). Always give the person that link as a clickable link (the "
                          "browser may open behind other windows), and say which Google account to use (account_hint). "
                          "When they say they are done, call it again with check=true to see whether Google is connected. "
                          "They copy nothing back. Use this instead of the google-workspace skill's manual "
                          "--auth-url/--auth-code steps. Afterwards use the google-workspace skill's google_api.py."),
          "parameters": {"type": "object", "properties": {
              "check": {"type": "boolean", "description": "true: only report whether the sign-in started earlier has finished."}},
              "required": []}}


def _handler(args, **kw) -> str:
    try:
        if isinstance(args, dict) and args.get("check"):
            cur = current_flow()
            if not cur:
                r = {"ok": False, "status": "none", "plain": "No Google sign-in was started. Call qosha_connect_google without check to start one."}
            else:
                r = dict(cur, ok=cur.get("status") == "connected")
                if cur.get("status") == "waiting":
                    r["plain"] = "Still waiting for the person to finish Google's sign-in. " + account_line()
        else:
            r = start_flow(open_browser=True)
            if r.get("ok") and r.get("status") == "waiting":
                r["plain"] = ("Google's sign-in has started. Give the person this link (it may also have opened in their "
                              "browser): %s\n%s%s When they are done, call qosha_connect_google with check=true."
                              % (r.get("auth_url"), (account_line() + " ") if account_line() else "", waiting_line()))
    except Exception as exc:
        r = {"ok": False, "error": type(exc).__name__, "plain": "Google could not be connected: %s" % exc}
    return json.dumps(r)


def register(ctx) -> None:
    retire_later()                             # an older write-capable sign-in never stays on disk (after any update)
    ctx.register_tool(name="qosha_connect_google", toolset="qosha", schema=SCHEMA, handler=_handler,
                      check_fn=lambda: True, description=SCHEMA["description"], emoji="🔗")


if __name__ == "__main__":
    import sys
    print(json.dumps(connect(open_browser="--no-browser" not in sys.argv), indent=2))
