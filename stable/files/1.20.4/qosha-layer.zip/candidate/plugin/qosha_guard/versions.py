"""File versions for the Qosha file viewer (night job 4, 2 Nov: files that behave like Claude's artifacts).

Each change to a file in the Qosha files folder becomes a version the person can look at and restore. Versions are
kept at $HERMES_HOME/qosha/file-versions/<key>/ (key = sha256 of the path below the files folder): index.json plus one
<n>.bin per version, at most KEEP versions of at most MAX_BYTES each.

They are recorded from three places, each a no-op when nothing changed (same sha256 as the newest version):
- the agent's tool hooks: before a write_file / patch runs (so the file as it was is kept) and after it ran;
- the viewer's info read (catches changes made any other way, e.g. a terminal step or Finder);
- a restore or rename by the person.

A convenience, not a control: the assistant runs as the same Mac user inside the same sandbox, so it is not protected
from the assistant. Paths are confined to the files folder and opened without following a link; a hook error never
blocks or changes a tool call.
"""
from __future__ import annotations

import errno
import hashlib
import json
import os
if os.name == "nt":   # Qosha on Windows: stand-in for folder descriptors (qosha_winfd.py in the plugin folder)
    import sys as _wsys, importlib.util as _wilu
    _wmod = _wsys.modules.get("qosha_winfd")
    if _wmod is None:
        _wspec = _wilu.spec_from_file_location("qosha_winfd", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "qosha_winfd.py"))
        _wmod = _wilu.module_from_spec(_wspec)
        _wsys.modules["qosha_winfd"] = _wmod
        _wspec.loader.exec_module(_wmod)
    os = _wmod.OS
import re
import secrets
import stat
import time
from pathlib import Path
from typing import Any, List, Optional

ROOT_ENV = "HERMES_DASHBOARD_FILES_ROOT"
MAX_BYTES = 5 * 1024 * 1024
KEEP = 50
_DIR_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0)
_FILE_FLAGS = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | getattr(os, "O_CLOEXEC", 0)
FILE_TOOLS = ("write_file", "patch")


def files_root() -> Optional[str]:
    raw = os.environ.get(ROOT_ENV, "").strip().rstrip("/")
    if not raw or not os.path.isabs(raw):
        return None
    return os.path.join(os.path.realpath(os.path.dirname(raw)), os.path.basename(raw))


def store_dir(home=None) -> Path:
    if home is None:
        try:
            from hermes_constants import get_hermes_home
            home = get_hermes_home()
        except Exception:
            home = os.environ.get("HERMES_HOME") or ""
        if not home:
            raise RuntimeError("no engine home")
    return Path(home) / "qosha" / "file-versions"


def rel_of(root: str, path: str) -> Optional[str]:
    """The path below the files folder, or None when it is not plainly inside it (no '..', '.', empty names)."""
    if not root or not isinstance(path, str) or not path.startswith(root + "/"):
        return None
    rel = path[len(root) + 1:]
    parts = rel.split("/")
    if not parts or any(p in ("", ".", "..") or "\x00" in p for p in parts):
        return None
    if any(p.startswith(".") for p in parts):   # hidden names are never shown, so never versioned
        return None
    return rel


def key_of(rel: str) -> str:
    return hashlib.sha256(rel.encode("utf-8", "surrogateescape")).hexdigest()[:32]


def read_confined(root: str, rel: str, limit: int = MAX_BYTES) -> Optional[bytes]:
    """The file's bytes, walked from the files folder without following any link; None if missing, not a regular
    file, or larger than `limit`."""
    parts = rel.split("/")
    fd = None
    try:
        fd = os.open(root, _DIR_FLAGS)
        for p in parts[:-1]:
            nfd = os.open(p, _DIR_FLAGS, dir_fd=fd)
            os.close(fd)
            fd = nfd
        ffd = os.open(parts[-1], _FILE_FLAGS, dir_fd=fd)
        try:
            st = os.fstat(ffd)
            if not stat.S_ISREG(st.st_mode) or st.st_size > limit:
                return None
            with os.fdopen(ffd, "rb") as fh:
                ffd = None
                data = fh.read(limit + 1)
            return data if len(data) <= limit else None
        finally:
            if ffd is not None:
                os.close(ffd)
    except OSError:
        return None
    finally:
        if fd is not None:
            os.close(fd)


INDEX_MAX = 1024 * 1024
LOCK_WAIT = 1.0


def _home_fd(home, create: bool) -> int:
    """A no-follow descriptor for <home>/qosha/file-versions (the home itself resolved once; every folder below it is
    opened without following a link, so a link planted there leads nowhere: GPT R-files1 HIGH 2)."""
    base = store_dir(home)
    fd = os.open(os.path.realpath(str(base.parent.parent)), _DIR_FLAGS)
    try:
        for name in (base.parent.name, base.name):
            if create:
                try:
                    os.mkdir(name, 0o700, dir_fd=fd)
                except FileExistsError:
                    pass
            nfd = os.open(name, _DIR_FLAGS, dir_fd=fd)
            os.close(fd)
            fd = nfd
        return fd
    except BaseException:
        os.close(fd)
        raise


def _key_fd(home, key: str, create: bool) -> Optional[int]:
    try:
        hfd = _home_fd(home, create)
    except OSError:
        return None
    try:
        if create:
            try:
                os.mkdir(key, 0o700, dir_fd=hfd)
            except FileExistsError:
                pass
        return os.open(key, _DIR_FLAGS, dir_fd=hfd)
    except OSError:
        return None
    finally:
        os.close(hfd)


def _read_at(dfd: int, name: str, limit: int) -> Optional[bytes]:
    """A regular file below the store folder, never through a link, never blocking on a pipe, at most `limit` bytes."""
    try:
        fd = os.open(name, _FILE_FLAGS, dir_fd=dfd)
    except OSError:
        return None
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_size > limit:
            return None
        with os.fdopen(fd, "rb") as fh:
            fd = None
            data = fh.read(limit + 1)
        return data if len(data) <= limit else None
    finally:
        if fd is not None:
            os.close(fd)


def _load_index(dfd: int) -> dict:
    raw = _read_at(dfd, "index.json", INDEX_MAX)
    try:
        idx = json.loads(raw.decode("utf-8")) if raw else None
        if isinstance(idx, dict) and isinstance(idx.get("versions"), list):
            return idx
    except (ValueError, UnicodeDecodeError):
        pass
    return {"versions": []}


def _write_at(dfd: int, name: str, data: bytes) -> None:
    tmp = ".tmp-" + secrets.token_hex(6)
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0), 0o600, dir_fd=dfd)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        os.replace(tmp, name, src_dir_fd=dfd, dst_dir_fd=dfd)   # replaces a link itself, never what it points to
    except BaseException:
        try:
            os.unlink(tmp, dir_fd=dfd)
        except OSError:
            pass
        raise


class _Locked:
    """One writer per file history at a time, across the dashboard and the agent (GPT R-files1 MEDIUM 4): flock on a
    lock file in its folder, waiting at most LOCK_WAIT seconds; without the lock nothing is written."""
    def __init__(self, dfd: int):
        self.dfd, self.fd = dfd, None

    def __enter__(self):
        fcntl = __import__("sys").modules["qosha_winfd"].fcntl if os.name == "nt" else __import__("fcntl")
        self.fd = os.open(".lock", os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK | getattr(os, "O_CLOEXEC", 0), 0o600, dir_fd=self.dfd)
        try:   # every failure closes the descriptor (GPT R-files2 MEDIUM)
            if not stat.S_ISREG(os.fstat(self.fd).st_mode):
                raise OSError("lock is not a file")
            end = time.monotonic() + LOCK_WAIT
            while True:
                try:
                    fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    return self
                except BlockingIOError:
                    if time.monotonic() > end:
                        raise
                    time.sleep(0.02)
        except BaseException:
            os.close(self.fd)
            self.fd = None
            raise

    def __exit__(self, *exc):
        if self.fd is not None:
            os.close(self.fd)   # closing releases the lock


def record(rel: str, data: bytes, source: str, home=None, session: str = "") -> Optional[dict]:
    """Keep `data` as the newest version of `rel` unless it equals the newest already kept."""
    if data is None or len(data) > MAX_BYTES:
        return None
    sha = hashlib.sha256(data).hexdigest()
    dfd = _key_fd(home, key_of(rel), True)
    if dfd is None:
        return None
    try:
        with _Locked(dfd):
            idx = _load_index(dfd)
            if idx.get("rel") not in (None, rel):
                return None
            vs = idx["versions"]
            if vs and vs[-1].get("sha256") == sha:
                return None
            n = (max(int(v.get("n", 0)) for v in vs) + 1) if vs else 1
            _write_at(dfd, "%d.bin" % n, data)
            entry = {"n": n, "sha256": sha, "size": len(data), "at": time.time(), "source": str(source)[:20]}
            if session and isinstance(session, str):
                entry["session"] = session[:100]
            vs.append(entry)
            while len(vs) > KEEP:
                old = vs.pop(0)
                try:
                    os.unlink("%d.bin" % int(old["n"]), dir_fd=dfd)
                except (OSError, KeyError, ValueError):
                    pass
            idx["rel"] = rel
            _write_at(dfd, "index.json", json.dumps(idx).encode())
            return entry
    finally:
        os.close(dfd)


def record_current(root: str, rel: str, source: str, home=None, session: str = "") -> Optional[dict]:
    data = read_confined(root, rel)
    return record(rel, data, source, home, session) if data is not None else None


def list_versions(rel: str, home=None) -> List[dict]:
    dfd = _key_fd(home, key_of(rel), False)
    if dfd is None:
        return []
    try:
        idx = _load_index(dfd)
    finally:
        os.close(dfd)
    if idx.get("rel") not in (None, rel):
        return []
    return [{k: v.get(k) for k in ("n", "sha256", "size", "at", "source")} for v in idx["versions"] if isinstance(v, dict)]


def read_version(rel: str, n: int, home=None) -> Optional[bytes]:
    """A kept version's bytes, only when they still match the hash recorded for them."""
    want = [v for v in list_versions(rel, home) if isinstance(v.get("n"), int) and v["n"] == int(n)]
    if not want:
        return None
    dfd = _key_fd(home, key_of(rel), False)
    if dfd is None:
        return None
    try:
        data = _read_at(dfd, "%d.bin" % int(n), MAX_BYTES)
    finally:
        os.close(dfd)
    if data is None or hashlib.sha256(data).hexdigest() != want[0].get("sha256"):
        return None
    return data


def move(old_rel: str, new_rel: str, home=None) -> None:
    """A rename keeps the history: the versions follow the file to its new name. An old history under the new name is
    first renamed aside and emptied through its own no-follow descriptor (never by pathname)."""
    try:
        hfd = _home_fd(home, False)
    except OSError:
        return
    try:
        src, dst = key_of(old_rel), key_of(new_rel)
        try:
            st = os.stat(src, dir_fd=hfd, follow_symlinks=False)
        except FileNotFoundError:
            return
        if not stat.S_ISDIR(st.st_mode):
            return
        try:
            aside = ".old-" + secrets.token_hex(6)
            os.rename(dst, aside, src_dir_fd=hfd, dst_dir_fd=hfd)
            try:
                afd = os.open(aside, _DIR_FLAGS, dir_fd=hfd)
            except OSError:
                os.unlink(aside, dir_fd=hfd)   # it was a link or a file: remove that entry itself
            else:
                try:
                    for e in os.listdir(afd):
                        try:
                            os.unlink(e, dir_fd=afd)
                        except OSError:
                            pass
                finally:
                    os.close(afd)
                os.rmdir(aside, dir_fd=hfd)
        except FileNotFoundError:
            pass
        os.rename(src, dst, src_dir_fd=hfd, dst_dir_fd=hfd)
        dfd = os.open(dst, _DIR_FLAGS, dir_fd=hfd)
        try:
            with _Locked(dfd):
                idx = _load_index(dfd)
                idx["rel"] = new_rel
                _write_at(dfd, "index.json", json.dumps(idx).encode())
        finally:
            os.close(dfd)
    finally:
        os.close(hfd)


# ---- agent hooks: observers only, they never block or change a tool call -----------------------------------------

_V4A = re.compile(r"^\*\*\* (?:Update|Add) File: (.+?)\s*$", re.M)


def _tool_paths(tool_name: str, args: Any) -> List[str]:
    if tool_name not in FILE_TOOLS or not isinstance(args, dict):
        return []
    out = []
    if isinstance(args.get("path"), str):
        out.append(args["path"])
    if tool_name == "patch" and isinstance(args.get("patch"), str):
        out += _V4A.findall(args["patch"])[:20]
    return out


def _resolve(path: str, task_id: str) -> str:
    try:   # the engine's own resolution for its file tools (cwd, ~)
        from tools.file_tools import _resolve_path_for_task
        return str(_resolve_path_for_task(path, task_id or "default"))
    except Exception:
        return os.path.abspath(os.path.expanduser(path))


def _observe(tool_name: str, args: Any, task_id: str, source: str, session: str = "") -> None:
    try:
        root = files_root()
        if not root:
            return
        for p in _tool_paths(tool_name, args):
            rel = rel_of(root, _resolve(p, task_id))
            if rel:
                record_current(root, rel, source, session=session if source == "qosha" else "")
    except Exception:
        pass


def pre_tool_call(tool_name: str = "", args: Any = None, task_id: str = "", **_: Any) -> None:
    _observe(tool_name, args, task_id, "before")
    return None


def post_tool_call(tool_name: str = "", args: Any = None, task_id: str = "", session_id: str = "", **_: Any) -> None:
    _observe(tool_name, args, task_id, "qosha", str(session_id or ""))
    return None


def recent(since: float, home=None, limit: int = 50, session: str = "") -> List[dict]:
    """Files the assistant's tools changed since `since` (seconds), newest first: the Chat page finds a file that was
    written by a relative path this way (the engine resolves it from the session's folder, which the page can't know)."""
    try:
        hfd = _home_fd(home, False)
    except OSError:
        return []
    out = []
    try:
        for name in os.listdir(hfd)[:5000]:
            if not re.fullmatch(r"[0-9a-f]{32}", name):
                continue
            try:
                dfd = os.open(name, _DIR_FLAGS, dir_fd=hfd)
            except OSError:
                continue
            try:
                idx = _load_index(dfd)
            finally:
                os.close(dfd)
            rel = idx.get("rel")
            if not isinstance(rel, str) or name != key_of(rel):
                continue
            ats = [float(v.get("at", 0)) for v in idx["versions"] if isinstance(v, dict) and v.get("source") == "qosha"
                   and (not session or v.get("session") == session)]   # only this conversation's changes (GPT R-files2)
            if ats and max(ats) >= since:
                out.append({"rel": rel, "at": max(ats)})
    finally:
        os.close(hfd)
    out.sort(key=lambda x: -x["at"])
    return out[:limit]
