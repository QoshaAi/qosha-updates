"""Gemini on the person's own Google subscription, through Google's own command-line tool (Ren, 17 Nov 2026:
"subscriptions, not API keys"; never by driving the Gemini web page).

Google ships two command-line tools that sign in with the person's Google account: Antigravity's `agy` and the
`gemini` CLI. This module finds one, asks it a question (text in, text out) and tells whether it is signed in. The
sign-in is the tool's own (Google's address, then the code Google shows is handed back to the tool); Qosha runs it
from its own "Connect your AI" panel (login_start / login_finish below) and reads no credential file.

How a question is asked (the same way as Qosha's Gemini seat on the Mac lab and the boxes):
- the question goes in on standard input, never on the command line (other programs can read command lines);
- no shell; fixed flags only; the tool's own sandbox flag on; never its "skip permissions" flag;
- the working folder is a fresh empty folder, removed afterwards, so the tool has no files to act on;
- a time limit ends the whole process group.
Used by: the "Connect your AI" panel (signin_api.py), Ask Gemini / the Gemini choice in Chat (assistants_api.py) and
the MCP tool ask_gemini (gemini_mcp.py), which lets Qosha itself ask Gemini inside a chat.

Which agy (contract AGYGUARD, 18 Nov 2026): Qosha's own copy, installed at the version Qosha tested
(<root>/engine/agy/agy, agy_pin.py), comes first; an agy the person installed elsewhere is used only when Qosha's own
is missing. Every agy call Qosha makes carries AGY_CLI_DISABLE_AUTO_UPDATE=true, so agy never replaces itself.
"""
from __future__ import annotations

import json
import logging
import os
import re
import secrets
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

TIMEOUT = 150
WIN = os.name == "nt"


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes"))


# Qosha's own agy, installed at the version Qosha tested (agy_pin.py; contract AGYGUARD, 18 Nov 2026), is used first.
# Every agy call Qosha makes carries this switch, so agy never replaces itself (the cloud boxes' setting).
NOUPDATE_ENV = {"AGY_CLI_DISABLE_AUTO_UPDATE": "true"}


def _env(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    env = dict(os.environ)
    env.update(NOUPDATE_ENV)
    if extra:
        env.update(extra)
    return env


_QUIET: Dict[str, str] = {}


def _quiet_dir() -> Optional[str]:
    """A private folder of openers that do nothing (open, xdg-open, noop; .cmd on Windows), made once per process."""
    d = _QUIET.get("d")
    if d and os.path.isdir(d):
        return d
    try:
        d = tempfile.mkdtemp(prefix="qosha-no-browser-")
        for n in (("open.cmd", "xdg-open.cmd", "noop.cmd") if WIN else ("open", "xdg-open", "noop")):
            f = os.path.join(d, n)
            with open(f, "w", encoding="ascii", newline="") as fh:
                fh.write("@exit /b 0\r\n" if WIN else "#!/bin/sh\nexit 0\n")
            if not WIN:
                os.chmod(f, 0o700)
        _QUIET["d"] = d
        return d
    except OSError:
        return None


def _quiet_env(extra: Optional[Dict[str, str]] = None) -> Optional[Dict[str, str]]:
    """For agy runs that must never open a browser (models, questions, checks): the openers on PATH and BROWSER do
    nothing (20 Nov 2026, Ren's sign-in pop-ups). None when that cannot be set up: the caller then starts nothing
    (fail closed). The sign-in launches keep _env(): opening Google's page is their job."""
    d = _quiet_dir()
    if not d:
        return None
    env = _env(extra)
    env["PATH"] = d + os.pathsep + env.get("PATH", "")
    env["BROWSER"] = os.path.join(d, "noop.cmd" if WIN else "noop")
    return env


def own_agy() -> Path:
    """<root>/engine/agy/agy(.exe): Qosha's own pinned copy (root = the home's parent)."""
    return _home().parent / "engine" / "agy" / ("agy.exe" if WIN else "agy")


def find() -> Tuple[str, str]:
    """("agy" | "gemini" | "", path): Google's command-line tool on this computer. Qosha's own pinned agy first; an agy
    the person installed elsewhere only when Qosha's own is missing."""
    try:
        own = own_agy()
        if own.is_file():
            return "agy", str(own)
    except Exception:
        pass
    local = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
    places = {"agy": [Path.home() / ".local" / "bin" / "agy", local / "agy" / "bin" / "agy.exe",   # Google's default place on Windows
                      local / "Programs" / "agy" / "agy.exe"],
              "gemini": [Path("/opt/homebrew/bin/gemini"), Path("/usr/local/bin/gemini")]}
    if WIN:   # the Windows installer puts Google's tool beside the engine: <install>\\engine\\gemini-cli\\gemini.cmd
        places["gemini"].insert(0, _home().parent / "engine" / "gemini-cli" / "gemini.cmd")
    for name in ("agy", "gemini"):
        hit = shutil.which(name) or next((str(p) for p in places[name] if p.is_file()), "")
        if hit:
            return name, hit
    return "", ""


def _kill(proc) -> None:
    try:
        if WIN:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True, timeout=10,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
        else:
            os.killpg(proc.pid, signal.SIGKILL)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def _drain(stream, sink: list) -> None:
    """Reads a pipe to its end into sink (so a full pipe never stalls the tool)."""
    try:
        while True:
            chunk = stream.read1(65536) if hasattr(stream, "read1") else stream.read(4096)
            if not chunk:
                break
            sink.append(chunk)
    except (OSError, ValueError):
        pass


def _envelope(out: str) -> dict:
    out = (out or "").strip()
    for cand in [out] + [ln for ln in reversed(out.splitlines()) if ln.strip().startswith("{")]:
        try:
            obj = json.loads(cand)
            if isinstance(obj, dict):
                return obj
        except Exception:
            continue
    return {}


def _spawn_kw() -> Dict[str, Any]:
    """Own process group (so a time limit ends the whole tree) and, on Windows, NO console window: Qosha's server has
    no visible console, and a console program started from it would otherwise get a window of its own."""
    if WIN:
        return {"creationflags": getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x200) | getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)}
    return {"start_new_session": True}


# What agy prints when it is NOT signed in and waits for a Google sign-in (seen 17 Nov 2026, agy 1.5.10, print mode:
# the Google address, "Waiting for authentication (timeout 60s)...", "Or, paste the authorization code here").
_SIGNED_OUT_MARKS = ("paste the authorization code", "waiting for authentication", "accounts.google.com",
                     "please sign in", "authentication required")


def _signin_seen(outs: list, errs: list) -> bool:
    """A sign-in or Google OAuth line in the error output, or in a standard-output line that is not a JSON event (the
    answer itself comes as JSON events, so an answer that mentions sign-ins is not mistaken for one)."""
    if any(m in b"".join(errs).decode("utf-8", "replace").lower() for m in _SIGNED_OUT_MARKS):
        return True
    for line in b"".join(outs).decode("utf-8", "replace").splitlines():
        t = line.strip().lower()
        if t and not t.startswith("{") and any(m in t for m in _SIGNED_OUT_MARKS):
            return True
    return False


# Text-only Gemini cannot use tools: agy's print mode cannot show a permission prompt, so it auto-denies a tool that
# needs one (an MCP server of the person's own Gemini set-up, seen 18 Nov 2026 23:20 MST with agy 1.5.11) and ends the
# turn with NO text, while still exiting 0 with {"status": "SUCCESS", "response": "", "denied_actions": [...]}.
# Qosha then asks once more with this note added, which got a plain answer in the same case.
RETRY_NOTE = ("\n\n(Note from Qosha: tools are not available in this text-only chat. Do not call any tool or command; "
              "answer in plain text from what you know, and say plainly if you cannot do what was asked without a "
              "tool.)")
RETRY_MIN_SECONDS = 30   # a retry needs at least this much of the time limit left
TOOL_DENIED_PLAIN = ("Gemini tried to use a tool, and Gemini in text-only chat can't use tools. Ask Qosha to do it, "
                     "or ask Gemini in other words.")

# Text-only means NO tools, enforced by agy itself, not only asked for (19 Nov 2026): since agy's headless runs start
# in Auto mode, which ran sandboxed commands (whoami, ls) and wrote files with no Qosha approval card. agy's
# --settings takes settings for that run only and never saves them, so the person's own ~/.gemini set-up is left as
# it is; the file lives in Qosha's home. Default mode (not Auto), strict tool permission, and every tool kind denied.
TEXT_ONLY_SETTINGS = {
    "agentMode": "",
    "toolPermission": "strict",
    "permissions": {"deny": ["command(*)", "read_file(*)", "write_file(*)", "mcp(*)", "read_url(*)", "execute_url(*)"]},
}


# ...and NO TOOLS OFFERED to the model at all (review round 2, #14, 19 Nov 2026): the deny groups above cannot deny web
# search (agy has no deny group for it), so a question could still go out as a search with the person's words. agy runs
# as a text-only custom agent instead: `tools: []` with `excludeDefaultComponents: true` leaves the model with no tool to
# call (proven with agy 1.5.11 on the Mac and the PC: a forced search is refused, the same agent with default tools
# searches). The agent file goes in the run's own fresh folder, under a name made for that run, so nothing in the
# person's own set-up can stand in for it; agy refuses to start when the named agent is missing (exit 1, nothing sent).
TEXT_ONLY_AGENT = """---
name: {name}
description: "Qosha's text-only Gemini: plain text answers, no tools."
tools: []
mainAgent: true
subagent: false
inheritMcp: false
excludeDefaultComponents: true
---

# Qosha text-only

Answer in plain text only, from what you know. You have no tools.
"""
TOOL_USED_PLAIN = ("Gemini tried to use a tool, which text-only chat does not allow, so Qosha stopped it and dropped that "
                   "answer. Ask Qosha to do it, or ask Gemini in other words.")
NEEDS_AGY_PLAIN = ("Gemini's text-only chat needs Google's newer tool (agy), which Qosha sets up. Ask Qosha to set it up.")
CANCELLED_PLAIN = "The question to Gemini was stopped."


def _text_only_agent(work: Path) -> str:
    """Writes the text-only agent into the run's folder (<work>/.agents/agents/) and returns its name for --agent."""
    name = "qosha-text-only-" + secrets.token_hex(6)
    d = Path(work) / ".agents" / "agents"
    d.mkdir(parents=True, exist_ok=True)
    (d / (name + ".md")).write_text(TEXT_ONLY_AGENT.format(name=name), encoding="utf-8")
    return name


def _text_only_settings() -> Path:
    """<home>/qosha/gemini-text-only.json, (re)written when missing or different. Raises OSError if it cannot be."""
    d = _home() / "qosha"
    d.mkdir(parents=True, exist_ok=True)
    p = d / "gemini-text-only.json"
    body = json.dumps(TEXT_ONLY_SETTINGS, indent=1)
    try:
        if p.read_text(encoding="utf-8") == body:
            return p
    except OSError:
        pass
    tmp = d / ("gemini-text-only.%s.tmp" % secrets.token_hex(4))
    tmp.write_text(body, encoding="utf-8")
    os.replace(tmp, p)
    return p


def ask(question: str, timeout: int = TIMEOUT, program: Optional[Tuple[str, str]] = None, cancel=None) -> Dict[str, Any]:
    """{"ok": True, "answer", "tool"} or {"ok": False, "error", "plain"}. `program` ("agy", path) asks through that
    program instead of find()'s (the daily canary checks a new Google release through this exact path). `cancel`
    (anything with is_set(), e.g. the council's stop signal) is checked before each run and while a run is going: once
    it is set nothing more is sent and a running agy is ended (review round 2, #13).
    When Gemini tried a tool and was turned away (so it gave no text), it is asked ONCE more with RETRY_NOTE, within
    the same time limit; if that is turned away too, the error is "tool_denied" with plain words."""
    name, path = program if program else find()
    if not name:
        return {"ok": False, "error": "not_installed", "plain": "Google's command-line tool (agy or gemini) is not installed on this computer."}
    if name != "agy":
        # only agy's text-only mode is enforced (no tools offered, every tool kind denied); the older `gemini` tool's
        # plan mode still lets the model search the web, and Google turns that tool away for personal plans anyway
        # (17 Nov 2026: IneligibleTier). Nothing is sent through it (review round 2, #14).
        return {"ok": False, "error": "tool_refused", "plain": NEEDS_AGY_PLAIN}
    question = str(question or "").strip()
    if not question:
        return {"ok": False, "error": "empty", "plain": "There was nothing to ask."}
    if _stopped(cancel):
        return {"ok": False, "error": "cancelled", "plain": CANCELLED_PLAIN}
    if _access_gate():                  # access first: with access ended not even agy's model list is asked (1.20.1)
        return {"ok": False, "error": "access_ended", "plain": "Your access to Qosha has ended, so Qosha can't answer."}
    u = _usable(path)
    if not u.get("ok"):
        return {"ok": False, "error": u["error"], "plain": u["plain"]}
    started = time.monotonic()
    r = _ask_once(name, path, question, timeout, cancel)
    # the retry only where both runs carry the enforced no-tools block (agy, TEXT_ONLY_SETTINGS): a tool the person
    # allowed in their own set-up could otherwise act on the first run and again on the retry (review 19 Nov, HIGH #7)
    if r.get("error") != "tool_denied":
        return r
    left = int(timeout - (time.monotonic() - started))
    if left >= RETRY_MIN_SECONDS and not _stopped(cancel):
        u = _usable(path)
        if not u.get("ok"):
            return {"ok": False, "error": u["error"], "plain": u["plain"]}     # the reason the retry sat out
        again = _ask_once(name, path, question + RETRY_NOTE, left, cancel)
        if again.get("error") != "tool_denied":
            return again
    return r


def _stopped(cancel) -> bool:
    try:
        return bool(cancel is not None and cancel.is_set())
    except Exception:
        return True      # a stop signal that cannot be read counts as set (nothing more is sent)


def _tool_step(line) -> Optional[str]:
    """One stream-json line: the tool's name ("tool" when it has none) if the line is a tool step, else None. Only a
    whole event counts (review round 3: the bytes "tool_name" inside an answer are an answer, not a tool)."""
    try:
        ev = json.loads(line)
    except (ValueError, UnicodeDecodeError):
        return None
    su = ev.get("step_update") if isinstance(ev, dict) else None
    if isinstance(su, dict) and su.get("step_type") == "tool":
        return str(su.get("tool_name") or "tool")
    return None


class _ToolWatch:
    """Reads agy's stream-json as it arrives, whole lines only (a partial line waits for the rest)."""

    def __init__(self, chunks: list):
        self.chunks, self.used, self.buf, self.tools = chunks, 0, b"", []

    def seen(self) -> bool:
        n = len(self.chunks)            # the reader thread only appends
        if n > self.used:
            self.buf += b"".join(self.chunks[self.used:n])
            self.used = n
            *lines, self.buf = self.buf.split(b"\n")
            for ln in lines:
                t = _tool_step(ln.strip()) if ln.strip().startswith(b"{") else None
                if t:
                    self.tools.append(t)
        return bool(self.tools)


def _result(out: str) -> Tuple[dict, list]:
    """agy's stream-json, one event per line: (the result object, the tools any step used). Falls back to a single
    JSON object (the older --output-format json shape)."""
    result, tools = None, []
    for line in (out or "").splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        t = _tool_step(line)
        if t:
            tools.append(t)
            continue
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        if isinstance(ev, dict) and ev.get("event") == "result" and isinstance(ev.get("result"), dict):
            result = ev["result"]
    if result is None:
        result = _envelope(out)
    return result, tools


def _write_stdin(proc, data: bytes) -> None:
    """Hands the question to agy in its own thread, so a full pipe never holds up Stop or the time limit (the run is
    ended instead, which also ends this write)."""
    try:
        proc.stdin.write(data)
        proc.stdin.close()
    except (OSError, ValueError):
        pass


def _ask_once(name: str, path: str, question: str, timeout: int, cancel=None) -> Dict[str, Any]:
    """One run of agy: the result dict of ask(), with error "tool_denied" when a tool was turned away, "tool_used" when
    a tool step ran anyway (the answer is dropped), "cancelled" when the stop signal came."""
    if _access_gate():                  # CONTRACT-ACCESS: no Gemini request while access has ended (every attempt)
        return {"ok": False, "error": "access_ended", "plain": "Your access to Qosha has ended, so Qosha can't answer."}
    if name != "agy":
        return {"ok": False, "error": "tool_refused", "plain": NEEDS_AGY_PLAIN}
    try:
        block = str(_text_only_settings())
    except OSError as exc:
        # never run agy without the block (fail closed)
        return {"ok": False, "error": "start", "plain": "Qosha could not prepare Gemini's no-tools setting (%s)."
                % type(exc).__name__}
    qenv = _quiet_env()
    if qenv is None:                    # never run agy where it could open a browser (fail closed)
        return {"ok": False, "error": "unsafe_start", "plain": "Gemini couldn't start safely."}
    work = tempfile.mkdtemp(prefix="qosha-gemini-")
    tool_seen = False
    try:
        try:
            agent = _text_only_agent(Path(work))
        except OSError as exc:
            return {"ok": False, "error": "start", "plain": "Qosha could not prepare Gemini's no-tools setting (%s)."
                    % type(exc).__name__}
        argv = [path, "--output-format", "stream-json", "--print-timeout", "120s", "--sandbox", "--settings", block,
                "--agent", agent, "--disable-slash-commands"]
        if _stopped(cancel):
            return {"ok": False, "error": "cancelled", "plain": CANCELLED_PLAIN}
        proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                cwd=work, shell=False, env=qenv, **_spawn_kw())
        outs: list = []
        errs: list = []
        readers = [threading.Thread(target=_drain, args=(proc.stdout, outs), daemon=True),
                   threading.Thread(target=_drain, args=(proc.stderr, errs), daemon=True)]
        for t in readers:
            t.start()
        # Stop that came while agy was starting: end it before the question is handed over (review round 3, #13)
        if _stopped(cancel):
            _kill(proc)
            return {"ok": False, "error": "cancelled", "plain": CANCELLED_PLAIN}
        threading.Thread(target=_write_stdin, args=(proc, question.encode("utf-8")), daemon=True).start()
        watch = _ToolWatch(outs)
        end = time.monotonic() + timeout
        signed_out = False
        while proc.poll() is None:
            if time.monotonic() > end:
                _kill(proc)
                return {"ok": False, "error": "timeout", "plain": "Gemini took too long to answer."}
            if _stopped(cancel):
                _kill(proc)
                return {"ok": False, "error": "cancelled", "plain": CANCELLED_PLAIN}
            # a tool step means the no-tools block failed: end the run at once, keep nothing (a backstop only; the
            # block above is what keeps tools from running). Whole events only (review round 3).
            if watch.seen():
                tool_seen = True
                _kill(proc)
                break
            # not signed in: the tool sits waiting for a Google sign-in (60 s, and it may open a browser tab);
            # stop it at once and say so, instead of a long wait for nothing (those lines go to its error output;
            # the answer itself goes to standard output, so an answer that mentions sign-ins is not mistaken for it)
            if _signin_seen(outs, errs):
                signed_out = True
                _kill(proc)
                break
            time.sleep(0.2)
        for t in readers:
            t.join(5)
        out = b"".join(outs).decode("utf-8", "replace")
        err = b"".join(errs).decode("utf-8", "replace")
        if signed_out:
            return {"ok": False, "error": "signed_out", "plain": "Gemini is not signed in on this computer yet."}
    except OSError as exc:
        return {"ok": False, "error": "start", "plain": "Google's command-line tool could not start (%s)." % type(exc).__name__}
    finally:
        shutil.rmtree(work, ignore_errors=True)
    env, tools = _result(out)
    if tool_seen or tools:
        logging.getLogger("qosha.gemini_cli").warning("text-only Gemini ran a tool (%s); the answer was dropped",
                                                      ",".join(sorted(set(tools)))[:120] or "tool")
        return {"ok": False, "error": "tool_used", "plain": TOOL_USED_PLAIN}
    if _stopped(cancel):
        return {"ok": False, "error": "cancelled", "plain": CANCELLED_PLAIN}
    text = str(env.get("response") or env.get("result") or "").strip()
    low = ((err or "") + " " + (out or "")).lower()
    if not text or env.get("is_error") or env.get("error"):
        # Google refusing the TOOL (seen 17 Nov with gemini-cli 0.68.0: the sign-in is fine, the client is turned away)
        # is not "signed out": checked before the sign-in words, because Google's message also says "auth".
        if "ineligibletier" in low.replace(" ", "").replace("_", "") or "no longer supported" in low:
            return {"ok": False, "error": "tool_refused", "plain": (
                "Google no longer lets this tool use a personal Gemini plan. Qosha needs Google's newer tool; "
                "ask Qosha to set it up.")}
        # agy did not find Qosha's text-only agent (an older agy, or the folder was changed): nothing was sent
        if "unknown agent" in str(env.get("error") or "").lower():
            return {"ok": False, "error": "start", "plain": "Qosha could not start Gemini's text-only mode on this computer."}
        # Gemini tried a tool that the print mode turned away (checked before the sign-in words: agy's own note about
        # it names "permission" and "settings", and could one day name an auth word)
        if not text and env.get("denied_actions"):
            return {"ok": False, "error": "tool_denied", "plain": TOOL_DENIED_PLAIN}
        if any(w in low for w in ("sign in", "signin", "log in", "login", "unauthenticated", "not authenticated", "auth", "credential")):
            return {"ok": False, "error": "signed_out", "plain": "Gemini is not signed in on this computer yet."}
        return {"ok": False, "error": "no_answer", "plain": "Gemini gave no answer just now."}
    return {"ok": True, "answer": text[:20000], "tool": name}


def _marker() -> Path:
    d = _home() / "qosha"
    d.mkdir(parents=True, exist_ok=True)
    return d / "gemini_cli.json"


def connected() -> bool:
    """What the last check found (no call to Google here)."""
    try:
        return json.loads(_marker().read_text(encoding="utf-8")).get("ok") is True and bool(find()[0])
    except Exception:
        return False


_ROW = re.compile(rb"^gemini-[a-z0-9.\-]+\t\S", re.M)


def _usable(path: str) -> Dict[str, Any]:
    """agy only: {"ok": True} when `agy models` (which never opens a sign-in) lists a usable Gemini model now; else
    {"ok": False, "error": "signed_out" | "unreadable", "plain"}. Nothing is asked of Gemini without it (20 Nov 2026,
    council QA: a question asked while agy cannot answer must never reach agy; agy 1.5.10 opened Google's sign-in for
    one)."""
    if _access_gate():                  # access right before every agy launch (review 20 Nov: the retry's listing too)
        return {"ok": False, "error": "access_ended", "plain": "Your access to Qosha has ended, so Qosha can't answer."}
    qenv = _quiet_env()
    if qenv is None:
        return {"ok": False, "error": "unsafe_start", "plain": "Gemini couldn't start safely."}
    try:
        r = subprocess.run([path, "models"], stdin=subprocess.DEVNULL, capture_output=True, timeout=30, shell=False,
                           env=qenv, **_spawn_kw())
    except Exception:
        return {"ok": False, "error": "unreadable", "plain": "Qosha could not reach Google's Gemini tool just now."}
    text = (r.stdout + r.stderr).decode("utf-8", "replace").lower()
    if "please sign in" in text or "not logged in" in text or "not signed in" in text:
        return {"ok": False, "error": "signed_out", "plain": "Gemini is not signed in on this computer yet."}
    if r.returncode != 0:
        return {"ok": False, "error": "unreadable", "plain": "Qosha could not reach Google's Gemini tool just now."}
    if not _ROW.search(r.stdout or b""):       # an answer without any model: not proof of a sign-out
        return {"ok": False, "error": "unreadable", "plain": "Qosha could not read Gemini's models just now."}
    return {"ok": True}


def _signed_out_quick(path: str) -> bool:
    """Kept for callers of the earlier name: True when Gemini cannot be asked now."""
    return not _usable(path).get("ok")


def check() -> Dict[str, Any]:
    """One very short question through the tool: it answers only when the person's Google sign-in works."""
    name, path = find()
    ended = _access_gate()              # access first: with access ended nothing is asked of agy, no marker is written
    u = _usable(path) if name == "agy" and not ended else {"ok": True}
    if ended:
        r = {"ok": False, "error": "access_ended", "plain": "Your access to Qosha has ended, so Qosha can't answer."}
    elif not u.get("ok"):
        r = {"ok": False, "error": u["error"], "plain": u["plain"]}      # no probe question without a usable listing
    else:
        r = ask("Reply with the single word: OK", timeout=90) if name else {"ok": False, "error": "not_installed",
                                                                             "plain": "Google's command-line tool is not installed yet."}
    if r.get("error") != "access_ended":     # an access refusal says nothing about the Gemini sign-in (review r2)
        try:
            _marker().write_text(json.dumps({"ok": bool(r.get("ok")), "tool": name, "at": time.time()}), encoding="utf-8")
        except OSError:
            pass
    return {"ok": bool(r.get("ok")), "tool": name, "error": r.get("error") or "", "plain": r.get("plain") or ""}


def forget() -> None:
    """Disconnect in Qosha: Qosha stops using the tool (the tool's own Google sign-in is the person's and stays)."""
    try:
        _marker().write_text(json.dumps({"ok": False, "at": time.time()}), encoding="utf-8")
    except OSError:
        pass


# ---- Sign-in inside Qosha's own "Connect your AI" panel (17 Nov 2026: Renato, Windows, copied Google's code but had
# no place to paste it: the old way opened the tool in a console window that could sit behind everything).
# Google's supported route is agy's own ACP terminal sign-in, `agy acp --login` (agy 1.5.10 `agy help acp`: "Log in
# with Google interactively, then exit (ACP terminal auth)"). It prints one Google address, waits for one line (the code
# Google shows, or the full address of the page you land on) and exits: 0 when Google accepted it and the sign-in is
# saved where agy keeps it (Apple Keychain, Windows Credential Manager), 1 otherwise. It reads ordinary pipes, so no
# terminal emulation is needed on either system. Qosha only relays: the address to the page, the code to the tool.
# Nothing here reads or writes the tool's stored sign-in itself.
LOGIN_TTL = 600            # a sign-in waits 10 minutes for the code, then ends by itself
_LOGINS: Dict[str, Dict[str, Any]] = {}
_LLOCK = threading.Lock()
# One sign-in at a time (20 Nov 2026, Ren: "fix the antigravity issue"): every `agy acp --login` opens Google's page in
# the browser by itself, so a second start would put another sign-in in front of the person and end the first one,
# whose page then answers with "Invalid code verifier". Starts are serialized, and a sign-in that is still waiting is
# handed back instead of being replaced.
_START_LOCK = threading.Lock()


# 20 Nov 2026 (Ren's Antigravity prompts: a TEST copy's panel opened Google's sign-in on the person's own desktop with
# their own agy): a sign-in starts only from a person's press, in the Qosha installed on this computer, with Qosha's
# own agy. The panel asks for a one-time press token inside a real click; the server takes each token once.
PRESS_TTL = 120
_PRESSES: Dict[str, float] = {}
_PLOCK = threading.Lock()
NOT_INSTALLED_HOME = {"ok": False, "error": "not_installed_home",
                      "plain": "Gemini sign-in opens only from the Qosha installed on this computer."}
NO_PRESS = {"ok": False, "error": "no_press", "plain": "Press Sign in with Gemini to start Google\u2019s sign-in."}


def press_new() -> str:
    """A one-time token for one press of a sign-in button (kept in memory, PRESS_TTL seconds)."""
    t = secrets.token_urlsafe(24)
    now = time.time()
    with _PLOCK:
        for k in [k for k, at in _PRESSES.items() if now - at > PRESS_TTL]:
            _PRESSES.pop(k, None)
        _PRESSES[t] = now
    return t


def _press_take(press) -> bool:
    """True once for a token press_new() gave out less than PRESS_TTL seconds ago; the token is used up."""
    if not isinstance(press, str) or not press:
        return False
    with _PLOCK:
        at = _PRESSES.pop(press, None)
    return at is not None and time.time() - at <= PRESS_TTL


def _installed_home() -> Optional[Path]:
    """The home of the Qosha installed for this person: macOS ~/Library/Application Support/Qosha/home, Windows
    %LOCALAPPDATA%\\Qosha\\home; None elsewhere."""
    if WIN:
        base = os.environ.get("LOCALAPPDATA")
        return (Path(base) if base else Path.home() / "AppData" / "Local") / "Qosha" / "home"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Qosha" / "home"
    return None


def installed_agy() -> Optional[str]:
    """Qosha's own agy, only in the Qosha installed for this person: the home is exactly _installed_home() and holds
    the install layout (<root>/layer/setup_home.py, <root>/engine/, the own agy). None in a test copy (even one with the
    same layout elsewhere), a temporary home or a cloud box."""
    try:
        h = _home()
        want = _installed_home()
        if want is None or h.resolve() != want.resolve():
            return None
        r = h.parent
        a = own_agy()
        if h.name == "home" and (r / "layer" / "setup_home.py").is_file() and (r / "engine").is_dir() and a.is_file():
            return str(a)
    except OSError:
        pass
    return None


def _signin_gate(press) -> Tuple[Optional[str], Optional[Dict[str, Any]]]:
    """(own agy path, None) when a sign-in may start now; (None, the refusal) otherwise. The installed check comes
    first, so a test copy never uses up a token; access before both."""
    if _access_gate():
        return None, {"ok": False, "error": "access_ended", "plain": "Your access to Qosha has ended."}
    path = installed_agy()
    if not path:
        return None, dict(NOT_INSTALLED_HOME)
    if not _press_take(press):
        return None, dict(NO_PRESS)
    return path, None
_TERMINAL = {"at": 0.0}       # when a Terminal sign-in ("Sign in in a Terminal window") was last opened
_ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)|\x1b[()][A-Za-z0-9]|\x1b[=>]")
_GURL = re.compile(r"https://accounts\.google\.com/[^\s\"'<>]+")
_CODE_OK = re.compile(r"^[\x21-\x7e]{4,4096}$")    # one line of visible characters: a code or the landing address
_PROMPT = ("authorization code", "press enter")


def _ltext(sess: Dict[str, Any]) -> str:
    return _ANSI.sub("", b"".join(sess["out"]).decode("utf-8", "replace")).replace("\r", "")


def _lend(sess: Dict[str, Any], why: str) -> None:
    """Ends one sign-in cleanly: the tool's input is closed (agy: "login cancelled", exit 1); killed if it lingers."""
    sess.setdefault("ended", why)
    t = sess.get("timer")
    if t is not None:
        t.cancel()
    p = sess["proc"]
    if p.poll() is None:
        try:
            p.stdin.close()
        except Exception:
            pass
        try:
            p.wait(5)
        except Exception:
            _kill(p)
            try:
                p.wait(5)
            except Exception:
                pass
    r = sess.get("reader")
    if r is not None:
        r.join(2)
    shutil.rmtree(sess.get("work") or "", ignore_errors=True)


def _lexpire(sid: str) -> None:
    with _LLOCK:
        sess = _LOGINS.pop(sid, None)
    if sess:
        _lend(sess, "expired")


def login_cancel(sid: Optional[str] = None) -> Dict[str, Any]:
    """Ends one sign-in (or every one when no id is given; that also forgets a Terminal sign-in). A sign-in shared by
    two panels ends only when both have let go of it."""
    with _LLOCK:
        if sid is None:
            _TERMINAL["at"] = 0.0
        else:
            s = _LOGINS.get(sid)
            if s is not None and s.get("users", 1) > 1:
                s["users"] -= 1
                return {"ok": True, "ended": 0}
        gone = [_LOGINS.pop(k) for k in list(_LOGINS) if sid is None or k == sid]
    for sess in gone:
        _lend(sess, "cancelled")
    return {"ok": True, "ended": len(gone)}


def login_active() -> int:
    with _LLOCK:
        return sum(1 for s in _LOGINS.values() if s["proc"].poll() is None)


def _login_attempt(path: str) -> Dict[str, Any]:
    """Starts `agy acp --login` once over plain pipes (its output and errors read together in the background; its
    input is a pipe, and closing it ends the sign-in). -> the session dict; OSError when it cannot start."""
    work = tempfile.mkdtemp(prefix="qosha-gemini-login-")
    try:
        proc = subprocess.Popen([path, "acp", "--login"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, cwd=work, shell=False, env=_env(), **_spawn_kw())
    except OSError:
        shutil.rmtree(work, ignore_errors=True)
        raise
    sess: Dict[str, Any] = {"proc": proc, "out": [], "work": work, "at": time.time()}
    sess["reader"] = threading.Thread(target=_drain, args=(proc.stdout, sess["out"]), daemon=True)
    sess["reader"].start()
    return sess


def login_start(wait: float = 30.0, press: str = "") -> Dict[str, Any]:
    """Starts Google's sign-in in the background and returns the address to open: {"ok", "id", "url", "expires_in"}.
    No window of any kind is opened. Only for a person's press (a press token) in the installed Qosha, with its own agy."""
    path, refused = _signin_gate(press)
    if refused:
        return refused
    name = "agy"
    if not _START_LOCK.acquire(blocking=False):   # never queued: it would start after its panel may have closed
        return {"ok": False, "error": "busy", "plain": "A Gemini sign-in is starting already; wait a moment."}
    try:
        return _login_start_locked(name, path, wait)
    finally:
        _START_LOCK.release()


def _login_start_locked(name: str, path: str, wait: float) -> Dict[str, Any]:
    if time.time() - _TERMINAL["at"] < LOGIN_TTL:
        return {"ok": False, "error": "terminal_waiting", "plain": "A Gemini sign-in is open in a Terminal window: "
                "finish it there, or press Cancel to start one here instead."}
    with _LLOCK:
        alive = [(k, s) for k, s in _LOGINS.items() if s["proc"].poll() is None]
        ended = [k for k, s in _LOGINS.items() if s["proc"].poll() is not None and not s.get("finishing")]
        gone = [_LOGINS.pop(k) for k in ended]
        finishing = [k for k, s in alive if s.get("finishing")]
        waiting = [(k, s) for k, s in alive if s.get("url") and not s.get("finishing")]
        if waiting:
            waiting[0][1]["users"] = waiting[0][1].get("users", 1) + 1
    for sess in gone:
        _lend(sess, "ended")
    if finishing:
        return {"ok": False, "error": "finishing", "plain": "Google is checking the code you pasted; wait a moment."}
    if waiting:
        sid, sess = waiting[0]
        left = max(1, int(LOGIN_TTL - (time.time() - sess.get("at", time.time()))))
        return {"ok": True, "id": sid, "url": sess["url"], "expires_in": left, "tool": name, "reused": True}
    return _login_start_new(name, path, wait)


def _login_start_new(name: str, path: str, wait: float) -> Dict[str, Any]:
    end = time.time() + wait
    try:
        sess = _login_attempt(path)
    except OSError as exc:
        return {"ok": False, "error": "start", "plain": "Google's sign-in could not start (%s)." % type(exc).__name__}
    url = ""
    while time.time() < end:
        txt = _ltext(sess)
        m = _GURL.search(txt)
        if m and any(k in txt.lower() for k in _PROMPT):
            url = m.group(0)
            break
        if sess["proc"].poll() is not None:
            break                        # it ended before asking for a code: no sign-in to finish
        time.sleep(0.1)
    if not url or sess["proc"].poll() is not None:
        rc = sess["proc"].poll()
        detail = "rc=%s out=%r" % (rc, _ltext(sess)[-160:])
        _lend(sess, "no_url")
        return {"ok": False, "error": "no_url", "plain": "Google's sign-in did not start.", "detail": detail}
    sid = secrets.token_urlsafe(12)
    sess["url"] = url
    sess["users"] = 1
    sess["timer"] = threading.Timer(LOGIN_TTL, _lexpire, args=(sid,))
    sess["timer"].daemon = True
    sess["timer"].start()
    with _LLOCK:
        _LOGINS[sid] = sess
    return {"ok": True, "id": sid, "url": url, "expires_in": LOGIN_TTL, "tool": name}


def login_finish(sid: str, code: str, wait: float = 90.0) -> Dict[str, Any]:
    """Hands the code the person copied from Google to the waiting tool, then checks that Gemini answers.
    {"ok": True, "connected": True} or {"ok": False, "error", "plain"} (plain words for the panel)."""
    code = str(code or "").strip()
    again = "Press “Open Google’s sign-in” again, sign in, and paste the new code."
    with _LLOCK:
        sess = _LOGINS.get(str(sid or ""))
        if sess is not None and _CODE_OK.match(code):
            if sess.get("finishing"):
                return {"ok": False, "error": "finishing", "plain": "Google is already checking a code for this sign-in."}
            sess["finishing"] = True       # stays registered: no other sign-in may start while Google checks the code
    if sess is None:
        return {"ok": False, "error": "expired", "plain": "This sign-in has ended (it waits 10 minutes). " + again}
    if not _CODE_OK.match(code):   # the sign-in stays open: the person can paste again
        return {"ok": False, "error": "bad_format", "plain": "That doesn’t look like Google’s code. Copy the whole code Google shows (one line) and paste it here."}
    try:
        return _finish(sess, code, wait, again)
    finally:
        with _LLOCK:
            for k in [k for k, s in _LOGINS.items() if s is sess]:
                _LOGINS.pop(k, None)


def _finish(sess: Dict[str, Any], code: str, wait: float, again: str) -> Dict[str, Any]:
    t = sess.get("timer")
    if t is not None:
        t.cancel()
    p = sess["proc"]
    if p.poll() is not None:
        _lend(sess, "gone")
        return {"ok": False, "error": "expired", "plain": "This sign-in had already stopped. " + again}
    mark = len(_ltext(sess))
    try:
        p.stdin.write(code.encode("ascii") + b"\n")
        p.stdin.flush()
    except (OSError, ValueError):
        _lend(sess, "write")
        return {"ok": False, "error": "expired", "plain": "This sign-in had already stopped. " + again}
    try:
        p.wait(wait)
    except subprocess.TimeoutExpired:
        pass
    if p.poll() is not None and sess.get("reader") is not None:
        sess["reader"].join(2)           # the last lines it wrote before ending
    after = _ltext(sess)[mark:].lower()
    rc = p.poll()
    _lend(sess, "finished")
    if rc != 0 or "couldn't log in" in after or "invalid_grant" in after:
        if "invalid_grant" in after:
            return {"ok": False, "error": "refused", "plain": "Google did not accept that code. A code works once and only for a few minutes. " + again}
        if rc is None:
            return {"ok": False, "error": "timeout", "plain": "Google took too long to answer. " + again}
        return {"ok": False, "error": "failed", "plain": "The sign-in did not finish. " + again}
    r = check()
    if r.get("ok"):
        return {"ok": True, "connected": True, "plain": "Gemini is connected."}
    return {"ok": False, "error": r.get("error") or "check", "plain": "Google accepted the sign-in, but Gemini did not answer yet. "
            + (r.get("plain") or "") + " Press Check again in a minute."}


def _front_windows(title: str, seconds: float = 8.0) -> None:
    """Brings the console window titled `title` to the front (Windows only; best effort). A window started by a
    program in the background otherwise opens behind the person's other windows."""
    try:
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        found: list = []
        proto = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def cb(h, _l):
            n = u.GetWindowTextLengthW(h)
            if n:
                b = ctypes.create_unicode_buffer(n + 1)
                u.GetWindowTextW(h, b, n + 1)
                if b.value.startswith(title) and u.IsWindowVisible(h):
                    found.append(h)
            return True
        end = time.time() + seconds
        while time.time() < end and not found:
            u.EnumWindows(proto(cb), 0)
            if not found:
                time.sleep(0.25)
        k = ctypes.windll.kernel32
        for h in found[:1]:
            u.ShowWindow(h, 9)                       # SW_RESTORE
            # Windows lets only the program in front hand over the front: borrow its input queue for a moment
            # (AttachThreadInput), with a tap of Alt, then raise and focus the sign-in window
            fg = u.GetForegroundWindow()
            me = k.GetCurrentThreadId()
            them = u.GetWindowThreadProcessId(fg, None) if fg else 0
            if them and them != me:
                u.AttachThreadInput(me, them, True)
            try:
                u.keybd_event(0x12, 0, 0, 0)
                u.keybd_event(0x12, 0, 2, 0)
                u.SetWindowPos(h, -1, 0, 0, 0, 0, 0x0043)   # on top (shown, not moved or sized) ...
                u.SetWindowPos(h, -2, 0, 0, 0, 0, 0x0043)   # ... then back to normal stacking, still above the rest
                u.BringWindowToTop(h)
                u.SetForegroundWindow(h)
                u.SwitchToThisWindow(h, True)
            finally:
                if them and them != me:
                    u.AttachThreadInput(me, them, False)
    except Exception:
        pass


def open_signin(press: str = "") -> Dict[str, Any]:
    """Fallback when the sign-in inside the panel cannot start: Google's sign-in in a window of its own, titled
    "Sign in to Gemini", brought to the front. The person pastes the code there and presses Enter. Only for the
    person's press of that button (a press token) in the installed Qosha, with its own agy."""
    path, refused = _signin_gate(press)
    if refused:
        return refused
    name = "agy"
    if not _START_LOCK.acquire(blocking=False):
        return {"ok": False, "error": "busy", "plain": "A Gemini sign-in is starting already; wait a moment."}
    try:
        if time.time() - _TERMINAL["at"] < LOGIN_TTL:
            return {"ok": False, "error": "terminal_waiting", "plain": "A Gemini sign-in is already open in a Terminal "
                    "window: finish it there, or press Cancel to end that wait."}
        if login_active():      # one sign-in at a time: the panel's own sign-in is still waiting or checking its code
            return {"ok": False, "error": "waiting", "plain": "A Gemini sign-in is already waiting in this panel: finish "
                    "it there (paste the code Google shows), or press Cancel first."}
        r = _open_terminal(name, path)
        if r.get("ok"):
            _TERMINAL["at"] = time.time()
        return r
    finally:
        _START_LOCK.release()


def terminal_cancel() -> Dict[str, Any]:
    """The person pressed Cancel for a Terminal sign-in: Qosha stops waiting for it (the Terminal window is theirs)."""
    with _LLOCK:
        _TERMINAL["at"] = 0.0
    return {"ok": True}


def _open_terminal(name: str, path: str) -> Dict[str, Any]:
    args = ["acp", "--login"] if name == "agy" else []
    try:
        if sys.platform == "darwin":
            import shlex
            # the Terminal window's shell does not inherit Qosha's environment: the no-self-update switch is set inline
            sh = ("printf '\\033]0;Sign in to Gemini\\007'; clear; "
                  + " ".join("%s=%s" % kv for kv in NOUPDATE_ENV.items()) + " "
                  + " ".join(shlex.quote(x) for x in [path] + args))
            osa = 'tell application "Terminal"\nactivate\ndo script "%s"\nend tell' % sh.replace("\\", "\\\\").replace('"', '\\"')
            subprocess.Popen(["/usr/bin/osascript", "-e", osa], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            where = "A Terminal window titled “Sign in to Gemini” opened."
        elif WIN:
            subprocess.Popen(["cmd", "/c", "start", "Sign in to Gemini", "cmd", "/k", path] + args, shell=False,
                             env=_env(), creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000))
            threading.Thread(target=_front_windows, args=("Sign in to Gemini",), daemon=True).start()
            where = "A window titled “Sign in to Gemini” opened."
        else:
            return {"ok": False, "error": "manual", "plain": "Open a terminal and run: %s %s" % (name, " ".join(args))}
    except OSError as exc:
        return {"ok": False, "error": "open", "plain": "The sign-in window could not be opened (%s)." % type(exc).__name__}
    return {"ok": True, "tool": name, "plain": where + " Google\u2019s sign-in page opens in your browser (if not, open the "
            "address shown in that window). Sign in; Google then shows a code: copy it, click into the \u201cSign in to "
            "Gemini\u201d window, paste the code there and press Enter. Then come back here and press Check again."}


def _access_gate():
    """CONTRACT-ACCESS: True when Qosha's access has ended or can't be confirmed (qosha_guard/access.py, loaded by path
    once). Fails closed."""
    import importlib.util as _ilu, sys as _sys
    from pathlib import Path as _P
    try:
        m = _sys.modules.get("qosha_access_gate")
        if m is None:
            p = _P(__file__).resolve().parent / "access.py"
            spec = _ilu.spec_from_file_location("qosha_access_gate", str(p))
            m = _ilu.module_from_spec(spec)
            spec.loader.exec_module(m)
            _sys.modules["qosha_access_gate"] = m
        return bool(m.admit_stopped())        # the same freshness check as a chat message (review r2 #9)
    except Exception:
        return True
