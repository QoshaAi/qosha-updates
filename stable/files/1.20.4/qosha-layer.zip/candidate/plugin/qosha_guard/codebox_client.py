"""Qosha's code sandbox, the assistant's side (CAPFIX, council D50). The guard rewrites a terminal or execute_code call
that runs code the assistant wrote into a call of this client with the original code; it runs (confined, like every
command of the assistant) in the folder the command would have run in, and asks the Qosha connector to run the code in
Qosha's code sandbox: a Linux container working on filtered snapshots of Your files and the selected working folder,
with skills/source snapshots read-only. Every network request, including GET/HEAD, waits on an Approve card. Prints
the program output and a bounded completion summary. A nonzero program exit remains unchanged; otherwise pending
approval exits3 and incomplete writeback or approval registration exits4. Ordinary completed runs exit0.

  python codebox_client.py <sh|python|node> <base64 code> [<timeout seconds>]"""
import base64
import json
import os
import re
import sys
import urllib.error
import urllib.request

NOTE = ("[Ran in Qosha's code sandbox on filtered snapshots of Your files and the selected working folder. "
        "Ordinary edits copy back only when the originals still match; deletes and executable writes wait for "
        "Approve. Skills and source are read-only. Every network request, including GET/HEAD, waits for Approve.]")


def completion_status(out):
    """Only fixed wording, counts and validated card IDs cross this boundary; never raw proposals or errors."""
    changes = out.get("changes")
    if not isinstance(changes, dict):
        if "changes" not in out and "decisions" not in out and "approval_errors" not in out:
            return [], 0
        return ["[Incomplete: Qosha could not confirm file changes or approval status. Review the staged results.]"], 4
    saved = changes.get("saved", [])
    pending = changes.get("pending", [])
    conflicts = changes.get("conflicts", [])
    errors = out.get("approval_errors", [])
    decisions = out.get("decisions", [])
    if not all(isinstance(x, list) for x in (saved, pending, conflicts, errors, decisions)):
        return ["[Incomplete: Qosha could not confirm file changes or approval status. Review the staged results.]"], 4
    lines = []
    if saved:
        lines.append("[Saved %d ordinary file change(s).]" % len(saved))
    cards = [d["id"] for d in decisions if isinstance(d, dict) and d.get("kind") in ("file.delete", "file.write")
             and isinstance(d.get("id"), str) and re.fullmatch(r"d_[0-9a-f]{12}", d["id"])]
    cards = list(dict.fromkeys(cards))
    if pending or decisions:
        lines.append("[Pending approval: %d proposed change(s) remain staged; they have not been applied. "
                     "Deletes and executable writes wait for the person's Approve.]" % max(len(pending), len(decisions)))
        if cards:
            lines.append("[Approval card(s): %s%s]" % (", ".join(cards[:20]),
                         "; %d additional card(s)" % (len(cards) - 20) if len(cards) > 20 else ""))
    if errors:
        lines.append("[Approval registration failed for %d staged change(s); complete approval cards could not be "
                     "prepared. Those proposed changes have not been applied.]" % len(errors))
    missing = max(0, len(pending) - len(cards) - len(errors))
    if missing:
        lines.append("[Incomplete: %d staged change(s) have no confirmed approval card.]" % missing)
    unmatched = len(pending) != len(cards) + len(errors)
    if unmatched and not missing:
        lines.append("[Incomplete: approval results do not match the staged proposals. Review their status before continuing.]")
    if conflicts:
        lines.append("[Writeback conflict: %d file change(s) require review; staged results were retained.]" % len(conflicts))
        if any(isinstance(c, str) and "new output installed" in c for c in conflicts):
            lines.append("[Some new output was installed before a concurrent change was detected. Competing contents "
                         "were preserved in a private staged backup. Review both versions before continuing.]")
        else:
            lines.append("[Not all file changes were saved. Review the retained results before continuing.]")
    incomplete = bool(conflicts or errors or unmatched or len(cards) != len(decisions))
    return lines, 4 if incomplete else 3 if pending or decisions else 0


def _key() -> str:
    home = os.environ.get("HERMES_HOME") or ""
    try:
        with open(os.path.join(home, "qosha", "connector.key")) as fh:
            return fh.read().strip()
    except OSError:
        return ""


def main(argv) -> int:
    if len(argv) < 3 or argv[1] not in ("sh", "python", "node"):
        sys.stderr.write(__doc__ + "\n")
        return 2
    code = base64.b64decode(argv[2]).decode("utf-8")
    timeout = int(argv[3]) if len(argv) > 3 and argv[3].isdigit() else 300
    url = (os.environ.get("QOSHA_CONNECTOR_URL") or "http://127.0.0.1:9239").rstrip("/") + "/v1/code"
    body = json.dumps({"lang": argv[1], "code": code, "cwd": os.getcwd(), "timeout": timeout}).encode()
    h = {"Content-Type": "application/json"}
    k = _key()
    if k:
        h["X-Qosha-Key"] = k
    req = urllib.request.Request(url, data=body, headers=h, method="POST")
    proxy = urllib.request.ProxyHandler({})          # the connector is on this Mac: never through the web proxy
    try:
        with urllib.request.build_opener(proxy).open(req, timeout=min(timeout, 1800) + 180) as r:
            out = json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read(20000) or b"{}")
        except ValueError:
            err = {}
        sys.stderr.write("Qosha's code sandbox: %s\n" % (err.get("detail") or err.get("error") or e.code))
        return 125
    except (OSError, ValueError) as e:
        sys.stderr.write("Qosha's code sandbox: the Qosha connector isn't answering (%s). Try again in a moment.\n"
                         % type(e).__name__)
        return 125
    text = str(out.get("output") or "")
    sys.stdout.write(text)
    if text and not text.endswith("\n"):
        sys.stdout.write("\n")
    rc = int(out.get("exit_code") if isinstance(out.get("exit_code"), int) else 1)
    if out.get("timed_out"):
        sys.stdout.write("[Stopped: the code ran longer than %d seconds.]\n" % timeout)
    if rc != 0 and ("No such file" in text or "Read-only file system" in text or "Permission denied" in text):
        sys.stdout.write(NOTE + "\n")
    lines, status = completion_status(out)
    for line in lines:
        sys.stdout.write(line + "\n")
    return rc if rc != 0 else status


if __name__ == "__main__":
    sys.exit(main(sys.argv))
