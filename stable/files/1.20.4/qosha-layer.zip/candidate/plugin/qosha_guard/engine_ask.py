"""One card per step: Qosha's card and the engine's own safety check never both ask (Ren's Mac, 17 Nov 2026 16:41).

The engine checks every shell command against its own list of risky patterns ("recursive delete", "delete in root
path", ...) and asks the person itself, in its own technical words, even right after the person allowed the same step
on Qosha's card. Here, before a shell step runs:
  * findings(): what the engine's check WOULD ask about for this exact command (its own detection, its own rules for
    when it asks: approval mode, the person's allowlist, refused-outright commands and who is present to answer);
  * plain(): those findings in plain words, so Qosha's single card can say them (never the pattern names);
  * grant() / revoke(): once the person allowed the step on Qosha's card (or had chosen "Always allow" for it), the
    engine's own supported grant (approve_session, what its "allow for this session" answer does) is given for exactly
    those findings, and taken back again as soon as the next tool step of that conversation starts. A finding the
    engine never lets anyone pre-approve (a command too complex to read to the end) is left to the engine.
The engine's refuse-outright rules and its checks for other commands stay as they are. Nothing here may raise.
"""
from __future__ import annotations

import re
import threading
from typing import Dict, List, Optional, Tuple

# engine finding (its description, lower case) -> plain words. First match wins. "family" says which of Qosha's own
# card kinds already covers it: a Qosha delete card covers the engine's delete findings, a share card a force push.
_PLAIN = [
    (r"osascript|applescript", None, "Control other apps on this Mac (they may close without saving, or keys may be typed)"),
    (r"registry", None, "Change settings in the Windows registry"),
    (r"hermes home|session store|hermes session", None, "Delete, move or change Qosha's own data (its chats and settings)"),
    (r"hermes config|hermes.*env|approval settings", None, "Change Qosha's own settings or safety rules"),
    (r"hermes update|hermes gateway|hermes/gateway|hermes launchd|start gateway|self-termination", None,
     "Stop or restart Qosha itself (what it is doing now would stop)"),
    (r"force push", "share", "Replace the online copy of a project (changes there that are not on this computer are lost)"),
    (r"git clean", "delete", "Delete files that a project does not keep in its history"),
    (r"reset --hard", "delete", "Throw away unsaved changes in a project (they cannot be brought back)"),
    (r"branch force delete", "delete", "Delete a project branch, even if it has work saved nowhere else"),
    (r"\bsql\b", "delete", "Delete data from a database"),
    (r"docker|podman", None, "Stop, delete or redirect containers (programs running in their own boxes)"),
    (r"uninstall", "delete", "Uninstall a program"),
    (r"shadow cop|backups", "delete", "Delete the computer's backup copies"),
    (r"service|systemctl|launchd", None, "Stop, restart or remove a service of the computer"),
    (r"format|partition|block device|disk copy|clear-disk|wipe free space|wipe disk", None, "Erase or overwrite a whole disk"),
    (r"delete|\brm\b|erase|wipe|prune|destruction", "delete", "Delete files or folders on this computer"),
    (r"shell-rc|sensitive", None, "Change your sign-in keys or your terminal's start-up files"),
    (r"credential|secret|ssh key|metadata endpoint", None, "Read or send passwords, keys or sign-in files"),
    (r"remote content|remote script|just-downloaded|invoke-expression", None, "Download a program or script from the internet and run it"),
    (r"decoded|obfuscation|encoded command|invisible|dynamic shell word|heredoc|malformed|parser limit|too complex", None,
     "Run instructions that are hidden or too complex for Qosha to read before they run"),
    (r"reverse shell|netcat|socat|/dev/tcp", None, "Open a remote-control connection from this computer to another one"),
    (r"chmod \+x", None, "Make a file runnable and run it straight away"),
    (r"chmod|chown|writable|acl|icacls|everyone", None, "Change who may open or change files on this computer"),
    (r"fork bomb", None, "Start a runaway process that can freeze the computer"),
    (r"kill|stop-process|taskkill", None, "Stop programs that are running"),
    (r"sudo|privilege", None, "Run a step with administrator rights"),
    (r"system config|system file|boot configuration|setx", None, "Change the computer's system settings"),
    (r"project env|project.*config", None, "Overwrite a project's settings or secrets file"),
]
_FALLBACK = "Do something the computer's safety check marks as risky (Qosha could not put it into plain words)"


def plain(description: str) -> Tuple[Optional[str], str]:
    """(family or None, plain sentence) for one engine finding."""
    low = (description or "").lower()
    for rx, fam, text in _PLAIN:
        if re.search(rx, low):
            return fam, text
    return None, _FALLBACK


def _ap():
    from tools import approval as ap
    return ap


def findings(command: str, background: bool = False) -> Optional[List[Tuple[str, str]]]:
    """[(engine key, description)] the engine's own check would ASK the person about for this command right now;
    [] when it would not ask (clean, allowed, refused outright, approvals off, nobody to ask); None if unknown."""
    try:
        ap = _ap()
        from tools import approval_context as actx
        from tools import terminal_tool as tt
        cmd = str(command or "")
        if not background:
            cmd = tt.trailing_amp_background_command(cmd) or cmd
        config = tt._get_env_config()
        if ap._should_skip_container_guards(config["env_type"], has_host_access=tt._docker_has_host_access(config)):
            return []
        if ap._floor_block(cmd, sudo_guard=True) is not None:
            return []          # the engine refuses it outright, with no question
        if ap._yolo_active() or actx._get_approval_mode() == "off":
            return []
        if not ap.hardline_scan_incomplete(cmd) and ap._command_matches_permanent_allowlist(cmd):
            return []
        _cb, is_cli, is_gateway, is_ask = ap._presence()
        if not (is_cli or is_gateway or is_ask):
            return []          # nobody to ask: the engine's own unattended rules apply, as before
        sk = ap.get_current_session_key()
        return [(k, d) for k, d in ap._command_findings(cmd) if ap._approval_scope(sk, k) is None]
    except Exception:
        return None


def _parts(command: str) -> List[str]:
    """The command split at ; && || and line breaks outside quotes (pipes stay inside a part: "curl ... | sh" is one)."""
    out, cur, q, i = [], [], None, 0
    while i < len(command):
        c = command[i]
        if q:
            cur.append(c)
            if c == q:
                q = None
            elif c == "\\" and q == '"' and i + 1 < len(command):
                cur.append(command[i + 1])
                i += 1
        elif c in "'\"":
            q = c
            cur.append(c)
        elif c == "\\" and i + 1 < len(command):
            cur.append(c + command[i + 1])
            i += 1
        elif c in ";\n" or command[i:i + 2] in ("&&", "||"):
            out.append("".join(cur))
            cur = []
            if command[i:i + 2] in ("&&", "||"):
                i += 1
        else:
            cur.append(c)
        i += 1
    out.append("".join(cur))
    return [x.strip() for x in out if x.strip()]


def all_risks(command: str, background: bool = False) -> List[Tuple[str, str]]:
    """Every risk the engine's detection sees in ANY part of the command (it reports only the first one for the whole
    command), for the card to say. [] when the engine would not ask in this context at all. Never used to grant."""
    try:
        if findings(command, background) is None:
            return []
        ap = _ap()
        from tools import approval_context as actx
        if ap._yolo_active() or actx._get_approval_mode() == "off":
            return []
        _cb, is_cli, is_gateway, is_ask = ap._presence()
        if not (is_cli or is_gateway or is_ask):
            return []
        seen, out = set(), []
        for part in _parts(command) + [command]:   # in the order the parts run; the whole command last
            for k, d in ap._command_findings(part):
                if k not in seen:
                    seen.add(k)
                    out.append((k, d))
        return out
    except Exception:
        return []


def can_grant(key: str) -> bool:
    try:
        return key != _ap()._SCAN_INCOMPLETE_DESCRIPTION
    except Exception:
        return False


_LOCK = threading.Lock()
_GRANTS: Dict[str, Dict[str, str]] = {}    # session key -> {engine key: tool call it was given for}


def is_allowed(rule_key: str) -> bool:
    """True when the person already chose "Always allow" (or this session) for Qosha's rule: the engine's gate then
    lets Qosha's card through without asking, and so must the engine's own check for the same step."""
    try:
        ap = _ap()
        return ap.is_approved(ap.get_current_session_key(), "plugin_rule:" + rule_key)
    except Exception:
        return False


def grant(keys: List[str], call_id: str, session_key: str = "") -> List[str]:
    """Give the engine's own session grant for these findings, for the step the person allowed. Returns the keys given."""
    given = []
    try:
        ap = _ap()
        sk = session_key or ap.get_current_session_key()
        for k in keys:
            if not can_grant(k) or ap._approval_scope(sk, k) is not None:
                continue        # never pre-approvable, or the person already allowed it themselves: not ours to take back
            ap.approve_session(sk, k)
            with _LOCK:
                _GRANTS.setdefault(sk, {})[k] = call_id or "?"
            given.append(k)
    except Exception:
        pass
    return given


def revoke(session_key: str = "", keep_call: str = "") -> int:
    """Take back the grants given for earlier steps (all of this conversation's, except the step keep_call)."""
    n = 0
    try:
        ap = _ap()
        sk = session_key or ap.get_current_session_key()
        with _LOCK:
            mine = _GRANTS.get(sk) or {}
            drop = [k for k, c in mine.items() if not keep_call or c != keep_call]
            for k in drop:
                mine.pop(k, None)
        if drop:
            with ap._lock:
                s = ap._session_approved.get(ap._session_grant_key(sk))
                for k in drop:
                    if s is not None and k in s:
                        s.discard(k)
                        n += 1
    except Exception:
        pass
    return n
