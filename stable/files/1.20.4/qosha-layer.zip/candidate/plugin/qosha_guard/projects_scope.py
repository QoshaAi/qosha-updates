"""Project rules for the approval guard (UAT 2 Nov 11:42; council C9 → D20). Block-only: it never allows a call the
rest of the guard would refuse; it runs before it and can only refuse.

1. Instructions are written by the person only: assistant file tools and terminal commands may not touch the files
   the engine loads as instructions (.hermes.md, HERMES.md, AGENTS.md, CLAUDE.md, .cursorrules) inside the files folder
   (terminal: anywhere): plain attempts to plant lasting instructions in a project are refused (a habit check).
2. In a project chat (a session whose working folder is <files root>/Projects/<slug>):
   - helpers (delegate_task) only when the project's "agents" option is on;
   - automations (cronjob, except listing) are refused: programmed tasks in projects are coming next;
   - file tools can't reach another project's folder or anything above its own (stored and resolved paths);
   - terminal commands that plainly name another project's folder or a parent folder are refused.
These are habit checks, not a wall: the assistant runs as the same Mac user and can write the lab's folders, so
project folders organise work; they don't separate it securely (said so on the page; GPT R-projects1).
Any error while checking one of these tools refuses that call (fails closed for these tools only).
"""
from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, Optional

ROOT_ENV = "HERMES_DASHBOARD_FILES_ROOT"
INSTRUCTION_NAMES = (".hermes.md", "hermes.md", "agents.md", "claude.md", ".cursorrules")
INSTRUCTION_DIRS = ("/.cursor/rules/",)   # the engine's last fallback (.cursor/rules/*.mdc)
FILE_TOOLS = ("read_file", "write_file", "patch", "search_files")
WRITE_TOOLS = ("write_file", "patch")
CRON_READS = ("list",)
SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")
_NAMES_RE = re.compile(r"(?i)(?<![A-Za-z0-9_-])(?:\.hermes\.md|hermes\.md|agents\.md|claude\.md|\.cursorrules|\.cursor)(?![A-Za-z0-9_-])")


def _block(message: str) -> Dict[str, str]:
    return {"action": "block", "message": "Not allowed by Qosha: " + message}


def files_root() -> Optional[str]:
    raw = os.environ.get(ROOT_ENV, "").strip()
    if not raw or not os.path.isabs(raw):
        return None
    raw = raw.rstrip("/")
    return os.path.realpath(raw)


class _NoRow(Exception):
    """A session id with no stored session: helpers and automations are refused (GPT R-projects1)."""


def _session_cwd(session_id: str, strict: bool = False) -> str:
    if not session_id:
        return ""
    from hermes_state import SessionDB
    db = SessionDB()
    try:
        row = db.get_session(session_id)
    finally:
        try:
            db.close()
        except Exception:
            pass
    if row is None and strict:
        raise _NoRow(session_id)
    return str((row or {}).get("cwd") or "")


def project_of(cwd: str, root: str) -> Optional[str]:
    """The project slug when cwd is a project folder (or inside one). The stored path decides first, so replacing the
    folder with a link elsewhere can't take a project chat out of its project's rules (GPT R-projects1); its
    resolved form is checked too."""
    if not cwd or not root:
        return None
    base = root + "/Projects/"
    for c in (os.path.normpath(cwd), os.path.realpath(cwd)):
        if c == base.rstrip("/"):
            return "?"                                       # the Projects folder itself: everything off
        if c.startswith(base):
            slug = c[len(base):].split("/", 1)[0]
            return slug if SLUG_RE.match(slug) else "?"     # "?": inside Projects but not a valid project → all off
    return None


def _options(slug: str) -> Dict[str, Any]:
    if slug == "?":
        return {"name": "this project", "archived": True, "agents": False, "tasks": False}
    from hermes_cli import projects_db as pdb
    with pdb.connect_closing() as conn:
        for p in pdb.list_projects(conn, include_archived=True):
            if p.slug == slug:
                out = {"name": p.name, "archived": bool(p.archived)}
                for o in ("agents", "tasks"):
                    row = conn.execute("SELECT value FROM project_meta WHERE key = ?",
                                       ("qosha.project.%s.%s" % (p.id, o),)).fetchone()
                    out[o] = bool(row) and row[0] == "1"
                return out
    return {"name": slug, "archived": True, "agents": False, "tasks": False}   # unknown: everything off


def _text(args: Any) -> str:
    try:
        return json.dumps(args, ensure_ascii=False, default=str)
    except Exception:
        return str(args)


def _resolve(path: str, cwd: str) -> str:
    p = os.path.expanduser(path)
    if not os.path.isabs(p):
        p = os.path.join(cwd or os.getcwd(), p)
    return os.path.realpath(p)


def check(tool_name: str, args: Any, session_id: str) -> Optional[Dict[str, Any]]:
    tool = str(tool_name or "")
    if tool not in FILE_TOOLS and tool not in ("terminal", "delegate_task", "cronjob"):
        return None
    try:
        root = files_root()
        a = args if isinstance(args, dict) else {}
        # 1. the instruction files
        shell = " ".join(str(a.get(k) or "") for k in ("command", "code", "workdir", "cwd", "dir", "directory",
                                                        "working_directory", "path"))
        if tool == "terminal" and _NAMES_RE.search(shell):
            return _block("instruction files (.hermes.md, AGENTS.md, CLAUDE.md, .cursorrules) are changed only by a "
                          "person, on the Projects page.")
        if tool in WRITE_TOOLS and root:
            path = a.get("path")
            names = [path] if isinstance(path, str) else []
            if tool == "patch":
                names += re.findall(r"\*\*\* (?:Add|Update|Delete) File: (.+)", str(a.get("patch") or ""))
                names += re.findall(r"\*\*\* Move to: (.+)", str(a.get("patch") or ""))
            cwd = _session_cwd(session_id) if names else ""
            for n in names:
                real = _resolve(n.strip(), cwd)
                raw = os.path.normpath(os.path.join(cwd or "/", os.path.expanduser(n.strip())))
                named = os.path.basename(raw).lower() in INSTRUCTION_NAMES or os.path.basename(real).lower() in INSTRUCTION_NAMES
                in_rules = any(d in (raw + "/") or d in (real + "/") for d in INSTRUCTION_DIRS)
                if (named or in_rules) and any(x == root or x.startswith(root + "/") for x in (raw, real)):
                    return _block("project instructions are changed only by a person, on the Projects page.")
        if not root:
            return None
        # 2. project chats
        try:
            cwd = _session_cwd(session_id, strict=tool in ("delegate_task", "cronjob"))
        except _NoRow:
            return _block("this chat has no saved record, so helpers and automations are not available in it.")
        slug = project_of(cwd, root)
        if not slug:
            return None
        opts = _options(slug)
        folder = root + "/Projects/" + slug
        base = root + "/Projects/"
        if tool == "terminal":
            # a habit check, not a wall (the assistant is the same Mac user): plain references to another project's
            # folder or to folders above this one are refused
            cmd = shell
            others = set(re.findall(r"/Projects/([^/\s'\"`;|&)]+)", cmd)) - {slug}
            if others or re.search(r"(?:^|[\s'\"=:`(/])\.\.(?:/|\s|$|['\"`;|&)])", cmd):
                return _block("a project chat works inside its own project's folder.")
            return None
        if tool == "delegate_task" and not (opts["agents"] and not opts["archived"]):
            return _block("helpers are off for the project %s. A person can turn them on in Projects." % opts["name"])
        if tool == "cronjob":
            action = str(a.get("action") or "").strip().lower()
            if action in CRON_READS:
                return None
            # programmed tasks inside a project are not offered yet (the lab's scheduler is off, and a project
            # folder sits inside the lab, where the guard refuses scheduled work): refused, whatever the option says
            return _block("programmed tasks inside a project are coming next; this automation was not created.")
        if tool in FILE_TOOLS:
            text_paths = [a.get("path")] if isinstance(a.get("path"), str) else []
            if tool == "patch":
                text_paths += re.findall(r"\*\*\* (?:Add|Update|Delete) File: (.+)", str(a.get("patch") or ""))
                text_paths += re.findall(r"\*\*\* Move to: (.+)", str(a.get("patch") or ""))
            if tool == "search_files" and not text_paths:
                text_paths = ["."]
            for n in text_paths:
                for real in (os.path.normpath(os.path.join(cwd or "/", os.path.expanduser(n.strip()))), _resolve(n.strip(), cwd)):
                    inside_other = real.startswith(base) and not (real == folder or real.startswith(folder + "/"))
                    above = base.startswith(real.rstrip("/") + "/")       # the Projects folder itself or anything above it
                    if inside_other or above:
                        return _block("a project chat works inside its own project's folder.")
        return None
    except Exception as exc:   # fails closed for these tools only
        return _block("the project check could not complete (%s), so this was blocked." % type(exc).__name__)
