"""Install Qosha's startup barrier into an engine environment (GUARDFIX message 1).
  <engine python> -I install_barrier.py [--check]
Copies startup_barrier.py beside the engine as qosha_startup_barrier.py and adds qosha_startup_barrier.pth (one line:
import qosha_startup_barrier) to that python's site-packages, so every start of the engine imports it first. --check:
exit 0 only if the engine's plugin module, imported fresh, carries the barrier (prints BARRIER ACTIVE)."""
import os
import shutil
import site
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def target_dir() -> str:
    for d in site.getsitepackages():
        if d.endswith("site-packages") and os.path.isdir(d):
            return d
    raise SystemExit("no site-packages for %s" % sys.executable)


def check() -> int:
    r = subprocess.run([sys.executable, "-c", "import hermes_cli.plugins as p; "
                        "print('BARRIER ACTIVE' if getattr(p._get_pre_tool_call_directive_details, '__qosha_barrier__', False) "
                        "else 'BARRIER MISSING')"], capture_output=True, text=True)
    out = (r.stdout or r.stderr).strip().splitlines()
    print(out[-1] if out else "BARRIER MISSING")
    return 0 if out and out[-1] == "BARRIER ACTIVE" else 1


def main() -> int:
    if "--check" in sys.argv:
        return check()
    d = target_dir()
    tmp = os.path.join(d, ".qosha_startup_barrier.py.tmp")
    shutil.copyfile(os.path.join(HERE, "startup_barrier.py"), tmp)
    os.replace(tmp, os.path.join(d, "qosha_startup_barrier.py"))
    with open(os.path.join(d, ".qosha_startup_barrier.pth.tmp"), "w") as fh:
        fh.write("import qosha_startup_barrier\n")
    os.replace(os.path.join(d, ".qosha_startup_barrier.pth.tmp"), os.path.join(d, "qosha_startup_barrier.pth"))
    return check()


if __name__ == "__main__":
    raise SystemExit(main())
