"""Google's `agy` (Gemini on the person's own Google subscription) at the version Qosha tested, in Qosha's own folder
(contract AGYGUARD, signed by Ren 18 Nov 2026).

One pinned file (agy-pin.json) names the version and, per computer, Google's GitHub release asset (file, size, sha256)
and the program inside it (member, size, sha256). Qosha installs exactly that program into <root>/engine/agy/agy
(Windows: agy.exe), per user, no administrator, and never lets it change by itself (every call Qosha makes carries
AGY_CLI_DISABLE_AUTO_UPDATE=true). A new version arrives only with a signed Qosha update (updater.py).

Used by: the installers (python agy_pin.py install ...), the updater (install, daily self-check), the dashboard's
Repair button (repair). Standard library only; the same code on Mac and Windows.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import platform
import re
import secrets
import shutil
import ssl
import subprocess
import sys
import tarfile
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple

WIN = os.name == "nt"
KEYS = ("mac_arm64", "mac_x64", "windows_x64", "windows_arm64")
URL_PREFIX = "https://github.com/google-antigravity/antigravity-cli/releases/download/"
NOUPDATE = "AGY_CLI_DISABLE_AUTO_UPDATE"
_VERSION_RE = re.compile(r"^\d{1,4}\.\d{1,4}\.\d{1,6}$")
_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_FILE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$")
# one model line of `agy models`, in Google's form "<model-id><TAB><display name>" (as 1.5.11 prints it:
# "gemini-4-argon-medium\tGemini 4 Argon (Medium)"); model-id = lower-case letters, digits, dots and hyphens.
# Contract run 3, C8: "ok" needs exit 0 AND at least one such line; anything else is not a working tool.
_MODEL_LINE = re.compile(r"^[a-z0-9][a-z0-9.-]*\t+[^\t\r\n]*\S[^\r\n]*\r?$", re.M)
DOWNLOAD_MAX = 600 * 1024 * 1024
CHECK_TIMEOUT = 60

PLAIN_REPAIR = "Gemini needs a repair"
_PLAIN = {
    "missing": PLAIN_REPAIR + ": Google's Gemini tool is not installed in Qosha yet. Press Repair.",
    "wrong_version": PLAIN_REPAIR + ": Google's Gemini tool is not the version Qosha tested. Press Repair.",
    "tampered": PLAIN_REPAIR + ": Google's Gemini tool was changed on this computer. Press Repair.",
    "signed_out": "Gemini needs you to sign in again. Press Sign in with Gemini.",
    "broken": PLAIN_REPAIR + ": Google's Gemini tool did not answer its check. Press Repair.",
    "ok": "Gemini's tool is installed and answers.",
}


# --- which computer ----------------------------------------------------------------------------------------------------
def platform_key(system: str, machine: str) -> str:
    """("Darwin","arm64") -> "mac_arm64", ... ; anything else raises ValueError."""
    s = str(system or "").strip().lower()
    m = str(machine or "").strip().lower()
    if s == "darwin":
        if m in ("arm64", "aarch64"):
            return "mac_arm64"
        if m in ("x86_64", "amd64"):
            return "mac_x64"
    elif s == "windows":
        if m in ("amd64", "x86_64", "x64"):
            return "windows_x64"
        if m in ("arm64", "aarch64"):
            return "windows_arm64"
    raise ValueError("no Gemini tool for this computer (%s %s)" % (system, machine))


def this_key() -> str:
    """This computer's key (the hardware's, also when this Python runs under emulation)."""
    system, machine = platform.system(), platform.machine()
    if system == "Windows":
        machine = os.environ.get("PROCESSOR_ARCHITEW6432") or os.environ.get("PROCESSOR_ARCHITECTURE") or machine
    elif system == "Darwin" and machine.lower() == "x86_64":
        try:   # an Intel Python on Apple silicon (Rosetta) still gets the Apple-silicon program
            r = subprocess.run(["/usr/sbin/sysctl", "-n", "hw.optional.arm64"], capture_output=True, text=True, timeout=5)
            if r.stdout.strip() == "1":
                machine = "arm64"
        except Exception:
            pass
    return platform_key(system, machine)


# --- the pin -----------------------------------------------------------------------------------------------------------
def _pos_int(v) -> bool:
    return isinstance(v, int) and not isinstance(v, bool) and v > 0


def validate_pin(d) -> dict:
    """A clean copy of a well-formed pin; raises ValueError otherwise."""
    if not isinstance(d, dict):
        raise ValueError("the pin is not an object")
    v = d.get("version")
    if not isinstance(v, str) or not _VERSION_RE.match(v):
        raise ValueError("pin version must be X.Y.Z (digits)")
    t = d.get("url_template")
    if not isinstance(t, str) or not t.startswith(URL_PREFIX) or "{version}" not in t or "{file}" not in t:
        raise ValueError("pin url_template must be Google's GitHub release address with {version} and {file}")
    try:
        probe = t.format(version=v, file="x.zip")
    except (KeyError, IndexError, ValueError):
        raise ValueError("pin url_template holds other fields")
    if not probe.startswith(URL_PREFIX) or any(c in probe for c in " \t\r\n\"'<>\\"):
        raise ValueError("pin url_template is not a plain address")
    assets = d.get("assets")
    if not isinstance(assets, dict) or not assets:
        raise ValueError("pin has no assets")
    out_assets = {}
    for k, a in assets.items():
        if k not in KEYS:
            raise ValueError("pin asset for an unknown computer: %r" % (k,))
        if not isinstance(a, dict):
            raise ValueError("pin asset %s is not an object" % k)
        f, member = a.get("file"), a.get("member")
        if not isinstance(f, str) or not _FILE_RE.match(f):
            raise ValueError("pin asset %s: bad file name" % k)
        if not f.endswith(".zip" if k.startswith("windows") else ".tar.gz"):
            raise ValueError("pin asset %s: unexpected archive type" % k)
        if (not isinstance(member, str) or not member or member.startswith(("/", "\\")) or ".." in re.split(r"[\\/]", member)
                or ":" in member or len(member) > 200):
            raise ValueError("pin asset %s: bad member" % k)
        for n in ("size", "binary_size"):
            if not _pos_int(a.get(n)) or a[n] > DOWNLOAD_MAX:
                raise ValueError("pin asset %s: %s must be a positive whole number" % (k, n))
        for n in ("sha256", "binary_sha256"):
            if not isinstance(a.get(n), str) or not _HEX64.match(a[n]):
                raise ValueError("pin asset %s: %s must be 64 hex digits" % (k, n))
        out_assets[k] = {"file": f, "size": a["size"], "sha256": a["sha256"], "member": member,
                         "binary_size": a["binary_size"], "binary_sha256": a["binary_sha256"]}
    return {"version": v, "url_template": t, "assets": out_assets}


def load_pin(path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return validate_pin(json.load(f))


# --- places ------------------------------------------------------------------------------------------------------------
def agy_dir(root) -> Path:
    return Path(root) / "engine" / "agy"


def agy_path(root, key: str) -> Path:
    if key not in KEYS:
        raise ValueError("unknown computer key %r" % (key,))
    return agy_dir(root) / ("agy.exe" if key.startswith("windows") else "agy")


def _read_json(p: Path):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return None


def installed_info(root) -> dict:
    d = _read_json(agy_dir(root) / "installed.json")
    return d if isinstance(d, dict) else {}


def _key_for(root, key: Optional[str] = None) -> str:
    """The given key, else the one recorded at install, else this computer's."""
    if key in KEYS:
        return key
    k = installed_info(root).get("key")
    return k if k in KEYS else this_key()


def _sha_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def agy_env(base: Optional[dict] = None) -> dict:
    """The environment of every agy call Qosha makes: its own self-update switched off."""
    env = dict(os.environ if base is None else base)
    env[NOUPDATE] = "true"
    return env


# --- download ----------------------------------------------------------------------------------------------------------
def _ssl_contexts():
    yield ssl.create_default_context()
    try:
        import certifi  # type: ignore
        yield ssl.create_default_context(cafile=certifi.where())
    except Exception:
        pass
    for f in ("/etc/ssl/cert.pem", "/private/etc/ssl/cert.pem"):
        if os.path.isfile(f):
            yield ssl.create_default_context(cafile=f)


def default_fetch(url: str, limit: int = DOWNLOAD_MAX, timeout: float = 120.0) -> bytes:
    """Google's file from GitHub over https (redirects to GitHub's file host are followed)."""
    import urllib.request
    if not url.startswith(URL_PREFIX):
        raise OSError("address not allowed: %s" % url)
    last: Exception = OSError("no certificate store")
    for ctx in _ssl_contexts():
        req = urllib.request.Request(url, headers={"User-Agent": "Qosha-agy/1"})
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
                if not r.geturl().startswith("https://"):
                    raise OSError("redirected away from https")
                data = r.read(limit + 1)
            if len(data) > limit:
                raise OSError("download too large")
            return data
        except ssl.SSLError as e:
            last = e
            continue
        except OSError as e:
            if isinstance(getattr(e, "reason", None), ssl.SSLError):
                last = e
                continue
            raise
    raise last


# --- install -----------------------------------------------------------------------------------------------------------
def _fail(error: str, detail: str = "") -> dict:
    why = {"download": "the download did not arrive", "size": "the download is not the size Qosha expects",
           "checksum": "the download does not match the version Qosha tested",
           "archive": "the download does not hold Google's program", "pin": "Qosha's pinned version is unreadable",
           "write": "Qosha could not write it to its folder"}.get(error, error)
    out = {"ok": False, "error": error, "plain": "%s: Google's Gemini tool could not be installed (%s). Qosha works "
           "without it; press Repair in Connect your AI to try again." % (PLAIN_REPAIR, why)}
    if detail:
        out["detail"] = detail[:300]
    return out


def _extract(data: bytes, key: str, member: str, dest, limit: int) -> Tuple[int, str]:
    """Writes `member` of the archive into the open file dest; returns (size, sha256). Raises ValueError("archive")."""
    h = hashlib.sha256()
    n = 0
    try:
        if key.startswith("windows"):
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                try:
                    info = z.getinfo(member)
                except KeyError:
                    raise ValueError("archive")
                if info.is_dir():
                    raise ValueError("archive")
                src = z.open(info)
                with src:
                    for chunk in iter(lambda: src.read(1 << 20), b""):
                        n += len(chunk)
                        if n > limit:
                            raise ValueError("size")
                        h.update(chunk)
                        dest.write(chunk)
        else:
            with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
                ti = None
                for cand in (member, "./" + member):
                    try:
                        ti = tf.getmember(cand)
                        break
                    except KeyError:
                        continue
                if ti is None or not ti.isfile():
                    raise ValueError("archive")
                src = tf.extractfile(ti)
                if src is None:
                    raise ValueError("archive")
                with src:
                    for chunk in iter(lambda: src.read(1 << 20), b""):
                        n += len(chunk)
                        if n > limit:
                            raise ValueError("size")
                        h.update(chunk)
                        dest.write(chunk)
    except ValueError:
        raise
    except (tarfile.TarError, zipfile.BadZipFile, EOFError, OSError, RuntimeError):
        raise ValueError("archive")
    return n, h.hexdigest()


def _replace(tmp: Path, final: Path) -> None:
    """Atomic replace. On Windows a running agy.exe cannot be overwritten but can be renamed: it is moved aside first."""
    try:
        os.replace(tmp, final)
    except PermissionError:
        if not WIN or not final.exists():
            raise
        aside = final.with_name(".agy-old-%s.exe" % secrets.token_hex(4))
        os.replace(final, aside)
        try:
            os.replace(tmp, final)
        except OSError:
            os.replace(aside, final)
            raise
        try:
            aside.unlink()
        except OSError:
            pass   # still running: removed by a later install


def _sweep(d: Path) -> None:
    for p in d.glob(".agy-old-*"):
        try:
            p.unlink()
        except OSError:
            pass


def _already(root, pin: dict, key: str) -> bool:
    exe = agy_path(root, key)
    inst = installed_info(root)
    a = pin["assets"][key]
    try:
        return (exe.is_file() and inst.get("version") == pin["version"] and inst.get("key") == key
                and exe.stat().st_size == a["binary_size"] and _sha_file(exe) == a["binary_sha256"]
                and validate_pin(_read_json(agy_dir(root) / "agy-pin.json")) == pin)
    except Exception:
        return False


def install(root, pin, key: str, fetch: Callable[[str], bytes]) -> dict:
    """Installs the pinned program for `key` into <root>/engine/agy. Every check passes or NOTHING changes."""
    root = Path(root)
    try:
        pin = validate_pin(pin)
        if key not in pin["assets"]:
            raise ValueError("the pin has no program for %s" % key)
    except ValueError as e:
        return _fail("pin", str(e))
    a = pin["assets"][key]
    d = agy_dir(root)
    exe = agy_path(root, key)
    if _already(root, pin, key):
        return {"ok": True, "path": str(exe), "version": pin["version"], "unchanged": True}
    url = pin["url_template"].format(version=pin["version"], file=a["file"])
    try:
        data = fetch(url)
        if not isinstance(data, (bytes, bytearray)):
            raise OSError("no data")
    except Exception as e:
        return _fail("download", type(e).__name__)
    if len(data) != a["size"]:
        return _fail("size", "%d bytes, expected %d" % (len(data), a["size"]))
    if hashlib.sha256(data).hexdigest() != a["sha256"]:
        return _fail("checksum")
    temps = []
    made_dir = not d.exists()
    try:
        d.mkdir(parents=True, exist_ok=True)
        tmp_exe = d / (".agy-new-%s" % secrets.token_hex(6))
        temps.append(tmp_exe)
        with open(tmp_exe, "wb") as f:
            try:
                size, digest = _extract(bytes(data), key, a["member"], f, a["binary_size"])
            except ValueError as e:
                return _fail("size" if str(e) == "size" else "archive")
            f.flush()
            os.fsync(f.fileno())
        if size != a["binary_size"]:
            return _fail("size", "program %d bytes, expected %d" % (size, a["binary_size"]))
        if digest != a["binary_sha256"]:
            return _fail("checksum", "the program inside does not match")
        if not WIN:
            os.chmod(tmp_exe, 0o755)
        tmp_inst = d / (".installed-new-%s" % secrets.token_hex(6))
        temps.append(tmp_inst)
        tmp_inst.write_text(json.dumps({"version": pin["version"], "key": key, "binary_sha256": digest}, indent=1),
                            encoding="utf-8")
        tmp_pin = d / (".pin-new-%s" % secrets.token_hex(6))
        temps.append(tmp_pin)
        tmp_pin.write_text(json.dumps(pin, indent=1), encoding="utf-8")
        _replace(tmp_exe, exe)
        os.replace(tmp_inst, d / "installed.json")
        os.replace(tmp_pin, d / "agy-pin.json")
        _sweep(d)
    except OSError as e:
        return _fail("write", type(e).__name__)
    finally:
        for t in temps:
            try:
                if t.exists():
                    t.unlink()
            except OSError:
                pass
        try:
            if made_dir and d.is_dir() and not any(d.iterdir()):
                d.rmdir()
        except OSError:
            pass
    return {"ok": True, "path": str(exe), "version": pin["version"]}


# --- self-check --------------------------------------------------------------------------------------------------------
def _default_run(argv, env) -> Tuple[Optional[int], str]:
    work = tempfile.mkdtemp(prefix="qosha-agy-check-")
    kw: Dict[str, Any] = {}
    if WIN:
        kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    try:
        p = subprocess.run(list(argv), env=env, cwd=work, stdin=subprocess.DEVNULL, capture_output=True,
                           timeout=CHECK_TIMEOUT, shell=False, **kw)
        return p.returncode, (p.stdout + p.stderr).decode("utf-8", "replace")
    except subprocess.TimeoutExpired:
        return None, "timeout"
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _result(state: str, version: Optional[str], **kw) -> dict:
    return dict({"ok": state == "ok", "state": state, "plain": _PLAIN[state], "version": version}, **kw)


def self_check(root, run=None) -> dict:
    """Is Qosha's own agy present, the pinned version, unchanged, and does `agy models` answer? Never asks Gemini."""
    root = Path(root)
    pin_raw = _read_json(agy_dir(root) / "agy-pin.json")
    try:
        pin = validate_pin(pin_raw)
    except ValueError:
        return _result("missing", None)
    try:
        key = _key_for(root)
    except ValueError:
        return _result("missing", pin["version"])
    exe = agy_path(root, key)
    if key not in pin["assets"] or not exe.is_file():
        return _result("missing", pin["version"])
    inst = installed_info(root)
    if inst.get("version") != pin["version"]:
        return _result("wrong_version", inst.get("version") or None)
    try:
        if _sha_file(exe) != pin["assets"][key]["binary_sha256"]:
            return _result("tampered", pin["version"])
    except OSError:
        return _result("missing", pin["version"])
    try:
        rc, text = (run or _default_run)([str(exe), "models"], agy_env())
    except Exception:
        return _result("broken", pin["version"])
    low = (text or "").lower()
    if "please sign in" in low or "not logged in" in low:
        return _result("signed_out", pin["version"])
    # "ok" only when the tool ended normally (exit 0) AND printed at least one model line in Google's form. A time-out,
    # a non-zero exit (even with model lines before the error), no output, or error text is "broken".
    if rc != 0 or not has_model_line(text):
        return _result("broken", pin["version"])
    return _result("ok", pin["version"])


def has_model_line(text) -> bool:
    """True when `agy models` output holds at least one "<model-id><TAB><display name>" line."""
    return bool(_MODEL_LINE.search(text or ""))


def repair_pin(root):
    """The pin a Repair installs: the one this computer runs on, else the installer's copy (<root>/engine/agy-pin.json,
    for a first install that did not finish)."""
    for p in (agy_dir(root) / "agy-pin.json", Path(root) / "engine" / "agy-pin.json"):
        try:
            return validate_pin(_read_json(p))
        except ValueError:
            continue
    return None


def repair(root, fetch=None, run=None) -> dict:
    """Reinstalls the pinned version (same checks as the installer), then checks again."""
    root = Path(root)
    pin = repair_pin(root)
    if pin is None:
        return dict(self_check(root, run), repaired=False)
    try:
        key = _key_for(root)
    except ValueError as e:
        return dict(self_check(root, run), repaired=False, error="computer", detail=str(e))
    res = install(root, pin, key, fetch or default_fetch)
    out = dict(self_check(root, run), repaired=bool(res.get("ok")))
    if not res.get("ok"):
        out["error"] = res.get("error")
        out["install_plain"] = res.get("plain")
    return out


# --- command line (the installers) -------------------------------------------------------------------------------------
def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="Qosha's pinned Google Gemini tool (agy)")
    sp = ap.add_subparsers(dest="cmd", required=True)
    i = sp.add_parser("install")
    i.add_argument("--root", required=True)
    i.add_argument("--pin", required=True)
    i.add_argument("--key")
    i.add_argument("--archive", help="install from this local file instead of downloading")
    c = sp.add_parser("check")
    c.add_argument("--root", required=True)
    r = sp.add_parser("repair")
    r.add_argument("--root", required=True)
    a = ap.parse_args(argv)
    try:
        if a.cmd == "install":
            try:
                pin = load_pin(a.pin)
            except (OSError, ValueError) as e:
                res = _fail("pin", type(e).__name__ + ": " + str(e))
            else:
                try:
                    key = a.key if a.key else this_key()
                    if key not in KEYS:
                        raise ValueError("unknown key %r" % key)
                except ValueError as e:
                    res = _fail("pin", str(e))
                else:
                    if a.archive:
                        arch = a.archive
                        res = install(a.root, pin, key, lambda _url: Path(arch).read_bytes())
                    else:
                        res = install(a.root, pin, key, default_fetch)
        elif a.cmd == "check":
            res = self_check(a.root)
        else:
            res = repair(a.root)
    except Exception as e:   # an installer must finish whatever happens here
        res = _fail("internal", type(e).__name__)
    print(json.dumps(res))
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
