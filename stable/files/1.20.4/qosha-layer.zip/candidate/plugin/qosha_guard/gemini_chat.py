"""Gemini as a full Qosha chat model (CONTRACT G1, signed by Ren 9 Nov 2026; council decision G1-D1).

The engine can use an "ACP agent" as a chat model (its provider id is "copilot-acp", written for GitHub's Copilot
CLI): for every model step it starts a command and talks to it on stdin/stdout, and the engine itself runs every tool
the model asks for, behind the same guard, approval cards and audit log as for Claude and ChatGPT. In a Qosha box that
command is Qosha's relay (connector/qosha_gemini_acp.py), which only forwards the step to the box's Gemini helper; the
helper is the only program that holds the person's Gemini app sign-in (in its own Chrome) and uses nothing the
app does by itself (CONTRACT G3, 10 Nov 2026; before that, Google's agy).

    engine (this process)  --stdin/stdout-->  relay  --one-use ticket-->  Gemini helper  -->  the Gemini app's page

The engine's files are not edited. Everything here changes the RUNNING engine, only for provider "copilot-acp", and
only when the box says where the relay is (QOSHA_GEMINI_ACP_RELAY; without it nothing is touched, as on the desktop):

1. The command is always the relay. The engine takes the command from the environment (hermes_cli/auth.py:7507) and
   its own start-up clean-up removes those variables (hermes_cli/env_loader.py:76-83); a delegated task may also name
   its own ACP command (tools/delegate_tool.py:1865). Here the credentials, the client's defaults and every client at
   the moment it starts a step are pinned to [the engine's python, -I, the relay]. Nothing else can be started as
   "Gemini".
2. The relay's process gets five variables and nothing else: PATH, HOME, LANG, the helper's address and a single-use
   ticket (about 90 seconds, made here from the helper key). The engine would hand it its whole environment, provider
   keys included (agent/copilot_acp_client.py:_build_subprocess_env). The helper key itself never leaves this process.
3. What a person can read is plain words. A step that cannot run or outlasts its limit becomes an ordinary answer
   ("Gemini could not answer just now...", "Gemini took too long to answer...") instead of the engine's error that
   names Copilot; an ordinary answer is also what stops the engine from retrying on the person's plan or switching to
   another model.
4. Stop ends Gemini. The engine's Stop only closes network sockets (run_agent.py:5550); an ACP step has none, so the
   step would run on for up to 15 minutes. Here Stop also closes the ACP client: the relay ends, the helper sees the
   hang-up, stops the app's answer and drops the step. The stopped step ends as "Gemini was stopped." (an error the
   engine discards, never an answer in the chat). A Stop that finds no process yet still holds: the client the engine
   aborted never starts a step again (the engine builds a new client for the next request), and a process the engine
   starts after a Stop is ended the moment it is registered (GPT reviews R1 #3, R2 #3). The engine's "protected" side
   tasks (the summary of a long chat) run in a worker the engine abandons on a hard cancel
   (agent/auxiliary_client.py:579); here that cancel also ends that worker's own relay and its step in the app, and only those: each
   step is tracked by itself, because the engine shares one client between side tasks (GPT reviews R1 #1, R2 #2).
5. No other model answers for Gemini. The engine's "switch to the fallback model" answers no for a Gemini chat. Its
   side tasks (a chat's title, a summary when the chat gets long; agent/auxiliary_client.py) run on the chat's own
   model, so in a Gemini chat they run on Gemini through the same relay, told to report errors as errors (strict
   mode) so that "plan limit reached" is never taken for a title, and asked ONCE: the engine's "try streaming, then
   ask again without" (agent/auxiliary_client.py:_create_with_progress) is skipped for the relay, which never streams
   (GPT review R1 #4). When Gemini cannot do a side task the task FAILS:
   every step by which the engine would quietly move it to another provider (OpenRouter, an API key in the box, the
   configured fallback chain) yields nothing while the task belongs to a Gemini chat. A provider that is NAMED (the
   Council's seats, an explicit auxiliary setting) is not touched.
6. Pictures: the engine describes a picture with a side task on a vision model. Gemini through the app's page takes text only,
   so in a Gemini chat that task is refused at once in plain words instead of going to a paid model.
7. The model list is Gemini's two models, with no call to GitHub's catalog (hermes_cli/models.py:4043), the ids are
   kept as they are, and the context size is 300000 (council decision G1-D1/D6).
8. Every label the engine has for the provider says "Gemini" (never "Copilot"), and so does the engine's own account
   card for it on its settings page (hermes_cli/web_server.py:_OAUTH_PROVIDER_CATALOG: "GitHub Copilot (ACP)", the
   command `copilot /login`, a GitHub link): named Gemini, no command, no link, "managed by Qosha".
9. Gemini sees its own earlier tool calls. The engine's prompt for an ACP agent writes only each message's text
   (agent/copilot_acp_client.py:_format_messages_as_prompt): a step in which the assistant only called tools vanishes
   and a tool's result arrives without a word of which call made it. Here each earlier call is written into the
   transcript as the same <tool_call> block the model is told to write, and each result names its tool and call.

Known limits (reported to Ren): the ticket can be read from the relay's environment by a process of the same user
during the relay's short life; a box config that NAMES a provider for a side task (auxiliary.<task>.provider) is
respected in a Gemini chat as in any other (council G1-D2; the shipped config names none).

Fail-open: an engine without these names is left as it is. Like seatfirst.py, run_agent is never imported from here
(it holds the import lock while plugins load); its class is patched once it is in sys.modules."""
import asyncio
import contextvars
import functools
import hashlib
import hmac
import json
import logging
import os
import re
import sys
import threading
import time
import types

log = logging.getLogger("qosha.gemini_chat")

PROVIDER = "copilot-acp"                    # the engine's id for "an ACP agent is the model"
# CONTRACT G3 (10 Nov 2026): Gemini's models are the ones the person's own Gemini app offers. The helper reads them
# from the app's page and the screens hand the list here (set_models); an id is made from the model's name there
# ("4 Carbon" -> gemini-4-carbon). Which ids exist is the app's to say: a step on an id the app does not offer comes
# back in plain words from the helper.
MODEL_ID = re.compile(r"^gemini-[a-z0-9]+(?:[.-][a-z0-9]+){0,7}$")
LABEL = "Gemini"
DESCRIPTION = "Gemini (your Gemini app subscription, through Qosha)"
# The engine takes no model under 64,000 tokens (its MINIMUM_CONTEXT_LENGTH) and starts to shorten a chat at three
# quarters of the size given here. The app's own limit is lower and is the helper's to say ("too long", plain words).
CONTEXT = 64000
# ... and it may not raise its own 75% trigger by configuration (agent/context_compressor.py _effective_threshold_percent),
# so a Gemini chat would be shortened only at 48,000 tokens, past what the app was measured to answer (120,000
# characters a step). The engine's own absolute cap (threshold_tokens_cap) is set for Gemini chats only: its estimate
# counts the system prompt, the conversation and the tool list, at about four characters a token, so 26,000 tokens is
# about 104,000 characters (GPT review G3 R1 and R2, D-d).
COMPACT_AT = 26000
TICKET_LIFE = 90                            # seconds; the helper's own number (connector/box_gemini_helper.py)
BASE_URL = "acp://copilot"                  # the engine's own marker address for this provider (not a network address)

NOT_CONNECTED = "Gemini is not connected in this Qosha. Pick Claude or ChatGPT for this chat."
FAILED = "Gemini could not answer just now. Try again, or pick Claude or ChatGPT for this chat."
TOO_LONG = "Gemini took too long to answer. Try again, or pick Claude or ChatGPT for this chat."
NO_PICTURES = "Gemini in Qosha cannot look at pictures yet. Pick Claude or ChatGPT for this chat."
NOT_A_MODEL = "That is not one of the models your Gemini app offers. Pick Gemini again in the picker."
STOPPED = "Gemini was stopped."

MARK = "qosha_gemini_chat"
# One state for the whole process. This file is loaded twice in the screens' process (by the plugin's package and, by
# path, by the dashboard's own routes); both copies must see the same relay path and the same side-task marker, or a
# wrapper installed by one copy would not see what the other copy set.
_SHARED = sys.modules.setdefault("qosha_gemini_chat_state", types.ModuleType("qosha_gemini_chat_state"))
if not hasattr(_SHARED, "STATE"):
    _SHARED.STATE = {"relay": ""}           # the relay's path, pinned once from the box's environment
if "models" not in _SHARED.STATE:
    _SHARED.STATE["models"] = []            # the ids the person's Gemini app offers, as last told by the helper
    # Whose side task is running in this context: None (no side task), "gemini" (it belongs to a Gemini chat, or
    # names Gemini), "other".
    _SHARED.AUX = contextvars.ContextVar("qosha_gemini_aux", default=None)
if not hasattr(_SHARED, "ATTEMPT"):
    # The cancellable side-task attempt running in this context (an _Attempt), if any.
    _SHARED.ATTEMPT = contextvars.ContextVar("qosha_gemini_attempt", default=None)
if not hasattr(_SHARED, "RUN"):
    # The model step (a _Run) this context is running, if any; and one lock for the steps' book-keeping.
    _SHARED.RUN = contextvars.ContextVar("qosha_gemini_run", default=None)
    _SHARED.LOCK = threading.Lock()
if not hasattr(_SHARED, "OWNER"):
    # The chat (the engine's session id) the work in this context belongs to, when the engine does not say so itself
    # (its title thread); and, per chat, the Gemini steps running for it right now.
    _SHARED.OWNER = contextvars.ContextVar("qosha_gemini_owner", default=None)
    _SHARED.OWNED = {}
_STATE = _SHARED.STATE
_AUX = _SHARED.AUX
if not hasattr(_SHARED, "STOPS"):
    _SHARED.STOPS = {}                      # chat key -> when Stop was last pressed for it (time.monotonic())
    # when the engine scheduled the title request being made or run in this context (set while it is scheduled, and
    # carried into that request's own thread)
    _SHARED.SCHEDULED = contextvars.ContextVar("qosha_gemini_scheduled", default=None)
_OWNER = _SHARED.OWNER
_OWNED = _SHARED.OWNED
_STOPS = _SHARED.STOPS
_SCHEDULED = _SHARED.SCHEDULED
_KEEP = 3600.0                              # seconds a Stop is remembered: far longer than any step can wait to start
_ATTEMPT = _SHARED.ATTEMPT
_RUN = _SHARED.RUN
_LOCK = _SHARED.LOCK
_ENGINE_ERROR = "Copilot ACP session/prompt failed: "
_NOT_FOR_PEOPLE = ("Copilot", "Hermes", "ACP")
_ENGINE_MODULES = ("hermes_cli", "agent", "tui_gateway", "run_agent", "cli", "gateway", "tools")


def _for_the_log(text) -> str:
    """The engine's Logs page shows log lines to the person: the engine's name for the provider is written as Gemini's
    relay there (found by the box gate's no-engine-name sweep)."""
    return re.sub(r"(?i)(github[ _-]?)?copilot([ _-]?acp)?", "gemini-relay", str(text))


def _norm(value) -> str:
    return str(value or "").strip().lower()


def _is_gemini(provider) -> bool:
    """The engine's id for the provider, under any name the engine itself maps to it (GPT review R2 #7)."""
    name = _norm(provider)
    if name == PROVIDER:
        return True
    if not name:
        return False
    models = sys.modules.get("hermes_cli.models")
    try:
        return _norm(models.normalize_provider(name)) == PROVIDER
    except Exception:
        return False


def _command():
    return sys.executable


def _args():
    return ["-I", _STATE["relay"]]


def _helper_key() -> str:
    """The helper key: the dashboard moves it out of the environment into the council's private store at start."""
    key = ""
    mod = sys.modules.get("qosha_council_integration")
    try:
        key = mod.gemini_helper_key() if mod is not None else ""
    except Exception:
        key = ""
    return key or os.environ.get("QOSHA_GEMINI_HELPER_KEY", "")


def make_ticket(key: str, now=None) -> str:
    """A single-use ticket for one model step, in the helper's own format (box_gemini_helper.make_ticket)."""
    exp = int((time.time() if now is None else now) + TICKET_LIFE)
    nonce = os.urandom(16).hex()
    mac = hmac.new(key.encode(), ("qosha-gemini-chat|%d|%s" % (exp, nonce)).encode(), hashlib.sha256).hexdigest()
    return "%d.%s.%s" % (exp, nonce, mac)


def _in_gemini() -> bool:
    """True while the work in this context belongs to a Gemini chat: a side task marked so, or (outside a side task)
    the turn the engine bound to this context. Never the engine's process-wide copy: another chat may have written it."""
    kind = _AUX.get()
    if kind is not None:
        return kind == "gemini"
    aux = sys.modules.get("agent.auxiliary_client")
    try:
        runtime = aux._RUNTIME_MAIN_CONTEXT.get()
    except Exception:
        return False
    return isinstance(runtime, dict) and _is_gemini(runtime.get("provider"))


def _work():
    """(the chat keys, when it began) of the work in this context. Named by the plugin for the engine's title thread;
    otherwise the turn the engine bound to this context. A chat has several keys, because the engine changes a chat's
    id when it shortens a long chat mid-turn: the id, the chat's lasting "scope" id, and the agent itself."""
    named = _OWNER.get()
    if named:
        return named
    aux = sys.modules.get("agent.auxiliary_client")
    try:
        runtime = aux._RUNTIME_MAIN_CONTEXT.get()
    except Exception:
        return set(), None
    if not isinstance(runtime, dict):
        return set(), None
    keys = set()
    if runtime.get("session_id"):
        keys.add("chat:%s" % runtime.get("session_id"))
    if runtime.get("cache_scope"):
        keys.add("scope:%s" % runtime.get("cache_scope"))
    return keys, runtime.get("_qosha_born")


def _agent_keys(agent) -> set:
    keys = {"agent:%d" % id(agent)}
    sid = getattr(agent, "session_id", "")
    if sid:
        keys.add("chat:%s" % sid)
    scope_of = getattr(sys.modules.get("agent.prompt_cache_scope"), "resolve_prompt_cache_scope_safe", None)
    try:
        scope = scope_of(agent) if scope_of is not None else None
    except Exception:
        scope = None
    if scope:
        keys.add("scope:%s" % scope)
    return keys


def _is_acp(client) -> bool:
    mod = sys.modules.get("agent.copilot_acp_client")
    cls = getattr(mod, "CopilotACPClient", None)
    try:
        return cls is not None and isinstance(client, cls)
    except Exception:
        return False


# ── patching helpers ────────────────────────────────────────────────────────────────────────────────────────────────

def _rebind(name, orig, new):
    """Engine modules that imported the function BY NAME keep the old one: point those at the new one too."""
    for modname, mod in list(sys.modules.items()):
        if mod is None or not modname.startswith(_ENGINE_MODULES):
            continue
        try:
            if vars(mod).get(name) is orig:
                setattr(mod, name, new)
        except Exception:
            continue


def _wrap(mod, name, make, changed):
    orig = vars(mod).get(name) if mod is not None else None
    if not callable(orig) or getattr(orig, MARK, False):
        return
    new = functools.wraps(orig)(make(orig))
    setattr(new, MARK, True)
    setattr(mod, name, new)
    _rebind(name, orig, new)
    changed.append("%s.%s" % (mod.__name__, name))


def _wrap_method(cls, name, make, changed, label):
    orig = vars(cls).get(name) if cls is not None else None
    if not callable(orig) or getattr(orig, MARK, False):
        return
    new = functools.wraps(orig)(make(orig))
    setattr(new, MARK, True)
    setattr(cls, name, new)
    changed.append("%s.%s" % (label, name))


def _load(name):
    try:
        __import__(name)
    except Exception as e:
        log.warning("Gemini chat: the engine module %s is not available: %s", _for_the_log(name), type(e).__name__)
        return None
    return sys.modules.get(name)


# ── 1. the command is always the relay ──────────────────────────────────────────────────────────────────────────────

def _patch_credentials(auth, changed):
    def make_resolver(orig):
        def resolve(provider_id, *a, **k):
            if not _is_gemini(provider_id):
                return orig(provider_id, *a, **k)
            _apply_late()
            return {"provider": PROVIDER, "api_key": PROVIDER, "base_url": BASE_URL, "command": _command(),
                    "args": _args(), "source": "process"}
        return resolve

    def make_status(orig):
        def status(provider_id, *a, **k):
            if not _is_gemini(provider_id):
                return orig(provider_id, *a, **k)
            return {"configured": True, "provider": PROVIDER, "name": LABEL, "command": _command(), "args": _args(),
                    "resolved_command": _command(), "base_url": BASE_URL, "logged_in": True}
        return status

    _wrap(auth, "resolve_external_process_provider_credentials", make_resolver, changed)
    _wrap(auth, "get_external_process_provider_status", make_status, changed)


# ── 2-3. the relay's environment, plain words, and the pinned command at the moment a step starts ───────────────────

def _child_env():
    env = {"PATH": os.environ.get("PATH") or "/usr/local/bin:/usr/bin:/bin",
           "HOME": os.environ.get("HOME") or "/",
           "LANG": os.environ.get("LANG") or "C.UTF-8",
           "QOSHA_GEMINI_HELPER_URL": os.environ.get("QOSHA_GEMINI_HELPER_URL", ""),
           "QOSHA_GEMINI_CHAT_TICKET": ""}
    key = _helper_key()
    if key:
        env["QOSHA_GEMINI_CHAT_TICKET"] = make_ticket(key)
    if _AUX.get() is not None:
        env["QOSHA_GEMINI_RELAY_STRICT"] = "1"          # a side task: errors come back as errors
    return env


def _plain_words(error, elapsed, limit, strict) -> str:
    text = str(error)
    if strict and _ENGINE_ERROR in text:
        tail = text.split(_ENGINE_ERROR, 1)[1].strip()
        if tail and not any(w in tail for w in _NOT_FOR_PEOPLE):
            return tail                                  # the relay's own plain words (a plan limit, not signed in)
    try:
        timed_out = isinstance(error, TimeoutError) and float(limit) > 0 and elapsed >= float(limit) - 1.0
    except (TypeError, ValueError):
        timed_out = False
    return TOO_LONG if timed_out else FAILED


def _field(obj, name):
    return obj.get(name) if isinstance(obj, dict) else getattr(obj, name, None)


def _with_tool_calls(messages):
    """A copy of the chat for the engine's prompt builder, with what it leaves out written into the text: each tool
    call the assistant made (as the same <tool_call> block the model is told to write) and, on each tool result, which
    call it answers. The list handed in is not changed."""
    out, names, made = [], {}, [0]
    for message in messages if isinstance(messages, (list, tuple)) else []:      # ids already in use are never made up
        for call in (message.get("tool_calls") or []) if isinstance(message, dict) else []:
            given = _field(call, "id")
            if isinstance(given, str) and given.strip():
                names.setdefault(" ".join(given.split()), "")
        given = message.get("tool_call_id") if isinstance(message, dict) else None
        if isinstance(given, str) and given.strip():                              # a result whose call was trimmed away
            names.setdefault(" ".join(given.split()), "")

    def one_line(value):
        return " ".join(str(value).split())              # a name or id can never start a new line in the transcript

    def new_id():
        while True:
            made[0] += 1
            if "call_%d" % made[0] not in names:
                return "call_%d" % made[0]
    for message in messages if isinstance(messages, (list, tuple)) else []:
        if not isinstance(message, dict):
            out.append(message)
            continue
        role = _norm(message.get("role"))
        calls = message.get("tool_calls")
        if role == "assistant" and isinstance(calls, (list, tuple)) and calls:
            blocks = []
            for call in calls:
                fn = _field(call, "function")
                name = _field(fn, "name") if fn is not None else None
                if not isinstance(name, str) or not name.strip():
                    continue
                args = _field(fn, "arguments")
                if not isinstance(args, str):
                    try:
                        args = json.dumps({} if args is None else args, ensure_ascii=False)
                    except (TypeError, ValueError):
                        args = "{}"
                name = one_line(name)
                call_id = _field(call, "id")
                call_id = one_line(call_id) if isinstance(call_id, str) and call_id.strip() else new_id()
                names[call_id] = name
                # "</" is written "<\/" (the same text to any JSON reader), so nothing inside a call can close its block
                blocks.append("<tool_call>" + json.dumps(
                    {"id": call_id, "type": "function", "function": {"name": name, "arguments": args}},
                    ensure_ascii=False).replace("</", "<\\/") + "</tool_call>")
            if blocks:
                text = _plain_text(message.get("content"))
                message = dict(message, content="\n".join(([text] if text else []) + blocks))
        elif role == "tool":
            call_id = message.get("tool_call_id")
            call_id = one_line(call_id) if isinstance(call_id, str) and call_id.strip() else ""
            name = message.get("name") if isinstance(message.get("name"), str) and message.get("name").strip() else None
            name = one_line(name or names.get(call_id) or "a tool")
            head = "Result of %s%s:" % (name, " (%s)" % call_id if call_id else "")
            message = dict(message, content=head + "\n" + _plain_text(message.get("content")))
        out.append(message)
    return out


def _plain_text(content) -> str:
    """A message's text, read the way the engine's own prompt builder reads it."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, dict):
        if isinstance(content.get("text"), str):
            return content["text"].strip()
        if isinstance(content.get("content"), str):
            return content["content"].strip()
        return json.dumps(content, ensure_ascii=True)
    if isinstance(content, (list, tuple)):
        parts = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and isinstance(item.get("text"), str) and item["text"].strip():
                parts.append(item["text"].strip())
        return "\n".join(parts).strip()
    return str(content).strip()


def _patch_acp_client(acp, changed):
    def make_prompt(orig):
        def format_messages_as_prompt(messages, *a, **k):
            try:
                messages = _with_tool_calls(messages)
            except Exception as e:                       # the engine's own transcript is still a working one
                log.warning("Gemini chat: the earlier tool calls could not be written out: %s", type(e).__name__)
            return orig(messages, *a, **k)
        return format_messages_as_prompt

    _wrap(acp, "_format_messages_as_prompt", make_prompt, changed)
    _wrap(acp, "_resolve_command", lambda orig: (lambda *a, **k: _command()), changed)
    _wrap(acp, "_resolve_args", lambda orig: (lambda *a, **k: _args()), changed)
    _wrap(acp, "_build_subprocess_env", lambda orig: (lambda *a, **k: _child_env()), changed)

    def make_run_prompt(orig):
        def run_prompt(self, prompt_text, *a, **k):
            run = _Run()
            attempt = _ATTEMPT.get()
            keys, born = _work()
            with _LOCK:
                # stopped before it started: the engine aborted this client's request, or Stop was pressed in this
                # chat after this piece of work began (a title thread that only now gets to its request)
                aborted = self.__dict__.get("_qosha_aborted", False) or (
                    born is not None and any(_STOPS.get(key, -1.0) >= born for key in keys))
                if not aborted:
                    self.__dict__.setdefault("_qosha_runs", []).append(run)
                    for key in keys:
                        _OWNED.setdefault(key, []).append(run)
            if aborted:
                raise RuntimeError(STOPPED)
            token = _RUN.set(run)
            started = time.monotonic()
            try:
                if attempt is not None and not attempt.add(run):
                    raise RuntimeError(STOPPED)          # the side task was cancelled before this step began
                self._acp_command, self._acp_args = _command(), _args()
                strict = _AUX.get() is not None
                limit = k.get("timeout_seconds", a[0] if a else 0)
                try:
                    out = orig(self, prompt_text, *a, **k)
                except Exception as e:
                    if run.stopped:
                        raise RuntimeError(STOPPED) from None
                    words = _plain_words(e, time.monotonic() - started, limit, strict)
                    log.warning("Gemini step did not finish (%s): %s", type(e).__name__, _for_the_log(str(e)[:300]))
                    try:
                        status = run.last.poll() if run.last is not None else None
                    except Exception:
                        status = None
                    if status is not None and status < 0 and -status not in (15, 9):
                        # not the engine's own close (15) or kill (9): the relay crashed (on an emulated box: the emulator)
                        log.warning("Gemini step: the relay ended by signal %d", -status)
                    if strict:
                        # A plain RuntimeError on purpose: the engine reads a TimeoutError type as "try another provider".
                        raise RuntimeError(words) from None
                    return words, ""
                if run.stopped:
                    raise RuntimeError(STOPPED)
                return out
            finally:
                _RUN.reset(token)
                with _LOCK:
                    runs = self.__dict__.get("_qosha_runs") or []
                    if run in runs:
                        runs.remove(run)
                    for key in keys:
                        mine = _OWNED.get(key) or []
                        if run in mine:
                            mine.remove(run)
                        if key in _OWNED and not mine:
                            del _OWNED[key]
        return run_prompt

    cls = getattr(acp, "CopilotACPClient", None)
    _wrap_method(cls, "_run_prompt", make_run_prompt, changed, "agent.copilot_acp_client.CopilotACPClient")
    if cls is not None and not isinstance(vars(cls).get("_active_process"), property):
        # The engine keeps ONE process per client (`self._active_process = proc`; close() ends it) and shares one
        # client between side tasks: the end of one step would end another step's process, and a Stop that lands
        # between a step's start and that line finds nothing to close. Here each step (a _Run, bound to the thread
        # that runs it) has its own process: inside a step the client's "active process" is that step's own, and a
        # process registered after its step was stopped is ended at once (GPT reviews R1 #3, R2 #2).
        def get_process(self):
            run = _RUN.get()
            if run is not None:
                return run.proc
            return self.__dict__.get("_qosha_active_process", self.__dict__.get("_active_process"))

        def set_process(self, proc):
            run = _RUN.get()
            if run is None:
                self.__dict__["_qosha_active_process"] = proc
            elif proc is None:
                with run.lock:
                    run.proc = None
            else:
                run.register(proc)

        def make_close(orig):
            def close(self, *a, **k):
                if _RUN.get() is None:                   # closed from outside its steps: every step it runs ends
                    with _LOCK:
                        runs = list(self.__dict__.get("_qosha_runs") or [])
                    for run in runs:
                        run.stop()
                return orig(self, *a, **k)
            return close
        _wrap_method(cls, "close", make_close, changed, "agent.copilot_acp_client.CopilotACPClient")
        cls._active_process = property(get_process, set_process)
        changed.append("agent.copilot_acp_client.CopilotACPClient._active_process")


# ── 4-5. Stop, and no model fallback (the agent class; patched once run_agent is loaded) ────────────────────────────

class _Run:
    """One model step: one relay process. The engine shares one client between side tasks, so a stop is kept per
    step, never per client (GPT review R2 #2)."""

    def __init__(self):
        self.lock, self.proc, self.stopped, self.last = threading.Lock(), None, False, None

    def register(self, proc):
        with self.lock:
            self.proc = self.last = proc
            stop = self.stopped
        if stop:
            _end(proc)                                   # started after its Stop: ended at once

    def stop(self):
        with self.lock:
            self.stopped = True
            proc = self.proc
        if proc is not None:
            _end(proc)                                   # the relay ends; the helper stops the step


def _end(proc):
    try:
        proc.terminate()
    except Exception:
        pass


def _stop_client(client):
    """The engine stopped this client's request (Stop in a chat): every step it is running ends, and it never starts
    another (the engine builds a new client for the next request)."""
    try:
        with _LOCK:
            client.__dict__["_qosha_aborted"] = True
            runs = list(client.__dict__.get("_qosha_runs") or [])
        for run in runs:
            run.stop()
        client.close()
    except Exception as e:
        log.warning("Gemini chat: closing the stopped step failed: %s", type(e).__name__)


def _stop_chat(agent):
    """Stop in a chat ends every Gemini step running for that chat, its side tasks too (the engine names a new chat on
    a thread of its own while the first answer is made), and work of that chat that began before the Stop never
    starts a step afterwards. Other chats are not touched (GPT reviews R3 #1, R4 #1-#3)."""
    try:
        keys = _agent_keys(agent)
        with _LOCK:
            now = time.monotonic()                       # read under the lock: a later Stop is never overwritten
            runs = []
            for key in keys:
                _STOPS[key] = max(now, _STOPS.get(key, now))
                runs += [r for r in (_OWNED.get(key) or []) if r not in runs]
            for key in [k for k, at in _STOPS.items() if now - at > _KEEP]:   # by age only: nothing that old can
                del _STOPS[key]                                               # still be waiting to start
        for run in runs:
            run.stop()
    except Exception as e:
        log.warning("Gemini chat: stopping the chat's steps failed: %s", type(e).__name__)


class _Attempt:
    """The steps one cancellable side-task attempt has started, so that its cancel ends exactly those."""

    def __init__(self):
        self.lock, self.runs, self.stopped = threading.Lock(), [], False

    def add(self, run) -> bool:
        with self.lock:
            if self.stopped:
                return False
            self.runs.append(run)
            return True

    def stop(self):
        with self.lock:
            self.stopped = True
            runs = list(self.runs)
        for run in runs:
            run.stop()


def _patch_agent(changed):
    mod = sys.modules.get("run_agent")
    cls = getattr(mod, "AIAgent", None) if mod is not None else None
    if cls is None:
        return

    def make_abort(orig):
        def abort(self, client, *a, **k):
            if _is_acp(client):
                _stop_client(client)                     # this request only; the chat's side tasks: see interrupt
            return orig(self, client, *a, **k)
        return abort

    def make_interrupt(orig):
        def interrupt(self, *a, **k):
            # Stop (the engine's hard interrupt) and only Stop: an ordinary interrupt (a new message arriving) leaves
            # the chat's side tasks alone, as the engine itself does (GPT review R5 #3). Stop while a tool runs has no
            # model request to abort, so it is caught here, at the engine's own entry point.
            if k.get("hard_cancel"):
                _stop_chat(self)
            return orig(self, *a, **k)
        return interrupt

    def make_fallback(orig):
        def fallback(self, *a, **k):
            if _is_gemini(getattr(self, "provider", "")):
                return False
            return orig(self, *a, **k)
        return fallback

    _wrap_method(cls, "_abort_request_openai_client", make_abort, changed, "run_agent.AIAgent")
    _wrap_method(cls, "interrupt", make_interrupt, changed, "run_agent.AIAgent")
    _wrap_method(cls, "_try_activate_fallback", make_fallback, changed, "run_agent.AIAgent")


def _patch_gateway(changed):
    """The screens' process only. The gateway's Stop helper tells the agent only while it counts the chat as running;
    a Stop that arrives just after the answer finished would not reach the chat's title request, which may still be
    running. Here the helper itself ends the chat's Gemini steps, running or not (GPT review R6 #2)."""
    gateway = sys.modules.get("tui_gateway.server")
    if gateway is None:
        return

    def make(orig):
        def interrupt_session_turn(sid, session, *a, **k):
            try:
                agent = session.get("agent") if isinstance(session, dict) else None
                if agent is not None:
                    _stop_chat(agent)
            except Exception as e:
                log.warning("Gemini chat: stopping the chat from the gateway failed: %s", type(e).__name__)
            return orig(sid, session, *a, **k)
        return interrupt_session_turn

    _wrap(gateway, "_interrupt_session_turn", make, changed)


def _patch_fallback_helper(changed):
    mod = sys.modules.get("agent.chat_completion_helpers")
    if mod is None:
        return

    def make(orig):
        def try_activate_fallback(agent, *a, **k):
            if _is_gemini(getattr(agent, "provider", "")):
                return False
            return orig(agent, *a, **k)
        return try_activate_fallback

    _wrap(mod, "try_activate_fallback", make, changed)


# ── 5-6. side tasks never move to another provider; pictures are refused ────────────────────────────────────────────

class _AsyncGemini:
    """The engine's async side-task path hands back its SYNC ACP client; this gives it the async shape it awaits."""

    def __init__(self, sync):
        self._qosha_sync = sync
        self.chat = types.SimpleNamespace(completions=types.SimpleNamespace(create=self._create))

    async def _create(self, **kwargs):
        attempt = _Attempt()
        token = _ATTEMPT.set(attempt)                    # the worker thread copies this context
        try:
            return await asyncio.to_thread(self._qosha_sync.chat.completions.create, **kwargs)
        except asyncio.CancelledError:
            attempt.stop()                               # a cancelled side task must not keep its step running
            raise
        finally:
            _ATTEMPT.reset(token)

    def close(self):
        # Nothing to close: the client under this wrapper is the engine's shared one and holds no connection between
        # steps; closing it here would end other side tasks' steps (Gemini review R3 #1).
        return None

    def __getattr__(self, name):
        if name.startswith("__") or name == "_qosha_sync":
            raise AttributeError(name)
        return getattr(self._qosha_sync, name)


def _aux_kind(aux, task, provider, model, base_url, api_key, main_runtime):
    """Where the engine will send this side task: "gemini" when it names Gemini or follows a Gemini chat."""
    try:
        resolved = _norm(aux._resolve_task_provider_model(task, provider, model, base_url, api_key)[0])
    except Exception:
        resolved = _norm(provider)
    if _is_gemini(resolved):
        return "gemini"
    if resolved not in ("", "auto"):
        return "other"
    try:
        main = aux._normalize_main_runtime(main_runtime).get("provider") or aux._read_main_provider()
    except Exception:
        return "gemini" if _in_gemini() else "other"
    return "gemini" if _is_gemini(main) else "other"


def _patch_side_tasks(aux, changed):
    def kind_of(args, kwargs):
        task = kwargs.get("task", args[0] if args else None)
        return task, _aux_kind(aux, task, kwargs.get("provider"), kwargs.get("model"), kwargs.get("base_url"),
                               kwargs.get("api_key"), kwargs.get("main_runtime"))

    def make_impl(orig):
        def impl(*args, **kwargs):
            task, kind = kind_of(args, kwargs)
            token = _AUX.set(kind)
            try:
                if kind == "gemini" and task == "vision":
                    raise RuntimeError(NO_PICTURES)
                return orig(*args, **kwargs)
            finally:
                _AUX.reset(token)
        return impl

    def make_async_impl(orig):
        async def impl(*args, **kwargs):
            task, kind = kind_of(args, kwargs)
            token = _AUX.set(kind)
            try:
                if kind == "gemini" and task == "vision":
                    raise RuntimeError(NO_PICTURES)
                return await orig(*args, **kwargs)
            finally:
                _AUX.reset(token)
        return impl

    def gate(nothing):
        def make(orig):
            def gated(*args, **kwargs):
                if _in_gemini():
                    return nothing()
                return orig(*args, **kwargs)
            return gated
        return make

    def make_to_async(orig):
        def to_async(sync_client, model, *args, **kwargs):
            if _is_acp(sync_client):
                return _AsyncGemini(sync_client), model
            return orig(sync_client, model, *args, **kwargs)
        return to_async

    def make_protected(orig):
        def run_protected_sync_provider_call(callback, kwargs, *a, **k):
            if _AUX.get() != "gemini":
                return orig(callback, kwargs, *a, **k)
            attempt = _Attempt()
            token = _ATTEMPT.set(attempt)                # the engine's worker copies this context
            try:
                return orig(callback, kwargs, *a, **k)
            except BaseException:
                # the engine's cancel abandons its worker; whatever ended the call, a step still running for this
                # attempt is ended (after a normal error none is left, so this changes nothing then)
                attempt.stop()
                raise
            finally:
                _ATTEMPT.reset(token)
        return run_protected_sync_provider_call

    def make_streams_internally(orig):
        def client_streams_internally(client, *a, **k):
            if _is_acp(client) or getattr(client, "_qosha_sync", None) is not None:
                return True                              # one plain request: no streamed try, no second ask
            return orig(client, *a, **k)
        return client_streams_internally

    _wrap(aux, "_run_protected_sync_provider_call", make_protected, changed)
    _wrap(aux, "_client_streams_internally", make_streams_internally, changed)
    _wrap(aux, "_call_llm_impl", make_impl, changed)
    _wrap(aux, "_async_call_llm_impl", make_async_impl, changed)
    _wrap(aux, "_get_provider_chain", gate(list), changed)
    for name in ("_try_configured_fallback_chain", "_try_main_fallback_chain", "_try_main_agent_model_fallback",
                 "_try_payment_fallback"):
        _wrap(aux, name, gate(lambda: (None, None, "")), changed)
    _wrap(aux, "_resolve_strict_vision_backend", gate(lambda: (None, None)), changed)
    _wrap(aux, "_to_async_client", make_to_async, changed)


def _patch_title(title, changed):
    """The engine names a chat on a thread of its own, which carries no word of which chat it works for. Here that
    thread's work is tied to its chat (its id, and the agent whose callback the engine hands the thread) and to the
    moment it began, so that Stop in the chat ends it or keeps it from starting (see _stop_chat)."""
    def make(orig):
        def auto_title_session(session_db, session_id, *a, **k):
            keys = {"chat:%s" % session_id} if session_id else set()
            for callback in (k.get("failure_callback"), k.get("title_callback"), a[1] if len(a) > 1 else None):
                owner = getattr(callback, "__self__", None)
                if owner is not None:
                    keys.add("agent:%d" % id(owner))
            born = _SCHEDULED.get()                      # when the engine scheduled THIS request (see below)
            token = _OWNER.set((keys, time.monotonic() if born is None else born))
            try:
                return orig(session_db, session_id, *a, **k)
            finally:
                _OWNER.reset(token)
        return auto_title_session

    def make_schedule(orig):
        def maybe_auto_title(session_db, session_id, *a, **k):
            # the request is dated from here, where the engine schedules it: a Stop that lands before its thread
            # first runs still counts as "after it began". The date travels with the thread the engine makes inside
            # this call (see _TitleThreads), so it belongs to that one request (GPT reviews R5 #1, R6 #1).
            token = _SCHEDULED.set(time.monotonic())
            try:
                return orig(session_db, session_id, *a, **k)
            finally:
                _SCHEDULED.reset(token)
        return maybe_auto_title

    class _TitleThreads:
        """What the engine's title code sees as `threading`: the real module, except that a thread made while a
        title request is being scheduled carries that request's date into its own run. Nothing else of the maker's
        context is carried (the engine starts that thread bare on purpose)."""
        qosha_gemini_chat = True

        def __init__(self, real):
            self._real = real

        def __getattr__(self, name):
            return getattr(self._real, name)

        def Thread(self, *a, **k):
            born, target = _SCHEDULED.get(), k.get("target")
            if born is not None and callable(target):
                def run(*ta, **tk):
                    token = _SCHEDULED.set(born)
                    try:
                        return target(*ta, **tk)
                    finally:
                        _SCHEDULED.reset(token)
                k = dict(k, target=run)
            return self._real.Thread(*a, **k)

    real = vars(title).get("threading")
    if real is not None and not getattr(real, MARK, False):
        title.threading = _TitleThreads(real)
        changed.append("agent.title_generator.threading")
    _wrap(title, "auto_title_session", make, changed)
    _wrap(title, "maybe_auto_title", make_schedule, changed)


def _patch_turn(aux, changed):
    """Each turn's binding gets the moment it began, so that work of a stopped turn can be told from the next turn's."""
    def make(orig):
        def set_runtime_main(*a, **k):
            token = orig(*a, **k)
            try:
                runtime = aux._RUNTIME_MAIN_CONTEXT.get()
                if isinstance(runtime, dict):
                    runtime["_qosha_born"] = time.monotonic()
            except Exception:
                pass
            return token
        return set_runtime_main

    _wrap(aux, "set_runtime_main", make, changed)


# ── 7-8. the model list and the labels ──────────────────────────────────────────────────────────────────────────────

def set_models(ids) -> None:
    """The ids the person's Gemini app offers (from the helper's status, through the screens). Only well-formed ids."""
    _SHARED.STATE["models"] = [m for m in (ids or []) if isinstance(m, str) and MODEL_ID.match(m)][:12]


def known_models() -> list:
    return list(_SHARED.STATE.get("models") or [])


def is_model(value) -> bool:
    return bool(MODEL_ID.match(str(value or "").strip()))


def _patch_catalog(models, changed):
    def provider_of(value):
        try:
            return _norm(models.normalize_provider(value))
        except Exception:
            return _norm(value)

    def make_ids(orig):
        def provider_model_ids(provider, *a, **k):
            if provider_of(provider) == PROVIDER:
                return known_models()
            return orig(provider, *a, **k)
        return provider_model_ids

    def make_validate(orig):
        def validate_requested_model(model_name, provider, *a, **k):
            if provider_of(provider) != PROVIDER:
                return orig(model_name, provider, *a, **k)
            if is_model(model_name):         # the app says whether it offers it, at the step, in plain words
                return {"accepted": True, "persist": True, "recognized": str(model_name).strip() in known_models(),
                        "message": None}
            return {"accepted": False, "persist": False, "recognized": False, "message": NOT_A_MODEL}
        return validate_requested_model

    def make_context(orig):
        def get_copilot_model_context(model_id, *a, **k):
            if is_model(model_id):
                return CONTEXT
            return orig(model_id, *a, **k)
        return get_copilot_model_context

    def make_normalize(orig):
        def normalize_copilot_model_id(model_id, *a, **k):
            raw = str(model_id or "").strip()
            if is_model(raw):
                return raw
            return orig(model_id, *a, **k)
        return normalize_copilot_model_id

    _wrap(models, "provider_model_ids", make_ids, changed)
    _wrap(models, "validate_requested_model", make_validate, changed)
    _wrap(models, "get_copilot_model_context", make_context, changed)
    _wrap(models, "normalize_copilot_model_id", make_normalize, changed)


def _patch_labels(auth, models, providers):
    done = False
    try:
        cfg = auth.PROVIDER_REGISTRY.get(PROVIDER) if auth is not None else None
        if cfg is not None and getattr(cfg, "name", LABEL) != LABEL:
            cfg.name = LABEL
            done = True
    except Exception as e:
        log.warning("Gemini chat: the provider's name could not be set: %s", type(e).__name__)
    if models is not None:
        try:
            entries = models.CANONICAL_PROVIDERS
            for i, entry in enumerate(list(entries)):
                if getattr(entry, "slug", None) == PROVIDER and getattr(entry, "label", None) != LABEL:
                    entries[i] = type(entry)(PROVIDER, LABEL, DESCRIPTION)
                    done = True
        except Exception as e:
            log.warning("Gemini chat: the model list's entry could not be set: %s", type(e).__name__)
        try:                                              # on its own: one label failing never skips another
            labels = getattr(models, "_PROVIDER_LABELS", None)
            if isinstance(labels, dict) and labels.get(PROVIDER) != LABEL:
                labels[PROVIDER] = LABEL
                done = True
        except Exception as e:
            log.warning("Gemini chat: the model list's label could not be set: %s", type(e).__name__)
    if providers is not None:
        try:
            overrides = getattr(providers, "_LABEL_OVERRIDES", None)
            if isinstance(overrides, dict) and overrides.get(PROVIDER) != LABEL:
                overrides[PROVIDER] = LABEL
                done = True
        except Exception as e:
            log.warning("Gemini chat: the label override could not be set: %s", type(e).__name__)
    return done


def _account_status():
    """The engine's account card for the provider: no sign-in state is claimed here (Qosha's own pages show whether
    Gemini is connected)."""
    return {"logged_in": False, "source": "qosha", "source_label": "Managed by Qosha, on your Google AI plan",
            "token_preview": None, "expires_at": None, "has_refresh_token": False}


def _patch_account_card(changed):
    """The screens' process only (never imported from here: hermes_cli.web_server is the dashboard itself)."""
    ws = sys.modules.get("hermes_cli.web_server")
    for card in getattr(ws, "_OAUTH_PROVIDER_CATALOG", None) or ():
        if isinstance(card, dict) and card.get("id") == PROVIDER and card.get("name") != LABEL:
            card.update({"name": LABEL, "cli_command": "", "docs_url": "", "status_fn": _account_status})
            changed.append("hermes_cli.web_server.account_card")


# ── apply ───────────────────────────────────────────────────────────────────────────────────────────────────────────

def _apply_late(changed=None):
    """The parts that live in modules the plugin must not import itself."""
    changed = [] if changed is None else changed
    try:
        _patch_agent(changed)
        _patch_fallback_helper(changed)
        _patch_account_card(changed)
        _patch_gateway(changed)
    except Exception as e:
        log.warning("Gemini chat: the agent patches could not be applied: %s", type(e).__name__)
    return changed


def _patch_compressor(cc, changed):
    def make(orig):
        def _apply_threshold_tokens_cap(self, *a, **k):
            out = orig(self, *a, **k)
            try:
                if is_model(getattr(self, "model", "")) and _is_gemini(getattr(self, "provider", "")):
                    if self.threshold_tokens > COMPACT_AT:
                        self.threshold_tokens = COMPACT_AT
            except Exception:
                pass
            return out
        return _apply_threshold_tokens_cap
    _wrap_method(getattr(cc, "ContextCompressor", None), "_apply_threshold_tokens_cap", make, changed,
                 "agent.context_compressor.ContextCompressor")


def apply():
    """Patch the running engine. Safe to call again and again; returns the names patched by THIS call."""
    relay = _STATE["relay"] or (os.environ.get("QOSHA_GEMINI_ACP_RELAY") or "").strip()
    if not relay:
        return []                                         # not a box with the relay (the desktop): touch nothing
    _STATE["relay"] = relay
    changed = []
    auth, models, providers = _load("hermes_cli.auth"), _load("hermes_cli.models"), _load("hermes_cli.providers")
    aux, acp = _load("agent.auxiliary_client"), _load("agent.copilot_acp_client")
    title = _load("agent.title_generator")
    _load("agent.prompt_cache_scope")
    cc = _load("agent.context_compressor")
    for patch, mod in ((_patch_credentials, auth), (_patch_acp_client, acp), (_patch_side_tasks, aux),
                       (_patch_catalog, models), (_patch_title, title), (_patch_turn, aux), (_patch_compressor, cc)):
        if mod is None:
            continue
        try:
            patch(mod, changed)
        except Exception as e:
            log.warning("Gemini chat: %s could not be applied: %s", patch.__name__, type(e).__name__)
    try:
        if _patch_labels(auth, models, providers):
            changed.append("labels")
    except Exception as e:
        log.warning("Gemini chat: the labels could not be set: %s", type(e).__name__)
    _apply_late(changed)
    if changed:
        log.info("Gemini chat: set up (%d parts): %s", len(changed), _for_the_log(", ".join(changed)))
    return changed


def ready() -> bool:
    """True when a Gemini chat can run in this process: the relay's file is there and the engine's command for the
    provider is pinned to it. The screens offer Gemini as a chat model only when this says yes; otherwise picking it
    would make the engine look for GitHub's Copilot program."""
    relay = _STATE["relay"]
    if not relay or not os.path.isfile(relay):
        return False
    _apply_late()                                         # the parts in modules loaded since (the engine's account card)
    auth = sys.modules.get("hermes_cli.auth")
    acp = sys.modules.get("agent.copilot_acp_client")
    aux = sys.modules.get("agent.auxiliary_client")
    models = sys.modules.get("hermes_cli.models")
    resolver = getattr(auth, "resolve_external_process_provider_credentials", None)
    run_prompt = vars(getattr(acp, "CopilotACPClient", type("none", (), {}))).get("_run_prompt")
    env = getattr(acp, "_build_subprocess_env", None)
    # the command, its environment and the step wrapper; and the side tasks' gates and the model list: without those a
    # Gemini chat's side task could reach another provider, so Gemini is not offered (Gemini review R2 #10)
    return all(getattr(fn, MARK, False) for fn in (
        resolver, run_prompt, env, getattr(aux, "_call_llm_impl", None), getattr(aux, "_async_call_llm_impl", None),
        getattr(aux, "_get_provider_chain", None), getattr(models, "provider_model_ids", None)))


def pre_llm_call(**kwargs):
    """Plugin hook before every model step: modules loaded since the last call (the agent class) get patched too."""
    try:
        apply()
    except Exception as e:
        log.warning("Gemini chat: apply failed: %s", type(e).__name__)
    return None
