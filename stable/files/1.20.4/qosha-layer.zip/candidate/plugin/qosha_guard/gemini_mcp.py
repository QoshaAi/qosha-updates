"""Qosha's Gemini tool for chats (an MCP server, started by the engine from mcp_servers.gemini):

    ask_gemini(question) -> Gemini's answer, on the person's own Google subscription

It only calls gemini_cli.ask (Google's own command-line tool, text in, text out; see that file for the rules). Run with
the engine's Python:  <engine python> gemini_mcp.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gemini_cli  # noqa: E402

try:  # the engine may carry either generation of the mcp library
    from mcp.server.fastmcp import FastMCP  # noqa: E402
except ImportError:
    from mcp.server.mcpserver import MCPServer as FastMCP  # noqa: E402

mcp = FastMCP("qosha-gemini", log_level="WARNING")


@mcp.tool()
def ask_gemini(question: str) -> str:
    """Ask Google Gemini a question on the person's own Google subscription and get its answer as text. Gemini sees
    only the text you pass: include what it needs. Use it when the person asks for Gemini's view or a second opinion."""
    r = gemini_cli.ask(question)
    return r["answer"] if r.get("ok") else "Gemini could not answer: " + str(r.get("plain") or r.get("error"))


if __name__ == "__main__":
    mcp.run()
