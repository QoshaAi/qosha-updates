"""The assistant's own OS sandbox on the Mac lab (GUARDFIX2, verifier findings 6 and 7).

Text rules can't see what code does once it runs (the verifier read auth.json with `'nosj.htua'[::-1]`). So on the
lab, every process the assistant starts (its terminal, background and PTY commands, execute_code and its kernel) is
started through run/bin/qosha-confine-bash or -python, which put it under assistant.sb: no sign-ins, keys or engine
folders, writes only in Files, and no network except Qosha's read-only web proxy (egress_proxy.py) and the connector.
The engine itself keeps lab.sb. This module points the engine's four process starters at the launchers; the guard
(hook.py) refuses the terminal and code tools on the lab whenever this is not active (fail closed)."""
from __future__ import annotations

import logging
import os
from pathlib import Path

log = logging.getLogger("qosha.confine")
_ACTIVE = False


def on_lab() -> bool:
    return bool(os.environ.get("QOSHA_LAB")) and not os.environ.get("QOSHA_BOX")


def paths() -> dict:
    from . import store
    run = store.engine_home().parent / "run"
    return {"profile": run / "assistant.sb", "bash": run / "bin" / "qosha-confine-bash",
            "python": run / "bin" / "qosha-confine-python"}


def _ready(p: dict) -> bool:
    return all(Path(p[k]).is_file() for k in ("profile", "bash", "python")) and all(
        os.access(p[k], os.X_OK) for k in ("bash", "python"))


def apply() -> bool:
    """Patch the engine's process starters (Mac lab only). True when every one of them now starts confined."""
    global _ACTIVE
    if not on_lab():
        return False
    p = paths()
    if not _ready(p):
        log.error("qosha confine: launchers or profile missing; the terminal and code tools stay refused")
        return False
    bash, py = str(p["bash"]), str(p["python"])
    import tools.environments.local as local
    import tools.process_registry as registry
    import tools.code_execution_tool as code
    local._find_bash = lambda: bash
    local._find_shell = lambda: bash
    registry._find_shell = lambda: bash
    code._resolve_child_python = lambda mode=None: py
    patched = (local._find_bash() == bash and local._find_shell() == bash and registry._find_shell() == bash
               and code._resolve_child_python("strict") == py)
    try:
        from . import egress_proxy
        proxy = egress_proxy.ensure()   # True only if this process serves it (never trust a stand-in on the port)
    except Exception as exc:
        log.error("qosha confine: read-only web proxy not started: %s", type(exc).__name__)
        proxy = False
    _ACTIVE = patched and proxy
    return _ACTIVE


def active() -> bool:
    """Every process starter still points at the launchers, and they and the profile exist."""
    if not _ACTIVE:
        return False
    try:
        p = paths()
        import tools.environments.local as local
        import tools.process_registry as registry
        import tools.code_execution_tool as code
        return (_ready(p) and local._find_bash() == str(p["bash"]) and local._find_shell() == str(p["bash"])
                and registry._find_shell() == str(p["bash"]) and code._resolve_child_python("strict") == str(p["python"]))
    except Exception:
        return False
