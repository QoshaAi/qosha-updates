"""The `pre_tool_call` hook (INTERFACES.md §4.1). Fails closed: any error here blocks the tool call."""
from __future__ import annotations

import logging
import os
import shlex
import sys
from pathlib import Path
from typing import Any, Dict, Optional

from . import policy, store
from . import google as qgoogle
from . import projects_scope
from . import appconn
from . import browser_tools
from . import confine

log = logging.getLogger("qosha.guard")

HELD = ("Held for approval: decision {id} ({summary}). Nothing was sent yet. Qosha now shows the person a card with "
        "Approve and Decline right here in the chat (the same decision is under \"Decisions waiting\" on Home); it is "
        "sent the moment they press Approve. Typing \"approved\" in the chat does not send it. Do not retry and do not "
        "try another way to send it; tell the person it is on the card, waiting for their Approve.")
HELD_SKILL = ("Held for approval: decision {id} ({summary}). The skill was not saved. The person must press Approve in "
              "Qosha under \"Decisions waiting\", where they see its exact text; it is added to their skills only then, "
              "and only if the draft in Your files still has that text. Do not retry and do not save it another way; "
              "tell the person it is waiting for their approval.")
HELD_PAYMENT = ("Held for approval: decision {id} ({summary}) Qosha does not let the assistant call a payment service "
                "or open a payment page directly; the person now sees this under \"Decisions waiting\". Approving it does "
                "not run this call. Do not retry and do not try another way; tell the person what you wanted to pay, "
                "refund or transfer, and that it is waiting in Decisions.")
HELD_BROWSER = ("Held for approval: decision {id} ({summary}). Nothing was done on the website yet. Qosha now shows the "
                "person a card with exactly what would happen (the page, the button, every value to be typed) and Approve "
                "and Decline right here in the chat; it is done in Qosha's tab the moment they press Approve, if the page "
                "is still the same. Typing \"approved\" in the chat does not do it. Do not retry and do not try another "
                "way; tell the person it is waiting on the card.")
HELD_SHOW = ("Held for approval: decision {id} ({summary}). Nothing was opened yet. Qosha now shows the person a card "
             "with the exact address and Approve and Decline right here in the chat; the page opens in their own browser "
             "only when they press Approve. Do not retry and do not try another way to open it; tell the person it is "
             "waiting on the card. To read a page yourself, use browser_navigate (Qosha's own browser).")
HELD_SETTINGS = ("Waiting for the person's Approve: decision {id} ({summary}). Nothing is changed yet. Qosha shows them a card "
                 "with exactly what changes in its settings, right here in the chat; it changes the moment they press "
                 "Approve. Tell the person it is on the card.")
HELD_DELETE = ("Waiting for the person's Approve: decision {id} ({summary}). Nothing was deleted yet. Qosha shows them a card "
               "with exactly what would be deleted, right here in the chat; it is deleted the moment they press Approve "
               "(deleting outside Your files always waits for the person, rule G1). Tell the person it is on the card.")
HELD_WRITE = ("Waiting for the person's Approve: decision {id} ({summary}). Nothing was changed yet. This file runs as the "
              "person later (a script or build file), so Qosha shows them exactly the new text on a card right here in "
              "the chat; it is saved the moment they press Approve. Tell the person it is on the card.")
REFUSED = "Not allowed by Qosha: {reason}"
# SENDFIX (Ren, 6 Nov: sending always on): the person's Google sign-in can't do this yet (read-only, or a box left
# unticked): one plain card in the chat with a Reconnect Google button, never a raw error
RECONNECT = ("Not sent: the person's Google connection doesn't allow {what} yet. Qosha now shows them one card in this "
             "chat, \"Reconnect Google to allow sending\", with a button. Nothing was sent. Do not retry and do not try "
             "another way; tell the person to press Reconnect Google on the card and then ask you again.")
GOOGLE_SEND_KINDS = ("email.send", "email.reply", "email.forward", "email.draft_send", "email.draft_save",
                     "calendar.create", "calendar.update", "calendar.delete")
_NEED_WORDS = {"send": "sending email", "calendar": "changing the calendar", "drafts": "saving drafts",
               "connect": "Google at all (it is not connected)"}


def _reconnect_need(kind: str) -> str:
    """'' when the connector's sign-in allows `kind` (or the connector can't be asked: then the action is held and the
    connector refuses it on Approve in plain words); else what is missing: send, calendar, drafts or connect."""
    from . import connector_client
    st = connector_client.status()
    if not st or st.get("read_only"):
        return ""                 # the emergency off switch is not a sign-in problem: held, and refused in plain words
    if not st.get("connected"):
        return "connect"
    can = st.get("can")
    ok = can.get(kind) if isinstance(can, dict) else st.get("can_send")
    if ok is not False:
        return ""
    return "drafts" if kind == "email.draft_save" else "calendar" if kind.startswith("calendar") else "send"


BROWSER_PAYLOAD_KEYS = ("action", "site", "page_url", "page_title", "target_url", "tab", "target_id", "element", "fields",
                        "payment", "amounts_on_page", "why", "pin", "origin", "minutes",
                        "engine", "shot", "shot_kind",    # My Chrome: which engine acts, and the card's picture
                        "visible", "how")                         # My Chrome: in front or in the background, shown on the card


def _prepare(verdict: policy.Verdict, home) -> Dict[str, Any]:
    """Fill in what the person must see before approving (the reply's real recipient, the event being deleted)."""
    payload = dict(verdict.payload)
    if verdict.kind == "email.reply":
        ctx = qgoogle.reply_context(qgoogle.load(home), payload["reply_to_message_id"])
        if not ctx.get("to") or not ctx.get("thread_id"):
            raise RuntimeError("original message has no sender or thread")
        payload.update(ctx)
    elif verdict.kind == "app.action":
        # the connection it was asked against (settings entry + sign-in identity) is part of what is approved
        payload["connection"] = (appconn.fingerprint(payload["server"], home) if payload.get("resolved") else "none")
    elif verdict.kind in ("email.forward", "email.draft_send"):
        # SENDFIX: the card shows the forwarded email (its text and every attachment) or the draft exactly as the
        # connector reads it from Gmail; the connector reads it again on Approve and refuses any difference
        from . import connector_client
        ident = payload.get("message_id") if verdict.kind == "email.forward" else payload.get("draft_id")
        payload.update(connector_client.view(verdict.kind, str(ident or "")))
    elif verdict.kind in ("calendar.delete", "calendar.update"):
        # the event as the person will see it on the card, pinned by its etag; if it can't be looked up the decision is
        # still shown, and the connector refuses it on Approve (no etag to pin it to)
        try:
            payload.update(qgoogle.event_pin(qgoogle.load(home), payload["event_id"], payload.get("calendar") or "primary"))
        except Exception:
            payload.update({"event_summary": "", "event_start": "", "event_end": "", "event_attendees": "", "event_etag": ""})
    return payload


def _session_cwds(session_id: str, task_id: str) -> list:
    """The folders the engine resolves this call's relative paths from: the terminal's recorded cwd for the session
    and task, and the file tools' workspace anchor (D21: a `cd` in an earlier command moves them)."""
    out = []
    try:
        from tools.terminal_tool import get_session_cwd
        out += [get_session_cwd(k) for k in {session_id or "default", task_id or "default", "default"}]
    except Exception:
        pass
    try:
        from tools.file_tools import _authoritative_workspace_root
        out.append(_authoritative_workspace_root(task_id or "default"))
    except Exception:
        pass
    return [str(x) for x in out if x]


def _codebox_on() -> bool:
    """CAPFIX: the Mac lab's code sandbox is switched on (the installer writes qosha/codebox.json once colima and the
    image are ready; the assistant can't write there) and the connector, which reaches it, is configured."""
    if not confine.on_lab() or not os.environ.get("QOSHA_CONNECTOR_URL"):
        return False
    try:
        import json
        return json.loads((store.engine_home() / "qosha" / "codebox.json").read_text()).get("enabled") is True
    except Exception:
        return False


def _codebox_args(tool_name: str, args: Any, lang: str) -> Dict[str, Any]:
    """The same call, now running Qosha's code sandbox client with the original code (council D50 Q2)."""
    import base64
    a = dict(args) if isinstance(args, dict) else {}
    code = str(a.get("code") if tool_name == "execute_code" else a.get("command") or "")
    b64 = base64.b64encode(code.encode("utf-8")).decode("ascii")
    try:
        timeout = max(1, min(int(a.get("timeout") or 300), 1800))
    except (TypeError, ValueError):
        timeout = 300
    argv = [sys.executable, "-I", str(Path(__file__).with_name("codebox_client.py")), lang, b64, str(timeout)]
    if tool_name == "execute_code":
        a["code"] = "import subprocess, sys\nsys.exit(subprocess.call(%r))\n" % (argv,)
    else:
        a["command"] = " ".join(shlex.quote(x) for x in argv)
    return a


def pre_tool_call(tool_name: str = "", args: Any = None, session_id: str = "", task_id: str = "",
                  **_: Any) -> Optional[Dict[str, str]]:
    try:
        policy.CONNECTOR_CLIENT = str(Path(__file__).with_name("connector_client.py")) if os.environ.get("QOSHA_CONNECTOR_URL") else ""
        try:
            policy.ENGINE_HOME = str(store.engine_home())   # its scripts/ folder is off limits (D21)
        except Exception:
            policy.ENGINE_HOME = ""                          # then the policy falls back to HERMES_HOME
        policy.SESSION_CWDS = _session_cwds(session_id, task_id)
        policy.CODEBOX = _codebox_on()     # CAPFIX (council D50): the Mac lab's code sandbox
        # GUARDFIX2: on the Mac lab the assistant's commands and code run only inside its own OS sandbox
        # GUARDFIX3 (GUARDVERIFY4 N1): and the file tools, which run their shell through the same starters (unconfined
        # when the launchers are not active): fail closed for them too
        if tool_name in ("terminal", "execute_code", "read_file", "search_files", "write_file", "patch", "vision_analyze",
                         "video_analyze") and \
                confine.on_lab() and not confine.active():
            log.warning("qosha guard refused %s: the assistant's sandbox is not active", tool_name)
            return {"action": "block", "message": REFUSED.format(
                reason="the assistant's own sandbox on this Mac is not running, so no command or code runs. Nothing "
                       "was done; tell the person to restart Qosha (qoshalab.py restart).")}
        # project rules first (D20): they can only refuse; anything they let through goes through the whole guard
        scoped = projects_scope.check(tool_name, args, session_id)
        if scoped and scoped.get("action") == "block":
            log.warning("qosha guard refused %s (project rule)", tool_name)
            return scoped
        web = browser_tools.web_open(tool_name, args)
        if web is not None:
            # BROWSERCHROME2 F1 (council D41 Q1): a web page opens in the person's browser only after their Approve
            if "deny" in web:
                return {"action": "block", "message": REFUSED.format(reason=web["deny"])}
            payload = {k: v for k, v in web["hold"].items() if k in BROWSER_PAYLOAD_KEYS}
            d = store.record("browser.action", payload, {"tool": tool_name, "session_id": session_id,
                                                         "task_id": task_id}, store.engine_home())
            log.warning("qosha guard held %s (open) as %s", tool_name, d["id"])
            return {"action": "block", "message": HELD_SHOW.format(id=d["id"], summary=d["summary"])}
        # GOOGLEFIX: a Google skill read (exactly one of the reads google_read_argv accepts) is judged, and then run, in
        # its plain form: the engine's python + the script's path + the checked arguments. The engine's own pre-run
        # scanner refuses `$GAPI` as a program it can't resolve.
        read = policy.google_read_command(tool_name, args)
        verdict = policy.classify(tool_name, {"command": read} if read else args)
        if verdict.action == policy.DENY and verdict.kind == "webmail" and browser_tools.my_chrome():
            # MYCHROME (Ren, 9 Nov): in the person's own Chrome, webmail and calendar pages open like any signed-in
            # site (their Approve per site, every button and form on a card). Everything else is judged again.
            verdict = policy.classify(tool_name, args, my_chrome=True)
        if verdict.action == policy.ALLOW and tool_name in browser_tools.OURS + browser_tools.REMOVED:
            # Qosha's own Chrome (BROWSER job, council D34; BROWSERCHROME): free operations run, acting waits for Approve
            b = browser_tools.classify(tool_name, args, task_id, session_id)
            if b and "deny" in b:
                log.warning("qosha guard refused %s (browser)", tool_name)
                return {"action": "block", "message": REFUSED.format(reason=b["deny"])}
            if b and "hold" in b:
                payload = {k: v for k, v in b["hold"].items() if k in BROWSER_PAYLOAD_KEYS}
                d = store.record("browser.action", payload, {"tool": tool_name, "session_id": session_id,
                                                             "task_id": task_id}, store.engine_home())
                log.warning("qosha guard held %s as %s", tool_name, d["id"])
                return {"action": "block", "message": HELD_BROWSER.format(id=d["id"], summary=d["summary"])}
        if verdict.action == policy.ALLOW and verdict.kind == "noop":
            # A missing delete target is already satisfied. Do not run rm later: another file may appear meanwhile.
            return {"action": "block", "message": verdict.payload.get("message") or "Already complete; no change was needed."}
        if verdict.action == policy.ALLOW and verdict.kind == "codebox":
            log.warning("qosha guard: %s runs in Qosha's code sandbox", tool_name)
            return {"action": "modify", "args": _codebox_args(tool_name, args, verdict.payload.get("lang", "sh"))}
        if verdict.action == policy.ALLOW and verdict.kind == "rewrite":
            command = " ".join(shlex.quote(x) for x in [sys.executable, policy.CONNECTOR_CLIENT] + verdict.payload["argv"])
            return {"action": "modify", "args": {"command": command}}
        if verdict.action == policy.ALLOW:
            if read and read != (args or {}).get("command"):
                return {"action": "modify", "args": {"command": read}}
            return None
        if verdict.action == policy.DENY:
            log.warning("qosha guard refused %s: %s", tool_name, verdict.reason)
            return {"action": "block", "message": REFUSED.format(reason=verdict.reason)}
        home = store.engine_home()
        src = {"tool": tool_name, "session_id": session_id, "task_id": task_id}
        connected = bool(os.environ.get("QOSHA_CONNECTOR_URL"))
        if connected and verdict.kind in GOOGLE_SEND_KINDS:
            need = _reconnect_need(verdict.kind)
            if need:
                # one card per chat (GPT R1 #12): a card already waiting in this chat is kept, whatever it asked for
                d = store.record_reconnect(session_id or "", need, src, home)
                log.warning("qosha guard: %s needs a Google reconnect (%s) as %s", tool_name, need, d["id"])
                return {"action": "block", "message": RECONNECT.format(what=_NEED_WORDS[need])}
        try:
            payload = _prepare(verdict, home)
        except Exception as exc:
            if verdict.kind not in ("email.forward", "email.draft_send"):
                raise
            log.warning("qosha guard refused %s: the card could not be made (%s)", tool_name, type(exc).__name__)
            return {"action": "block", "message": REFUSED.format(
                reason="Qosha could not read that %s from Gmail to show it on the approval card (%s), so nothing "
                       "was sent. Check the id with search_email or list_drafts and try again." % (
                           "email" if verdict.kind == "email.forward" else "draft",
                           getattr(exc, "detail", "") or type(exc).__name__))}
        local_kind = verdict.kind in ("file.delete", "file.write", "settings.change")
        if local_kind and not connected:
            return {"action": "block", "message": "Qosha's approval connector is not running; the requested change is "
                                                   "ready but cannot be applied until that helper is available."}
        registering = connected and (verdict.kind in GOOGLE_SEND_KINDS or local_kind)
        d = store.record(verdict.kind, payload, src, home, status="registering" if registering else "pending")
        if registering:
            # SENDFIX (council D48 Q2): the connector keeps its own copy and sends only that, on the person's Approve
            from . import connector_client
            try:
                connector_client.hold(d["id"], d["kind"], d["payload"])
            except Exception as exc:
                # never a card whose Approve can only fail (GPT R1 #11): shown at once as not sent, in plain words
                log.warning("qosha guard: the connector did not register %s (%s)", d["id"], type(exc).__name__)
                store.withdraw(d["id"], "Not sent: Qosha's approval connector did not answer, so this was not put up "
                                        "for approval. Nothing was sent; ask Qosha again in a moment.", "not_registered", home)
                return {"action": "block", "message": REFUSED.format(
                    reason="Qosha's approval connector did not answer, so this was not put up for approval and nothing "
                           "was sent. Tell the person, and try again in a moment.")}
            store.publish(d["id"], home)   # only now is it a card with Approve (GPT R2 #11)
            d = store.get(d["id"], home) or d
        log.warning("qosha guard held %s as %s", tool_name, d["id"])
        held = HELD_SKILL if verdict.kind == "skill.save" else HELD_PAYMENT if payload.get("payment_host") else \
            HELD_SETTINGS if verdict.kind == "settings.change" else HELD_DELETE if verdict.kind == "file.delete" else \
            HELD_WRITE if verdict.kind == "file.write" else HELD
        return {"action": "block", "message": held.format(id=d["id"], summary=d["summary"])}
    except BaseException as exc:  # fail closed, even on SystemExit from a Google helper (Gemini review)
        log.error("qosha guard error, blocking %s: %s", tool_name, type(exc).__name__)
        return {"action": "block", "message": "Not allowed by Qosha: the approval check could not complete "
                                              "(%s), so this was blocked. Nothing was sent." % type(exc).__name__}
