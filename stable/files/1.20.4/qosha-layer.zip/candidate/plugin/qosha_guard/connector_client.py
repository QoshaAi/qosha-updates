#!/usr/bin/env python3
"""Inside the lab: Google reads through the Qosha connector (council decision D8), which alone holds the sign-in.

Two uses, no credentials in either:
1. A drop-in for the engine's google_api.py where Qosha's code loads it (plugin_api.py and qosha_guard via
   QOSHA_GOOGLE_API_PATH): TOKEN_PATH (the connector's no-secret status file), get_credentials(), build_service()
   returning googleapiclient-style objects whose .execute() asks the connector. Only read methods exist; the connector
   refuses anything else.
2. The assistant's read commands: the guard rewrites `google_api.py gmail search|get|labels` and `calendar list` to
   this file, which prints the same JSON as the engine's script.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

URL = os.environ.get("QOSHA_CONNECTOR_URL", "http://127.0.0.1:9239")


def _request_headers(extra=None):
    h = {"Content-Type": "application/json"}
    try:
        key = (_home() / "qosha" / "connector.key").read_text().strip()
        if key:
            h["X-Qosha-Key"] = key
    except OSError:
        pass
    h.update(extra or {})
    return h


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME", str(Path.home() / ".hermes")))


TOKEN_PATH = _home() / "qosha" / "google-connected.json"


def refresh_status() -> None:
    """Keep TOKEN_PATH (no secrets: connected, account, scopes) in step with the connector, written by the lab itself:
    the connector may run as another macOS user that can't write into the lab's home (separate-user plan)."""
    try:
        with urllib.request.urlopen(urllib.request.Request(URL + "/v1/status", headers=_request_headers()), timeout=5) as r:
            st = json.loads(r.read())
    except Exception:
        return  # keep the last known state; reads will report the connector as unreachable
    try:
        TOKEN_PATH.parent.mkdir(parents=True, exist_ok=True)
        if st.get("connected"):
            data = json.dumps({"connected": True, "account": st.get("account"), "read_only": st.get("read_only"),
                               "scopes": ["https://www.googleapis.com/auth/" + x for x in st.get("scopes", [])],
                               "via": "qosha-connector"})
            try:
                if TOKEN_PATH.read_text() == data:
                    return  # unchanged: keep the file (its time is part of the dashboard's cache key)
            except OSError:
                pass
            tmp = TOKEN_PATH.with_name(".google-connected.%d.tmp" % os.getpid())
            tmp.write_text(data)
            os.replace(tmp, TOKEN_PATH)
        elif TOKEN_PATH.exists():
            TOKEN_PATH.unlink()
    except OSError:
        pass


if os.environ.get("QOSHA_CONNECTOR_URL"):
    refresh_status()


class ConnectorError(RuntimeError):
    def __init__(self, message: str, code: str = "", detail: str = ""):
        super().__init__(message)
        self.code, self.detail = code, detail


_last_refresh = 0.0


def read(api: str, params: dict) -> dict:
    global _last_refresh
    import time as _t
    if _t.time() - _last_refresh > 60:  # the connector may have started after the lab (a daemon starts at boot)
        _last_refresh = _t.time()
        refresh_status()
    req = urllib.request.Request(URL + "/v1/read", data=json.dumps({"api": api, "params": params}).encode(),
                                 headers=_request_headers(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            code = json.loads(e.read()).get("error", "")
        except Exception:
            code = ""
        raise ConnectorError("connector refused %s: HTTP %s %s" % (api, e.code, code))
    except OSError as e:
        raise ConnectorError("Qosha connector unreachable (%s)" % type(e).__name__)


def outcomes(refs: list, timeout: int = 10) -> dict:
    """What the connector did for these decisions, from its own ledger ({ref: {state, result | error, detail}}).
    The person's Approve goes from their browser straight to the connector's approval port (D26), which no lab
    process can reach; the dashboard only reads the outcome back to show it."""
    req = urllib.request.Request(URL + "/v1/outcomes", data=json.dumps({"refs": list(refs)}).encode(),
                                 headers=_request_headers(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return {o["ref"]: o for o in json.loads(r.read()).get("outcomes", []) if isinstance(o, dict) and "ref" in o}
    except urllib.error.HTTPError as e:
        raise ConnectorError("connector refused: HTTP %s" % e.code, "refused")
    except (OSError, ValueError) as e:
        raise ConnectorError("Qosha connector unreachable (%s)" % type(e).__name__, "unreachable")


def decline(ref: str, timeout: int = 10) -> dict:
    """Tell the connector the person declined, before the store says so: once it is recorded there an Approve can't
    win anymore, and if an Approve already won the connector says so (409 already_approved)."""
    req = urllib.request.Request(URL + "/v1/decline", data=json.dumps({"ref": ref}).encode(),
                                 headers=_request_headers(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            code = json.loads(e.read()).get("error", "")
        except Exception:
            code = ""
        raise ConnectorError("connector refused: HTTP %s %s" % (e.code, code), code or "refused")
    except (OSError, ValueError) as e:
        raise ConnectorError("Qosha connector unreachable (%s)" % type(e).__name__, "unreachable")


def _post(path: str, body: dict, timeout: int = 15) -> dict:
    req = urllib.request.Request(URL + path, data=json.dumps(body).encode(), headers=_request_headers(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            code = json.loads(e.read()).get("error", "")
        except Exception:
            code = ""
        raise ConnectorError("connector refused: HTTP %s %s" % (e.code, code), code or "refused")
    except (OSError, ValueError) as e:
        raise ConnectorError("Qosha connector unreachable (%s)" % type(e).__name__, "unreachable")


def hold(ref: str, kind: str, payload: dict) -> dict:
    """SENDFIX (council D48 Q2): register a held email or calendar change with the connector, which keeps its own
    unchangeable copy; on Approve it sends only that copy, and only if it equals what the card showed."""
    return _post("/v1/hold", {"ref": ref, "kind": kind, "payload": payload})


def view(kind: str, ident: str) -> dict:
    """SENDFIX: what a forward's or a draft send's card must show, computed by the connector from the exact message."""
    return _post("/v1/view", {"kind": kind, "id": ident}, timeout=30)


def status(timeout: int = 5) -> dict:
    """The connector's no-secret status: connected, account, scopes, and per kind of action whether this sign-in allows
    it (`can`). {} when the connector can't be reached."""
    try:
        with urllib.request.urlopen(urllib.request.Request(URL + "/v1/status", headers=_request_headers()),
                                    timeout=timeout) as r:
            st = json.loads(r.read())
        return st if isinstance(st, dict) else {}
    except Exception:
        return {}


def ask(assistant: str, question: str, timeout: int = 150) -> dict:
    """Ask another assistant through the connector (UAT 2 Nov, council C6/D17): text in, text out, no tools."""
    req = urllib.request.Request(URL + "/v1/ask", data=json.dumps({"assistant": assistant, "question": question}).encode(),
                                 headers=_request_headers(), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read())
        except Exception:
            body = {}
        raise ConnectorError("%s: %s" % (body.get("error", "HTTP %s" % e.code), body.get("detail", "")))
    except OSError as e:
        raise ConnectorError("Qosha connector unreachable (%s)" % type(e).__name__)


def assistants() -> dict:
    """Which other assistants the connector can reach (no secrets)."""
    try:
        with urllib.request.urlopen(urllib.request.Request(URL + "/v1/status", headers=_request_headers()), timeout=5) as r:
            return dict(json.loads(r.read()).get("assistants") or {})
    except (OSError, ValueError):
        return {}


_CONTAINERS = ("users", "messages", "labels", "events", "calendarList")
_READS = ("list", "get", "getProfile")


class _Request:
    def __init__(self, api, params):
        self.api, self.params = api, params

    def execute(self, num_retries=0):
        return read(self.api, self.params)


class _Node:
    def __init__(self, path):
        self._path = path

    def __getattr__(self, name):
        if name not in _CONTAINERS and name not in _READS:
            raise AttributeError("%s is not a read; only the Qosha connector can send, after the person approves" % name)
        return _Method(self._path + [name])


class _Method:
    def __init__(self, path):
        self._path = path

    def __call__(self, **params):
        if self._path[-1] in ("list", "get", "getProfile"):
            return _Request(".".join(self._path), params)
        return _Node(self._path)  # users(), messages(), events(): keep walking


def get_credentials():
    return object()


def build_service(api: str, version: str):
    if api not in ("gmail", "calendar"):
        raise ConnectorError("unsupported service")
    return _Node([api])


# ------------------------------------------------------------------ CLI twin of google_api.py's read commands

def _headers(msg):
    return {h["name"].lower(): h["value"] for h in msg.get("payload", {}).get("headers", [])}


def _body(payload):
    import base64
    if payload.get("mimeType", "").startswith("text/plain") and payload.get("body", {}).get("data"):
        return base64.urlsafe_b64decode(payload["body"]["data"]).decode("utf-8", "replace")
    for part in payload.get("parts", []) or []:
        b = _body(part)
        if b:
            return b
    if payload.get("body", {}).get("data"):
        return base64.urlsafe_b64decode(payload["body"]["data"]).decode("utf-8", "replace")
    return ""


def _tz(v):
    return v if (not v or v.endswith("Z") or "+" in v[10:] or "-" in v[10:]) else v + "Z"


def main(argv=None):
    ap = argparse.ArgumentParser(description="Qosha: Google reads through the connector")
    sub = ap.add_subparsers(dest="service", required=True)
    g = sub.add_parser("gmail").add_subparsers(dest="action", required=True)
    p = g.add_parser("search"); p.add_argument("query"); p.add_argument("--max", type=int, default=10)
    p = g.add_parser("get"); p.add_argument("message_id")
    g.add_parser("labels")
    c = sub.add_parser("calendar").add_subparsers(dest="action", required=True)
    p = c.add_parser("list"); p.add_argument("--start", default=""); p.add_argument("--end", default="")
    p.add_argument("--max", type=int, default=25); p.add_argument("--calendar", default="primary")
    sub.add_parser("check")
    a = ap.parse_args(argv)
    if a.service == "check":  # stands in for the skill's `setup.py --check`
        try:
            req = urllib.request.Request(URL + "/v1/status", headers=_request_headers())
            with urllib.request.urlopen(req, timeout=20) as r:
                st = json.loads(r.read())
        except OSError as e:
            print("NOT_AUTHENTICATED: the Qosha connector is not running (%s)" % type(e).__name__)
            return 1
        if st.get("connected"):
            print("AUTHENTICATED: Google is connected through the Qosha connector (%s). Use the google_api.py read "
                  "commands; sends and calendar changes wait for a person's approval in Qosha."
                  % ("read-only" if st.get("read_only") else "approval needed for sends"))
            return 0
        print("NOT_AUTHENTICATED: Google is not connected on this Mac yet; a person signs in through Qosha.")
        return 1
    try:
        if a.service == "gmail" and a.action == "search":
            ids = read("gmail.users.messages.list", {"q": a.query, "maxResults": a.max}).get("messages", [])
            out = []
            for m in ids:
                msg = read("gmail.users.messages.get", {"id": m["id"], "format": "metadata", "metadataHeaders": ["From", "To", "Subject", "Date"]})
                h = _headers(msg)
                out.append({"id": msg["id"], "threadId": msg.get("threadId", ""), "from": h.get("from", ""), "to": h.get("to", ""),
                            "subject": h.get("subject", ""), "date": h.get("date", ""), "snippet": msg.get("snippet", ""),
                            "labels": msg.get("labelIds", [])})
            print(json.dumps(out, indent=2, ensure_ascii=False))
        elif a.service == "gmail" and a.action == "get":
            msg = read("gmail.users.messages.get", {"id": a.message_id, "format": "full"})
            h = _headers(msg)
            print(json.dumps({"id": msg["id"], "threadId": msg.get("threadId", ""), "from": h.get("from", ""), "to": h.get("to", ""),
                              "subject": h.get("subject", ""), "date": h.get("date", ""), "labels": msg.get("labelIds", []),
                              "body": _body(msg.get("payload", {}))}, indent=2, ensure_ascii=False))
        elif a.service == "gmail" and a.action == "labels":
            labels = read("gmail.users.labels.list", {}).get("labels", [])
            print(json.dumps([{"id": l["id"], "name": l["name"], "type": l.get("type", "")} for l in labels], indent=2))
        elif a.service == "calendar" and a.action == "list":
            now = datetime.now(timezone.utc)
            items = read("calendar.events.list", {"calendarId": a.calendar, "timeMin": _tz(a.start or now.isoformat()),
                                                  "timeMax": _tz(a.end or (now + timedelta(days=7)).isoformat()),
                                                  "maxResults": a.max, "singleEvents": True, "orderBy": "startTime"}).get("items", [])
            print(json.dumps([{"id": e["id"], "summary": e.get("summary", "(no title)"),
                               "start": e.get("start", {}).get("dateTime", e.get("start", {}).get("date", "")),
                               "end": e.get("end", {}).get("dateTime", e.get("end", {}).get("date", "")),
                               "location": e.get("location", ""), "description": e.get("description", ""),
                               "status": e.get("status", ""), "htmlLink": e.get("htmlLink", "")} for e in items], indent=2, ensure_ascii=False))
    except ConnectorError as e:
        print(str(e), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
