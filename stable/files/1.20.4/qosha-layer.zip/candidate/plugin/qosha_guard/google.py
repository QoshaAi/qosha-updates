"""Load the engine's own google-workspace module (google_api.py) for the executor and the hook's read-only lookups.

Search order matches INTERFACES.md §2. Outside tests, the file must be byte-identical to the pinned upstream script or
to the pinned script with the pilot's 4-scope narrowing, so an edited copy is never trusted with the send scope.
"""
from __future__ import annotations

import hashlib
import os
import sys
from pathlib import Path
from types import ModuleType
from typing import Optional

REL = Path("skills/productivity/google-workspace/scripts/google_api.py")
from .policy import TRUSTED_GAPI_SHA256 as TRUSTED_SHA256  # pinned upstream, and pinned + 4-scope narrowing
TEST_ENV = "QOSHA_GOOGLE_API_PATH"


class GoogleUnavailable(Exception):
    pass


def candidates(home: Path) -> list:
    out = []
    if os.environ.get(TEST_ENV):
        out.append(Path(os.environ[TEST_ENV]))
    out.append(home / REL)
    try:
        import hermes_cli
        out.append(Path(hermes_cli.__file__).resolve().parents[1] / REL)
    except Exception:
        pass
    return out


def load(home: Path) -> ModuleType:
    """Fresh import each call (the module fixes HERMES_HOME and the token path at import time)."""
    for path in candidates(home):
        if not path.is_file():
            continue
        # QOSHA_GOOGLE_API_PATH is set by the lab's own launchd agent (never by the assistant): tests' fakes, or the
        # Qosha connector's read-only adapter, which holds no credentials.
        is_adapter = bool(os.environ.get(TEST_ENV)) and path == Path(os.environ[TEST_ENV])
        data = path.read_bytes()  # checked and executed from the same bytes
        if not is_adapter and hashlib.sha256(data).hexdigest() not in TRUSTED_SHA256:
            raise GoogleUnavailable("google_api.py at %s is not a trusted copy" % path.parent.name)
        mod = ModuleType("qosha_google_api")
        mod.__file__ = str(path)
        exec(compile(data, str(path), "exec"), mod.__dict__)  # resolves HERMES_HOME from this process's env, like the skill
        if Path(mod.TOKEN_PATH).parent.resolve() not in (home.resolve(), (home / "qosha").resolve()):
            raise GoogleUnavailable("google_api.py resolved a different engine home")
        return mod
    raise GoogleUnavailable("google-workspace skill not found")


def token_present(home: Path) -> bool:
    return (home / "google_token.json").is_file()


def service(mod: ModuleType, api: str, version: str):
    try:
        return mod.build_service(api, version)
    except SystemExit as exc:  # google_api exits when there is no token
        raise GoogleUnavailable("not signed in to Google") from exc


def reply_context(mod: ModuleType, message_id: str) -> dict:
    """What gmail_reply would derive from the original message (read-only messages.get)."""
    svc = service(mod, "gmail", "v1")
    original = svc.users().messages().get(userId="me", id=message_id, format="metadata",
                                          metadataHeaders=["From", "Subject", "Message-ID"]).execute()
    headers = {h["name"].lower(): h["value"] for h in original.get("payload", {}).get("headers", [])}
    subject = headers.get("subject", "")
    if not subject.startswith("Re:"):
        subject = "Re: " + subject
    return {"to": headers.get("from", ""), "subject": subject, "thread_id": original.get("threadId", ""),
            "in_reply_to": headers.get("message-id", "")}


def event_summary(mod: ModuleType, event_id: str, calendar: str = "primary") -> str:
    svc = service(mod, "calendar", "v3")
    ev = svc.events().get(calendarId=calendar, eventId=event_id).execute()
    return "%s (%s)" % (ev.get("summary", "(no title)"),
                        ev.get("start", {}).get("dateTime", ev.get("start", {}).get("date", "")))


def event_pin(mod: ModuleType, event_id: str, calendar: str = "primary") -> dict:
    """What the person must see before approving a change or delete, pinned to this version of the event (its etag):
    the connector refuses if the event changed after they saw it (GPT R-email1 #2)."""
    svc = service(mod, "calendar", "v3")
    ev = svc.events().get(calendarId=calendar, eventId=event_id).execute()
    when = lambda k: ev.get(k, {}).get("dateTime", ev.get(k, {}).get("date", ""))
    # exactly what the connector derives from the live event (qosha_connector.event_view): it refuses any difference
    return {"event_summary": str(ev.get("summary", "(no title)")), "event_start": when("start"), "event_end": when("end"),
            "event_attendees": ", ".join(str(a.get("email", "")) for a in ev.get("attendees", []) or [] if a.get("email")),
            "event_etag": str(ev.get("etag", ""))}
