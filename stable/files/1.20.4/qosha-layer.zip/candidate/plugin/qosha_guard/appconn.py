"""Which connection a connected-app action was asked against (GPT R-skillsmcp2 #1).

An approval covers one app connection: the engine's settings entry for the server (where it connects and what it runs,
also after ${VAR} interpolation), a keyed digest (HMAC-SHA256) of every header and environment VALUE after
interpolation (GPT R-skillsmcp3: a changed Authorization or account-selecting variable is a different account), and
the stored sign-in's identity (the token files' inode, modification time and size: never their contents). The HMAC key
is 32 random bytes at $HERMES_HOME/qosha/appconn.key (0600, created on first use, in the folder the assistant can't
reach); it is never logged or returned. The hook puts this fingerprint into the held payload, so it
is part of the hash a person approves; the executor recomputes it just before running and refuses on any difference.
A sign-in refresh between asking and approving therefore also means "ask again" (fail closed).
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
from pathlib import Path
from typing import Any, Dict, Optional


def _names(value: Any) -> list:
    return sorted(str(k) for k in value) if isinstance(value, dict) else []


def canonical_entry(entry: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not isinstance(entry, dict):
        return {"missing": True}
    out = {k: entry.get(k) for k in ("url", "command", "args", "transport", "auth", "cwd")}
    out["headers"] = _names(entry.get("headers"))
    out["env"] = _names(entry.get("env"))
    oauth = entry.get("oauth") if isinstance(entry.get("oauth"), dict) else {}
    out["oauth"] = {k: (v if k in ("client_id", "scope", "scopes", "redirect_uri", "client_metadata_url") else "<set>")
                    for k, v in sorted(oauth.items())}
    return out


def _token_files(server: str, home: Path) -> list:
    safe = re.sub(r"[^\w\-]", "_", server).strip("_")[:128] or "default"   # the engine's token file name
    d = home / "mcp-tokens"
    return [d / (safe + ".json"), d / (safe + ".client.json")]


def _stat(path: Path):
    try:
        st = os.stat(path)
    except OSError:
        return "none"
    return [st.st_ino, st.st_mtime_ns, st.st_size]


def read_entry(server: str, home: Path) -> Optional[Dict[str, Any]]:
    import yaml
    try:
        text = (home / "config.yaml").read_text()
    except FileNotFoundError:
        return None
    cfg = yaml.safe_load(text) or {}
    servers = cfg.get("mcp_servers") or {}
    return servers.get(server) if isinstance(servers, dict) else None


def _key(home: Path) -> bytes:
    d = home / "qosha"
    d.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = d / "appconn.key"
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        pass
    else:
        with os.fdopen(fd, "wb") as fh:
            fh.write(secrets.token_bytes(32))
    key = path.read_bytes()
    if len(key) != 32:
        raise RuntimeError("connection key unreadable")   # fail closed: the hook blocks, the executor refuses
    return key


def _macs(key: bytes, value: Any) -> Dict[str, str]:
    if not isinstance(value, dict):
        return {}
    return {str(k): hmac.new(key, json.dumps(v, sort_keys=True, default=str).encode(), hashlib.sha256).hexdigest()
            for k, v in value.items()}


def fingerprint(server: str, home: Path, entry: Any = "read") -> str:
    """sha256 of the connection: the canonical settings entry, its resolved endpoint and keyed digests of every header,
    environment and oauth value (after ${VAR} interpolation), plus the sign-in files' identity."""
    if entry == "read":
        entry = read_entry(server, home)
    body = {"server": server, "entry": canonical_entry(entry),
            "signin": [_stat(p) for p in _token_files(server, home)]}
    if isinstance(entry, dict):
        from hermes_cli.mcp_config import _resolve_mcp_server_config   # the engine's own interpolation
        resolved = _resolve_mcp_server_config(entry)
        key = _key(home)
        body["resolved"] = {k: resolved.get(k) for k in ("url", "command", "args", "transport", "cwd")}
        body["values"] = {"headers": _macs(key, resolved.get("headers")), "env": _macs(key, resolved.get("env")),
                          "oauth": _macs(key, resolved.get("oauth"))}
        # every other setting too, whatever its name (identity_header, client certificates, future keys): a keyed
        # digest of the whole resolved entry, so any change to how or as whom the app connects means "ask again"
        # (GPT R-skillsmcp4)
        body["all"] = hmac.new(key, json.dumps(resolved, sort_keys=True, default=str).encode(), hashlib.sha256).hexdigest()
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()
