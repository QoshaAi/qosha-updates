"""Automatic model hand-off (Ren, 17 Nov 2026, roadmap item 9; Answering line: option 1).

When the model answering a chat cannot read an attached image, the engine already hands the picture to a helper on its
own: it sends the model a note naming the file (agent/image_routing.py, "text" mode), the model calls the engine's
`vision_analyze` tool, and that tool asks the engine's auxiliary "vision" model to read the picture
(agent/auxiliary_client.py). A model that CAN read images gets the picture itself and nothing here runs.

Two gaps are filled here, nothing else is built:
1. The engine looks for a helper only on the answering model's own account and then on paid aggregators (OpenRouter,
   Nous, DeepInfra). A person whose only AI accounts are Qosha's sign-ins (Claude, ChatGPT) or a Gemini key had no
   helper at all. Those accounts are added at the END of the engine's own search order, through the engine's own
   per-provider readers, so whatever the engine picked before still wins. Nothing is written to config.yaml: an
   explicit `auxiliary.vision` setting would make the engine send every picture through a helper, even to models
   that can read it themselves.
2. Who read the picture is added to the tool's result as `qosha_read_by` (only when the helper is not the answering
   model itself), so the chat page can say "Answering: Claude · image read by Gemini" for that reply.
When no connected account can read images, the answering model is told to say so plainly in its reply.
Fail-open everywhere: an engine without these names is left exactly as it is."""
from __future__ import annotations

import json
import logging
import re
import threading
import time

log = logging.getLogger("qosha.handoff")

# Helpers added after the engine's own order: a Gemini key, then the Claude and ChatGPT sign-ins Qosha connects
# (no per-use cost on a subscription seat). Each is tried only when its account is connected.
EXTRA_ORDER = ("gemini", "anthropic", "openai-codex")
# The engine has no default model for a ChatGPT sign-in as a helper; Qosha's own ChatGPT model (brain_api PREFERRED).
CHATGPT_MODEL = "gpt-6.1-sol"
TOOLS = {"vision_analyze": "image", "video_analyze": "video"}
NO_READER = (
    "Qosha note for this turn: the person attached an image, but none of the AI accounts connected here can read "
    "images, so you cannot see it. Start your answer with one plain sentence saying that none of their connected AI "
    "accounts can read images, so you could not see the picture, and that connecting Claude, ChatGPT or Gemini under "
    "AI accounts fixes it. Then help with the rest of the message. Do not name any tool or setting."
)
_IMAGE_NOTE = "[The user attached an image:"

_lock = threading.Lock()
_seen: dict = {}   # (session_id, turn_id) -> (time, helper name): the last picture a helper read in that turn


def name_for(provider: str, model: str) -> str:
    """The name a person knows for a provider/model (never the engine's own names)."""
    p = re.sub(r"^.*\(([^)]+)\)$", r"\1", str(provider or "")).strip().lower()   # "fallback_chain[0](anthropic)"
    m = str(model or "").strip().lower()
    if "gemini" in m or p in ("gemini", "google", "copilot-acp"):
        return "Gemini"
    if "claude" in m or p == "anthropic":
        return "Claude"
    if re.search(r"(^|/)(gpt|o\d)", m) or m.startswith("openai/") or p in ("openai-codex", "openai"):
        return "ChatGPT"
    for key, label in (("grok", "Grok"), ("llama", "Llama"), ("qwen", "Qwen"), ("pixtral", "Mistral"),
                       ("mistral", "Mistral"), ("kimi", "Kimi"), ("glm", "GLM")):
        if key in m:
            return label
    return "another connected AI"


def apply() -> bool:
    """Add the person's own accounts to the end of the engine's search for an image reader."""
    try:
        import agent.auxiliary_client as ac
        order = tuple(ac._VISION_AUTO_PROVIDER_ORDER)
        backends = ac._STRICT_VISION_BACKENDS
    except Exception as exc:
        log.warning("Qosha hand-off not set up: %s", type(exc).__name__)
        return False
    if "gemini" not in backends:
        backends["gemini"] = lambda model: ac.resolve_provider_client("gemini", model, is_vision=True)
    codex = backends.get("openai-codex")
    if codex is not None and not getattr(codex, "__qosha__", False):
        def _codex(model, _orig=codex):
            return _orig(model or CHATGPT_MODEL)
        _codex.__qosha__ = True
        backends["openai-codex"] = _codex
    ac._VISION_AUTO_PROVIDER_ORDER = order + tuple(p for p in EXTRA_ORDER if p not in order and p in backends)
    return True


def _main_name() -> str:
    try:
        from agent.auxiliary_client import _read_main_model, _read_main_provider
        return name_for(_read_main_provider(), _read_main_model())
    except Exception:
        return ""


def post_auxiliary_call(**kw):
    """Remember which account read the picture in this turn (the engine's observer event; nothing is changed)."""
    try:
        if kw.get("aux_task") != "vision" or kw.get("error"):
            return None
        helper = name_for(kw.get("provider"), kw.get("response_model") or kw.get("model"))
        if helper == _main_name():
            return None   # the answering model read it itself: no hand-off
        sid = str(kw.get("session_id") or "")
        now = time.time()
        with _lock:
            for k in [k for k, v in _seen.items() if now - v[0] > 900]:
                _seen.pop(k, None)
            _seen[(sid, str(kw.get("turn_id") or ""))] = (now, helper)
            _seen[(sid, "")] = (now, helper)   # when the tool's side does not carry the turn id
    except Exception:
        pass
    return None


def transform_tool_result(tool_name=None, result=None, session_id="", turn_id="", **kw):
    """Add `qosha_read_by` to the reading tool's result when a helper read the picture in this turn."""
    try:
        if tool_name not in TOOLS or not isinstance(result, str):
            return None
        sid = str(session_id or "")
        with _lock:
            hit = _seen.pop((sid, str(turn_id or "")), None) if turn_id else None
            loose = _seen.pop((sid, ""), None)
            hit = hit or (loose if loose and time.time() - loose[0] < 300 else None)
        if not hit:
            return None
        data = json.loads(result)
        if not isinstance(data, dict) or not data.get("success"):
            return None
        data["qosha_read_by"] = hit[1]
        data["qosha_read_kind"] = TOOLS[tool_name]
        return json.dumps(data, indent=2, ensure_ascii=False)
    except Exception:
        return None


def _has_reader() -> bool:
    try:
        from tools.vision_tools import check_vision_requirements
        return bool(check_vision_requirements())
    except Exception:
        return True   # unknown: say nothing


def pre_llm_call(user_message=None, **kw):
    """A picture the answering model cannot read and no connected account to read it: tell the model to say so."""
    try:
        text = user_message
        if isinstance(text, list):
            text = " ".join(str(p.get("text") or "") for p in text if isinstance(p, dict))
        if not isinstance(text, str) or _IMAGE_NOTE not in text:
            return None
        if _has_reader():
            return None
        return {"context": NO_READER}
    except Exception:
        return None


def register(ctx) -> None:
    apply()
    for hook in ("post_auxiliary_call", "transform_tool_result", "pre_llm_call"):
        try:
            ctx.register_hook(hook, globals()[hook])
        except Exception as exc:
            log.warning("Qosha hand-off hook %s not registered: %s", hook, type(exc).__name__)
