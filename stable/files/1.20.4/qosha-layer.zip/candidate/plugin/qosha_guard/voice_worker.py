"""Qosha's natural on-device voice (Ren, 17 Nov 2026: "Free natural voice now"): Kokoro-82M (Apache-2.0 weights) through
kokoro-onnx, on this computer, nothing sent anywhere. Run with the voice environment's Python (not the engine's):

    <tts python> voice_worker.py <model.onnx> <voices.bin>            a worker: one JSON request per line on stdin
    <tts python> voice_worker.py <model.onnx> <voices.bin> --say out.wav "text" [lang]   one file, then exit

Worker protocol: {"id", "text", "lang"} -> {"id", "ok": true, "wav_b64", "ms", "voice"} | {"id", "ok": false, "error"}.
The model is loaded once and stays loaded. Languages: en, pt (Brazilian), es; anything else is spoken as English.
Note for packaging: kokoro-onnx turns pt/es text into sounds with espeak-ng (GPL), loaded as a separate library.
"""
import base64
import io
import json
import sys
import time

VOICES = {"en": ("af_heart", "en-us"), "pt": ("pf_dora", "pt-br"), "es": ("ef_dora", "es")}


def load(model: str, voices: str):
    from kokoro_onnx import Kokoro
    return Kokoro(model, voices)


def wav_bytes(k, text: str, lang: str):
    import soundfile as sf
    voice, code = VOICES.get(lang if lang in VOICES else "en")
    samples, rate = k.create(text, voice=voice, speed=1.0, lang=code)
    buf = io.BytesIO()
    sf.write(buf, samples, rate, format="WAV", subtype="PCM_16")
    return buf.getvalue(), voice, len(samples) / float(rate)


def main() -> int:
    model, voices = sys.argv[1], sys.argv[2]
    k = load(model, voices)
    if len(sys.argv) > 3 and sys.argv[3] == "--say":
        out, text, lang = sys.argv[4], sys.argv[5], (sys.argv[6] if len(sys.argv) > 6 else "en")
        t0 = time.time()
        data, voice, secs = wav_bytes(k, text, lang)
        open(out, "wb").write(data)
        print(json.dumps({"file": out, "voice": voice, "audio_seconds": round(secs, 2), "made_in_seconds": round(time.time() - t0, 2)}))
        return 0
    sys.stdout.write(json.dumps({"ready": True}) + "\n"); sys.stdout.flush()
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        rid = None
        try:
            req = json.loads(line)
            rid = req.get("id")
            text = str(req.get("text") or "").strip()[:1200]
            if not text:
                raise ValueError("nothing to say")
            t0 = time.time()
            data, voice, secs = wav_bytes(k, text, str(req.get("lang") or "en"))
            out = {"id": rid, "ok": True, "wav_b64": base64.b64encode(data).decode("ascii"), "ms": int((time.time() - t0) * 1000),
                   "voice": voice, "audio_seconds": round(secs, 2)}
        except Exception as exc:
            out = {"id": rid, "ok": False, "error": type(exc).__name__ + ": " + str(exc)[:160]}
        sys.stdout.write(json.dumps(out) + "\n"); sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
