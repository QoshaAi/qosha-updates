"""Connect Google in one step (Ren, 17 Nov 2026: "the person just sees Connected, no copy-paste").

The engine's bundled google-workspace skill signs in with a redirect to http://localhost:1, so the person must copy the
browser's address back into the chat. This helper uses the same skill (its scopes, client file and token format, so
google_api.py works unchanged) but catches Google's redirect on a loopback port of this computer, so the person only
signs in to Google and sees "Connected".

Tool: qosha_connect_google. Python: start_flow() -> dict (returns at once), flow_status(id), cancel_flow(),
open_in_browser(id), connect(timeout=300) -> dict (waits; kept for scripts).
The Google OAuth client comes from <home>/google_client_secret.json (the skill's place); if it is missing, a Qosha
install may ship one as <plugin>/google_client.json (Desktop-app client, no secret values in this repo).

17 Nov 2026 evening (Windows, real client): the sign-in used to be opened only by the hidden dashboard process
(webbrowser.open) while the page waited up to 300 s with no address. On Windows a hidden background process may not
bring a window forward while the person is using another one (foreground lock), so Google's page opened BEHIND the
Qosha window and nothing visible happened. Now the flow starts and the address comes back at once; the PAGE opens it
(the window the person is using may bring the browser forward) and shows a link; the loopback server waits in the
background for up to 10 minutes, one flow at a time, state checked, PKCE kept; the page polls flow_status().
"""
from __future__ import annotations

import hmac
import html
import importlib.util
import json
import os
import secrets
import shutil
import sys
import threading
import time
import types
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict
from urllib.parse import parse_qs, quote, urlparse


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes"))


def _skill_setup():
    """The bundled skill's setup.py, loaded as a module (home copy first, then the engine's)."""
    cands = [_home() / "skills" / "productivity" / "google-workspace" / "scripts" / "setup.py"]
    try:
        import hermes_constants
        cands.append(Path(hermes_constants.__file__).resolve().parent / "skills" / "productivity" / "google-workspace"
                     / "scripts" / "setup.py")
    except Exception:
        pass
    for p in cands:
        if p.is_file():
            import sys
            if str(p.parent) not in sys.path:
                sys.path.insert(0, str(p.parent))
            spec = importlib.util.spec_from_file_location("qosha_gws_setup", p)
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)
            return m
    raise RuntimeError("the google-workspace skill is not installed")


# Google Workspace MCP (taylorwilsdon/google_workspace_mcp 2.5.0; Ren 02:20: full tool set for Gmail, Calendar, Drive,
# Docs, Sheets, Contacts, Tasks): one sign-in feeds both it and the bundled skill. Its scopes for those services:
WORKSPACE_MCP_SCOPES = [
    "https://www.googleapis.com/auth/" + x for x in (
        "calendar", "calendar.events", "calendar.readonly", "contacts", "contacts.readonly", "documents",
        "documents.readonly", "drive", "drive.file", "drive.readonly", "gmail.compose", "gmail.labels", "gmail.modify",
        "gmail.readonly", "gmail.send", "gmail.settings.basic", "spreadsheets", "spreadsheets.readonly", "tasks",
        "tasks.readonly", "userinfo.email", "userinfo.profile")] + ["openid"]


def workspace_mcp_dir() -> Path:
    return _home() / "google_workspace_mcp" / "credentials"


def _private_json(path, payload) -> None:
    """Writes the sign-in file readable only by this user: Qosha's own writer, the same behaviour as the engine's
    skills/productivity/google-workspace/scripts/_secure_storage.py write_private_json (JSON, indent 2, utf-8, mode 0600
    from creation, fsync, atomic replace). Qosha never calls the skill script's helpers for this (18 Nov 2026: the
    install's older Qosha-library copy of that script had no write_private_json, so Connect Google on a fresh Mac failed
    at the very end and the sign-in was lost; council GPT + Gemini: "own token writing directly")."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp.%d.%s" % (os.getpid(), secrets.token_hex(4)))
    created = False
    try:
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        created = True                   # only a temp file this call made is ever removed below
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(str(tmp), str(path))
    finally:
        if created:
            try:
                tmp.unlink()
            except OSError:
                pass


def _write_workspace_mcp(creds, email: str, granted) -> str:
    """The same sign-in in the Workspace MCP's own credential format (auth/credential_store.py, file per account)."""
    if not email:
        return "skipped: no account email"
    from urllib.parse import quote
    d = workspace_mcp_dir()
    d.mkdir(parents=True, exist_ok=True)
    data = {"token": creds.token, "refresh_token": creds.refresh_token, "token_uri": creds.token_uri,
            "client_id": creds.client_id, "client_secret": creds.client_secret, "scopes": list(granted or creds.scopes or []),
            "expiry": creds.expiry.isoformat() if getattr(creds, "expiry", None) else None}
    path = d / (quote(email, safe="@._-") + ".json")
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(data, f, indent=2)
    return "written"


PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Qosha</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#F5F4F0;color:#0B0B0B;
font-family:"Google Sans Flex","Helvetica Neue",Arial,sans-serif}.c{background:#fff;border:1px solid #E2E1DB;border-radius:20px;
padding:32px 40px;max-width:440px;box-shadow:0 1px 2px rgba(11,11,11,.04),0 8px 28px rgba(11,11,11,.05)}
h1{margin:0 0 8px;font-size:22px;font-weight:500;color:#0B3326}p{margin:0;color:#3E4B45;line-height:22px}
.bar{height:4px;width:48px;background:#B8955A;border-radius:2px;margin-bottom:16px}</style></head>
<body><div class="c"><div class="bar"></div><h1>%s</h1><p>%s</p></div></body></html>"""


FLOW_TTL = 600   # seconds a started sign-in waits for Google's answer (10 minutes)

# The OAuth app Qosha ships only lets accounts of one Google Workspace in (Google refuses others with its own
# "Access blocked ... org_internal" page and never calls back). hd= tells Google's account chooser to offer only that
# domain's accounts. QOSHA_GOOGLE_DOMAIN overrides it; set it empty for an app open to every account.
def account_domain() -> str:
    d = os.environ.get("QOSHA_GOOGLE_DOMAIN")
    return "qosha.ai" if d is None else d.strip().lstrip("@")


def account_line() -> str:
    d = account_domain()
    return ("Use your @%s Google account; other accounts are refused for now." % d) if d else ""


def waiting_line() -> str:
    """What Qosha shows while Google's sign-in waits in the browser (Ren 17 Nov 18:40: Renato's tab opened, but the
    app never told him it was waiting for him)."""
    d = account_domain()
    return "Google\u2019s sign-in is open in your browser. Finish it there" + (", with your @%s account." % d if d else ".")


# one registry per process, shared by every copy of this module (the chat tool and the Connections page load it under
# different names): one sign-in at a time on this computer
_REG = sys.modules.get("qosha_google_flow_registry")
if _REG is None:
    _REG = types.ModuleType("qosha_google_flow_registry")
    _REG.lock = threading.Lock()
    _REG.current = None
    sys.modules["qosha_google_flow_registry"] = _REG


def _now() -> float:
    return time.time()


class _GoogleFlow:
    """One sign-in: a loopback server on 127.0.0.1:<free port> served by a background thread until Google answers with
    this flow's state, the flow is cancelled, or FLOW_TTL passes."""

    def __init__(self, setup_mod, secret: Path, ttl: int):
        from google_auth_oauthlib.flow import Flow
        self.s = setup_mod
        self.id = "g" + secrets.token_urlsafe(18)
        self.started = _now()
        self.deadline = self.started + ttl
        self.status = "waiting"           # waiting | connected | failed | timeout | cancelled
        self.email = ""
        self.scopes: list = []
        self.workspace_mcp = ""
        self.error = ""
        self.plain = ""
        self.refused = 0                  # callbacks refused (wrong or missing state)
        self.browser_opened = None        # None: not tried; True/False: webbrowser.open's answer
        self._done = threading.Event()
        self._lock = threading.Lock()
        flow_ref = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _page(self, code: int, title: str, text: str):
                data = (PAGE % (html.escape(title), html.escape(text))).encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self):
                flow_ref._callback(self)

        self.srv = HTTPServer(("127.0.0.1", 0), H)
        self.srv.timeout = 0.5
        self.redirect = "http://127.0.0.1:%d/" % self.srv.server_address[1]
        self.flow = Flow.from_client_secrets_file(
            str(secret), scopes=sorted(set(setup_mod.SCOPES) | set(WORKSPACE_MCP_SCOPES)), redirect_uri=self.redirect,
            autogenerate_code_verifier=True)   # PKCE: the verifier stays in this process
        extra = {"hd": account_domain()} if account_domain() else {}
        self.url, self.state = self.flow.authorization_url(access_type="offline", prompt="consent", **extra)
        self.thread = threading.Thread(target=self._serve, daemon=True, name="qosha-google-signin")

    # ---- the loopback server -------------------------------------------------------------------------------------
    def _serve(self):
        try:
            while not self._done.is_set() and _now() < self.deadline:
                self.srv.handle_request()     # returns after 0.5 s without a request
        except Exception as exc:              # never leave the flow "waiting" if the server breaks
            self._finish("failed", "server_" + type(exc).__name__, "Google did not connect. Press Connect Google to try again.")
        finally:
            if self.status == "waiting":
                self._finish("timeout", "timeout", "The Google sign-in was not finished within 10 minutes. "
                             + (account_line() + " " if account_line() else "") + "Press Connect Google to try again.")
            try:
                self.srv.server_close()
            except Exception:
                pass

    def _finish(self, status: str, error: str = "", plain: str = "") -> bool:
        with self._lock:
            if self.status != "waiting":
                return False
            self.status, self.error, self.plain = status, error, plain
            self._done.set()
            return True

    def _callback(self, h):
        u = urlparse(h.path)
        q = parse_qs(u.query)
        if u.path != "/" or ("code" not in q and "error" not in q):
            h.send_response(404); h.send_header("Content-Length", "0"); h.end_headers(); return
        got_state = q.get("state", [""])[0]
        if self.status != "waiting":
            h._page(410, "Already finished", "This Google sign-in has already ended. Go back to Qosha.")
            return
        if not got_state or not hmac.compare_digest(got_state.encode(), self.state.encode()):
            # not the sign-in Qosha started (a stale tab, a forged address): refused, the real one keeps waiting
            self.refused += 1
            h._page(400, "Not connected", "This sign-in page is not the one Qosha started. Go back to Qosha and use the "
                                          "Google sign-in it opened (or press Connect Google again).")
            return
        if "error" in q:
            err = q.get("error", ["cancelled"])[0][:80]
            plain = ("The Google sign-in was cancelled." if err == "access_denied" else
                     "Google did not connect (Google said: %s)." % err)
            line = account_line()
            self._finish("failed", err, plain + (" " + line if line else "") + " Press Connect Google to try again.")
            h._page(200, "Not connected", plain + " Go back to Qosha and try again.")
            return
        try:
            self._store(q)
        except Exception as exc:
            try:                         # best effort: a closed stderr must not stop the answer below
                print("qosha google sign-in: could not store the answer: %s: %s" % (type(exc).__name__, str(exc)[:200]),
                      file=sys.stderr, flush=True)
            except Exception:
                pass
            self._finish("failed", "token_" + type(exc).__name__,
                         "Google answered, but Qosha could not finish the sign-in (%s). Press Connect Google to try again."
                         % type(exc).__name__)
            h._page(200, "Not connected", "Qosha could not finish the sign-in. Go back to Qosha and try again.")
            return
        if not self._finish("connected", "", "Google is connected%s." % (" as " + self.email if self.email else "")):
            # stopped (Disconnect) while Google was answering: what was just written is taken back
            for f in [Path(self.s.TOKEN_PATH)] + ([workspace_mcp_dir() / (quote(self.email, safe="@._-") + ".json")]
                                                   if self.email else []):
                try:
                    f.unlink()
                except FileNotFoundError:
                    pass
            h._page(200, "Not connected", "This Google sign-in was stopped in Qosha. Go back to Qosha.")
            return
        h._page(200, "Connected", "Google is connected to Qosha%s. You can close this tab and go back to Qosha."
                % (" as " + self.email if self.email else ""))

    def _store(self, q):
        """Exchanges the code (with the PKCE verifier) and writes the skill's token and the Workspace tools' copy."""
        s = self.s
        os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"
        self.flow.fetch_token(code=q["code"][0])
        creds = self.flow.credentials
        payload = s._normalize_authorized_user_payload(json.loads(creds.to_json()))
        granted = list(getattr(creds, "granted_scopes", None) or []) or q.get("scope", [""])[0].split()
        if granted:
            payload["scopes"] = granted
        _private_json(s.TOKEN_PATH, payload)
        email = ""
        try:
            from googleapiclient.discovery import build
            email = build("gmail", "v1", credentials=creds).users().getProfile(userId="me").execute().get("emailAddress", "")
        except Exception:
            pass
        self.email, self.scopes = email, granted
        self.workspace_mcp = _write_workspace_mcp(creds, email, granted)

    # ---- what callers see ----------------------------------------------------------------------------------------
    def wait(self, timeout: float) -> bool:
        return self._done.wait(timeout)

    def snapshot(self) -> Dict[str, Any]:
        r = {"flow_id": self.id, "status": self.status, "plain": self.plain, "error": self.error,
             "seconds_left": max(0, int(self.deadline - _now())) if self.status == "waiting" else 0,
             "refused": self.refused, "browser_opened": self.browser_opened, "account_hint": account_line()}
        if self.status == "waiting":
            r["auth_url"] = self.url
            r["waiting_line"] = waiting_line()
        if self.status == "connected":
            r.update({"email": self.email, "scopes": self.scopes, "workspace_mcp": self.workspace_mcp})
        return r


def _prepare():
    """(setup module, client file) or a {"ok": False, ...} answer when this computer can't start a sign-in."""
    s = _skill_setup()
    secret = Path(s.CLIENT_SECRET_PATH)
    if not secret.exists():
        shipped = Path(__file__).resolve().parent.parent / "google_client.json"
        if shipped.is_file():
            shutil.copyfile(shipped, secret)
            os.chmod(secret, 0o600)
        else:
            return None, {"ok": False, "error": "no_client", "plain": (
                "Qosha has no Google sign-in app set up on this computer yet (google_client_secret.json). Ask the "
                "person for their Google OAuth client file (Desktop app), or follow the google-workspace skill's Step 2.")}
    # The Google packages are the engine's own (its "google" extra). The skill's own check wants exact older versions
    # and runs pip when they differ; a person's computer has no pip (Windows, a client Mac), so it is not used here.
    try:
        from google_auth_oauthlib.flow import Flow  # noqa: F401
        import googleapiclient.discovery  # noqa: F401
        import google.oauth2.credentials  # noqa: F401
    except Exception:
        return None, {"ok": False, "error": "no_google_packages", "plain": (
            "The Google parts of Qosha are missing on this computer, so the sign-in could not start. Reinstall Qosha.")}
    return (s, secret), None


def _open(flow: "_GoogleFlow") -> bool:
    try:
        flow.browser_opened = bool(webbrowser.open(flow.url))
    except Exception:
        flow.browser_opened = False
    return flow.browser_opened


def start_flow(open_browser: bool = False, ttl: int = FLOW_TTL) -> Dict[str, Any]:
    """Starts a sign-in (or returns the one already waiting: never two at once) and answers at once with Google's
    address. open_browser: also ask this computer to open it (a second path; on Windows it may open behind)."""
    with _REG.lock:
        cur = _REG.current
        if cur is not None and cur.status == "waiting" and _now() < cur.deadline:
            r = dict(cur.snapshot(), ok=True, reused=True)
        else:
            try:
                prep, problem = _prepare()
            except Exception as exc:
                return {"ok": False, "error": "no_skill", "plain": "Google's sign-in could not start on this computer "
                        "(%s). Reinstall Qosha." % type(exc).__name__}
            if problem:
                return problem
            cur = _GoogleFlow(prep[0], prep[1], ttl)
            _REG.current = cur
            cur.thread.start()
            r = dict(cur.snapshot(), ok=True, reused=False)
    if open_browser and r.get("status") == "waiting":
        r["browser_opened"] = _open(cur)
    return r


def _find(flow_id: str):
    cur = _REG.current
    if cur is not None and flow_id and hmac.compare_digest(str(flow_id).encode(), cur.id.encode()):
        return cur
    return None


def flow_status(flow_id: str) -> Dict[str, Any]:
    cur = _find(flow_id)
    if cur is None:
        return {"flow_id": flow_id, "status": "unknown", "plain": "This Google sign-in has expired. Press Connect Google again."}
    return cur.snapshot()


def open_in_browser(flow_id: str) -> Dict[str, Any]:
    """Opens the waiting flow's own address from this computer (the page asks when its own window.open was blocked)."""
    cur = _find(flow_id)
    if cur is None or cur.status != "waiting":
        return {"ok": False, "status": cur.status if cur else "unknown"}
    return {"ok": True, "browser_opened": _open(cur)}


def current_flow() -> Dict[str, Any]:
    cur = _REG.current
    return cur.snapshot() if cur is not None else {}


def cancel_flow(flow_id: str = "") -> bool:
    """Ends a waiting sign-in (Cancel, or Disconnect pressed meanwhile); its late answer is refused. With flow_id, only
    that sign-in is ended."""
    cur = _find(flow_id) if flow_id else _REG.current
    if cur is None or cur.status != "waiting":
        return False
    return cur._finish("cancelled", "cancelled", "The Google sign-in was stopped. Press Connect Google to start again.")


def waiting_signin():
    """For a "waiting for you" count (waiting.py): None, or the Google sign-in that waits for the person right now:
    {"kind": "google_signin", "flow_id", "since" (epoch s), "seconds_left", "line", "auth_url"}."""
    cur = _REG.current
    if cur is None or cur.status != "waiting" or _now() >= cur.deadline:
        return None
    return {"kind": "google_signin", "flow_id": cur.id, "since": cur.started, "seconds_left": int(cur.deadline - _now()),
            "line": waiting_line(), "auth_url": cur.url}


def connect(timeout: int = 300, open_browser: bool = True) -> Dict[str, Any]:
    """Starts a sign-in and WAITS for it (scripts and older callers). The page and the chat tool use start_flow()."""
    r = start_flow(open_browser=open_browser, ttl=max(timeout, 1) + 5)
    if not r.get("ok"):
        return r
    cur = _find(r["flow_id"])
    if cur is not None and not cur.wait(timeout):
        cur._finish("timeout", "timeout", "The Google sign-in was not finished in time.")
    snap = cur.snapshot() if cur is not None else {"status": "unknown"}
    if snap["status"] == "connected":
        return {"ok": True, "email": snap.get("email", ""), "scopes": snap.get("scopes", []),
                "browser_opened": snap.get("browser_opened"), "workspace_mcp": snap.get("workspace_mcp", ""),
                "plain": snap.get("plain") or "Google is connected."}
    return {"ok": False, "error": snap.get("error") or snap["status"], "auth_url": r.get("auth_url", ""),
            "plain": snap.get("plain") or "Google did not connect."}


SCHEMA = {"name": "qosha_connect_google",
          "description": ("Connect the person's Google account (Gmail, Calendar, Drive, Docs, Sheets, Contacts) to Qosha. "
                          "Call it once: it starts Google's sign-in, tries to open it in their browser and returns at once "
                          "with the sign-in link (auth_url). Always give the person that link as a clickable link (the "
                          "browser may open behind other windows), and say which Google account to use (account_hint). "
                          "When they say they are done, call it again with check=true to see whether Google is connected. "
                          "They copy nothing back. Use this instead of the google-workspace skill's manual "
                          "--auth-url/--auth-code steps. Afterwards use the google-workspace skill's google_api.py."),
          "parameters": {"type": "object", "properties": {
              "check": {"type": "boolean", "description": "true: only report whether the sign-in started earlier has finished."}},
              "required": []}}


def _handler(args, **kw) -> str:
    try:
        if isinstance(args, dict) and args.get("check"):
            cur = current_flow()
            if not cur:
                r = {"ok": False, "status": "none", "plain": "No Google sign-in was started. Call qosha_connect_google without check to start one."}
            else:
                r = dict(cur, ok=cur.get("status") == "connected")
                if cur.get("status") == "waiting":
                    r["plain"] = "Still waiting for the person to finish Google's sign-in. " + account_line()
        else:
            r = start_flow(open_browser=True)
            if r.get("ok") and r.get("status") == "waiting":
                r["plain"] = ("Google's sign-in has started. Give the person this link (it may also have opened in their "
                              "browser): %s . %s When they are done, call qosha_connect_google with check=true."
                              % (r.get("auth_url"), account_line()))
    except Exception as exc:
        r = {"ok": False, "error": type(exc).__name__, "plain": "Google could not be connected: %s" % exc}
    return json.dumps(r)


def register(ctx) -> None:
    ctx.register_tool(name="qosha_connect_google", toolset="qosha", schema=SCHEMA, handler=_handler,
                      check_fn=lambda: True, description=SCHEMA["description"], emoji="🔗")


if __name__ == "__main__":
    import sys
    print(json.dumps(connect(open_browser="--no-browser" not in sys.argv), indent=2))
