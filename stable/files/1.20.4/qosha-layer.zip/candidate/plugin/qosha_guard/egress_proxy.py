"""Qosha's read-only web proxy for the assistant's own code on the Mac lab (GUARDFIX2, verifier finding 7).

The assistant's terminal and code run under assistant.sb (confine.py), which allows no network except this proxy on
127.0.0.1:9245 (and the Qosha connector). The proxy lets code READ the web: GET and HEAD without a body, to public
addresses only. Anything else (POST, PUT, PATCH, DELETE, a body, an upgrade to a socket) is not sent: it becomes a card
under "Decisions waiting" (like a payment hold: approving it does not run the request) and the code gets a 403 that
says so. One narrow exception (a weaker guarantee, stated): the maps skill's Overpass mirrors take their read queries
only by POST, so a POST to exactly those two addresses on port 443, form-encoded with a single `data=` field of at most
16 KB, is forwarded (GPT review R1: fixed authority, port, schema and framing). Only ports 80 and 443; never this
Mac's own addresses, the local network or anything not globally routable.

HTTPS is read by terminating TLS here with Qosha's own certificate authority (made on first use in the engine's
qosha/egress folder, which the assistant can't read); the launchers point the confined programs at a bundle of the
usual public roots plus that authority. The upstream connection is verified against the public roots, to the address
checked here (no DNS rebinding to this Mac or the local network)."""
from __future__ import annotations

import hashlib
import http.client
import ipaddress
import logging
import os
import re
import socket
import socketserver
import ssl
import threading
import time
from pathlib import Path
from typing import Dict, Optional, Tuple

log = logging.getLogger("qosha.egress")

PORT = int(os.environ.get("QOSHA_EGRESS_PORT") or 9245)   # throwaway test labs use their own
READ_METHODS = ("GET", "HEAD")
# read-only query services that take the query as a POST body (maps skill: maps_client.py OVERPASS_URLS)
READ_POSTS = {("overpass-api.de", "/api/interpreter"), ("overpass.kumi.systems", "/api/interpreter")}
MAX_HEAD = 64 * 1024
MAX_HELD_BODY = 1024 * 1024
MAX_READ_POST = 16 * 1024
CARDS_PER_MINUTE = 10
PORTS = (80, 443)
MAX_CONNECTIONS = 32
MAX_CERTS = 256
HOP = {"connection", "keep-alive", "proxy-connection", "proxy-authorization", "proxy-authenticate", "te", "trailer",
       "transfer-encoding", "upgrade"}
# GUARDFIX3 (verifier round 2, note 9): headers some servers read as "treat this GET as a POST/PUT/DELETE". Never
# forwarded; one that names any method but GET/HEAD makes the request an action (held on a card, not sent).
METHOD_OVERRIDE = {"x-http-method-override", "x-http-method", "x-method-override", "x-original-method",
                   "x-original-http-method", "x-forwarded-method", "x-ms-method-override"}


def _override_header(name: str) -> bool:
    """GPT review (GUARDFIX3): servers fold '_' into '-' (WSGI's HTTP_X_HTTP_METHOD_OVERRIDE), so names are compared
    with every non-alphanumeric as '-'; and any name that says method-override is one."""
    n = re.sub(r"[^a-z0-9]+", "-", name.strip().lower())
    return n in METHOD_OVERRIDE or "method-override" in n or n.endswith("-http-method")

_server = None
_codebox_server = None
_lock = threading.Lock()
_ctx_cache: Dict[str, ssl.SSLContext] = {}
_cards: list = []


def _home() -> Path:
    from . import store
    return store.engine_home()


def _bundle_path() -> Path:
    return _home().parent / "run" / "tmp" / "qosha-egress" / "bundle.pem"


def _ca_dir() -> Path:
    return _home() / "qosha" / "egress"


def _ca():
    """Qosha's own authority (key 600 in the engine's qosha/ folder, which assistant.sb denies)."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID
    import datetime
    d = _ca_dir()
    key_p, crt_p = d / "ca.key", d / "ca.pem"
    if not (key_p.exists() and crt_p.exists()):
        d.mkdir(mode=0o700, parents=True, exist_ok=True)
        key = ec.generate_private_key(ec.SECP256R1())
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Qosha assistant read-only web proxy")])
        now = datetime.datetime.now(datetime.timezone.utc)
        crt = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
               .serial_number(x509.random_serial_number()).not_valid_before(now - datetime.timedelta(days=1))
               .not_valid_after(now + datetime.timedelta(days=3650))
               .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
               .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
               .add_extension(x509.KeyUsage(digital_signature=True, key_cert_sign=True, crl_sign=True,
                                            content_commitment=False, key_encipherment=False, data_encipherment=False,
                                            key_agreement=False, encipher_only=False, decipher_only=False), critical=True)
               .sign(key, hashes.SHA256()))
        fd = os.open(str(key_p) + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                      serialization.NoEncryption()))
        os.replace(str(key_p) + ".tmp", key_p)
        crt_p.write_bytes(crt.public_bytes(serialization.Encoding.PEM))
    key = serialization.load_pem_private_key(key_p.read_bytes(), None)
    crt = x509.load_pem_x509_certificate(crt_p.read_bytes())
    return key, crt, crt_p


HEALTH_HOST = "qosha-egress.invalid"


def _token() -> bytes:
    """A secret only the lab's own processes can read (qosha/egress/token; assistant.sb denies qosha/): another engine
    process of this lab uses it to tell the real proxy from a stand-in on the port."""
    import secrets
    p = _ca_dir() / "token"
    _ca_dir().mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(secrets.token_hex(32))
    except FileExistsError:
        pass
    return p.read_bytes().strip()


def _proof(nonce: str) -> str:
    import hmac
    return hmac.new(_token(), nonce.encode("ascii", "replace"), hashlib.sha256).hexdigest()


def _sibling_serves(port: int, mode: str = "") -> bool:
    """Is the process on the port this lab's own proxy (another engine process of the lab)? Asked with a fresh nonce."""
    import hmac, secrets
    nonce = secrets.token_hex(16)
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=5) as c:
            c.sendall(("GET http://%s/health HTTP/1.1\r\nHost: %s\r\nX-Qosha-Egress-Check: %s\r\n\r\n"
                       % (HEALTH_HOST, HEALTH_HOST, nonce)).encode("ascii"))
            data = b""
            while len(data) < 4096:
                chunk = c.recv(4096)
                if not chunk:
                    break
                data += chunk
    except OSError:
        return False
    body = data.split(b"\r\n\r\n", 1)[-1].decode("ascii", "replace").strip()
    return data.startswith(b"HTTP/1.1 200") and hmac.compare_digest(body, _proof(mode + nonce))


def _write_bundle(ca_pem: Path) -> None:
    import certifi
    b = _bundle_path()
    b.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
    tmp = b.with_name(".bundle.tmp")
    tmp.write_bytes(Path(certifi.where()).read_bytes() + b"\n" + ca_pem.read_bytes())
    os.chmod(tmp, 0o644)
    os.replace(tmp, b)


def _leaf_ctx(host: str) -> ssl.SSLContext:
    with _lock:
        if host in _ctx_cache:
            return _ctx_cache[host]
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID
    import datetime
    ca_key, ca_crt, _ = _ca()
    key = ec.generate_private_key(ec.SECP256R1())
    now = datetime.datetime.now(datetime.timezone.utc)
    try:
        san = x509.IPAddress(ipaddress.ip_address(host))
    except ValueError:
        san = x509.DNSName(host)
    crt = (x509.CertificateBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, host[:64])]))
           .issuer_name(ca_crt.subject).public_key(key.public_key()).serial_number(x509.random_serial_number())
           .not_valid_before(now - datetime.timedelta(days=1)).not_valid_after(now + datetime.timedelta(days=30))
           .add_extension(x509.SubjectAlternativeName([san]), critical=False)
           # Python 3.13+ verifies strictly (VERIFY_X509_STRICT): key identifiers are required
           .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
           .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
           .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
           .add_extension(x509.ExtendedKeyUsage([x509.oid.ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
           .sign(ca_key, hashes.SHA256()))
    d = _ca_dir() / "leaf"
    d.mkdir(mode=0o700, parents=True, exist_ok=True)
    p = d / (hashlib.sha256(host.encode()).hexdigest()[:2] + ".pem")   # at most 256 files, overwritten in turn
    fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(crt.public_bytes(serialization.Encoding.PEM) + key.private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(str(p))
    ctx.set_alpn_protocols(["http/1.1"])
    with _lock:
        if len(_ctx_cache) >= MAX_CERTS:
            _ctx_cache.pop(next(iter(_ctx_cache)))
        _ctx_cache[host] = ctx
    return ctx


def _local_addresses() -> set:
    """This Mac's own IPv4 addresses (a publicly numbered interface is still this Mac), read fresh for every connection
    (GPT review R2: no stale window). {"*"} when they can't be read: then nothing is reached."""
    import subprocess
    try:
        r = subprocess.run(["/sbin/ifconfig"], capture_output=True, text=True, timeout=5)
        addrs = {l.split()[1] for l in r.stdout.splitlines() if l.strip().startswith("inet ")}
    except (OSError, subprocess.SubprocessError, IndexError):
        return {"*"}
    return addrs if r.returncode == 0 and "127.0.0.1" in addrs else {"*"}


def public_address(host: str, port: int) -> Optional[str]:
    """The first address of `host` if EVERY address it resolves to is public; else None (this Mac, the local network,
    link-local, multicast, reserved: Qosha's own services and the person's devices are not the web)."""
    try:
        infos = socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM)
    except OSError:
        return None
    addrs = [i[4][0] for i in infos]
    if not addrs:
        return None
    if port not in PORTS:
        return None
    local = _local_addresses()
    if "*" in local:
        return None
    for a in addrs:
        ip = ipaddress.ip_address(a)
        if not ip.is_global or ip.is_multicast or a in local:
            return None
    return addrs[0]


REPLAY_MAX = 64 * 1024                   # CAPFIX: a held write up to this size is sent on the person's Approve
REPLAY_METHODS = ("POST", "PUT", "PATCH", "DELETE")
REPLAY_HEADERS = ("content-type", "accept", "accept-language", "user-agent")


def _hold(method: str, url: str, body_bytes: int, ctype: str, body: Optional[bytes] = None,
          headers: Optional[Dict[str, str]] = None) -> str:
    """A card under Decisions waiting. CAPFIX (owner order, GPT R1 #10): a plain write (POST/PUT/PATCH/DELETE, a body
    of at most REPLAY_MAX bytes, no method trick) is sent exactly as shown, once, when the person presses Approve; to a
    payment service it never is (payments are always held). Anything else: the card only. Rate-limited."""
    now = time.time()
    with _lock:
        _cards[:] = [t for t in _cards if now - t < 60]
        if len(_cards) >= CARDS_PER_MINUTE:
            return ""
        _cards.append(now)
    from . import store, policy
    host = url.split("/")[2] if "://" in url else url
    pay = policy._pay_host_in(host.lower().split(":")[0]) if hasattr(policy, "_pay_host_in") else None
    replay = body is not None and method in REPLAY_METHODS and len(body) <= REPLAY_MAX and not pay and len(url) <= 2000
    args = {"method": method, "url": url[:2000] if replay else url[:500], "declared_body_bytes": body_bytes,
            "content_type": ctype[:100]}
    shown = ""
    if replay:
        import base64
        args["body_b64"] = base64.b64encode(body).decode("ascii")
        args["headers"] = {k: v[:300] for k, v in (headers or {}).items() if k in REPLAY_HEADERS}
        try:
            text = body.decode("utf-8")
        except UnicodeDecodeError:
            text = "(%d bytes that are not text)" % len(body)
        shown = "%s %s\n\n%s" % (method, url[:2000], text)
    payload = {"server": "", "tool": "web_request", "registered_name": "web_request", "resolved": False,
               "replay": bool(replay), "body": shown,
               "server_label": "Website write by the assistant's code (%s %s)" % (method, host[:80]), "arguments": args}
    if pay:
        payload["payment_host"] = pay
    d = store.record("app.action", payload, {"tool": "web_request", "session_id": "", "task_id": ""}, _home())
    log.warning("qosha egress held %s %s as %s", method, host, d["id"])
    return d["id"] + ("" if replay else "!")


HELD_REPLAY_TEXT = ("Waiting for the person's Approve: decision {id}. This {method} to {host} was not sent yet: Qosha "
                    "shows the person exactly what would be sent, and it is sent once when they press Approve (rule G1). "
                    "Do not retry; tell the person it is waiting on the card.\n")
HELD_TEXT = ("Held for approval: decision {id}. Qosha lets the assistant's code read websites (GET and HEAD) but not "
             "send anything to them, so this {method} to {host} was NOT sent. The person sees it under \"Decisions "
             "waiting\"; approving it does not run this request. Do not retry and do not try another way; tell the "
             "person what you wanted to send and where.\n")
REFUSED_TEXT = ("Not allowed by Qosha: the assistant's code can read websites (GET and HEAD) but not send anything to "
                "them, and this {method} to {host} was not sent (too many held requests this minute, so no new card).\n")
LOCAL_TEXT = ("Not allowed by Qosha: the assistant's code can't reach this Mac's own services or the local network "
              "({host}).\n")


class _Handler(socketserver.StreamRequestHandler):
    timeout = 150

    def _head(self, rfile) -> Optional[Tuple[str, str, str, Dict[str, str], list]]:
        line = rfile.readline(MAX_HEAD)
        if not line:
            return None
        parts = line.decode("latin-1").strip().split(" ")
        if len(parts) != 3:
            return None
        headers, raw, total = {}, [], len(line)
        while True:
            h = rfile.readline(MAX_HEAD)
            total += len(h)
            if total > MAX_HEAD:
                return None
            if h in (b"\r\n", b"\n", b""):
                break
            k, _, v = h.decode("latin-1").partition(":")
            headers[k.strip().lower()] = v.strip()
            raw.append((k.strip(), v.strip()))
        return parts[0].upper(), parts[1], parts[2], headers, raw

    def _reply(self, wfile, code: int, text: str) -> None:
        body = text.encode("utf-8")
        wfile.write(("HTTP/1.1 %d %s\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: %d\r\n"
                     "Connection: close\r\n\r\n" % (code, "Forbidden" if code == 403 else "Bad Gateway", len(body)))
                    .encode("latin-1") + body)
        wfile.flush()

    def handle(self) -> None:
        head = self._head(self.rfile)
        if not head:
            return
        method, target, _, headers, raw = head
        if method == "CONNECT":
            host, _, port = target.rpartition(":")
            host = host.strip("[]")
            try:
                port_n = int(port)
            except ValueError:
                return
            if not public_address(host, port_n):
                return self._reply(self.wfile, 403, LOCAL_TEXT.format(host=host))
            self.wfile.write(b"HTTP/1.1 200 Connection established\r\n\r\n")
            self.wfile.flush()
            try:
                tls = _leaf_ctx(host).wrap_socket(self.connection, server_side=True)
            except (ssl.SSLError, OSError):
                return
            tls.settimeout(150)
            rf, wf = tls.makefile("rb"), tls.makefile("wb")
            inner = self._head(rf)
            if not inner:
                return
            m2, path, _, h2, raw2 = inner
            self._one(m2, "https", host, port_n, path, h2, raw2, rf, wf)
            try:
                wf.flush()
                tls.unwrap()
            except (ssl.SSLError, OSError, ValueError):
                pass
            return
        if target == "http://%s/health" % HEALTH_HOST and method == "GET":
            body = _proof(headers.get("x-qosha-egress-check", "")).encode("ascii")
            self.wfile.write(b"HTTP/1.1 200 OK\r\nContent-Length: %d\r\nConnection: close\r\n\r\n" % len(body) + body)
            return self.wfile.flush()
        if not target.startswith("http://"):
            return self._reply(self.wfile, 403, LOCAL_TEXT.format(host=target[:80]))
        rest = target[len("http://"):]
        hostport, slash, path = rest.partition("/")
        host, _, port = hostport.rpartition(":") if ":" in hostport else (hostport, "", "80")
        try:
            port_n = int(port or 80)
        except ValueError:
            return
        self._one(method, "http", host, port_n, "/" + path if slash else "/", headers, raw, self.rfile, self.wfile)

    @staticmethod
    def _framing(raw) -> Optional[str]:
        """GPT review R1: one unambiguous body framing or nothing. Returns "none", "length", "chunked" or None (refuse):
        both Content-Length and Transfer-Encoding, more than one of either, a length that isn't plain decimal, or a
        transfer coding other than exactly "chunked"."""
        cl = [v.strip() for k, v in raw if k.lower() == "content-length"]
        te = [v.strip().lower() for k, v in raw if k.lower() == "transfer-encoding"]
        if len(cl) > 1 or len(te) > 1 or (cl and te):
            return None
        if te:
            return "chunked" if te[0] == "chunked" else None
        if cl:
            return "length" if cl[0].isdigit() and len(cl[0]) <= 12 else None
        return "none"

    @staticmethod
    def _body(headers: Dict[str, str], rfile, limit: int) -> bytes:
        """Only the map-query exception reads a body: a plain decimal Content-Length (checked by _framing) up to
        `limit`, never chunked."""
        n = int(headers["content-length"])
        return rfile.read(n) if 0 < n <= limit else b""

    def _one(self, method, scheme, host, port, path, headers, raw, rfile, wfile) -> None:
        url = "%s://%s%s%s" % (scheme, host, "" if port in (80, 443) else ":%d" % port, path)
        framing = self._framing(raw)
        if sum(k.lower() == "host" for k, _ in raw) > 1 or sum(k.lower() == "content-type" for k, _ in raw) > 1:
            framing = None   # GPT review R2: one Host and one Content-Type, or nothing
        if framing is None:
            return self._reply(wfile, 403, "Not allowed by Qosha: this request's length is ambiguous, so it was not "
                                           "sent.\n")
        has_body = framing == "chunked" or (framing == "length" and int(headers["content-length"]) > 0)
        upgrade = "upgrade" in headers or "upgrade" in headers.get("connection", "").lower()
        override = sorted({v.strip().upper() for k, v in raw if _override_header(k)} - set(READ_METHODS))
        if override:
            method = "%s (as %s)" % (method, "/".join(override))
        read_post = (method == "POST" and (host.lower(), path) in READ_POSTS and scheme == "https" and port == 443
                     and framing == "length" and int(headers["content-length"]) <= MAX_READ_POST and not upgrade
                     and headers.get("content-type", "").split(";")[0].strip().lower() == "application/x-www-form-urlencoded")
        if not ((method in READ_METHODS and not has_body and not upgrade) or read_post):
            # GPT review R2: a held request's body is never read (nothing to exhaust the engine with); the card shows
            # its declared size only
            declared = int(headers["content-length"]) if framing == "length" else -1
            did = ""
            body = None
            n = 0 if framing == "none" else declared
            if method in REPLAY_METHODS and framing in ("length", "none") and 0 <= n <= REPLAY_MAX and \
                    not upgrade and not override:
                body = self._body(headers, rfile, REPLAY_MAX) if n > 0 else b""
                if len(body) != n:
                    body = None
            try:
                did = _hold(method, url, declared, headers.get("content-type", ""), body, headers)
            except Exception as exc:   # still not sent; the card just couldn't be made
                log.error("qosha egress: card not made: %s", type(exc).__name__)
            replay = bool(did) and not did.endswith("!")
            did = did.rstrip("!")
            text = (HELD_REPLAY_TEXT if replay else HELD_TEXT if did else REFUSED_TEXT).format(id=did, method=method, host=host)
            self._reply(wfile, 403, text)
            # discard what the client is still sending, 16 KB at a time and at most 1 MB, so closing doesn't reset the
            # connection before it read the reply (nothing is kept)
            try:
                self.connection.settimeout(2)
                left = MAX_HELD_BODY
                while left > 0:
                    chunk = rfile.read1(16384) if hasattr(rfile, "read1") else rfile.read(16384)
                    if not chunk:
                        break
                    left -= len(chunk)
            except (OSError, ValueError):
                pass
            return
        ip = public_address(host, port)
        if not ip:
            return self._reply(wfile, 403, LOCAL_TEXT.format(host=host))
        body = self._body(headers, rfile, MAX_READ_POST) if read_post else None
        if read_post:
            import urllib.parse
            try:
                form = urllib.parse.parse_qs(body.decode("ascii"), keep_blank_values=True, strict_parsing=True)
            except (UnicodeDecodeError, ValueError):
                form = {}
            if len(body) > MAX_READ_POST or list(form) != ["data"] or len(form["data"]) != 1:
                return self._reply(wfile, 403, "Not allowed by Qosha: only a map query (one data= field) may be posted "
                                               "to %s; this was not sent.\n" % host)
        try:
            sock = socket.create_connection((ip, port), timeout=120)   # Overpass answers in ~35 s
            if scheme == "https":
                import certifi
                up_ctx = ssl.create_default_context(cafile=certifi.where())
                sock = up_ctx.wrap_socket(sock, server_hostname=host)
                conn = http.client.HTTPSConnection(host, port, timeout=120, context=up_ctx)
            else:
                conn = http.client.HTTPConnection(host, port, timeout=120)
            conn.sock = sock
            conn.putrequest(method, path, skip_host=True, skip_accept_encoding=True)
            # the body's length and the Host are never the client's word (GPT reviews R1, R2): Host is the checked
            # authority, the length is the body actually read
            conn.putheader("Host", host if port in (80, 443) else "%s:%d" % (host, port))
            for k, v in raw:
                if k.lower() not in HOP and not _override_header(k) and k.lower() not in (
                        "content-length", "host", "content-type"):
                    conn.putheader(k, v)
            if read_post:
                conn.putheader("Content-Type", "application/x-www-form-urlencoded")
            conn.putheader("Connection", "close")
            if body is not None:
                conn.putheader("Content-Length", str(len(body)))
            conn.endheaders(body)
            resp = conn.getresponse()
        except (OSError, http.client.HTTPException, ssl.SSLError) as exc:
            return self._reply(wfile, 502, "Qosha's web proxy could not reach %s (%s).\n" % (host, type(exc).__name__))
        out = ["HTTP/1.1 %d %s" % (resp.status, resp.reason)]
        for k, v in resp.getheaders():
            if k.lower() not in HOP and k.lower() != "content-length":
                out.append("%s: %s" % (k, v))
        out.append("Connection: close")
        wfile.write(("\r\n".join(out) + "\r\n\r\n").encode("latin-1"))
        if method != "HEAD":
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                wfile.write(chunk)
        wfile.flush()
        conn.close()


class _Server(socketserver.ThreadingTCPServer):
    daemon_threads = True
    allow_reuse_address = True   # SO_REUSEADDR: a restart isn't blocked by old connections (no second listener: not REUSEPORT)
    _slots = threading.BoundedSemaphore(MAX_CONNECTIONS)

    def process_request(self, request, client_address):
        if not self._slots.acquire(blocking=False):   # the engine's own threads come first
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._slots.release()


def ensure(port: int = PORT) -> bool:
    """Start the proxy in this engine process. True if THIS process now serves it, or another engine process of this lab
    does and proves it (_sibling_serves): a port someone else holds could be a stand-in that forwards anything (GPT
    review R1), so the lab's terminal and code then stay refused."""
    global _server
    if _server is not None:
        return _ensure_codebox(port + 2)
    try:
        _, _, ca_pem = _ca()
        _write_bundle(ca_pem)
    except Exception as exc:
        log.error("qosha egress: no certificate authority: %s", type(exc).__name__)
        return False
    try:
        srv = _Server(("127.0.0.1", port), _Handler)
    except OSError as exc:
        if _sibling_serves(port):   # another engine process of this lab serves it (it proved it knows the lab's token)
            return _ensure_codebox(port + 2)
        log.error("qosha egress: port %d not available (%s); the assistant's terminal and code stay refused", port,
                  type(exc).__name__)
        return False
    _server = srv
    threading.Thread(target=srv.serve_forever, name="qosha-egress", daemon=True).start()
    return _ensure_codebox(port + 2)


def _record_codebox_request(payload):
    """Register, then publish. This callback never performs the HTTP request or approves it."""
    from . import store, connector_client
    moment = time.time()
    with _lock:
        _cards[:] = [t for t in _cards if moment - t < 60]
        if len(_cards) >= CARDS_PER_MINUTE:
            raise ValueError("too many waiting requests")
        _cards.append(moment)
    # Exact request bytes (including credentials) go straight to protected helper
    # storage. Never insert the raw request into the assistant-readable database.
    public = connector_client._post("/v1/code-request", {"payload": payload})
    if not isinstance(public, dict) or set(public.get("arguments") or {}) != {"source", "request_ref", "request_sha256"}:
        raise ValueError("private request registration not confirmed")
    decision = store.record("app.action", public, {"tool": "codebox.web_request"}, _home(), status="registering")
    try:
        result = connector_client.hold(decision["id"], "app.action", public)
        if result.get("status") != "held":
            raise ValueError("request not registered")
        store.publish(decision["id"], _home())
    except Exception:
        store.withdraw(decision["id"], "The code request could not be registered; nothing was sent.", "not_held", _home())
        raise
    return decision["id"]


def _ensure_codebox(port):
    """Separate codebox-only listener: every request is held before DNS/network.

    Existing browser/read proxy routing stays on its original port. A foreign or
    ordinary read listener cannot satisfy the mode-separated proof on this port.
    """
    global _codebox_server
    if _codebox_server is not None:
        return _codebox_server.server_address == ("127.0.0.1", port)
    try:
        import importlib.util
        import sys
        from . import policy
        path = _home().parent / "connector/qosha_codebox_net.py"
        spec = importlib.util.spec_from_file_location("_qosha_codebox_net_listener", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        handler = module.handler_factory(sys.modules[__name__], _record_codebox_request, policy._pay_host_in)
        server = _Server(("127.0.0.1", port), handler)
    except OSError:
        return _sibling_serves(port, "codebox:")
    except Exception as error:
        log.error("qosha codebox: approval listener unavailable (%s)", type(error).__name__)
        return False
    _codebox_server = server
    threading.Thread(target=server.serve_forever, name="qosha-codebox-approval", daemon=True).start()
    return True
