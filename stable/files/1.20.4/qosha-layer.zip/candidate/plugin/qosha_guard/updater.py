"""Qosha updates itself (Ren, 17 Nov 2026 ~16:20: "I want whatever next onboarding or install to follow this method").

What it does, on the person's own computer (Mac and Windows alike):
- Once a day (and when asked: Settings > Version and updates, Home's notice, or in the chat) it reads the update list
  ("manifest") of its channel from the sources in order: the primary address (Qosha's cloud bucket), then the
  fallback (a public repository holding only signed release files). Both addresses come from
  <home>/qosha/updates-config.json, else the defaults below.
- A manifest counts only when its Ed25519 signature matches one of the public keys built into this file (whatever the
  source). Every file must match the size and sha256 the signed manifest gives. Refused: unsigned, wrong signature,
  older or same version, a paused channel or release, a release not meant for this computer's ring
  (ren-mac -> test-pc -> renato -> everyone), or one that needs a newer engine than this one.
- The person sees a small notice (Home and Settings) with one line of what changed: "Update now" or "Tonight"
  (2 AM local; if the computer is not on between 2 and 6 AM it waits for the next night).
- Automatic rings (the signed list's auto_rings; 1.20.2, Ren 20 Nov 2026: "Overnight updates need to happen as soon as
  the next time someone is online, it cannot wait because most of them will not be online in the hours you set"):
  installed at the next check when Qosha is idle (no turn running or waiting, and no typing or message activity for
  IDLE_S), at any hour; activity during the download ends that try with nothing changed, and it is tried again later.
- Updating runs in its own process: download and check again, back up Qosha's layer and the person's Qosha settings,
  stop Qosha, unpack the new layer and run its setup_home.py exactly as the installer's layer step does, put back the
  person's customisations, start Qosha the way it was started, then a health check: the dashboard answers, its pages
  load, the conversation list reads the same conversations, the AI accounts state and the sign-in files are unchanged,
  and the running plugin reports the new version. Any failure: automatic roll back to the version before, and one
  plain line for the person.

The person's own changes to Qosha's program files (contract KEEPEDITS, 18 Nov 2026; keep_edits.py): before the new
release is installed, every file of <home>/plugins/qosha that differs from what the running release installed is
captured; after the install it is put back (the release did not change it), merged line by line with the release's
version (both changed it, in different places), or kept with the release's version saved beside it as
<file>.qosha-<version>.new (both changed the same lines). Every such file is named in the update log and in the
"Qosha was updated" notice; a failed update puts them back byte for byte. An update never starts while a chat is
answering: it waits (checking every 30 s, up to 30 minutes) for the engine to be quiet, and otherwise applies at the
next quiet moment.

Customisations: <home>/qosha/custom/plugin/ mirrors <home>/plugins/qosha/ (for example
custom/plugin/dashboard/pages/chat.html); after every update the updater copies that folder over the new plugin, so a
file there wins over everything else. The person's settings (config.yaml, which updates only add Qosha's own keys to),
SOUL.md, memories, skills they made, chats, sign-ins and files are never replaced by an update.
Removing a file from custom/plugin/ gives Qosha's own version back at the next update.

Google's Gemini tool (agy; contract AGYGUARD, 18 Nov 2026): a signed release may carry an "agy" entry (a pin, see
agy_pin.py). apply() installs it after the layer into <root>/engine/agy (the previous one kept) and puts the previous
one back when the health check fails. Once a day, with the update check, Qosha's own agy is checked (present, pinned
version and bytes, `agy models` answers; no question to Gemini) into <home>/qosha/agy-check.json for the screens.

The engine's own self-update is switched off from Qosha's screens and chat (patch_engine_update_gate and
lock_engine_updates): engine versions come only with a Qosha release.

Standard library only, plus `cryptography` (part of the engine's own environment) for the signature check. The same
file runs three ways: imported by the dashboard (routes, daily check), imported by the plugin in the chat (tool), and
as a separate program for the update itself (python updater.py apply --root ROOT --port PORT).
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

# --- trust and sources ---------------------------------------------------------------------------------------------
# Qosha's release signing key(s): key id -> raw Ed25519 public key (base64). The private key never leaves the release
# Mac (~/.qosha-release/). A second key can be added here by a signed release before the first one is retired.
PUBLIC_KEYS = {
    "3b379198e50e171e": "uY2TmE7t4rsP+i5ttCtQMpZI1PJ4oTlQYmEDqgprnTg=",      # made 17 Nov 2026 16:36 MST
}
# Default sources (each needs Ren's OK before it exists; until then a config file names local or other addresses).
DEFAULT_PRIMARY = "https://storage.googleapis.com/qosha-updates"
DEFAULT_FALLBACK = "https://raw.githubusercontent.com/QoshaAi/qosha-updates/main"
CHANNEL = "stable"
RINGS = ("ren-mac", "test-pc", "renato", "everyone")
DEFAULT_RING = "everyone"
MANIFEST_MAX = 256 * 1024
FILE_MAX = 400 * 1024 * 1024
TONIGHT_HOUR = 2
TONIGHT_WINDOW_H = 4                 # 2 AM .. 6 AM; outside it the update waits for the next night ("Tonight" only)
IDLE_S = 10 * 60                     # automatic updates: no typing or message activity for this long (1.20.2)
CHECK_EVERY_S = 24 * 3600
# a check that found no usable source (all down, or a half-refreshed file server serving a new list with the old
# signature: 17 Nov 2026, refused as it should be) is tried again sooner, not a day later
RETRY_S = 30 * 60
VERSION_RE = re.compile(r"^\d{1,4}(\.\d{1,6}){1,3}$")
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$")
WIN = os.name == "nt"
UPDATER_VERSION = 1
# an update in progress counts as running this long (it may first wait up to 30 minutes for a chat to finish)
APPLY_STALE_S = 45 * 60
QUIET_MAX_S = 30 * 60
QUIET_EVERY_S = 30
QUIET_LAST_S = 5 * 60                # a chat that starts during the backup: waited for up to 5 more minutes
# the door: from the busy check that let the update go on until Qosha is stopped, a new chat turn waits at its start
# (it does not begin answering); it opens by itself after this long, and at once when the update finds it busy
DOOR_TTL_S = 5 * 60

_lock = threading.Lock()


# --- the person's own changes (keep_edits.py) ------------------------------------------------------------------------
KEEP_EDITS_COPY = "qosha-keep-edits.py"     # the copy beside the updater's own copy in <root>/run (see start_apply)


def _load_keep_edits():
    """keep_edits.py, loaded by file: beside this file (the plugin's qosha_guard, or <root>/run where the update runs
    from a copy), else the installed plugin's. Loaded once, when this file is loaded: before an update replaces it."""
    import importlib.util
    here = Path(__file__).resolve().parent
    places = [here / "keep_edits.py", here / KEEP_EDITS_COPY]
    h = os.environ.get("HERMES_HOME")
    if h:
        places.append(Path(h) / "plugins" / "qosha" / "qosha_guard" / "keep_edits.py")
    for p in places:
        mod = _load_keep_edits_file(p)
        if mod is not None:
            return mod
    return None


def _load_keep_edits_file(p: Path):
    """One copy of keep_edits.py, or None when it is missing or does not load (a broken copy is skipped, never fatal:
    18 Nov 2026, the Windows install's rewrite had broken one and every update was refused)."""
    import importlib.util
    try:
        if not p.is_file():
            return None
        spec = importlib.util.spec_from_file_location("qosha_keep_edits", str(p))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod if all(hasattr(mod, n) for n in ("capture", "restore", "record_installed", "put_back")) else None
    except Exception:
        return None


def _keep_edits_from_package(root: Path, zip_path: Path):
    """The update's own keep_edits.py (checked package): written beside the updater's copy in <root>/run and loaded,
    when no copy on this computer loads."""
    try:
        with zipfile.ZipFile(zip_path) as z:
            data = z.read("candidate/plugin/qosha_guard/keep_edits.py")
        (root / "run").mkdir(exist_ok=True)
        dst = root / "run" / KEEP_EDITS_COPY
        dst.write_bytes(data)
        return _load_keep_edits_file(dst)
    except Exception:
        return None


try:
    keep_edits = _load_keep_edits()
except Exception:              # never fatal: _apply_locked falls back to the update's own copy
    keep_edits = None


def _wait_until_quiet_missing(probe, sleep=time.sleep, clock=time.monotonic, max_s=QUIET_MAX_S, every_s=QUIET_EVERY_S):
    return False


# the update waits for a quiet moment through this name (tests replace it)
wait_until_quiet = keep_edits.wait_until_quiet if keep_edits is not None else _wait_until_quiet_missing


# --- places ----------------------------------------------------------------------------------------------------------
def home_dir() -> Path:
    h = os.environ.get("HERMES_HOME")
    if h:
        return Path(h)
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path.home() / ".hermes"


def root_dir(home: Path | None = None) -> Path | None:
    """The per-user Qosha folder (engine/, home/, layer/), or None where Qosha does not install this way (cloud box)."""
    h = (home or home_dir()).resolve()
    r = h.parent
    if (r / "layer" / "setup_home.py").is_file() and (r / "engine").is_dir() and h.name == "home":
        return r
    return None


def _qdir(home: Path) -> Path:
    d = home / "qosha"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _read_json(p: Path, default):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(p: Path, data) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name("." + p.name + ".tmp")
    tmp.write_text(json.dumps(data, indent=1, sort_keys=True), encoding="utf-8")
    os.replace(tmp, p)


_ACC = {}


def _access():
    """access.py beside this file (CONTRACT-ACCESS), loaded by path once."""
    p = Path(__file__).resolve().parent / "access.py"
    m = _ACC.get("m")
    if m is None:
        import importlib.util
        spec = importlib.util.spec_from_file_location("qosha_access_upd", str(p))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        _ACC["m"] = m
    return m


def access_stopped(home: Path | None = None) -> bool:
    """No update is installed while Qosha's access has ended or can't be confirmed. If access.py can't be loaded, this
    counts as stopped (fail closed); start_apply puts a copy beside the run copy of this file."""
    try:
        return bool(_access().stopped(home))
    except Exception:
        return True            # fail closed: start_apply puts access.py beside the run copy of this file


def load_config(home: Path | None = None) -> dict:
    h = home or home_dir()
    c = _read_json(_qdir(h) / "updates-config.json", {})
    if not isinstance(c, dict):
        c = {}
    ring = c.get("ring") if c.get("ring") in RINGS else DEFAULT_RING
    out = {"ring": ring, "channel": str(c.get("channel") or CHANNEL),
           "primary": str(c.get("primary") if c.get("primary") is not None else DEFAULT_PRIMARY),
           "fallback": str(c.get("fallback") if c.get("fallback") is not None else DEFAULT_FALLBACK),
           "auto_check": c.get("auto_check", True) is not False,
           # CONTRACT-ACCESS §9: a release for a ring in the signed list's auto_rings is scheduled for the night by
           # itself, unless the person turned this off (Settings, or by asking Qosha)
           "auto_update": c.get("auto_update", True) is not False,
           "tick_seconds": max(1, int(c.get("tick_seconds") or 600))}
    if not re.fullmatch(r"[a-z0-9-]{1,32}", out["channel"]):
        out["channel"] = CHANNEL
    return out


def set_config(changes: dict, home: Path | None = None) -> dict:
    h = home or home_dir()
    p = _qdir(h) / "updates-config.json"
    c = _read_json(p, {})
    c = c if isinstance(c, dict) else {}
    for k, v in changes.items():
        if k == "ring" and v not in RINGS:
            raise ValueError("ring must be one of " + ", ".join(RINGS))
        c[k] = v
    _write_json(p, c)
    return load_config(h)


def load_state(home: Path | None = None) -> dict:
    s = _read_json(_qdir(home or home_dir()) / "updates.json", {})
    return s if isinstance(s, dict) else {}


def save_state(s: dict, home: Path | None = None) -> None:
    _write_json(_qdir(home or home_dir()) / "updates.json", s)


def _log(root: Path | None, msg: str) -> None:
    line = "%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        if root:
            (root / "logs").mkdir(exist_ok=True)
            with open(root / "logs" / "updates.log", "a", encoding="utf-8") as f:
                f.write(line)
    except OSError:
        pass


# --- versions --------------------------------------------------------------------------------------------------------
def vt(v: str) -> tuple:
    if not isinstance(v, str) or not (v == "0" or VERSION_RE.match(v)):
        return (-1,)
    return tuple(int(x) for x in v.split("."))


def current_version(root: Path | None = None) -> str:
    r = root or root_dir()
    if not r:
        return "0"
    rel = _read_json(r / "layer" / "RELEASE.json", {})
    v = rel.get("version") if isinstance(rel, dict) else None
    return v if isinstance(v, str) and VERSION_RE.match(v) else "0"


def engine_version(root: Path) -> str | None:
    st = _read_json(root / "engine" / "install-stamp.json", {})
    v = st.get("baseVersion") if isinstance(st, dict) else None
    return v if isinstance(v, str) and VERSION_RE.match(v) else None


# --- fetching and checking -------------------------------------------------------------------------------------------
class Refused(Exception):
    """A source answered, but what it served is not acceptable (signature, hash, version, ...)."""


def _url_ok(url: str) -> bool:
    u = urllib.parse.urlsplit(url)
    if u.scheme == "https" and u.hostname:
        return True
    return u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost", "::1")


def _get(url: str, limit: int, timeout: float = 20.0) -> bytes:
    if not _url_ok(url):
        raise Refused("address not allowed (https only): %s" % url)
    req = urllib.request.Request(url, headers={"User-Agent": "Qosha-Updater/%d" % UPDATER_VERSION,
                                               "Cache-Control": "no-cache"})
    opener = urllib.request.build_opener()
    if urllib.parse.urlsplit(url).hostname in ("127.0.0.1", "localhost", "::1"):
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req, timeout=timeout) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise Refused("answer too large")
    return data


def verify_signature(data: bytes, sig_doc: bytes) -> str:
    """Returns the key id that signed `data`; raises Refused otherwise (also when the check cannot run: fail closed)."""
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except Exception:
        raise Refused("signature check not available on this computer")
    try:
        d = json.loads(sig_doc.decode("utf-8"))
        sig = base64.b64decode(d["sig"], validate=True)
        assert d.get("alg") == "ed25519" and len(sig) == 64
    except Exception:
        raise Refused("signature file unreadable")
    for kid, pk in PUBLIC_KEYS.items():
        try:
            Ed25519PublicKey.from_public_bytes(base64.b64decode(pk)).verify(sig, data)
            return kid
        except InvalidSignature:
            continue
        except Exception:
            continue
    raise Refused("signature does not match Qosha's key")


_AP = {}


def _ap():
    """agy_pin (Qosha's pinned Google Gemini tool). Loaded by file: this file also runs as a copy in <root>/run/, so the
    installed plugin's copy (the new one, during an update) is preferred, then the one beside this file."""
    places = [home_dir() / "plugins" / "qosha" / "qosha_guard" / "agy_pin.py", Path(__file__).resolve().parent / "agy_pin.py"]
    for p in places:
        if not p.is_file():
            continue
        key = str(p.resolve())
        mod = _AP.get(key)
        if mod is None:
            import importlib.util
            spec = importlib.util.spec_from_file_location("qosha_agy_pin_%d" % len(_AP), str(p))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            _AP[key] = mod
        return mod
    raise Refused("Qosha's Gemini tool module (agy_pin.py) is missing")


def _valid_release(r) -> bool:
    try:
        if isinstance(r, dict) and "agy" in r:      # Google's Gemini tool at a tested version: a well-formed pin only
            _ap().validate_pin(r["agy"])
        assert isinstance(r, dict) and VERSION_RE.match(r["version"])
        assert isinstance(r.get("rings"), list) and r["rings"] and all(x in RINGS for x in r["rings"])
        assert isinstance(r.get("notes", ""), str) and len(r.get("notes", "")) <= 300
        assert isinstance(r.get("files"), list) and r["files"]
        for f in r["files"]:
            assert NAME_RE.match(f["name"]) and re.fullmatch(r"[0-9a-f]{64}", f["sha256"])
            assert isinstance(f["size"], int) and 0 < f["size"] <= FILE_MAX
            assert f["path"] == "files/%s/%s" % (r["version"], f["name"])
        assert any(f["name"] == "qosha-layer.zip" for f in r["files"])
        if r.get("min_engine") is not None:
            assert VERSION_RE.match(r["min_engine"])
        return True
    except Exception:
        return False


def read_manifest(base: str, channel: str) -> dict:
    """The signed manifest of one source; raises OSError (source down) or Refused (served something unacceptable)."""
    base = base.rstrip("/")
    bust = "?t=%d" % int(time.time())
    data = _get("%s/%s/manifest.json%s" % (base, channel, bust), MANIFEST_MAX)
    sig = _get("%s/%s/manifest.json.sig%s" % (base, channel, bust), 4096)
    kid = verify_signature(data, sig)
    try:
        m = json.loads(data.decode("utf-8"))
    except ValueError:
        raise Refused("manifest unreadable")
    if not (isinstance(m, dict) and m.get("schema") == 1 and m.get("product") == "qosha"
            and m.get("channel") == channel and isinstance(m.get("releases"), list)):
        raise Refused("manifest is not a Qosha manifest for this channel")
    m["_key_id"] = kid
    return m


def pick_release(m: dict, ring: str, current: str, engine: str | None, skip=()):
    """(release or None, reason) for this computer. `skip`: versions that already failed here (rolled back)."""
    if m.get("paused") is True:
        return None, "paused"
    best, why = None, "up_to_date"
    for r in m["releases"]:
        if not _valid_release(r):
            continue
        if vt(r["version"]) <= vt(current) or r["version"] in skip:
            continue
        if r.get("paused") is True:
            why = why if best else "paused"
            continue
        if ring not in r["rings"] and "everyone" not in r["rings"]:
            why = why if best else "not_for_this_ring"
            continue
        if r.get("min_engine") and (engine is None or vt(engine) < vt(r["min_engine"])):
            why = why if best else "needs_newer_engine"
            continue
        if best is None or vt(r["version"]) > vt(best["version"]):
            best = r
    return (best, "available") if best else (None, why)


def find_update(home: Path | None = None, root: Path | None = None) -> dict:
    """Asks the sources in order. Result: {status, release?, source?, tried:[...]} (no exception)."""
    h = home or home_dir()
    r = root or root_dir(h)
    cfg = load_config(h)
    cur = current_version(r)
    eng = engine_version(r) if r else None
    tried = []
    for name in ("primary", "fallback"):
        base = cfg[name]
        if not base:
            continue
        try:
            m = read_manifest(base, cfg["channel"])
        except Refused as e:
            tried.append({"source": name, "result": "refused", "why": str(e)})
            continue
        except (OSError, ValueError, urllib.error.URLError) as e:
            tried.append({"source": name, "result": "unreachable", "why": type(e).__name__})
            continue
        rel, why = pick_release(m, cfg["ring"], cur, eng, load_state(h).get("failed_versions") or [])
        tried.append({"source": name, "result": why})
        out = {"status": why, "current": cur, "ring": cfg["ring"], "tried": tried, "source": name, "base": base}
        ar = m.get("auto_rings")
        out["auto"] = bool(isinstance(ar, list) and cfg["ring"] in ar)      # only a ring named itself
        # the signed agy entry of the release this computer RUNS (for its ring): the pin Repair installs where none is
        # on this computer yet (an install updated by an updater that did not know agy)
        for cr in m["releases"]:
            if (isinstance(cr, dict) and cr.get("version") == cur and cr.get("agy") and _valid_release(cr)
                    and (cfg["ring"] in cr["rings"] or "everyone" in cr["rings"])):
                out["current_agy"] = cr["agy"]
                break
        if rel:
            out["release"] = {k: rel[k] for k in ("version", "notes", "rings", "files", "min_engine", "created", "agy")
                              if k in rel}
        return out
    return {"status": "unreachable", "current": cur, "ring": cfg["ring"], "tried": tried}


def check(home: Path | None = None, quiet: bool = False) -> dict:
    """Checks now and remembers the answer for the screens."""
    h = home or home_dir()
    res = find_update(h)
    if res.get("current_agy"):
        _remember_agy_pin(root_dir(h), res["current_agy"])
    with _lock:
        s = load_state(h)
        s["last_check"] = int(time.time())
        s["last_check_status"] = res["status"]
        if res.get("release"):
            s["available"] = {"version": res["release"]["version"], "notes": res["release"].get("notes", "")}
        elif res["status"] in ("up_to_date", "paused", "not_for_this_ring", "needs_newer_engine"):
            s.pop("available", None)
            if (s.get("tonight") or {}).get("version") and res["status"] != "unreachable":
                s.pop("tonight", None)      # a paused or withdrawn release is not applied at night
        d = s.get("deferred")
        if d and (time.time() >= d.get("until", 0) or d.get("version") != (s.get("available") or {}).get("version")):
            s.pop("deferred", None)         # "Later" lasts until the next day's check, and only for that version
        if res["status"] != "unreachable":
            s["auto"] = bool(res.get("auto"))       # an unreachable check keeps what the last good one said
        if res["status"] != "unreachable" and (s.get("tonight") or {}).get("auto") and not (
                res.get("auto") and load_config(h)["auto_update"]):
            s.pop("tonight", None)          # the ring was taken off auto_rings, or the switch was turned off
        av = s.get("available")
        if (av and res.get("auto") and load_config(h)["auto_update"] and not s.get("tonight") and not s.get("deferred")
                and not access_stopped(h)):
            # the "Tonight" path (every way it is called off still applies), but at the next idle moment (1.20.2)
            s["tonight"] = {"version": av["version"], "at": int(time.time()), "label": "when idle", "auto": True}
            _log(root_dir(h), "scheduled %s for the next time Qosha is idle (automatic updates for ring %s)" % (
                av["version"], res["ring"]))
        save_state(s, h)
    _log(root_dir(h), "check: %s (current %s, ring %s; %s)" % (
        res["status"], res["current"], res["ring"],
        "; ".join("%s=%s" % (t["source"], t["result"]) for t in res["tried"])))
    return status(h)


def download(rel: dict, bases: list, dest: Path, channel: str = CHANNEL) -> dict:
    """Every file of the release into dest, checked against the signed size and sha256 (any source may serve it)."""
    dest.mkdir(parents=True, exist_ok=True)
    out = {}
    for f in rel["files"]:
        got, last = None, "no source"
        for base in bases:
            if not base:
                continue
            try:
                data = _get("%s/%s/%s" % (base.rstrip("/"), channel, f["path"]), f["size"] + 1, timeout=120)
            except Refused as e:
                last = str(e)
                continue
            except (OSError, ValueError, urllib.error.URLError) as e:
                last = type(e).__name__
                continue
            if len(data) != f["size"] or hashlib.sha256(data).hexdigest() != f["sha256"]:
                last = "file %s does not match the signed list" % f["name"]
                continue
            got = data
            break
        if got is None:
            raise Refused(last)
        p = dest / f["name"]
        tmp = p.with_name(p.name + ".part")
        tmp.write_bytes(got)
        os.replace(tmp, p)
        out[f["name"]] = p
    return out


# --- Google's Gemini tool (agy) at the version a signed release names --------------------------------------------------
# A release may carry an "agy" entry (a pin: version, and per computer Google's file, size, sha256 and the program's
# size and sha256). It is installed only from a signed manifest, only with a release this computer's ring takes (both
# checked above), into Qosha's own folder; the program it replaces is kept in engine/agy/previous/ and put back when
# the update's health check fails.
AGY_FILES = ("agy", "agy.exe", "installed.json", "agy-pin.json")


def _agy_key(root: Path, key: str | None = None) -> str:
    ap = _ap()
    if key in ap.KEYS:
        return key
    k = ap.installed_info(root).get("key")
    return k if k in ap.KEYS else ap.this_key()


def _agy_current(root: Path, pin: dict, key: str) -> bool:
    """True when this computer's agy is already exactly the pinned program."""
    ap = _ap()
    exe = ap.agy_path(root, key)
    try:
        return (exe.is_file() and ap.installed_info(root).get("version") == pin["version"]
                and ap._sha_file(exe) == pin["assets"][key]["binary_sha256"])
    except (OSError, KeyError):
        return False


def update_agy(root: Path, rel: dict, key: str | None = None, fetch=None) -> dict:
    """Installs the release's agy (when it has one and this computer does not run it yet). The current program,
    installed.json and agy-pin.json are kept in engine/agy/previous/ first. A failed install changes nothing."""
    root = Path(root)
    if not isinstance(rel, dict) or not rel.get("agy"):
        return {"ok": True, "skipped": True}
    ap = _ap()
    try:
        pin = ap.validate_pin(rel["agy"])
        key = _agy_key(root, key)
    except ValueError as e:
        return {"ok": False, "error": "pin", "plain": "The update's Gemini tool entry is unreadable (%s)." % e}
    if key not in pin["assets"]:
        return {"ok": True, "skipped": True, "why": "no Gemini tool for this computer in this release"}
    if _agy_current(root, pin, key):
        return {"ok": True, "skipped": True}
    d = ap.agy_dir(root)
    staged = d / "previous.new"
    try:
        if staged.exists():
            shutil.rmtree(staged)
        staged.mkdir(parents=True)
        present = []
        for n in AGY_FILES:
            if (d / n).is_file():
                shutil.copy2(d / n, staged / n)
                present.append(n)
        (staged / "previous.json").write_text(json.dumps({"files": present, "at": int(time.time())}), encoding="utf-8")
    except OSError as e:
        shutil.rmtree(staged, ignore_errors=True)
        return {"ok": False, "error": "write", "plain": "Qosha could not keep a copy of its Gemini tool (%s)." % type(e).__name__}
    res = ap.install(root, pin, key, fetch or ap.default_fetch)
    if not res.get("ok"):
        shutil.rmtree(staged, ignore_errors=True)
        return res
    prev = d / "previous"
    shutil.rmtree(prev, ignore_errors=True)
    os.replace(staged, prev)
    _log(root, "agy updated to %s (previous kept)" % pin["version"])
    return res


def rollback_agy(root: Path) -> bool:
    """Puts engine/agy/previous/ back byte for byte (and removes what was not there before). False: nothing to put back."""
    ap = _ap()
    d = ap.agy_dir(Path(root))
    prev = d / "previous"
    info = _read_json(prev / "previous.json", None)
    if not prev.is_dir() or not isinstance(info, dict) or not isinstance(info.get("files"), list):
        return False
    had = [n for n in info["files"] if n in AGY_FILES]
    for n in AGY_FILES:
        try:
            if n in had:
                tmp = d / (".rollback-" + n)
                shutil.copy2(prev / n, tmp)
                os.replace(tmp, d / n)
            elif (d / n).exists():
                (d / n).unlink()
        except OSError as e:
            _log(Path(root), "agy rollback could not restore %s: %s" % (n, type(e).__name__))
            return False
    shutil.rmtree(prev, ignore_errors=True)
    _log(Path(root), "agy rolled back")
    return True


def agy_check_file(root: Path) -> Path:
    return Path(root) / "home" / "qosha" / "agy-check.json"


def agy_daily_check(root: Path, run=None) -> dict:
    """Qosha's own agy: present, the pinned version and bytes, and `agy models` answers (no question to Gemini).
    The answer is kept for the screens in <root>/home/qosha/agy-check.json."""
    root = Path(root)
    try:
        res = _ap().self_check(root, run)
    except Exception as exc:
        res = {"ok": False, "state": "broken", "plain": "Gemini needs a repair: its check could not run (%s)." % type(exc).__name__,
               "version": None}
    try:
        _write_json(agy_check_file(root), dict(res, at=int(time.time())))
    except OSError:
        pass
    return res


def _remember_agy_pin(root: Path | None, agy: dict) -> None:
    """Keeps the signed agy entry of the running release as <root>/engine/agy-pin.json (the installer's copy of the
    pin): what Repair and the daily check install when this computer has no agy of Qosha's own yet."""
    if not root or not (Path(root) / "engine").is_dir():
        return
    try:
        pin = _ap().validate_pin(agy)
        p = Path(root) / "engine" / "agy-pin.json"
        if _read_json(p, None) != pin:
            _write_json(p, pin)
    except Exception as exc:
        _log(Path(root), "agy pin not kept: %s" % type(exc).__name__)


def agy_install_missing(root: Path, fetch=None) -> dict | None:
    """When Qosha's own agy is missing and a pin is known (installer's copy or the running release's signed entry):
    installs it (same checks as the installer). None when there is nothing to do."""
    ap = _ap()
    pin = ap.repair_pin(root)
    if pin is None:
        return None
    try:
        key = _agy_key(root)
    except ValueError:
        return None
    if key not in pin["assets"]:
        return None
    res = ap.install(root, pin, key, fetch or ap.default_fetch)
    _log(Path(root), "agy was missing; install of %s: %s" % (pin["version"], "ok" if res.get("ok") else res.get("error")))
    return res


def _agy_prefetch(root: Path, rel: dict):
    """Before anything is stopped: the release's agy download, checked against the signed size and sha256. Returns a
    fetch that serves it (or None when no agy change is needed); raises Refused when it cannot be had."""
    if not rel.get("agy"):
        return None
    ap = _ap()
    try:
        pin = ap.validate_pin(rel["agy"])
        key = _agy_key(root)
    except ValueError as e:
        raise Refused("the release's Gemini tool entry: %s" % e)
    if key not in pin["assets"] or _agy_current(root, pin, key):
        return None
    a = pin["assets"][key]
    url = pin["url_template"].format(version=pin["version"], file=a["file"])
    try:
        data = ap.default_fetch(url)
    except Exception as e:
        raise Refused("Google's Gemini tool could not be downloaded (%s)" % type(e).__name__)
    if len(data) != a["size"] or hashlib.sha256(data).hexdigest() != a["sha256"]:
        raise Refused("Google's Gemini tool download does not match the signed list")
    return lambda _url: data


# --- idle: when an automatic update may install (1.20.2) --------------------------------------------------------------
def _activity_file(home: Path) -> Path:
    return _qdir(home) / "activity"


def mark_activity(home: Path | None = None) -> None:
    """Typing in Qosha's pages (POST /updates/activity) and every chat turn's start and end mark the last activity."""
    p = _activity_file(home or home_dir())
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(str(int(time.time())), encoding="utf-8")
    except OSError:
        pass


def last_activity(home: Path) -> float:
    try:
        return _activity_file(home).stat().st_mtime
    except OSError:
        return 0.0


def quiet_for_idle(home: Path, now: float | None = None) -> bool:
    """No typing or message activity for IDLE_S."""
    return (now if now is not None else time.time()) - last_activity(home) >= IDLE_S


def _pending_asks(home: Path) -> int:
    """Questions open in a chat: approval cards and "Waiting for you" steps (qosha/asks.json of the home and of every
    profile; ask.py keeps them for an hour). A list that can't be read counts as one (1.20.2 review #2)."""
    n = 0
    files = [home / "qosha" / "asks.json"]
    try:
        if (home / "profiles").exists():
            os.listdir(home / "profiles")       # a folder that can't be listed counts as pending (r1 review #2)
        files += sorted((home / "profiles").glob("*/qosha/asks.json"))
    except OSError:
        return 1
    for p in files:
        if not p.exists():
            continue
        try:
            items = json.loads(p.read_text(encoding="utf-8"))
            n += sum(1 for x in items if isinstance(x, dict) and time.time() - float(x.get("at") or 0) < 3600)
        except Exception:
            return 1
    return n


def idle_at_stop(home: Path) -> bool:
    """In the install process, right before it stops Qosha: no activity for IDLE_S, no turn waiting at the door, and
    nothing waiting for the person (1.20.2 review #1, #2)."""
    try:
        return (quiet_for_idle(home) and _door_waiting(home) == 0 and _pending_asks(home) == 0
                and _door_waiting(home) == 0)   # the door read again, last (r1 review #1)
    except Exception:
        return False


def idle(home: Path, now: float | None = None) -> bool:
    """In the dashboard: no turn running or waiting (the engine's ledger, direct chats, the door), nothing waiting for
    the person (approvals, "Waiting for you"), and no activity for IDLE_S. Anything unreadable counts as not idle."""
    try:
        return (quiet_for_idle(home, now) and not engine_busy() and _direct_busy(home) == 0
                and _door_waiting(home) == 0 and _pending_asks(home) == 0)
    except Exception:
        return False


def _activity_hook(**_kw):
    """pre_llm_call / post_llm_call: a chat turn is activity. Adds nothing to the turn."""
    mark_activity()
    return None


# --- status for the screens ------------------------------------------------------------------------------------------
def in_night_window(now: float | None = None) -> bool:
    """Between 2 and 6 AM on this computer's clock."""
    t = datetime.fromtimestamp(now if now is not None else time.time()).astimezone()
    return TONIGHT_HOUR <= t.hour < TONIGHT_HOUR + TONIGHT_WINDOW_H


def next_tonight(now: datetime | None = None) -> datetime:
    now = now or datetime.now().astimezone()
    t = now.replace(hour=TONIGHT_HOUR, minute=0, second=0, microsecond=0)
    return t if now < t else t + timedelta(days=1)


def status(home: Path | None = None) -> dict:
    h = home or home_dir()
    r = root_dir(h)
    s = load_state(h)
    cfg = load_config(h)
    cur = current_version(r)
    av = s.get("available")
    if av and vt(av.get("version", "")) <= vt(cur):
        av = None
    applying = s.get("applying")
    if applying and time.time() - applying.get("since", 0) > APPLY_STALE_S:
        applying = None                       # a run that never reported back
    if applying and applying.get("waiting") and _cancel_asked(h):
        applying = None                       # cancelled while it waited: the run ends at its next check
    tonight = s.get("tonight") if av else None
    d = s.get("deferred") or {}
    deferred = bool(av and d.get("version") == av.get("version") and time.time() < d.get("until", 0))
    wq = s.get("when_quiet") or {}
    when_quiet = bool(av and wq.get("version") == av.get("version"))
    # Home's notice: "offer" = the card; "tonight" = one quiet line; "none" = nothing (deferred, or nothing waiting).
    # Settings always shows a waiting update with its buttons, whatever this says.
    auto_t = bool(tonight and tonight.get("auto"))     # an automatic update: nothing to decide, no line (1.20.2)
    notice = "none" if not av or applying or auto_t else ("tonight" if tonight else ("none" if deferred else "offer"))
    out = {"local": bool(r), "current": cur, "ring": cfg["ring"], "available": av,
           "last_check": s.get("last_check"), "last_check_status": s.get("last_check_status"),
           "tonight": tonight, "applying": bool(applying), "deferred": deferred,
           "deferred_until": d.get("until") if deferred else None, "notice": notice,
           # waiting: the update has started but waits for the chat that is answering ("Qosha will update when this
           # answer finishes"); when_quiet: an earlier wait ran out, the update applies at the next quiet moment
           "waiting": bool(applying and applying.get("waiting")),
           "when_quiet": when_quiet,
           "last_result": s.get("last_result"),
           # a night update (by itself or "Tonight"): Home doesn't reload by itself when it is done
           "applying_why": (applying or {}).get("why") if applying else None,
           "auto": bool(s.get("auto")), "auto_update": cfg["auto_update"]}
    return out


def schedule_tonight(home: Path | None = None) -> dict:
    h = home or home_dir()
    with _lock:
        s = load_state(h)
        av = s.get("available")
        if not av:
            raise Refused("no update waiting")
        at = next_tonight()
        s["tonight"] = {"version": av["version"], "at": int(at.timestamp()), "label": "%d AM" % TONIGHT_HOUR}
        s.pop("deferred", None)
        save_state(s, h)
    _log(root_dir(h), "scheduled %s for %s" % (av["version"], at.isoformat()))
    return status(h)


def cancel_tonight(home: Path | None = None) -> dict:
    """"Not tonight": the night's update is called off and the notice rests until the next day's check."""
    h = home or home_dir()
    with _lock:
        s = load_state(h)
        s.pop("tonight", None)
        save_state(s, h)
    return defer(h)


DEFER_S = CHECK_EVERY_S


def defer(home: Path | None = None, now: float | None = None) -> dict:
    """"Later" (or the notice's X): Home stops showing this version until the next day's check, in every page,
    tab and window (kept here, not in the page). Settings still shows it with its buttons."""
    h = home or home_dir()
    now = now or time.time()
    with _lock:
        s = load_state(h)
        av = s.get("available")
        if not av:
            raise Refused("no update waiting")
        s["deferred"] = {"version": av["version"], "at": int(now), "until": int(now + DEFER_S)}
        s.pop("when_quiet", None)
        save_state(s, h)
    _log(root_dir(h), "later: %s until the next day's check" % av["version"])
    return status(h)


# --- starting the update (from the dashboard or the chat) ------------------------------------------------------------
def _env_python(root: Path) -> str:
    pat = "installs/*/environments/*/venv/" + ("Scripts/python.exe" if WIN else "bin/python")
    found = sorted((root / "home").glob(pat), key=lambda p: p.stat().st_mtime)
    return str(found[-1]) if found else sys.executable


def _dashboard_port() -> int | None:
    a = sys.argv
    for i, x in enumerate(a[:-1]):
        if x == "--port" and a[i + 1].isdigit():
            return int(a[i + 1])
    return None


def start_apply(port: int | None = None, home: Path | None = None, reason: str = "now") -> dict:
    """Starts the update in its own process (it stops and restarts this dashboard)."""
    h = home or home_dir()
    r = root_dir(h)
    if not r:
        raise Refused("updates are managed elsewhere on this computer")
    if access_stopped(h):
        raise Refused("Qosha's access has ended or can't be confirmed, so no update is installed")
    port = port or _dashboard_port() or load_state(h).get("port") or 9219
    s = load_state(h)
    if s.get("applying") and time.time() - s["applying"].get("since", 0) < APPLY_STALE_S:
        return status(h)
    (r / "run").mkdir(exist_ok=True)
    runner = r / "run" / "qosha-updater.py"
    shutil.copyfile(Path(__file__).resolve(), runner)       # runs from a copy: the update replaces this file
    acc_src = Path(__file__).resolve().parent / "access.py"
    shutil.copyfile(acc_src, r / "run" / "access.py")       # the run copy checks access again before it installs
    ke_src = Path(__file__).resolve().parent / "keep_edits.py"
    if ke_src.is_file():                                     # and keeps the person's changes with the copy beside it
        shutil.copyfile(ke_src, r / "run" / KEEP_EDITS_COPY)
    cmd = [_env_python(r), "-I", str(runner), "apply", "--root", str(r), "--port", str(int(port)), "--why", reason]
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("PYTHON", "PIP_"))}
    env["HERMES_HOME"] = str(h)
    log = open(r / "logs" / "updates-run.log", "ab")
    kw = {}
    if WIN:
        kw["creationflags"] = 0x00000008 | 0x00000200 | 0x08000000     # detached, own group, no window
    else:
        kw["start_new_session"] = True
    try:
        p = subprocess.Popen(cmd, cwd=str(r), env=env, stdin=subprocess.DEVNULL,
                             stdout=log, stderr=subprocess.STDOUT, **kw)
    finally:
        log.close()
    with _lock:
        s = load_state(h)
        s["applying"] = {"since": int(time.time()), "pid": p.pid, "why": reason}
        s["port"] = int(port)
        save_state(s, h)
    _log(r, "update started (%s), process %d" % (reason, p.pid))
    return status(h)


def cancel_wait(home: Path | None = None) -> dict:
    """The person cancels an update that is still waiting for a chat to finish (nothing was changed yet). The waiting
    update process sees it at its next check and stops; an update that already started installing cannot be cancelled.
    Cancel also calls off the night's update and the next-quiet-moment retry, so nothing starts again by itself."""
    h = home or home_dir()
    with _lock:
        s = load_state(h)
        a = s.get("applying")
        s.pop("when_quiet", None)
        s.pop("tonight", None)
        save_state(s, h)
        if a and time.time() - a.get("since", 0) < APPLY_STALE_S:
            if not a.get("waiting"):
                raise Refused("the update is already being installed")
            # a file of its own: the waiting process writes the state file too, and must not overwrite this answer
            _cancel_file(h).write_text(str(int(time.time())), encoding="utf-8")
    _log(root_dir(h), "update cancelled by the person while it waited for a chat")
    return status(h)


def _cancel_file(home: Path) -> Path:
    return _qdir(home) / "update-cancel"


def _cancel_asked(home: Path) -> bool:
    return _cancel_file(home).exists()


def _set_waiting(home: Path, waiting: bool, why: str = "now") -> None:
    with _lock:
        s = load_state(home)
        a = s.get("applying")
        if not isinstance(a, dict):
            a = {"since": int(time.time()), "pid": os.getpid(), "why": why}
        a["waiting"] = waiting
        if waiting:
            a["since"] = int(time.time())       # the 45-minute window counts from the start of the wait
        s["applying"] = a
        save_state(s, home)


# --- background: daily check and the night's update ------------------------------------------------------------------
_bg = {"started": False}


def tick(home: Path | None = None, now: float | None = None) -> str:
    """One pass of the background work. Returns what it did (for tests and the log)."""
    h = home or home_dir()
    if not root_dir(h):
        return "not_local"
    now = now or time.time()
    if access_stopped(h):               # review r1 #13: no install of any kind (Qosha, Gemini's tool) while stopped
        with _lock:
            s = load_state(h)
            if s.get("tonight") or s.get("when_quiet"):
                s.pop("tonight", None)
                s.pop("when_quiet", None)
                save_state(s, h)
                _log(root_dir(h), "the night's update was called off: Qosha's access has ended or can't be confirmed")
        return "access_stopped"
    _memory_daily(h)                  # MEM1-SAFE: the nightly backup (after the access check: it stops with the rest of Qosha)
    cfg = load_config(h)
    s = load_state(h)
    did = "nothing"
    every = RETRY_S if s.get("last_check_status") == "unreachable" else CHECK_EVERY_S
    if cfg["auto_check"] and now - (s.get("last_check") or 0) >= every:
        check(h, quiet=True)
        did = "checked"
        s = load_state(h)
    # once a day, with the update check: Qosha's own Gemini tool (agy) is checked (no question is sent to Gemini)
    r = root_dir(h)
    last_doc = _read_json(agy_check_file(r), {}) if r else {}
    last_agy = last_doc.get("at") if isinstance(last_doc, dict) else None
    if r and now - (last_agy if isinstance(last_agy, (int, float)) else 0) >= CHECK_EVERY_S:
        try:
            if agy_daily_check(r).get("state") == "missing":
                # never installed here (an install that could not download it, or one updated by an updater that did
                # not know agy): the pinned version is installed now, then checked again
                got = agy_install_missing(r)
                if got is not None and got.get("ok"):
                    agy_daily_check(r)
        except Exception as exc:
            _log(r, "agy check failed: %s" % type(exc).__name__)
    # an update that waited 30 minutes for a chat to finish and gave up: applied at the next quiet moment (the person
    # asked for it; "Later", "Not tonight" and Cancel call it off)
    wq = s.get("when_quiet")
    av = s.get("available") or {}
    ap = s.get("applying")
    running = bool(ap and now - ap.get("since", 0) < APPLY_STALE_S)
    if wq and not running:
        if wq.get("version") != av.get("version"):
            with _lock:
                s = load_state(h)
                s.pop("when_quiet", None)
                save_state(s, h)
        elif wq.get("auto") and not idle(h, now):
            pass                                # an automatic update waits for the next idle moment (1.20.2)
        elif not engine_busy():
            start_apply(None, h, reason=str(wq.get("why") or "now"))
            return "quiet_started"
    t = s.get("tonight")
    if t and t.get("auto") and s.get("available") and not s.get("applying"):
        if idle(h, now):                                         # any hour, once Qosha is idle (1.20.2)
            start_apply(None, h, reason="tonight")
            did = "auto_started"
    elif t and s.get("available") and not s.get("applying"):
        if now >= t["at"] + TONIGHT_WINDOW_H * 3600:            # the computer was off or asleep in the window
            with _lock:
                s = load_state(h)
                nt = next_tonight()
                s["tonight"]["at"] = int(nt.timestamp())
                save_state(s, h)
            did = "tonight_moved"
        elif now >= t["at"]:
            start_apply(None, h, reason="tonight")
            did = "tonight_started"
    return did


def tick_pause(home: Path) -> int:
    """Seconds until the next background pass: tick_seconds, but every QUIET_EVERY_S (30 s) while an update waits for
    the next quiet moment, so it applies within 30 s after the chat's answer ends."""
    p = load_config(home)["tick_seconds"]
    try:
        if load_state(home).get("when_quiet"):
            p = min(p, QUIET_EVERY_S)
    except Exception:
        pass
    return max(1, int(p))


def _bg_sleep(home: Path, total: float, sleep=time.sleep) -> float:
    """The background loop's pause: total seconds, but slept in slices of at most QUIET_EVERY_S (30 s). After every
    slice the state is read again, and the pause ends at once when an update now waits for a quiet moment (when_quiet
    is written by the separate apply process, so no in-memory signal could reach this thread). A deferral that begins
    during a long pause is therefore seen within 30 s, and the next pass then runs every 30 s. Elapsed time is the sum
    of the slices slept (not a clock), so the pause always ends. Returns the seconds slept."""
    slept = 0.0
    total = max(0.0, float(total))
    while slept < total:
        step = min(float(QUIET_EVERY_S), total - slept)
        sleep(step)
        slept += step
        try:
            if load_state(home).get("when_quiet"):
                break
        except Exception:
            pass
    return slept


def start_background(home: Path | None = None) -> bool:
    if _bg["started"]:
        return False
    _bg["started"] = True
    h = home or home_dir()

    def work():
        _bg_sleep(h, min(60, tick_pause(h)))
        while True:
            try:
                tick(h)
            except Exception as exc:
                _log(root_dir(h), "background pass failed: %s" % type(exc).__name__)
            _bg_sleep(h, tick_pause(h))
    threading.Thread(target=work, daemon=True, name="qosha-updates").start()
    return True


# --- is a chat answering? --------------------------------------------------------------------------------------------
def engine_busy() -> bool:
    """In the dashboard: True while the engine has a chat turn (or other work) in progress, from the engine's own
    ledger (hermes_cli.web_server_idle_exit.busy_ledger(): a non-empty string or None -> busy). When the ledger cannot
    be read, it counts as busy: an update never risks stopping a chat."""
    try:
        from hermes_cli.web_server_idle_exit import busy_ledger
        v = busy_ledger()
    except Exception:
        return True
    return v is None or bool(v)


# The door. The update's busy check (the dashboard's /busy?hold=1) and the closing of the door are one step under
# _door_lock: when no turn is in progress, the door closes; when one is, the door opens. While it is closed, a chat turn
# that starts waits at its start (the pre_llm_call hook below, registered by register()) and is counted as waiting, so
# the next busy check sees it, answers "busy" and opens the door: that turn then answers normally and the update waits
# for it. A turn can therefore never begin answering between the update's last check and the stop. The door opens by
# itself after DOOR_TTL_S, and when the dashboard starts (mount()).
_door_lock = threading.Lock()


def _door_file(home: Path) -> Path:
    return _qdir(home) / "update-door.json"


def _door_wait_dir(home: Path) -> Path:
    return _qdir(home) / "update-door-waiting"


def door_closed(home: Path) -> bool:
    p = _door_file(home)
    if not p.exists():
        return False
    d = _read_json(p, {})
    until = d.get("until") if isinstance(d, dict) else None
    return isinstance(until, (int, float)) and time.time() < until


def _door_close(home: Path) -> None:
    _write_json(_door_file(home), {"until": time.time() + DOOR_TTL_S, "pid": os.getpid()})


def door_open(home: Path) -> None:
    try:
        _door_file(home).unlink()
    except OSError:
        pass


def _door_waiting(home: Path) -> int:
    """Chat turns now waiting at the closed door (in any Qosha process); markers older than the door's life are
    leftovers of a stopped process and do not count."""
    n = 0
    try:
        for p in _door_wait_dir(home).iterdir():
            try:
                if time.time() - p.stat().st_mtime < DOOR_TTL_S + 60:
                    n += 1
            except OSError:
                pass
    except OSError:
        pass
    return n


DIRECT_STALE_S = 20 * 60


def _direct_dir(home: Path) -> Path:
    return _qdir(home) / "direct-busy"


def _direct_busy(home: Path) -> int:
    """Qosha's own chats that answer outside an engine turn (Ask Gemini, the council) in progress now; a marker older
    than DIRECT_STALE_S is a leftover of a stopped process."""
    n = 0
    d = _direct_dir(home)
    if not d.exists():
        return 0
    try:
        for p in d.iterdir():
            try:
                if time.time() - p.stat().st_mtime < DIRECT_STALE_S:
                    n += 1
            except FileNotFoundError:
                pass
    except OSError:
        return 1                                # can't look: counts as busy (review r2 #12)
    return n


class direct_chat:
    """Around a direct chat (review r1 #12): counted as busy for the update's last look BEFORE it passes the door,
    then waits at a closed door like an engine turn. So an update never stops Qosha in the middle of it."""

    def __init__(self, home: Path | None = None):
        self.h = home or home_dir()
        self.mark = None

    def __enter__(self):
        d = _direct_dir(self.h)               # review r2 #12: no marker, no answer (OSError goes to the caller)
        d.mkdir(parents=True, exist_ok=True)
        self.mark = d / ("%d-%d-%d" % (os.getpid(), threading.get_ident(), time.time_ns()))
        self.mark.write_text("", encoding="utf-8")
        try:
            door_gate()
        except Exception:
            pass
        return self

    def __exit__(self, *exc):
        mark_activity(self.h)           # a direct answer is message activity (1.20.2 review MEDIUM)
        if self.mark is not None:
            try:
                self.mark.unlink()
            except OSError:
                pass
        return False


def busy_and_hold(home: Path, hold: bool) -> bool:
    """In the dashboard, for the /busy route: True while a chat turn is in progress or waiting at the door (then the
    door opens); otherwise False, and with hold the door closes for DOOR_TTL_S (until the update stops Qosha)."""
    with _door_lock:
        busy = engine_busy() or _door_waiting(home) > 0 or _direct_busy(home) > 0
        if busy:
            door_open(home)
        elif hold:
            _door_close(home)
        return busy


def door_gate(**_kw):
    """pre_llm_call hook: while the door is closed (an update is about to stop Qosha), a chat turn waits here before it
    begins answering, marked as waiting so the update's next check sees it and lets it through. Never longer than the
    door's own life. Returns None: it adds nothing to the turn."""
    try:
        h = home_dir()
        if not door_closed(h):
            return None
        mark_activity(h)                # a turn at the door is activity (1.20.2 review #1)
        d = _door_wait_dir(h)
        d.mkdir(parents=True, exist_ok=True)
        mark = d / ("%d-%d-%d" % (os.getpid(), threading.get_ident(), time.time_ns()))
        mark.write_text("", encoding="utf-8")
    except Exception:
        return None
    try:
        end = time.monotonic() + DOOR_TTL_S + 5
        while time.monotonic() < end:
            try:
                if not door_closed(h):
                    break
            except Exception:
                break
            time.sleep(0.5)
    finally:
        try:
            mark.unlink()
        except OSError:
            pass
    return None


def chat_busy_remote(port: int, home: Path) -> bool:
    """From the update process: asks the running dashboard (its /busy route) whether a turn is in progress; when none
    is, the same request closes the door (see busy_and_hold) until Qosha is stopped. Raises when the dashboard does not
    answer (the wait counts that as busy)."""
    tok = _token(port)
    if not tok:
        raise OSError("Qosha's dashboard did not answer")
    code, body = _http(port, "/api/plugins/qosha/updates/busy?hold=1", tok)
    if code != 200:
        raise OSError("the busy check answered %d" % code)
    v = json.loads(body.decode("utf-8")).get("busy")
    if not isinstance(v, bool):
        raise ValueError("the busy check gave no answer")
    return v


def release_door(port: int, home: Path) -> None:
    """From the update process: opens the door again (the update is not stopping Qosha right now). Best effort: the
    door also opens by itself after DOOR_TTL_S."""
    try:
        tok = _token(port)
        if tok:
            _http(port, "/api/plugins/qosha/updates/busy?release=1", tok)
    except Exception:
        pass


# --- the update itself (separate process) ----------------------------------------------------------------------------
def _http(port: int, path: str, token: str | None = None, timeout: float = 10.0):
    req = urllib.request.Request("http://127.0.0.1:%d%s" % (port, path),
                                 headers={"X-Hermes-Session-Token": token} if token else {})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(req, timeout=timeout) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, b""
    except Exception:
        return 0, b""


def _token(port: int) -> str | None:
    code, body = _http(port, "/")
    m = re.search(rb'__HERMES_SESSION_TOKEN__\s*=\s*"([^"]+)"', body or b"")
    return m.group(1).decode() if code == 200 and m else None


def _fingerprint(p: Path) -> str:
    """sha256 of a sign-in file, kept in memory only to prove the update did not change it."""
    try:
        return hashlib.sha256(p.read_bytes()).hexdigest()
    except FileNotFoundError:
        return "absent"
    except OSError:
        return "unreadable"


def snapshot(port: int, home: Path) -> dict:
    tok = _token(port)
    snap = {"token": bool(tok), "sessions": None, "accounts": None,
            "files": {n: _fingerprint(home / n) for n in ("auth.json", ".env", "google_token.json")}}
    if tok:
        c, b = _http(port, "/api/sessions?limit=50", tok)
        if c == 200:
            try:
                snap["sessions"] = sorted(x.get("id") for x in json.loads(b).get("sessions", []))
            except Exception:
                pass
        c, b = _http(port, "/api/plugins/qosha/signin/accounts", tok)
        if c == 200:
            try:
                snap["accounts"] = json.loads(b)
            except Exception:
                pass
    return snap


def health(port: int, home: Path, before: dict, expect_version: str | None, wait_s: int = 240) -> tuple:
    t0 = time.time()
    while time.time() - t0 < wait_s:
        if _http(port, "/api/status")[0] == 200:
            break
        time.sleep(1)
    else:
        return False, "Qosha did not start again"
    tok = None
    for _ in range(30):
        tok = _token(port)
        if tok:
            break
        time.sleep(1)
    if not tok:
        return False, "Qosha's screens did not load"
    code, body = _http(port, "/")
    if code != 200 or b"<title>Qosha</title>" not in body:
        return False, "Qosha's start page did not load"
    for page in ("/dashboard-plugins/qosha/index.html", "/dashboard-plugins/qosha/settings.html"):
        c, b = _http(port, page)
        if c != 200 or b"Qosha" not in b:
            return False, "a Qosha page did not load (%s)" % page.rsplit("/", 1)[-1]
    if expect_version:
        c, b = _http(port, "/api/plugins/qosha/updates/status", tok)
        try:
            v = json.loads(b).get("current") if c == 200 else None
        except Exception:
            v = None
        if v != expect_version:
            return False, "the new version did not start (it reports %s)" % (v or "nothing")
    after = snapshot(port, home)
    if before.get("sessions") is not None:
        if after.get("sessions") is None:
            return False, "the conversation list did not read"
        if not set(before["sessions"]) <= set(after["sessions"]):
            return False, "the conversation list changed"
    if before.get("accounts") is not None:
        # the same answers for every account the previous version reported (a newer version may report more)
        # (gemini_state / gemini_plain are the last self-check of Google's Gemini tool, not an account: an update may
        # rightly change them)
        skip = ("gemini_state", "gemini_plain")
        b = {k: v for k, v in before["accounts"].items() if k not in skip} if isinstance(before["accounts"], dict) else before["accounts"]
        n = after.get("accounts")
        if not isinstance(n, dict) or not isinstance(b, dict) or any(k in n and n[k] != v for k, v in b.items()) or not set(b) <= set(n):
            return False, "the AI accounts state changed"
    if after["files"] != before["files"]:
        return False, "a sign-in file changed"
    return True, "ok"


def _ps_rows() -> list:
    """(pid, ppid, command line) of every process of this person."""
    rows = []
    if WIN:
        ps = ("Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine | "
              "ConvertTo-Json -Compress")
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True,
                           text=True, creationflags=0x08000000)
        try:
            data = json.loads(r.stdout or "[]")
        except ValueError:
            data = []
        for d in data if isinstance(data, list) else [data]:
            rows.append((int(d.get("ProcessId") or 0), int(d.get("ParentProcessId") or 0),
                         "%s %s" % (d.get("ExecutablePath") or "", d.get("CommandLine") or "")))
    else:
        r = subprocess.run(["ps", "-axo", "pid=,ppid=,command="], capture_output=True, text=True)
        for line in r.stdout.splitlines():
            parts = line.strip().split(None, 2)
            if len(parts) == 3 and parts[0].isdigit() and parts[1].isdigit():
                rows.append((int(parts[0]), int(parts[1]), parts[2]))
    return rows


def _norm(s: str) -> str:
    return s.replace("\\", "/").lower() if WIN else s


def stop_qosha(root: Path, port: int) -> dict:
    """Stops this install's launcher and dashboard and their children; only processes proven to belong to this
    install (pid file or child of one, AND its command line names this install's folder), never this process.
    Returns how the launcher was running, to start it again the same way."""
    me = os.getpid()
    rows = _ps_rows()
    by_pid = {p: (pp, c) for p, pp, c in rows}
    rootn = _norm(str(root))
    seeds = []
    launcher_cmd = None
    for name in ("launcher.pid", "dashboard.pid"):
        try:
            pid = int((root / "run" / name).read_text().strip())
        except (OSError, ValueError):
            continue
        if pid in by_pid and rootn in _norm(by_pid[pid][1]):
            seeds.append(pid)
            if name == "launcher.pid" and "launcher.py" in by_pid[pid][1]:
                launcher_cmd = by_pid[pid][1]
    kids = {}
    for p, pp, c in rows:
        kids.setdefault(pp, []).append(p)
    todo, seen = list(seeds), set()
    while todo:
        p = todo.pop()
        if p in seen:
            continue
        seen.add(p)
        todo.extend(kids.get(p, []))
    # never this process nor its own parents: on Windows an environment's python.exe is a small launcher that runs
    # the real Python as its child and takes it down with it (found on the test PC, 17 Nov)
    mine, p = set(), me
    while p and p not in mine and p in by_pid and p not in seeds:     # up to the dashboard that started it
        mine.add(p)
        p = by_pid[p][0]
    mine.add(me)
    victims = [p for p in seen if p not in mine and p in by_pid and rootn in _norm(by_pid[p][1])]
    # parents first, so the launcher cannot start a new dashboard in between
    order = [p for p in seeds if p in victims] + [p for p in victims if p not in seeds]
    for p in order:
        try:
            if WIN:
                subprocess.run(["taskkill", "/PID", str(p), "/F"], capture_output=True, creationflags=0x08000000)
            else:
                os.kill(p, 15)
        except Exception:
            pass
    t0 = time.time()
    while time.time() - t0 < 30:
        alive = {p for p, _, _ in _ps_rows()} & set(order)
        if not alive and _http(port, "/api/status", timeout=2)[0] == 0:
            break
        time.sleep(1)
    else:
        if not WIN:
            for p in order:
                try:
                    os.kill(p, 9)
                except Exception:
                    pass
            time.sleep(2)
    _log(root, "stopped %d Qosha processes" % len(order))
    return {"launcher_cmd": launcher_cmd}


def _launch_agent_label(root: Path):
    if WIN:
        return None
    import plistlib
    d = Path.home() / "Library" / "LaunchAgents"
    for p in sorted(d.glob("*.plist")) if d.is_dir() else []:
        try:
            with open(p, "rb") as f:
                pl = plistlib.load(f)
        except Exception:
            continue
        args = pl.get("ProgramArguments") or []
        if pl.get("WorkingDirectory") == str(root) and any(str(a).endswith("launcher.py") for a in args):
            return pl.get("Label"), p
    return None


def start_qosha(root: Path, port: int, how: dict) -> str:
    la = _launch_agent_label(root)
    if la:
        label, plist = la
        uid = os.getuid()
        r = subprocess.run(["launchctl", "kickstart", "gui/%d/%s" % (uid, label)], capture_output=True)
        if r.returncode != 0:
            subprocess.run(["launchctl", "bootstrap", "gui/%d" % uid, str(plist)], capture_output=True)
        return "launchagent %s" % label
    py = None
    tools = sorted((root / "home" / "tools").glob("python-*"))
    if tools:
        py = tools[-1] / ("pythonw.exe" if WIN else "bin/python3")
    if not py or not py.exists():
        py = Path(sys.executable)
    args = [str(py), "-I", str(root / "layer" / "launcher.py"), "--root", str(root), "--port", str(port)]
    cmd = how.get("launcher_cmd") or ""
    m = re.search(r"--apps\s+(\S+)", cmd)
    if m and not WIN:
        args += ["--apps", m.group(1)]
    if WIN:
        flags = 0x00000008 | 0x00000200 | 0x01000000             # detached, own group, out of this job
        try:
            subprocess.Popen(args, cwd=str(root), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, creationflags=flags)
        except OSError:
            subprocess.Popen(args, cwd=str(root), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, creationflags=0x00000008 | 0x00000200)
    else:
        subprocess.Popen(args, cwd=str(root), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    return "launcher"


def _copytree(src: Path, dst: Path) -> None:
    shutil.copytree(src, dst, symlinks=True, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))


_MEM_RETRY_S = 3600
_mem_state: dict = {}            # per home: {"failed_at": monotonic seconds, "running": bool}
_mem_guard = threading.Lock()


def _nightly_backup_module():
    try:
        from . import nightly_backup as _nb
        return _nb
    except ImportError:            # the updater's own copy, run outside the plugin package
        import importlib.util
        import sys
        _nb = sys.modules.get("qosha_nightly_backup")
        if _nb is None:
            src = Path(__file__).resolve().parent / "nightly_backup.py"
            spec = importlib.util.spec_from_file_location("qosha_nightly_backup", str(src))
            _nb = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(_nb)
            sys.modules["qosha_nightly_backup"] = _nb
        return _nb


def _memory_daily(home: Path) -> None:
    """Never raises: the memory step can never stop the tick or reach the updater's own log."""
    try:
        _memory_daily_step(home)
    except Exception:
        import logging
        logging.getLogger("qosha.memory").warning("Qosha memory step skipped this time")


def _memory_daily_step(home: Path) -> None:
    """MEM1-SAFE, backup only (20 Nov 2026): at most one nightly backup a day (qosha_guard/nightly_backup.py: the
    engine's own full backup, the 7 newest kept). The backup runs on its own thread (one at a time per home), so a slow
    backup never holds up the update checks; after a failure it is tried again an hour later, not on every pass.
    Qosha writes nothing itself; failures go to the log in fixed words."""
    import logging
    mlog = logging.getLogger("qosha.memory")
    key = str(home)
    try:
        nb = _nightly_backup_module()
    except Exception:
        mlog.warning("Qosha nightly backup not set up")
        return
    with _mem_guard:
        st = _mem_state.setdefault(key, {"failed_at": 0.0, "running": False})
        busy = st["running"]
        cooling = st["failed_at"] and time.monotonic() - st["failed_at"] < _MEM_RETRY_S
        if not busy and not cooling:
            st["running"] = True
    if busy or cooling:
        return

    def work():
        ok = False
        try:
            r = nb.daily_backup(home)
            ok = isinstance(r, dict) and bool(r.get("ok"))
            if not ok:
                mlog.warning("Qosha nightly backup not made this time")
        except Exception:
            mlog.warning("Qosha nightly backup not made this time")
        finally:
            with _mem_guard:
                st["running"] = False
                st["failed_at"] = 0.0 if ok else time.monotonic()

    try:
        threading.Thread(target=work, daemon=True, name="qosha-memory-backup").start()
    except Exception:
        with _mem_guard:                # a thread that never started must not keep the job marked as running
            st["running"] = False
            st["failed_at"] = time.monotonic()
        mlog.warning("Qosha nightly backup not started this time")


def backup(root: Path, home: Path, cur: str) -> Path:
    b = root / "updates" / "backups" / ("%s-from-%s" % (time.strftime("%Y%m%d-%H%M%S"), cur))
    b.mkdir(parents=True)
    _copytree(root / "layer", b / "layer")
    if (home / "plugins" / "qosha").is_dir():
        _copytree(home / "plugins" / "qosha", b / "plugin")
    for n in ("config.yaml", "SOUL.md"):
        if (home / n).is_file():
            shutil.copy2(home / n, b / n)
    (b / "DONE").write_text(cur)
    # keep the three newest backups
    olds = sorted(p for p in (root / "updates" / "backups").iterdir() if p.is_dir())
    for p in olds[:-3]:
        shutil.rmtree(p, ignore_errors=True)
    return b


def run_setup_home(root: Path, home: Path) -> tuple:
    py = _env_python(root)
    lay = root / "layer"
    eng = root / "engine"
    out = []
    for cmd in ([py, "-I", str(lay / "engine_exec.py"), "--root", str(root), "--save"],
                [py, "-I", str(lay / "engine_exec.py"), "--root", str(root), "--script", str(lay / "setup_home.py"),
                 "--engine", str(eng), "--src", str(eng), "--home", str(home)]):
        r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(root), creationflags=0x08000000 if WIN else 0)
        out.append((r.stdout or "")[-4000:] + (r.stderr or "")[-2000:])
        if r.returncode != 0:
            return False, "\n".join(out)
    ok = "SETUP HOME DONE" in out[-1]
    return ok, "\n".join(out)


class AccessEnded(Exception):
    """Access ended while the update was being unpacked: nothing has been replaced (verification #9)."""


def install_layer(root: Path, zip_path: Path, before_swap=None) -> None:
    new = root / "layer.new"
    if new.exists():
        shutil.rmtree(new)
    new.mkdir()
    with zipfile.ZipFile(zip_path) as z:
        for n in z.namelist():
            if n.startswith("/") or ".." in Path(n).parts or ":" in n:
                raise Refused("package holds a path outside its folder")
        z.extractall(new)
    if not (new / "setup_home.py").is_file() or not (new / "RELEASE.json").is_file():
        raise Refused("package is not a Qosha layer")
    old = root / "layer.old"
    if old.exists():
        shutil.rmtree(old)
    if before_swap is not None and before_swap():
        shutil.rmtree(new, ignore_errors=True)
        raise AccessEnded()
    os.replace(root / "layer", old)
    os.replace(new, root / "layer")
    shutil.rmtree(old, ignore_errors=True)


SETTINGS_FILES = ("config.yaml", "SOUL.md")


def settings_at_stop(home: Path, b: Path) -> None:
    """Round-3 review #11 (and review r1 #14): the backup was taken before the wait; once Qosha is stopped, the
    person's settings are recorded again exactly as they are now: a file present is copied (to a temporary name, then
    renamed, so a full disk never leaves a cut copy in its place); a file the person removed is recorded as absent, so
    a rollback does not bring it back."""
    for n in SETTINGS_FILES:
        absent = b / (n + ".absent")
        if (home / n).is_file():
            tmp = b / (n + ".at-stop.tmp")
            shutil.copy2(home / n, tmp)
            _replace_retry(tmp, b / n)
            if absent.exists():
                absent.unlink()
        else:
            absent.write_text("removed by the person before the update\n", encoding="utf-8")


WIN_RETRY_S = 10.0


def _replace_retry(src, dst) -> None:
    """os.replace, retried while Windows reports the file in use by another program (a backup tool, an editor):
    final-pass review #4."""
    end = time.monotonic() + WIN_RETRY_S
    while True:
        try:
            os.replace(src, dst)
            return
        except PermissionError:
            if time.monotonic() > end:
                raise
            time.sleep(0.2)


def _sha_or_none(p: Path):
    try:
        return hashlib.sha256(p.read_bytes()).hexdigest()
    except OSError:
        return None


def restore(root: Path, home: Path, b: Path, keep_if_changed: dict | None = None) -> list:
    """Puts the previous layer back, then the person's settings as they were at the stop. A settings file that changed
    after the new version started (keep_if_changed: its hash then) is the person's own newer save and is kept
    (final-pass review #8). Returns the settings files that could not be put back (Qosha is restarted anyway)."""
    lay = root / "layer"
    if lay.exists():
        bad = root / "layer.failed"
        if bad.exists():
            shutil.rmtree(bad, ignore_errors=True)
        os.replace(lay, bad)
        shutil.rmtree(bad, ignore_errors=True)
    _copytree(b / "layer", lay)
    left = []
    for n in SETTINGS_FILES:
        if keep_if_changed is not None and n in keep_if_changed and _sha_or_none(home / n) != keep_if_changed[n]:
            continue                                    # saved by the person after the new version opened: theirs
        try:
            if (b / (n + ".absent")).exists():
                try:
                    (home / n).unlink()
                except FileNotFoundError:
                    pass
            elif (b / n).is_file():
                tmp = home / (n + ".qosha-restore.tmp")      # never a cut file in the person's place (verification #10)
                shutil.copy2(b / n, tmp)
                _replace_retry(tmp, home / n)
        except OSError:
            left.append(n)
    return left


# --- customisations --------------------------------------------------------------------------------------------------
CUSTOM_README = """Your own changes to Qosha's own files live here, so updates never undo them.

custom/plugin/ mirrors Qosha's program folder (plugins/qosha). Put a changed or added file at the same path it has
there, for example custom/plugin/dashboard/pages/chat.html. After every update Qosha copies this folder over its new
files, so your version wins. Delete a file here to get Qosha's own version back at the next update.
Your settings, chats, memories, skills, sign-ins and files are never replaced by an update and do not need to be here.
"""


def custom_dir(home: Path) -> Path:
    d = home / "qosha" / "custom"
    (d / "plugin").mkdir(parents=True, exist_ok=True)
    if not (d / "README.txt").exists():
        (d / "README.txt").write_text(CUSTOM_README, encoding="utf-8")
    return d


def apply_customizations(home: Path) -> list:
    """Copies <home>/qosha/custom/plugin/** over <home>/plugins/qosha/. Regular files only, never outside it."""
    src = custom_dir(home) / "plugin"
    dst = (home / "plugins" / "qosha").resolve()
    done = []
    if not dst.is_dir():
        return done
    for f in sorted(src.rglob("*")):
        if f.is_symlink() or not f.is_file() or "__pycache__" in f.parts:
            continue
        rel = f.relative_to(src)
        t = (dst / rel).resolve()
        if dst not in t.parents:
            continue
        t.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(f, t)
        done.append(rel.as_posix())
    return done


# --- the engine's own self-update: off -------------------------------------------------------------------------------
QOSHA_UPDATE_TEXT = "Qosha keeps itself up to date: see Settings > Version and updates, or ask Qosha to check for updates."
_GATE = "# qosha-update-gate"


def patch_engine_update_gate(engine: Path) -> list:
    """Source patches in the engine (like setup_home.py's): its own update command, the chat's /update and the
    dashboard's Update button all refuse with Qosha's line. Idempotent; returns what was patched."""
    done = []
    spots = [
        ("hermes_cli/update_contract.py",
         '    ``None`` means the install is eligible for in-place update (git checkout or unknown-but-\n'
         '    mutable). Never raises; on any internal error it falls back to the heuristic layer only.\n    """\n',
         '    return UpdateRefusal("qosha-managed", %r, "")  %s\n' % (QOSHA_UPDATE_TEXT, _GATE)),
        ("gateway/slash_commands.py",
         '        restart it may trigger; marker files let this or the next gateway process notify the user."""\n',
         '        return %r  %s\n' % (QOSHA_UPDATE_TEXT, _GATE)),
        ("hermes_cli/web_server_files.py",
         ' pip stays blocked in containers: its\n    apply path mutates the running container filesystem.\n    """\n',
         '    return True  %s\n' % _GATE),
    ]
    for rel, anchor, line in spots:
        p = engine / rel
        try:
            t = p.read_text(encoding="utf-8")
        except OSError:
            continue
        if _GATE in t or anchor not in t:
            if _GATE in t:
                done.append(rel)
            continue
        p.write_text(t.replace(anchor, anchor + line, 1), encoding="utf-8")
        done.append(rel)
    a = engine / "hermes_cli" / "web_routers" / "actions.py"
    try:
        t = a.read_text(encoding="utf-8")
        old = '_MANAGED_EXTERNALLY_MESSAGE = "Hermes updates are managed outside this dashboard in containerized environments."'
        if old in t:
            a.write_text(t.replace(old, "_MANAGED_EXTERNALLY_MESSAGE = %r" % QOSHA_UPDATE_TEXT, 1), encoding="utf-8")
        if "_MANAGED_EXTERNALLY_MESSAGE = %r" % QOSHA_UPDATE_TEXT in a.read_text(encoding="utf-8"):
            done.append("hermes_cli/web_routers/actions.py")
    except OSError:
        pass
    return done


def lock_engine_updates() -> bool:
    """In the running dashboard: the Update button stays hidden (can_update_hermes false) and the engine's update
    routes answer with Qosha's line, also on an install whose engine was not patched yet."""
    try:
        import hermes_cli.web_server_files as wsf
        wsf._dashboard_local_update_managed_externally = lambda: True
    except Exception:
        pass
    ws = sys.modules.get("hermes_cli.web_server")
    app = getattr(ws, "app", None)
    if app is None:
        return False
    try:
        from fastapi.responses import JSONResponse
        from fastapi.routing import APIRoute
    except Exception:
        return False
    if any(getattr(r, "name", "") == "qosha_engine_update_check" for r in app.router.routes):
        return True

    async def qosha_engine_update_check():
        return {"install_method": "qosha", "current_version": "", "behind": None, "update_available": False,
                "can_apply": False, "update_command": "", "message": QOSHA_UPDATE_TEXT}

    async def qosha_engine_update_apply():
        return JSONResponse(status_code=409, content={"ok": False, "error": "managed_by_qosha", "message": QOSHA_UPDATE_TEXT})

    app.router.routes.insert(0, APIRoute("/api/hermes/update/check", qosha_engine_update_check, methods=["GET"],
                                         name="qosha_engine_update_check"))
    app.router.routes.insert(0, APIRoute("/api/hermes/update", qosha_engine_update_apply, methods=["POST"],
                                         name="qosha_engine_update_apply"))
    return True


# --- apply (the separate process) ------------------------------------------------------------------------------------
def _result(home: Path, ok: bool, version: str, message: str, **kw) -> None:
    with _lock:
        s = load_state(home)
        s.pop("applying", None)
        if ok:
            s.pop("available", None)
            s.pop("tonight", None)
            s.pop("deferred", None)
            s.pop("when_quiet", None)
        s["last_result"] = dict({"ok": ok, "version": version, "message": message, "at": int(time.time())}, **kw)
        if not ok and kw.get("tried"):          # a version that failed and was rolled back is not offered again
            s["failed_versions"] = sorted(set((s.get("failed_versions") or []) + [kw["tried"]]))
            if (s.get("available") or {}).get("version") == kw["tried"]:
                s.pop("available", None)
                s.pop("tonight", None)
        hist = s.get("history") or []
        hist.append(s["last_result"])
        s["history"] = hist[-20:]
        save_state(s, home)


def apply(root: Path, port: int, why: str = "now") -> int:
    home = root / "home"
    os.environ["HERMES_HOME"] = str(home)
    lockf = root / "run" / "update.lock"
    try:
        fd = os.open(str(lockf), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
    except FileExistsError:
        if time.time() - lockf.stat().st_mtime < 3600:
            _log(root, "another update is running")
            return 3
        lockf.unlink()
        return apply(root, port, why)
    cur = current_version(root)
    try:
        # Google's Gemini tool goes with the release: update_agy installs the release's agy after the layer (the
        # previous one kept), rollback_agy puts it back when the health check fails
        return _apply_locked(root, home, port, cur, why, agy_update=update_agy, agy_rollback=rollback_agy)
    except Exception as exc:          # anything unexpected before the swap: nothing was changed
        _log(root, "update stopped before changing anything: %s" % exc)
        _result(home, False, cur, "Qosha could not update just now; nothing changed. It will try again later.",
                stage="prepare", detail=str(exc)[:200])
        return 2
    finally:
        try:
            lockf.unlink()
        except OSError:
            pass


def _edits_text(report: list) -> str:
    """The notice's lines for the person's own changes (keep_edits.restore's report)."""
    def names(how):
        return [Path(e["file"]).name for e in report if e.get("how") == how]
    out = []
    kept, merged = names("kept"), names("merged")
    if kept:
        out.append("Your change%s to %s %s kept." % ("s" if len(kept) > 1 else "", ", ".join(kept),
                                                    "were" if len(kept) > 1 else "was"))
    if merged:
        out.append("Your change%s to %s %s kept and combined with this update." % (
            "s" if len(merged) > 1 else "", ", ".join(merged), "were" if len(merged) > 1 else "was"))
    for e in report:
        if e.get("how") == "conflict":
            n = Path(e["file"]).name
            out.append("Your change to %s was kept; this update's version of that %s was not applied. Ask Qosha to "
                       "combine them." % (n, "screen" if n.endswith(".html") else "file"))
        if e.get("how") == "saved":
            n = Path(e["file"]).name
            out.append("This update changed the same part of your Home page that you had changed, so the update's "
                       "Home page is in use and your version is saved in Qosha's folder as %s. Ask Qosha to put your "
                       "change back on top." % ((e.get("aside") or [n + " (saved copy)"])[0]))
    return " ".join(out)


def _when_quiet(home: Path, version: str, why: str) -> None:
    with _lock:
        s = load_state(home)
        auto = bool((s.get("tonight") or {}).get("auto")) and why == "tonight"
        s["when_quiet"] = {"version": version, "why": why, "at": int(time.time()), "auto": auto}
        save_state(s, home)


def _quiet_outcome(root: Path, home: Path, cur: str, new: str, why: str, quiet: bool):
    """After a wait for a quiet moment: None = go on; otherwise the update ends here with nothing changed (7 = the
    person cancelled, 6 = a chat was still answering: it applies at the next quiet moment)."""
    _set_waiting(home, False, why)
    if _cancel_asked(home):
        try:
            _cancel_file(home).unlink()
        except OSError:
            pass
        _log(root, "update to %s cancelled by the person while it waited; nothing changed" % new)
        with _lock:                     # nothing starts again by itself: not tonight, not at the next quiet moment
            s = load_state(home)
            s.pop("tonight", None)
            s.pop("when_quiet", None)
            save_state(s, home)
        _result(home, False, cur, "The update was cancelled; nothing changed.", stage="check", detail="cancelled")
        return 7
    if not quiet:
        _when_quiet(home, new, why)
        _log(root, "a chat was still answering; nothing changed, %s applies at the next quiet moment" % new)
        _result(home, False, cur, "A chat was answering, so Qosha did not update yet; nothing changed. It updates at "
                                  "the next quiet moment.", stage="wait", detail="chat in progress")
        return 6
    return None


def _apply_locked(root: Path, home: Path, port: int, cur: str, why: str, agy_update=None, agy_rollback=None) -> int:
    global keep_edits, wait_until_quiet
    cfg = load_config(home)
    found = find_update(home, root)
    rel = found.get("release")
    if not rel:
        _log(root, "nothing to apply (%s)" % found["status"])
        _result(home, False, cur, {"paused": "Updates are paused for now; nothing changed.",
                                   "up_to_date": "Qosha is already up to date."}.get(
                    found["status"], "No update is available for this computer right now; nothing changed."),
                stage="check", detail=found["status"])
        return 1
    new = rel["version"]
    st0 = load_state(home)
    t = st0.get("tonight") or {}
    wq0 = st0.get("when_quiet") or {}
    if why == "tonight" and (t.get("auto") or wq0.get("auto")) and not idle_at_stop(home):
        _log(root, "automatic update to %s waits until Qosha is idle" % new)
        _result(home, False, cur, "Qosha will update the next time it's idle.", stage="wait", detail="not_idle")
        return 6
    if why == "tonight" and (t.get("auto") or wq0.get("auto")) and not (found.get("auto") and cfg["auto_update"]):
        # scheduled by itself, but the signed list or the person's switch no longer allows it (review r1 MEDIUM)
        _log(root, "automatic update to %s no longer allowed (list or switch); nothing changed" % new)
        with _lock:
            s = load_state(home)
            s.pop("tonight", None)
            s.pop("when_quiet", None)
            save_state(s, home)
        _result(home, False, cur, "Automatic updates are off for this computer; nothing changed.", stage="check",
                detail="auto_off")              # also ends "applying" (review r2 MEDIUM)
        return 1
    if access_stopped(home):
        _log(root, "Qosha's access has ended or can't be confirmed; nothing changed")
        _result(home, False, cur, "Qosha's access has ended or can't be confirmed, so the update was not installed. "
                                  "Nothing changed.", stage="check", detail="access")
        return 8
    bases = [found["base"]] + [cfg[n] for n in ("primary", "fallback") if cfg[n] and cfg[n] != found["base"]]
    files = download(rel, bases, root / "updates" / "downloads" / new, cfg["channel"])
    if keep_edits is None:         # no copy on this computer loads: the checked update brings its own
        keep_edits = _keep_edits_from_package(root, files["qosha-layer.zip"])
        if keep_edits is not None:
            if wait_until_quiet is _wait_until_quiet_missing:   # the quiet-moment check comes with it
                wait_until_quiet = keep_edits.wait_until_quiet
            _log(root, "keep_edits.py taken from the update itself (this computer's copy did not load)")
    if keep_edits is None:
        raise RuntimeError("keep_edits.py is missing beside the updater; nothing was changed")
    _log(root, "downloaded and checked %s (%s)" % (new, ", ".join(sorted(files))))
    # Google's Gemini tool of this release (if it carries one): downloaded and checked now, before anything stops
    agy_fetch = _agy_prefetch(root, rel) if agy_update is not None else None
    if agy_fetch is not None:
        _log(root, "downloaded and checked Google's Gemini tool %s" % rel["agy"].get("version"))
    # never in the middle of a chat: wait (every 30 s, up to 30 minutes) until the engine has no turn in progress.
    # The person can cancel while it waits; nothing has been changed yet.
    try:
        _cancel_file(home).unlink()
    except OSError:
        pass

    def busy():                     # a cancel ends the wait at once (then nothing is done)
        return (not _cancel_asked(home)) and chat_busy_remote(port, home)
    _set_waiting(home, True, why)
    _log(root, "waiting for a quiet moment (no chat answering) before updating to %s" % new)
    quiet = wait_until_quiet(busy)
    rc = _quiet_outcome(root, home, cur, new, why, quiet)
    if rc is not None:
        release_door(port, home)
        return rc
    release_door(port, home)        # the backup below must not keep the person's next message waiting
    before = snapshot(port, home)
    b = backup(root, home, cur)
    _log(root, "backup at %s" % b)
    # the last look, just before stopping. A quiet answer closes the door (chat_busy_remote): from then on a new turn
    # waits at its start instead of answering. The person's changes are captured with the door closed, then checked
    # once more: a turn that began meanwhile (it may itself have changed Qosha's screens) is waited for, and the
    # changes are captured again after it. Qosha is stopped only right after a quiet answer.
    last_until = time.monotonic() + QUIET_LAST_S
    first = True
    while True:
        if not first:
            _set_waiting(home, True, why)
            _log(root, "a chat started just before the update; waiting for it to finish")
        first = False
        quiet = wait_until_quiet(busy, max_s=max(0.0, last_until - time.monotonic()))
        rc = _quiet_outcome(root, home, cur, new, why, quiet)
        if rc is not None:
            release_door(port, home)
            return rc
        # the person's own changes to Qosha's program files, against what the running release installed
        captured = keep_edits.capture(home, root / "layer" / "candidate" / "plugin")
        try:
            still = busy()
        except Exception:
            still = True
        if _cancel_asked(home):         # cancelled during the last look: nothing was changed, nothing is
            rc = _quiet_outcome(root, home, cur, new, why, True)
            release_door(port, home)
            return rc
        if not still:
            break
        release_door(port, home)
    _log(root, "your changes found before the update: %d file(s)%s" % (
        len(captured), (": " + ", ".join(sorted(captured))) if captured else ""))
    if access_stopped(home):            # review r1 #11 / Gemini #5: revoked while it waited: nothing is installed
        release_door(port, home)
        _log(root, "Qosha's access has ended or can't be confirmed; %s was not installed, nothing changed" % new)
        _result(home, False, cur, "Qosha's access has ended or can't be confirmed, so the update was not installed. "
                                  "Nothing changed.", stage="check", detail="access")
        return 8
    if why == "tonight" and (t.get("auto") or wq0.get("auto")) and not idle_at_stop(home):
        # the last look, right before the stop (1.20.2 + review #1/#2): someone typed or chatted, a turn waits at the
        # door, or something waits for the person: nothing is stopped; tried again when Qosha is idle
        release_door(port, home)
        _log(root, "activity while the automatic update to %s got ready; nothing changed, it waits until Qosha is idle"
             % new)
        _result(home, False, cur, "Qosha will update the next time it's idle.", stage="wait", detail="not_idle")
        return 6
    report, edit_bases = [], {}
    try:
        how = stop_qosha(root, port)
    except Exception:
        release_door(port, home)
        raise
    stage = "install"
    agy_changed = False
    at_start = None                     # the settings when the new version started (None: it never started)
    not_back = []
    # round-3 review #11: the backup was taken before the wait; the person's settings are recorded again now that Qosha
    # is stopped. Nothing has been replaced yet: if they can't be recorded, or access ended while Qosha stopped, Qosha
    # is started again exactly as it was, with no restore over the person's files (review r2 #13, #14)
    untouched_why = None
    try:
        settings_at_stop(home, b)
    except Exception as exc:
        untouched_why = "the settings could not be recorded (%s)" % type(exc).__name__
    if untouched_why is None and access_stopped(home):
        untouched_why = "Qosha's access has ended or can't be confirmed"
    if untouched_why is not None:
        _log(root, "%s; %s was not installed, Qosha started again unchanged" % (untouched_why, new))
        try:
            start_qosha(root, port, how)
        finally:
            release_door(port, home)
        _result(home, False, cur, "Qosha did not update; nothing changed.", stage="check", detail=untouched_why[:200])
        return 8
    try:
        install_layer(root, files["qosha-layer.zip"], before_swap=lambda: access_stopped(home))
        ok, out = run_setup_home(root, home)
        _log(root, "setup_home: %s" % ("ok" if ok else "FAILED"))
        if not ok:
            (root / "logs" / ("update-setup-%s.log" % new)).write_text(out, encoding="utf-8")
            raise RuntimeError("Qosha's set-up step did not finish")
        gate = patch_engine_update_gate(root / "engine")
        custom = apply_customizations(home)
        _log(root, "engine update gate: %s; customisations kept: %d" % (", ".join(gate) or "none", len(custom)))
        # the person's changes back over the new release; a file in custom/plugin/ still wins (copied just above)
        stage = "keep"
        custom_set = set(custom)
        report = keep_edits.restore(home, {k: v for k, v in captured.items() if k not in custom_set}, new,
                                    bases_out=edit_bases)
        for e in report:
            if e["how"] in ("conflict", "saved"):
                beside = ", ".join(e.get("aside") or ["%s.qosha-%s.new" % (e["file"], keep_edits._safe_version(new))])
            _log(root, "your change %s: %s%s" % ({"kept": "kept", "merged": "kept and merged",
                                                  "conflict": "kept; the update's version saved beside it",
                                                  "saved": "saved beside the update's version (Home page)"}[e["how"]],
                                                 e["file"], (" -> %s" % beside) if e["how"] in ("conflict", "saved") else ""))
        stage = "install"
        if agy_fetch is not None:
            stage = "gemini"
            ra = agy_update(root, rel, fetch=agy_fetch)
            if not ra.get("ok"):
                raise RuntimeError("Google's Gemini tool could not be updated (%s)" % ra.get("error"))
            agy_changed = not ra.get("skipped")
        stage = "start"
        at_start = {n: _sha_or_none(home / n) for n in SETTINGS_FILES}     # final-pass review #8
        started = start_qosha(root, port, how)
        _log(root, "started (%s)" % started)
        stage = "health"
        ok, why_h = health(port, home, before, new)
        if not ok:
            raise RuntimeError(why_h)
    except AccessEnded:
        _log(root, "Qosha's access ended while %s was unpacked; nothing was replaced, Qosha started again unchanged" % new)
        try:
            start_qosha(root, port, how)
        finally:
            release_door(port, home)
        _result(home, False, cur, "Qosha did not update; nothing changed.", stage="check", detail="access")
        return 8
    except Exception as exc:
        _log(root, "update to %s failed at %s: %s; rolling back to %s" % (new, stage, exc, cur))
        ok2 = False
        try:
            stop_qosha(root, port)
            if agy_changed and agy_rollback is not None:
                _log(root, "Google's Gemini tool put back: %s" % ("ok" if agy_rollback(root) else "FAILED"))
            not_back = restore(root, home, b, keep_if_changed=at_start)
            if not_back:
                _log(root, "rollback: could not put back %s (kept in %s); Qosha is started anyway" % (", ".join(not_back), b))
            ok_s, out = run_setup_home(root, home)
            patch_engine_update_gate(root / "engine")
            apply_customizations(home)
            # the person's own files exactly as they were before the update (kept, merged and conflicted alike)
            try:
                back = keep_edits.put_back(home, captured)
                _log(root, "rollback: your changes put back as they were: %d file(s)" % len(back))
            except Exception as exc3:
                _log(root, "rollback could not put back your changes: %s (a copy is in %s)" % (exc3, b))
            start_qosha(root, port, how)
            ok2, why2 = health(port, home, before, None)
            _log(root, "rollback: %s (%s)" % ("ok" if ok2 else "FAILED", why2 if not ok2 else "set-up %s" % ("ok" if ok_s else "had errors")))
        except Exception as exc2:
            _log(root, "rollback failed: %s" % exc2)
        if ok2 and not_back:
            _result(home, False, cur, "The update to %s did not work, so Qosha went back to the version you had, but "
                                      "could not put back %s; a copy is in %s." % (new, ", ".join(not_back), b),
                    stage=stage, detail=str(exc)[:200], tried=new, needs_help=True)
            return 4
        if ok2:
            _result(home, False, cur, "The update to %s did not work, so Qosha went back to the version you had. "
                                      "Nothing of yours changed." % new, stage=stage, detail=str(exc)[:200], tried=new)
            return 4
        _result(home, False, cur, "Qosha could not finish an update and could not go back by itself. Your chats and "
                                  "settings are safe; a copy of the previous version is in %s." % b, stage=stage,
                detail=str(exc)[:200], tried=new, needs_help=True)
        return 5
    # what this release installed, for the next update's comparison (the person's own versions marked as theirs)
    try:
        keep_edits.record_installed(home, bases=edit_bases)
    except Exception as exc:
        # an out-of-date record would make this release's own changes look like the person's: without one, the next
        # update compares against this release's package instead
        _log(root, "the record of the installed files could not be saved (%s); the next update compares against the "
                   "release package" % exc)
        for d in (keep_edits.installed_dir(home), home / "qosha" / "plugin-base"):
            shutil.rmtree(d, ignore_errors=True)
    try:
        sync_profile_plugins(home)
    except Exception:
        pass
    msg = "Qosha was updated to %s." % new
    if report:
        msg += " " + _edits_text(report)
    _result(home, True, new, msg, notes=rel.get("notes", ""), why=why, kept=report)
    _log(root, "updated %s -> %s (%s)" % (cur, new, why))
    if agy_changed:
        try:
            agy_daily_check(root)       # the screens show the new Gemini tool's state at once
        except Exception:
            pass
    return 0


# --- the dashboard's routes (mounted by plugin_api.py under /api/plugins/qosha/updates) -----------------------------
try:
    from fastapi import APIRouter, Body, Request
    from fastapi.responses import JSONResponse as _JR

    router = APIRouter()

    def _own_port(request) -> int | None:
        """The port this dashboard really listens on: the socket the request came in on, never the address the page
        was opened with. Through a tunnel or a proxy those differ (18 Nov 2026: opened through a test tunnel on 9220,
        the update restarted Qosha on 9220 while the Qosha app looks at 9219)."""
        try:
            srv = request.scope.get("server")
            if srv and isinstance(srv[1], int) and srv[1] > 0:
                return srv[1]
        except Exception:
            pass
        return _dashboard_port() or request.url.port

    def _ok(d, code=200):
        return _JR(status_code=code, content=d, headers={"Cache-Control": "no-store"})

    @router.get("/status")
    def _r_status(request: Request):
        h = home_dir()
        own = _own_port(request)
        if own:
            with _lock:
                s = load_state(h)
                if s.get("port") != own:
                    s["port"] = own
                    save_state(s, h)
        return _ok(status(h))

    @router.get("/busy")
    def _r_busy(hold: int = 0, release: int = 0):
        # for the update process: is a chat turn (or other engine work) in progress? From the engine's own
        # hermes_cli.web_server_idle_exit.busy_ledger(), see engine_busy(), plus turns waiting at the door. hold=1:
        # when none is, the door closes in the same step (busy_and_hold); release=1: the door opens.
        h = home_dir()
        if release:
            with _door_lock:
                door_open(h)
            return _ok({"busy": engine_busy(), "door": "open"})
        return _ok({"busy": busy_and_hold(h, bool(hold))})

    @router.post("/check")
    def _r_check():
        if not root_dir():
            return _ok({"error": "not_local"}, 404)
        return _ok(check())

    @router.post("/auto")
    def _r_auto(body: dict = Body(default={})):
        on = (body or {}).get("on")
        if not isinstance(on, bool):
            return _ok({"error": "bad_request"}, 400)
        set_config({"auto_update": on})
        if not on:
            with _lock:
                s = load_state()
                if (s.get("tonight") or {}).get("auto"):
                    s.pop("tonight", None)      # turned off: a night update Qosha scheduled by itself is called off
                if (s.get("when_quiet") or {}).get("auto"):
                    s.pop("when_quiet", None)   # and its next-quiet-moment retry (review r2)
                save_state(s)
        return _ok(status())

    @router.post("/activity")
    def _r_activity():
        mark_activity()                 # typing in Qosha's pages (qosha-access.js): automatic updates wait (1.20.2)
        return {"ok": True}

    @router.post("/apply")
    def _r_apply(request: Request, body: dict = Body(default={})):
        when = (body or {}).get("when", "now")
        try:
            if when == "tonight":
                return _ok(schedule_tonight())
            if when == "cancel_tonight":
                return _ok(cancel_tonight())
            if when == "later":
                return _ok(defer())
            if when == "cancel":
                return _ok(cancel_wait())
            if when != "now":
                return _ok({"error": "bad_request"}, 400)
            if not status().get("available"):
                return _ok({"error": "no_update"}, 409)
            return _ok(start_apply(_own_port(request)))
        except Refused as e:
            return _ok({"error": str(e)}, 409)
except Exception:          # imported outside the dashboard (the chat, the update process)
    router = None


def _plugin_version(plug: Path) -> str:
    try:
        return str(json.loads((plug / "dashboard" / "manifest.json").read_text(encoding="utf-8")).get("version") or "")
    except Exception:
        return ""


def sync_profile_plugins(home: Path | None = None) -> list:
    """Every profile of this install runs the install's own Qosha plugin (final-pass review #5: a profile cloned under
    an older version kept an old copy without the access check). A profile copy that differs from the main one in
    version, or lacks qosha_guard/access.py, is replaced; the old copy is kept in <profile>/qosha/plugin-before-<v>."""
    h = home or home_dir()
    main = h / "plugins" / "qosha"
    if not (main / "qosha_guard" / "access.py").is_file():
        return []
    want, done = _plugin_version(main), []
    profiles = h / "profiles"
    if not profiles.is_dir():
        return []
    for prof in sorted(p for p in profiles.iterdir() if p.is_dir() and not p.is_symlink()):
        dst = prof / "plugins" / "qosha"
        if not dst.is_dir() or dst.is_symlink():
            continue
        if (dst / "qosha_guard" / "access.py").is_file() and _plugin_version(dst) == want:
            continue
        try:
            new = prof / "plugins" / ".qosha.new"
            if new.exists():
                shutil.rmtree(new)
            _copytree(main, new)
            stem = prof / "qosha" / ("plugin-before-%s-%s" % (_plugin_version(dst) or "old", time.strftime("%Y%m%d-%H%M%S")))
            keep, n = stem, 2
            while keep.exists():                # an earlier backup is never deleted (1.20.1, final-pass new-3)
                keep = Path("%s-%d" % (stem, n))
                n += 1
            keep.parent.mkdir(parents=True, exist_ok=True)
            _replace_retry(dst, keep)
            _replace_retry(new, dst)
            done.append(prof.name)
            _log(root_dir(h), "profile %s: Qosha's plugin brought up to %s (the old copy is in %s)" % (prof.name, want, keep))
        except Exception as exc:
            _log(root_dir(h), "profile %s: Qosha's plugin could not be updated: %s" % (prof.name, type(exc).__name__))
    return done


def mount(parent_router) -> None:
    """Called once by the dashboard: the routes, the engine's update switch-off, the daily check."""
    if router is not None:
        parent_router.include_router(router, prefix="/updates")
    lock_engine_updates()
    try:
        door_open(home_dir())          # a fresh start: no update is about to stop this dashboard
    except Exception:
        pass
    if root_dir():
        custom_dir(home_dir())
        try:
            sync_profile_plugins(home_dir())
        except Exception:
            pass
        start_background()


# --- the chat: a tool Qosha uses when the person asks ----------------------------------------------------------------
def _tool(args, **_kw) -> str:
    a = args if isinstance(args, dict) else {}
    act = str(a.get("action") or "check").lower()
    try:
        if not root_dir():
            return json.dumps({"success": False, "error": "This Qosha is updated by Qosha's team, not from here."})
        if act == "check":
            st = check()
        elif act == "update_now":
            st = status()
            if not st.get("available"):
                st = check()
            if not st.get("available"):
                return json.dumps({"success": True, "result": "Qosha is up to date (version %s)." % st["current"]})
            st = start_apply()
            return json.dumps({"success": True, "result": "Qosha will update to %s when this answer finishes. It "
                               "restarts for about a minute; this chat comes back by itself, and your own changes to "
                               "Qosha's screens are kept." % st["available"]["version"]})
        elif act == "tonight":
            st = status()
            if not st.get("available"):
                st = check()
            if not st.get("available"):
                return json.dumps({"success": True, "result": "Qosha is up to date (version %s)." % st["current"]})
            st = schedule_tonight()
            return json.dumps({"success": True, "result": "Qosha will update to %s tonight at 2 AM if this computer "
                               "is on." % st["available"]["version"]})
        else:
            st = status()
        if st.get("available"):
            txt = "Update available: Qosha %s (you have %s). What changed: %s Ask me to update now or tonight." % (
                st["available"]["version"], st["current"], st["available"].get("notes") or "improvements.")
        else:
            txt = "Qosha is up to date (version %s)." % st["current"]
            if st.get("last_check_status") == "unreachable":
                txt = "Qosha could not reach its update source just now (version %s); it tries again later." % st["current"]
        return json.dumps({"success": True, "result": txt})
    except Refused as e:
        return json.dumps({"success": False, "error": str(e)})


TOOL_SCHEMA = {
    "name": "qosha_updates",
    "description": ("Qosha's own updates (this app). action=check: see whether a new tested Qosha version is "
                    "available and what changed; update_now: install it now (Qosha restarts for about a minute; "
                    "use only when the person asked); tonight: install it at 2 AM tonight. The person's chats, "
                    "memories, settings and sign-ins are kept; a failed update goes back by itself."),
    "parameters": {"type": "object", "properties": {
        "action": {"type": "string", "enum": ["check", "update_now", "tonight", "status"]}}, "required": ["action"]},
}


def register(ctx) -> None:
    """From the plugin's register(): the chat tool, and the engine's own /update switched off in this process."""
    ctx.register_tool(name="qosha_updates", toolset="terminal", schema=TOOL_SCHEMA, handler=_tool,
                      check_fn=lambda: bool(root_dir()), description=TOOL_SCHEMA["description"], emoji="⬆️")
    try:
        ctx.register_hook("pre_llm_call", door_gate)      # a turn never begins answering just before an update stops Qosha
    except Exception:
        pass
    for _hook in ("pre_llm_call", "post_llm_call"):      # a chat turn is activity: automatic updates wait (1.20.2)
        try:
            ctx.register_hook(_hook, _activity_hook)
        except Exception:
            pass
    try:
        import gateway.slash_commands as sc

        async def _qosha_update_command(self, event):
            return QOSHA_UPDATE_TEXT
        for obj in vars(sc).values():
            if isinstance(obj, type) and "_handle_update_command" in vars(obj):
                obj._handle_update_command = _qosha_update_command
    except Exception:
        pass


# --- command line ----------------------------------------------------------------------------------------------------
def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="Qosha's updater")
    ap.add_argument("action", choices=["apply", "check", "status", "tick", "gate", "customize", "ring"])
    ap.add_argument("value", nargs="?", help="for ring: one of " + ", ".join(RINGS))
    ap.add_argument("--root")
    ap.add_argument("--port", type=int, default=9219)
    ap.add_argument("--why", default="now")
    a = ap.parse_args(argv)
    root = Path(a.root).resolve() if a.root else root_dir()
    if not root:
        print("not a per-user Qosha install")
        return 2
    os.environ["HERMES_HOME"] = str(root / "home")
    if a.action == "apply":
        return apply(root, a.port, a.why)
    if a.action == "check":
        print(json.dumps(check(root / "home"), indent=1))
    elif a.action == "status":
        print(json.dumps(status(root / "home"), indent=1))
    elif a.action == "tick":
        print(tick(root / "home"))
    elif a.action == "gate":
        print(json.dumps(patch_engine_update_gate(root / "engine")))
    elif a.action == "ring":
        if a.value not in RINGS:
            print("ring must be one of: " + ", ".join(RINGS))
            return 2
        print(json.dumps(set_config({"ring": a.value}, root / "home")))
    elif a.action == "customize":
        print(json.dumps(apply_customizations(root / "home")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
