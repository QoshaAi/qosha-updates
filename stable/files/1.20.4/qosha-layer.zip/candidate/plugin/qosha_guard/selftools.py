"""Qosha's own tools for looking at and changing Qosha itself (CAPFIX, owner order 6 Nov; council D50 Q3).

qosha_self_view: opens one of Qosha's own screens, read-only, in a separate throwaway headless Chrome run by Qosha's
helper (connector/qosha_selfview.py): a screenshot saved in Your files, the screen's accessibility tree and its text,
with nothing able to click, type, post or open a live connection. The assistant then looks at the screenshot with
vision_analyze and can read the screen's code with read_file.

qosha_change_setting: asks to change one of Qosha's settings. The guard turns every call into an Approve card that shows
exactly what changes (policy.settings_change); the handler below is never reached with a change."""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any

PAGES = ("home", "chat", "skills", "connections", "projects", "settings", "files", "tasks", "automations",
         "conversations")


def _key() -> str:
    try:
        from . import store
        return (store.engine_home() / "qosha" / "connector.key").read_text().strip()
    except Exception:
        return ""


def self_view(args: Any, **_kw) -> str:
    a = args if isinstance(args, dict) else {}
    page = str(a.get("page") or "home").strip().lower()
    if page not in PAGES:
        return json.dumps({"success": False, "error": "Pick one of Qosha's screens: %s." % ", ".join(PAGES)})
    body = {"page": page, "width": a.get("width") or 1440, "height": a.get("height") or 900}
    url = os.environ.get("QOSHA_CONNECTOR_URL", "http://127.0.0.1:9239").rstrip("/") + "/v1/selfview"
    h = {"Content-Type": "application/json"}
    if _key():
        h["X-Qosha-Key"] = _key()
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers=h, method="POST")
    try:
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=240) as r:
            out = json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read(20000) or b"{}")
        except ValueError:
            err = {}
        return json.dumps({"success": False, "error": str(err.get("detail") or err.get("error") or e.code)})
    except (OSError, ValueError) as e:
        return json.dumps({"success": False, "error": "Qosha's helper isn't answering (%s)." % type(e).__name__})
    text = ["Qosha's own screen: %s (%s)" % (page, out.get("url", "")),
            "Screenshot (look at it with vision_analyze): %s" % out.get("screenshot", ""),
            "Full page structure saved as: %s" % out.get("dom_file", ""),
            "Requests the page made: %s allowed (read-only), %s stopped" % (out.get("allowed", 0), out.get("blocked", 0)),
            "", "Accessibility tree (role \"name\"):", str(out.get("ax_tree") or "")[:30000],
            "", "Visible text:", str(out.get("text") or "")[:12000]]
    return json.dumps({"success": True, "result": "\n".join(text)})


def change_setting(args: Any, **_kw) -> str:
    return json.dumps({"success": False, "error": "Qosha changes its settings only on the person's Approve; ask again "
                                                  "and the card will show the exact change."})


_SCHEMAS = {
    "qosha_self_view": ("Look at one of Qosha's own screens (this app) as the person sees it, read-only: returns a "
                        "screenshot file in Your files (open it with vision_analyze), the screen's accessibility tree "
                        "and its visible text. Use it to review Qosha's own UI, readability and layout; read the screen's "
                        "code with read_file (Qosha's plugin and web UI are readable).",
                        {"page": {"type": "string", "enum": list(PAGES)},
                         "width": {"type": "integer", "description": "window width in pixels (default 1440)"},
                         "height": {"type": "integer", "description": "window height in pixels (default 900)"}},
                        ["page"]),
    "qosha_change_setting": ("Change one of Qosha's own settings (its config.yaml), e.g. key display.streaming, value "
                             "false. The person sees exactly what changes on an Approve card in the chat; it changes "
                             "when they press Approve.",
                             {"key": {"type": "string"}, "value": {"type": "string"}}, ["key", "value"]),
}
_HANDLERS = {"qosha_self_view": self_view, "qosha_change_setting": change_setting}
_TOOLSETS = {"qosha_self_view": "browser", "qosha_change_setting": "terminal"}


def register(ctx) -> None:
    for name, (desc, props, req) in _SCHEMAS.items():
        schema = {"name": name, "description": desc, "parameters": {"type": "object", "properties": props, "required": req}}
        ctx.register_tool(name=name, toolset=_TOOLSETS[name], schema=schema, handler=_HANDLERS[name],
                          check_fn=(lambda: bool(os.environ.get("QOSHA_CONNECTOR_URL"))) if name == "qosha_self_view"
                          else (lambda: True), description=desc, emoji="🪞" if name == "qosha_self_view" else "⚙️")
