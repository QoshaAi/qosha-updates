"""Qosha approval policy: decides, for one agent tool call, whether it may run, must be held for a person's approval,
or is refused (INTERFACES.md §4.1).

Non-negotiable 1: agents only suggest. A recognisable email send/reply or calendar write through the engine's own
google-workspace script is HELD: recorded as a decision with its exact payload, and the call itself is blocked. Any
other way to send mail or change the calendar is REFUSED. Everything else is allowed.

The policy is pure (no I/O) except `_script_text`, which reads a local script the agent asks to run so its contents can
be checked too. The hook wrapper (qosha_guard.hook) turns any exception here into a refusal.
"""
from __future__ import annotations

import base64
import binascii
import fnmatch
import hashlib
import json
import os
import posixpath
import re
import shlex
import stat
import sys
import unicodedata
import urllib.parse
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

ALLOW, HOLD, DENY = "allow", "hold", "deny"

# Tools that run code or feed a running shell: their whole text is checked.
CODE_TOOLS = {"terminal", "process", "execute_code", "browser_exec", "browser_cdp"}
# Tools that write files or skills: a file that talks to Google or mail could be run later.
WRITE_TOOLS = {"write_file", "patch", "skill_manage"}
# google_api.py commands that only read (the token has no gmail.modify scope; these never change anything).
READ_ONLY = {("gmail", "search"), ("gmail", "get"), ("gmail", "labels"), ("calendar", "list")}
HOLDABLE = {("gmail", "send"): "email.send", ("gmail", "reply"): "email.reply",
            ("calendar", "create"): "calendar.create", ("calendar", "update"): "calendar.update",
            ("calendar", "delete"): "calendar.delete"}

# Seen anywhere in any tool's arguments: credentials. Never needed by the agent.
CREDENTIAL_MARKERS = ("google_token", "google_client_secret", ".qosha-secrets", "qosha-lab-google-client",
                      # the engine's own sign-ins (ChatGPT and Claude live in auth.json and .env) and the connector key
                      # (GPT R-assist3: reachable by relative path from the engine home)
                      "auth.json", "connector.key", "credentials.json")
ENV_FILE = re.compile(r"(?:^|[\s/'\"=<>|;&(])\.env(?:$|[\s'\";|&)<>])")
# Credential basenames, including the model transport's provider-prefixed files.
# Bound to the complete basename: api-key.py remains readable source, and .key is not a blanket ban.
API_KEY_NAME = r"(?:[A-Za-z0-9][A-Za-z0-9_.-]*[-_])?api[-_]?keys?(?:\.(?:txt|json|env))?"
API_KEY_FILE = re.compile(r"(?:^|[\s/'\"=<>|;&(])(" + API_KEY_NAME + r")(?=$|[\s/'\";|&)<>])", re.I)
# Seen in code/shell/file text: Qosha's own approval machinery, the engine home that holds the plugin, its config and
# the decision store, and the dashboard API that records approvals. The assistant never needs to touch these; a
# command that does could approve, replay or switch off the hold (GPT review R-guard, 2 Nov).
GUARD_MARKERS = (
    "qosha_guard", "plugins/qosha", "hermes_plugins", "decisions.sqlite", "decisions_api", "executor.json",
    "hermes_home", "engine_home", "qoshalab/home", "qoshalab", "/.hermes", "~/.hermes", "config.yaml", "/api/plugins", "api/plugins",
    "x-hermes-session-token", "hermes_session_token", "hermes_dashboard_session_token", ":9219", ":9119", ":9231",
    "plugin_api", "hermes_cli", "plugins.enabled", "hermes_safe_mode", "safe_mode",
    ":9239", ":9241", "v1/ask", "gemini_helper", "v1/execute", "v1/read", "qosha_connector", "connector_client", "qosha/secure", "launchagents",
    "sqlite", "qosha/", "/qosha", "state.db", "kanban.db",
    "launchctl", "osascript", "system events", "crontab", "lab.sb", "sandbox-exec", ".zshrc", ".zprofile", ".bash_profile",
)
# Seen in code/shell/file text: another way to reach Gmail, Calendar or mail. Refused unless the text is a clean
# google_api.py invocation (checked separately).
MAIL_MARKERS = (
    "google_api", "gapi", "googleapis", "googleapiclient", "google.oauth2", "google_auth", "build_service",
    "get_credentials", "gws_bridge", "gmail", "/calendar/v3", "calendar_v3", "calendar.events", "events().insert",
    "himalaya", "sendmail", "smtplib", "smtp", "msmtp", "mutt", "mailx", "agentmail", "emailer.py",
    "graph.microsoft.com", "outlook.office", "mailto:", "google-workspace",
)
# A word, not a substring: `gws` the Google Workspace CLI; `mail` the BSD mail command.
MAIL_WORDS = re.compile(r"(?<![\w.-])(gws|mail)(?![\w-])")
# Ways to hide the markers above (decode-and-run, names built at run time). Refused in every code tool.
OBFUSCATION = re.compile(
    r"\beval\b|\bexec\b|__import__|importlib|\bcompile\s*\(|base64|b64decode|codecs|fromhex|rot.?13|"
    r"\\x[0-9a-f]{2}|\\u00[0-9a-f]{2}|\\[0-7]{3}|\bchr\s*\(|xxd\s+-r|openssl\s+(enc|base64)|"
    r"\bprintf\s+['\"]?\\|\$'|\$\"",
    re.I)
MCP_WRITE = re.compile(r"send|reply|forward|draft|trash|delete|remove|insert|create|update|patch|modify|move|label|"
                       r"archive|schedule|invite|rsvp|respond", re.I)
MCP_MAIL = re.compile(r"mail|gmail|email|outlook|calendar|event|smtp|inbox|message", re.I)
SCRIPT_SUFFIXES = (".py", ".sh", ".bash", ".zsh", ".js", ".mjs", ".cjs", ".ts", ".rb", ".pl", ".php", ".command")
# The engine's own google_api.py: the pinned upstream bytes, or the same with the pilot's 4-scope narrowing.
TRUSTED_GAPI_SHA256 = {
    "d3822ef5cbdfad1d280fb619b9d85f2bdc0f8d8756398eb0189a126e8a6fbf89",
    "62909c3e14eb9924e300c26a3549a62c692f5bfa6c8447927e981a364489a112",
}
GAPI_SUFFIX = "/skills/productivity/google-workspace/scripts/google_api.py"


def _load_trusted_scripts() -> frozenset:
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "trusted_skill_scripts.json")) as fh:
            return frozenset(json.load(fh).get("sha256") or ())
    except (OSError, ValueError):
        return frozenset()


# GUARDFIX (council D43): the release's own skill scripts (trusted_skill_scripts.json, made by make_trusted.py: every
# script of the skill library except those reaching outside services) are the product's code, not the assistant's: the
# assistant can't change the skills folders, so their TEXT is not re-scanned for words (a user agent "Qosha/1.0",
# re.compile, a "find" method). Their arguments are checked like any command's.
TRUSTED_SKILL_SHA256 = _load_trusted_scripts()
SETUP_SUFFIX = "/skills/productivity/google-workspace/scripts/setup.py"
# Set by the hook when the Qosha connector holds the sign-in (QOSHA_CONNECTOR_URL): reads are rewritten to it.
CONNECTOR_CLIENT = ""
# Set by the hook: the engine home, whose scripts/ folder holds the scripts automations run at fire time (D21).
ENGINE_HOME = ""

# D21: automation settings that run OUTSIDE this guard when the automation fires (the engine runs the script, the
# monitor check and the delivery itself, not through a tool call): a person sets them up, never the assistant.
CRON_REFUSED = ("An automation that runs a script, checks a monitor or delivers somewhere other than Qosha acts later "
                "without passing the approval check, so the person sets those up themselves (rule G1): Settings \u2192 Advanced "
                "\u2192 Automation details (a script must already be in Qosha's scripts folder). An automation that runs a "
                "prompt and keeps its result in Qosha (deliver: \"local\") works now: create that one.")
CRON_RUN_FIELDS = ("script", "monitor", "monitor_script", "monitor_url")
SCRIPTS_REFUSED = ("This reaches the data side of Qosha's engine folder, which holds its sign-ins and keys (rule G2) and "
                   "its approval guard, records and automations' scripts (rule G1). What works: read Qosha's code with "
                   "read_file or search_files (its plugin, engine source and web UI are readable by full path); change a "
                   "setting with qosha_change_setting (key and value) (the person approves the exact change on a card); look at its "
                   "screens with qosha_self_view; work on files in Your files or anywhere in the person's home. Archive and "
                   "recursive commands (tar, zip, rsync, find, rg, cp -r, grep -r) aren't run on the engine folder; use "
                   "them on Your files or on plain paths.")   # CAPFIX: rule named, alternatives real (owner order)
# CAPFIX: Qosha's own data files, by name (its code is readable: source_path)
OWN_DATA_REFUSED = ("That is Qosha's own data (%s): its approval records and settings (rule G1) or sign-ins and keys "
                    "(rule G2). Qosha's code is readable (read_file on its plugin, engine source and web UI); settings "
                    "change with qosha_change_setting (key and value), which the person approves on a card.")
# D21: inside the engine home the assistant may use only these (its work folder and the engine's skills, whose
# scripts run through tool calls, which this guard checks); everything else there is off limits to every path
# GUARDFIX (council D43 Q3 A, 5 Nov): also the engine's caches and, in the cloud box (where the person's home folder IS the
# engine home), the cache folders the skills' own scripts use; every other entry, known or new, stays closed
HOME_OPEN = ("files", "skills", "audio_cache", "image_cache")
# ... except these inside them (none: cache/ holds a browser's sign-in state and the engine's tool records, and in the cloud
# box .cache, .venvs, .npm hold programs the release's skills run, so all of them stay closed; GPT r1, Opus r1 B2-B4)
_OPEN_CLOSED: tuple = ()
_HOME_KNOWN = ("scripts", "cron", "hooks", "plugins", "bin", "platforms", "pairing", "qosha", "config.yaml", ".env",
               "auth.json", "state.db", "kanban.db", "projects.db", "sessions", "memories", "logs")
# tools that write many files at once into a destination folder (or the working folder when none is given)
_BULK_ALWAYS = {"unzip", "rsync", "ditto", "cpio", "pax", "7z", "7za", "xar", "unar", "patch", "cpdup", "bsdtar"}
_BULK_COPY = {"cp", "mv", "ln", "install", "rsync", "ditto"}          # last operand is the destination
_GIT_WRITES = {"clone", "checkout", "apply", "am", "pull", "merge", "reset", "restore", "switch", "stash", "worktree",
               "read-tree", "checkout-index", "rebase", "cherry-pick", "revert"}
_DEST_FLAGS = ("-C", "--directory", "-d", "--target-directory", "-t", "-o", "--output")
# Set by the hook: the session's recorded working folders (the terminal's cwd record, the file tools' anchor)
SESSION_CWDS: List[str] = []

# Saving a new skill (founder decision, 3 Nov): the assistant saves the draft in Your files as skill-drafts/<name>.md and shows
# it; skill_manage create with the same name and exactly that text is HELD as a "skill.save" decision; the executor adds
# it to the library (skills/made-by-you/<name>) once, only on Approve, only while the draft still has that text. Every
# other write into the skills folders by the assistant is refused.
SKILL_DRAFTS = "skill-drafts"
SKILL_SAVE_CATEGORY = "made-by-you"
SKILL_NAME = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
SKILL_MAX_CHARS = 100_000
SKILLS_REFUSED = ("The assistant can't write into the skills folders directly. To add a new skill: save the exact text "
                  "as skill-drafts/<name>.md in Your files and open it for the person, then call skill_manage with "
                  "action \"create\", the same name and exactly the same text. Qosha puts it in Decisions waiting; it "
                  "is added to the library only when the person presses Approve. Existing skills can't be changed or "
                  "deleted by the assistant.")
# commands that only read the files they name (a skill's own files may be read or run, never written)
# (no pagers: less -O writes a log file, GPT save-9)
_SKILL_READERS = {"cat", "head", "tail", "ls", "wc", "file", "stat", "grep", "egrep", "fgrep", "diff", "cmp", "shasum",
                  "md5", "sha1sum", "sha256sum"}


@dataclass
class Verdict:
    action: str                       # allow | hold | deny
    reason: str = ""
    kind: str = ""                    # for hold
    payload: Dict[str, Any] = field(default_factory=dict)
    needs_reply_context: bool = False  # email.reply: To/Subject/thread come from the original message


def _strings(value: Any) -> List[str]:
    out: List[str] = []
    if isinstance(value, str):
        out.append(value)
    elif isinstance(value, dict):
        for k, v in value.items():
            out.extend(_strings(k)); out.extend(_strings(v))
    elif isinstance(value, (list, tuple)):
        for v in value:
            out.extend(_strings(v))
    return out


def _fold(text: str) -> str:
    """GUARDFIX3 (GUARDVERIFY4 N2): names compared the way this Mac's disks compare them: NFKC (long s, ligatures and
    full-width letters become their plain forms) and casefold (auth.jſon is auth.json, .ENV is .env)."""
    return unicodedata.normalize("NFKC", text).casefold()


def _squash(text: str) -> str:
    """Lower-case and drop quoting, escapes, concatenation and whitespace so 'goo''gle_api' or "gm"+"ail" still match."""
    t = _fold(text)
    return re.sub(r"[\s'\"\\+`{}()\[\],]", "", t)


def _guard_hit(text: str) -> Optional[str]:
    low, sq = _fold(text), _squash(text)
    for m in GUARD_MARKERS:
        if m in low or _squash(m) in sq:
            return m
    return None


def _mail_hit(text: str) -> Optional[str]:
    hit = _guard_hit(text)
    if hit:
        return hit
    low, sq = text.lower(), _squash(text)
    for m in MAIL_MARKERS:
        if m in low or m.replace("_", "").replace("-", "").replace(".", "") in sq.replace("_", "").replace("-", "").replace(".", ""):
            return m
    m = MAIL_WORDS.search(low)
    return m.group(1) if m else None


def _cred_hit(text: str) -> Optional[str]:
    sq, low = _squash(text), _fold(text)
    key = API_KEY_FILE.search(low) or API_KEY_FILE.search(re.sub(r"['\"\\]", "", low))
    if key:
        return key.group(1)
    for m in CREDENTIAL_MARKERS:
        if m in low or _squash(m) in sq:
            return m
    if ENV_FILE.search(text) or ENV_FILE.search(low):
        return ".env"
    return None


# The credential files themselves, for names the shell builds from quotes, escapes, globs, braces or expansions
# (GPT R-assist4: `cat home/.e''nv`, `cat home/.en\v` and `cat home/a?th.json` reached them).
CRED_NAMES = (".env", "auth.json", "connector.key", "credentials.json", "google_token.json",
              "google_client_secret.json", ".qosha-secrets", "qosha-lab-google-client.json",
              "api-key", "api_key", "apikey", "anthropic-api-key", "openai-api-key", "google-api-key",
              "gemini-api-key", "anthropic_api_key", "openai_api_key")
CRED_DIRS = (".qosha-secrets",)               # a wildcard folder in the middle of a path can only reach these
_EXP = "\x04"                                  # an expansion ($X, ${X}, $(..), `..`): could be any text, even none
_BO, _BC, _BS = "\x01", "\x03", "\x02"         # unquoted { } , (brace expansion)
_QUOTED = {"*": "\x05", "?": "\x06", "[": "\x07"}  # quoted or escaped * ? [: literal characters, not globs
_UNQUOTE = {v: k for k, v in _QUOTED.items()}
_WORD_END = set(" \t\r\n;&|<>()")
_FIND_PATTERN_FLAGS = {"-name", "-iname", "-path", "-ipath", "-wholename", "-iwholename", "--include", "-g", "--glob"}


def _shell_words(text: str, nested: Optional[List[str]] = None) -> List[tuple]:
    """Shell words as (pattern, raw, text) triples. `pattern` is what the shell would match: quoted and escaped
    characters are literal (\x05 \x06 \x07), unquoted * ? [..] are globs, expansions are _EXP. `raw` keeps quoted
    wildcards active, for words a program globs itself (find -name 'a?th.json'). `text` is the word with quotes and
    escapes removed (a `sh -c` body). The bodies of $(..), `..` and ${..} are added to `nested` (GPT R-assist5: they
    run too). Unbalanced quotes run to the end (tolerant, never raises)."""
    words, pat, raw, txt, i, n, have = [], [], [], [], 0, len(text), False
    nested = [] if nested is None else nested
    doc_end = None                             # where the here-document text of the current line ends

    def lit(c):
        pat.append(_QUOTED.get(c, c)); raw.append(c); txt.append(c)

    def skip_group(j, open_c, close_c):        # j just past the opener; returns the index past the matching closer
        return _group_end(text, j, open_c, close_c)

    def expansion(k):
        j = _skip_expansion(text, k, skip_group)
        if text[k] == "`":                     # inside backticks \` \$ \\ stand for ` $ \ (nested backticks, R-assist6)
            nested.append(re.sub(r"\\([`$\\])", r"\1", text[k + 1:j - 1]))
        elif text[k + 1:k + 2] in ("(", "{"):
            nested.append(text[k + 2:j - 1])
        pat.append(_EXP); raw.append(_EXP); txt.append(text[k:j])
        return j

    while i < n:
        c = text[i]
        if c in "<>" and text[i + 1:i + 2] == "(":
            # process substitution <(..) >(..): its body runs, and its output may be fed to a shell (R-assist7)
            if have:
                words.append(("".join(pat), "".join(raw), "".join(txt))); pat, raw, txt, have = [], [], [], False
            j = skip_group(i + 2, "(", ")")
            nested.append(text[i + 2:j - 1])
            words.append((_PSUB, _PSUB, _PSUB))
            i = j; continue
        if c == "<" and text[i:i + 2] == "<<" and text[i + 2:i + 3] != "<":
            # here-document: its lines are text, not shell words (no globbing). The delimiter is a whole word after
            # quote removal (<<'E'OF ends at EOF, R-assist8); the text starts after this line (after any earlier
            # here-document of the same line) and belongs to THIS command, also when ; or | follows on the line.
            if have:
                words.append(("".join(pat), "".join(raw), "".join(txt))); pat, raw, txt, have = [], [], [], False
            j = i + 2
            strip_tabs = text[j:j + 1] == "-"
            j += strip_tabs
            while j < n and (text[j] in " \t" or text[j:j + 2] == "\\\n"):
                j += 2 if text[j] == "\\" else 1           # blanks and line continuations before the word
            delim, quoted = [], False
            while j < n and text[j] not in " \t\n;&|<>()":
                ch = text[j]
                if ch == "'":
                    k = text.find(ch, j + 1); k = n if k < 0 else k
                    delim.append(text[j + 1:k]); quoted = True; j = k + 1
                elif ch == '"':                        # inside "..": \\ \" \$ \` lose their backslash (R-assist9)
                    k, quoted = j + 1, True
                    while k < n and text[k] != '"':
                        if text[k] == "\\" and text[k + 1:k + 2] == "\n":
                            k += 2                             # a line continuation disappears (R-assist10)
                        elif text[k] == "\\" and text[k + 1:k + 2] in ('\\', '"', "$", "`"):
                            delim.append(text[k + 1]); k += 2
                        else:
                            delim.append(text[k]); k += 1
                    j = k + 1
                elif ch == "\\" and text[j + 1:j + 2] == "\n":
                    j += 2                                     # line continuation
                elif ch == "\\":
                    delim.append(text[j + 1:j + 2]); quoted = True; j += 2
                else:
                    delim.append(ch); j += 1
            delim = "".join(delim)
            if not delim:
                words.append((_UNSURE, _UNSURE, _UNSURE))   # a here-document we can't delimit: refused
                i = n; continue
            start = doc_end if doc_end is not None else (n if text.find("\n", j) < 0 else text.find("\n", j) + 1)
            body, k = [], start
            while k < n:
                e = text.find("\n", k); e = n if e < 0 else e
                line = text[k:e]; k = e + 1
                while not quoted and k < n and (len(line) - len(line.rstrip("\\"))) % 2 == 1:
                    e = text.find("\n", k); e = n if e < 0 else e   # unquoted: a trailing \ joins the next line,
                    line = line[:-1] + text[k:e]; k = e + 1         # also for the terminator (E\<newline>OF)
                if (line.lstrip("\t") if strip_tabs else line) == delim:
                    break
                body.append(line)
            doc_end = min(k, n)
            body = "\n".join(body)
            if not quoted:                             # an unquoted delimiter: $(..) and `..` in the text run
                q = 0
                while q < len(body):
                    if body[q] in "$`":
                        e = _skip_expansion(body, q, lambda jj, o, cc: _group_end(body, jj, o, cc))
                        if body[q] == "`":
                            nested.append(re.sub(r"\\([`$\\])", r"\1", body[q + 1:e - 1]))
                        elif body[q + 1:q + 2] in ("(", "{"):
                            nested.append(body[q + 2:e - 1])
                        q = max(e, q + 1)
                    else:
                        q += 2 if body[q] == "\\" else 1
            words.append((_REDIR_DOC, _REDIR_DOC, _REDIR_DOC))
            words.append((_HEREDOC, body, body))
            i = j; continue
        if c == "\n" and doc_end is not None and doc_end > i:
            if have:
                words.append(("".join(pat), "".join(raw), "".join(txt))); pat, raw, txt, have = [], [], [], False
            words.append((None, None, None))
            i, doc_end = doc_end, None; continue
        if c == "\\" and text[i + 1:i + 2] == "\n":
            i += 2; continue                   # a line continuation: nothing at all
        if c in _WORD_END:
            if c in "<>" and have and re.fullmatch(r"[0-9]+", "".join(txt)):   # GUARDFIX2 (GPT r5): ASCII only
                pat, raw, txt, have = [], [], [], False   # 2>/dev/null: the 2 is a descriptor, not a word (R-assist10)
            if have:
                words.append(("".join(pat), "".join(raw), "".join(txt))); pat, raw, txt, have = [], [], [], False
            nxt = text[i + 1:i + 2]
            if c == "&" and nxt == ">":
                words.append((_REDIR_OUT, _REDIR_OUT, _REDIR_OUT)); i += 2; continue      # &> file
            if c == "|" and nxt == "&":
                words.append((None, "|", None)); i += 2; continue                         # |& : a pipe
            if c in ";&|\n()":
                pipe = c == "|" and nxt != "|" and text[i - 1:i] != "|"
                words.append((None, "|" if pipe else c, None))   # end of a simple command (| : output piped on)
            elif c == "<":
                words.append((_REDIR_IN, _REDIR_IN, _REDIR_IN))   # < << <<< : input from a file or text
            elif c == ">":
                words.append((_REDIR_OUT, _REDIR_OUT, _REDIR_OUT))
            if c in "<>" and nxt == "&":
                i += 1                             # >&2 <&3 : the & belongs to the redirect
            i += 1; continue
        if c == "#" and not have:
            e = text.find("\n", i)
            i = n if e < 0 else e                  # a comment, up to (not including) the end of the line
            continue
        have = True
        if c == "\\":
            if i + 1 < n and text[i + 1] != "\n":
                lit(text[i + 1])
            i += 2
        elif c == "'":
            k = text.find("'", i + 1); k = n if k < 0 else k
            for ch in text[i + 1:k]:
                lit(ch)
            i = k + 1
        elif c == '"':
            i += 1
            while i < n and text[i] != '"':
                if text[i] == "\\" and i + 1 < n and text[i + 1] in '$`"\\\n':
                    if text[i + 1] != "\n":
                        lit(text[i + 1])
                    i += 2
                elif text[i] in "$`" and (text[i] == "`" or _skip_expansion(text, i, skip_group) > i + 1):
                    i = expansion(i)
                else:
                    lit(text[i]); i += 1
            i += 1
        elif c in "$`":
            if c == "$" and _skip_expansion(text, i, skip_group) == i + 1:
                lit("$"); i += 1
            else:
                i = expansion(i)
        elif c in "*?[":
            pat.append(c); raw.append(c); txt.append(c); i += 1
        elif c in "{,}":
            m = {"{": _BO, ",": _BS, "}": _BC}[c]
            pat.append(m); raw.append(m); txt.append(c); i += 1
        else:
            lit(c); i += 1
    if have:
        words.append(("".join(pat), "".join(raw), "".join(txt)))
    return words


def _group_end(text: str, j: int, open_c: str, close_c: str) -> int:
    """j just past the opener; the index past the matching closer, or the end. Quotes, escapes and backticks inside
    are skipped, so a quoted ")" or "}" does not close it early (R-assist8)."""
    n, depth = len(text), 1
    while j < n and depth:
        c = text[j]
        if c == "\\":
            j += 2; continue
        if c == "'":
            k = text.find("'", j + 1); j = n if k < 0 else k + 1; continue
        if c in "\"`":
            k = j + 1
            while k < n and text[k] != c:
                k += 2 if text[k] == "\\" else 1
            j = k + 1; continue
        if c == "$" and text[j + 1:j + 2] in "({":
            j = _group_end(text, j + 2, text[j + 1], ")" if text[j + 1] == "(" else "}"); continue
        depth += (c == open_c) - (c == close_c)
        j += 1
    return min(j, n)


def _skip_expansion(text: str, i: int, skip_group) -> int:
    n = len(text)
    if text[i] == "`":
        j = i + 1
        while j < n and text[j] != "`":
            j += 2 if text[j] == "\\" else 1
        return j + 1
    j = i + 1
    if j < n and text[j] == "{":
        return skip_group(j + 1, "{", "}")
    if j < n and text[j] == "(":
        return skip_group(j + 1, "(", ")")
    if j < n and text[j] in "'\"":                 # $'..' / $"..": ANSI-C and locale strings (refused elsewhere too)
        k = text.find(text[j], j + 1)
        return n if k < 0 else k + 1
    if j < n and (text[j].isalnum() or text[j] == "_"):
        while j < n and (text[j].isalnum() or text[j] == "_"):
            j += 1
        return j
    if j < n and text[j] in "@*#?$!-":
        return j + 1
    return j


def _brace_expand(word: str, limit: int = 64) -> List[str]:
    """Bash brace expansion over the unquoted markers; groups beyond the limit or {a..z} ranges become _EXP."""
    out, todo = [], [word]
    while todo:
        w = todo.pop()
        start = None
        for idx, ch in enumerate(w):
            if ch == _BO:
                start = idx
            elif ch == _BC and start is not None:
                body = w[start + 1:idx]
                if _BS in body:
                    if len(out) + len(todo) >= limit:
                        todo.append(w[:start] + _EXP + w[idx + 1:])
                    else:
                        todo.extend(w[:start] + part + w[idx + 1:] for part in body.split(_BS))
                    break
                if ".." in body:
                    todo.append(w[:start] + _EXP + w[idx + 1:]); break
                start = None
        else:
            out.append(w.replace(_BO, "{").replace(_BC, "}").replace(_BS, ","))
    return out


def _component_hit(comp: str, globs: bool, last: bool = True) -> Optional[str]:
    if not comp or set(comp) <= {_EXP}:
        return None                            # a whole folder from $HOME etc.: nothing to match it against
    if not globs:                              # code, not a shell: * ? [ are just characters
        comp = comp.replace("*", "\x05").replace("?", "\x06").replace("[", "\x07")
    if not re.search(r"[*?\[]", comp) and _EXP not in comp:
        name = "".join(_UNQUOTE.get(ch, ch) for ch in comp).lower()
        if name == ".env":
            return ".env"
        if re.fullmatch(API_KEY_NAME, name, re.I):
            return name
        return next((m for m in CREDENTIAL_MARKERS if m in name), None)
    pattern = "".join({"\x05": "[*]", "\x06": "[?]", "\x07": "[[]", _EXP: "*"}.get(ch, ch) for ch in comp).lower()
    for name in (CRED_NAMES if last else CRED_DIRS):
        if name.startswith(".") and comp[0] in "*?[":
            continue                           # the shell's * ? [..] never match a leading dot
        if fnmatch.fnmatchcase(name, pattern):
            return name
    return None


_SHELLS = {"sh", "bash", "zsh", "dash", "ksh", "mksh", "fish", "csh", "tcsh",
           # these run a string through a shell, so they count as one (their operands are checked as commands)
           "watch", "flock", "su", "runuser", "script", "parallel", "ssh", "busybox", "toybox"}
_SCRIPT_FILE = re.compile(r"\.(py|pyc|pl|pm|rb|js|mjs|cjs|ts|php|lua|tcl|r|awk)$", re.I)
_PREFIXES = {"command", "builtin", "env", "nice", "nohup", "time", "sudo", "doas", "xargs", "stdbuf", "timeout",
             "caffeinate", "arch", "then", "do", "else", "if", "while", "until", "!", "{"}
# Interpreters whose code (-c / -e / a program text) can run shell commands (os.system, `..`, system()). Their quoted
# strings are read with wildcards active; a bare * or ? (multiplication, a pattern) alone is not a file name.
_INTERPRETERS = re.compile(r"^(python[\d.]*|perl[\d.]*|ruby|node|nodejs|php|deno|bun|lua[\d.]*|tclsh|rscript|awk|gawk|nawk|mawk)$")
_PSUB, _REDIR_IN, _REDIR_OUT, _REDIR_DOC, _HEREDOC, _UNSURE = "\x00psub", "\x00<", "\x00>", "\x00<<", "\x00heredoc", "\x00?"


def _loose_cred_hit(text: str) -> Optional[str]:
    """A context-free second net under the shell reading below (R-assist8: each parser slip hid a pattern). Quotes and
    escapes are dropped, expansions become *, the text is cut at blanks and shell punctuation, and every path part that
    is a credential name, or a wildcard pattern with at least two fixed characters that matches one, is refused,
    wherever it stands (here-document, nested command, program text). A lone * or .* is left to the shell reading."""
    t = re.sub(r"\$\{[^}]*\}|\$[A-Za-z_][A-Za-z0-9_]*|\$[0-9@*#?$!-]", "*", text)
    t = re.sub(r"[\'\"\\]", "", t)
    for tok in re.split(r"[\s;&|<>()`$]+", t):
        if not tok:
            continue
        for w in _brace_expand(tok.replace("{", _BO).replace(",", _BS).replace("}", _BC)):
            for comp in re.split(r"[/=:]", w):
                low = comp.lower()
                if not re.search(r"[*?\[]", low):
                    if low == ".env" or any(m in low for m in CREDENTIAL_MARKERS) or re.fullmatch(API_KEY_NAME, low, re.I):
                        return low
                    continue
                if len(re.sub(r"\[[^\]]*\]|[*?]", "", low)) < 2:
                    if "/" in w and comp == re.split(r"[/=:]", w)[-1] and set(low) <= set("*?"):
                        return "every file in a folder"   # home/* : could be a sign-in file (R-assist9)
                    continue
                for name in CRED_NAMES:
                    try:
                        if fnmatch.fnmatchcase(name, low):
                            return name
                    except re.error:
                        return "an unreadable pattern"
    return None


def _shell_cred_hit(text: str, globs: bool, depth: int = 0, code: bool = False) -> Optional[str]:
    return _shell_scan(text, globs, depth, code)[0]


def _shell_scan(text: str, globs: bool, depth: int = 0, code: bool = False) -> tuple:
    """(hit, runs a shell or interpreter anywhere, nested commands included).

    Credential files named by what the shell (or, with globs=False, the quoting alone) turns the words into, also
    inside $(..), `..` (also nested), ${..}, <(..) and every operand of a shell, which run too (GPT R-assist5..7). A
    shell given its commands as input (< file, << here-doc, <<< text, <(..)) is refused outright: that text can't be
    checked. With code=True (the text of a python/perl/awk/... program) quoted wildcards count as wildcards."""
    if depth > 6:
        return "nested commands", True         # deeper than anyone writes by hand: refused rather than guessed
    prev, nested, code_bodies = "", [], []
    shell = interp = fed = shell_fed = psub = program = after_prefix = expect_code = interp_awk = awk_stdin = False
    first, redirect_target, docs, env_seen = True, None, [], False
    piped = sticky = empty = False
    empty = True
    group = any_exec = any_input = False       # compound commands: ( .. ) and { .. } with their own redirects
    for pat, raw, txt in _shell_words(text, nested) + [(None, None, None)]:
        if pat in (_PSUB, _REDIR_IN, _REDIR_DOC) or raw == "|":
            any_input = True
        if raw == "(" or (pat is not None and txt == "{"):
            group = True
        if shell or interp:
            any_exec = True
        if pat is None:
            if piped:                          # ... | sh, | . /dev/stdin, | command -p bash, | env python3
                fed = shell_fed = True
            # after the first pipe every later command counts as fed (fail closed): | newline cmd, | (..; sh),
            # | { :; sh; }, | # comment<newline> sh all reach a shell's input (R-assist10, R-assist11)
            sticky = sticky or raw == "|"
            piped = sticky
            empty = True
            if shell and shell_fed:
                return "commands fed to a shell", True
            if interp and (psub or (fed and (not interp_awk or awk_stdin))):
                # an interpreter given input (pipe, <, <(..)) is refused whatever its options say: which operand is
                # the program depends on each interpreter's option grammar (-Wignore, -E -, -X dev.py ..., R-assist13);
                # awk always takes its program as an operand, unless -f names stdin
                return "a program fed as input", True
            if interp:
                code_bodies.extend(docs)       # python3 - <<EOF, also <<EOF python3 -: the here-document is the program
            prev, shell, interp, fed, shell_fed, psub, program, first = "", False, False, False, False, False, False, True
            awk_stdin = env_seen = False
            docs, after_prefix = [], False
            continue
        empty = False
        if pat == _UNSURE:
            return "nested commands", True
        if pat == _REDIR_DOC:                  # a here-document: checked as text below (as code for interpreters)
            shell_fed = True
            continue
        if pat in (_PSUB, _REDIR_IN):
            fed = shell_fed = True
            psub = psub or pat == _PSUB
            if pat == _REDIR_IN and redirect_target is None:
                redirect_target = True         # the next word is the file read, not a program operand
            continue
        if pat == _REDIR_OUT:
            redirect_target = True if redirect_target is None else redirect_target
            continue
        if pat == _HEREDOC:                    # (pattern, body, body): the text given as input to this command
            docs.append(raw)
            continue
        if shell:
            nested.append(txt)                 # a shell's operands run as commands (sh -c, -lc, +c, -- body, -; ...)
        prev_word = prev
        if interp and not redirect_target:
            # Which operand is the program decides whether stdin is data or the program (R-assist12: option values
            # like -W ignore, -X dev are not programs). Every operand is checked as code anyway.
            m = re.match(r"-[A-Za-z]*[ceEmr](.+)$", txt, re.S)
            if expect_code:
                code_bodies.append(txt); program = True; expect_code = False
            elif m:                            # attached program text: -c"code", -e'code' (R-assist8)
                code_bodies.append(m.group(1)); program = True
            elif re.fullmatch(r"-[A-Za-z]*[ceEmr]", txt):
                expect_code = True             # -c code, -e code, -m module: the next word is the program
            if interp_awk and (re.fullmatch(r"-f-?|-f(/dev/stdin|/dev/fd/0|-)", txt) or
                               (prev_word == "-f" and txt in ("-", "/dev/stdin", "/dev/fd/0"))):
                awk_stdin = True               # awk -f /dev/stdin: the program comes from the input
            elif not txt.startswith("-"):
                code_bodies.append(txt)
                if interp_awk or _SCRIPT_FILE.search(txt):
                    program = True             # awk 'prog', python3 tally.py: stdin is data
        was_target, redirect_target = redirect_target, None
        use = raw if (code or (globs and prev in _FIND_PATTERN_FLAGS)) else pat
        for w in (_brace_expand(use) if globs else [use.replace(_BO, "{").replace(_BC, "}").replace(_BS, ",")]):
            comps = w.replace("=", "/").split("/")
            for k, comp in enumerate(comps):
                if code and len(comps) == 1 and set(comp) <= set("*?"):
                    continue                   # 2 * 3 in a program is not a file pattern (home/* still is)
                hit = _component_hit(comp, globs, last=(k == len(comps) - 1))
                if hit:
                    return hit, True
        prev = "".join(_UNQUOTE.get(ch, ch) for ch in pat).replace(_BO, "{").replace(_BC, "}").replace(_BS, ",")
        name = prev.rsplit("/", 1)[-1].lower()
        if globs and (name in _SHELLS or name == "source" or (first and name == ".") or set(pat) <= {_EXP}):
            shell = True                       # also `$SHELL -c ..` in any position (after < /dev/null, command ..)
        if globs and _INTERPRETERS.match(name) and not interp:
            interp, expect_code = True, False
            interp_awk = name.endswith("awk")
        if env_seen and re.match(r"-[A-Za-z]*S|--split-string", prev):
            return "nested commands", True      # env -S "python3 -W..": a command line in one string (R-assist16..18)
        cmd_name = "" if prev.startswith("-") else name   # an option's text is never a command name (R-assist18)
        if cmd_name == "env":
            env_seen = True                     # by name: /usr/bin/env too (R-assist17)
        if cmd_name in _PREFIXES:
            after_prefix = True
        elif not (was_target or _ASSIGN.match(prev) or prev.isdigit() or (after_prefix and prev.startswith("-"))):
            first = False                      # a redirect's file, an fd number, a prefix and its options: no command
    if globs and group and any_exec and any_input:
        # { python3 -; } < <(..), (sh) < file: a group's input reaches every command inside; rather than follow it
        # through the group, a group that runs a shell or interpreter in a text that gives input is refused (R-assist14)
        return "a program fed as input", True
    for body in code_bodies:
        hit = _shell_cred_hit(body, globs, depth + 1, code=True)
        if hit:
            return hit, True
    for body in nested:
        hit, runs = _shell_scan(body, globs, depth + 1)
        if hit:
            return hit, True
        any_exec = any_exec or runs
    if globs and any_exec and any_input and nested:
        # "$(python3 -)" in a command given input: a substitution inherits that input; rather than follow it,
        # a text that gives input and runs a shell or interpreter inside a substitution is refused (R-assist15)
        return "a program fed as input", True
    return None, any_exec


# ------------------------------------------------------------------ shell parsing

_SEPARATORS = {";", "&&", "||", "|", "&", "\n", "|&", ";;"}


def _split_commands(command: str) -> Optional[List[List[str]]]:
    """Split a shell command line into simple commands (token lists). None if it can't be parsed safely."""
    try:
        lex = shlex.shlex(command.replace("\r", "\n"), posix=True, punctuation_chars=";&|<>()\n")
        lex.whitespace = " \t"
        lex.whitespace_split = True
        lex.commenters = ""
        tokens = list(lex)
    except ValueError:
        return None
    cmds, cur = [], []
    for tok in tokens:
        if tok in _SEPARATORS or (tok and set(tok) <= set(";&|\n")):
            if cur:
                cmds.append(cur); cur = []
        else:
            cur.append(tok)
    if cur:
        cmds.append(cur)
    return cmds


_ASSIGN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*=")
_PY = re.compile(r"^(.*/)?(python3?(\.\d+)?|uv|env)$")
_GAPI_VAR = {"$gapi", "${gapi}"}


def _gapi_index(tokens: List[str]) -> Optional[int]:
    """Index of the token naming google_api.py (path or $GAPI) when the simple command INVOKES it, else None."""
    i = 0
    while i < len(tokens) and _ASSIGN.match(tokens[i]):
        i += 1                                     # leading VAR=value assignments
    if i >= len(tokens):
        return None
    t = tokens[i]
    if t.lower() in _GAPI_VAR:
        return i
    if _PY.match(t):
        j = i + 1
        if t.endswith("uv"):                       # uv run [python] script
            if j < len(tokens) and tokens[j] == "run":
                j += 1
            if j < len(tokens) and _PY.match(tokens[j]):
                j += 1
        while j < len(tokens) and tokens[j] in ("-u", "-B", "-I", "-E", "-s", "-S"):
            j += 1
        if j < len(tokens) and tokens[j].endswith("/google_api.py") or (j < len(tokens) and tokens[j] == "google_api.py"):
            return j
        return None
    if t.endswith("/google_api.py") or t == "google_api.py":
        return i
    return None


def _parse_flags(argv: List[str], spec: Dict[str, str], positional: List[str]) -> Optional[Dict[str, Any]]:
    """Tiny argparse twin for google_api.py's subcommands. spec maps --flag -> payload key ('' marks a boolean)."""
    out: Dict[str, Any] = {}
    pos = list(positional)
    i = 0
    while i < len(argv):
        a = argv[i]
        if a.startswith("--"):
            name, eq, val = a.partition("=")
            if name not in spec:
                return None
            key = spec[name]
            if key.startswith("!"):                # boolean flag
                if eq:
                    return None
                out[key[1:]] = True
                i += 1
                continue
            if not eq:
                if i + 1 >= len(argv):
                    return None
                val = argv[i + 1]
                i += 1
            if key in out:
                return None                        # repeated flag: ambiguous, refuse
            out[key] = val
        elif a.startswith("-") and a != "-":
            return None
        else:
            if not pos:
                return None
            out[pos.pop(0)] = a
        i += 1
    if pos:
        return None
    return out


_SPECS = {
    ("gmail", "send"): ({"--to": "to", "--subject": "subject", "--body": "body", "--cc": "cc", "--from": "from",
                         "--html": "!html", "--thread-id": "thread_id"}, [], ("to", "subject", "body")),
    ("gmail", "reply"): ({"--body": "body", "--from": "from"}, ["reply_to_message_id"], ("reply_to_message_id", "body")),
    ("calendar", "create"): ({"--summary": "summary", "--start": "start", "--end": "end", "--location": "location",
                              "--description": "description", "--attendees": "attendees", "--calendar": "calendar"},
                             [], ("summary", "start", "end")),
    ("calendar", "update"): ({"--summary": "summary", "--start": "start", "--end": "end", "--location": "location",
                              "--description": "description", "--calendar": "calendar"}, ["event_id"], ("event_id",)),
    ("calendar", "delete"): ({"--calendar": "calendar"}, ["event_id"], ("event_id",)),
}
_DEFAULTS = {
    "email.send": {"cc": "", "from": "", "html": False, "thread_id": ""},
    "email.reply": {"from": ""},
    "calendar.create": {"location": "", "description": "", "attendees": "", "calendar": "primary"},
    "calendar.update": {"summary": "", "start": "", "end": "", "location": "", "description": "", "calendar": "primary"},
    "calendar.delete": {"calendar": "primary"},
    # SENDFIX (6 Nov): forward, send a draft, save a draft (the Qosha Google tools; Bcc only when asked for)
    "email.forward": {"cc": "", "bcc": "", "body": "", "from": ""},
    "email.draft_send": {},
    "email.draft_save": {"to": "", "cc": "", "bcc": ""},
}
_ID = re.compile(r"^[A-Za-z0-9_@.\-]{1,256}$")


def _has_expansion(command: str) -> bool:
    """True if the shell would substitute anything ($x, ${x}, $(...), `...`, <(...)) outside single quotes.
    Text inside single quotes is literal, so '$9,900' in a quoted body is fine."""
    quote = None
    i = 0
    while i < len(command):
        ch = command[i]
        if quote == "'":
            if ch == "'":
                quote = None
        elif ch == "\\" and quote != "'":
            i += 2
            continue
        elif ch == "'" and quote is None:
            quote = "'"
        elif ch == '"':
            quote = None if quote == '"' else '"'
        elif ch == "`" or (ch == "$" and i + 1 < len(command) and (command[i + 1].isalnum() or command[i + 1] in "_{(@*#?!$-'\"")):
            return True  # includes ANSI-C $'...' quoting, which shlex reads differently from the shell
        elif ch == "<" and command[i + 1:i + 2] == "(" and quote is None:
            return True
        i += 1
    return quote is not None  # unbalanced quotes: refuse


_GAPI_DEF = re.compile(r'^GAPI=(python3?\s+)?(\$\{HERMES_HOME(:-\$HOME/\.hermes)?\}|\$HERMES_HOME)'
                       r'/skills/productivity/google-workspace/scripts/google_api\.py$')
# Piping or feeding text into an interpreter runs whatever the text says (a downloaded script, an email body).
PIPE_TO_INTERPRETER = re.compile(r"\|\s*(sudo\s+)?(/[\w/.-]*/)?(sh|bash|zsh|dash|ksh|fish|python[\d.]*|node|ruby|perl|php|"
                                 r"osascript|xargs|source|\.|eval|exec)\b", re.I)
PY_STARTUP = re.compile(r"sitecustomize|usercustomize|\.pth\b|pythonstartup|pythonpath|pythonhome|ld_preload|"
                        r"dyld_insert_libraries|node_options|perl5opt|rubyopt", re.I)


def _definition_ok(token: str) -> bool:
    """`VAR=value` alone. GAPI may only point at the google-workspace script; other variables may not mention
    mail, calendar, credentials or Qosha's own files."""
    name, _, value = token.partition("=")
    if name == "GAPI":
        return bool(_GAPI_DEF.match(token.strip()))
    return _mail_hit(value) is None and _cred_hit(value) is None


def _setup_check(cmds: List[List[str]]) -> Optional[Verdict]:
    """The skill's sign-in helper (setup.py). Its --check runs first in every skill session: answer it from the Qosha
    connector. Every other action (new sign-in, codes, revoke, installing packages) is for a person, not the assistant."""
    for c in cmds:
        for j, t in enumerate(c):
            if t.endswith(SETUP_SUFFIX) or t == "setup.py" and any(x.endswith("google-workspace/scripts") for x in c):
                if j == 0 or not _PY.match(c[j - 1]) or any(_ASSIGN.match(x) for x in c[:j - 1]):
                    return Verdict(DENY, "Run the Google sign-in helper only as `python .../setup.py --check`.")
                if len(cmds) != 1:
                    return Verdict(DENY, "Run the Google sign-in check on its own.")
                rest = c[j + 1:]
                if rest in (["--check"], ["--check-live"]):
                    if CONNECTOR_CLIENT:
                        return Verdict(ALLOW, kind="rewrite", payload={"argv": ["check"]})
                    return Verdict(DENY, "Google is not connected on this Mac yet; a person signs in (Qosha runbook).")
                return Verdict(DENY, "Signing in to Google is done by a person in Qosha, not by the assistant.")
    return None


def _open_relative(word: str) -> str:
    """GUARDFIX: a word that is a path inside the engine's Files or skills folder (links followed), written as
    "files:<path>" or "skills:<path>", so the folders' own full path (the lab's ".../QoshaLab/home", the library's "qosha-library")
    is not read as a reference to Qosha's own settings; what follows is still scanned."""
    hp = _home_parts()
    m = re.match(r"^([A-Za-z_][A-Za-z0-9_]*=)(/.*)$", word)
    if m:                                      # NAME=<path> (a setting a skill documents): its value
        return m.group(1) + _open_relative(m.group(2))
    p = os.path.expanduser(word)
    if not hp or not p.startswith("/") or "\x00" in p:
        return word
    full = os.path.realpath(p)
    for name in ("files", "skills"):
        root = os.path.realpath("/" + "/".join(hp + [name]))
        if full == root or full.startswith(root + os.sep):
            return name + ":" + os.path.relpath(full, root)   # "skills:qosha-library/..." (not "/qosha")
    return word


def _classify_shell(command: str) -> Verdict:
    if PIPE_TO_INTERPRETER.search(command):
        return Verdict(DENY, "Piping text into a shell or interpreter is not allowed while mail and calendar are connected.")
    if PY_STARTUP.search(command):
        return Verdict(DENY, "Changing how programs start (startup files, preload variables) is not allowed.")
    cmds = _split_commands(command)
    if cmds is None:
        return Verdict(DENY, "This command mentions email or calendar tools in a way Qosha can't read safely.")
    setup = _setup_check(cmds)
    if setup is not None:
        return setup
    invocations = [(c, _gapi_index(c)) for c in cmds]
    hits = [(c, i) for c, i in invocations if i is not None]
    for c, i in invocations:
        if i is None:
            if all(_ASSIGN.match(t) for t in c):
                # GAPI="python .../google_api.py": defining the helper is fine; the use is checked when it runs.
                if all(_definition_ok(t) for t in c):
                    continue
            text = " ".join(_open_relative(t) for t in c)
            hit = _mail_hit(text)
            if hit:
                if _guard_hit(text):
                    return Verdict(DENY, "Qosha's own settings, approval records and sign-in are off limits to the "
                                         "assistant (found %r)." % hit)
                return Verdict(DENY, "Sending or changing mail or calendar this way is not allowed (found %r)." % hit)
    if not hits:
        return Verdict(ALLOW)
    if len(hits) > 1:
        return Verdict(DENY, "Run one Google command at a time so a person can review it.")
    c, i = hits[0]
    if any(_ASSIGN.match(t) for t in c[:i]):
        return Verdict(DENY, "No environment settings in front of Google commands.")
    if len(c) < i + 3:
        return Verdict(DENY, "Incomplete Google command.")
    service, action = c[i + 1], c[i + 2]
    rest = c[i + 3:]
    # The helper's own definition and name may use $HERMES_HOME/$GAPI; nothing else may expand (Gemini review).
    tail = re.sub(r"""(^|;)\s*GAPI=("[^"]*"|'[^']*'|\S+)\s*""", r"\1", command)
    tail = re.sub(r"\$\{?GAPI\}?", "GAPI", tail)
    tail = re.sub(r"\$\{HERMES_HOME(:-\$HOME/\.hermes)?\}(?=/skills/)|\$HERMES_HOME(?=/skills/)", "H", tail)
    if re.search(r"`|\$\(|<\(", command) or _has_expansion(tail):
        return Verdict(DENY, "Google commands must be written literally: no $variables, $(...) or backticks after "
                             "the script name.")
    if (service, action) in READ_ONLY:
        if any(t in (">", ">>", "<", "(", ")") for t in rest):
            return Verdict(DENY, "Redirects are not allowed on Google commands.")
        if CONNECTOR_CLIENT:
            # The sign-in lives in the Qosha connector: run the same read through it (same JSON output).
            return Verdict(ALLOW, kind="rewrite", payload={"argv": [service, action] + rest})
        home = os.environ.get("HERMES_HOME", "")
        script = os.path.expanduser(c[i]) if not c[i].startswith("$") else (home + GAPI_SUFFIX if home else "")
        if not (script and os.path.isfile(script) and _sha256(script) in TRUSTED_GAPI_SHA256):
            return Verdict(DENY, "Qosha only runs the unchanged google-workspace script from this assistant's home.")
        return Verdict(ALLOW)
    kind = HOLDABLE.get((service, action))
    if not kind:
        return Verdict(DENY, "Qosha only allows reading mail and calendar, and through approval: gmail send/reply, "
                             "calendar create/update/delete. `%s %s` is not available." % (service, action))
    if len(hits) != 1 or len(cmds) != 1 and not all(
            all(_ASSIGN.match(t) for t in other) for other in cmds if other is not c):
        return Verdict(DENY, "Send this Google command on its own (no other commands in the same line), so a "
                             "person can approve exactly it.")
    # The literal text written in the command is what gets approved. Shell expansion would make it differ.
    if any(t in ("<", ">", ">>", "<<", "(", ")") for t in rest):
        return Verdict(DENY, "Write the email or event text literally in the command (no $variables, $(...), "
                             "backticks, redirects or here-documents), so the person approves exactly what is sent.")
    spec, pos, required = _SPECS[(service, action)]
    parsed = _parse_flags(rest, spec, pos)
    if parsed is None or any(not str(parsed.get(k, "")).strip() for k in required):
        return Verdict(DENY, "Qosha could not read this %s command exactly (unknown, repeated or missing options)." % kind)
    payload = dict(_DEFAULTS[kind]); payload.update(parsed)
    if kind == "calendar.update" and not any(str(payload.get(k, "")).strip()
                                             for k in ("summary", "start", "end", "location", "description")):
        return Verdict(DENY, "Say what changes: calendar update <event id> with --summary, --start, --end, --location "
                             "or --description.")
    for key in ("reply_to_message_id", "event_id", "thread_id"):
        if payload.get(key) and not _ID.match(payload[key]):
            return Verdict(DENY, "Invalid id in %s." % key)
    return Verdict(HOLD, kind=kind, payload=payload, needs_reply_context=(kind == "email.reply"))


def _script_paths(text: str, workdir: Optional[str]) -> List[str]:
    out = []
    for tok in re.findall(r"[\w./~+-]+", text):
        if tok.endswith(SCRIPT_SUFFIXES):
            p = os.path.expanduser(tok)
            if not os.path.isabs(p) and workdir:
                p = os.path.join(workdir, p)
            out.append(p)
    return out


def _sha256(path: str) -> str:
    try:
        with open(path, "rb") as fh:
            return hashlib.sha256(fh.read()).hexdigest()
    except OSError:
        return ""


def _script_text(path: str, limit: int = 2_000_000) -> Optional[str]:
    try:
        if os.path.isfile(path) and os.path.getsize(path) <= limit:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                return fh.read()
    except OSError:
        return None
    return None


def _restricted(job: dict) -> str:
    """Why a stored job runs or delivers outside the guard, or ""."""
    for key in ("script", "monitor_script", "monitor_url"):
        if job.get(key):
            return "runs a " + key.replace("_", " ")
    if job.get("no_agent"):
        return "runs without the assistant"
    d = job.get("deliver", "local")
    if d is None:
        d = "local"
    if isinstance(d, (list, tuple)):
        d = ",".join(str(x) for x in d)
    if any(p.strip() != "local" for p in str(d).split(",") if p.strip()) or not str(d).strip():
        return "sends its result elsewhere"
    return ""


def _stored_job(job_id: str) -> Optional[dict]:
    """The job as the engine stored it (<engine home>/cron/jobs.json), read directly (never the engine's resolver,
    which falls back to ~/.hermes); None when it can't be read or found."""
    eh = ENGINE_HOME or os.environ.get("HERMES_HOME", "")
    if not eh or not job_id:
        return None
    try:
        with open(os.path.join(eh, "cron", "jobs.json"), "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return None
    jobs = data.get("jobs", []) if isinstance(data, dict) else data if isinstance(data, list) else []
    return next((j for j in jobs if isinstance(j, dict) and str(j.get("id")) == job_id), None)


def _cron_refusal(args: Any) -> str:
    """Why a cronjob tool call is refused (D21), or "". Fields that make the engine run something at fire time outside
    the tool hook: script, no_agent, monitor (script or URL); and delivery anywhere but "local" (the final message and
    failure notices are sent by the engine itself). Clearing a script or monitor ("" on update) is fine. On create the
    delivery must be said: left out, the engine sends to the chat it was created from when that is a messaging app."""
    if not isinstance(args, dict):
        return "unreadable settings"
    for key in CRON_RUN_FIELDS:
        v = args.get(key)
        if v is not None and not (isinstance(v, str) and not v.strip()):
            return key
    if args.get("no_agent") not in (None, False, 0):
        return "no_agent"
    action = str(args.get("action") or "").strip().lower()
    if action not in ("create", "list", "pause", "remove", "delete", ""):
        # update, resume, run, ...: the engine keeps the job's stored settings (a run's own `deliver` is ignored), so
        # a job a person set up to run scripts or send elsewhere can't be changed, resumed or fired by the assistant
        stored = _stored_job(str(args.get("job_id") or ""))
        if stored is None:
            return "the automation could not be read"
        why = _restricted(stored)
        if why:
            return "this automation " + why
    if "deliver" in args and args.get("deliver") is not None:
        d = args.get("deliver")
        if not isinstance(d, str) or any(p.strip() != "local" for p in d.split(",")):   # the engine's exact word
            return "deliver"
    elif action == "create":
        return "deliver not set to local"
    return ""


def _path_tokens(text: str) -> List[str]:
    """Every path-like token of a text, context-free (inside sh -c '..', $(..), program text alike): quotes and escapes
    dropped, expansions become *, cut at blanks and shell punctuation and at =; {a,b} alternatives expanded, then
    commas cut (python 'a','b')."""
    t = re.sub(r"\$\{[^}]*\}|\$[A-Za-z_][A-Za-z0-9_]*|\$[0-9@*#?$!-]", "*", text)
    t = re.sub(r"[\'\"\\]", "", t)
    out = []
    for tok in re.split(r"[\s;&|<>()`$=]+", t):
        if not tok:
            continue
        for alt in _brace_expand(tok.replace("{", _BO).replace(",", _BS).replace("}", _BC)):
            out.extend(x for x in alt.split(",") if x)
    return out


# GUARDFIX3 (verifier round 3, finding 1, blocking): macOS has more than one spelling for the same folder, and realpath
# keeps them: the Data volume's firmlinks (/System/Volumes/Data/Users/x is /Users/x) and volfs (/.vol/<dev>/<inode>,
# /.vol/<dev>/2/Users/x). Paths are therefore compared by IDENTITY: every existing folder of a path is matched by
# (device, inode) against the engine home and each of its parents (so any spelling of them, or of a folder inside them,
# maps to the home's own spelling); a firmlink/volfs spelling is first turned into the kernel's own path (F_GETPATH on
# its longest existing folder); a /.vol path that still can't be named is refused.
_F_GETPATH = getattr(__import__("fcntl"), "F_GETPATH", None)
# GUARDVERIFY4 N1: also macOS's /.nofollow/<path> and /.resolve/<n>/<path> spellings (matched on _fold()ed text, so
# /ſyſtem/... counts too)
_ALIAS_TEXT = re.compile(r"(?i)(?:^|[^A-Za-z0-9_.-])/+\.(?:vol|nofollow|resolve)(?:/|$|[^A-Za-z0-9_.-])|"
                         r"/+system/+volumes/+data(?:/|$|[^A-Za-z0-9_.-])")
# GUARDVERIFY4 N1: folders whose tree holds the Data volume (and so the person's home and the lab) through its mount at
# /System/Volumes/Data, without being the home's parents by path: a search from them is a search above the home
_DATA_MOUNT_PARENTS = ("/System", "/System/Volumes")
_ALIAS_REFUSED = "\x00alias"


def _alias_spelling(p: str) -> bool:
    low = _fold(p)
    return low in ("/.vol", "/system/volumes", "/.nofollow", "/.resolve") or \
        low.startswith(("/.vol/", "/system/volumes/", "/.nofollow/", "/.resolve/"))


def _kernel_path(p: str) -> str:
    """The kernel's own path of p's longest existing folder (F_GETPATH; folders only, never a file or a device, opened
    non-blocking), with the rest appended."""
    import stat as _stat
    q, rest = p, []
    while q and q != "/":
        try:
            if _stat.S_ISDIR(os.stat(q).st_mode):
                fd = os.open(q, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | os.O_NONBLOCK)
                try:
                    import fcntl as _fcntl
                    real = _fcntl.fcntl(fd, _F_GETPATH, bytes(1024)).split(b"\0", 1)[0].decode("utf-8", "surrogateescape")
                finally:
                    os.close(fd)
                if real.startswith("/"):
                    return os.path.join(real, *reversed(rest)) if rest else real
        except (OSError, ValueError):
            pass
        rest.append(os.path.basename(q))
        q = os.path.dirname(q)
    return p


def _holds_data_mount(p: str) -> bool:
    """True when p (literal part) is /System or /System/Volumes, by folded text or by identity (any spelling the disk
    accepts: /ſyſtem/Volumes, /.nofollow/System/Volumes, ...): their tree holds the Data volume's mount."""
    if not p.startswith("/") or re.search(r"[*?\[]", p):
        return False
    if _fold(p).rstrip("/") in ("/system", "/system/volumes"):
        return True
    try:
        st = os.stat(p)
    except (OSError, ValueError):
        return False
    for q in _DATA_MOUNT_PARENTS:
        try:
            s2 = os.stat(q)
        except OSError:
            continue
        if (st.st_dev, st.st_ino) == (s2.st_dev, s2.st_ino):
            return True
    return False


def _by_identity(p: str, hp: List[str]) -> str:
    """p with its deepest existing folder that IS the engine home or one of its parents (same device and inode, links
    followed) written the way the home is written."""
    if not hp or not p.startswith("/"):
        return p
    ids = {}
    q = "/" + "/".join(hp)
    while True:
        try:
            st = os.stat(q)
            ids.setdefault((st.st_dev, st.st_ino), q)
        except OSError:
            pass
        if q == "/":
            break
        q = os.path.dirname(q)
    q, rest = p, []
    while True:
        try:
            st = os.stat(q)
            known = ids.get((st.st_dev, st.st_ino))
            if known is not None:
                return os.path.join(known, *reversed(rest)) if rest else known
        except OSError:
            pass
        if q in ("/", ""):
            return p
        rest.append(os.path.basename(q))
        q = os.path.dirname(q)


def _canon(path: str, hp: Optional[List[str]] = None) -> str:
    """The literal part of an absolute path (before any pattern part) in canonical spelling (see above); the rest as
    written. _ALIAS_REFUSED for a /.vol spelling that names nothing the kernel can name."""
    if not path.startswith("/") or "\x00" in path:
        return path
    parts = path.split("/")
    k = next((i for i, x in enumerate(parts) if re.search(r"[*?\[]", x)), len(parts))
    head, tail = "/".join(parts[:k]) or "/", parts[k:]
    if _alias_spelling(head):
        if _F_GETPATH is not None:
            head = _kernel_path(head)
        if head.lower().startswith("/system/volumes/data/"):
            head = head[len("/System/Volumes/Data"):]          # the Data volume's firmlinks (also for a new name)
        if _fold(head) in ("/.vol", "/.nofollow", "/.resolve") or _fold(head).startswith(("/.vol/", "/.nofollow/", "/.resolve/")):
            return _ALIAS_REFUSED
    head = _by_identity(head, hp if hp is not None else _home_parts())
    return "/".join([head.rstrip("/")] + tail) if tail else head


def _resolve(path: str) -> str:
    """Absolute; links followed the way the system follows them (a link before ".." first: pivot/../cron), for the
    literal part before the first pattern part (/tmp -> /private/tmp). A name the system can't take (NUL) stays as is.
    GUARDFIX3: and in canonical spelling (_canon)."""
    if "\x00" in path:
        return os.path.normpath(path.replace("\x00", ""))
    parts = path.split("/")
    k = next((i for i, x in enumerate(parts) if re.search(r"[*?\[]", x)), len(parts))
    if k == len(parts):
        return _canon(os.path.realpath(path))
    head = "/".join(parts[:k]) or "/"
    return _canon(os.path.join(os.path.realpath(head), *parts[k:]))     # the rest as written: "pivot*/.." stays visible


def _in_home(path: str, hp: List[str]) -> str:
    """"" (not in the engine home), "home" (the home itself), "open" (its files/ or skills/), "closed" (anything else
    in it), "above" (one of its parent folders). Parts may be patterns: a pattern that could name a closed entry is
    closed; a pattern followed later by ".." can't be followed here and is closed. Names compare without case (this
    Mac's disks ignore case: /PRIVATE/ is /private/). GUARDFIX3: compared in canonical spelling (_canon: firmlink and
    volfs spellings, any spelling of the home's folders by identity); on the Mac lab the rest of the lab folder (its
    lab.json, logs, run/, src/, venv/ next to the engine home) is closed too, however it is reached."""
    path = _canon(path, hp)
    if path == _ALIAS_REFUSED:
        return "closed"
    if hp and _holds_data_mount(path):
        return "above"                         # GUARDVERIFY4 N1: /System, /System/Volumes (any spelling)
    parts = [_fold(x) for x in path.split("/") if x]
    hp = [_fold(x) for x in hp]
    if len(hp) >= 2 and hp[-2] == "qoshalab" and len(parts) >= len(hp) and \
            all(fnmatch.fnmatchcase(w, g) for w, g in zip(hp[:-1], parts[:len(hp) - 1])):
        g = parts[len(hp) - 1]                 # verifier r3 finding 2: ../../lab.json, ../../logs, ../../run, ../../src
        if not fnmatch.fnmatchcase(hp[-1], g):
            return "closed"
        if any(c in g for c in "*?["):         # a pattern there: closed when it could name anything but the home
            try:
                names = {x.lower() for x in os.listdir("/" + "/".join(hp[:-1]))}
            except OSError:
                names = set()
            if any(fnmatch.fnmatchcase(x, g) for x in names | {"logs", "run", "src", "venv", "lab.json"} if x != hp[-1]):
                return "closed"
    if any(re.search(r"[*?\[]", x) for x in parts) and ".." in parts[next(i for i, x in enumerate(parts)
                                                                           if re.search(r"[*?\[]", x)):]:
        return "closed"
    n = min(len(parts), len(hp))
    for want, got in zip(hp[:n], parts[:n]):
        if not fnmatch.fnmatchcase(want, got):
            return ""
    if len(parts) < len(hp):
        return "above"
    if len(parts) == len(hp):
        return "home"
    nxt = parts[len(hp)]
    if len(parts) > len(hp) + 1 and any(nxt == a and fnmatch.fnmatchcase(b, parts[len(hp) + 1]) or
                                        (any(c in nxt for c in "*?[") and fnmatch.fnmatchcase(a, nxt) and
                                         fnmatch.fnmatchcase(b, parts[len(hp) + 1])) for a, b in _OPEN_CLOSED):
        return "closed"
    if any(c in nxt for c in "*?["):           # a pattern: closed when it could name a closed entry there
        home = "/" + "/".join(hp)
        try:
            names = {x.lower() for x in os.listdir(home)}
        except OSError:
            names = set()
        names |= set(_HOME_KNOWN)
        return "closed" if any(fnmatch.fnmatchcase(x, nxt) for x in names if x not in HOME_OPEN) else "open"
    return "open" if nxt in HOME_OPEN else "closed"


_NATIVE_MAGIC = {b"\xfe\xed\xfa\xce", b"\xfe\xed\xfa\xcf", b"\xce\xfa\xed\xfe", b"\xcf\xfa\xed\xfe",
                 b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca", b"\x7fELF"}   # Mach-O (thin, fat) and ELF
_visiting: set = set()
_SYSTEM_DIRS = ("/bin/", "/sbin/", "/usr/bin/", "/usr/sbin/", "/usr/libexec/", "/System/", "/Library/Developer/",
                "/opt/homebrew/", "/usr/local/Cellar/", "/Applications/")
_ENGINE_CLI = {"hermes", "hermes-agent", "qlab-cli", "qlab-hermes"}   # the engine's command line (cron, plugins, config)
_RUNNERS = re.compile(r"^(python[\d.]*|perl[\d.]*|ruby|node|nodejs|php|deno|bun|lua[\d.]*|tclsh|rscript|awk|gawk|"
                      r"sh|bash|zsh|dash|ksh|mksh|fish|csh|tcsh|source|\.|osascript|swift)$")
_EXTRACT = {"tar", "gtar", "bsdtar", "unzip", "ditto", "rsync", "cpio", "pax", "7z", "7za", "xar", "unar", "patch",
            "cpdup", "git"}


def _words_all(text: str, depth: int = 0) -> List[tuple]:
    """Shell words as (text, pattern) with quotes respected ('my notes/..' stays one word; in the pattern a quoted * ? [
    is literal and unquoted { , } are brace markers), from the text and, recursively, from the bodies that run too
    ($(..), `..`, <(..)) and, when a shell may run quoted text (a shell word, eval/source/., a command from a variable,
    or any unquoted pattern word that could name a shell), from that text; comments dropped."""
    nested: List[str] = []
    out = []
    for w in _shell_words(text, nested):
        if w[0] is None or str(w[0]).startswith("\x00"):
            continue
        g = "".join({"\x05": "[*]", "\x06": "[?]", "\x07": "[[]", _EXP: "*"}.get(ch, ch) for ch in w[0])
        out.append((w[2], g, bool(re.search(r"[*?\[\x01\x04]", w[0]))))   # (text, pattern, has an unquoted pattern)
    if depth < 4:
        for body in nested:
            out += _words_all(body, depth + 1)
        if any(t.rsplit("/", 1)[-1] in _SHELLS | {"eval", "source", "."} or (t[:1] != "" and t[0] in "$`") or pt
               for t, g, pt in out):
            for t, g, pt in list(out):
                if re.search(r"[\s;&|<>()$`'\"\\*?\[{#=]", t):   # sh -c '>x', 'a b': a shell runs that text too
                    out += _words_all(t, depth + 1)
    return out


def _expand(g: str, bases: List[str]) -> Optional[List[str]]:
    """The paths a shell word's pattern names now (braces, then globs, from every base); None when too many."""
    import glob as _glob
    alts = _brace_expand(os.path.expanduser(g), limit=256) if any(m in g for m in (_BO, _BC)) else [os.path.expanduser(g)]
    if len(alts) >= 256:
        return None
    out = []
    for a in alts:
        a = a.replace(_EXP, "*").replace(_BO, "{").replace(_BC, "}").replace(_BS, ",")
        for c in ([a] if a.startswith("/") else [os.path.join(x, a) for x in bases]):
            if re.search(r"[*?\[]", c):
                found = _glob.glob(c)
                out += found
            else:
                out.append(c)
            if len(out) > 5000:
                return None
    return out


def _alternatives(g: str, bases: List[str]) -> Optional[List[str]]:
    """The brace alternatives of a word's pattern, joined to every base, patterns kept (for _where)."""
    alts = _brace_expand(os.path.expanduser(g), limit=256) if any(m in g for m in (_BO, _BC)) else [os.path.expanduser(g)]
    if len(alts) >= 256:
        return None
    out = []
    for a in alts:
        a = a.replace(_EXP, "*").replace(_BO, "{").replace(_BC, "}").replace(_BS, ",")
        out += [a] if a.startswith("/") else [os.path.join(x, a) for x in bases]
    return out


def _home_parts() -> List[str]:
    eh = ENGINE_HOME or os.environ.get("HERMES_HOME", "")
    return [x for x in os.path.realpath(os.path.expanduser(eh)).split("/") if x] if eh else []


# GUARDFIX (GPT r1): a cd with no folder, to ~ or -, or a popd, can land in the person's home folder (in the cloud box
# the engine home) or a folder named earlier: that folder is a base too. _BASE_TEXT holds the call's text while it is
# checked; _EXTRA_BASES the code tool's other folders (execute_code's own kernel folder).
_CD_HOME = re.compile(r"(?:^|[;&|(){}`\n]|\bthen|\bdo|\belse)\s*(?:builtin\s+|command\s+)?(?:cd|pushd|popd|chdir)"
                      r"(?:\s*(?:$|[;&|)}`\n])|\s+(?:-\S*\s+)*(?:~|-(?:\s|$)|\$HOME|\$\{HOME\}|\$OLDPWD|\$\{OLDPWD\}))")
_BASE_TEXT: List[str] = []
_EXTRA_BASES: List[str] = []


def _default_cwd() -> str:
    """The folder the engine runs a command in when nothing else is recorded: TERMINAL_CWD (config terminal.cwd), else
    the process's own folder (the engine's "." / "auto" / "cwd" mean that too)."""
    t = (os.environ.get("TERMINAL_CWD") or "").strip()
    return t if t and t not in (".", "auto", "cwd") else os.getcwd()


def _bases(workdirs: List[str], tokens: List[str], code: bool = True) -> List[str]:
    """Folders a relative path may start from: the engine's default folder for commands (TERMINAL_CWD, else the
    dashboard's folder), the dashboard's folder (file tools without a record), the session's recorded folders, the
    call's workdir, and every cd/pushd target in the text. GUARDFIX (council D43 Q1 A): not the person's home folder:
    the engine never runs a command there unless one of the above is it (in the cloud box it is the engine home)."""
    t_cwd = (os.environ.get("TERMINAL_CWD") or "").strip()
    anchored = SESSION_CWDS or (t_cwd.startswith("/") and os.path.isdir(t_cwd))   # file tools: record, then TERMINAL_CWD
    bases = [_default_cwd()] + ([] if (code or anchored) and os.path.isdir(_default_cwd()) else [os.getcwd()]) + \
        list(SESSION_CWDS)
    if not code and SESSION_CWDS:
        bases = list(SESSION_CWDS)             # GPT r3: file tools resolve from the session's record when there is one
    # (code: the terminal's own folder; the engine falls back to its process folder when that one is missing)
    bases = [_resolve(os.path.abspath(os.path.expanduser(b))) for b in bases if b]
    if workdirs:
        # an explicit working folder replaces the default ones (the engine runs the call there: _resolve_command_cwd)
        bases = [x for w in workdirs for b in list(bases) for x in
                 (_resolve(os.path.join(b, os.path.expanduser(w))),
                  _resolve(posixpath.normpath(os.path.join(b, os.path.expanduser(w)))))]   # Opus r5 N2: cd's logical ..
    # (after the working folder, GPT r4: `cd` with no folder leaves it for HOME whatever the call's workdir)
    if _CD_HOME.search("\n".join(tokens_text for tokens_text in _BASE_TEXT)):
        bases.append(_resolve(os.path.expanduser("~")))   # GPT r1: `cd; touch hooks/x` goes to HOME (the box's engine home)
    bases += [_resolve(b) for b in _EXTRA_BASES]
    for i, tok in enumerate(tokens):
        # GPT r9b: tar/make/git -C <dir> and --directory=<dir> also move where the names after them resolve
        cdir = tok[len("--directory="):] if tok.startswith("--directory=") else \
            (tok if i > 0 and tokens[i - 1] in ("-C", "--directory") else "")
        if cdir:
            cdir = os.path.expanduser(cdir)
            for b in list(bases):
                c = cdir if cdir.startswith("/") else os.path.join(b, cdir)
                bases += [_resolve(c), _resolve(posixpath.normpath(c))]
        j = i - 1
        while j >= 0 and tokens[j].startswith("-"):
            j -= 1                             # cd -- dir, cd -P dir
        if j >= 0 and j < i and tokens[j].rsplit("/", 1)[-1] in ("cd", "pushd") and not tok.startswith("-"):
            tok = os.path.expanduser(tok)
            for b in list(bases):
                c = tok if tok.startswith("/") else os.path.join(b, tok)
                bases += [_resolve(c), _resolve(posixpath.normpath(c))]   # Opus r5 N2: cd takes .. logically
    return bases


def _where(path: str, hp: List[str]) -> str:
    """_in_home, but patterns are expanded against what exists (glob) and every match is followed through links."""
    w = _in_home(path, hp)
    if re.search(r"[*?\[]", path):
        import glob as _glob
        parts = path.split("/")
        k = max(i for i, x in enumerate(parts) if re.search(r"[*?\[]", x))
        found = _glob.glob("/".join(parts[:k + 1]))     # what the pattern names now, then the rest (may not exist yet)
        if len(found) > 5000:
            return "closed"                    # too many to follow: refused, never truncated
        for m in found:
            if _in_home(os.path.realpath(os.path.join(m, *parts[k + 1:])), hp) == "closed":
                return "closed"
    elif w == "open" and _in_home(os.path.realpath(path), hp) == "closed":
        return "closed"
    return w


def _where_all(path: str, hp: List[str]) -> Optional[set]:
    """Every classification a pattern path can take: the pattern itself and each thing it names now (followed through
    links, the rest as written). None: too many matches to follow."""
    kinds = {_in_home(path, hp)}
    if re.search(r"[*?\[]", path):
        import glob as _glob
        parts = path.split("/")
        k = max(i for i, x in enumerate(parts) if re.search(r"[*?\[]", x))
        found = _glob.glob("/".join(parts[:k + 1]))
        if len(found) > 5000:
            return None
        for m in found:
            kinds.add(_in_home(os.path.realpath(os.path.join(m, *parts[k + 1:])), hp))
    return kinds


def _google_hold_signature(verdict: "Verdict") -> str:
    """Bind the final held action, all payload bytes and reply-context requirement; never binds an ALLOW."""
    return json.dumps([verdict.kind, verdict.payload, verdict.needs_reply_context],
                      sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def _google_hold_script_paths() -> set:
    """Only the configured home and supported installed engine roots; never a caller's suffix or QOSHA_SRC."""
    roots = {"/opt/hermes"}
    home = ENGINE_HOME or os.environ.get("HERMES_HOME", "")
    if isinstance(home, str) and home.startswith("/") and os.path.normpath(home) == home and os.path.realpath(home) == home:
        roots.add(home)
    # The kit imports this package before loading plugins. Use that already-loaded provenance without importing
    # anything or searching cwd/sys.path. Its source tree must have the exact supported pinned-install layout.
    engine = sys.modules.get("hermes_cli")
    package = getattr(engine, "__file__", None)
    suffix = "/hermes_cli/__init__.py"
    if isinstance(package, str) and package.startswith("/") and package.endswith(suffix) and \
            os.path.normpath(package) == package and os.path.realpath(package) == package:
        installed = package[:-len(suffix)]
        if installed == "/opt/hermes" or installed.endswith("/src/hermes-6eb531c"):
            roots.add(installed)
    return {root + GAPI_SUFFIX for root in roots}


def _google_hold_scan_binding(tool: str, args: Any) -> Optional[tuple]:
    """Narrow grammar for an actual Python invocation of one literal Google mutation; no body trust yet."""
    if tool != "terminal" or not isinstance(args, dict) or not set(args) <= {"command", "timeout", "workdir"}:
        return None
    command = args.get("command")
    if not isinstance(command, str) or _has_expansion(command):
        return None
    cmds = _split_commands(command)
    if not cmds or len(cmds) != 1:
        return None
    words = cmds[0]
    allowed_python = {"python", "python3", "/usr/bin/python", "/usr/bin/python3", "/opt/hermes/.venv/bin/python",
                      sys.executable}
    if not words or words[0] not in allowed_python or not re.fullmatch(r"python(?:3?(?:\.[0-9]+)?)?", _program_identity(words[0])):
        return None
    index = 1
    while index < len(words) and words[index] in ("-u", "-B", "-I", "-E", "-s", "-S"):
        index += 1
    if index + 2 >= len(words):
        return None
    path = words[index]
    if not path.startswith("/") or os.path.normpath(path) != path or not path.endswith(GAPI_SUFFIX):
        return None
    if path not in _google_hold_script_paths():
        return None
    action = tuple(words[index + 1:index + 3])
    if action not in _SPECS or action not in HOLDABLE:
        return None
    verdict = _classify_shell(command)
    if verdict.action != HOLD or verdict.kind != HOLDABLE[action]:
        return None
    return path, _google_hold_signature(verdict)


def _google_scan_stat(st) -> tuple:
    return (st.st_dev, st.st_ino, st.st_mode, st.st_nlink, st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def _read_google_scan_candidate(path: str, expected) -> bytes:
    """Read the existing scan candidate once through pinned no-follow descriptors, with bounded stable bytes."""
    if not path.startswith("/") or os.path.normpath(path) != path or os.path.realpath(path) != path:
        raise OSError("noncanonical Google script")
    parts = path[1:].split("/")
    parent = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
    fd = None
    try:
        for name in parts[:-1]:
            nxt = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            os.close(parent)
            parent = nxt
        fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > 2_000_000 or \
                _google_scan_stat(before) != _google_scan_stat(expected):
            raise OSError("Google script identity changed")
        chunks, size = [], 0
        while size <= 2_000_000:
            chunk = os.read(fd, min(65536, 2_000_001 - size))
            if not chunk:
                break
            chunks.append(chunk)
            size += len(chunk)
        raw = b"".join(chunks)
        after = os.fstat(fd)
        leaf = os.stat(parts[-1], dir_fd=parent, follow_symlinks=False)
        named = os.stat(path, follow_symlinks=False)
        if len(raw) > 2_000_000 or len(raw) != before.st_size or os.path.realpath(path) != path or \
                any(_google_scan_stat(now) != _google_scan_stat(before) for now in (after, leaf, named)):
            raise OSError("Google script changed during scan")
        return raw
    finally:
        if fd is not None:
            os.close(fd)
        os.close(parent)


def _finish_google_scan(verdict: "Verdict", scan: dict) -> "Verdict":
    """A skipped scan can only finish denied or with the exact bound HOLD; never an executable tool call."""
    if not scan.get("used") or verdict.action == DENY:
        return verdict
    binding = scan.get("binding")
    try:
        exact = verdict.action == HOLD and binding and _google_hold_signature(verdict) == binding[1]
    except (TypeError, ValueError):
        exact = False
    if not exact:
        return Verdict(DENY, "The Google approval action changed while it was checked. Nothing was run; ask again.")
    return verdict


def _home_check(strings: List[str], workdirs: List[str], code: bool, file_paths: List[str], depth: int = 0,
                inherited: Optional[List[str]] = None, shell_text: bool = True, google_scan: Optional[dict] = None) -> bool:
    """D21, fail closed: True when the call could reach the engine home outside its open folders (files/, skills/).
    code=True (terminal, process, execute_code, scripts they run): every shell word (quotes respected, patterns and
    braces expanded the way the shell does, nested bodies included) and every context-free token; working inside the
    home; the engine's own command line; links made into the home; bulk and recursive commands while a folder they may
    start from is above the home; copies/moves naming the home or a folder above it; and the bodies of existing files
    the command may run. Command names count by what their patterns name (/bin/ba[s]h is bash). code=False (file
    tools): the given paths, intact."""
    hp = _home_parts()
    if not hp:
        return False
    wf = [w for s in strings for w in _words_all(s)] if code else []
    if not shell_text:                         # program text (python, perl, ...): no shell globbing of its words,
        wf = [(t, g, pt and "/" in t) for t, g, pt in wf]   # except path-like ones it may hand to a shell
    words = [t for t, g, pt in wf]
    toks = [t for s in strings for t in _path_tokens(s)] if code else []
    # Opus r2 N2: a path glued to short options (sort -o../cron/x, cp -t../plugins, tar -xf../x.tar) is a path too
    toks += [m.group(1) for w in words + toks for m in [re.match(r"^-[A-Za-z]+([./~].*)$", w)] if m]
    bases = _bases(workdirs, words + toks, code) + list(inherited or [])   # a script runs where its command runs
    names = {os.path.expanduser(t).rsplit("/", 1)[-1] for t in words + toks}
    patterned = [(t, g) for t, g, pt in wf if pt]
    for t, g in patterned:                     # command names written as patterns count by what they name
        found = _expand(g, bases)
        if found is None:
            return True                        # more than can be checked
        names.update(f.rsplit("/", 1)[-1] for f in found)
    if code:
        if any(_in_home(b, hp) in ("home", "closed") for b in bases):
            return True                        # working in the engine home itself or a closed part of it (GUARDFIX:
                                               # its open folders, Files above all, are the assistant's workspace)
        if names & _ENGINE_CLI:
            return True
    # Bulk and recursive commands (archives, sync, patch, git, recursive copy/search/change) write or walk whole
    # folders: since the person's home folder and the dashboard's folder are above the engine home, they are refused
    # for the assistant whatever their flags or destinations (R-cronpolicy4: flags mean different things per command).
    rec = any(re.fullmatch(r"-[A-Za-z]*[rR][A-Za-z]*|--recursive", t) for t in words + toks)
    rec_cp = rec or any(re.fullmatch(r"-[A-Za-z]*a[A-Za-z]*|--archive", t) for t in words + toks)   # cp -a
    if code and (names & (_EXTRACT - {"git"}) or ("git" in names and names & _GIT_WRITES) or
                 names & {"find", "rg", "ag", "tree", "du", "zip", "rsync"} or
                 (names & {"cp", "scp"} and rec_cp) or
                 (names & {"grep", "egrep", "fgrep", "ls", "chmod", "chown", "rm"} and rec) or
                 names & {"diff", "gdiff", "cmp", "comm", "sdiff"}):   # Opus r3: a folder compare prints both sides
        if any(_in_home(b, hp) in ("above", "home") for b in bases):
            return True
        # GUARDFIX: now that the work folder is Files, also every word that names the engine home or a folder above it
        # (tar czf out.tgz <home>, zip -r x.zip .., grep -r x ~); the command itself, not a program's text it runs
        for t, g, pt in (wf if depth == 0 and shell_text else []):
            tt = os.path.expanduser(t)
            if tt and "\x00" not in tt and any(_in_home(_resolve(c), hp) in ("above", "home") for c in
                                                ([tt] if tt.startswith("/") else [os.path.join(b, tt) for b in bases])):
                return True
            if pt:
                alts = _alternatives(g, bases)
                if alts is None or any(_where_all(_resolve(c), hp) is None or
                                       _where_all(_resolve(c), hp) & {"above", "home"} for c in alts):
                    return True
        for tok in (toks if depth == 0 and shell_text else []):
            tt = os.path.expanduser(tok)
            if tt and "\x00" not in tt and any(_in_home(_resolve(c), hp) in ("above", "home") for c in
                                                ([tt] if tt.startswith("/") else [os.path.join(b, tt) for b in bases])):
                return True
    links = code and (bool(names & {"ln", "link"}) or bool(re.search(r"symlink|hardlink|\blink_to\b|os\.link\b",
                                                                        " ".join(strings))))
    movers = code and bool(names & {"cp", "mv", "install", "ditto", "ln", "link"})

    def judge(c: str, expand: bool) -> bool:
        r = _resolve(c)
        kinds = _where_all(r, hp) if expand else {_in_home(r, hp)}
        if kinds is None or "closed" in kinds:
            return True
        if re.search(r"[*?\[]", c) and _in_home(os.path.realpath(c), hp) == "closed":
            return True                        # the name as written may exist literally ('alias[1]' a link)
        if movers and kinds & {"home", "above"}:
            return True                        # cp/mv into the home or a folder above it (cp -R x/. <lab>, mv y/cron home)
        if links and kinds & {"home", "open"}:
            return True                        # a link made to or inside the home could lead anywhere in it
        return False

    for t, g, pt in wf:                        # shell words: as written, and as their patterns name (braces first)
        tt = os.path.expanduser(t)
        if tt and "\x00" not in tt:
            for c in ([tt] if tt.startswith("/") else [os.path.join(b, tt) for b in bases]):
                if judge(c, False):
                    return True
        if pt:
            alts = _alternatives(g, bases)
            if alts is None:
                return True
            for c in alts:
                if judge(c, True):
                    return True
    for tok in toks + list(file_paths):        # context-free tokens (no expansion) and file-tool paths (as given)
        tok = os.path.expanduser(tok)
        if not tok or "\x00" in tok:
            continue
        for c in ([tok] if tok.startswith("/") else [os.path.join(b, tok) for b in bases]):
            if judge(c, tok in file_paths):
                return True
    if code and depth > 8:
        return True                            # scripts that run scripts deeper than this: refused, not guessed
    if code:
        # files the command may run: an interpreter's operand (any name, no suffix needed) or an executable file
        runs = any(_RUNNERS.match(n) for n in names)
        cands: List[str] = []
        data_words = _trusted_data_words(strings) if depth == 0 else set()
        for t in set(words + toks) - data_words:
            tt = os.path.expanduser(t)
            cands += [tt] if tt.startswith("/") else [os.path.join(b, tt) for b in bases]
        for t, g in patterned:
            found = _expand(g, bases)
            if found is None or len(found) > 200:
                return True                    # too many to check
            cands += found
        for c in cands:
            try:
                st = os.stat(c)
            except (OSError, ValueError):
                continue
            if not os.path.isfile(c) or not (runs or st.st_mode & 0o111):
                continue
            if _binary_data(c) is None:
                return True                    # unreadable, or a zip an interpreter could run (__main__.py)
            if st.st_size > 2_000_000:
                return True                    # can't be checked
            scan_candidate = bool(depth == 0 and google_scan and google_scan.get("binding") and
                                  c == google_scan["binding"][0])
            try:
                if scan_candidate:
                    raw = _read_google_scan_candidate(c, st)
                else:
                    with open(c, "rb") as fh:
                        raw = fh.read()
            except OSError:
                return True
            # Hash the exact descriptor-bound bytes that would be recursively scanned; no separate hash(path) check.
            if scan_candidate and hashlib.sha256(raw).hexdigest() in TRUSTED_GAPI_SHA256:
                google_scan["used"] = True
                continue
            first = raw[:80].split(b"\n", 1)[0]
            if raw[:4] in _NATIVE_MAGIC and b"\x00" in first and os.path.realpath(c).startswith(_SYSTEM_DIRS):
                continue                       # the system's own programs (which the assistant can't write); any
                                               # other file is read as code whatever its header
            if _trusted_skill_script(c):
                continue                       # GUARDFIX: the release's own skill code (its arguments are checked)
            key = (st.st_dev, st.st_ino)
            if key in _visiting:
                continue                       # already being checked higher up (a runs b runs a)
            _visiting.add(key)
            shebang = first.decode("latin-1") if first.startswith(b"#!") else ""
            # shell semantics unless only a non-shell interpreter could run it: a shell named anywhere in the command
            # (bash file overrides a python shebang), a shell shebang, or no shebang at all
            shell_file = bool(names & (_SHELLS | {"source", "."})) or bool(
                re.search(r"\b(sh|bash|zsh|dash|ksh|fish)\b", shebang)) or not shebang
            try:
                hit = _home_check([raw.replace(b"\x00", b" ").decode("utf-8", "replace")], workdirs, True, [],
                                  depth + 1, bases, shell_file)
            finally:
                _visiting.discard(key)
            if hit:
                return True
    return False


def _patch_paths(text: str) -> Optional[List[str]]:
    """File names an engine (V4A) patch touches, by the engine's own parser when it is importable (in the dashboard),
    else by its headers (Add/Update/Delete File, Move File: a -> b, Move to). None: a patch Qosha can't read."""
    if not re.search(r"\*\*\*\s*(Begin Patch|Add File|Update File|Delete File|Move)", text):
        return []
    try:
        from tools.patch_parser import parse_v4a_patch   # the pinned engine's grammar
        ops, err = parse_v4a_patch(text)
        if err:
            return None
        return [p for op in ops for p in (op.file_path, getattr(op, "new_path", None)) if p]
    except ImportError:
        pass
    out = []
    for line in text.splitlines():
        m = re.match(r"\s*\*\*\*\s*(?:Add|Update|Delete)\s+File:\s*(.+?)\s*$", line)
        if m:
            out.append(m.group(1)); continue
        m = re.match(r"\s*\*\*\*\s*Move\s+File:\s*(.+?)\s*->\s*(.+?)\s*$", line)
        if m:
            out += [m.group(1), m.group(2)]; continue
        m = re.match(r"\s*\*\*\*\s*Move\s+to:\s*(.+?)\s*$", line)
        if m:
            out.append(m.group(1))
    return out or None


# ---- Connected apps (MCP servers, night job 3) -------------------------------------------------------------------
# Only servers in Qosha's catalog (qosha_guard/mcp_catalog.json, written by mcp/install_mcp.py; the assistant can't
# write the plugins folder) and only their listed read tools run without a person. Everything else is HELD as an
# "app.action" decision with the exact arguments; a missing or unreadable catalog holds everything.
MCP_CATALOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mcp_catalog.json")
MCP_MAIL_STRICT = re.compile(r"mail|gmail|email|outlook|calendar|smtp|inbox", re.I)
# Words in a tool's name that mean it changes, sends, shares or pays: always held, even if listed as a read.
_MCP_WRITE_TOKENS = {
    "send", "post", "delete", "del", "remove", "pay", "payout", "publish", "share", "create", "update", "write", "edit",
    "move", "invite", "transfer", "refund", "charge", "cancel", "archive", "upload", "submit", "approve", "add", "set",
    "put", "patch", "modify", "insert", "rename", "merge", "close", "assign", "comment", "reply", "forward",
    "schedule", "book", "order", "run", "execute", "exec", "call", "trigger", "start", "stop", "deploy", "grant",
    "revoke", "void", "capture", "duplicate", "copy", "import", "export", "sync", "save", "store", "apply", "enable",
    "disable", "push", "fork", "dispatch", "sign", "finalize", "mark", "resolve", "reopen", "transition", "link",
    "unlink", "tag", "label", "notify", "message", "email", "draft", "generate", "make", "new", "restore", "purge",
    "trash", "clear", "reset", "batch", "bulk", "mutate", "upsert", "replace", "accept", "decline", "reject"}
_MCP_WRITE_SUBSTR = ("send", "delete", "publish", "transfer", "refund", "remove", "share", "invite", "payout", "create",
                     "update", "write", "upload", "submit")
_MCP_CACHE: Dict[str, Any] = {"mtime": None, "cat": None}
# Test seam: a function (server, tool) -> True/False/None giving the engine's readOnlyHint for a discovered tool.
MCP_READ_ONLY_HINT = None


def _mcp_sanitize(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_]", "_", str(value or ""))


def mcp_catalog() -> Optional[Dict[str, Dict[str, Any]]]:
    """{raw server name: catalog entry}, or None when the catalog is missing or malformed (then all is held)."""
    try:
        mtime = os.stat(MCP_CATALOG_PATH).st_mtime_ns
        if _MCP_CACHE["mtime"] != mtime:
            with open(MCP_CATALOG_PATH, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            _MCP_CACHE["cat"] = {s["name"]: s for s in data["servers"]
                                 if isinstance(s, dict) and isinstance(s.get("name"), str)}
            _MCP_CACHE["mtime"] = mtime
        return _MCP_CACHE["cat"]
    except Exception:
        _MCP_CACHE["mtime"] = _MCP_CACHE["cat"] = None
        return None


# Test seam: a function (registry name) -> {"server": raw, "tool": raw, "servers": [all raw MCP servers]} or None.
MCP_IDENTITY = None


def _mcp_names_collide(a: str, b: str) -> bool:
    """Two different raw server names that the engine's tool names could confuse (same sanitized form, or one a
    `_`-prefix of the other: `files` / `files_evil` / `files__evil`)."""
    if a == b:
        return False
    x, y = _mcp_sanitize(a), _mcp_sanitize(b)
    return x == y or x.startswith(y + "_") or y.startswith(x + "_")


def mcp_identity(tool: str) -> Optional[Dict[str, Any]]:
    """The raw server and raw tool the ENGINE registered under this tool name, from its own records (never by
    splitting the name): tools.mcp_tool._mcp_tool_server_names gives the server, and the one raw tool of that server
    whose registered name equals `tool` gives the tool. None when not registered, or when more than one raw tool
    maps to the name (ambiguous)."""
    if MCP_IDENTITY is not None:
        return MCP_IDENTITY(tool)
    import sys
    mod = sys.modules.get("tools.mcp_tool")   # the engine's MCP client, loaded in the agent process
    if mod is None:
        return None
    owners = dict(getattr(mod, "_mcp_tool_server_names", None) or {})
    server = owners.get(tool)
    if not isinstance(server, str):
        return None
    prefixed = getattr(mod, "mcp_prefixed_tool_name")
    raws = set()
    live = getattr(mod, "_servers", {}).get(server)
    for t in list(getattr(live, "_tools", None) or []):
        raws.add(getattr(t, "name", None))
    raws |= set((getattr(mod, "_tool_read_only_hints", {}) or {}).get(server, {}) or {})
    matches = [r for r in raws if isinstance(r, str) and prefixed(server, r) == tool]
    if len(matches) != 1:
        return None
    servers = sorted(set(v for v in owners.values() if isinstance(v, str)) | set(getattr(mod, "_servers", {}) or {}))
    return {"server": server, "tool": matches[0], "servers": servers}


def mcp_parse(tool: str):
    """(identity or None, catalog entry or None). The entry only when the engine's own records name exactly one raw
    server and tool for this name, that server is one of Qosha's apps, and no other configured server's name could be
    confused with it."""
    ident = mcp_identity(tool)
    if ident is None:
        return None, None
    cat = mcp_catalog() or {}
    entry = cat.get(ident["server"])
    if entry is not None and any(_mcp_names_collide(ident["server"], o) for o in ident.get("servers") or []):
        entry = None
    return ident, entry


def _mcp_read_only_hint(server: str, name: str) -> Optional[bool]:
    """The engine's discovery-time readOnlyHint for the RAW server and tool (exact names)."""
    if MCP_READ_ONLY_HINT is not None:
        return MCP_READ_ONLY_HINT(server, name)
    import sys
    mod = sys.modules.get("tools.mcp_tool")
    hints = getattr(mod, "_tool_read_only_hints", None) if mod else None
    if not isinstance(hints, dict):
        return None
    v = (hints.get(server) or {}).get(name)
    return None if v is None else v is True


def _mcp_tokens(name: str) -> List[str]:
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", name)
    return [t for t in re.split(r"[^A-Za-z0-9]+", spaced.lower()) if t]


def mcp_write_name(name: str) -> bool:
    low = name.lower()
    return bool(set(_mcp_tokens(name)) & _MCP_WRITE_TOKENS) or any(w in low for w in _MCP_WRITE_SUBSTR)


_MCP_PATH_KEYS = ("path", "paths", "source", "destination", "root", "file", "files", "directory", "dir", "target")


def _files_root() -> str:
    eh = ENGINE_HOME or os.environ.get("HERMES_HOME", "")
    return os.path.realpath(os.path.join(os.path.expanduser(eh), "files")) if eh else ""


def _mcp_files_outside(args: Any) -> Optional[str]:
    """A path argument of the files server that leaves the files folder (after `..`, `~` and links), or None."""
    root = _files_root()
    if not root:
        return "no files folder"
    vals: List[str] = []
    if isinstance(args, dict):
        for k, v in args.items():
            if k in _MCP_PATH_KEYS or k.endswith("path") or k.endswith("Path"):
                vals += _strings(v)
    hp = _home_parts()
    for v in vals:
        p = os.path.expanduser(v.strip())
        full = os.path.realpath(p if os.path.isabs(p) else os.path.join(root, p))
        if full != root and not full.startswith(root + os.sep):
            return v
        if hp and _skills_place(full, hp):
            return v                           # a skill linked into Your files is still a skill (GPT save-18)
    return None


def _mcp_files_relative(args: Any) -> str:
    """The files server's arguments as text, with each path inside the files folder written relative to it (a path
    outside keeps its full text; _mcp_files_outside refuses it anyway)."""
    root = _files_root()
    out: List[str] = []
    if isinstance(args, dict):
        for k, v in args.items():
            pathlike = k in _MCP_PATH_KEYS or k.endswith("path") or k.endswith("Path")
            for t in _strings(v):
                if pathlike and root:
                    p = os.path.expanduser(t.strip())
                    full = os.path.realpath(p if os.path.isabs(p) else os.path.join(root, p))
                    if full == root or full.startswith(root + os.sep):
                        t = os.path.relpath(full, root)
                out.append(t)
    else:
        out = _strings(args)
    return "\n".join(out)


def _mcp_hold(tool: str, ident: Optional[Dict[str, Any]], entry: Optional[Dict[str, Any]], args: Any,
              why: str) -> Verdict:
    """Held as an app.action. `server`/`tool` are the RAW names from the engine (hashed with the payload; the executor
    runs only that exact server and tool). An unresolved name is still held, with `resolved: false`: it can't run."""
    payload = {"server": ident["server"] if ident else "", "tool": ident["tool"] if ident else "",
               "registered_name": tool, "resolved": bool(ident),
               "server_label": (entry or {}).get("label") or (ident["server"] if ident else tool),
               "arguments": args if isinstance(args, dict) else {"value": args}}
    return Verdict(HOLD, why, "app.action", payload)


# The "Qosha Google" MCP server (D26, founder 3 Nov): reads run; sends and calendar changes are held as the same decisions
# as the engine's own google_api.py commands, with the same payload fields, and the person approves them on a card.
GOOGLE_MCP_READS = ("search_email", "read_email", "list_events", "list_drafts")
GOOGLE_MCP_HOLDS = {
    "send_email": ("email.send", {"to": "to", "subject": "subject", "body": "body", "cc": "cc", "bcc": "bcc"},
                   ("to", "subject", "body")),
    # SENDFIX: the card shows the forwarded email and its attachments, or the draft, as the connector reads them (hook)
    "forward_email": ("email.forward", {"message_id": "message_id", "to": "to", "cc": "cc", "bcc": "bcc", "body": "body"},
                      ("message_id", "to")),
    "send_draft": ("email.draft_send", {"draft_id": "draft_id"}, ("draft_id",)),
    "save_draft": ("email.draft_save", {"to": "to", "cc": "cc", "bcc": "bcc", "subject": "subject", "body": "body"},
                   ("subject", "body")),
    "reply_email": ("email.reply", {"message_id": "reply_to_message_id", "body": "body"}, ("reply_to_message_id", "body")),
    "create_event": ("calendar.create", {"summary": "summary", "start": "start", "end": "end", "location": "location",
                                         "description": "description", "attendees": "attendees"}, ("summary", "start", "end")),
    "update_event": ("calendar.update", {"event_id": "event_id", "summary": "summary", "start": "start", "end": "end",
                                         "location": "location", "description": "description"}, ("event_id",)),
    "delete_event": ("calendar.delete", {"event_id": "event_id"}, ("event_id",)),
}
_MULTILINE = ("body", "description")
_HIDDEN = re.compile("[\x00-\x08\x0b-\x1f\x7f-\x9f\u200b-\u200d\u2028\u2029\u202a-\u202e\u2060\u2066-\u2069\ufeff]")


def _classify_google_mcp(name: str, args: Any) -> Verdict:
    if name in GOOGLE_MCP_READS:
        return Verdict(ALLOW)
    spec = GOOGLE_MCP_HOLDS.get(name)
    if spec is None:
        return Verdict(DENY, "Not one of Qosha's Google actions.")
    kind, fields, required = spec
    if not isinstance(args, dict):
        return Verdict(DENY, "Qosha's Google actions take named fields.")
    extra = sorted(k for k in args if k not in fields)
    if extra:
        return Verdict(DENY, "Qosha's Google action %s has no field %r." % (name, extra[0]))
    payload = dict(_DEFAULTS[kind])
    for src, dst in fields.items():
        v = args.get(src)
        if v is None:
            continue
        if src == "attendees" and isinstance(v, list) and all(isinstance(x, str) for x in v):
            v = ", ".join(v)
        if not isinstance(v, str):
            return Verdict(DENY, "%s must be text." % src)
        # what the person reads on the card is exactly what is sent: no hidden or line-faking characters
        if _HIDDEN.search(v.replace("\n", "").replace("\t", "") if src in _MULTILINE else v) or (
                src not in _MULTILINE and ("\n" in v or "\t" in v)):
            return Verdict(DENY, "%s holds characters that can't be shown safely on the approval card." % src)
        payload[dst] = v
    missing = [r for r in required if not str(payload.get(r, "")).strip()]
    if missing:
        return Verdict(DENY, "%s needs %s." % (name, ", ".join(missing)))
    for k in ("reply_to_message_id", "event_id", "message_id", "draft_id"):
        if k in payload and not _ID.match(payload[k]):
            return Verdict(DENY, "%s is not a valid id." % k)
    if kind == "calendar.update" and not any(payload.get(k) for k in ("summary", "start", "end", "location", "description")):
        return Verdict(DENY, "update_event needs at least one new value.")
    return Verdict(HOLD, "sends an email or changes the calendar", kind, payload, kind == "email.reply")


def _classify_mcp(tool: str, ident: Optional[Dict[str, Any]], entry: Optional[Dict[str, Any]], args: Any) -> Verdict:
    if ident is None:
        return _mcp_hold(tool, ident, entry, args, "the engine does not know exactly which app this is")
    if entry is None:
        return _mcp_hold(tool, ident, entry, args, "not one of Qosha's connected apps")
    name = ident["tool"]
    if entry.get("files_folder_only"):   # the files server: only its listed operations, only inside the files folder
        if name not in (entry.get("read_tools") or []) or name not in _FILES_OPS:
            return _mcp_hold(tool, ident, entry, args, "not a known files operation")
        bad = _mcp_files_outside(args)
        if bad:
            return Verdict(DENY, "The files connection only works inside your Qosha files folder (%r is outside it)." % bad)
        if name in _FILES_WRITES:
            # same rules as the engine's own write_file (WRITE_TOOLS); a path inside the files folder is scanned as its
            # name below that folder, as for write_file (its full path names the lab home, a marker: night job 5 live check)
            text = _mcp_files_relative(args)
            if OBFUSCATION.search(text) or PY_STARTUP.search(text):
                return Verdict(DENY, "Writing encoded code or program start-up files is not allowed while mail and calendar are connected.")
            hit = _mail_hit(text)
            if hit:
                return Verdict(DENY, "Writing files that use mail or calendar access is not allowed (%r)." % hit)
        return Verdict(ALLOW)
    if mcp_write_name(name):
        return _mcp_hold(tool, ident, entry, args, "changes, sends, shares or pays")
    if name not in [r for r in entry.get("read_tools") or [] if isinstance(r, str)]:
        return _mcp_hold(tool, ident, entry, args, "not a known read")
    if _mcp_read_only_hint(ident["server"], name) is not True:
        return _mcp_hold(tool, ident, entry, args, "the app does not mark it read-only")
    return Verdict(ALLOW)


# The filesystem server's operations Qosha lets run inside the files folder (server-filesystem 2.1.0). Any other
# operation of that server, now or after an update, waits for approval.
_FILES_READS = ("read_file", "read_text_file", "read_media_file", "read_multiple_files", "list_directory",
                "list_directory_with_sizes", "directory_tree", "search_files", "get_file_info",
                "list_allowed_directories")
_FILES_WRITES = ("write_file", "edit_file", "create_directory", "move_file")
_FILES_OPS = _FILES_READS + _FILES_WRITES


_PATCH_FILE_LINE = re.compile(r"^(\*\*\* (?:Update|Add|Delete) File: |\*\*\* Move to: )(.+?)[ \t]*$", re.M)


def _files_relative_text(tool: str, args: Any, joined: str) -> str:
    """write_file / patch (night job 4): a target path that resolves inside the files folder is scanned as its name below
    that folder, the way the files app's paths are (_mcp_files_relative): its full path names the lab home, which is a
    marker, so a file could not be made there by its full path. The content and every other path are scanned as
    written; the home and folder checks above have already run on the real paths."""
    root = _files_root()
    if tool not in ("write_file", "patch", "read_file", "search_files") or not root or not isinstance(args, dict):
        return joined
    # GUARDFIX: read_file / search_files too, and a path in the skills folder is scanned from "skills/" on (on the Mac
    # the lab home's full path is itself a marker, so Files and the skills could not be read by their full path)
    hp = _home_parts()
    skills = "/" + "/".join(hp + ["skills"]) if hp else ""

    def rel(t: str) -> str:
        p = os.path.expanduser(t.strip())
        if not os.path.isabs(p):
            return t
        full = os.path.realpath(p)
        if full.startswith(root + os.sep):
            return os.path.relpath(full, root)
        if tool in ("read_file", "search_files") and skills and full.startswith(skills + os.sep):
            return "skills/" + os.path.relpath(full, skills)
        return t

    out: List[str] = []
    for k, v in args.items():
        for t in _strings(v):
            if k in ("path", "file_path", "root", "directory") and t.strip():
                t = rel(t)
            elif k == "patch":
                t = _PATCH_FILE_LINE.sub(lambda m: m.group(1) + rel(m.group(2)), t)
            out.append(t)
    return "\n".join(out)


def _in_skills(path: str, hp: List[str]) -> bool:
    """True when an absolute path (links already followed) is the engine's skills folder or inside it; a pattern part
    there counts when it could name skills/."""
    parts = [x.lower() for x in path.split("/") if x]
    if len(parts) <= len(hp) or _in_home(path, hp) in ("", "above", "home"):
        return False
    return fnmatch.fnmatchcase("skills", parts[len(hp)])


_LINK_CACHE: Dict[str, Any] = {}


def _skill_link_targets(hp: List[str]) -> List[str]:
    """Where links inside the skills folders point, and links inside those targets in turn (a linked skill's real folder
    counts as the skills folder too, GPT save-12). Lower case (this Mac's disks ignore case). Cached for 30 s."""
    import time as _time
    root = "/" + "/".join(hp) + "/skills"
    hit = _LINK_CACHE.get(root)
    if hit and _time.time() - hit[0] < 30:
        return hit[1]
    out: List[str] = [os.path.realpath(root).lower()] if os.path.islink(root) else []
    todo, done = [root], set()
    while todo and len(done) < 50 and len(out) < 2000:
        top = todo.pop()
        if top.lower() in done:
            continue
        done.add(top.lower())
        for d, dirs, files in os.walk(top):
            for n in dirs + files:
                p = os.path.join(d, n)
                if os.path.islink(p):
                    t = os.path.realpath(p)
                    out.append(t.lower())
                    if os.path.isdir(t):
                        todo.append(t)
    if todo or len(out) >= 2000:
        out = ["/"]                            # too many links to follow: everything counts as the skills folder
    _LINK_CACHE[root] = (_time.time(), out)
    return out


def _skills_place(path: str, hp: List[str]) -> bool:
    """An absolute path: inside the skills folders as written, as resolved, or inside a folder a skills link points to."""
    if _in_skills(path, hp) or _in_skills(os.path.normpath(path), hp):
        return True
    r = os.path.realpath(path) if not re.search(r"[*?\[]", path) else path
    if _in_skills(r, hp):
        return True
    low = r.lower()
    return any(t == "/" or low == t or low.startswith(t.rstrip("/") + "/") for t in _skill_link_targets(hp))


def _skills_reach(c: str, hp: List[str]) -> bool:
    """A path (absolute; may hold patterns) that is or could be inside the skills folders: as written, through links
    before the first pattern, and, for a pattern, every match it names now followed through links."""
    if _skills_place(_resolve(c), hp) or _skills_place(os.path.normpath(c), hp):
        return True
    if not re.search(r"[*?\[]", c):
        return _skills_place(c, hp)
    import glob as _glob
    parts = c.split("/")
    k = max(i for i, x in enumerate(parts) if re.search(r"[*?\[]", x))
    found = _glob.glob("/".join(parts[:k + 1]))
    if len(found) > 5000:
        return True
    return any(_skills_place(os.path.join(m, *parts[k + 1:]), hp) for m in found)


def _skills_hits(word: str, bases: List[str], hp: List[str]) -> List[str]:
    w = os.path.expanduser(word)
    if not w or "\x00" in w:
        return []
    return [_resolve(c) for c in ([w] if w.startswith("/") else [os.path.join(b, w) for b in bases]) if _skills_reach(c, hp)]


def _program_identity(word: str) -> str:
    """What a command word really runs: the resolved file's name when it is one of the system's own programs in /bin or
    /usr/bin (which the assistant can't write), else "" (a link, copy or file elsewhere named like one is not it:
    GPT save-14, save-16). Interpreters may also live elsewhere (a venv, Homebrew): there the resolved name counts."""
    import shutil as _sh
    exe = os.path.expanduser(word) if "/" in word else (_sh.which(word) or "")
    if not exe:
        return ""
    real = os.path.realpath(exe)
    base = os.path.basename(real)
    if real.startswith(("/bin/", "/usr/bin/")):
        return base
    return base if _RUNNERS.match(base) else ""


def _says_skills(text: str) -> bool:
    """The word "skills" anywhere, also built from pieces or reversed (quotes, +, spaces, brackets and commas dropped)."""
    sq = _squash(text)
    return "skills" in sq or "slliks" in sq


# a terminal command that names the skills folders must be this plain: one command, literal words, no quoting,
# patterns, redirects, pipes, substitutions or chaining (GPT save-1 .. save-11: anything richer is refused, not parsed)
_PLAIN_COMMAND = re.compile(r"[\w ./@%+=:,~-]+")
_QUOTED_PLAIN = re.compile("[\\w ./@%+=:,~'\"-]+")


def _plain_words(command: str) -> Optional[List[str]]:
    """The words of a plain command (above), or None. GUARDFIX (council D43): the skills' own documented commands quote
    their paths (python3 "<skill>/scripts/docx_read.py" "<files>/My report.docx" --text): quotes may group words, nothing
    else is added (no $, backticks, backslashes, patterns, braces, redirects, pipes or chaining, even inside quotes)."""
    c = command.strip()
    if _PLAIN_COMMAND.fullmatch(c):
        return c.split()
    if not _QUOTED_PLAIN.fullmatch(c):
        return None
    try:
        words = shlex.split(c)
    except ValueError:
        return None
    return words if words and all(words) else None


def _skills_write(tool: str, args: Any, strings: List[str], workdirs: List[str], file_paths: List[str]) -> bool:
    """True when the call could write into the skills folders outside the skill.save path. Fails closed.
    File tools: any target there (as written, resolved, or through a link inside them). Code tools other than the
    terminal: any mention of the skills folders, also as the word "skills" in pieces. Terminal: a command that names
    them, by path or by the word, must be exactly `<reader> <literal paths>` (cat, head, tail, ls, wc, file, stat,
    grep, diff, cmp, sums) or a literal run of a skill's own script (`<script>` or `<interpreter> <script>`, with no
    other word naming them); reading a skill otherwise goes through read_file or skill_view. Files the call may run
    (scripts that run scripts, patterns expanded, to depth 8) may not name them either."""
    hp = _home_parts()
    if not hp:
        return False
    if tool in ("write_file", "patch"):
        bases = _bases(workdirs, [], False)
        return any(_skills_hits(p, bases, hp) for p in file_paths)
    if tool not in CODE_TOOLS:
        return False
    wf = [w for x in strings for w in _words_all(x)]
    toks = [t for x in strings for t in _path_tokens(x)]
    bases = _bases(workdirs, [t for t, g, pt in wf] + toks)

    def reaches(t, g, pt) -> bool:
        if _skills_hits(t, bases, hp):
            return True
        if pt:
            alts = _alternatives(g, bases)
            return alts is None or any(_skills_reach(c, hp) for c in alts)
        return False

    command = args.get("command") if isinstance(args, dict) else None
    if tool == "terminal" and isinstance(command, str) and _google_script_only(command):
        return False                           # the engine's own Google script: classified (held or read) below
    named = any(_says_skills(x) for x in strings) or any(reaches(t, g, pt) for t, g, pt in wf) or \
        any(_skills_hits(t, bases, hp) for t in toks)
    if named:
        words = _plain_words(command) if tool == "terminal" and isinstance(command, str) else None
        if words is None:
            return True
        while len(words) > 1 and _skill_env_ok(words[0]):
            words = words[1:]                  # GUARDFIX: a setting the skill documents, its value inside Your files
        name = words[0].rsplit("/", 1)[-1]
        if name in _SKILL_READERS or _RUNNERS.match(name):
            real = _program_identity(words[0])
            if name in _SKILL_READERS and not (real == name or (name in ("egrep", "fgrep") and real == "grep")):
                return True                    # a link or copy named like a reader is not one (GPT save-14)
            if _RUNNERS.match(name) and not _RUNNERS.match(real):
                return True
        if name in _SKILL_READERS:
            for w in words[1:]:
                if w.startswith("-"):
                    if _says_skills(w) or "=" in w:
                        return True            # an option naming them (--file=..., -o...)
                elif not _skills_hits(w, bases, hp) and _says_skills(w):
                    return True                # the word without being a path there
        else:
            script = 0
            if _RUNNERS.match(name):
                script = 1                     # python3 <script> ...: no options before the script
            if len(words) <= script:
                return True
            hits = _skills_hits(words[script], bases, hp)
            if not hits or not all(os.path.isfile(r) for r in hits):
                return True                    # the command or script is not an existing file of a skill
            if any(_says_skills(w) or _skills_hits(w, bases, hp) for w in words[script + 1:]):
                return True                    # its arguments may not name the skills folders
    # the files this call runs: each command word, the script operand of an interpreter or shell, and any executable
    # file named (its data files are not read as code); patterns expanded
    run: List[tuple] = []
    cmds = _split_commands(command) if tool == "terminal" and isinstance(command, str) else None
    for c in (cmds if cmds is not None else [[t for t, g, pt in wf]]):
        i = 0
        while i < len(c) and _ASSIGN.match(c[i]):
            i += 1
        if i < len(c):
            run.append(c[i])
            if _RUNNERS.match(c[i].rsplit("/", 1)[-1]) or re.search(r"[*?\[]", c[i]) or \
                    _RUNNERS.match(os.path.basename(os.path.realpath(os.path.expanduser(c[i])))) or \
                    _RUNNERS.match(_program_identity(c[i]) or "-"):
                j = i + 1
                while j < len(c) and c[j].startswith("-"):
                    j += 1
                if j < len(c):
                    run.append(c[j])
    if tool != "terminal" or cmds is None or any(_RUNNERS.match(os.path.expanduser(t).rsplit("/", 1)[-1])
                                                 or t.rsplit("/", 1)[-1] in _SHELLS for t, g, pt in wf):
        run += [t for t, g, pt in wf]          # an interpreter or shell anywhere (env sh x, sh -c '..'): any file named
    data_words = _trusted_data_words(strings)
    rwf = [(t, g, pt) for t, g, pt in wf if t in run and t not in data_words]
    execs = [(t, g, pt) for t, g, pt in wf if t not in run and not pt and
             any(os.path.isfile(c) and os.access(c, os.X_OK) and not os.path.realpath(c).startswith(_SYSTEM_DIRS)
                 for c in ([os.path.expanduser(t)] if os.path.expanduser(t).startswith("/") else
                           [os.path.join(b, os.path.expanduser(t)) for b in bases]))]
    # the script operands themselves are read as code whatever their name; other files named (data) only for paths
    strict = tuple(os.path.join(b, os.path.expanduser(t)) if not os.path.expanduser(t).startswith("/") else os.path.expanduser(t)
                   for c in (cmds or []) for t in c[1:2] for b in bases)
    return _scripts_name_skills(rwf + execs, [], bases, hp, 0, set(), strict)


def _google_script_only(command: str) -> bool:
    """One invocation of the google-workspace script (google_api.py or its setup.py, by path or $GAPI), optionally after
    plain GAPI=... definitions, and nothing else: no substitutions, redirects or other commands. It lives in the skills
    folder and only reads or is held for approval (_classify_shell); it writes no files."""
    if re.search(r"`|\$\(|<\(|>\(|[<>]", command):
        return False
    cmds = _split_commands(command)
    if not cmds:
        return False
    calls = [c for c in cmds if not all(_ASSIGN.match(t) for t in c)]
    if len(calls) != 1 or not all(all(_definition_ok(t) for t in c) for c in cmds if c is not calls[0]):
        return False
    c = calls[0]
    i = _gapi_index(c)
    if i is not None:
        return True
    i = 0
    while i < len(c) and _ASSIGN.match(c[i]):
        i += 1
    return i + 1 < len(c) and bool(_PY.match(c[i])) and c[i + 1].endswith(SETUP_SUFFIX)


# GOOGLEFIX (5 Nov): in the cloud box the person's home folder and the engine's working folder ARE the engine home
# (/opt/data), so _home_check's "working inside the engine home" rule refuses every terminal command there, the Google
# skill's reads included. Exactly these reads are let past that rule (nothing else is): the skill's own google_api.py
# (this engine home's copy, no link, trusted bytes) run by python with gmail search/get/labels or calendar list and only
# their read flags, by its full path, by the skill's own spelling of that path (${HERMES_HOME:-$HOME/.hermes}/...,
# $HERMES_HOME/...; only when HERMES_HOME is this home) or as the skill writes it (GAPI="python ${HERMES_HOME...}/...
# google_api.py" then $GAPI ...). No other command, operator, redirect, variable or path. The rest of the policy still checks the call.
_GREAD_GAPI = re.compile(r'^GAPI="(?P<py>python3?) (?P<path>[^"\s]+)"\s*(;|&&|\n)\s*\$GAPI (?P<rest>.*)$')
_GREAD_PY = ("python", "python3", "/opt/hermes/.venv/bin/python", "/opt/hermes/.venv/bin/python3")
_BOX_PY = "/opt/hermes/.venv/bin/python"
_GREAD_SAFE = re.compile(r"[A-Za-z0-9 _:.,@+/%='\"-]*")
_GREAD_FLAGS = {("gmail", "search"): ({"--max"}, 1), ("gmail", "get"): (set(), 1), ("gmail", "labels"): (set(), 0),
                ("calendar", "list"): ({"--start", "--end", "--max", "--calendar"}, 0)}


def google_read_argv(tool: str, args: Any) -> Optional[List[str]]:
    """[interpreter, read arguments...] when the call is exactly one of the reads above, else None."""
    if tool != "terminal" or not isinstance(args, dict) or not set(args) <= {"command", "timeout"}:
        return None
    command, eh = args.get("command"), ENGINE_HOME or os.environ.get("HERMES_HOME", "")
    if not isinstance(command, str) or not eh:
        return None
    gapi = os.path.join(os.path.realpath(eh), GAPI_SUFFIX.lstrip("/"))
    if os.path.realpath(gapi) != gapi or not os.path.isfile(gapi) or _sha256(gapi) not in TRUSTED_GAPI_SHA256:
        return None
    command = command.strip()
    # $GAPI and the ${HERMES_HOME...} spellings expand in the shell from its HERMES_HOME: it must be this home
    same_home = bool(os.environ.get("HERMES_HOME")) and os.path.realpath(os.environ["HERMES_HOME"]) == os.path.realpath(eh)
    m = _GREAD_GAPI.match(command)
    if m:
        if not same_home:
            return None
        py, named, rest = m.group("py"), m.group("path"), m.group("rest")
    else:
        head = command.split(" ", 2)
        if len(head) < 3:
            return None
        py, named, rest = head
    # the script by its full path, or by the skill's own spelling of it when the shell's HERMES_HOME is this home
    for var in ("${HERMES_HOME:-$HOME/.hermes}", "${HERMES_HOME}", "$HERMES_HOME"):
        if named.startswith(var + "/") and same_home:
            named = os.path.realpath(eh) + named[len(var):]
            break
    if py not in _GREAD_PY or named != gapi:
        return None
    if not _GREAD_SAFE.fullmatch(rest):
        return None
    try:
        argv = shlex.split(rest)
    except ValueError:
        return None
    spec = _GREAD_FLAGS.get(tuple(argv[:2]))
    if spec is None:
        return None
    flags, npos, pos, i = spec[0], spec[1], [], 2
    while i < len(argv):
        if argv[i].startswith("-"):
            if argv[i] not in flags or i + 1 >= len(argv) or argv[i + 1].startswith("-"):
                return None
            i += 2
        else:
            pos.append(argv[i]); i += 1
    return [py] + argv if len(pos) == npos else None


def _google_read_call(tool: str, args: Any) -> bool:
    return google_read_argv(tool, args) is not None


def google_read_command(tool: str, args: Any) -> Optional[str]:
    """The one command the hook runs for an allowed read: the box's engine python (else the same interpreter) + the
    script's absolute path + the parsed arguments, quoted, so the engine's own pre-run scanner sees a plain program (it can't resolve `$GAPI`) and
    the shell runs exactly what was checked."""
    argv = google_read_argv(tool, args)
    if argv is None:
        return None
    eh = ENGINE_HOME or os.environ.get("HERMES_HOME", "")
    gapi = os.path.join(os.path.realpath(eh), GAPI_SUFFIX.lstrip("/"))
    # the box's engine python has the Google client libraries; the terminal's own `python` may not (5 Nov, live)
    py = _BOX_PY if os.path.isfile(_BOX_PY) and os.access(_BOX_PY, os.X_OK) else argv[0]
    return " ".join(shlex.quote(x) for x in [py, gapi] + argv[1:])


def _google_read_hint(tool: str, args: Any) -> str:
    command = args.get("command") if isinstance(args, dict) else None
    if tool != "terminal" or not isinstance(command, str) or "google_api" not in command:
        return ""
    eh = ENGINE_HOME or os.environ.get("HERMES_HOME", "")
    gapi = os.path.join(os.path.realpath(eh), GAPI_SUFFIX.lstrip("/")) if eh else "google_api.py"
    return (" To read Gmail or Calendar, run one google-workspace read command on its own (gmail search/get/labels or "
            "calendar list with their own options), with no pipe, redirect, variable or other command, e.g. "
            "python %s calendar list --start 2026-11-02T00:00:00Z --end 2026-11-09T00:00:00Z" % gapi)


def _trusted_data_words(strings: List[str]) -> set:
    """GUARDFIX (GPT r1/r2b, a 2 MB PDF): the operands after a release skill script in a plain command
    (python3 "<skill>/scripts/x.py" "<file>" ...): data that script reads, not code anything runs. Only that exact form."""
    out: set = set()
    for x in strings:
        w = _plain_words(x) if isinstance(x, str) else None
        while w and len(w) > 1 and _skill_env_ok(w[0]):
            w = w[1:]
        if w and len(w) > 1 and re.fullmatch(r"python3?|node", w[0]) and w[1].startswith("/") and \
                _trusted_skill_script(w[1]):
            out |= set(w[2:])
    return out


def _trusted_skill_script(path: str) -> bool:
    """A file of the release's skill library: in this engine home's skills folder (not a person's own skills), reached
    without a link at its last part, with one of the trusted hashes."""
    hp = _home_parts()
    if not hp or not TRUSTED_SKILL_SHA256:
        return False
    r = os.path.realpath(path)
    skills = "/" + "/".join(hp + ["skills"]) + "/"
    if not r.startswith(skills) or r.startswith(skills + SKILL_SAVE_CATEGORY + "/") or os.path.islink(path):
        return False
    return os.path.isfile(r) and os.path.getsize(r) <= 2_000_000 and _sha256(r) in TRUSTED_SKILL_SHA256


def _scripts_name_skills(wf: List[tuple], toks: List[str], bases: List[str], hp: List[str], depth: int, seen: set,
                         strict: tuple = ()) -> bool:
    """Every existing file the text names (patterns expanded as the shell would) outside the skills folders and the
    system's own programs, read as code: True when one names the skills folders (also as the word in pieces), or runs
    a file that does, to depth 8 (GPT save-4)."""
    if depth > 8:
        return True
    cands: List[str] = []
    for t, g, pt in wf:
        tt = os.path.expanduser(t)
        cands += [tt] if tt.startswith("/") else [os.path.join(b, tt) for b in bases]
        if pt:
            found = _expand(g, bases)
            if found is None or len(found) > 200:
                return True
            cands += found
    for t in toks:
        tt = os.path.expanduser(t)
        cands += [tt] if tt.startswith("/") else [os.path.join(b, tt) for b in bases]
    checked = 0
    for c in cands:
        try:
            st = os.stat(c)
        except (OSError, ValueError):
            continue
        r = os.path.realpath(c)
        if not os.path.isfile(r) or r in seen:
            continue
        try:
            with open(r, "rb") as fh:
                magic = fh.read(4)
        except OSError:
            return True
        if magic in _NATIVE_MAGIC and r.startswith(_SYSTEM_DIRS):
            continue                           # the system's own programs; any text file there is still read
        if _trusted_skill_script(r):
            continue                           # GUARDFIX: the release's own skill code
        if _binary_data(r) is None:
            return True                        # unreadable, or a zip python could run
        in_library = _skills_place(r, hp)
        seen.add(r)
        checked += 1
        if checked > 200 or st.st_size > 2_000_000:
            return True
        try:
            with open(r, "rb") as fh:
                body = fh.read().replace(b"\x00", b" ").decode("utf-8", "replace")
        except OSError:
            return True
        # relative names in it may start from its own folder too; a library script's own folder is in the skills
        # folder, so there only absolute names count (any relative word would look like a skills path)
        sb = bases if in_library else bases + [os.path.dirname(r)]
        iw = _words_all(body)
        it = _path_tokens(body)
        if in_library:
            iw = [w for w in iw if os.path.expanduser(w[0]).startswith("/")]
            it = [w for w in it if os.path.expanduser(w).startswith("/")]
        # a library script may say "skills" in its text, but may not name a skills path (GPT save-15); no file run
        # may name a skill draft (drafts are text, GPT save-16)
        code = depth > 0 or r.endswith(SCRIPT_SUFFIXES) or body.startswith("#!") or bool(st.st_mode & 0o111) \
            or c in strict
        squashed = _squash(body)
        if (code and not in_library and _says_skills(body)) or (in_library and "/skills/" in squashed) \
                or any(_skills_hits(w, sb, hp) for w, g, pt in iw) \
                or any(_skills_hits(w, sb, hp) for w in it) or _runs_a_draft([body], [os.path.dirname(r)]) \
                or SKILL_DRAFTS in _squash(body):
            return True
        if _scripts_name_skills(iw, it, sb, hp, depth + 1, seen):
            return True
    return False


def skill_text_problem(content: str, name: str) -> str:
    """Why the engine would not take this SKILL.md as a new skill named `name` ("" when it would): the engine's own
    checks for a new skill when importable, and the frontmatter's name must be the skill's name."""
    try:
        from tools.skill_manager_tool import _validate_frontmatter
        err = _validate_frontmatter(content, new_skill=True)
        if err:
            return err
    except ImportError:
        if not content.lstrip("\ufeff").startswith("---") or not re.search(r"\n---\s*\n", content[3:]):
            return "SKILL.md must start with a frontmatter block between --- lines."
    m = re.search(r"\n---\s*\n", content.lstrip("\ufeff")[3:])
    head = content.lstrip("\ufeff")[3:m.start() + 3] if m else ""
    got = re.search(r"(?m)^name:\s*['\"]?([^'\"\n]*?)['\"]?\s*$", head)
    if not got or got.group(1).strip() != name:
        return "The frontmatter's name must be %s, the skill's name." % name
    if not re.search(r"(?m)^description:\s*\S", head):
        return "The frontmatter needs a one-sentence description of when to use the skill."
    return ""


# guard markers that are also ordinary words in a skill's or a task's text (a person approves a skill's exact text)
_GENERIC_MARKERS = {"sqlite", "config.yaml", "qosha/", "/qosha", "osascript", "system events", "crontab"}


def _skill_save(args: Any) -> Verdict:
    """skill_manage: only "create" of a new skill whose exact text is saved in Your files as skill-drafts/<name>.md is
    held (kind skill.save); every other action, or a create without that draft, is refused."""
    if not isinstance(args, dict) or args.get("action") != "create":
        return Verdict(DENY, SKILLS_REFUSED)
    name, content = args.get("name"), args.get("content")
    if not isinstance(name, str) or not SKILL_NAME.match(name):
        return Verdict(DENY, "A new skill's name must be lower-case words joined by hyphens (up to 64 characters). "
                             + SKILLS_REFUSED)
    if not isinstance(content, str) or not content.strip() or len(content) > SKILL_MAX_CHARS:
        return Verdict(DENY, "The skill's text is empty or too long (over %d characters)." % SKILL_MAX_CHARS)
    if OBFUSCATION.search(content) or PY_STARTUP.search(content):
        return Verdict(DENY, "A skill's text may not hold encoded code or program start-up settings.")
    low, sq = content.lower(), _squash(content)    # GUARDFIX (audit row 20): "read a SQLite export" is not Qosha's records
    hit = next((m for m in GUARD_MARKERS if m not in _GENERIC_MARKERS and (m in low or _squash(m) in sq)), None)
    if hit:
        return Verdict(DENY, "A skill's text may not use Qosha's own settings, approval records or sign-in (%r)." % hit)
    why = skill_text_problem(content, name)
    if why:
        return Verdict(DENY, "This skill can't be added as written: %s Fix the draft, show it again, then ask again." % why)
    root = _files_root()
    if not root:
        return Verdict(DENY, "Qosha could not find Your files, so the draft could not be checked.")
    rel = "%s/%s.md" % (SKILL_DRAFTS, name)
    draft = os.path.join(root, rel)
    try:
        if os.path.islink(draft) or os.path.realpath(draft) != draft or not os.path.isfile(draft):
            raise OSError("missing")
        with open(draft, "rb") as fh:
            shown = fh.read(SKILL_MAX_CHARS * 4 + 1)
    except OSError:
        return Verdict(DENY, "Save the exact text in Your files as %s first and open it for the person. " % rel
                             + SKILLS_REFUSED)
    if shown != content.encode("utf-8"):
        return Verdict(DENY, "The text differs from the draft %s in Your files. Show the person the exact text first "
                             "(save it there and open it), then ask again with exactly that text." % rel)
    return Verdict(HOLD, kind="skill.save", payload={
        "name": name, "category": SKILL_SAVE_CATEGORY, "draft": rel, "content": content,
        "content_sha256": hashlib.sha256(content.encode("utf-8")).hexdigest()})


def _drafts_root() -> str:
    root = _files_root()
    return os.path.join(root, SKILL_DRAFTS) if root else ""


def _is_skill_draft(tool: str, args: Any) -> bool:
    """write_file, or a patch replace, of one Markdown file directly in Your files/skill-drafts/ (not a link); a
    relative path counts only when every recorded working folder of the session puts it there (GPT save-13)."""
    d = _drafts_root()
    if tool not in ("write_file", "patch") or not d or not isinstance(args, dict) or not isinstance(args.get("path"), str):
        return False
    if tool == "patch" and (args.get("mode") not in (None, "replace") or "patch" in args):
        return False
    p = os.path.expanduser(args["path"].strip())
    cands = [p] if os.path.isabs(p) else [os.path.join(b, p) for b in SESSION_CWDS if b]
    return bool(cands) and all(os.path.dirname(os.path.realpath(c)) == d and c.endswith(".md") and not os.path.islink(c)
                               and SKILL_NAME.match(os.path.basename(c)[:-3]) is not None for c in cands)


# GUARDFIX (council D43, audit K5): a plain document the assistant saves in Your files (a reply draft, notes, a report)
# may say "gmail", "sqlite" or "base64": it is text, not code. A document is never run by the guard's leave: any file a
# terminal command runs (an interpreter's or shell's operand, whatever its name) is checked as code when it runs.
DOC_SUFFIXES = (".md", ".markdown", ".txt", ".csv", ".tsv")


def _is_plain_document(tool: str, args: Any) -> bool:
    """write_file of one document (DOC_SUFFIXES) inside Your files, not through a link; a relative path counts only when
    every recorded working folder of the session puts it there."""
    root = _files_root()
    if tool != "write_file" or not root or not isinstance(args, dict) or not isinstance(args.get("path"), str):
        return False
    if set(args) - {"path", "content"}:
        return False
    p = os.path.expanduser(args["path"].strip())
    cands = [p] if os.path.isabs(p) else [os.path.join(b, p) for b in SESSION_CWDS if b]
    return bool(cands) and all(os.path.realpath(c).startswith(root + os.sep) and c.lower().endswith(DOC_SUFFIXES) and
                               os.path.realpath(c).lower().endswith(DOC_SUFFIXES) and not os.path.islink(c) for c in cands)


def _binary_data(path: str) -> Optional[bool]:
    """True: a binary data file (a NUL in its first 8 KB, not a native program, not a zip holding __main__.py, which
    python runs); False: text or a native program; None: unreadable or a runnable zip."""
    try:
        with open(path, "rb") as fh:
            head = fh.read(8192)
    except OSError:
        return None
    if head[:4] in _NATIVE_MAGIC or b"\x00" not in head:
        return False
    if head[:2] == b"PK":
        import zipfile
        try:
            with zipfile.ZipFile(path) as z:
                if any(n.rsplit("/", 1)[-1].lower() in ("__main__.py", "__main__.pyc") for n in z.namelist()):
                    return None
        except Exception:
            return None
    return True


# GPT r1 (`python3 -W ignore x.txt` runs x.txt): per runner family, (options taking the next word, options after which
# no script file follows, options taking nothing). Any other option makes the script's place unsure.
_RUNNER_OPTS = (
    (re.compile(r"^python[\d.]*$"), {"-W", "-X", "--check-hash-based-pycs"}, {"-c", "-m"},
     {"-u", "-B", "-I", "-E", "-s", "-S", "-O", "-OO", "-q", "-b", "-bb", "-d", "-P", "-R", "-v", "-i", "-x"}),
    (re.compile(r"^(node|nodejs|deno|bun)$"), {"-r", "--require", "--import", "--loader", "--experimental-loader", "-C",
                                               "--conditions", "--input-type", "--title"}, {"-e", "-p", "--eval", "--print"},
     {"--no-warnings", "--trace-warnings", "--enable-source-maps", "--no-deprecation", "run"}),
    (re.compile(r"^(sh|bash|zsh|dash|ksh|mksh|fish|csh|tcsh)$"), {"-o", "-O", "+O", "+o", "--rcfile", "--init-file"},
     {"-c", "-s"}, {"-e", "-u", "-x", "-v", "-n", "-f", "-i", "-l", "--norc", "--noprofile", "--login", "--posix"}),
    (re.compile(r"^perl[\d.]*$"), set(), {"-e", "-E"}, {"-w", "-T", "-t", "-n", "-p", "-l", "-a", "-W", "-X"}),
    (re.compile(r"^ruby$"), {"-I", "-r", "-C", "-E", "-x"}, {"-e"}, {"-w", "-v", "-d", "-n", "-p", "-l", "-a"}),
)


# commands that only read, list or copy the files they are given (never run them as instructions)
_PURE_READERS = {"cat", "head", "tail", "wc", "grep", "egrep", "fgrep", "rg", "ls", "file", "stat", "diff", "cmp",
                 "shasum", "md5", "md5sum", "sha1sum", "sha256sum", "sort", "uniq", "cut", "jq", "zip", "unzip", "tar",
                 "cp", "mv", "rm", "du", "find", "touch", "mkdir", "echo", "printf", "date", "pwd", "basename",
                 "dirname", "realpath", "tr", "nl", "column", "fold", "rev", "tee", "cd", "pushd", "popd", "rmdir",
                 "ln", "chmod", "true", "false", "test", "[", "seq", "expr", "sleep"}
# build and task runners read these files from their folder as instructions (Opus r1 B1: npm test runs package.json)
_PROJECT_RUNNERS = {"npm", "npx", "yarn", "pnpm", "bun", "deno", "make", "gmake", "just", "task", "rake", "composer",
                    "pip", "pip3", "uv", "poetry", "pdm", "hatch", "tox", "nox", "at", "batch", "cargo", "mvn", "gradle",
                    "corepack", "node-gyp", "meson", "ninja", "cmake", "scons", "invoke", "fab", "doit"}
_PROJECT_FILES = ("package.json", "deno.json", "deno.jsonc", "Makefile", "makefile", "GNUmakefile", "justfile",
                  "Justfile", "Taskfile.yml", "Taskfile.yaml", "Rakefile", "composer.json", "pyproject.toml", "setup.py",
                  "setup.cfg", "tox.ini", "noxfile.py", "requirements.txt", "Cargo.toml", "build.rs", ".npmrc",
                  "pom.xml", "build.gradle", "CMakeLists.txt", "meson.build", "build.ninja", "tasks.py", "fabfile.py",
                  "dodo.py", "bunfig.toml", ".yarnrc", ".yarnrc.yml")


def _run_operands(command: str, bases: List[str]) -> List[str]:
    """Existing files a terminal command runs: the operand of an interpreter or shell (after its options), a command
    word naming a file, every existing text file named by a command that is not a pure reader (make -f x.txt, at -f
    x.txt, python3 -c "...open('x.txt')..."), and a build runner's own instruction files; relative ones from every base."""
    out: List[str] = []
    for c in _split_commands(command) or []:
        progs = {w.rsplit("/", 1)[-1] for w in c if not _ASSIGN.match(w)}
        if progs & _PROJECT_RUNNERS:
            for b in bases:
                for name in _PROJECT_FILES:
                    f = os.path.join(b, name)
                    if os.path.isfile(f) and f not in out:
                        out.append(f)
        lead = next((w for w in c if not _ASSIGN.match(w)), "")
        # a release skill script run with its arguments: it reads its data files, it does not run them (checked: the
        # runner's script operand below must be that script)
        trusted_run = any(_trusted_skill_script(os.path.expanduser(w) if w.startswith(("/", "~")) else os.path.join(b, w))
                          for w in c[1:2] for b in (bases or [""]))
        if lead.rsplit("/", 1)[-1] not in _PURE_READERS and not trusted_run:
            for t in [w for w in c[1:]] + _path_tokens(" ".join(c)):
                t = os.path.expanduser(t)
                for f in ([t] if t.startswith("/") else [os.path.join(b, t) for b in bases]):
                    if os.path.isfile(f) and f not in out and not _trusted_skill_script(f) and \
                            (_binary_data(f) is False or os.path.getsize(f) <= 2_000_000):   # large media: data
                        try:
                            with open(f, "rb") as fh:
                                if fh.read(4) in _NATIVE_MAGIC:
                                    continue
                        except OSError:
                            continue
                        out.append(f)
        i = 0
        while i < len(c) and _ASSIGN.match(c[i]):
            i += 1
        if i >= len(c):
            continue
        cand = []
        if "/" in c[i]:
            cand.append(c[i])
        # the runner may come after wrappers (env python3 x, nohup bash x, timeout 5 sh x): every runner word counts
        for k in range(i, len(c)):
            name = c[k].rsplit("/", 1)[-1]
            if not (_RUNNERS.match(name) or name in _SHELLS):
                continue
            fam = next((o for o in _RUNNER_OPTS if o[0].match(name)), None)
            value, noscript, flags = fam[1:] if fam else (set(), set(), set())
            j, sure = k + 1, fam is not None
            while j < len(c) and (c[j].startswith("-") or c[j].startswith("+")):
                if c[j] in noscript:
                    j = len(c); break
                if c[j] not in value and c[j] not in flags and not (c[j].startswith("--") and "=" in c[j]):
                    sure = False               # an option this table does not know may take the next word
                j += 2 if c[j] in value else 1
            if j < len(c):
                cand.append(c[j])
            if not sure:                       # then every existing text file the runner is given counts as code
                cand += [w for w in c[k + 1:] if not w.startswith("-")]
        for t in cand:
            t = os.path.expanduser(t)
            for f in ([t] if t.startswith("/") else [os.path.join(b, t) for b in bases]):
                if os.path.isfile(f) and f not in out:
                    try:
                        with open(f, "rb") as fh:
                            native = fh.read(4) in _NATIVE_MAGIC   # a program, not text (checked as before)
                    except OSError:
                        native = False
                    if not native:             # (a NUL inside does not make a script data: R-cronpolicy5)
                        out.append(f)
    return out


# GUARDFIX (Opus r1 B5, council D44): in the cloud box the person's home folder IS the engine home, so the box's
# sign-ins sit beside the assistant's work with no barrier but this guard, and code can build any path while it runs
# (python -c "...'nosj.nekot'[::-1]..."): text checks can't see that. There, until an OS barrier separates them, the
# assistant runs no code of its own: only the release's skill scripts (by their full path, literal arguments), the
# Google reads, and file and text commands that never run what they are given. On the Mac the lab's sandbox and the
# connector hold the Google sign-in, as before.
BOX_CODE_REFUSED = ("In Qosha's cloud box, code Qosha writes itself doesn't run yet: the box's sign-ins share its user "
                    "until the box gets its own code sandbox (rule G2: secrets are never shown). What works now: the "
                    "skills' own scripts by full path with literal arguments (python3 \"<skill folder>/scripts/<script>.py\" "
                    "\"<file>\" ...), plain commands (ls, cat, grep, rg, wc, sort, cp, mv, mkdir, zip, unzip) and the Google reads.")
# GUARDFIX2 (council D45, split -> conservative): on the Mac lab any same-user process can read other processes'
# start-up settings (sysctl KERN_PROCARGS2, measured; no sandbox rule blocks it), so code the assistant writes itself
# is refused there too, with the same allowed set as the box, until Qosha runs as its own macOS user.
MAC_CODE_REFUSAL = True                        # (unit tests of the layers below it switch it off)
MAC_CODE_REFUSED = ("Qosha's code sandbox isn't running on this Mac right now, so this code didn't run (on this Mac code "
                    "Qosha writes runs there, away from other programs' sign-ins: rule G2). Skills, file and text commands "
                    "and Google reads still work. The fix: Qosha's update turns the code sandbox on (it needs colima, "
                    "which this Mac has).")
# Opus r2: a list of allowed options per program, not a list of bad ones (glued values, file lists and walkers that
# follow everything were the gaps). flags: options taking nothing; values: options taking the next word (judged as a
# path like every word); prefixes: long options with =value; num: "-<digits>" allowed (head -20).
_BOX_GRAMMAR = {
    "ls": ("-l -a -la -al -lh -lah -alh -1 -R -t -S -r -h -d -lt -ltr -lS -F -A", "", "", False),
    "cat": ("-n -b -s", "", "", False),
    "head": ("-q", "-n -c", "", True), "tail": ("-q", "-n -c", "", True),
    "wc": ("-l -w -c -m -lw -lc", "", "", False),
    "grep": ("-i -n -c -l -L -v -w -r -E -F -o -h -H -s -q -x -in -rn -ri -rin -ril -il -iw -nH -rl -ic -rc", "-e -A -B -C -m",
             "--include= --exclude= --exclude-dir= --color=", False),
    "rg": ("-i -n -c -l -w -F -S -s -x -v -o -N --files --hidden --no-ignore --count --files-with-matches --json -uu -u",
           "-e -g -t -T -A -B -C -m --type --glob --max-count", "--glob= --type= --max-count= --color=", False),
    "sort": ("-n -r -u -f -h -nr -rn -k1 -b -V", "-k -t", "--key= --field-separator=", False),
    "uniq": ("-c -d -u -i", "", "", False), "cut": ("", "-d -f -c", "", False), "tr": ("-d -s -c", "", "", False),
    "date": ("-u -R -I", "", "", False), "pwd": ("", "", "", False), "echo": ("-n -e -E", "", "", False),
    "printf": ("", "", "", False), "mkdir": ("-p -v", "", "", False), "touch": ("", "", "", False),
    "cp": ("-r -R -p -n -v -a -i -f -rp -rv -pr", "", "", False), "mv": ("-n -v -f -i", "", "", False),
    "rm": ("-r -f -rf -fr -v -i -R", "", "", False), "rmdir": ("-p", "", "", False), "ln": ("-s -f -sf -fs", "", "", False),
    "diff": ("-u -q -i -w -b -B -y", "", "", False), "cmp": ("-s", "", "", False), "file": ("-b -i --mime-type", "", "", False),
    "stat": ("", "", "", False), "du": ("-s -h -sh -hs -a -c", "-d", "--max-depth=", False),
    "find": ("-print -type -name -iname -maxdepth -mindepth -size -mtime -mmin -empty -not -o -a ( ) ! f d l -ls", "",
             "", False),
    "zip": ("-r -q -j -9 -0 -v -y", "", "", False), "unzip": ("-l -q -o -n -p -v -t", "-d", "", False),
    "tar": ("-t -x -c -z -j -J -v -f tf tzf tvf tvzf xf xzf xvf xvzf xjf xJf cf czf cvf cvzf cjf cJf -tf -tzf -tvf -xf -xzf "
            "-xvf -xvzf -cf -czf -cvf -cvzf -xjf -cjf -xJf -cJf --list --extract --create --gzip --verbose", "-f",
            "", False),   # GPT r9b: no -C/--directory (it moves where tar resolves the names after it); use workdir
    "jq": ("-r -c -s -n -S -e -j -M -C", "--arg --argjson --indent", "", False),
    "basename": ("", "", "", False), "dirname": ("", "", "", False), "realpath": ("", "", "", False),
    "sha256sum": ("", "", "", False), "sha1sum": ("", "", "", False), "md5sum": ("", "", "", False),
    "shasum": ("", "-a", "", False), "column": ("-t", "-s", "", False), "nl": ("", "", "", False),
    "fold": ("-s", "-w", "", False), "rev": ("", "", "", False), "comm": ("-1 -2 -3 -12 -13 -23", "", "", False),
    "paste": ("-s", "-d", "", False), "tee": ("-a", "", "", False), "true": ("", "", "", False),
    "false": ("", "", "", False), "test": ("-e -f -d -s -z -n", "", "", False), "[": ("-e -f -d -s -z -n ]", "", "", False),
    "seq": ("", "", "", False), "expr": ("", "", "", False), "sleep": ("", "", "", False),
    "chmod": ("+x -x u+x a+r -R", "", "", False),
    "zcat": ("", "", "", False), "gzip": ("-k -d -c -9", "", "", False), "gunzip": ("-k -c", "", "", False),
    "pdftotext": ("-layout -raw -nopgbrk", "-f -l", "", False), "pdfinfo": ("", "", "", False),
    "cal": ("", "", "", False), "whoami": ("", "", "", False), "uname": ("-a -s -m -r", "", "", False),
    "df": ("-h", "", "", False), "nproc": ("", "", "", False), "uptime": ("", "", "", False),
}


def _box_words_ok(name: str, words: List[str]) -> bool:
    """Every option of this program call is one the grammar allows (values as separate words)."""
    flags, values, prefixes, num = (set(x.split()) if isinstance(x, str) else x for x in _BOX_GRAMMAR[name])
    i = 1
    while i < len(words):
        w = words[i]
        if w.startswith("-") and len(w) > 1 and not (name in ("find", "test", "[") and w in flags):
            if w == "--":
                return False                   # Opus r3: "--" moves options past this check (find -- . -execdir)
            if w in flags or (num and re.fullmatch(r"-\d+", w)):
                i += 1; continue
            if w in values:
                i += 2; continue
            if any(w.startswith(pf) for pf in prefixes):
                i += 1; continue
            return False
        if name == "find" and w.startswith("-") and w not in flags:
            return False
        if name == "tar" and i == 1 and w not in flags and not w.startswith("-"):
            return False                       # tar's first word is its mode
        i += 1
    return True


# settings a release skill documents in front of its own command (grounded-citations: the ledger in Your files)
_SKILL_ENV = {"HERMES_CITATION_LEDGER"}


def _skill_env_ok(word: str) -> bool:
    """NAME=<path> for a _SKILL_ENV setting whose value is a full path inside Your files (Opus rerun: a ledger in the
    skills folder or /tmp would let the skill write there)."""
    name, _, val = word.partition("=")
    if name not in _SKILL_ENV or not val:
        return False
    root = _files_root()
    full = os.path.realpath(os.path.expanduser(val))
    return bool(root) and val.startswith(("/", "~/")) and full.startswith(root + os.sep)


def _shared_home() -> bool:
    """The cloud box layout: QOSHA_BOX, or the person's home folder inside the engine home."""
    hp = _home_parts()
    home = [x for x in os.path.realpath(os.path.expanduser("~")).split("/") if x]
    return os.environ.get("QOSHA_BOX") == "1" or bool(hp and home[:len(hp)] == hp)


def _box_code_refusal(tool: str, args: Any) -> bool:
    """True when the call would run code the assistant wrote (BOX_CODE_REFUSED; GUARDFIX2: MAC_CODE_REFUSED on the Mac)."""
    if not MAC_CODE_REFUSAL and not _shared_home():
        return False
    if tool in ("execute_code", "browser_exec", "browser_cdp"):
        return True
    if tool == "process":
        if isinstance(args, dict) and args.get("action") in ("list", "poll", "log", "wait", "kill"):
            return False
    elif tool != "terminal":
        return False
    command = args.get("command") if isinstance(args, dict) else None
    if not isinstance(command, str):
        return tool == "process"
    if _google_read_call("terminal", {"command": command}) or _google_script_only(command):
        return False                           # the Google skill's own commands: classified below (reads, held sends)
    box = _shared_home()
    scan = command if box else re.sub(r"\$\{?GAPI\}?|\$\{HERMES_HOME(:-\$HOME/\.hermes)?\}|\$HERMES_HOME", "", command)
    if re.search(r"\$\(|`|<\(|>\(|<<|\$\{?[A-Za-z_]", scan):
        return True                            # substitutions, here-documents, variables
    cmds = _split_commands(re.sub(r"(?<![\w&])[12]?>&[12](?![\w])", " ", command))   # 2>&1, >&2: stream joins
    if not cmds:
        return True
    for c in cmds:
        if c and c[0] in ("<", ">", ">>", "2>", "&>"):
            return True
        if not box and (_gapi_index(c) is not None or all(t.startswith("GAPI=") and _definition_ok(t) for t in c)):
            continue                           # the Mac: the Google skill's own command (_classify_shell judges it)
        while c and _skill_env_ok(c[0]) and len(c) > 1:
            c = c[1:]                          # a setting a skill documents, its value inside Your files
        if not c or _ASSIGN.match(c[0]):
            return True                        # environment settings (PYTHONPATH=..., NODE_OPTIONS=...)
        words = [w for w in c if w not in ("<", ">", ">>")]
        prog, name = words[0], words[0].rsplit("/", 1)[-1]
        # Opus GUARDFIX2 review: exactly /bin/<name> or /usr/bin/<name> (a "/usr/bin/../../<Files>/cat" is the assistant's file)
        if name in _BOX_GRAMMAR and ("/" not in prog or prog in ("/bin/" + name, "/usr/bin/" + name)):
            if not _box_words_ok(name, words):
                return True                    # an option this program is not allowed with in the box
            continue
        # (cd, pushd, popd are not in the box's grammar, however they are spelled: Opus r6 B1-B3; use workdir instead)
        if name == "cd" and prog == "cd" and not _shared_home():
            continue                           # the Mac: cd to a folder (its targets are judged as bases elsewhere)
        if re.fullmatch(r"python3?|node", name) and "/" not in prog and len(words) > 1:
            script = os.path.expanduser(words[1])
            if script.startswith("/") and _trusted_skill_script(script):
                continue                       # a release skill script by its full path; its arguments are checked
        return True
    return False


# GUARDFIX2 (verifier finding 1 and 6, G2 cloud): the box grammar said WHICH options a program may take but not WHERE
# it may read or write, so `grep -r x /run`, `rg --hidden x /run`, `cp -r /run Files/r` and `cat /opt/q*/c*/...` read
# the mounted model key, the Google client and the guard's own code. In the box every path a file or text command
# names (operands, redirect targets, option values that are paths, and the folder it runs in when it walks or unpacks
# with no path) must resolve, after braces, ~, patterns and links, inside Your files (read and write) or the skills
# folder (read only). An allow-list, not more deny words: /run, /var/run, /proc, /sys, /etc, /tmp, /home, / and the
# engine home are simply outside it. Until an OS barrier separates the box's sign-ins from the assistant's commands.
BOX_OUTSIDE_REFUSED = ("In Qosha's cloud box, commands and file tools work only inside Your files ({files}), and can "
                       "read the skills folder. This call names a place outside them ({word}).")
_BOX_NO_PATHS = {"echo", "printf", "date", "pwd", "true", "false", "seq", "expr", "sleep", "cal", "whoami", "uname",
                 "nproc", "uptime", "basename", "dirname", "tr"}
_BOX_READERS = {"ls", "cat", "head", "tail", "wc", "grep", "rg", "sort", "cut", "diff", "cmp", "file", "stat", "du",
                "find", "zcat", "pdfinfo", "realpath", "sha256sum", "sha1sum", "md5sum", "shasum", "column", "nl",
                "fold", "rev", "comm", "paste", "jq", "test", "[", "df"}
_BOX_WALKERS = {"rg", "find", "du", "tar", "zip"}       # (and grep, ls, cp, diff, chmod, rm with a recursive option)


def _box_roots() -> tuple:
    """(Your files, the skills folder), each as written and with links followed."""
    eh = os.path.expanduser(ENGINE_HOME or os.environ.get("HERMES_HOME", ""))
    if not eh:
        return (), ()
    f, s = os.path.join(eh, "files"), os.path.join(eh, "skills")
    return ({os.path.normpath(f), os.path.realpath(f)}, {os.path.normpath(s), os.path.realpath(s)})


def _box_under(path: str, roots) -> bool:
    return any(path == r or path.startswith(r.rstrip("/") + "/") for r in roots)


def _box_superset(pattern: str) -> str:
    """A pattern Python's glob matches at least everything bash's would: every bracket expression ([[:lower:]], [^a],
    [!.]) becomes ? (GPT r2: Python has no character classes)."""
    return re.sub(r"\[[!^]?\]?(?:\[:[a-z]+:\]|[^\]])*\]", "?", pattern)


def _box_word_inside(word: str, bases: List[str], write: bool, redirect: bool = False) -> bool:
    """Every path this word can name (braces, ~, patterns, from every base) is inside Your files, or (reading) the skills
    folder, as the system resolves it (links, then ".."): the part before a pattern and every match it has now."""
    import glob as _glob
    files, skills = _box_roots()
    if not files:
        return False
    roots = files if write else files | skills
    if word == "-" or word == "/dev/null" and (redirect or not write):
        return True                            # standard input / output, the empty file (GPT r2: no chmod of it)
    if "\n" in word or "\x00" in word:
        return False
    alts = _brace_expand(word.replace("{", _BO).replace(",", _BS).replace("}", _BC), limit=64) \
        if "{" in word else [word]
    if len(alts) >= 64:
        return False
    for alt in alts:
        alt = os.path.expanduser(alt.replace(_EXP, "*"))   # ~ and ~user (/root, /home/...) are outside
        if alt.startswith("~") or _EXP in alt:
            return False
        for c in ([alt] if alt.startswith("/") else [os.path.join(b, alt) for b in bases]):
            parts = c.split("/")
            k = next((i for i, x in enumerate(parts) if re.search(r"[*?\[]", x)), len(parts))
            for x in parts[k:]:
                # a pattern part that can stand for ".." or "." (.*, .?, .[.], [.]*) climbs (bash 3.2 and dotglob)
                if re.search(r"[*?\[]", x) and not x.startswith(("*", "?")) and \
                        (fnmatch.fnmatchcase("..", _box_superset(x)) or fnmatch.fnmatchcase(".", _box_superset(x))):
                    return False
            head = "/".join(parts[:k]) or "/"
            if k < len(parts):
                head = os.path.dirname(head + "/x")   # the folder the pattern starts in
            if not _box_under(os.path.realpath(head), roots):
                return False                   # (as the system resolves it: links, then "..")
            if k == len(parts):
                try:
                    if os.path.isfile(c) and os.stat(c).st_nlink > 1:
                        return False           # GPT r4: a hard link may be a file outside them under another name
                except OSError:
                    pass
                continue
            if os.path.lexists(c) and not _box_under(os.path.realpath(c), roots):
                return False                   # GPT r3: a quoted name that only looks like a pattern ('a[bc]')
            try:
                found = _glob.glob(_box_superset(c))
            except (OSError, ValueError, re.error):
                return False
            if len(found) > 5000:
                return False
            for m in found:
                if not _box_under(os.path.realpath(m), roots):
                    return False
                try:
                    if os.path.isfile(m) and os.stat(m).st_nlink > 1:
                        return False           # GPT r5: a hard link reached by a pattern
                except OSError:
                    pass
    return True


def _box_link_out(roots_walked: List[str]) -> Optional[str]:
    """A link under these folders that leads outside Your files and the skills folder (a walker that follows links,
    zip -r, diff -r, would read through it), or a folder too large to check. Links to folders inside them are walked
    too (GPT r2: os.walk does not enter them)."""
    files, skills = _box_roots()
    seen, todo, done = 0, [r for r in roots_walked if os.path.isdir(r)], set()
    while todo:
        r = todo.pop()
        if os.path.realpath(r) in done:
            continue
        done.add(os.path.realpath(r))
        for dp, dns, fns in os.walk(r, followlinks=False):
            for n in dns + fns:
                seen += 1
                if seen > 50000:
                    return r
                pth = os.path.join(dp, n)
                if os.path.islink(pth):
                    real = os.path.realpath(pth)
                    if not _box_under(real, files | skills):
                        return pth
                    if os.path.isdir(real):
                        todo.append(real)
                    elif os.path.isfile(real) and os.stat(real).st_nlink > 1:
                        return pth             # GPT r5: a link to a hard-linked file
                else:
                    try:
                        st = os.lstat(pth)
                    except OSError:
                        continue
                    if st.st_nlink > 1 and not os.path.isdir(pth):
                        return pth             # GPT r4: a hard link may be a file outside them under another name
    return None


def _box_operands(name: str, words: List[str]) -> Optional[tuple]:
    """(reads, writes, cwd_use, walks) for one program call of the box grammar: the words it takes as paths to read
    or to write, whether it reads ("r") or writes ("w") its working folder when no path is given, and whether it walks
    folders. None: can't tell (refused)."""
    flags, values, prefixes, num = (set(x.split()) if isinstance(x, str) else x for x in _BOX_GRAMMAR[name])
    if name in _BOX_NO_PATHS:
        return [], [], "", False
    opts, vals, ops, i = [], {}, [], 1
    if name == "find":                         # find <paths...> <expression>: only the leading words are paths
        while i < len(words) and not (words[i].startswith("-") or words[i] in ("(", ")", "!")):
            ops.append(words[i]); i += 1
        return ops, [], ("r" if not ops else ""), True
    while i < len(words):
        w = words[i]
        if name == "jq" and w in ("--arg", "--argjson"):
            i += 3; continue                   # --arg NAME VALUE
        if w.startswith("-") and len(w) > 1 and w not in ("-",):
            if w in values:
                vals.setdefault(w, []).append(words[i + 1] if i + 1 < len(words) else "")
                opts.append(w); i += 2; continue
            opts.append(w); i += 1; continue
        if name == "tar" and i == 1:
            opts.append("-" + w); i += 1; continue   # tar's first word is its mode (cf, xzf, ...)
        ops.append(w); i += 1
    letters = "".join(o.lstrip("-") for o in opts if not o.startswith("--"))
    rec = any(o in ("--recursive",) for o in opts) or bool(re.search(r"[rR]", letters))
    if name == "grep":
        if "-e" not in vals and ops:
            ops = ops[1:]                      # the pattern
        return ops, [], ("r" if rec and not ops else ""), rec
    if name == "rg":
        if "--files" not in opts and "-e" not in vals and ops:
            ops = ops[1:]
        return ops, [], ("r" if not ops else ""), True
    if name == "jq":
        # GPT r3: a filter can load modules by path (include/import) or read the environment (env)
        if ops and re.search(r"\b(include|import|env|input_filename|modulemeta|get_search_list)\b|\$ENV|\$__", ops[0]):
            return None
        return ops[1:], [], "", False          # the filter, then files
    if name in ("test", "["):
        return [words[j + 1] for j in range(1, len(words) - 1) if words[j] in ("-e", "-f", "-d", "-s")], [], "", False
    if name == "ls":
        return ops, [], ("r" if not ops else ""), "R" in letters
    if name == "du":
        return ops, [], ("r" if not ops else ""), True
    if name in _BOX_READERS:
        return ops, [], "", rec and name == "diff"
    if name == "chmod":
        if ops and re.fullmatch(r"[ugoa]*[-+=][rwxXst]*|[0-7]{3,4}", ops[0]):
            ops = ops[1:]
        return [], ops, "", rec
    if name == "rmdir" and "p" in letters:
        return None                            # GPT r3: -p removes the folders above it too (Your files itself)
    if name in ("mkdir", "touch", "rm", "rmdir", "mv", "tee"):
        return [], ops, "", rec and name == "rm"
    if name == "cp":
        return ops[:-1], ops[-1:], "", rec or "a" in letters
    if name == "ln":
        if "s" not in letters:
            return [], ops, ("w" if len(ops) < 2 else ""), False   # a hard link writes through to its target
        return None if len(ops) > 2 else (ops[:1], ops[1:], ("w" if len(ops) < 2 else ""), False)
    if name == "uniq":
        return ops[:1], ops[1:2], "", False
    if name in ("gzip", "gunzip"):
        return (ops, [], "", False) if "c" in letters else ([], ops, "", False)
    if name == "pdftotext":
        return (ops[:1], ops[1:2], "", False) if len(ops) >= 2 else ([], ops, "", False)
    if name == "zip":
        return ops[1:], ops[:1], "", rec
    if name == "unzip":
        listing = bool(re.search(r"[ltpv]", letters))
        return ops[:1], ([] if listing else vals.get("-d", [])), ("" if listing or "-d" in vals else "w"), False
    if name == "tar":
        # GPT r3: the long forms are whole words ("--extract" holds a "c")
        create = "c" in letters or "--create" in opts
        extract = "x" in letters or "--extract" in opts
        if create == extract and (create or not ("t" in letters or "--list" in opts)):
            return None                        # no mode, or two: can't tell
        archive = vals.get("-f", [])
        if not archive and "f" in letters and ops:
            archive, ops = ops[:1], ops[1:]
        if create:
            return ops, archive, ("" if ops else "r"), True
        if extract:
            return archive, ops, "w", False   # it unpacks into its working folder
        return archive, [], "", False
    return None


def _box_outside(tool: str, args: Any) -> Optional[str]:
    """In the cloud box: the first word of this call that names a place outside Your files (or, read only, the skills
    folder), or None. Programs outside the box grammar are BOX_CODE_REFUSED's business (checked before this)."""
    if not isinstance(args, dict):
        return None
    files, skills = _box_roots()
    if not files:
        return "the engine home"
    if tool in ("read_file", "search_files", "write_file", "patch"):
        paths = []
        for k in _MCP_PATH_KEYS + ("file_path", "filename", "file_glob_root"):
            val = args.get(k)
            for x in (val if isinstance(val, list) else [val]):
                if isinstance(x, str) and x:
                    paths.append(x)
        for x in _strings(args):
            paths += _patch_paths(x) or []
        if tool == "search_files":
            paths = [x for q in paths for x in _search_parts(q)] or ["."]   # GPT review r3: ". ~" is two roots
        bases = _bases([], [], False)
        for p in paths:
            if not _box_word_inside(p, bases, tool in ("write_file", "patch")):
                return p
        return None
    if tool != "terminal":
        return None
    command = args.get("command")
    if not isinstance(command, str) or _google_read_call("terminal", {"command": command}) or \
            _google_script_only(command):
        return None                            # the Google skill's own commands: classified elsewhere
    wd = args.get("workdir")
    workdirs = [wd] if isinstance(wd, str) and wd else []
    bases = _bases(workdirs, [])
    for b in bases:
        if not _box_under(os.path.realpath(b), files | skills):
            return b                           # it would run in a folder outside them
    # GPT r2: words as bash makes them (quotes, escapes, line continuations, fd numbers before redirects), not shlex's
    for m in re.finditer(r"[<>]", command):
        # GPT r3/r4: _shell_words takes any digits glued to < or > for a descriptor ("2"<, \2<, 2""2<); bash only bare
        # digits that start a word. Anything else glued to a redirect is refused here.
        i = j = m.start()
        while j > 0 and command[j - 1] in "0123456789":
            j -= 1
        prev = command[j - 1] if j > 0 else " "
        if (j < i and prev not in " \t\n;&|(") or (j == i and prev in "\\\"'"):
            return "a quoted or joined word right before < or >"
    words = _shell_words(command)
    cmd: List[tuple] = []
    cmds = [cmd]
    for k, (pat, raw, _txt) in enumerate(words):
        if pat is None:
            if raw == "|" and k and words[k - 1][0] == _REDIR_OUT:
                continue                       # >| file
            cmd = []; cmds.append(cmd); continue
        if pat in (_PSUB, _REDIR_DOC, _HEREDOC, _UNSURE) or _EXP in pat:
            return raw                         # substitutions, here-documents, $'..', $x: not checked, not run
        cmd.append(pat)
    for c in cmds:
        if c:
            hit = _box_command_outside(c, bases, files, skills)
            if hit:
                return hit
    return None


def _box_globbed(words: List[str], bases: List[str]) -> List[str]:
    """The folders and files these words name now (patterns expanded, a superset of bash's), for the link walk."""
    import glob as _glob
    out = []
    for x in words:
        for b in bases:
            p = os.path.join(b, os.path.expanduser(x))
            out += (_glob.glob(_box_superset(p)) if re.search(r"[*?\[]", p) else [p])[:5000]
    return out


def _box_member_dash(path: str) -> bool:
    """GPT r4: an archive member whose name (any part) starts with "-" (unpacked, a later * passes it as an option)."""
    try:
        import tarfile
        import zipfile
        if zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as z:
                names = z.namelist()
        else:
            with tarfile.open(path) as t:
                names = t.getnames()
    except Exception:
        return True
    return any(part.startswith("-") for n in names for part in n.split("/"))


def _box_braces(w: str, limit: int = 64) -> List[str]:
    """Bash brace expansion IN BASH'S ORDER (GPT r2: the order decides which word is a pattern and which a file);
    {a..b} sequences become _EXP (refused). Over the limit: the list is cut there (refused by the caller)."""
    for i, ch in enumerate(w):
        if ch != _BO:
            continue
        depth, parts, start, j = 0, [], i + 1, i
        while j < len(w):
            if w[j] == _BO:
                depth += 1
            elif w[j] == _BC:
                depth -= 1
                if depth == 0:
                    parts.append(w[start:j]); break
            elif w[j] == _BS and depth == 1:
                parts.append(w[start:j]); start = j + 1
            j += 1
        else:
            continue                           # no closing brace: literal
        if len(parts) < 2:
            if re.fullmatch(r"-?\w+\.\.-?\w+(\.\.-?\d+)?", parts[0] if parts else ""):
                return [w[:i] + _EXP + w[j + 1:]]
            continue                           # {x}: literal
        out: List[str] = []
        for part in parts:
            out += _box_braces(w[:i] + part + w[j + 1:], limit)
            if len(out) >= limit:
                return out[:limit]
        return out
    return [w.replace(_BO, "{").replace(_BC, "}").replace(_BS, ",")]


def _box_command_outside(c: List[str], bases: List[str], files: set, skills: set) -> Optional[str]:
    """One simple command, as _shell_words patterns (unquoted { } , * ? [ active; quoted ones marked literal)."""
    # bash expands braces BEFORE the program sees its words (GPT r2: `grep -e {x,/run/k}`, `find -name {x,-newer,..}`)
    expanded: List[tuple] = []                 # (text, has an unquoted pattern, is a redirect marker)
    for pat in c:
        if pat in (_REDIR_IN, _REDIR_OUT):
            expanded.append((pat, False, True)); continue
        alts = _box_braces(pat) if _BO in pat else [pat]
        if len(alts) >= 64 or any(_EXP in x for x in alts):
            return pat.replace(_BO, "{").replace(_BC, "}").replace(_BS, ",")
        for x in alts:
            globby = bool(re.search(r"[*?\[]", x))
            expanded.append(("".join(_UNQUOTE.get(ch, ch) for ch in x), globby, False))
    words, reads, writes, rreads, rwrites, globbed = [], [], [], [], [], []
    j = 0
    while j < len(expanded):
        text, globby, redir = expanded[j]
        if redir:
            k = j
            while k < len(expanded) and expanded[k][2]:
                k += 1                         # >> and <> are two markers
            if k < len(expanded):
                (rwrites if any(e[0] == _REDIR_OUT for e in expanded[j:k]) else rreads).append(expanded[k][0])
                if any(e[0] == _REDIR_IN for e in expanded[j:k]):
                    rreads.append(expanded[k][0])
            j = k + 1; continue
        words.append(text)
        if globby:
            globbed.append(text)               # GPT r2: bash lists folders for a pattern whatever the program (echo /etc/p*)
        j += 1
    for x in rreads:
        if not _box_word_inside(x, bases, False, redirect=True):
            return x
    for x in rwrites:
        if not _box_word_inside(x, bases, True, redirect=True) or any(
                part.startswith("-") for part in x.split("/")):
            return x                           # GPT r5: nor a file named like an option (> ./-e)
    for x in globbed:
        if not _box_word_inside(x, bases, False):
            return x
        # GPT r4/r5: a relative pattern can expand to a word starting with "-" (-e, -f/etc/hosts), which the program
        # takes as an option
        if not x.startswith(("/", "~")) and any(os.path.relpath(m, b).startswith("-") for b in bases
                                                for m in _box_globbed([x], [b])):
            return x
    while words and _skill_env_ok(words[0]) and len(words) > 1:
        words = words[1:]
    if not words:
        return None
    prog, name = words[0], words[0].rsplit("/", 1)[-1]
    if name in _BOX_GRAMMAR and ("/" not in prog or prog in ("/bin/" + name, "/usr/bin/" + name)):   # Opus GUARDFIX2
        if not _box_words_ok(name, words):
            return prog                        # an option made by brace expansion (find -newer, ...)
        got = _box_operands(name, words)
        if got is None:
            return prog
        r, w, cwd_use, walks = got
        reads += r; writes += w
    elif re.fullmatch(r"python3?|node", name) and "/" not in prog and len(words) > 1 and \
            words[1].startswith("/") and _trusted_skill_script(words[1]):
        # a release skill script (by its full path): its path-like arguments and --opt=<path> values
        for x in words[2:]:
            v = x.split("=", 1)[1] if x.startswith("-") and "=" in x else x
            if re.match(r"^-[A-Za-z][^=-]", x) and "=" not in x:
                v = x[2:]                      # Opus GUARDFIX2 review: a glued short option's value (-o/tmp/x.pdf)
            if "://" not in v and (v.startswith(("/", "~", ".")) or "/" in v):
                reads.append(v)
                if re.match(r"^-(o|-out|-output|-dest|-dir|-target)", x) or (
                        x.startswith("-") and re.search(r"out|dest|dir|target|save|write", x.split("=", 1)[0], re.I)):
                    writes.append(v)           # an output option's value: Files only (never the skills folder)
        cwd_use, walks = "", False
    else:
        return prog                            # (the box grammar's refusal has the reason; this is a second check)
    for x in reads:
        if not _box_word_inside(x, bases, False):
            return x
    if name == "pdftotext" and len(writes) == 1:
        writes.append(re.sub(r"\.pdf$", "", writes[0], flags=re.I) + ".txt")   # GPT r4: its implicit output
    if name == "zip" and writes and not writes[0].lower().endswith(".zip"):
        writes.append(writes[0] + ".zip")      # GPT r5: zip adds .zip
    if name in ("diff", "cmp") and len(reads) == 2:
        for a_, b_ in ((reads[0], reads[1]), (reads[1], reads[0])):
            for b in bases:
                if os.path.isdir(os.path.join(b, os.path.expanduser(b_))) and not os.path.isdir(
                        os.path.join(b, os.path.expanduser(a_))):
                    implied = os.path.join(b_, os.path.basename(a_.rstrip("/")))   # GPT r5: diff file folder
                    if not _box_word_inside(implied, bases, False):
                        return implied
    if name in ("cp", "mv") and any(re.fullmatch(r"-[A-Za-z]*[rRa][A-Za-z]*", x) for x in words[1:]):
        for src in _box_globbed([x for x in words[1:-1] if not x.startswith("-")], bases):
            for dp, dns, fns in os.walk(src) if os.path.isdir(src) else ():
                if any(n.startswith("-") for n in dns + fns):
                    return os.path.join(dp, next(n for n in dns + fns if n.startswith("-")))
    if name in ("gzip", "gunzip") and writes:
        letters_z = "".join(x.lstrip("-") for x in words[1:] if x.startswith("-") and not x.startswith("--"))
        writes += [re.sub(r"\.gz$", "", x) if ("d" in letters_z or name == "gunzip") else x + ".gz" for x in list(writes)]
    for x in writes:
        if not _box_word_inside(x, bases, True):
            return x
        if any(part.startswith("-") for part in x.split("/")):
            return x                           # GPT r4/r5: a file or folder named like an option (a later ?f/.. passes it)
    ops = [x for x in words[1:] if not x.startswith("-")]
    if name in ("cp", "mv", "ln") and len(ops) >= 2:
        # GPT r2: into a folder, the file written is <folder>/<name> (an existing link there is written through)
        for b in bases:
            dest = os.path.join(b, os.path.expanduser(ops[-1]))
            if os.path.isdir(dest) or ops[-1].endswith("/"):
                for src in _box_globbed(ops[:-1], bases) or ops[:-1]:
                    t = os.path.join(dest, os.path.basename(os.path.normpath(src)))
                    if not _box_word_inside(t, [dest], True) or os.path.islink(t) or \
                            os.path.basename(t).startswith("-"):
                        return t
    if name in ("tar", "unzip") and cwd_use == "w" or name == "unzip":
        # GPT r2: whatever its spelling (evil.b?n), an archive it unpacks must exist now and hold no link, absolute
        # name or ".." (a link it makes would be written through later in the same line)
        archives = _box_globbed(reads[:1] if name == "unzip" else reads, bases)
        if not archives or any(not os.path.isfile(x) or _archive_has_links(x) or _box_member_dash(x) for x in archives):
            return (reads or ["the archive"])[0]
        # GPT r4: unpacking writes through a link already where it unpacks
        dests = [os.path.join(b, os.path.expanduser(w)) for w in writes for b in bases] if name == "unzip" and writes \
            else list(bases)
        hit = _box_link_out([d for d in dests if os.path.isdir(d)])
        if hit:
            return hit
    if cwd_use == "w":
        for b in bases:
            if not _box_under(os.path.realpath(b), files):
                return b                       # it would unpack or link into the skills folder
    if walks:
        hit = _box_link_out(_box_globbed(reads + writes, bases) if reads or writes else list(bases))
        if hit:
            return hit
    if name == "ln" and "s" in "".join(x.lstrip("-") for x in words[1:] if x.startswith("-")):
        ops = [x for x in words[1:] if not x.startswith("-")]
        if ops and not ops[0].startswith(("/", "~")):
            link = ops[1] if len(ops) > 1 else "."
            for b in bases:
                lp = os.path.join(b, os.path.expanduser(link))
                # a relative link target counts from the folder the link is made in (or inside, for a folder)
                for d in (os.path.dirname(lp), lp):
                    if not _box_word_inside(os.path.join(d, ops[0]), [d], False):
                        return ops[0]
    return None


def _bulk_link_escape(command: str, bases: List[str]) -> bool:
    """Opus r1 B6: recursive and archive commands follow links they are not given by name (zip -r, grep -R, rsync -L,
    tar -h) and extracting an archive can make such links. True when a folder such a command walks holds a link into
    the engine home outside its open folders, or an archive it extracts holds a link, an absolute name or "..". """
    hp = _home_parts()
    if not hp:
        return False
    cmds = _split_commands(command) or []
    for c in cmds:
        names = {w.rsplit("/", 1)[-1] for w in c}
        rec = any(re.fullmatch(r"-[A-Za-z]*[rRa][A-Za-z]*|--recursive|--archive|--dereference-recursive", w) for w in c)
        walks = names & {"tar", "bsdtar", "rsync", "rg", "find", "unzip", "ditto", "7z", "7za", "cpio", "pax"} or \
            (rec and names & {"zip", "cp", "grep", "egrep", "fgrep", "ls", "scp", "chmod", "chown", "diff", "gdiff"}) or \
            ("du" in names and any(w in ("-L", "--dereference") for w in c))
        if not walks:
            continue
        roots: List[str] = []
        for w in c[1:]:
            if w.startswith("-"):
                continue
            w = os.path.expanduser(w)
            for f in ([w] if w.startswith("/") else [os.path.join(b, w) for b in bases]):
                if os.path.isdir(f):
                    roots.append(f)
                elif os.path.isfile(f) and names & {"unzip", "tar", "bsdtar", "ditto", "7z", "7za", "cpio", "pax"}:
                    if _archive_has_links(f, any_name=True):
                        return True            # Opus r2 N3b: any file such a command is given, whatever its name
        if not roots and names & {"rg", "find", "grep", "egrep", "fgrep"}:
            roots = list(bases[:1])            # rg, grep -r and find with no folder walk the work folder
        if names & {"unzip", "tar", "bsdtar", "ditto", "7z", "7za", "cpio", "pax"}:
            roots += list(bases[:1])           # Opus r2 N3b: extracting writes through a link already in the folder
        seen = 0
        for r in roots:
            for dp, dns, fns in os.walk(r, followlinks=False):
                for n in dns + fns:
                    seen += 1
                    if seen > 50000:
                        return True            # too many to check
                    pth = os.path.join(dp, n)
                    if os.path.islink(pth) and _in_home(os.path.realpath(pth), hp) in ("closed", "home", "above"):
                        return True
    return False


def _archive_has_links(path: str, any_name: bool = False) -> bool:
    """An archive holding a link, an absolute name or "..". any_name: a file that is no archive at all is fine; one
    that can't be read as either kind but looks like one is refused."""
    try:
        import zipfile
        import tarfile
        if any_name and not zipfile.is_zipfile(path):
            try:
                is_tar = tarfile.is_tarfile(path)
            except Exception:
                is_tar = False
            if not is_tar:
                return False
            return _tar_links(path)
        if zipfile.is_zipfile(path) or path.lower().endswith(".zip"):
            import zipfile
            with zipfile.ZipFile(path) as z:
                for i in z.infolist():
                    if ((i.external_attr >> 16) & 0o170000) == 0o120000 or i.filename.startswith("/") or \
                            ".." in i.filename.split("/") or _member_named_badly(i.filename):
                        return True
            return False
        return _tar_links(path)
    except Exception:
        return True


def _tar_links(path: str) -> bool:
    import tarfile
    try:
        with tarfile.open(path) as t:
            for m in t.getmembers():
                if m.issym() or m.islnk() or m.name.startswith("/") or ".." in m.name.split("/") or \
                        _member_named_badly(m.name):
                    return True
        return False
    except Exception:
        return True


def _member_named_badly(name: str) -> bool:
    """Opus r3 R3-2: an archive member named like a sign-in file or Qosha's own files (unpacked beside them, a folder
    compare would show the real ones)."""
    return bool(_cred_hit(name) or _guard_hit(name))


def _runs_a_draft(strings: List[str], workdirs: List[str]) -> bool:
    """A code tool naming a file in skill-drafts/ while a shell or interpreter could run it: drafts are text."""
    d = _drafts_root()
    if not d:
        return False
    wf = [w for x in strings for w in _words_all(x)]
    toks = [t for x in strings for t in _path_tokens(x)]
    bases = _bases(workdirs, [t for t, g, pt in wf] + toks)
    for t in [t for t, g, pt in wf] + toks:
        tt = os.path.expanduser(t)
        for c in ([tt] if tt.startswith("/") else [os.path.join(b, tt) for b in bases]):
            r = _resolve(c)
            if r == d or r.startswith(d + "/") or os.path.realpath(c).startswith(d + "/"):
                return True
    return False


# Payments (pay-fix step 1, 3 Nov): payment connectors are held in _classify_mcp, but a terminal, code, process or
# browser call could reach a payment service directly. Any such call that would otherwise run is HELD as an app.action
# with `resolved: false` (the executor never runs it: Approve can't replay a terminal or browser call). Rules only add
# holds; nothing here can turn a refusal or a hold into a run.
# Text checks are a speed bump, not the boundary: the boundary is that the assistant never gets a payment key (refused
# below) and connected money apps hold every write. Clicks inside an already open page can't be judged from text.
# Payment and money-movement API hosts (and whole payment sites): any subdomain of these counts.
PAYMENT_HOSTS = (
    "api.stripe.com", "checkout.stripe.com", "buy.stripe.com", "pay.stripe.com", "connect.stripe.com",
    "api-m.paypal.com", "api.paypal.com", "api-m.sandbox.paypal.com", "api.sandbox.paypal.com", "paypal.me",
    "connect.squareup.com", "connect.squareupsandbox.com",
    "quickbooks.api.intuit.com", "sandbox-quickbooks.api.intuit.com", "api.xero.com",
    "api.ramp.com", "demo-api.ramp.com", "api.airwallex.com", "api-demo.airwallex.com", "integrations.expensify.com",
    "api.myob.com", "api.wise.com", "api.transferwise.com", "api.sandbox.transferwise.tech",
    "api.plaid.com", "production.plaid.com", "development.plaid.com", "sandbox.plaid.com",
    "api.dwolla.com", "api-sandbox.dwolla.com", "api.braintreegateway.com", "api.sandbox.braintreegateway.com",
    "api.adyen.com", "checkout-test.adyen.com", "pal-test.adyen.com", "adyenpayments.com",
    "api.coinbase.com", "api.exchange.coinbase.com", "api.commerce.coinbase.com",
    "api.mercury.com", "api.brex.com", "platform.brexapis.com", "api.gusto.com", "api.gusto-demo.com",
    "payments.amazon.com", "pay-api.amazon.com", "pay-api.amazon.eu", "pay-api.amazon.jp",
    # payment and transfer sites: every page
    "venmo.com", "cash.app", "wise.com", "transferwise.com", "zellepay.com",
)
_PAY_HOST_SET = frozenset(PAYMENT_HOSTS)
# host-like words, matched once each (GPT R-pay1 #8: the old `(?:label\.)*` prefix rescanned long dotted text)
_HOSTLIKE = re.compile(r"(?<![a-z0-9-])[a-z0-9-]+(?:\.[a-z0-9-]+)+")
# distinctive enough to find inside text with quotes, spaces and `+` removed ("api.str" + "ipe.com")
_PAY_SQUASHED = tuple(h for h in PAYMENT_HOSTS if h.count(".") >= 2 or h in ("paypal.me", "adyenpayments.com"))
_PAY_PAGES = re.compile(r"(?<![a-z0-9-])((?:[a-z0-9-]+\.){0,8}paypal\.com)(?::\d+)?/+(?:[a-z]{2}(?:[-_][a-z]{2})?/+)?"
                        r"(?:myaccount/+(?:transfer|money|wallet)|send|pay|checkoutnow|webapps/+herm(?:es)|cgi-bin/+webscr|donate)"
                        r"|(?<![a-z0-9-])([a-z0-9-]+\.myshopify\.com)(?::\d+)?/+admin(?![a-z0-9])")
# (PayPal's own checkout path is /webapps/ plus the engine's word: spelled in two parts so the naming scan stays exact)
# browser tools: a checkout, transfer, wire, ACH, payout or send-money page on any site
_URL = re.compile(r"(?:[a-z][a-z0-9+.-]*:)?//([^/\s'\"<>?#]+)(/[^\s'\"<>?#]*)"
                  r"|(?<![\w.@-])((?:[a-z0-9-]+\.)+[a-z]{2,})(?::\d+)?(/[^\s'\"<>?#]*)")
_PAY_PATH_WORDS = {"checkout", "checkouts", "transfer", "transfers", "wire", "wires", "ach", "payout", "payouts"}
_PAY_PATH_JOINED = ("sendmoney", "moneytransfer", "sendpayment", "paynow")
# a path part of more words is an article's title ("how-do-i-send-money-help293"), unless it starts with a pay word
# and carries no year (GPT R-pay1 #3: "checkout-one-two-three-four" is still a checkout page)
_SLUG_WORDS = 4
# Reading (PAYPORT, 4 Nov): a browser opening exactly one plain URL of a payment company's own documentation or help,
# a code or encyclopedia site, or a page whose path starts with a reading word (docs, help, blog, news, a year) is not
# held for that path; short pay words deeper in a generic site's path still count (/help/wire). Never for a payment API
# or checkout host, never for a PayPal pay page; a redirect target after `?` or `#` (also a relative one) is checked.
_WHOLE_SITES = ("venmo.com", "cash.app", "wise.com", "transferwise.com", "zellepay.com")
_READING_DOC_HOSTS = ("docs.stripe.com", "support.stripe.com", "developer.paypal.com", "developer.squareup.com",
                      "developer.intuit.com", "developer.xero.com", "central.xero.com", "docs.wise.com",
                      "docs.airwallex.com", "docs.ramp.com", "docs.github.com", "plaid.com")
_READING_DOC_PATHS = {"stripe.com": "docs", "www.stripe.com": "docs", "squareup.com": "help", "www.paypal.com": "cshelp"}
_READING_HOSTS = ("github.com", "gitlab.com", "wikipedia.org", "stackoverflow.com", "stackexchange.com")  # + subdomains
_READING_SEGMENTS = {"docs", "doc", "documentation", "help", "cshelp", "support", "article", "articles", "blog", "blogs",
                     "news", "learn", "guide", "guides", "wiki", "kb", "faq", "faqs", "legal", "glossary", "press",
                     "newsroom", "stories", "story"}
_YEAR = re.compile(r"(?:19|20)\d\d")
_ONE_URL = re.compile(r"https?://([a-z0-9.-]+)(?::\d{1,5})?(/[^\s'\"<>?#\\]*)?([?#][^\s'\"<>\\]*)?", re.I)
# a payment SDK in code: it reaches the service without the host in the text (GPT R-pay1 #6)
_PAY_SDK = re.compile(r"(?:^|[\s;(,])(?:import|from)\s+(stripe|paypalrestsdk|paypalcheckoutsdk|paypalserversdk|square|"
                      r"squareup|braintree|plaid|adyen|wise|coinbase|intuitlib|quickbooks|xero_python|gocardless_pro|"
                      r"mollie|razorpay|dwollav2)(?![\w])"
                      r"|require\(\s*['\"`](stripe|@paypal/[\w-]+|square|squareup|braintree|plaid|@adyen/[\w-]+|"
                      r"coinbase|xero-node|gocardless-nodejs|@mollie/[\w-]+|razorpay|dwolla-v2)['\"`]\s*\)"
                      r"|\bfrom\s+['\"`](stripe|@paypal/[\w-]+|square|braintree|plaid|@adyen/[\w-]+|xero-node)['\"`]",
                      re.M)
# payment secret keys: treated as sign-in credentials (refused), in any tool's arguments. No left boundary on the
# distinctive prefixes: `curl -usk_live_...` glues the key to an option (GPT R-pay1 #1).
_PAY_SECRETS = (("Stripe secret key", re.compile(r"(?:sk|rk)_(?:live|test)_[A-Za-z0-9]{8,}")),
                ("Square access token", re.compile(r"sq0(?:atp|csp)-[A-Za-z0-9_-]{8,}")),
                ("Square access token", re.compile(r"(?<![A-Za-z0-9])EAAA[A-Za-z0-9_-]{56,}")),
                ("PayPal/Braintree access token", re.compile(r"access_token\$(?:production|sandbox)\$", re.I)))
PAYMENT_TOOLS = CODE_TOOLS
# how a browser reads a host: full-width and ideographic dots are dots, `\` is `/`, a trailing dot is dropped
_DOTS = str.maketrans({"。": ".", "．": ".", "｡": ".", "\\": "/"})


def _decoded_forms(text: str) -> List[str]:
    """The text, its URL-decoded forms, any base64 runs in it that decode to readable text, and each as a browser
    would read its addresses (dots, backslashes, trailing dots, dot segments)."""
    out = [text]
    t = text
    for _ in range(3):
        u = urllib.parse.unquote_plus(t)
        if u == t:
            break
        out.append(u); t = u
    for run in re.findall(r"[A-Za-z0-9+/_-]{16,}={0,2}", text):
        try:
            raw = base64.b64decode(run + "=" * (-len(run) % 4), altchars=b"-_" if ("-" in run or "_" in run) else None)
        except (binascii.Error, ValueError):
            continue
        s = raw.decode("utf-8", "ignore")
        if s and sum(c.isprintable() or c.isspace() for c in s) >= 0.9 * len(s):
            out.append(s)
    for form in list(out):
        t = unicodedata.normalize("NFKC", form).translate(_DOTS)
        t = re.sub(r"(?<=[a-z0-9-])\.+(?=[:/?#]|$)", "", t, flags=re.I)     # www.paypal.com./send
        for _ in range(16):              # paths as a browser resolves them: paypal.com/us/cshelp/../send is /us/send
            u = re.sub(r"/\.(?=/|$)|/(?!\.\.(?:/|$))[^/?#\s'\"]+/\.\.(?=/|$)", "", t)
            if u == t:
                break
            t = u
        if t != form:
            out.append(t)
    return out


def _payment_secret(text: str) -> Optional[str]:
    for form in _decoded_forms(text):
        for label, rx in _PAY_SECRETS:
            if rx.search(form) or rx.search(re.sub(r"[\s'\"\\+`]", "", form)):
                return label
    return None


def _pay_host_in(low: str) -> Optional[str]:
    """A payment host (or a subdomain of one) named in lower-case text."""
    for m in _HOSTLIKE.finditer(low):
        labels = m.group(0).split(".")
        for i in range(max(0, len(labels) - 5), len(labels) - 1):      # payment hosts have at most 5 labels
            h = ".".join(labels[i:])
            if h in _PAY_HOST_SET:
                return h
    return None


def _reading_rest(s: str) -> Optional[str]:
    """When s is exactly one plain URL of a reading page: its `?`/`#` part (still checked), else None."""
    m = _ONE_URL.fullmatch(s.strip())
    if not m:
        return None                     # anything else (encoded, Unicode or userinfo hosts, several URLs): no exemption
    host = m.group(1).lower()
    if host.endswith(".") or ".." in host:
        return None
    pay = _pay_host_in(host)
    if pay and pay not in _WHOLE_SITES:
        return None                                         # a payment API or checkout host is never a reading page
    path = posixpath.normpath(urllib.parse.unquote(m.group(2) or "/").lower())   # /docs/../wire is /wire
    if _PAY_PAGES.search(host + path):
        return None                                         # a PayPal pay page or a shop's admin
    segs = [x for x in path.split("/") if x]
    rest = m.group(3) or ""
    # a relative redirect target (?next=/wire) counts as a page on the same host (GPT R-pay1 #3)
    for v in re.findall(r"(?<=[=#])(/[^&#\s]*)", urllib.parse.unquote(rest).lower()):
        if _pay_path(host, posixpath.normpath(v)):
            rest += " //%s%s" % (host, posixpath.normpath(v))
    # a payment company's documentation host exactly (not dashboard.stripe.com), a code or encyclopedia site
    if host in _READING_DOC_HOSTS or any(host == h or host.endswith("." + h) for h in _READING_HOSTS):
        return rest
    # the reading word leads the path (after a locale like us/ or en-gb/): /docs/.., /us/cshelp/.., /2026/11/..
    i = 1 if segs and re.fullmatch(r"[a-z]{2}(?:[-_][a-z]{2})?", segs[0]) else 0
    if i < len(segs) and _READING_DOC_PATHS.get(host) == segs[i]:
        return rest                                         # stripe.com/docs/payouts: the company's own docs
    if i < len(segs) and (segs[i] in _READING_SEGMENTS or _YEAR.fullmatch(segs[i])):
        deeper = [x for x in segs[i + 1:] if len([p for p in re.split(r"[-_.~+]+", x) if p]) <= 2]
        return None if _pay_path(host, "/" + "/".join(deeper)) else rest      # /help/wire is still a wire page
    return None


def _pay_path(host: str, path: str) -> Optional[str]:
    for seg in path.split("/"):
        parts = [p for p in re.split(r"[-_.~+]+", seg) if p]
        if len(parts) > _SLUG_WORDS and (parts[0] not in _PAY_PATH_WORDS or any(_YEAR.fullmatch(p) for p in parts)):
            continue                                        # an article's title
        if set(parts) & _PAY_PATH_WORDS or any(j in re.sub(r"[-_.~+]", "", seg) for j in _PAY_PATH_JOINED):
            return "%s (a %s page)" % (host.split("@")[-1].split(":")[0], seg)
    return None


def _payment_host(tool: str, strings: List[str]) -> Optional[str]:
    """The payment service a terminal, code, process or browser call reaches, if any."""
    for s in strings:
        rest = _reading_rest(s) if tool == "browser_navigate" else None
        if rest is not None:
            s = rest
        for form in _decoded_forms(s):
            low = form.lower()
            h = _pay_host_in(low)
            if h:
                return h
            m = _PAY_PAGES.search(low)
            if m:
                return m.group(1) or m.group(2)
            sq = _squash(form).replace("\\", "")
            for h in _PAY_SQUASHED:
                if h in sq:
                    return h
            if ".myshopify.com/admin" in sq:
                return "myshopify.com"
            if tool in ("execute_code", "terminal", "process", "browser_exec", "browser_cdp"):
                m = _PAY_SDK.search(form)
                if m:
                    return "%s (payment library)" % next(g for g in m.groups() if g)
            if tool.startswith("browser_"):
                for m in _URL.finditer(low):
                    host, path = (m.group(1), m.group(2)) if m.group(1) is not None else (m.group(3), m.group(4))
                    hit = _pay_path(host, path)
                    if hit:
                        return hit
    return None


def _script_bodies(tool: str, args: Any, strings: List[str]) -> List[str]:
    """The scripts a terminal or code call runs (GPT R-pay1 #5: their contents count as part of the call)."""
    if tool not in CODE_TOOLS:
        return []
    workdir = args.get("workdir") or args.get("cwd") if isinstance(args, dict) else None
    bodies = (_script_text(p) for p in _script_paths("\n".join(strings), workdir if isinstance(workdir, str) else None))
    return [b for b in bodies if b]



def _literal_source_cat(tool: str, args: Any) -> bool:
    """Only a single cat of absolute Qosha source paths: its bytes are data, not executed code.
    This narrows payment-host scanning only; the underlying verdict and secret scans still apply.
    No options, wrappers, relative paths, pipes, redirects, expansion or command substitution.
    """
    if tool != "terminal" or not isinstance(args, dict) or not isinstance(args.get("command"), str):
        return False
    words = _plain_words(args["command"])
    return bool(words and len(words) > 1 and words[0] in ("cat", "/bin/cat", "/usr/bin/cat")
                and all(os.path.isabs(path) and source_path(path) for path in words[1:]))


def classify(tool_name: str, args: Any, my_chrome: bool = False) -> Verdict:
    """The single decision point. Never raises for well-formed input; the hook treats exceptions as DENY.
    my_chrome: the person chose their own Chrome as Qosha's browser (the hook asks the connector); only then may a
    browser tool name a webmail or calendar site (rule G2 is lifted there: MYCHROME, Ren 9 Nov)."""
    google_scan = {"binding": None, "used": False}
    verdict = _classify(tool_name, args, google_scan, my_chrome)
    tool = (tool_name or "").strip()
    if verdict.action == DENY and _reroutable(tool, args, verdict):
        # CAPFIX (owner order; Gemini D50 Q5): on the Mac, a command the host-side checks can't vouch for runs in Qosha's
        # code sandbox instead of being refused (it holds no sign-in and can't reach this Mac's services)
        verdict = Verdict(ALLOW, "", "codebox", {"lang": "python" if tool == "execute_code" else "sh"})
    # a "rewrite" only runs Qosha's own Google connector client with fixed arguments: it can't reach a payment service
    if verdict.action == ALLOW and verdict.kind != "rewrite" and (tool in PAYMENT_TOOLS or tool.startswith("browser_")):
        strings = _strings(args if args is not None else {})
        bodies = _script_bodies(tool, args, strings)
        if any(_payment_secret(b) for b in bodies):
            return Verdict(DENY, "This script holds a payment secret key; Qosha never lets the assistant use one.")
        # A literal read of Qosha source may contain payment-host constants. They are not destinations
        # reached by cat. Keep scanning the command itself and keep the body secret-key check above.
        host = _payment_host(tool, strings if _literal_source_cat(tool, args) else strings + bodies)
        if host:
            return Verdict(HOLD, "reaches a payment service", "app.action",
                           {"server": "", "tool": tool, "registered_name": tool, "resolved": False,
                            "server_label": "Payment service (%s)" % host, "payment_host": host,
                            "arguments": args if isinstance(args, dict) else {"value": args}})
    return _finish_google_scan(verdict, google_scan)


def _dot_pattern(text: str) -> bool:
    """Opus r5 N1: an UNQUOTED pattern in a path part that starts with "." (.? .[.] .*), which older shells (the Mac's
    bash 3.2) let match "..". Quoted text (sed 's/.*//') is not a pattern."""
    for w in _shell_words(text):
        pat = w[0]
        if not isinstance(pat, str):
            continue
        for part in pat.split("/"):
            if part.startswith(".") and re.search(r"[*?\[\x01]", part):
                return True
    return False


def _moves_own_folder(command: str, bases: List[str]) -> bool:
    """GPT r9b: `mv ../sub ../reports/deep && touch ../../../hooks/x`: moving (or removing) the folder the command runs
    in, or a folder above it, changes where its later relative paths land; refused."""
    for c in _split_commands(command) or []:
        if not c or c[0].rsplit("/", 1)[-1] not in ("mv", "rm", "rmdir", "rename"):
            continue
        for w in c[1:]:
            if w.startswith("-"):
                continue
            w = os.path.expanduser(w)
            for f in ([w] if w.startswith("/") else [os.path.join(b, w) for b in bases]):
                for real in {os.path.realpath(f), posixpath.normpath(f)}:
                    if any(b == real or b.startswith(real.rstrip("/") + "/") for b in bases):
                        return True
    return False


def _folder_history(text: str, depth: int = 0) -> bool:
    """GPT r6: cd/pushd to the shell's previous folder however it is quoted (cd '-', cd "-", cd \\-), or to a folder
    named by an expansion this guard can't see; also inside quoted command text a shell runs (sh -c '...')."""
    cmds = _split_commands(text)
    if cmds is None:
        return bool(re.search(r"\b(?:cd|pushd)\b", text))     # can't read it: a cd in it is refused
    for c in cmds:
        # GPT r8: a cd with a redirection hides its real destination from the folders judged: refused outright
        if set(c) & {"cd", "pushd", "chdir"} and set(c) & {">", ">>", "<", "<<", "<<<", ">&", "&>", "<>", ">|"}:
            return True
        # GPT r7: redirections are not arguments (cd 2>/dev/null '-'): drop them, with their targets
        k, words = 0, []
        while k < len(c):
            if c[k] in (">", ">>", "<", "<<", "<<<", ">&", "&>", "<>", ">|"):
                k += 2; continue
            if re.fullmatch(r"\d+", c[k]) and k + 1 < len(c) and c[k + 1] in (">", ">>", "<", ">&", "<>", ">|"):
                k += 3; continue
            words.append(c[k]); k += 1
        for i, w in enumerate(words):
            if w in ("cd", "pushd", "chdir"):
                args = [x for x in words[i + 1:] if not re.fullmatch(r"-[LPe@]+|--", x)]
                if args and (args[0] == "-" or args[0].startswith(("~-", "~+")) or re.search(r"[$`]", args[0])) or \
                        "-" in words[i + 1:]:
                    return True
            if depth < 3 and re.search(r"\s", w) and re.search(r"\b(?:cd|pushd)\b", w) and _folder_history(w, depth + 1):
                return True
    return False


def _reaches_proc(strings: List[str], workdirs: Optional[List[str]] = None) -> bool:
    """A path that, once normalized from any base (or as a pattern), lands in /proc or /dev/fd."""
    toks = [t for x in strings for t in _path_tokens(x)]
    saved = list(_EXTRA_BASES)
    _EXTRA_BASES[:] = []                       # (execute_code's "/" base would make every `*` reach /proc)
    try:
        bases = _bases(list(workdirs or []), toks, True) + _bases([], [], False)   # Opus r6 B2 / GPT r9b: cd targets, workdir
    finally:
        _EXTRA_BASES[:] = saved
    for t in toks:
        t = os.path.expanduser(t)
        # a relative path that climbs may start from a folder this guard does not know (a kernel's temp folder)
        for c in ([t] if t.startswith("/") else [os.path.join(b, t) for b in bases + (["/"] if ".." in t else [])]):
            n = posixpath.normpath(c)
            first = n.split("/")[1] if n.count("/") >= 1 and len(n) > 1 else ""
            if first and (fnmatch.fnmatchcase("proc", first.lower()) or n.startswith("/dev/fd")):
                return True
            try:
                if os.path.realpath(c).startswith(("/proc/", "/dev/fd")):
                    return True
            except (OSError, ValueError):
                pass
    return False


def _search_parts(path: str) -> List[str]:
    """The path as given and, when it splits into two or more parts at commas or blanks, each part: the engine's
    search_files searches every part that exists when the whole string doesn't (tools/file_operations.py,
    _try_multi_path_search). GUARDFIX3, GPT review of round 3."""
    out = [path]
    q = os.path.expanduser(path)               # GPT review r3b: the engine expands ~ first, then splits (only a path that
    try:                                       # does not exist; from every folder a relative one may start from)
        exists = os.path.exists(q) if q.startswith("/") else all(
            os.path.exists(os.path.join(b, q)) for b in _bases([], [], False))
    except (OSError, ValueError):
        exists = False
    if not exists:
        for r in dict.fromkeys([path, q]):
            parts = [x for chunk in r.split(",") for x in chunk.split() if x.strip()]
            if len(parts) >= 2:
                out += parts
    return list(dict.fromkeys(out))


def _vision_local_path(args: Any, keys=("image_url", "image", "path")) -> Optional[str]:
    """GUARDFIX3 (verifier r3 finding 6): the local file vision_analyze would open, spelled the way the engine reads it
    (tools/image_source.py: file:// stripped as text, ~ expanded, a relative name from the engine's own process folder),
    else None (a web address, data: URL, or a scheme the engine refuses)."""
    if not isinstance(args, dict):
        return None
    url = next((args.get(k) for k in keys if args.get(k)), "")
    if not isinstance(url, str) or not url.strip():
        return None
    u = url.strip()
    if u.startswith("data:") or u.startswith(("http://", "https://")):
        return None                            # (case as the engine: tools/image_source.py)
    if _ENGINE_SCHEME.match(u) and not u.lower().startswith("file://"):
        return None                            # the engine refuses other schemes (only "<scheme>://" is one)
    if u.lower().startswith("file://"):
        u = u[len("file://"):]                 # GPT review r3: exactly as the engine (file://home/x is home/x)
    # GPT review r3b: the engine's Path.resolve() follows links before "..": realpath from its own process folder
    return os.path.realpath(os.path.join(os.getcwd(), os.path.expanduser(u)))


_VISION_MEDIA = ("images", "image_cache", os.path.join("cache", "images"))
_ENGINE_SCHEME = re.compile(r"^[A-Za-z][A-Za-z0-9+.\-]*://")   # tools/image_source.py _SCHEME_RE


def _vision_media_ok(path: str) -> bool:
    """The person's own uploaded images (the dashboard keeps them in <engine home>/images; the engine's image caches):
    vision may look at a plain file really inside them (links followed, no hard links). GPT review r3."""
    hp = _home_parts()
    if not hp:
        return False
    home = "/" + "/".join(hp)
    real = _canon(os.path.realpath(path), hp)
    real_home = os.path.realpath(home)
    for d in _VISION_MEDIA:
        root = os.path.realpath(os.path.join(home, d))
        if root != os.path.join(real_home, d):
            continue                           # GPT review r3b: a linked images/ (or cache/) would move the boundary
        try:
            if real.startswith(root + os.sep) and os.path.isfile(real) and os.stat(real).st_nlink == 1:
                return True
        except OSError:
            return False
    return False


# ---------------------------------------------------------------------------------------------------------- CAPFIX
# Ren, 6 Nov ("Qosha is me ... if I'm telling it to do something, it needs to do something"): only his three rules
# stay. G1: what leaves the machine, deletes and payments wait for his one-tap Approve; payments are always held; G2:
# secrets are never shown to the assistant. Everything else works through chat (council D50).

# D50 Q1/Q2: on the Mac lab, code the assistant writes itself runs in Qosha's code sandbox (a Linux container that sees
# Your files and nothing else of this Mac's; connector/qosha_codebox.py) instead of being refused. Set by the hook.
CODEBOX = False
_HOST_ONLY = {"open", "/usr/bin/open"}


_KEEP_REFUSED = ("Qosha never lets the assistant read or use sign-in credentials", "payment", "Sending messages directly",
                 "would switch off Qosha's approval guard", "That is Qosha's own data", "Signing in to Google")


def _reroutable(tool: str, args: Any, verdict: "Verdict") -> bool:
    """A refusal of a terminal or code call that cites none of the three rules' own checks (credentials, payments,
    Qosha's approval machinery, Google sign-in) and isn't Google's or `open`'s own path: on the Mac with the code
    sandbox on, such a call runs there instead."""
    if not CODEBOX or _shared_home() or tool not in ("terminal", "execute_code") or not isinstance(args, dict):
        return False
    if any(k in (verdict.reason or "") for k in _KEEP_REFUSED):
        return False
    text = str(args.get("code") if tool == "execute_code" else args.get("command") or "")
    if not text.strip() or _payment_secret(text) or _cred_hit(text):
        return False
    if tool == "terminal":
        if _google_read_call("terminal", {"command": text}) or _google_script_only(text) or \
                re.search(r"google_api|gapi|setup\.py|connector_client", text, re.I):
            return False
        for c in _split_commands(text) or []:
            prog = c[0].rsplit("/", 1)[-1] if c else ""
            if c and (c[0] in _HOST_ONLY or prog in _ENGINE_CLI or prog == "qosha"):
                return False
    return True


_DELETERS_ANY = {"rm", "rmdir", "unlink", "mv", "shred", "srm", "trash", "truncate", "rsync", "ditto"}


def _deletes(command: str) -> bool:
    """GPT R1 #3: a command that can delete or move files (rm/mv/... anywhere in it, find -delete, git clean). On the
    Mac with the code sandbox on, such a command runs there (it sees only Your files), unless it is a plain
    `rm <paths>` outside Your files, which becomes an Approve card (delete_hold)."""
    for c in _split_commands(command) or [[command]]:
        names = [w.rsplit("/", 1)[-1] for w in c]
        if set(names) & _DELETERS_ANY or ("find" in names and any(w in ("-delete", "-exec", "-execdir", "-ok") for w in c)) \
                or ("git" in names and any(w in ("clean", "rm", "mv") for w in c)):
            return True
    return False


def codebox_call(tool: str, args: Any) -> Optional[tuple]:
    """(language, code) when this call is code the assistant wrote that goes to Qosha's code sandbox, else None. Plain
    file and text commands, the release's skill scripts, Google reads and `open` keep running on this Mac as before."""
    if not CODEBOX or _shared_home() or tool not in ("terminal", "execute_code") or not isinstance(args, dict):
        return None
    if tool == "execute_code":
        code = args.get("code")
        return ("python", code) if isinstance(code, str) and code.strip() else None
    command = args.get("command")
    if not isinstance(command, str) or not command.strip():
        return None
    if not _box_code_refusal(tool, args) and not _deletes(command):
        return None
    for c in _split_commands(command) or []:
        prog = c[0].rsplit("/", 1)[-1] if c else ""
        if c and (c[0] in _HOST_ONLY or prog in _ENGINE_CLI or prog == "qosha"):
            return None                        # Qosha's open (a card) and its own command line (settings: a card)
    if _google_read_call("terminal", {"command": command}) or _google_script_only(command) or _mail_hit(command):
        return None                            # Google goes through the connector, which holds sends for Approve
    return ("sh", command)


# D50 Q4: Qosha's own code is not a secret. The assistant may READ the plugin (the guard included), the engine's source
# and web UI, the lab's sandbox profiles and the skills; data that may hold sign-ins or tokens stays closed (G2):
# .env, auth.json, config.yaml, databases, the qosha/ folder (keys, tokens, the proxy's authority), secure/, sessions,
# logs, memories. Writing any of Qosha's own files still goes through the guard (settings: an Approve card).
SOURCE_SUFFIXES = (".py", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".css", ".scss", ".html", ".htm", ".svg", ".md",
                   ".txt", ".json", ".yaml", ".yml", ".sb", ".c", ".h", ".toml", ".cfg", ".ini", ".sh", ".map")
_SOURCE_SECRET = re.compile(r"(^|/)(\.env[^/]*|auth\.json|[^/]*token[^/]*|[^/]*secret[^/]*|[^/]*credential[^/]*|"
                            r"connector\.key|[^/]*\.pem|[^/]*\.key|config\.yaml|[^/]*\.db|[^/]*\.sqlite[^/]*)$", re.I)
_SOURCE_READERS = {"cat", "head", "tail", "wc", "grep", "egrep", "fgrep", "rg", "ls", "file", "stat", "diff", "nl"}


def _source_roots() -> List[str]:
    hp = _home_parts()
    if not hp:
        return []
    home = "/" + "/".join(hp)
    lab = os.path.dirname(home)
    roots = [os.path.join(home, "plugins")]
    if os.path.basename(lab).lower() == "qoshalab" or os.path.isfile(os.path.join(lab, "lab.json")):
        roots += [os.path.join(lab, "src"), os.path.join(lab, "venv")]
    return [os.path.realpath(r) for r in roots]


def source_path(path: str, folder_ok: bool = False) -> bool:
    """A file of Qosha's own code (by its real place and kind), or with folder_ok a folder of it (to search or list)."""
    if not isinstance(path, str) or not path.strip() or _ALIAS_TEXT.search(path) or re.search(r"[*?\[\x00]", path):
        return False
    p = os.path.expanduser(path.strip())
    if not p.startswith("/"):
        return False
    real = os.path.realpath(p)
    hp = _home_parts()
    lab = os.path.dirname("/" + "/".join(hp)) if hp else ""
    in_root = any(real == r or real.startswith(r + "/") for r in _source_roots())
    profile = bool(lab) and os.path.dirname(real) == os.path.realpath(os.path.join(lab, "run")) and real.endswith(".sb")
    if not (in_root or profile):
        return False
    if _SOURCE_SECRET.search(real) and not real.endswith(("_secret.py", "secrets.py", "token.py", "tokens.py")):
        return False
    if os.path.isdir(real):
        return folder_ok
    return real.lower().endswith(SOURCE_SUFFIXES)


def _person_path(path: str) -> bool:
    """A full path (or ~/...) in the person's home, outside the lab folder, not a firmlink or pattern spelling."""
    if not isinstance(path, str) or not path.strip() or _ALIAS_TEXT.search(path) or re.search(r"[*?\[\x00,]", path):
        return False
    p = os.path.expanduser(path.strip())
    if not p.startswith("/"):
        return False
    real = os.path.realpath(p)
    person = os.path.realpath(os.path.expanduser("~"))
    hp = _home_parts()
    lab = os.path.realpath("/" + "/".join(hp[:-1])) if len(hp) > 1 else ""
    eng = os.path.realpath("/" + "/".join(hp)) if hp else ""
    inside = lambda r, root: bool(root) and (r == root or r.startswith(root + "/"))
    return inside(real, person) and real != person and not inside(real, lab) and not inside(real, eng)


def _person_reader(command: str) -> bool:
    """One strict cat invocation reuses the existing shell grammar and file-read checks. No codebox input mount is
    needed for an ordinary absolute document read. Other command shapes keep the existing classification."""
    words = _plain_words(command)
    if not words or words[0] not in ("cat", "/bin/cat", "/usr/bin/cat") or not _box_words_ok("cat", words):
        return False
    paths = [word for word in words[1:] if not word.startswith("-")]
    if not paths or not all(_person_path(path) for path in paths):
        return False
    original_text, original_bases = list(_BASE_TEXT), list(_EXTRA_BASES)
    try:
        return all(_classify("read_file", {"path": path}).action == ALLOW for path in paths)
    finally:
        _BASE_TEXT[:] = original_text
        _EXTRA_BASES[:] = original_bases


def _source_reader(command: str) -> bool:
    """`cat|head|grep|rg|ls ... <Qosha's own code>`: one plain reader whose every path is Qosha's code."""
    words = _plain_words(command)
    if not words or words[0].rsplit("/", 1)[-1] not in _SOURCE_READERS or "/" in words[0]:
        return False
    paths = [w for w in words[1:] if not w.startswith("-") and ("/" in w or w.startswith("~"))]
    return bool(paths) and all(source_path(w, folder_ok=True) for w in paths)


# Owner order: Qosha's own settings change when Ren asks, through an Approve card showing exactly what changes. Only
# a change that would switch off Qosha's approval guard itself (G1's enforcement) is refused.
SETTINGS_CLI = re.compile(r"^(?:hermes|qosha)\s+config\s+set\s+(?P<key>[A-Za-z0-9_.\-]{1,120})\s+(?P<value>.{0,2000})$", re.S)
_SECRETISH_KEY = re.compile(r"key|token|secret|passw|credential|auth", re.I)


def _guard_switched_off(cfg: Any) -> bool:
    """GPT R1 #1: exactly as the engine reads it (hermes_cli/plugins.py): plugins.enabled must be a LIST holding the
    string "qosha", plugins.disabled (if any) a list without it, and the plugin's own entry must not turn it off."""
    plugins = cfg.get("plugins") if isinstance(cfg, dict) else None
    if not isinstance(plugins, dict):
        return True
    enabled, disabled = plugins.get("enabled"), plugins.get("disabled", [])
    if not isinstance(enabled, list) or "qosha" not in [x for x in enabled if isinstance(x, str)]:
        return True
    if disabled is not None and (not isinstance(disabled, list) or "qosha" in disabled):
        return True
    entry = (plugins.get("entries") or {}).get("qosha") if isinstance(plugins.get("entries") or {}, dict) else None
    return isinstance(entry, dict) and entry.get("enabled") is False


def _flat(d: Any, pre: str = "") -> Dict[str, Any]:
    """Settings as dotted key -> value (lists and scalars are values)."""
    if not isinstance(d, dict) or not d:
        return {pre: d} if pre else {}
    out = {}
    for k, v in d.items():
        key = "%s.%s" % (pre, k) if pre else str(k)
        out.update(_flat(v, key) if isinstance(v, dict) and v else {key: v})
    return out


_SECRET_VALUE = re.compile(r"sk-|AIza|gh[pousr]_|xox[abposr]-|ya29\.|(?:sk|rk|pk)_(?:live|test)_|-----BEGIN|eyJ[A-Za-z0-9_\-]{10,}\.")


def _shown(key: str, value: Any) -> str:
    """Structurally redact both old and new values, including secret fields nested inside lists."""
    def clean(name, item):
        if _SECRETISH_KEY.search(name) or "env" in name.lower().split("."):
            return "(hidden)"
        if isinstance(item, dict):
            return {k: clean(str(k), v) for k, v in item.items()}
        if isinstance(item, list):
            return [clean("", v) for v in item]
        if isinstance(item, str) and _SECRET_VALUE.search(item):
            return "(hidden)"
        return item
    shown = clean(key, value)
    return shown if isinstance(shown, str) else json.dumps(shown, ensure_ascii=False)


def settings_change(tool: str, args: Any, home_override=None) -> Optional[Verdict]:
    """A change to Qosha's settings (config.yaml): HOLD as settings.change listing exactly the keys that change (never
    the rest of the file, GPT R1 #2/#7), or DENY when it would switch off the guard; None when not a settings change.
    The executor applies exactly these key changes to the file it finds, only if the file is unchanged since."""
    a = args if isinstance(args, dict) else {}
    hp = [p for p in str(home_override).split("/") if p] if home_override is not None else _home_parts()
    if not hp:
        return None
    cfg_path = "/" + "/".join(hp + ["config.yaml"])
    key = value = new_cfg = None
    if tool == "qosha_change_setting":
        key, value = str(a.get("key") or "").strip(), a.get("value")
    elif tool == "terminal" and isinstance(a.get("command"), str):
        m = SETTINGS_CLI.match(a["command"].strip())
        if not m:
            return None
        key = m.group("key")
        try:
            value = " ".join(shlex.split(m.group("value")))
        except ValueError:
            return Verdict(DENY, "Give qosha_change_setting the setting key display.streaming and value false, or ask Qosha to change that setting.")
    elif tool in ("write_file", "patch") and any(
            isinstance(a.get(k), str) and os.path.realpath(os.path.expanduser(a[k])) == os.path.realpath(cfg_path)
            for k in ("path", "file_path")):
        if tool == "patch" or not isinstance(a.get("content"), str):
            return Verdict(DENY, "Change Qosha's settings with qosha_change_setting (key and value) or by writing the "
                                 "whole settings file with write_file; the person approves the exact change on a card.")
        new_cfg = a.get("content")
    else:
        return None
    import yaml
    try:
        with open(cfg_path, encoding="utf-8") as fh:
            old_text = fh.read()
        cfg = yaml.safe_load(old_text) or {}
    except (OSError, yaml.YAMLError):
        return Verdict(DENY, "Qosha's settings file can't be read right now, so nothing was changed.")
    if not isinstance(cfg, dict):
        return Verdict(DENY, "Qosha's settings file isn't a settings map, so nothing was changed.")
    if new_cfg is None:
        if not key or not re.fullmatch(r"[A-Za-z0-9_\-]+(\.[A-Za-z0-9_\-]+)*", key):
            return Verdict(DENY, "Name the setting by its key, e.g. display.streaming.")
        try:
            parsed = yaml.safe_load(value) if isinstance(value, str) else value
        except yaml.YAMLError:
            parsed = value
        new = json.loads(json.dumps(cfg, default=str))
        node = new
        for k in key.split(".")[:-1]:
            if not isinstance(node.get(k), dict):
                node[k] = {}
            node = node[k]
        node[key.split(".")[-1]] = parsed
    else:
        try:
            new = yaml.safe_load(new_cfg) or {}
        except yaml.YAMLError:
            return Verdict(DENY, "The new settings text isn't valid settings (YAML), so nothing was changed.")
        if not isinstance(new, dict):
            return Verdict(DENY, "The new settings text isn't a settings map, so nothing was changed.")
    if _guard_switched_off(new):
        return Verdict(DENY, "That change would switch off Qosha's approval guard (plugins.enabled must keep \"qosha\"), "
                             "which is what makes sends, deletes and payments wait for the person's Approve (rule G1). Every "
                             "other setting can be changed: ask for it and the person approves the change on a card.")
    def valid_keys(value):
        if isinstance(value, dict):
            return all(isinstance(k, str) and re.fullmatch(r"[A-Za-z0-9_\-]+", k) and valid_keys(v)
                       for k, v in value.items())
        if isinstance(value, list):
            return all(valid_keys(v) for v in value)
        return True
    if not valid_keys(cfg) or not valid_keys(new):
        return Verdict(DENY, "This settings map has keys the approval card cannot represent exactly; nothing changed.")
    before, after = _flat(json.loads(json.dumps(cfg, default=str))), _flat(json.loads(json.dumps(new, default=str)))
    sets = {k: v for k, v in after.items() if k not in before or before[k] != v}
    unsets = sorted(k for k in before if k not in after and not any(x.startswith(k + ".") for x in after))
    def contains_secret(key, value):
        if _SECRETISH_KEY.search(key) or "env" in key.lower().split("."):
            return True
        if isinstance(value, dict):
            return any(contains_secret(str(k), v) for k, v in value.items())
        if isinstance(value, list):
            return any(contains_secret("", v) for v in value)
        return isinstance(value, str) and bool(_SECRET_VALUE.search(value))
    if any(contains_secret(k, v) for k, v in sets.items()):
        return Verdict(DENY, "This change contains sign-in data (rule G2); it needs the private connector settings path, "
                             "so it cannot be placed in a readable approval card.")

    if not sets and not unsets:
        return Verdict(DENY, "That setting already has this value; nothing to change.")
    if len(sets) + len(unsets) > 40:
        return Verdict(DENY, "That is %d setting changes at once; one card shows at most 40. Change a few settings at "
                             "a time." % (len(sets) + len(unsets)))
    lines = ["%s: %s -> %s" % (k, _shown(k, before[k]) if k in before else "(not set)", _shown(k, v))
             for k, v in sorted(sets.items())] + ["%s: %s -> (removed)" % (k, _shown(k, before[k])) for k in unsets]
    if len("\n".join(lines)) > 200_000:
        return Verdict(DENY, "These changes exceed the approval card size; change fewer settings at a time.")
    one = next(iter(sets)) if len(sets) == 1 and not unsets else ""
    what = ("Change Qosha's setting %s to %s" % (one, _shown(one, sets[one]))) if one else \
        "Change %d of Qosha's settings" % (len(sets) + len(unsets))
    return Verdict(HOLD, "changes Qosha's settings", "settings.change",
                   {"file": "config.yaml", "before_sha256": hashlib.sha256(old_text.encode()).hexdigest(),
                    "set": sets, "unset": unsets, "body": "\n".join(lines), "what": what[:300]})


# Owner order: Qosha edits the person's files in their folders. The engine's own write tools may write there (lab.sb
# opens the home except dot entries, ~/Library, the lab, git folders, PATH folders and secret names); a file that RUNS
# (a script, a Makefile, package.json, anything already executable) waits for the person's Approve, because code
# written there would run later as the person, outside every sandbox (GPT R1 #6).
_RUNS_SUFFIX = SCRIPT_SUFFIXES + (".plist", ".scpt", ".applescript", ".tool", ".bat", ".ps1", ".fish", ".bashrc", ".zshrc",
                                  ".profile", ".service", ".desktop", ".app", ".workflow", ".lua", ".pyw")
_RUNS_NAMES = {"makefile", "gnumakefile", "justfile", "rakefile", "gemfile", "package.json", "pyproject.toml", "setup.py",
               "setup.cfg", "dockerfile", "docker-compose.yml", "docker-compose.yaml", "compose.yaml", "tox.ini",
               "noxfile.py", "conftest.py", "procfile", "vagrantfile", "taskfile.yml", "build.gradle", "pom.xml"}


def runs_later(path: str) -> bool:
    name = os.path.basename(path).lower()
    if name.endswith(_RUNS_SUFFIX) or name in _RUNS_NAMES:
        return True
    try:
        st = os.stat(path)
        return bool(st.st_mode & 0o111) and not os.path.isdir(path)
    except OSError:
        return False


def person_write(tool: str, args: Any) -> Optional[Verdict]:
    """write_file/patch on the person's own files outside Qosha's folders: ALLOW (lab.sb is the boundary), a card for a
    file that runs, None when this is not such a write."""
    if tool not in ("write_file", "patch") or not isinstance(args, dict) or _shared_home():
        return None
    paths = [str(args.get(k)) for k in ("path", "file_path") if isinstance(args.get(k), str) and args.get(k)]
    if tool == "patch":
        for x in _strings(args):
            pp = _patch_paths(x)
            if pp:
                paths += pp
    files = _files_root()
    deleting_patch = tool == "patch" and bool(re.search(r"^\s*\*\*\*\s*Delete File:", "\n".join(_strings(args)), re.M))
    def allowed_path(x):
        real = os.path.realpath(os.path.expanduser(x))
        return _person_path(x) or (deleting_patch and files and real.startswith(files + "/"))
    if not paths or not all(allowed_path(x) for x in paths):
        return None
    if any(_cred_hit(x) for x in paths):
        return None                            # a sign-in name: the usual refusal
    if tool == "patch":
        text = "\n".join(_strings(args))
        if re.search(r"^\s*\*\*\*\s*(Delete File|Move to|Move File):", text, re.M):
            dels = [m.strip() for m in re.findall(r"^\s*\*\*\*\s*Delete File:\s*(.+?)\s*$", text, re.M)]
            if dels and not re.search(r"^\s*\*\*\*\s*(Update File|Add File|Move to|Move File):", text, re.M):
                full = [os.path.join(os.path.realpath(os.path.dirname(os.path.expanduser(d))), os.path.basename(d))
                        for d in dels]                 # a link is deleted itself, never what it points to
                return _delete_verdict(full, False)
            return Verdict(DENY, "Moving or deleting the person's files in the same patch as other changes isn't "
                                 "done in one step: deleting waits for their Approve (rule G1). Delete with its own "
                                 "patch (or `rm <path>`), and copy files with cp.")
        if any(runs_later(os.path.realpath(os.path.expanduser(x))) for x in paths):
            return Verdict(DENY, "This file runs as the person later (a script or build file), so changing it waits for "
                                 "their Approve: write the whole new text with write_file and Qosha shows them the "
                                 "change on a card.")
        return Verdict(ALLOW)
    target = os.path.realpath(os.path.expanduser(paths[0]))
    if not runs_later(target):
        return Verdict(ALLOW)
    content = args.get("content") if isinstance(args.get("content"), str) else ""
    if len(content) > 200_000:
        return Verdict(DENY, "That file is too large to show on one Approve card (over 200,000 characters).")
    import difflib
    try:
        with open(target, encoding="utf-8", errors="replace") as fh:
            old = fh.read()
        before = hashlib.sha256(open(target, "rb").read()).hexdigest()
    except OSError:
        old, before = "", None
    diff = "".join(difflib.unified_diff(old.splitlines(True), content.splitlines(True), target + " (now)",
                                        target + " (after Approve)", n=2))
    return Verdict(HOLD, "changes a file that runs", "file.write",
                   {"path": target, "before_sha256": before, "content": content, "body": diff or content,
                    "what": ("Change %s" if before else "Create %s") % target})


def _delete_payload(paths: List[str], recursive: bool) -> Dict[str, Any]:
    identities = {}
    present = []
    for path in paths:
        try:
            parent = os.stat(os.path.dirname(path), follow_symlinks=False)
            target = os.stat(path, follow_symlinks=False)
        except FileNotFoundError:
            continue  # An absent target is NOT approval to delete a later replacement.
        present.append(path)
        identities[path] = {"parent": [parent.st_dev, parent.st_ino],
                            "target": [target.st_dev, target.st_ino, target.st_mode]}
    return {"paths": present, "recursive": recursive, "identities": identities,
            "body": "Move to Trash:\n" + "\n".join(present),
            "what": "Move to Trash: %s" % (present[0] if len(present) == 1 else "%d items" % len(present))}


def _delete_verdict(paths: List[str], recursive: bool) -> Verdict:
    payload = _delete_payload(paths, recursive)
    if not payload['paths']:
        return Verdict(ALLOW, "The named files are already absent; nothing was removed.", "noop",
                       {"message": "The named files are already absent; nothing was removed."})
    return Verdict(HOLD, "moves files to Trash after approval", "file.delete", payload)


# Every deletion, including Your files, waits for the person's Approve (G1).

_DELETERS = {"rm", "rmdir", "unlink", "trash"}
_LAST_DELETE_IN_FILES = [False]


def delete_hold(tool: str, args: Any) -> Optional[Verdict]:
    """`rm [-r|-f] <paths>` naming anything outside Your files (in the person's home): HOLD as file.delete."""
    _LAST_DELETE_IN_FILES[0] = False
    if tool != "terminal" or not isinstance(args, dict) or not isinstance(args.get("command"), str):
        return None
    words = _plain_words(args["command"])
    if not words or words[0].rsplit("/", 1)[-1] not in _DELETERS or ("/" in words[0] and words[0] not in ("/bin/rm",)):
        return None
    opts = [w for w in words[1:] if w.startswith("-")]
    if any(o not in ("-r", "-R", "-f", "-rf", "-fr", "-Rf", "-v", "-d", "--") for o in opts):
        return None
    paths = [w for w in words[1:] if not w.startswith("-")]
    if not paths:
        return None
    wd = args.get("workdir") if isinstance(args.get("workdir"), str) and args.get("workdir") else ""
    base = os.path.expanduser(wd) if wd.startswith(("/", "~")) else _default_cwd()
    files = _files_root()
    person = os.path.realpath(os.path.expanduser("~"))
    full = []
    for w in paths:
        f = os.path.expanduser(w)
        f = os.path.normpath(f if f.startswith("/") else os.path.join(base, f))
        # the folder's real place, the last name as written (a link is deleted, not what it points to)
        f = os.path.join(os.path.realpath(os.path.dirname(f)), os.path.basename(f))
        full.append(f)
    if not all(x.startswith(person + "/") for x in full):
        return None                            # elsewhere: the usual checks (and the OS) decide
    hp = _home_parts()
    lab = os.path.realpath("/" + "/".join(hp[:-1])) if len(hp) > 1 else ""
    if lab and any((x == lab or x.startswith(lab + "/")) and not (files and x.startswith(files + "/")) for x in full):
        return None                            # Qosha's own folders: the usual refusal (its guard and sign-ins)
    return _delete_verdict(full, any(o in ("-r", "-R", "-rf", "-fr", "-Rf") for o in opts))


def _classify(tool_name: str, args: Any, google_scan: Optional[dict] = None, my_chrome: bool = False) -> Verdict:
    tool = (tool_name or "").strip()
    if tool == "video_analyze":
        # GPT review of GUARDVERIFY4 fixes: the engine reads a local video inside its own process and sends its bytes to
        # the model (tools/vision_tools.py): the same rule as read_file of that path (no media exception for videos)
        local = _vision_local_path(args, ("video_url", "video", "path"))
        if local is not None:
            raw = str(next((args.get(k) for k in ("video_url", "video", "path") if args.get(k)), "")).strip()
            raw = raw[len("file://"):] if raw.lower().startswith("file://") else raw
            for cand in dict.fromkeys([local, raw]):
                v = _classify("read_file", {"path": cand})
                if v.action != ALLOW:
                    return Verdict(DENY, v.reason or "Not allowed by Qosha: this video is outside your files.")
    if tool == "vision_analyze":
        # GUARDFIX3 (verifier r3 finding 6): a local image is a file read: the same rules as read_file of that path
        # (in the box: Your files only; on the Mac: not the engine's folders, not a sign-in)
        local = _vision_local_path(args)
        if local is not None and not _vision_media_ok(local):
            raw = str(args.get("image_url") or args.get("image") or args.get("path") or "").strip()
            raw = raw[len("file://"):] if raw.lower().startswith("file://") else raw
            for cand in dict.fromkeys([local, raw]):   # as the engine reads it, and as a file tool would read the name
                v = _classify("read_file", {"path": cand})
                if v.action != ALLOW:
                    return Verdict(DENY, v.reason or "Not allowed by Qosha: this image is outside your files.")
    strings = _strings(args if args is not None else {})
    joined = "\n".join(strings)
    _BASE_TEXT[:] = strings
    _EXTRA_BASES[:] = []
    # CAPFIX (owner order, council D50): a settings change is an Approve card; code the assistant wrote runs in Qosha's
    # code sandbox on the Mac (it holds no sign-in, so only a payment key in its text is refused; a payment service it
    # would reach is held by classify() below)
    sv = settings_change(tool, args)
    if sv is not None:
        return sv
    pw = person_write(tool, args)
    if pw is not None:
        return pw
    if CODEBOX and not _shared_home():
        dh = delete_hold(tool, args)               # a plain `rm <paths>` outside Your files: an Approve card
        if dh is not None:
            return dh
    if tool == "terminal" and not CODEBOX and not _shared_home() and isinstance(args, dict) and \
            isinstance(args.get("command"), str) and _deletes(args["command"]):
        dh = delete_hold(tool, args)
        if dh is not None:
            return dh
        words = [w for c in (_split_commands(args["command"]) or []) for w in c]
        if not _LAST_DELETE_IN_FILES[0] and any(_person_path(w) or w.startswith(("~", "..", "$HOME", "${HOME}"))
                                                for w in words):
            # GPT R1 #3 with the code sandbox off: a deleting command that isn't a plain `rm <paths>` can't be checked
            return Verdict(DENY, "Deleting or moving files outside Your files waits for the person's Approve (rule G1): "
                                 "run `rm <path>` on its own and Qosha shows them a card. (Other deleting commands run "
                                 "in Qosha's code sandbox, which isn't running right now.)")
    cb = codebox_call(tool, args)
    if cb:
        if _payment_secret(joined):
            return Verdict(DENY, "This code holds a payment secret key; payments always wait for the person (payments rule), "
                                 "so Qosha never lets code use one. Pay from the payment service's own page instead.")
        return Verdict(ALLOW, "", "codebox", {"lang": cb[0]})
    if tool == "execute_code":
        # GPT r1: the engine keeps one code kernel per session, so a folder change in one call would carry into the
        # next, out of this guard's sight: execute_code may not change folders. Relative paths may also start from the
        # kernel's own temp folder or climb to the top of the disk.
        if "chdir" in _squash(joined) or re.search(r"(?m)^\s*%\s*(cd|pushd|popd)\b", joined):
            return Verdict(DENY, "Code run with execute_code can't change its working folder. Use full paths, or the "
                                 "terminal with a workdir.")
        import tempfile as _tf
        _EXTRA_BASES[:] = ["/", os.path.join(_tf.gettempdir(), "kernel")]

    hit = _cred_hit(joined) or _payment_secret(joined)
    if hit:
        return Verdict(DENY, "Qosha never lets the assistant read or use sign-in credentials (%s)." % hit)
    if _ALIAS_TEXT.search(joined) or _ALIAS_TEXT.search(_fold(joined)):
        # GUARDFIX3 (verifier r3 finding 1): macOS's second spellings of every folder (the Data volume's firmlinks, volfs
        # inode paths) carry none of the names the checks look for; the assistant never needs them
        return Verdict(DENY, "Not allowed by Qosha: use the folder's ordinary path (/Users/..., not /System/Volumes/Data/... "
                             "or /.vol/...).")
    if re.search(r"(?:^|[\s'\"=:(<>|;&`])/+proc(?:/|\b)|/dev/fd/|/dev/std(?:in|out|err)\b", joined) and tool in \
            CODE_TOOLS | WRITE_TOOLS | {"read_file", "search_files"}:
        # Opus r3 R3-3: a process's environment (/proc/<pid>/environ) holds the box's model key
        return Verdict(DENY, "System process information is not available to the assistant.")
    _wd = [args["workdir"]] if tool == "terminal" and isinstance(args, dict) and isinstance(args.get("workdir"), str) \
        and args.get("workdir") else []
    if tool in CODE_TOOLS | WRITE_TOOLS | {"read_file", "search_files"} and _reaches_proc(strings, _wd):
        return Verdict(DENY, "System process information is not available to the assistant.")   # GPT r3: ../../proc
    if tool in ("terminal", "process") and (re.search(
            r"(?:^|[\s;&|(){}`])(?:builtin\s+|command\s+)?(?:cd|pushd)\s+(?:-\S*\s+)*-(?:$|[\s;&|)}`])|"
            r"\b(?:popd|dirs)\b|OLDPWD|~[-+0-9]", joined) or any(_folder_history(x) for x in strings)):
        # Opus r4: the shell's folder history (cd -, ~-, popd, $OLDPWD) leads to a folder this guard can't see
        return Verdict(DENY, "Change folders by their full path; the folder history (cd -, popd, ~-) isn't available.")
    if tool in CODE_TOOLS and any(_dot_pattern(x) for x in strings):
        # Opus r5 N1: in older shells (the Mac's bash 3.2) `.?` and `.[.]` match `..`
        return Verdict(DENY, "Write `..` and hidden names literally, not as a pattern (.?, .[.], .*).")
    if tool == "skill_manage":
        return _skill_save(args)
    dh = delete_hold(tool, args)
    if dh is not None:
        return dh
    if tool in ("read_file", "search_files") and isinstance(args, dict):
        sp = [str(args.get(k)) for k in ("path", "file_path", "root", "target", "directory")
              if isinstance(args.get(k), str) and args.get(k)]
        if sp and all(source_path(x, folder_ok=tool == "search_files") for x in sp):
            return Verdict(ALLOW)              # CAPFIX D50 Q4: Qosha's own code (not a secret)
        if sp and not _shared_home() and all(_person_path(x) for x in sp):
            # CAPFIX (owner order): the person's own files anywhere in their home, outside Qosha's folders: read like
            # Hermes reads them. Words in the path ("qosha/", "sqlite", "config.yaml") are not a reason to refuse: the
            # sign-in stores are closed by lab.sb (D46) and by the credential names checked above.
            return Verdict(ALLOW)
    if tool == "terminal" and isinstance(args, dict) and isinstance(args.get("command"), str) and \
            (_source_reader(args["command"]) or _person_reader(args["command"])):
        return Verdict(ALLOW)
    if tool in CODE_TOOLS or tool in WRITE_TOOLS or tool in ("read_file", "search_files"):
        # D21: the engine home outside its open folders (automations, scripts, hooks, plugins, settings), by any path
        # GPT r4: only the folder the tool really takes (the terminal's and process's `workdir`); the engine ignores the
        # others (a file tool's `workdir`, a terminal's `cwd`), so they must not move where paths are judged from
        workdirs = [str(args.get("workdir"))] if tool == "terminal" and isinstance(args, dict) and \
            isinstance(args.get("workdir"), str) and args.get("workdir") != "" else []   # GPT r7: " " is a folder too
        # Opus r4 R4-1: the engine resolves a relative workdir (and "-") from the shell's own current or previous folder,
        # which this guard can't see: only a full path (or ~/...) is taken. GPT r5: `process` ignores workdir.
        if workdirs and not os.path.expanduser(workdirs[0]).startswith("/"):
            return Verdict(DENY, "Give the working folder as a full path (for example the Files folder's own path).")
        if tool in CODE_TOOLS:
            if _box_code_refusal(tool, args):   # GUARDFIX2 (council D45): the Mac lab too, until its own user
                if not _shared_home():
                    return Verdict(DENY, MAC_CODE_REFUSED)
                if any(w and w[0] in ("cd", "pushd", "popd", "chdir") for w in (_split_commands(
                        str(args.get("command") or "")) or []) if isinstance(args, dict)):
                    return Verdict(DENY, "In Qosha's cloud box, give the terminal a full-path workdir instead of cd "
                                         "(for example workdir \"/opt/data/files/Projects/demo\").")
                return Verdict(DENY, BOX_CODE_REFUSED)
            if _shared_home():
                out = _box_outside(tool, args)   # GUARDFIX2: only inside Your files (and reading skills)
                if out:
                    return Verdict(DENY, BOX_OUTSIDE_REFUSED.format(files=min(_box_roots()[0] or {""}), word=out))
            gread = _google_read_call(tool, args)   # GOOGLEFIX: the skill's exact reads only (see _google_read_call)
            command = args.get("command") if isinstance(args, dict) else None
            if tool == "terminal" and isinstance(command, str) and _moves_own_folder(command, _bases(workdirs, [])):
                return Verdict(DENY, "Moving or removing the folder a command works in (or one above it) is not "
                                     "allowed; give the paths from a folder that stays put.")
            if tool in ("terminal", "process") and isinstance(command, str) and \
                    _bulk_link_escape(command, _bases(workdirs, [])):
                return Verdict(DENY, "This folder or archive holds a link into Qosha's own folders, so commands that "
                                     "walk or unpack it are not run. Remove the link, or name single files.")
            if google_scan is not None:
                google_scan["binding"] = _google_hold_scan_binding(tool, args)
            if not gread and _home_check(strings, workdirs, True, [], google_scan=google_scan):
                return Verdict(DENY, SCRIPTS_REFUSED + _google_read_hint(tool, args))
            if not gread and _skills_write(tool, args, strings, workdirs, []):
                return Verdict(DENY, SKILLS_REFUSED)
            command = args.get("command") if isinstance(args, dict) else None
            plain_read = tool == "terminal" and isinstance(command, str) and _PLAIN_COMMAND.fullmatch(command.strip()) \
                and command.split()[0].rsplit("/", 1)[-1] in _SKILL_READERS \
                and _program_identity(command.split()[0]) in _SKILL_READERS
            if not plain_read and not gread and _runs_a_draft(strings, workdirs):
                return Verdict(DENY, "Skill drafts in Your files are text for a person to approve; they can't be run. "
                                     "Read one with read_file.")
        else:
            if _shared_home():
                out = _box_outside(tool, args)   # GUARDFIX2: only inside Your files (and reading skills)
                if out:
                    return Verdict(DENY, BOX_OUTSIDE_REFUSED.format(files=min(_box_roots()[0] or {""}), word=out))
            paths = [str(args.get(k)) for k in ("path", "file_path", "root", "target", "directory")
                     if isinstance(args, dict) and isinstance(args.get(k), str) and args.get(k)]
            for x in strings:
                pp = _patch_paths(x)
                if pp is None:
                    return Verdict(DENY, "Qosha could not read the files this patch changes, so it was not applied.")
                paths += pp
            if tool == "search_files":
                # a search walks everything under its root: the home itself or a folder above it would include it
                # GPT review r3: the engine also splits a path it can't find into several (". ~"): each part is a root
                paths = [x for q in paths for x in _search_parts(q)]
                hp = _home_parts()
                roots = paths or ["."]
                for r0 in roots:
                    r0 = os.path.expanduser(r0)
                    for c in ([r0] if r0.startswith("/") else [os.path.join(b, r0) for b in _bases(workdirs, [], False)]):
                        if hp and _in_home(_resolve(c), hp) in ("home", "above", "closed"):
                            return Verdict(DENY, SCRIPTS_REFUSED + " Search inside your files folder or another folder.")
            if _home_check([], workdirs, False, paths):
                return Verdict(DENY, SCRIPTS_REFUSED)
            if _skills_write(tool, args, strings, workdirs, paths):
                return Verdict(DENY, SKILLS_REFUSED)
    if tool in CODE_TOOLS:
        hit = next(filter(None, (_shell_cred_hit(s, globs=tool in ("terminal", "process")) or _loose_cred_hit(s)
                                 for s in strings)), None)
        if hit in ("commands fed to a shell", "a program fed as input", "nested commands"):
            return Verdict(DENY, "Commands given to a shell or interpreter as input (a pipe, a redirect, a here-document "
                                 "or a substitution) can't be checked, so they are not run while mail and calendar are "
                                 "connected. Run the command directly.")
        if hit:
            return Verdict(DENY, "Qosha never lets the assistant read or use sign-in credentials (%s, named through "
                                 "quotes, escapes, wildcards or variables)." % hit)

    if tool.startswith("mcp__") or tool.startswith("mcp_"):
        ident, entry = mcp_parse(tool)
        if ident and entry and entry.get("google_connector"):   # the "Qosha Google" server (the connector, D26)
            if _guard_hit(joined):
                return Verdict(DENY, OWN_DATA_REFUSED % "this connection's request")
            return _classify_google_mcp(ident["tool"], args)
        # mail and calendar go through Qosha's Google/Outlook connector only (a second path would skip its checks)
        mail = MCP_MAIL_STRICT if entry is not None else MCP_MAIL
        if mail.search(tool) and MCP_WRITE.search(tool):
            return Verdict(DENY, "Mail and calendar changes through connected apps need Qosha's approval and are "
                                 "not available to the assistant directly.")
        # the files server names the files folder by its full path (inside the lab home): that part of a path is not
        # a reference to Qosha's own folders; what follows it is still checked (live check, night job 3)
        if _guard_hit(_mcp_files_relative(args) if ident and entry and entry.get("files_folder_only") else joined):
            return Verdict(DENY, OWN_DATA_REFUSED % "this connection's request")
        return _classify_mcp(tool, ident, entry, args)

    if tool == "send_message":
        action = (args or {}).get("action", "send") if isinstance(args, dict) else "send"
        if action in ("list",):
            return Verdict(ALLOW)
        return Verdict(DENY, "Sending messages directly is not allowed. Draft the email with the google-workspace "
                             "`gmail send` command; Qosha holds it for a person to approve.")

    if tool in ("read_file", "search_files"):
        hit = _guard_hit(_files_relative_text(tool, args, joined))
        if hit and not re.search(r"/skills/[\w./-]+\.md\b", joined):
            return Verdict(DENY, OWN_DATA_REFUSED % repr(hit))
        return Verdict(ALLOW)

    if tool in WRITE_TOOLS:
        if _is_plain_document(tool, args):
            return Verdict(ALLOW)              # GUARDFIX: text in Your files (credentials and folders checked above)
        if OBFUSCATION.search(joined) or PY_STARTUP.search(joined):
            return Verdict(DENY, "Writing encoded code or program start-up files is not allowed while mail and calendar are connected.")
        text = _files_relative_text(tool, args, joined)
        # a skill draft (Your files/skill-drafts/<name>.md) is instructions for a person to approve, never run: it may
        # talk about Gmail or the calendar (GPT save-13); Qosha's own folders and settings stay off limits in it
        hit = _guard_hit(text) if _is_skill_draft(tool, args) else _mail_hit(text)
        if hit:
            return Verdict(DENY, "Writing files or skills that use mail or calendar access is not allowed (%r)." % hit)
        return Verdict(ALLOW)

    if tool in CODE_TOOLS:
        if tool == "process" and isinstance(args, dict) and args.get("action") in ("list", "poll", "log", "wait"):
            return Verdict(ALLOW)
        workdir = args.get("workdir") if isinstance(args, dict) and tool in ("terminal", "process") else None   # GPT r4
        command = None
        if isinstance(args, dict):
            command = args.get("command") if tool == "terminal" else None
            if tool == "terminal" and command is None:
                command = args.get("code")
        # Scripts the command runs: their contents count as part of the command.
        runs = _script_paths(joined, workdir if isinstance(workdir, str) else None)
        if tool == "terminal" and isinstance(command, str):   # GUARDFIX: a document run as a script is code too
            runs += [p for p in _run_operands(command, _bases([workdir] if isinstance(workdir, str) and workdir else [], []))
                     if p not in runs]
        for p in runs:
            if tool == "terminal" and (p.endswith(GAPI_SUFFIX) or p.endswith(SETUP_SUFFIX)):
                continue  # the engine's own script: its commands are classified below (reads run, writes are held)
            if _trusted_skill_script(p):
                continue  # GUARDFIX: the release's own skill code (its arguments are checked)
            body = _script_text(p)
            if body is None and os.path.exists(p):
                return Verdict(DENY, "Qosha could not check this script (too large or unreadable), so it was not run.")
            if body is not None and OBFUSCATION.search(body):
                return Verdict(DENY, "This script decodes or builds code at run time; not allowed while mail and calendar are connected.")
            if body is not None:
                if _home_check([body], [workdir] if isinstance(workdir, str) and workdir else [], True, []):
                    return Verdict(DENY, SCRIPTS_REFUSED)   # a script that uses the engine home (D21, R-cronpolicy2)
                if _cred_hit(body):
                    return Verdict(DENY, "This script reads sign-in credentials; not allowed.")
                if _mail_hit(body):
                    return Verdict(DENY, "This script uses mail or calendar access directly; not allowed. Use the "
                                         "google-workspace commands so sends are held for approval.")
        if OBFUSCATION.search(joined):
            return Verdict(DENY, "Encoded or dynamically built commands are not allowed while mail and calendar are "
                                 "connected. Write the command plainly.")
        if tool == "terminal" and isinstance(command, str):
            # where it runs matters too: a working folder inside the engine home, the lab or a sign-in folder makes a
            # harmless-looking relative path (`cat auth.json`) a credential read (GPT R-assist3)
            for k in ("workdir", "cwd", "dir", "directory", "working_directory", "path"):
                v = args.get(k) if isinstance(args, dict) else None
                if isinstance(v, str) and v.strip() and (_guard_hit(_open_relative(v.strip())) or _cred_hit(v)):
                    return Verdict(DENY, "Commands don't run inside Qosha's sign-in or engine folders (rule G2: sign-ins "
                                         "and keys live there). Run it in Your files or another of the person's folders.")
            return _classify_shell(command)
        hit = _mail_hit(joined)
        if hit:
            return Verdict(DENY, "Mail and calendar access from %s is not allowed (%r). Use the google-workspace "
                                 "commands in the terminal: reads run, sends wait for approval." % (tool, hit))
        return Verdict(ALLOW)

    if tool.startswith("browser_"):
        low = joined.lower()
        refused = ("Qosha's web browser doesn't open this Mac's own dashboard (its pages approve "
                   "actions: rule G1) or webmail and calendar sites (rule G2). To look at Qosha's own "
                   "screens use qosha_self_view (screenshot, page structure, text); for mail and calendar "
                   "use Qosha's Google tools.")
        if re.search(r"(localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\]|accounts\.google|myaccount\.google|/api/plugins)",
                     low) or _guard_hit(joined):
            return Verdict(DENY, refused)
        if not my_chrome and re.search(r"(mail\.google|calendar\.google|gmail\.com|outlook\.|office\.com)", low):
            return Verdict(DENY, refused, "webmail")     # lifted only in the person's own Chrome (hook.py)
        return Verdict(ALLOW)

    if tool == "cronjob":
        why = _cron_refusal(args)
        if why:
            return Verdict(DENY, CRON_REFUSED + " (" + why + ")")

    if tool in ("cronjob", "delegate_task"):
        text = joined
        hp = _home_parts()
        raw = os.path.expanduser(ENGINE_HOME or os.environ.get("HERMES_HOME", "")).rstrip("/")
        for name in (("files", "skills") if hp else ()):
            root = "/" + "/".join(hp + [name])
            for form in {root, os.path.realpath(root)} | ({raw + "/" + name} if raw.startswith("/") else set()):
                text = re.sub(re.escape(form) + r"(?=/|\b)", name + ":", text)   # its full path names the lab home
        hit = _guard_hit(text)
        if hit or OBFUSCATION.search(joined):
            return Verdict(DENY, "Scheduling or delegating work on Qosha's own settings is not allowed (%r)." % (hit or "encoded text"))
        return Verdict(ALLOW)

    # Any other tool (web search, kanban, ...): only credentials are checked (above).
    return Verdict(ALLOW)
