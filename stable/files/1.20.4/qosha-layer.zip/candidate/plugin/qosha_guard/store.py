"""Decisions waiting: the durable record of what the assistant asked to send (INTERFACES.md §4.2).

SQLite at $HERMES_HOME/qosha/decisions.sqlite (folder 700, file 600). The agent process writes `pending` rows through
the hook; the dashboard process reads them and moves each out of `pending` exactly once. Every change is also written
to an append-only event table (the audit trail and the Recent activity feed).
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional

KINDS = ("email.send", "email.reply", "calendar.create", "calendar.update", "calendar.delete", "app.action",
         "skill.save", "browser.action",
         # SENDFIX (6 Nov): forward, send a draft, save a draft; and the one "Reconnect Google" card (nothing to approve)
         "email.forward", "email.draft_send", "email.draft_save", "google.reconnect",
         # CAPFIX (owner order, 6 Nov): a change to Qosha's own settings; a delete outside Your files
         "settings.change", "file.delete", "file.write")
# SENDFIX (GPT R2 #11): "registering" = held, not yet shown: the Qosha connector has not confirmed its own copy
STATUSES = ("registering", "pending", "declined", "approved_not_sent", "sending", "sent", "failed")
FINAL = ("declined", "approved_not_sent", "sent", "failed")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS decisions (
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL, decided_at TEXT,
  summary TEXT NOT NULL, payload_json TEXT NOT NULL, payload_sha256 TEXT NOT NULL, source_json TEXT NOT NULL,
  result_json TEXT);
CREATE INDEX IF NOT EXISTS decisions_status ON decisions(status, created_at);
CREATE TABLE IF NOT EXISTS decision_events (
  seq INTEGER PRIMARY KEY AUTOINCREMENT, decision_id TEXT NOT NULL, at TEXT NOT NULL, event TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '');
CREATE TRIGGER IF NOT EXISTS decision_events_no_update BEFORE UPDATE ON decision_events
  BEGIN SELECT RAISE(ABORT, 'audit rows are append-only'); END;
CREATE TRIGGER IF NOT EXISTS decision_events_no_delete BEFORE DELETE ON decision_events
  BEGIN SELECT RAISE(ABORT, 'audit rows are append-only'); END;
"""


class StoreError(Exception):
    def __init__(self, code: str, message: str = ""):
        super().__init__(message or code)
        self.code = code


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def canonical(payload: Dict[str, Any]) -> str:
    return json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def payload_hash(payload: Dict[str, Any], kind: str = "") -> str:
    """What a person approves: the action kind and its exact payload (a changed kind is a different action)."""
    return hashlib.sha256(canonical({"kind": kind, "payload": payload}).encode("utf-8")).hexdigest()


def engine_home() -> Path:
    try:
        from hermes_constants import get_hermes_home  # the engine's own resolver (profiles, overrides)
        return Path(get_hermes_home())
    except Exception:
        env = os.environ.get("HERMES_HOME")
        if not env:
            raise StoreError("no_home", "HERMES_HOME is not set")
        return Path(env)


def db_path(home: Optional[Path] = None) -> Path:
    return (home or engine_home()) / "qosha" / "decisions.sqlite"


@contextmanager
def connect(home: Optional[Path] = None) -> Iterator[sqlite3.Connection]:
    path = db_path(home)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    fresh = not path.exists()
    old = os.umask(0o077)
    try:
        conn = sqlite3.connect(str(path), timeout=10, isolation_level=None)
    finally:
        os.umask(old)
    try:
        if fresh:
            os.chmod(path, 0o600)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=10000")
        conn.executescript(_SCHEMA)
        yield conn
    finally:
        conn.close()


def _event(conn: sqlite3.Connection, decision_id: str, event: str, detail: str = "") -> None:
    conn.execute("INSERT INTO decision_events(decision_id, at, event, detail) VALUES (?,?,?,?)",
                 (decision_id, now_iso(), event, detail[:500]))


def _row(r: sqlite3.Row) -> Dict[str, Any]:
    return {"id": r["id"], "kind": r["kind"], "status": r["status"], "created_at": r["created_at"],
            "decided_at": r["decided_at"], "summary": r["summary"], "payload": json.loads(r["payload_json"]),
            "payload_sha256": r["payload_sha256"], "source": json.loads(r["source_json"]),
            "result": json.loads(r["result_json"]) if r["result_json"] else None}


def summarize(kind: str, p: Dict[str, Any]) -> str:
    if kind == "email.send":
        return 'Send "%s" to %s' % (p.get("subject", ""), p.get("to", ""))
    if kind == "email.reply":
        return 'Reply "%s" to %s' % (p.get("subject", ""), p.get("to", ""))
    if kind == "email.forward":
        return 'Forward "%s" to %s' % (p.get("subject", ""), p.get("to", ""))
    if kind == "email.draft_send":
        return 'Send the draft "%s" to %s' % (p.get("subject", ""), p.get("to", ""))
    if kind == "email.draft_save":
        return 'Save the draft "%s" in Gmail' % p.get("subject", "")
    if kind == "google.reconnect":
        return "Reconnect Google to allow sending"
    if kind == "calendar.create":
        return 'Add "%s" to the calendar (%s)' % (p.get("summary", ""), p.get("start", ""))
    if kind == "calendar.update":
        return 'Change the calendar event "%s"' % (p.get("event_summary") or p.get("event_id", ""))
    if kind == "calendar.delete":
        return 'Delete the calendar event "%s"' % (p.get("event_summary") or p.get("event_id", ""))
    if kind == "app.action" and p.get("payment_host"):   # a terminal, code or browser call to a payment service
        return "Wants to reach a payment service: %s. Nothing was sent yet." % p["payment_host"]
    if kind == "app.action":
        return "%s: %s" % (p.get("server_label") or p.get("server", ""), p.get("tool", ""))
    if kind == "skill.save":
        return 'Add the skill "%s" to your library' % p.get("name", "")
    if kind in ("settings.change", "file.delete", "file.write"):   # CAPFIX (owner order): made by the guard, never by the assistant
        return str(p.get("what") or kind)[:300]
    if kind == "browser.action":   # a click, submit or held link in Qosha's own Chrome (BROWSER job, BROWSERCHROME)
        site = str(p.get("site") or "")
        if p.get("action") == "show":
            w = "Open %s in your browser" % (p.get("target_url") or site)
        elif p.get("action") == "signin":
            w = "Use your sign-in on %s for %s minutes: %s" % (p.get("origin") or site, p.get("minutes") or "", p.get("target_url") or "")
        elif p.get("action") == "open":
            w = "Open %s" % (p.get("target_url") or site)
        elif p.get("action") == "submit":
            w = 'Submit the form on %s ("%s")' % (site, (p.get("element") or {}).get("text") or "form")
        else:
            w = 'Click "%s" on %s' % ((p.get("element") or {}).get("text") or "item", site)
        return ("Payment: " if p.get("payment") else "") + w
    return kind


def record(kind: str, payload: Dict[str, Any], source: Dict[str, Any], home: Optional[Path] = None,
           status: str = "pending") -> Dict[str, Any]:
    """Record a held action as pending (or "registering": not shown until publish()). An identical waiting payload
    returns the existing decision (agent retries)."""
    if kind not in KINDS:
        raise StoreError("bad_kind", kind)
    if status not in ("pending", "registering"):
        raise StoreError("bad_status", status)
    digest = payload_hash(payload, kind)
    with connect(home) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            r = conn.execute("SELECT * FROM decisions WHERE status IN ('pending', 'registering') AND payload_sha256=? "
                             "AND kind=?", (digest, kind)).fetchone()
            if r:
                _event(conn, r["id"], "held_again")
                conn.execute("COMMIT")
                return _row(r)
            did = "d_" + secrets.token_hex(6)
            conn.execute("INSERT INTO decisions(id, kind, status, created_at, summary, payload_json, payload_sha256, "
                         "source_json) VALUES (?,?,?,?,?,?,?,?)",
                         (did, kind, status, now_iso(), summarize(kind, payload)[:300], canonical(payload), digest,
                          json.dumps({k: str(v)[:200] for k, v in source.items() if v}, sort_keys=True)))
            _event(conn, did, "held", kind)
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        return _row(conn.execute("SELECT * FROM decisions WHERE id=?", (did,)).fetchone())


def get(decision_id: str, home: Optional[Path] = None) -> Optional[Dict[str, Any]]:
    with connect(home) as conn:
        r = conn.execute("SELECT * FROM decisions WHERE id=?", (decision_id,)).fetchone()
        return _row(r) if r else None


def list_decisions(status: str = "pending", limit: int = 50, home: Optional[Path] = None) -> List[Dict[str, Any]]:
    with connect(home) as conn:
        if status == "all":
            rows = conn.execute("SELECT * FROM decisions ORDER BY created_at DESC, rowid DESC LIMIT ?", (limit,))
        else:
            rows = conn.execute("SELECT * FROM decisions WHERE status=? ORDER BY created_at DESC, rowid DESC LIMIT ?",
                                (status, limit))
        return [_row(r) for r in rows.fetchall()]


def counts(home: Optional[Path] = None) -> Dict[str, int]:
    today = datetime.now().astimezone().date().isoformat()
    with connect(home) as conn:
        pending = conn.execute("SELECT COUNT(*) FROM decisions WHERE status='pending'").fetchone()[0]
        resolved = sum(1 for r in conn.execute("SELECT decided_at FROM decisions WHERE decided_at IS NOT NULL")
                       if datetime.fromisoformat(r[0]).astimezone().date().isoformat() == today)
        return {"pending": pending, "resolved_today": resolved}


def claim(decision_id: str, expected_sha256: str, new_status: str, home: Optional[Path] = None) -> Dict[str, Any]:
    """Move a pending decision to `new_status` (sending | approved_not_sent | declined) exactly once."""
    if new_status not in ("sending", "approved_not_sent", "declined"):
        raise StoreError("bad_status", new_status)
    with connect(home) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            r = conn.execute("SELECT * FROM decisions WHERE id=?", (decision_id,)).fetchone()
            if not r:
                raise StoreError("not_found")
            if r["status"] != "pending":
                raise StoreError("not_pending")
            if new_status != "declined":
                stored = json.loads(r["payload_json"])
                if payload_hash(stored, r["kind"]) != r["payload_sha256"] or expected_sha256 != r["payload_sha256"]:
                    raise StoreError("payload_changed")
            conn.execute("UPDATE decisions SET status=?, decided_at=? WHERE id=? AND status='pending'",
                         (new_status, now_iso(), decision_id))
            _event(conn, decision_id, {"sending": "approved", "approved_not_sent": "approved_not_sent",
                                       "declined": "declined"}[new_status])
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        return _row(conn.execute("SELECT * FROM decisions WHERE id=?", (decision_id,)).fetchone())


def finish(decision_id: str, status: str, result: Dict[str, Any], home: Optional[Path] = None) -> Dict[str, Any]:
    """`sending` -> sent | failed. Never moves anything back to pending (at most one send)."""
    if status not in ("sent", "failed"):
        raise StoreError("bad_status", status)
    with connect(home) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            n = conn.execute("UPDATE decisions SET status=?, result_json=? WHERE id=? AND status='sending'",
                             (status, json.dumps(result, sort_keys=True), decision_id)).rowcount
            if n != 1:
                raise StoreError("not_sending")
            _event(conn, decision_id, status, (result.get("error") or result.get("message_id") or result.get("event_id")
                                               or result.get("deleted") or result.get("saved") or "")[:200])
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        return _row(conn.execute("SELECT * FROM decisions WHERE id=?", (decision_id,)).fetchone())


def publish(decision_id: str, home: Optional[Path] = None) -> int:
    """SENDFIX: the connector confirmed its own copy: the decision is shown, waiting for Approve."""
    with connect(home) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            n = conn.execute("UPDATE decisions SET status='pending' WHERE id=? AND status='registering'",
                             (decision_id,)).rowcount
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK")
            raise
    return n


def record_reconnect(session: str, need: str, source: Dict[str, Any], home: Optional[Path] = None) -> Dict[str, Any]:
    """SENDFIX (GPT R2 #12): the one "Reconnect Google" card of a chat, in one transaction: a card already waiting in
    this chat is returned, whatever it was for; else a new one."""
    with connect(home) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            for r in conn.execute("SELECT * FROM decisions WHERE kind='google.reconnect' AND status='pending'").fetchall():
                try:
                    sid = json.loads(r["source_json"]).get("session_id", "")
                except ValueError:
                    sid = ""
                if sid == (session or ""):
                    conn.execute("COMMIT")
                    return _row(r)
            payload = {"need": need, "session": session or ""}
            did = "d_" + secrets.token_hex(6)
            conn.execute("INSERT INTO decisions(id, kind, status, created_at, summary, payload_json, payload_sha256, "
                         "source_json) VALUES (?,?,?,?,?,?,?,?)",
                         (did, "google.reconnect", "pending", now_iso(), summarize("google.reconnect", payload),
                          canonical(payload), payload_hash(payload, "google.reconnect"),
                          json.dumps({k: str(v)[:200] for k, v in source.items() if v}, sort_keys=True)))
            _event(conn, did, "held", "google.reconnect")
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        return _row(conn.execute("SELECT * FROM decisions WHERE id=?", (did,)).fetchone())


def withdraw(decision_id: str, error: str, code: str, home: Optional[Path] = None) -> int:
    """SENDFIX (GPT R1 #11): a held action the Qosha connector did not register can never be approved: it is shown as
    not sent, in plain words, at once (never as a card whose Approve can only fail). Returns 1 if the row changed."""
    with connect(home) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            r = conn.execute("SELECT status FROM decisions WHERE id=?", (decision_id,)).fetchone()
            if not r or r["status"] not in ("pending", "registering"):
                conn.execute("COMMIT")
                return 0
            conn.execute("UPDATE decisions SET status='failed', decided_at=?, result_json=? WHERE id=? AND status IN "
                         "('pending', 'registering')",
                         (now_iso(), json.dumps({"error": error, "code": code}), decision_id))
            _event(conn, decision_id, "failed", error[:200])
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK")
            raise
    return 1


def resolve_reconnect(decision_id: str, home: Optional[Path] = None) -> int:
    """SENDFIX: a waiting "Reconnect Google" card is done once Google allows what it was for (nothing was approved or
    sent by it). Returns 1 if the row changed."""
    with connect(home) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            r = conn.execute("SELECT status, kind FROM decisions WHERE id=?", (decision_id,)).fetchone()
            if not r or r["kind"] != "google.reconnect" or r["status"] != "pending":
                conn.execute("COMMIT")
                return 0
            conn.execute("UPDATE decisions SET status='sent', decided_at=?, result_json=? WHERE id=? AND status='pending'",
                         (now_iso(), json.dumps({"reconnected": True}), decision_id))
            _event(conn, decision_id, "reconnected")
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK")
            raise
    return 1


def apply_outcome(decision_id: str, status: str, result: Dict[str, Any], home: Optional[Path] = None,
                  approved_as: str = "") -> int:
    """The Qosha connector's own record of what it did for an approved Google action (D26) -> this row and Recent
    activity. It only moves forward (pending -> sending -> sent | failed); a row already sent never changes. The
    connector's ledger, not this store, is what approves and limits a send. Returns 1 if the row changed."""
    if status not in ("sending", "sent", "failed"):
        raise StoreError("bad_status", status)
    with connect(home) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            r = conn.execute("SELECT status FROM decisions WHERE id=?", (decision_id,)).fetchone()
            if not r:
                raise StoreError("not_found")
            cur = r["status"]
            if cur == status or cur == "sent" or (status == "sending" and cur not in ("pending", "declined")):
                conn.execute("COMMIT")
                return 0
            if approved_as:   # this row was changed after the approval: show what the connector says was approved
                result = dict(result, changed_after_approval=True, approved_as=approved_as)
                conn.execute("UPDATE decisions SET summary=? WHERE id=?", (approved_as[:300], decision_id))
            conn.execute("UPDATE decisions SET status=?, decided_at=COALESCE(decided_at, ?), result_json=? WHERE id=?",
                         (status, now_iso(), json.dumps(result, sort_keys=True) if status != "sending" else None, decision_id))
            if cur == "pending":
                _event(conn, decision_id, "approved")
            if status != "sending":
                _event(conn, decision_id, status, (result.get("error") or result.get("message_id") or result.get("event_id")
                                                   or result.get("deleted") or "")[:200])
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        return 1


_EVENT_TITLES = {"held": "Held for approval", "held_again": "Asked again (still waiting)", "approved": "Approved",
                 "approved_not_sent": "Approved (sending was switched off)", "declined": "Declined",
                 "sent": "Sent after approval", "failed": "Approved, but not done"}


def recent_events(limit: int = 10, home: Optional[Path] = None) -> List[Dict[str, Any]]:
    """For the Recent activity card (INTERFACES.md §3.7): newest first."""
    with connect(home) as conn:
        rows = conn.execute("SELECT e.decision_id, e.at, e.event, e.detail, d.summary, d.kind, d.result_json FROM decision_events e "
                            "JOIN decisions d ON d.id = e.decision_id ORDER BY e.seq DESC LIMIT ?", (limit,)).fetchall()
    def title(r) -> str:
        t = _EVENT_TITLES.get(r["event"], r["event"])
        if r["event"] == "sent" and (r["kind"].startswith("calendar") or r["kind"] in ("app.action", "skill.save")):
            t = "Done after approval"
        if r["event"] == "sent" and r["kind"] == "browser.action":
            # a form Chrome could not confirm is never called sent (MYCHROME G5; Claude review R6 M2)
            try:
                res = json.loads(r["result_json"]) if r["result_json"] else {}
            except ValueError:
                res = {}
            if isinstance(res, dict) and res.get("outcome") == "unconfirmed":
                t = "Approved, not confirmed"
        t = "%s: %s" % (t, r["summary"])
        if r["event"] == "failed" and r["detail"]:
            t += " (%s)" % r["detail"]   # the plain-words reason
        return t
    return [{"kind": "decision", "title": title(r), "detail": r["event"], "at": r["at"], "ref": r["decision_id"]}
            for r in rows]
