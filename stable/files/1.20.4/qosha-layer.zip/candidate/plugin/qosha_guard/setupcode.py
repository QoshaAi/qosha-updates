"""One-time setup code for a new client (Ren, 17 Nov 2026: "the standard installer for everyone + a one-time setup code
that fetches that client's setup (keys, accounts, preferences) once, encrypted; nothing personal inside the
installer").

The code is four everyday words (about 40 bits, from the list below), for example "maple river candle orbit".
From the code alone both sides derive, with scrypt (slow on purpose, N=2^15, r=8, p=1): the object's name (an id that
reveals nothing about the code) and the AES-256-GCM key. The client's setup is one encrypted object at
<source>/setup/<id>.bin in the same bucket (and fallback) as updates: no server is needed, and nobody without the code
can find or read it. Inside the encrypted object is its own delete permission (in the bucket: a signed DELETE address,
valid 7 days), so the computer that used it deletes it right after the setup succeeds; a lifecycle rule deletes
anything left after 7 days, and the object carries its own expiry, checked here. A code is also remembered on this
computer as used. Values (keys) are written where the engine keeps them (.env) and are never shown or logged; the
person sees names only ("OpenRouter key added").
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

FORMAT = b"QSC1"
SALT = b"qosha-setup-code-v1"
SCRYPT = {"n": 2 ** 15, "r": 8, "p": 1, "maxmem": 128 * 1024 * 1024, "dklen": 64}
OBJECT_MAX = 256 * 1024
CONFIG_SECTIONS = ("model", "agent", "display", "tts", "stt", "browser", "memory", "providers")
ENV_KEY = re.compile(r"^[A-Z][A-Z0-9_]{1,63}$")

_WORDS = """
able acid acorn actor adult aerial afraid agent agree ahead aim air alarm album alert alien alley allow almond alpine
amber ample anchor angle animal ankle answer apple april apron arch arctic arena argue arm armor army arrow art aspen
atlas atom attic audio august aunt autumn avenue award awake axis baby bacon badge bag bagel baker balcony ball
bamboo banana band banjo bank barn barrel basil basin basket bath beach beacon bean bear beaver bed bee beetle bell
belt bench berry bicycle bird biscuit bishop blade blanket blaze blend blink block bloom blossom blue blush board
boat body bold bolt bonus book boost boot border bottle boulder bowl box brave bread breeze brick bridge brief
bright broom brother brown brush bubble bucket buddy budget buffalo bulb bundle bunny burger bus butter button cabin
cable cactus cafe cake calm camel camera camp canal candle candy cannon canoe canvas canyon cape captain car carbon
card cargo carpet carrot cart castle cat cedar cello cement cereal chair chalk champion chapter charm chart cheese
cherry chess chest chicken chief chili chimney chip choice chorus cider cinema circle citrus city civic clam clay
clever cliff climb clock cloud clover clown club coach coast cobalt cocoa coconut coffee coin comet comfort comic
compass cookie copper coral corn cotton couch country cousin cover cowboy crab cradle craft crane crayon cream
credit creek crew cricket crisp crown crystal cube cup cupboard curious curtain cushion cycle daisy dance dawn day
decade deck deer delta denim desert design desk dial diamond diary diesel dinner dish disk diver dock doctor dolphin
domain donkey door double dove dragon drama drawer dream dress drift drink drum duck dune dust eagle earth easel east
echo eclipse edge effort egg eight elbow elder elegant element elephant elevator elk ember emerald empire energy
engine enjoy entry envoy equal error escape essay estate ever exact exhibit exit expert fabric face fact fairy
falcon fame family fan fancy farm fashion father fault feather fence ferry festival fiber field fig film final
finger fire fish flag flame flash flat flavor fleet flight flint flock flower fluid flute focus fog folder forest
fork fortune forum fossil fox frame fresh friend frog frost fruit fuel future galaxy game garage garden garlic gate
gauge gem gentle giant gift ginger giraffe glacier glass globe glove glow goat gold golf goose gorilla gospel grain
grape graph grass gravity great green grid grill grocery group guard guest guide guitar habit hammer hamster hand
happy harbor harvest hat hawk hazel health heart hedge helmet hero heron hill hint hobby hockey holiday honey hood
hope horizon horn horse hotel hour house hub human humble hunt husky ice icon idea igloo image impact inch index
indoor infant ink inlet insect island ivory jacket jaguar jar jazz jeans jelly jewel job jockey joke journal journey
joy judge juice jungle junior jury kayak keen kettle key kid kidney king kiosk kit kitchen kite kitten kiwi knee
knife knot koala label lace ladder lady lagoon lake lamb lamp lance lantern laptop large latch laugh lava lawn layer
leaf learn leather lemon lens leopard letter level library lift light lilac lily limb lime linen lion liquid list
little lizard llama lobby lobster local lock locust lodge logic lonely loop lotus loud lounge love loyal lucky lumber
lunar lunch lyric machine magic magnet maize major mammal mango mansion maple marble march margin marine market mask
match meadow medal melody melon member memory mentor menu mercy merit mesa metal meteor method middle midnight mild
milk mill mimic mind mineral minute mirror mission mitten mixer model modern moment monitor monkey month moon moose
morning mosaic moss mother motion motor mountain mouse movie muffin mule museum music mustard myth nail napkin narrow
nation nature navy near nectar needle neon nephew nest net network neutral never next nickel night ninja noble noise
noodle normal north nose note novel number nurse nut oak oasis object ocean october office olive omega onion open
opera orange orbit orchard orchid organ origin osprey otter outdoor oval oven owl oxygen oyster pace pacific paddle
page paint palace palm panda panel panther paper parade parent park parrot party pasta pastel path patio pattern
peach peak peanut pear pebble pelican pencil penguin pepper perfect piano picnic picture piece pig pigeon pilot pine
pink pioneer pipe pirate pistachio pizza planet plant plaster plate play plaza pledge plum plume pocket poem poet
polar pole police pond pony popcorn poppy portal possum potato pottery powder praise prairie prism prize program
proud pudding pulse pumpkin pupil puppy purple puzzle pyramid quail quarter queen quest quick quiet quilt quiz
rabbit raccoon radar radio rail rain rainbow raisin ranch range rapid raven razor ready recipe record reef region
relax relay remote rescue resort rhythm ribbon rice rich ride ridge rifle ring ripple river road robin robot rocket
rodeo roof room rooster root rope rose rover royal rubber ruby rug ruler runner rural saddle safari saga sail salad
salmon salt sample sand satin saturn sauce savanna scale scarf school science scooter scout screen sea seal season
seat second secret seed senior sense sentence sequel shadow shark shell shelter sheriff shield ship shirt shore
shrimp signal silk silver simple siren sister skate sketch ski skill sky slate sled slipper slope smile smoke snack
snail snake snow soap soccer social sock sofa soft soil solar soldier solid sonic sound soup south space spark
sparrow speaker spice spider spinach spirit splash sponge spoon sport spring sprout spruce square squid squirrel
stable stadium staff stage stamp star statue steam steel stem step stereo stick stone stool storm story stove straw
stream street string studio sugar suit summer summit sun sunset super surf swamp swan sweater sweet swift swing
symbol table tablet taco tail talent tango tank tape target taxi tea teacher team teapot tennis tent term thermal
thunder ticket tide tiger timber time tiny toast today token tomato tomorrow tool tooth topic torch tornado tortoise
total tower town toy track tractor trade trail train tram travel tray treasure tree trend trial tribe trick trophy
truck trumpet trust truth tulip tuna tunnel turkey turtle tutor twelve twin type umbrella uncle unicorn union unit
universe upper urban useful valley value vanilla vapor vase vault velvet vendor venture venus verse vessel veteran
video view village vine violet violin virtual visa visit vista visual vital vivid vocal voice volcano voyage wagon
waiter walnut walrus wander warm wash wasp water wave wax weather web wedding week west whale wheat wheel whisper
white widget wild willow window wing winter wise wizard wolf wonder wood wool world worth wrap wren yacht yard year
yellow yoga yogurt young zebra zero zigzag zinc zipper zone zoo
"""
WORDS = sorted({w for w in _WORDS.split() if re.fullmatch(r"[a-z]{3,9}", w)})


class SetupError(Exception):
    """A plain-words reason the person can read."""


def normalize(code: str) -> str:
    words = [w for w in re.split(r"[^a-z]+", (code or "").lower()) if w]
    if len(words) != 4:
        raise SetupError("A setup code is four words, like: maple river candle orbit.")
    return "-".join(words)


def derive(code: str):
    """(object id, 32-byte key) from the code."""
    k = hashlib.scrypt(normalize(code).encode(), salt=SALT, **SCRYPT)
    return hashlib.sha256(b"id" + k[:32]).hexdigest()[:40], k[32:]


def new_code() -> str:
    assert len(WORDS) >= 1024
    return " ".join(secrets.choice(WORDS) for _ in range(4))


def _aes():
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    return AESGCM


def seal(oid: str, key: bytes, payload: dict) -> bytes:
    nonce = secrets.token_bytes(12)
    return FORMAT + nonce + _aes()(key).encrypt(nonce, json.dumps(payload).encode(), FORMAT + oid.encode())


def unseal(oid: str, key: bytes, blob: bytes) -> dict:
    if not blob.startswith(FORMAT) or len(blob) < 4 + 12 + 16:
        raise SetupError("That code didn't work.")
    try:
        data = _aes()(key).decrypt(blob[4:16], blob[16:], FORMAT + oid.encode())
        return json.loads(data)
    except Exception:
        raise SetupError("That code didn't work.")


def make_setup(preset: dict, days: int = 7, delete_base: str = "", signed_delete=None):
    """For the release tool: (code, object id, encrypted object, delete token).
    signed_delete(oid) -> URL: the bucket's signed DELETE address for that object (then no token is used); without
    it, the local stand-in's address and a random token."""
    code = new_code()
    oid, key = derive(code)
    if signed_delete:
        token, url = "", signed_delete(oid)
    else:
        token, url = secrets.token_urlsafe(24), "%s/setup/%s.bin" % (delete_base.rstrip("/"), oid)
    payload = {"schema": 1, "made": int(time.time()), "expires": int(time.time()) + days * 86400, "preset": preset,
               "delete": {"url": url, "token": token}}
    return code, oid, seal(oid, key, payload), token


# --- the client side -------------------------------------------------------------------------------------------------
def _home() -> Path:
    h = os.environ.get("HERMES_HOME")
    if h:
        return Path(h)
    from hermes_constants import get_hermes_home
    return Path(get_hermes_home())


def _state_path(home: Path) -> Path:
    (home / "qosha").mkdir(parents=True, exist_ok=True)
    return home / "qosha" / "setup.json"


def _state(home: Path) -> dict:
    try:
        s = json.loads(_state_path(home).read_text(encoding="utf-8"))
        return s if isinstance(s, dict) else {}
    except Exception:
        return {}


def _save(home: Path, s: dict) -> None:
    p = _state_path(home)
    tmp = p.with_name(".setup.json.tmp")
    tmp.write_text(json.dumps(s, indent=1), encoding="utf-8")
    os.replace(tmp, p)


def _sources(home: Path) -> list:
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("qosha_updater_cfg", Path(__file__).with_name("updater.py"))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        cfg = m.load_config(home)
        return [b for b in (cfg["primary"],) if b], m      # setup objects live in the bucket only
    except Exception:
        return [], None


def _fetch(url: str) -> bytes | None:
    """The object, or None when it is not there (404/403). Raises OSError when the source cannot be reached."""
    u = urllib.parse.urlsplit(url)
    if not (u.scheme == "https" or (u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost", "::1"))):
        return None
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({})) if u.hostname in ("127.0.0.1", "localhost") \
        else urllib.request.build_opener()
    try:
        with opener.open(urllib.request.Request(url, headers={"User-Agent": "Qosha-Setup/1"}), timeout=20) as r:
            data = r.read(OBJECT_MAX + 1)
            return data if len(data) <= OBJECT_MAX else None
    except urllib.error.HTTPError as e:
        if e.code in (403, 404, 410):
            return None
        raise OSError("source error %d" % e.code)


def _delete(d: dict) -> bool:
    url = (d or {}).get("url") or ""
    u = urllib.parse.urlsplit(url)
    if not (u.scheme == "https" or (u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost", "::1"))):
        return False
    h = {"User-Agent": "Qosha-Setup/1"}
    if d.get("token"):
        h["X-Qosha-Delete-Token"] = d["token"]
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({})) if u.hostname in ("127.0.0.1", "localhost") \
        else urllib.request.build_opener()
    try:
        with opener.open(urllib.request.Request(url, headers=h, method="DELETE"), timeout=20) as r:
            return r.status in (200, 204)
    except Exception:
        return False


def _set_env(home: Path, values: dict) -> list:
    p = home / ".env"
    lines = p.read_text(encoding="utf-8").splitlines() if p.exists() else []
    names = []
    for k, v in values.items():
        if not ENV_KEY.match(str(k)) or not isinstance(v, str) or "\n" in v or "\r" in v:
            continue
        lines = [ln for ln in lines if not re.match(r"^\s*(export\s+)?%s\s*=" % re.escape(k), ln)]
        lines.append("%s=%s" % (k, v))
        names.append(k)
    tmp = p.with_name(".env.qosha-tmp")
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    os.replace(tmp, p)
    return names


def _merge_config(home: Path, changes: dict) -> list:
    changes = {k: v for k, v in (changes or {}).items() if k in CONFIG_SECTIONS}
    if not changes:
        return []
    cfg = home / "config.yaml"
    try:
        from ruamel.yaml import YAML
        y = YAML()
        data = y.load(cfg.read_text(encoding="utf-8")) if cfg.exists() else {}
        data = data or {}

        def merge(dst, src):
            for k, v in src.items():
                if isinstance(v, dict) and isinstance(dst.get(k), dict):
                    merge(dst[k], v)
                else:
                    dst[k] = v
        merge(data, changes)
        import io
        buf = io.StringIO()
        y.dump(data, buf)
        text = buf.getvalue()
    except ImportError:
        import yaml
        data = yaml.safe_load(cfg.read_text(encoding="utf-8")) if cfg.exists() else {}
        data = data or {}
        for k, v in changes.items():
            if isinstance(v, dict) and isinstance(data.get(k), dict):
                data[k].update(v)
            else:
                data[k] = v
        text = yaml.safe_dump(data, sort_keys=False, allow_unicode=True)
    tmp = cfg.with_name(".config.yaml.setup-tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, cfg)
    return sorted(changes)


def _add_memory(home: Path, entries: list) -> int:
    entries = [" ".join(str(e).split())[:400] for e in (entries or []) if str(e).strip()][:30]
    if not entries:
        return 0
    d = home / "memories"
    d.mkdir(exist_ok=True)
    p = d / "USER.md"
    old = p.read_text(encoding="utf-8").strip() if p.exists() else ""
    parts = [x for x in old.split("\n§\n") if x.strip()] if old else []
    parts += [e for e in entries if e not in parts]
    p.write_text("\n§\n".join(parts) + "\n", encoding="utf-8")
    return len(entries)


ENV_LABELS = {"OPENROUTER_API_KEY": "OpenRouter key", "ANTHROPIC_API_KEY": "Anthropic key",
              "OPENAI_API_KEY": "OpenAI key", "GEMINI_API_KEY": "Gemini key", "GOOGLE_API_KEY": "Google AI key"}


def redeem(code: str, home: Path | None = None) -> dict:
    h = home or _home()
    s = _state(h)
    now = time.time()
    fails = [t for t in s.get("fails", []) if now - t < 600]
    if len(fails) >= 5:
        raise SetupError("Too many tries. Please wait a few minutes and try again.")
    try:
        oid, key = derive(code)
    except SetupError:
        raise
    if oid in s.get("used", []):
        raise SetupError("This code was already used on this computer.")
    bases, upd = _sources(h)
    blob, reached = None, False
    for b in bases:
        try:
            blob = _fetch("%s/setup/%s.bin" % (b.rstrip("/"), oid))
            reached = True
        except OSError:
            continue
        if blob:
            break
    if not blob:
        s["fails"] = fails + [now]
        _save(h, s)
        if not reached:
            raise SetupError("Qosha could not reach its setup service. Check the internet connection and try again.")
        raise SetupError("That code didn't work. Check the four words, or ask Qosha's team for a new code.")
    try:
        p = unseal(oid, key, blob)
    except SetupError:
        s["fails"] = fails + [now]
        _save(h, s)
        raise
    if p.get("schema") != 1 or not isinstance(p.get("preset"), dict):
        raise SetupError("That code is for a newer Qosha. Please update Qosha first.")
    if now > p.get("expires", 0):
        raise SetupError("That code has expired. Ask Qosha's team for a new one.")
    pre = p["preset"]
    done = []
    names = _set_env(h, pre.get("env") or {})
    done += ["%s added" % ENV_LABELS.get(n, n.replace("_", " ").title()) for n in names]
    secs = _merge_config(h, pre.get("config") or {})
    if secs:
        done.append("settings: %s" % ", ".join(secs))
    n = _add_memory(h, pre.get("memory_user") or [])
    if n:
        done.append("%d preference%s saved to memory" % (n, "" if n == 1 else "s"))
    ring = (pre.get("updates") or {}).get("ring")
    if ring and upd:
        try:
            upd.set_config({"ring": ring}, h)
            done.append("updates: %s" % ring)
        except Exception:
            pass
    deleted = _delete(p.get("delete") or {})
    s["used"] = (s.get("used") or []) + [oid]
    s["done"] = {"at": int(now), "client": str(pre.get("client") or "")[:80], "deleted": deleted, "items": done}
    s.pop("fails", None)
    _save(h, s)
    return {"ok": True, "items": done, "client": s["done"]["client"], "deleted_from_cloud": deleted}


def _sessions_count(home: Path) -> int:
    import sqlite3
    db = home / "state.db"
    if not db.exists():
        return 0
    try:
        c = sqlite3.connect("file:%s?mode=ro" % db.as_posix(), uri=True, timeout=2)
        try:
            return int(c.execute("select count(*) from sessions").fetchone()[0])
        finally:
            c.close()
    except Exception:
        return 1      # unknown: do not offer


def offer(home: Path | None = None) -> dict:
    h = home or _home()
    s = _state(h)
    show = not s.get("done") and not s.get("dismissed") and _sessions_count(h) == 0
    return {"offer": bool(show), "done": s.get("done")}


try:
    from fastapi import APIRouter, Body
    from fastapi.responses import JSONResponse as _JR

    router = APIRouter()

    def _ok(d, code=200):
        return _JR(status_code=code, content=d, headers={"Cache-Control": "no-store"})

    @router.get("/status")
    def _r_status():
        return _ok(offer())

    @router.post("/redeem")
    def _r_redeem(body: dict = Body(default={})):
        try:
            return _ok(redeem(str((body or {}).get("code") or "")))
        except SetupError as e:
            return _ok({"ok": False, "error": str(e)}, 400)

    @router.post("/dismiss")
    def _r_dismiss():
        h = _home()
        s = _state(h)
        s["dismissed"] = int(time.time())
        _save(h, s)
        return _ok(offer())
except Exception:
    router = None
