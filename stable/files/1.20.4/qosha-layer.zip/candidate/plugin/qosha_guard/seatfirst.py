"""Claude on the person's own subscription seat first, Qosha's API key only as fallback (Ren, 17:40 MST 4 Nov).

The engine already orders the two credentials that way (agent/credential_pool.py:2835-2866: CLAUDE_CODE_OAUTH_TOKEN
before ANTHROPIC_API_KEY) and already rotates its credential pool on a rate limit and comes back after the reset time.
Five things in the pinned engine stop that from working for Claude, all fixed here in the running engine (the
engine's files are not edited, like identity.py). 1-3 apply only to the configuration in SEAT_VARS below:

1. Before every request the engine re-reads the Anthropic token from the environment, seat always first
   (run_agent.py:6318-6365, called from run_agent.py:5650). Right after the pool rotates to the API key this puts the
   limited seat back, the request is refused again, and the pool then benches the API key for the seat's 429. Here,
   for the configuration managed (see SEAT_VARS), that re-read is replaced by one that follows the pool: the seat when
   it is usable, otherwise the credential the pool chose; when .env changed meanwhile (a renewed, added or removed
   token or key) the pool is loaded again with the engine's own loader first. The switch goes through the engine's own _swap_credential, which keeps the
   client, agent.api_key and the pool identity together, so a later failure is put on the right credential.
2. On the first rate limit the engine waits for the provider's retry-after (capped at 600 s,
   agent/conversation_loop.py:6693-6708) and retries the same limited credential before rotating
   (agent/agent_runtime_helpers.py:1288-1300). Here the first rate limit or usage/billing limit rotates at once when
   another credential is usable now (cooldowns judged the engine's way) and the limit lasts longer than
   SHORT_LIMIT_SECONDS; a very short limit keeps the engine's own wait-and-retry on the seat. A seat limit with no
   reset time benches the seat for SEAT_PROBE_SECONDS instead of the engine's hour.
3. A chat keeps one agent for many messages and the engine only picks a credential again when one fails, so after a
   failover the chat would stay on the API key. The pool-following re-read in 1 brings it back to the seat as soon as
   the seat's reset time has passed.
4. The engine tells an API key from a subscription token by its first letters: "sk-ant-api..." is a key, any other
   "sk-ant-..." is taken for a subscription token (agent/anthropic_credentials.py:56-80) and sent as a Bearer token
   with Claude Code's identity headers (agent/anthropic_adapter.py:758-768). Console keys issued in another shape
   (Qosha AI's s7-b4 key is one) would go the subscription way. Here the value the person put in ANTHROPIC_API_KEY is
   always an API key, sent with x-api-key as Anthropic documents for Console keys.
5. (found by the review) A seat token renewed in .env kept its old "dead" mark on disk, so later chats skipped it:
   see _patch_status_merge.
Fail-open: an engine without these names is left as it is. Only the "anthropic" provider is touched."""
import logging
import os
import sys
import time

log = logging.getLogger("qosha.seatfirst")

SHORT_LIMIT_SECONDS = 20


OAUTH_MODULES = ("agent.anthropic_credentials", "agent.anthropic_adapter", "agent.account_usage")


def _declared_api_key():
    try:
        from agent.credential_pool import get_env_prefer_dotenv
        return (get_env_prefer_dotenv("ANTHROPIC_API_KEY") or "").strip()
    except Exception:
        return ""


def _patch_oauth_detection():
    changed = []
    for name in OAUTH_MODULES:
        mod = sys.modules.get(name)
        orig = getattr(mod, "_is_oauth_token", None) if mod is not None else None
        if not callable(orig) or getattr(orig, "qosha_seatfirst", False):
            continue

        def is_oauth(key, _orig=orig):
            if key and isinstance(key, str) and key.strip() == _declared_api_key():
                return False   # the person declared this value an API key
            return _orig(key)

        is_oauth.qosha_seatfirst = True
        setattr(mod, "_is_oauth_token", is_oauth)
        changed.append(name + "._is_oauth_token")
    return changed


TOKEN_FIELDS = ("access_token", "refresh_token", "expires_at_ms", "expires_at", "last_refresh")
STATUS_FIELDS = ("last_status", "last_status_at", "last_error_code", "last_error_reason", "last_error_message",
                 "last_error_reset_at")


def _current_fingerprint(source):
    """Fingerprint of the value .env holds now for an env-sourced entry (None for other sources)."""
    if not isinstance(source, str) or not source.startswith("env:"):
        return None
    try:
        from agent.credential_pool import get_env_prefer_dotenv
        from agent.credential_persistence import fingerprint_secret_value
        value = (get_env_prefer_dotenv(source[4:]) or "").strip()
        return fingerprint_secret_value(value) if value else None
    except Exception:
        return None


def _patch_status_merge():
    """Saving the pool keeps a newer on-disk failure over the in-memory state unless the token changed
    (hermes_cli/auth.py:1747-1801), but for credentials from .env the token itself is never on disk, only its
    fingerprint, so the check never fires: a seat renewed in .env got its old "dead" mark copied back onto the new
    token, and every later chat skipped the renewed seat for the paid key. Here, when the fingerprints differ, the side
    holding the token that is in .env NOW wins: a writer with the current token keeps its state (the disk status was
    the old token's), a stale writer with the old token keeps the disk's state for the current token. Same
    fingerprints, or no current value to judge by: the engine's own merge. Anthropic, env credentials only."""
    mod = sys.modules.get("hermes_cli.auth")
    orig = getattr(mod, "_merge_disk_cooldown_state", None) if mod is not None else None
    if not callable(orig) or getattr(orig, "qosha_seatfirst", False):
        return []

    def merge(entry, disk_entry, provider_id):
        if provider_id == "anthropic" and isinstance(entry, dict) and isinstance(disk_entry, dict) \
                and entry.get("source") in SIGNIN_SOURCES:
            # a signed-in seat renews its token pair and the refresh token works once: a chat still holding the older
            # pair must not write it back over the newer one (the engine's merge keeps the writer's tokens whenever
            # they differ, hermes_cli/auth.py:1775-1779)
            try:
                newer = int(disk_entry.get("expires_at_ms") or 0) > int(entry.get("expires_at_ms") or 0)
            except (TypeError, ValueError):
                newer = False
            if newer and disk_entry.get("access_token") and disk_entry.get("access_token") != entry.get("access_token"):
                # the disk's newer pair keeps its own status too: this writer's failure was its OLD token's
                kept = dict(entry)
                for field in TOKEN_FIELDS + STATUS_FIELDS:
                    if field in disk_entry:
                        kept[field] = disk_entry[field]
                return kept
            return orig(entry, disk_entry, provider_id)
        if provider_id == "anthropic" and isinstance(entry, dict) and isinstance(disk_entry, dict):
            new, old = entry.get("secret_fingerprint"), disk_entry.get("secret_fingerprint")
            cur = _current_fingerprint(entry.get("source"))
            if new and old and new != old and cur:
                if new == cur:
                    return entry   # this writer holds the token now in .env: the disk status was the old token's
                if old == cur:     # a stale writer (old token): the disk already holds the current token's state
                    kept = dict(entry)
                    for field in ("secret_fingerprint",) + STATUS_FIELDS:
                        kept[field] = disk_entry.get(field)
                    return kept
        return orig(entry, disk_entry, provider_id)

    merge.qosha_seatfirst = True
    mod._merge_disk_cooldown_state = merge
    return ["hermes_cli.auth._merge_disk_cooldown_state"]


def _api_key_sent_as_key(agent):
    """An agent built before the detection was patched may hold the API key on the subscription path: rebuild it."""
    if not getattr(agent, "_is_anthropic_oauth", False):
        return False
    declared = _declared_api_key()
    if not declared or (getattr(agent, "_anthropic_api_key", "") or "").strip() != declared:
        return False
    agent._rebuild_anthropic_client()
    agent._is_anthropic_oauth = False
    return True


# The configurations this manages: at most one subscription seat and at most one Console API key, the key from the
# environment / .env (agent/credential_pool.py:3268-3393). The seat is either a setup-token in .env (Ren's Mac,
# checked by tests/seatfirst_live_check.py L1) or the person's own sign-in through the engine's sign-in
# (`auth add anthropic --type oauth`, agent/anthropic_credentials.py:933, stored as a "manual:hermes_pkce" pool entry
# on the box's own disk; the cloud boxes' Connect Claude page). Any other pool (Claude Code's own credential file,
# keys added by hand, two keys) is left to the engine's own behaviour, untouched.
SEAT_VARS = ("ANTHROPIC_TOKEN", "CLAUDE_CODE_OAUTH_TOKEN")
SIGNIN_SOURCES = ("manual:hermes_pkce",)
KEY_VARS = ("ANTHROPIC_API_KEY",)
# A seat limit that names no reset time: try the seat again after this long instead of the engine's 1-hour bench
# (agent/credential_pool.py:133-135). A 429 costs nothing, an hour on the API key does.
SEAT_PROBE_SECONDS = 300


def _probe_seconds():
    try:
        return max(30, int(os.environ.get("QOSHA_SEAT_PROBE_SECONDS", SEAT_PROBE_SECONDS)))
    except ValueError:
        return SEAT_PROBE_SECONDS


def _var(entry):
    src = getattr(entry, "source", "") or ""
    return src[4:] if src.startswith("env:") else ""


def _is_seat(entry):
    return entry is not None and (_var(entry) in SEAT_VARS or getattr(entry, "source", "") in SIGNIN_SOURCES)


def _managed(pool):
    """True for the one configuration managed here (see SEAT_VARS above)."""
    if pool is None or getattr(pool, "provider", "") != "anthropic":
        return False
    try:
        entries = pool.entries()
    except Exception:
        return False
    seats = [e for e in entries if _is_seat(e)]
    keys = [e for e in entries if _var(e) in KEY_VARS]
    # several seats are all the person's own (e.g. an older sign-in a running chat wrote back): any of them is fine,
    # the engine's fill-first selection picks the best-ranked usable one
    return bool(entries) and len(keys) <= 1 and len(seats) + len(keys) == len(entries) \
        and getattr(pool, "_strategy", "fill_first") == "fill_first"


def _usable(entry, now=None):
    """Usable now, judged the engine's way: not dead, has a key, and any cooldown is over."""
    status = getattr(entry, "last_status", None)
    if status == "dead" or not getattr(entry, "runtime_api_key", None):
        return False
    if status == "exhausted":
        try:
            from agent.credential_pool import _exhausted_until
            until = _exhausted_until(entry, sole_credential=False)
        except Exception:
            return False
        return until is None or (now or time.time()) >= until
    return True


def _entry(pool, entry_id):
    return next((e for e in pool.entries() if e.id == entry_id), None) if entry_id else None


def _env_values():
    """The managed variables set in .env / the environment, minus those the person removed with the engine's
    `auth remove` (the engine's loader skips those too, agent/credential_pool.py:3290-3300)."""
    from agent.credential_pool import get_env_prefer_dotenv
    try:
        from hermes_cli.auth import is_source_suppressed
    except Exception:
        def is_source_suppressed(_p, _s):
            return False
    out = {}
    for var in SEAT_VARS + KEY_VARS:
        value = (get_env_prefer_dotenv(var) or "").strip()
        if value and not is_source_suppressed("anthropic", "env:" + var):
            out[var] = value
    return out


def _signin_changed(pool):
    """A sign-in added, removed or renewed on disk by another process (the Connect Claude page, or another chat that
    renewed the seat's token) while this chat runs: then this chat's copy is stale (e.g. still holds the old token
    marked dead) and the pool is loaded again."""
    def key(e, get):
        if get(e, "source") in SIGNIN_SOURCES:
            return (get(e, "id"), get(e, "access_token") or "", str(get(e, "expires_at_ms") or ""))
        return (get(e, "id"), "", "")
    try:
        from hermes_cli.auth import read_credential_pool
        disk = {key(e, lambda x, k: x.get(k)) for e in read_credential_pool("anthropic") if isinstance(e, dict)}
    except Exception:
        return False
    return disk != {key(e, getattr) for e in pool.entries()}


def _fresh_pool(agent, pool):
    """A seat token or key renewed, added or removed in .env after this chat started (Ren runs `claude setup-token`
    again): the chat's pool still holds the old values, and a dead or benched old value would keep it on the paid key.
    Then the pool is loaded again with the engine's own loader, which seeds the current values and clears a renewed
    credential's old failure exactly as it does for a new chat (agent/credential_pool.py:3503-3566). Returns the pool
    to use, or None when the new configuration is not one managed here (then the engine's own refresh runs)."""
    same_env = _env_values() == {_var(e): e.runtime_api_key for e in pool.entries() if _var(e) and e.runtime_api_key}
    if same_env and not _signin_changed(pool):
        return pool
    from agent.credential_pool import load_pool
    fresh = load_pool("anthropic")
    if not _managed(fresh):
        return None
    agent._credential_pool = fresh
    return fresh


def _current(agent, pool):
    entry = _entry(pool, getattr(agent, "_credential_pool_entry_id", None))
    if entry is None:   # never rotated yet: the entry whose key the agent sends
        key = getattr(agent, "_anthropic_api_key", None) or getattr(agent, "api_key", None)
        entry = next((e for e in pool.entries() if e.runtime_api_key and e.runtime_api_key == key), None)
    return entry


def _note_credential(agent):
    """One log line when a chat's Claude credential changes: which kind and where it came from (the pool source name),
    never the value or an account name."""
    try:
        pool = getattr(agent, "_credential_pool", None)
        entry = _current(agent, pool) if pool is not None else None
        if entry is not None:
            note = "%s (%s)" % ("seat" if _is_seat(entry) else "API key", entry.source)
        else:
            note = "%s (not pooled)" % ("seat" if getattr(agent, "_is_anthropic_oauth", False) else "API key")
        if getattr(agent, "_qosha_seatfirst_note", None) != note:
            agent._qosha_seatfirst_note = note
            log.info("Claude credential in use: %s session=%s", note, getattr(agent, "session_id", "?"))
    except Exception:
        pass


def _patch_refresh(cls):
    orig = getattr(cls, "_try_refresh_anthropic_client_credentials", None)
    if not callable(orig) or getattr(orig, "qosha_seatfirst", False):
        return False

    def refresh(self):
        if getattr(self, "provider", None) != "anthropic":
            return orig(self)
        try:
            _patch_oauth_detection()
            _patch_status_merge()
            _api_key_sent_as_key(self)
        except Exception:
            pass
        pool = getattr(self, "_credential_pool", None)
        if not _managed(pool):
            return orig(self)
        try:
            chosen = _choose(self, pool)
            return orig(self) if chosen is None else chosen
        except Exception:
            return orig(self)
        finally:
            _note_credential(self)

    refresh.qosha_seatfirst = True
    cls._try_refresh_anthropic_client_credentials = refresh
    return True


RENEW_RETRY_SECONDS = 60


def _renewal_failed(entry):
    """A signed-in seat marked exhausted without an HTTP status: a failed token renewal (agent/credential_pool.py:2053),
    whether it happened in this chat's request or when the chat was created (hermes_cli/runtime_provider.py:2104)."""
    return (entry is not None and getattr(entry, "source", "") in SIGNIN_SOURCES
            and getattr(entry, "last_status", None) == "exhausted" and getattr(entry, "last_error_code", None) is None)


def _short_renewal_bench(pool):
    """Give every failed renewal a RENEW_RETRY_SECONDS bench instead of the engine's hour. Returns a seat whose current
    token is still valid despite the failed renewal (usable now), if any."""
    from dataclasses import replace
    valid, changed = None, False
    for e in list(pool.entries()):
        if not _renewal_failed(e):
            continue
        if e.last_error_reset_at is None:
            e2 = replace(e, last_error_reset_at=float(e.last_status_at or time.time()) + RENEW_RETRY_SECONDS)
            pool._replace_entry(e, e2)
            e, changed = e2, True
        if valid is None and int(e.expires_at_ms or 0) > int(time.time() * 1000) + 5000:
            valid = e
    if changed:
        try:
            pool._persist()
        except Exception:
            pass
    return valid


def _choose(agent, pool):
    """Before each request, in place of the engine's refresh (run_agent.py:6318-6365), which re-reads the token from the
    environment (seat setup-token first, then the API key, a signed-in seat only after both, agent/anthropic_credentials
    .py:812-845) and so undoes a failover, or on a box never uses the signed-in seat at all: follow the pool. The
    engine's own fill-first selection returns the seat whenever it is usable (it ranks first, agent/credential_pool.py
    :2835-2866), clears cooldowns that have ended and renews a signed-in seat's short-lived token
    (agent/credential_pool.py:2170-2392); otherwise the chat stays on the credential the pool chose.
    Returns the engine refresh's answer (True = client rebuilt), or None to hand over to the engine's own refresh."""
    pool = _fresh_pool(agent, pool)
    if pool is None:
        return None
    current = _current(agent, pool)
    if current is not None and not current.runtime_api_key:
        current = None   # its value was removed from .env (the loader keeps an empty row): never send an empty key
    _short_renewal_bench(pool)
    if any(_is_seat(e) and _usable(e) for e in pool.entries()):
        chosen = pool.select()   # fill-first: the best-ranked usable seat (seats rank before the key)
        target = chosen if chosen is not None else current
        still_valid = _short_renewal_bench(pool)   # select() may just have failed a renewal
        if still_valid is not None and not (target is not None and _is_seat(target) and target.id != still_valid.id):
            target = still_valid   # keep using the seat while its current token is valid
    elif _short_renewal_bench(pool) is not None:
        target = _short_renewal_bench(pool)
    elif current is not None:
        target = current
    else:
        target = pool.select()
    if target is None:
        return False
    if target.id == getattr(agent, "_credential_pool_entry_id", None) \
            and target.runtime_api_key == getattr(agent, "_anthropic_api_key", None):
        return False
    agent._swap_credential(target)   # sets the client, agent.api_key and the pool identity together (run_agent.py:6474)
    return True


def _limit_seconds(error_context):
    reset_at = (error_context or {}).get("reset_at")
    try:
        return float(reset_at) - time.time()
    except (TypeError, ValueError):
        return None


def _patch_recover(cls):
    orig = getattr(cls, "_recover_with_credential_pool", None)
    if not callable(orig) or getattr(orig, "qosha_seatfirst", False):
        return False

    def recover(self, *, status_code=None, has_retried_429=False, classified_reason=None, error_context=None, **kw):
        try:
            pool = getattr(self, "_credential_pool", None)
            reason = getattr(classified_reason, "value", classified_reason)
            limited = reason in ("rate_limit", "billing") or (reason is None and status_code in (429, 402))
            if limited and getattr(self, "provider", None) == "anthropic" and _managed(pool):
                current = _current(self, pool)
                now = time.time()
                others = [e for e in pool.entries() if current is None or e.id != current.id]
                left = _limit_seconds(error_context)
                if _is_seat(current) and left is None:
                    # no reset time named: bench the seat for a short probe window, not the engine's hour
                    error_context = dict(error_context or {}, reset_at=now + _probe_seconds())
                    left = _probe_seconds()
                if not has_retried_429 and any(_usable(e, now) for e in others) and (left is None or left > SHORT_LIMIT_SECONDS):
                    has_retried_429 = True   # rotate now instead of waiting out the limit on the same credential
        except Exception:
            pass
        return orig(self, status_code=status_code, has_retried_429=has_retried_429,
                    classified_reason=classified_reason, error_context=error_context, **kw)

    recover.qosha_seatfirst = True
    cls._recover_with_credential_pool = recover
    return True


def apply():
    """Patch the engine's agent class if it is loaded. Never imports it: plugins are loaded while the engine is still
    importing its agent module (run_agent.py:138 -> model_tools.py:248), so importing it from here deadlocks on the
    import lock. Returns the names patched."""
    changed = []
    mod = sys.modules.get("run_agent")
    cls = getattr(mod, "AIAgent", None) if mod is not None else None
    changed += _patch_oauth_detection()
    changed += _patch_status_merge()
    if cls is None:
        return changed
    if _patch_refresh(cls):
        changed.append("_try_refresh_anthropic_client_credentials")
    if _patch_recover(cls):
        changed.append("_recover_with_credential_pool")
    return changed


def pre_llm_call(**kwargs):
    """Once per turn, before the first model request: by then the agent class is loaded. Adds nothing to the turn."""
    try:
        apply()
    except Exception:
        pass
    return None
