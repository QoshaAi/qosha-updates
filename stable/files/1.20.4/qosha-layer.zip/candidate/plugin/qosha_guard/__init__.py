"""Qosha guard: Decisions waiting (non-negotiable 1). policy -> hook -> store -> executor. INTERFACES.md §4."""
