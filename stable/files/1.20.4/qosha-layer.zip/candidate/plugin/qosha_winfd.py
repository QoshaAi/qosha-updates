"""Qosha on Windows: a stand-in for folder descriptors (dir_fd), which Windows' Python does not have.

Qosha's Files, Projects and file-history code walks the files folder one folder at a time with descriptors
(os.open(folder), then os.open(name, dir_fd=folder), os.stat(name, dir_fd=...), ...) and never follows a link. On
Windows a folder cannot be opened that way, so every such call failed and the Files page answered "not available".

`OS` below behaves like the `os` module for those calls: a "folder descriptor" is a number that stands for the folder's
path; a name used with it must be one plain name (no slash, backslash, colon, "." or ".."); and a link (a symlink or a
junction: any reparse point) is never walked through or opened: it is refused the same way the no-follow flags refuse
it on a Mac. Everything else is passed to the real `os`. Part of the plugin since 17 Nov (written and tested on the
Windows test PC by the Windows build); files_api.py, projects_api.py, versions.py and projects_scope.py load it on Windows only.

Difference from the Mac: there the kernel checks "is this a link" and opens in one step; here it is a check and then
the open (a very short gap). It is the person's own computer and their own files folder.
"""
import errno
import os as _os
import stat as _stat
import threading

_REPARSE = getattr(_stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400)
_lock = threading.Lock()
_dirs = {}          # stand-in descriptor -> absolute folder path
_next = [1 << 24]   # far above any real descriptor number


def _is_link(st) -> bool:
    return _stat.S_ISLNK(st.st_mode) or bool(getattr(st, 'st_file_attributes', 0) & _REPARSE)


def _plain(name) -> str:
    name = _os.fsdecode(name)
    if not name or name in ('.', '..') or any(c in name for c in '/\\:\x00'):
        raise OSError(errno.EINVAL, 'not a plain name', name)
    return name


def _full(name, dir_fd):
    if dir_fd is None:
        return _os.fspath(name)
    with _lock:
        base = _dirs.get(dir_fd)
    if base is None:
        raise OSError(errno.EBADF, 'not a folder descriptor')
    return _os.path.join(base, _plain(name))


class _OS:
    O_DIRECTORY = 1 << 28      # made-up bits: only this stand-in reads them
    O_NOFOLLOW = 1 << 29
    O_NONBLOCK = 0
    O_CLOEXEC = getattr(_os, 'O_NOINHERIT', 0)

    def __getattr__(self, name):
        return getattr(_os, name)

    def open(self, path, flags, mode=0o777, *, dir_fd=None):
        full = _full(path, dir_fd)
        real = flags & ~(self.O_DIRECTORY | self.O_NOFOLLOW)
        try:
            st = _os.lstat(full)
        except FileNotFoundError:
            st = None
        if flags & self.O_DIRECTORY:
            if st is None:
                raise FileNotFoundError(errno.ENOENT, 'no such folder', full)
            if _is_link(st):
                raise OSError(errno.ELOOP, 'a link is not followed', full)
            if not _stat.S_ISDIR(st.st_mode):
                raise NotADirectoryError(errno.ENOTDIR, 'not a folder', full)
            with _lock:
                _next[0] += 1
                fd = _next[0]
                _dirs[fd] = _os.path.abspath(full)
            return fd
        if st is not None and (flags & self.O_NOFOLLOW) and _is_link(st):
            raise OSError(errno.ELOOP, 'a link is not followed', full)
        return _os.open(full, real | getattr(_os, 'O_BINARY', 0), mode)

    def close(self, fd):
        with _lock:
            if _dirs.pop(fd, None) is not None:
                return
        _os.close(fd)

    def fstat(self, fd):
        with _lock:
            p = _dirs.get(fd)
        return _os.lstat(p) if p is not None else _os.fstat(fd)

    def stat(self, path, *, dir_fd=None, follow_symlinks=True):
        full = _full(path, dir_fd)
        return _os.stat(full) if follow_symlinks else _os.lstat(full)

    def lstat(self, path, *, dir_fd=None):
        return _os.lstat(_full(path, dir_fd))

    def unlink(self, path, *, dir_fd=None):
        full = _full(path, dir_fd)
        try:
            _os.unlink(full)
        except PermissionError:
            st = _os.lstat(full)
            if getattr(st, 'st_file_attributes', 0) & _REPARSE:
                _os.rmdir(full)      # a folder link or junction: the link itself goes, never what it points to
            elif not (st.st_mode & _stat.S_IWRITE):
                _os.chmod(full, _stat.S_IWRITE)   # a read-only file
                _os.unlink(full)
            else:
                raise

    remove = unlink

    def mkdir(self, path, mode=0o777, *, dir_fd=None):
        _os.mkdir(_full(path, dir_fd), mode)

    def rmdir(self, path, *, dir_fd=None):
        _os.rmdir(_full(path, dir_fd))

    def link(self, src, dst, *, src_dir_fd=None, dst_dir_fd=None, follow_symlinks=True):
        _os.link(_full(src, src_dir_fd), _full(dst, dst_dir_fd))

    def rename(self, src, dst, *, src_dir_fd=None, dst_dir_fd=None):
        _os.rename(_full(src, src_dir_fd), _full(dst, dst_dir_fd))      # Windows: fails if dst exists

    def replace(self, src, dst, *, src_dir_fd=None, dst_dir_fd=None):
        _os.replace(_full(src, src_dir_fd), _full(dst, dst_dir_fd))

    def _where(self, path):
        if isinstance(path, int):
            with _lock:
                p = _dirs.get(path)
            if p is None:
                raise OSError(errno.EBADF, 'not a folder descriptor')
            return p
        return path

    def scandir(self, path='.'):
        return _os.scandir(self._where(path))

    def listdir(self, path='.'):
        return _os.listdir(self._where(path))


class _Fcntl:
    """The one fcntl call Qosha's file history uses: an exclusive, non-waiting lock on its lock file."""
    LOCK_EX, LOCK_NB, LOCK_UN, LOCK_SH = 2, 4, 8, 1

    def flock(self, fd, how):
        import msvcrt
        try:
            _os.lseek(fd, 0, 0)
            msvcrt.locking(fd, msvcrt.LK_UNLCK if how & self.LOCK_UN else msvcrt.LK_NBLCK, 1)
        except OSError as exc:
            if how & self.LOCK_UN:
                return
            raise BlockingIOError(errno.EAGAIN, 'locked by another writer') from exc


OS = _OS()
fcntl = _Fcntl()
