"""Qosha Council (P0, 8 Nov 2026). The plugin's register() (agent side) and dashboard/plugin_api.py (screens side) both
reach the council through load(), which loads the three modules once by path under fixed names. Both sides then share
ONE set of marked turns and jobs (a second copy would mark a turn the engine's hook never sees)."""
import importlib.util
import sys
import threading
from pathlib import Path

_LOCK = threading.Lock()
_FILES = (("qosha_council_core", "core.py"), ("qosha_council_seats", "seats.py"),
          ("qosha_council_integration", "integration.py"))


def load():
    with _LOCK:
        mod = sys.modules.get("qosha_council_integration")
        if mod is not None:
            return mod
        here = Path(__file__).resolve().parent
        for name, fname in _FILES:
            if name in sys.modules:
                continue
            spec = importlib.util.spec_from_file_location(name, here / fname)
            m = importlib.util.module_from_spec(spec)
            sys.modules[name] = m
            try:
                spec.loader.exec_module(m)
            except Exception:
                sys.modules.pop(name, None)
                raise
        return sys.modules["qosha_council_integration"]
