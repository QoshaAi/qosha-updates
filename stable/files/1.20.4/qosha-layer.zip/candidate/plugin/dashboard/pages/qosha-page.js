/* Qosha owner pages: small shared helpers (UAT 2 Nov). Theme, the dashboard session token (read from the parent
   dashboard on every request, never stored, logged or put in a URL), JSON requests, safe element building (text only,
   never HTML from data), plain dates, and navigation inside the dashboard. */
(function () {
  'use strict';
  // CONTRACT-ACCESS: the Access ended card on every Qosha page (qosha-access.js; Settings stays open)
  try { var qa = document.createElement('script'); qa.src = (document.currentScript && document.currentScript.src ? new URL('qosha-access.js?v=1.20.2b', document.currentScript.src).href : 'qosha-access.js?v=1.20.2b'); qa.defer = true; (document.head || document.documentElement).appendChild(qa); } catch (e) { /* the engine's own block still stops every answer */ }
  var Q = {};
  try { if (window.localStorage.getItem('qosha.theme') === 'dark') document.documentElement.classList.add('t-dark'); } catch (e) { /* light */ }
  window.addEventListener('message', function (ev) {
    if (ev.origin === window.location.origin && ev.data && typeof ev.data.qoshaTheme === 'string') {
      document.documentElement.classList.toggle('t-dark', ev.data.qoshaTheme === 'dark');
    }
  });
  Q.token = function () {
    try {
      var f = window;
      while (f.parent && f.parent !== f) {
        f = f.parent;
        var t = f.__HERMES_SESSION_TOKEN__;
        if (typeof t === 'string' && /^[\x21-\x7e]+$/.test(t)) return t;
      }
    } catch (e) { /* no readable dashboard parent */ }
    return null;
  };
  // where this Qosha runs, for the words: a page that knows it sets Q.where ('mac', 'cloud' or 'computer'; Chat does,
  // from the assistants API); until then a page served over https is the cloud box (the Mac's Qosha is plain http on
  // this computer), and otherwise the words name no place
  Q.where = '';
  function where() { return /^(mac|cloud|computer)$/.test(Q.where) ? Q.where : window.location.protocol === 'https:' ? 'cloud' : ''; }
  Q.api = function (method, path, body, opts) {
    var headers = {};
    var t = Q.token();
    if (t) headers['X-Hermes-Session-Token'] = t;
    var init = {method: method, credentials: 'same-origin', cache: 'no-store', headers: headers};
    if (body instanceof FormData) init.body = body;
    else if (body !== undefined) { headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(body); }
    if (opts && opts.signal) init.signal = opts.signal;
    return fetch(path, init).then(function (r) {
      return r.text().then(function (txt) {
        var data = null;
        try { data = txt ? JSON.parse(txt) : null; } catch (e) { data = null; }
        if (!r.ok) {
          var d = data && (typeof data.detail === 'string' ? data.detail : (data.error || ''));
          var err = new Error(Q.plainError(r.status, d));
          err.status = r.status;
          // the server's own sentence, for a caller that knows its route sends plain words (Ask Gemini does)
          err.detail = data && typeof data.detail === 'string' ? data.detail.slice(0, 300) : '';
          throw err;
        }
        return data;
      });
    }, function () {
      var w = where();
      throw new Error(w === 'cloud' ? 'Your cloud Qosha is not answering right now. Wait a minute, then try again.'
        : w === 'mac' || !w ? 'Qosha is not answering on this computer right now. Check that Qosha is running, then try again.'
        : 'Qosha is not answering on this computer right now. Check that Qosha is running, then try again.');
    });
  };
  Q.plainError = function (status, detail) {
    var w = where();
    if (status === 401 || status === 403) return w === 'cloud' ? 'This page needs to be opened inside your cloud Qosha (its sign-in is missing). Reload the page.'
      : 'This page needs to be opened inside Qosha (sign-in to this computer\'s Qosha is missing).';
    if (status === 404) return 'Not found. It may have been removed; reload the page.';
    if (status === 409) return 'That change isn\'t possible right now. Reload the page and try again.';
    // the engine's own error text can carry its internal names and paths: only a plain sentence is shown
    if (w === 'cloud') return 'Something went wrong in your cloud Qosha (error ' + status + '). Try again; if it keeps happening, tell Ren.';
    return 'Something went wrong on this computer (error ' + status + '). Try again; if it keeps happening, restart Qosha.';
  };
  // el('div', {class: 'x', onclick: fn, 'aria-label': 'y'}, 'text', child, ...): text is always text
  Q.el = function (tag, attrs) {
    var n = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v == null || v === false) return;
      if (k.slice(0, 2) === 'on' && typeof v === 'function') n.addEventListener(k.slice(2), v);
      else if (k === 'class') n.className = v;
      else if (k === 'text') n.textContent = v;
      else n.setAttribute(k, v === true ? '' : String(v));
    });
    for (var i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (c == null || c === false) continue;
      if (Array.isArray(c)) c.forEach(function (x) { if (x) n.appendChild(typeof x === 'string' ? document.createTextNode(x) : x); });
      else n.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
    }
    return n;
  };
  Q.clear = function (n) { while (n && n.firstChild) n.removeChild(n.firstChild); return n; };
  // plain dates: "Today 14:05", "Yesterday 09:12", "Mon 3 Nov", "3 Nov 2025"
  Q.when = function (v) {
    if (v == null || v === '') return '';
    var d = typeof v === 'number' ? new Date(v < 1e12 ? v * 1000 : v) : new Date(v);
    if (isNaN(d.getTime())) return '';
    var now = new Date(), day = 86400000;
    var start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    var hm = d.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
    if (d.getTime() >= start + day) {                 // the future (a next run): Tomorrow, a weekday, or a date
      if (d.getTime() < start + 2 * day) return 'Tomorrow ' + hm;
      if (d.getTime() < start + 7 * day) return d.toLocaleDateString([], {weekday: 'short', day: 'numeric', month: 'short'}) + ' ' + hm;
      return d.toLocaleDateString([], {day: 'numeric', month: 'short', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric'});
    }
    if (d.getTime() >= start) return 'Today ' + hm;
    if (d.getTime() >= start - day) return 'Yesterday ' + hm;
    if (d.getTime() >= start - 6 * day) return d.toLocaleDateString([], {weekday: 'short', day: 'numeric', month: 'short'});
    if (d.getFullYear() === now.getFullYear()) return d.toLocaleDateString([], {day: 'numeric', month: 'short'});
    return d.toLocaleDateString([], {day: 'numeric', month: 'short', year: 'numeric'});
  };
  // open a dashboard route (single-page navigation in the parent); a normal link when opened on its own
  Q.go = function (route) {
    var go = null;
    try { go = window.parent && window.parent !== window && window.parent.qoshaGo; } catch (e) { go = null; }
    if (typeof go === 'function') go(route); else window.location.href = route;
  };
  Q.status = function (node, text, isErr) {
    if (!node) return;
    node.textContent = text || '';
    node.classList.toggle('err', !!isErr && !!text);
    if (isErr && text) node.setAttribute('role', 'alert'); else node.setAttribute('role', 'status');
  };
  // the engine's name never on screen (Ren, 3 Nov 21:46): the same words as the dashboard shell (index.js), for
  // texts Qosha's pages show that the assistant made, e.g. a conversation's title. Display only.
  (function () {
    var H = 'h\u0065rmes', N = 'n\u006fus', HOME = '~/QoshaLab/home';
    function cased(word, like) {
      if (like === like.toUpperCase() && like !== like.toLowerCase()) return word.toUpperCase();
      return like.charAt(0) === like.charAt(0).toUpperCase() ? word.charAt(0).toUpperCase() + word.slice(1) : word;
    }
    var RULES = [
      // an address on the engine maker's site, or naming the engine: only a neutral host stays
      [new RegExp('https?://[^\\s"\'<>)]*(?:' + H + '|' + N + ')[^\\s"\'<>)]*', 'gi'), function (u) {
        var host = u.replace(/^https?:\/\//i, '').split(/[\/?#]/)[0];
        return new RegExp(H + '|' + N, 'i').test(host) ? 'the upstream website' : host + '/\u2026';
      }],
      [new RegExp('~/\\.' + H + '(?![A-Za-z0-9_])', 'gi'), function () { return HOME; }],
      [new RegExp('\\$\\{?' + H + '_HOME\\}?', 'gi'), function () { return HOME; }],
      // the engine maker's own models (e.g. "<maker>/<engine>-4-405b", "<engine> 3 70B") are not Qosha's: a neutral name
      [new RegExp('\\b' + N + ' ?research/' + H + '[- ]?', 'gi'), function () { return 'upstream/model-'; }],
      [new RegExp('\\b(?:' + N + '[- :]+)?' + H + '[- ]?(?=\\d)', 'gi'), function (m) { return cased('upstream model ', m); }],
      // who the assistant is: Qosha, by Qosha AI (only there: the maker's own models and services are never Qosha's)
      [new RegExp('\\b(I am|I\'m|I’m|you are|you\'re|you run on|this is|running on|runs on)\\s+' + H + '(?:[\\s_-]*agent)?,?\\s+\\(?(?:(?:built|made|created)\\s+)?by\\s+' + N + ' ?research\\)?', 'gi'),
       function (m, who) { return who + ' Qosha by Qosha AI'; }],
      // the engine's own docs and its program's module name (log lines) are the engine's, never Qosha's
      [new RegExp(H + '[\\s_-]*(?:agent[\\s_-]*)?(docs|documentation)\\b', 'gi'), function () { return 'upstream docs'; }],
      [new RegExp(H + '_cli\\b', 'gi'), function () { return 'engine'; }],
      [new RegExp(H + ' agent\\b', 'gi'), function (m) { return cased('qosha', m); }],
      [new RegExp('\\bthe ' + H + ' team\\b', 'gi'), function () { return 'the upstream team'; }],
      [new RegExp('@?(?<![A-Za-z])' + N + '[-_ ]?research\\b', 'gi'), function () { return 'the upstream project'; }],
      [new RegExp('(?<![A-Za-z])' + N + '[-_ ]?portal\\b', 'gi'), function (m) { return cased('engine portal', m); }],
      [new RegExp('\\b' + N + '-approved\\b', 'gi'), function (m) { return cased('curated', m); }],
      [new RegExp('(?<![A-Za-z])' + N + '[-_ ](?=[A-Za-z])', 'gi'), function () { return ''; }],
      [new RegExp('(?<![A-Za-z])' + N + '(?![A-Za-z])', 'gi'), function (m) { return cased('portal', m); }],
      [new RegExp(H, 'gi'), function (m) { return cased('qosha', m); }],
      [/\u2624/g, function () { return ''; }]];
    var HAS = new RegExp(H + '|(?<![A-Za-z])' + N + '|\u2624', 'i');
    Q.brand = function (t) { t = String(t == null ? '' : t); if (!HAS.test(t)) return t; for (var i = 0; i < RULES.length; i++) t = t.replace(RULES[i][0], RULES[i][1]); return t; };
  })();
  window.Qosha = Q;
})();
