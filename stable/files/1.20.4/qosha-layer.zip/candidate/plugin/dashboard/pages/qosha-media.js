/* Qosha: pictures, videos and files inside the chat (Ren, 20 Nov 2026: "it needs to behave exactly the same way
   claude does"). Used by chat.html:
     var m = QoshaMedia.prepare(text)      // the answer's media references swapped for placeholders
     ...QoshaMd.render(m.text)...
     QoshaMedia.attach(fragment, m)        // the placeholders become pictures, players and file cards
     QoshaMedia.thumbs(messageBox, files)  // the person's attached pictures as thumbnails in their message
   What becomes media (never inside code blocks or inline code, except a line that is only a quoted path):
     MEDIA:/absolute/path (or MEDIA:"path with spaces"), ![alt](local path or file://), and a line holding only an
     absolute path to a picture, video or audio file. Mac and Windows paths alike.
   A picture on the web (![alt](https://...)) stays a link card: Claude's apps don't show outside pictures inline.
   Bytes come from /api/plugins/qosha/media (media_api.py: Qosha's own folders only), fetched with the session header
   into a blob, so no token is ever in a URL. Everything is built from DOM nodes; no text becomes markup. */
(function () {
  'use strict';
  if (window.QoshaMedia) return;
  // the feature switch (slices: off until the last slice turns pictures in the chat on); off, nothing is changed
  var ENABLED = true;
  var API = '/api/plugins/qosha/media/';
  var IMG = /\.(png|jpe?g|gif|webp|bmp|avif|heic)$/i, VID = /\.(mp4|m4v|webm|mov|ogv)$/i, AUD = /\.(mp3|m4a|aac|wav|ogg|oga|opus|flac)$/i;
  var IMG_MAX = 40 * 1024 * 1024, PLAY_MAX = 300 * 1024 * 1024;
  var ABS = /^(?:\/|~\/|[A-Za-z]:[\\\/]|file:\/\/)/;
  var blobs = {};   // path -> {url, at}: one fetch per file per page

  function tok() {
    try { var f = window; if (typeof f.__HERMES_SESSION_TOKEN__ === 'string') return f.__HERMES_SESSION_TOKEN__;
      while (f.parent && f.parent !== f) { f = f.parent; if (typeof f.__HERMES_SESSION_TOKEN__ === 'string') return f.__HERMES_SESSION_TOKEN__; } } catch (e) {}
    return '';
  }
  function req(method, path, body, raw) {
    var h = {'X-Hermes-Session-Token': tok()}; if (body) h['Content-Type'] = 'application/json';
    return fetch(API + path, {method: method, headers: h, credentials: 'same-origin', cache: 'no-store', body: body ? JSON.stringify(body) : undefined})
      .then(function (r) {
        if (raw && r.ok) return r.blob();
        return r.json().catch(function () { return {}; }).then(function (d) { if (!r.ok) { var e = new Error(d.detail || ('HTTP ' + r.status)); e.data = d; throw e; } return d; });
      });
  }
  function q(p) { var pr = projDir(); return encodeURIComponent(p) + (pr ? '&project=' + encodeURIComponent(pr) : ''); }
  // the project folder of the chat showing this answer (chat.html sets QoshaMedia.project): Qosha's project rule
  function projDir() { try { return (window.QoshaMedia && window.QoshaMedia.project && window.QoshaMedia.project()) || null; } catch (e) { return null; } }
  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) { if (k === 'onclick') n.addEventListener('click', attrs[k]); else if (k === 'text') n.textContent = attrs[k]; else n.setAttribute(k, attrs[k]); });
    (kids || []).forEach(function (c) { if (c) n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return n;
  }
  function baseName(p) { return String(p).replace(/[\\\/]+$/, '').split(/[\\\/]/).pop() || p; }
  function size(n) { return n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(0) + ' KB' : n < 1073741824 ? (n / 1048576).toFixed(1) + ' MB' : (n / 1073741824).toFixed(1) + ' GB'; }

  // ---- finding media in the answer's text ----------------------------------------------------------------------
  function cleanPath(p) {
    p = String(p || '').trim();
    var m = /^(["'`])(.*)\1$/.exec(p); if (m) p = m[2];
    return p.replace(/[)\].,;:!?]+$/, function (t) { return /\.[A-Za-z0-9]+$/.test(p.slice(0, p.length - t.length)) ? '' : t; });
  }
  function mediaPath(p) { return IMG.test(p) || VID.test(p) || AUD.test(p); }
  function prepare(text, partial) {
    if (!ENABLED) return {text: String(text == null ? '' : text), items: [], nonce: ''};
    if (String(text == null ? '' : text).length > 100000) return {text: String(text), items: [], nonce: ''};   // shown as plain text (qosha-md.js MAX_LEN)
    var nonce = Math.random().toString(36).slice(2, 8).toUpperCase().replace(/[^A-Z]/g, 'Q');
    var items = [], lines = String(text == null ? '' : text).split('\n'), out = [], fence = null, group = null;
    function token(list) { return 'QMEDIA' + nonce + 'X' + list.join('Y') + 'XQ'; }
    function flush() { if (group) { out.push(''); out.push(token(group)); out.push(''); group = null; } }
    function add(item) { items.push(item); (group = group || []).push(items.length - 1); }
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i], t = line.trim(), f = /^(`{3,}|~{3,})/.exec(t);
      if (partial && i === lines.length - 1) { flush(); out.push(line); continue; }   // still arriving: left as text
      if (fence) { out.push(line); if (f && t.indexOf(fence) === 0) fence = null; continue; }
      if (f) { flush(); fence = f[1]; out.push(line); continue; }
      var found = [];
      // MEDIA: tags, on their own or inside the line (outside inline code)
      var rest = line.replace(/`[^`]*`/g, function (c) { return c.replace(/MEDIA:/g, 'MEDIA\u200b:'); });
      var mm, re = /MEDIA:\s*("([^"]+)"|'([^']+)'|`([^`]+)`|(\S[^\n]*?(?:\.[A-Za-z0-9]{1,5}))(?=\s*$|\s+(?:and|y|e)\s|[,;]\s)|(\S+))/g;
      var kept = rest.replace(re, function (all, _x, a, b, c, d, e) { found.push({kind: 'path', path: cleanPath(a || b || c || d || e)}); return ''; });
      // ![alt](target): local -> media; web -> a link card
      kept = kept.replace(/!\[([^\]\n]{0,200})\]\(\s*<?([^)\n>]+?)>?\s*\)/g, function (all, alt, target) {
        target = target.replace(/\s+"[^"]*"$/, '');
        if (/^https?:\/\//i.test(target)) found.push({kind: 'web', url: target, alt: alt});
        else if (ABS.test(target)) found.push({kind: 'path', path: cleanPath(target), alt: alt});
        else return all;
        return '';
      });
      // a line that is only an absolute media path (optionally quoted or in backticks, or a list bullet)
      if (!found.length) {
        var only = /^\s*(?:[-*]\s+)?(["'`]?)((?:\/|~\/|[A-Za-z]:[\\\/]|file:\/\/)[^"'`\n]+?)\1\s*$/.exec(line);
        if (only && mediaPath(only[2])) { found.push({kind: 'path', path: cleanPath(only[2])}); kept = ''; }
      }
      if (!found.length) { flush(); out.push(line.replace(/MEDIA\u200b:/g, 'MEDIA:')); continue; }
      var left = kept.replace(/MEDIA\u200b:/g, 'MEDIA:').replace(/^\s*[-*]\s*$/, '').trim();
      if (left) { flush(); out.push(left); }
      found.forEach(add);
      if (left) flush();
    }
    flush();
    return {text: out.join('\n'), items: items, nonce: nonce};
  }

  // ---- the elements ----------------------------------------------------------------------------------------------
  function blobOf(path, cap) {
    var b = blobs[path];
    if (b) return Promise.resolve(b);
    return req('GET', 'info?path=' + q(path)).then(function (d) {
      if (d.size > cap) { var e = new Error('too large'); e.data = {error: 'too_large', info: d}; throw e; }
      return req('GET', 'file?path=' + q(path), null, true).then(function (bl) {
        var u = URL.createObjectURL(bl); blobs[path] = {url: u, info: d}; return blobs[path];
      });
    });
  }
  function card(path, d, note) {
    var name = (d && d.name) || baseName(path), ext = (d && d.ext) || (/\.([A-Za-z0-9]{1,8})$/.exec(name) || [, ''])[1];
    var meta = el('div', {class: 'qm-meta', text: (ext ? ext.toUpperCase() + ' file' : 'File') + (d && typeof d.size === 'number' ? ' · ' + size(d.size) : '')});
    var acts = el('div', {class: 'qm-acts'});
    var c = el('div', {class: 'qm-card', role: 'group', 'aria-label': name},
      [el('div', {class: 'qm-badge', 'aria-hidden': 'true', text: (ext || 'file').slice(0, 4).toUpperCase()}),
       el('div', {class: 'qm-body'}, [el('div', {class: 'qm-name', title: name, text: name}), meta, note ? el('div', {class: 'qm-note', text: note}) : null]), acts]);
    if (d && d.ok) {
      if (d.openable) acts.appendChild(el('button', {class: 'qm-b', type: 'button', text: 'Open', onclick: function () { req('POST', 'open', {path: path, project: projDir()}).catch(function () {}); }}));
      acts.appendChild(el('button', {class: 'qm-b', type: 'button', text: 'Show in folder', onclick: function () { req('POST', 'reveal', {path: path, project: projDir()}).catch(function () {}); }}));
      acts.appendChild(el('button', {class: 'qm-b', type: 'button', text: 'Download', onclick: function () { download(path, name); }}));
    }
    return c;
  }
  function download(path, name) {
    req('GET', 'file?path=' + q(path) + '&download=1', null, true).then(function (bl) {
      var u = URL.createObjectURL(bl), a = el('a', {href: u, download: name || baseName(path)});
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(u); }, 60000);
    }, function () {});
  }
  function refused(path, err) {
    var d = err && err.data;
    return card(path, null, d && d.error === 'outside' ? 'Qosha shows files from its own folders only.'
      : d && d.error === 'too_large' ? 'This file is too large to show here.' : (d && d.detail) || 'This file can’t be shown.');
  }
  function openFrom(img) {
    // every picture of this answer, in order; arrows move between them
    var scope = img.closest('.txt') || img.closest('.qm-group') || document.body;
    var all = Array.prototype.slice.call(scope.querySelectorAll('.qm-pic img[data-path]'));
    var gallery = all.map(function (x) { return {path: x.getAttribute('data-path'), alt: x.getAttribute('alt')}; });
    viewer(gallery, Math.max(0, all.indexOf(img)));
  }
  // a failed picture, player or card keeps its place (the same element), so a redrawn answer reuses it
  function swapTo(holder, content) { holder.className = 'qm-item'; holder.textContent = ''; holder.appendChild(content); }
  function picture(path, alt) {
    var fig = el('figure', {class: 'qm-pic'}), img = el('img', {alt: alt || baseName(path), decoding: 'async'});
    img.setAttribute('data-path', path);
    fig.appendChild(img);
    blobOf(path, IMG_MAX).then(function (b) {
      img.src = b.url;
      img.addEventListener('click', function () { openFrom(img); });
      img.setAttribute('tabindex', '0'); img.setAttribute('role', 'button'); img.setAttribute('aria-label', 'Open ' + (alt || b.info.name) + ' full size');
      img.addEventListener('keydown', function (ev) { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); openFrom(img); } });
    }, function (e) {
      if (e && e.data && e.data.info) { swapTo(fig, card(path, e.data.info, 'This picture is too large to show here.')); return; }
      swapTo(fig, refused(path, e));
    });
    return fig;
  }
  function player(path, kind) {
    var wrap = el('div', {class: 'qm-' + kind});
    var m = el(kind, {controls: '', preload: 'metadata', playsinline: ''});
    m.autoplay = false;
    wrap.appendChild(m);
    blobOf(path, PLAY_MAX).then(function (b) {
      m.src = b.url;
      wrap.appendChild(el('div', {class: 'qm-cap', text: b.info.name}));
    }, function (e) {
      swapTo(wrap, e && e.data && e.data.info ? card(path, e.data.info, 'This file is too large to play here; open it instead.') : refused(path, e));
    });
    return wrap;
  }
  function fileCard(path) {
    var holder = el('div', {class: 'qm-holder'});
    req('GET', 'info?path=' + q(path)).then(function (d) { swapTo(holder, card(path, d)); }, function (e) { swapTo(holder, refused(path, e)); });
    return holder;
  }
  function webCard(url, alt) {
    var host = ''; try { host = new URL(url).host; } catch (e) {}
    var a = el('a', {class: 'qm-web', href: url, target: '_blank', rel: 'noopener noreferrer'},
      [el('span', {class: 'qm-badge', 'aria-hidden': 'true', text: 'WEB'}), el('span', {class: 'qm-body'}, [el('span', {class: 'qm-name', text: alt || 'Picture on the web'}), el('span', {class: 'qm-meta', text: host})])]);
    return a;
  }
  function build(items, keep) {
    var pics = items.filter(function (it) { return it.kind === 'path' && IMG.test(it.path); });
    var box = el('div', {class: 'qm-group' + (pics.length > 1 ? ' qm-grid' : '')});
    items.forEach(function (it) {
      // an answer drawn again while it streams keeps the elements it already has (a playing video never restarts)
      var k = (it.kind === 'web' ? 'w:' + it.url : 'p:' + it.path), made = keep && keep[k];
      if (!made) {
        made = it.kind === 'web' ? webCard(it.url, it.alt) : IMG.test(it.path) ? picture(it.path, it.alt)
          : VID.test(it.path) ? player(it.path, 'video') : AUD.test(it.path) ? player(it.path, 'audio') : fileCard(it.path);
        if (keep) keep[k] = made;
      }
      box.appendChild(made);
    });
    return box;
  }
  function attach(frag, m, node) {
    if (!m || !m.items.length) return frag;
    var re = new RegExp('QMEDIA' + m.nonce + 'X([0-9Y]+)XQ');
    var walker = document.createTreeWalker(frag, NodeFilter.SHOW_TEXT), hits = [], n;
    while ((n = walker.nextNode())) if (re.test(n.nodeValue)) hits.push(n);
    hits.forEach(function (t) {
      var keep = node ? (node.__qm = node.__qm || {}) : null;
      var mt, guard = 0;
      // every marker in this text node, one at a time: only the marker is replaced, the words around it stay (a long
      // answer shown as plain text keeps all its words: review r1 #1)
      while ((mt = re.exec(t.nodeValue)) && guard++ < 100000) {
        var ids = mt[1].split('Y').map(Number), box = build(ids.map(function (i) { return m.items[i]; }).filter(Boolean), keep);
        var p = t.parentNode;
        if (p && p.nodeName === 'P' && p.childNodes.length === 1 && p.textContent.trim() === mt[0]) { p.replaceWith(box); break; }
        var after = t.splitText(mt.index);
        var rest = after.splitText(mt[0].length);
        after.replaceWith(box);
        t = rest;
      }
    });
    ensureCss();
    return frag;
  }

  // ---- the full-window viewer ------------------------------------------------------------------------------------
  var open = null;
  function viewer(gallery, index, srcOf) {
    if (open) open.close();
    ensureCss();
    var i = Math.max(0, index || 0), last = document.activeElement, zoomed = false;
    var img = el('img', {class: 'qm-v-img', alt: ''});
    var count = el('div', {class: 'qm-v-count', 'aria-live': 'polite'});
    var prev = el('button', {class: 'qm-v-nav qm-v-prev', type: 'button', 'aria-label': 'Previous picture', text: '‹'});
    var next = el('button', {class: 'qm-v-nav qm-v-next', type: 'button', 'aria-label': 'Next picture', text: '›'});
    var dl = el('button', {class: 'qm-v-b', type: 'button', text: 'Download'});
    var app = el('button', {class: 'qm-v-b', type: 'button', text: 'Open in app'});
    var x = el('button', {class: 'qm-v-b qm-v-x', type: 'button', 'aria-label': 'Close', text: '×'});
    var stage = el('div', {class: 'qm-v-stage'}, [img]);
    var layer = el('div', {class: 'qm-v', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Picture'},
      [el('div', {class: 'qm-v-top'}, [count, el('div', {class: 'qm-v-acts'}, [dl, app, x])]), stage, prev, next]);
    function show() {
      var g = gallery[i]; zoomed = false; img.classList.remove('zoom');
      count.textContent = gallery.length > 1 ? (i + 1) + ' of ' + gallery.length : (g.name || baseName(g.path || ''));
      prev.hidden = next.hidden = gallery.length < 2;
      app.hidden = !g.path;
      if (g.src) img.src = g.src;
      else blobOf(g.path, IMG_MAX).then(function (b) { img.src = b.url; img.alt = g.alt || b.info.name; }, function () {});
    }
    function go(d) { if (gallery.length > 1) { i = (i + d + gallery.length) % gallery.length; show(); } }
    function key(ev) {
      if (ev.key === 'Escape') { ev.preventDefault(); close(); }
      else if (ev.key === 'ArrowRight') { ev.preventDefault(); go(1); }
      else if (ev.key === 'ArrowLeft') { ev.preventDefault(); go(-1); }
      else if (ev.key === 'Tab') {   // focus stays in the viewer
        var f = [dl, app, x, prev, next].filter(function (b) { return !b.hidden; });
        var at = f.indexOf(document.activeElement);
        if (ev.shiftKey && at <= 0) { ev.preventDefault(); f[f.length - 1].focus(); }
        else if (!ev.shiftKey && at === f.length - 1) { ev.preventDefault(); f[0].focus(); }
      }
    }
    function close() { document.removeEventListener('keydown', key, true); layer.remove(); open = null; try { if (last) last.focus(); } catch (e) {} }
    layer.addEventListener('click', function (ev) { if (ev.target === layer || ev.target === stage) close(); });
    img.addEventListener('click', function (ev) {
      ev.stopPropagation(); zoomed = !zoomed; img.classList.toggle('zoom', zoomed);
      if (zoomed) { var r = img.getBoundingClientRect(); img.style.transformOrigin = ((ev.clientX - r.left) / r.width * 100) + '% ' + ((ev.clientY - r.top) / r.height * 100) + '%'; }
    });
    prev.addEventListener('click', function (ev) { ev.stopPropagation(); go(-1); });
    next.addEventListener('click', function (ev) { ev.stopPropagation(); go(1); });
    x.addEventListener('click', close);
    dl.addEventListener('click', function () { var g = gallery[i]; if (g.path) download(g.path, g.name); else { var a = el('a', {href: g.src, download: g.name || 'picture'}); document.body.appendChild(a); a.click(); a.remove(); } });
    app.addEventListener('click', function () { var g = gallery[i]; if (g.path) req('POST', 'open', {path: g.path, project: projDir()}).catch(function () {}); });
    document.addEventListener('keydown', key, true);
    document.body.appendChild(layer);
    show(); x.focus();
    open = {close: close};
    return open;
  }

  // ---- the person's own attached pictures ------------------------------------------------------------------------
  function thumbs(box, files) {
    if (!ENABLED) return;
    var pics = (files || []).filter(function (f) { return f && f.image && typeof f.data === 'string' && /^data:image\/(png|jpeg|gif|webp|bmp)/.test(f.data); });
    if (!box || !pics.length) return;
    ensureCss();
    var gallery = pics.map(function (f) { return {src: f.data, name: f.name}; });
    var row = el('div', {class: 'qm-thumbs'});
    pics.forEach(function (f, i) {
      var t = el('img', {class: 'qm-thumb', src: f.data, alt: f.name || 'Attached picture', tabindex: '0', role: 'button'});
      t.addEventListener('click', function () { viewer(gallery, i); });
      t.addEventListener('keydown', function (ev) { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); viewer(gallery, i); } });
      row.appendChild(t);
    });
    var txt = box.querySelector('.txt');
    if (txt && txt.nextSibling) box.insertBefore(row, txt.nextSibling); else box.appendChild(row);
  }

  var cssDone = false;
  function ensureCss() {
    if (cssDone) return; cssDone = true;
    var css = '.qm-group{margin:10px 0;display:flex;flex-direction:column;gap:10px;align-items:flex-start}' +
      '.qm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px;width:100%}' +
      '.qm-pic{margin:0;max-width:100%}.qm-pic img{display:block;max-width:100%;max-height:420px;width:auto;height:auto;border-radius:12px;border:1px solid var(--line,#E2E1DB);cursor:zoom-in;background:var(--band,#F5F4F0)}' +
      '.qm-grid .qm-pic img{width:100%;height:160px;object-fit:cover;max-height:none}' +
      '.qm-pic img:focus-visible,.qm-thumb:focus-visible{outline:2px solid var(--forest,#0B3326);outline-offset:2px}' +
      '.qm-video,.qm-audio{max-width:100%}.qm-video video{display:block;max-width:100%;max-height:480px;border-radius:12px;background:#000}.qm-audio audio{width:min(420px,100%)}' +
      '.qm-cap{font-size:12px;color:var(--ink2,#5E5D59);margin-top:4px}' +
      '.qm-card,.qm-web{display:flex;gap:12px;align-items:center;max-width:520px;width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid var(--line,#E2E1DB);border-radius:12px;background:var(--surface,#FFFFFF);color:var(--ink,#0B0B0B);text-decoration:none}' +
      '.qm-badge{flex:none;width:40px;height:40px;border-radius:9px;background:var(--well,#E3EEE7);color:var(--forest,#0B3326);display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:600;letter-spacing:.04em}' +
      '.qm-body{flex:1;min-width:0;display:flex;flex-direction:column}.qm-name{font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
      '.qm-meta,.qm-note{font-size:12px;color:var(--ink2,#5E5D59)}.qm-acts{display:flex;gap:6px;flex-wrap:wrap}' +
      '.qm-b{height:30px;padding:0 10px;border-radius:8px;border:1px solid var(--line,#E2E1DB);background:transparent;color:inherit;font:inherit;font-size:12px;cursor:pointer}.qm-b:hover{background:var(--hover,#F5F4F0)}' +
      '.qm-thumbs{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}.qm-thumb{width:72px;height:72px;object-fit:cover;border-radius:10px;border:1px solid var(--line,#E2E1DB);cursor:zoom-in}' +
      '.qm-v{position:fixed;inset:0;z-index:2147482000;background:rgba(10,10,10,.9);display:flex;align-items:center;justify-content:center}' +
      '.qm-v-stage{position:absolute;inset:56px 64px 24px;display:flex;align-items:center;justify-content:center;overflow:auto}' +
      '.qm-v-img{max-width:100%;max-height:100%;object-fit:contain;cursor:zoom-in;transition:transform 160ms}.qm-v-img.zoom{transform:scale(2);cursor:zoom-out}' +
      '.qm-v-top{position:absolute;top:0;left:0;right:0;height:56px;display:flex;align-items:center;justify-content:space-between;padding:0 16px;color:#F3F3F1;font-size:14px}' +
      '.qm-v-acts{display:flex;gap:8px}.qm-v-b{height:34px;padding:0 12px;border-radius:8px;border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.08);color:#FFF;font:inherit;cursor:pointer}' +
      '.qm-v-x{font-size:20px;line-height:1;width:34px;padding:0}.qm-v-nav{position:absolute;top:50%;transform:translateY(-50%);width:44px;height:64px;border:0;border-radius:10px;background:rgba(255,255,255,.1);color:#FFF;font-size:32px;cursor:pointer}' +
      '.qm-v-prev{left:10px}.qm-v-next{right:10px}.qm-v-b:focus-visible,.qm-v-nav:focus-visible{outline:2px solid #FFF;outline-offset:2px}';
    var s = document.createElement('style'); s.id = 'qm-css'; s.textContent = css; (document.head || document.documentElement).appendChild(s);
  }

  window.QoshaMedia = {prepare: prepare, attach: attach, thumbs: thumbs, viewer: viewer};
})();
