/* Live voice chat (15 Nov 2026, Ren: "just build it the right way"): a hands-free conversation on the Chat page. The
   person presses Live once and talks; Qosha hears when they stop, turns the words into text with the engine's own
   speech-to-text (/api/audio/transcribe, the same route dictation uses, where Qosha runs), sends them to the assistant
   picked by the box (Qosha, Claude, ChatGPT or Gemini, with its model and effort), and reads the answer aloud sentence
   by sentence while it is still being written, with this device's own offline voice. Talking over the answer stops it
   (barge-in) and what was said is sent instead. Pressing Live again, saying "stop listening", a New chat or three quiet
   minutes end it.
   What does NOT change: anything Qosha would send, pay, delete or share still waits for the person's own click on its
   card (a voice never approves; Qosha says that a card is waiting). The answer is read only with a voice that runs on
   this device (localService), never the engine's network read-aloud. Text only, never HTML from data.
   One copy of the listening loop; pages/chat.html wires it to the conversation. */
(function () {
  'use strict';
  if (window.QoshaLive) return;

  var TEST = window.__qoshaLiveTest === true;   // set only by the browser tests, before the page loads
  var RATE = 16000;                 // what speech-to-text wants: 16 kHz, one channel
  var CFG = {
    minRms: 0.012,                  // never treat anything quieter than this as speech
    startFactor: 3,                 // speech starts at the room's own noise x this ...
    bargeFactor: 4.5,               // ... and at x this while the answer is being read aloud (speaker bleed)
    bargeMinRms: 0.02,
    startMs: 130,                   // this long above the line: speech has started
    bargeMs: 260,                   // longer while the answer is read aloud
    bargeGraceMs: 500,              // right after a sentence starts playing, nothing counts (the onset transient)
    endMs: 600,                     // this long below the line: the words so far are turned into text, to see if the
                                    // person has finished. A finished sentence is sent at once ...
    longEndMs: 1500,                // ... an unfinished one ("and so, my fellow Americans") waits this long for the rest
    minSpeechMs: 250,               // shorter than this is a click or a cough, not words
    preRollMs: 400,                 // kept from before speech was noticed, so the first word is whole
    maxUtterMs: 60000,
    idleOffMs: 180000,              // three quiet minutes: Live ends by itself
    hardOffMs: 600000,              // ten minutes with nothing said, whatever the answer is doing: Live ends (GPT R1 #2)
    setupMs: 10000,                 // the audio set-up must be done this long after the microphone opened (GPT R2)
    maxFails: 2,
    sttBaseMs: 60000, sttPerSec: 20,  // a transcription not back after 60 s + 20x its length counts as failed: the slot is always freed
    sessionMaxMs: 1800000,          // one Live chat lasts at most 30 minutes, whatever is heard (verifier VL-1 M2: a bound on spend)
    maxTurns: 40,                   // at most this many messages sent by voice in one Live chat
    hiddenOffMs: 120000,            // the window hidden (another tab, minimised) for 2 minutes: Live ends                    // this many failures in a row (speech-to-text, or the answer): Live ends (GPT R1 #4)
    busyWaitMs: 8000
  };
  var END_LIVE = ['stop listening', 'end live chat', 'end the live chat', 'end voice chat', 'goodbye'];
  var STOP_ANSWER = ['stop', 'cancel', 'be quiet', 'quiet', 'stop talking'];

  function button() {
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'vb live';
    b.setAttribute('aria-pressed', 'false');
    b.setAttribute('aria-label', 'Live voice chat: talk hands-free and hear the answers');
    b.title = 'Live voice chat';
    var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('aria-hidden', 'true'); s.setAttribute('class', 'ic');
    [['circle', {cx: '12', cy: '12', r: '3'}], ['path', {d: 'M6.3 6.3a8 8 0 0 0 0 11.4M17.7 6.3a8 8 0 0 1 0 11.4'}]].forEach(function (x) {
      var p = document.createElementNS('http://www.w3.org/2000/svg', x[0]);
      Object.keys(x[1]).forEach(function (k) { p.setAttribute(k, x[1][k]); }); s.appendChild(p);
    });
    b.appendChild(s);
    var t = document.createElement('span'); t.className = 'tlk'; t.setAttribute('aria-hidden', 'true'); t.textContent = 'Live';
    b.appendChild(t);
    return b;
  }

  // ---- small pure helpers (also used by the tests) -----------------------------------------------------------------
  function norm(t) { return String(t || '').toLowerCase().replace(/[^a-z0-9à-ÿ' ]+/g, ' ').replace(/\s+/g, ' ').trim(); }
  // has the person finished? Speech-to-text punctuates: a sentence that ends is finished, one that trails off is not.
  // The spoken commands are finished however they are written.
  function finished(t) {
    t = String(t || '').trim();
    if (isPhrase(t, END_LIVE) || isPhrase(t, STOP_ANSWER)) return true;
    if (/(\.\.\.|…|[,;:\-–—])["')\]]?$/.test(t)) return false;
    return /[.!?。！？]["')\]]?$/.test(t);
  }
  function isPhrase(t, list) { var n = norm(t); return !!n && list.indexOf(n) >= 0; }
  // what a voice should say of a piece of Markdown: the words, not the marks
  function speakable(md) {
    return String(md || '')
      .replace(/```[\s\S]*?```/g, ' (code is on screen) ').replace(/```[\s\S]*$/, ' ')
      .replace(/`([^`]*)`/g, '$1')
      .replace(/!\[([^\]]*)\]\([^)]*\)/g, '$1').replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')
      .replace(/https?:\/\/\S+/g, ' (a link, on screen) ')
      .replace(/^\s{0,3}#{1,6}\s+/gm, '').replace(/^\s{0,3}>\s?/gm, '').replace(/^\s*[-*+]\s+/gm, '').replace(/^\s*\|?[-: |]{3,}\|?\s*$/gm, ' ')
      .replace(/\|/g, ', ').replace(/[*_~]{1,3}/g, '')
      .replace(/[ \t]+/g, ' ').trim();
  }
  // whole sentences from the start of `buf`; the unfinished rest stays. An open code fence waits for its end.
  function takeSentences(buf, flush) {
    var out = [], fences = (buf.match(/```/g) || []).length;
    if (fences % 2 && !flush) { var at = buf.lastIndexOf('```'); var head = buf.slice(0, at); var r0 = takeSentences(head, true); return {out: r0.out, rest: buf.slice(at)}; }
    var re = /([.!?…:;]["')\]]?)(\s+|$)|\n+/g, m, last = 0;
    while ((m = re.exec(buf))) {
      var end = m.index + m[0].length;
      if (!flush && end >= buf.length && !/\n$/.test(m[0]) && !/\s$/.test(m[0])) break;   // "3." may still become "3.5"
      var piece = buf.slice(last, end);
      if (piece.trim()) out.push(piece);
      last = end;
    }
    var rest = buf.slice(last);
    if (flush && rest.trim()) { out.push(rest); rest = ''; }
    return {out: out, rest: rest};
  }
  // is `heard` just the answer coming back through the microphone? Most of its words are in what was being read aloud.
  function isEcho(heard, spoken) {
    var h = norm(heard).split(' ').filter(Boolean), s = norm(spoken);
    if (h.length < 2 || !s) return false;
    var set = {}; s.split(' ').forEach(function (w) { set[w] = 1; });
    var hit = 0; h.forEach(function (w) { if (set[w]) hit++; });
    return hit / h.length >= 0.7;
  }
  function wavDataUrl(chunks, total) {
    var buf = new ArrayBuffer(44 + total * 2), v = new DataView(buf), o = 0;
    var str = function (s) { for (var i = 0; i < s.length; i++) v.setUint8(o++, s.charCodeAt(i)); };
    str('RIFF'); v.setUint32(o, 36 + total * 2, true); o += 4; str('WAVEfmt '); v.setUint32(o, 16, true); o += 4;
    v.setUint16(o, 1, true); o += 2; v.setUint16(o, 1, true); o += 2; v.setUint32(o, RATE, true); o += 4;
    v.setUint32(o, RATE * 2, true); o += 4; v.setUint16(o, 2, true); o += 2; v.setUint16(o, 16, true); o += 2;
    str('data'); v.setUint32(o, total * 2, true); o += 4;
    for (var c = 0; c < chunks.length; c++) { var a = chunks[c]; for (var i = 0; i < a.length; i++) { var x = Math.max(-1, Math.min(1, a[i])); v.setInt16(o, x < 0 ? x * 0x8000 : x * 0x7fff, true); o += 2; } }
    var bytes = new Uint8Array(buf), bin = '';
    for (var k = 0; k < bytes.length; k += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(k, k + 0x8000));
    return 'data:audio/wav;base64,' + window.btoa(bin);
  }
  // the audio thread hands over what the microphone hears in blocks (about 43 ms each at 48 kHz)
  var TAP = 'class QoshaTap extends AudioWorkletProcessor{constructor(){super();this.b=new Float32Array(2048);this.n=0;}' +
    'process(i){var c=i[0]&&i[0][0];if(c){for(var k=0;k<c.length;k++){this.b[this.n++]=c[k];if(this.n===2048){this.port.postMessage(this.b.slice(0));this.n=0;}}}return true;}}' +
    'registerProcessor("qosha-tap",QoshaTap);';

  // o: {button, say(text, err), transcribe(body) → Promise {transcript}, blocked() → '' or why Live can't start/continue,
  //     busy() → an answer is being written, send(text) → true when it was sent, interrupt() (the page's Stop),
  //     name() → who answers ("Qosha"), device() → "this computer", box(text) (put words in the text box, unsent)}
  function attach(o) {
    var on = false, seq = 0, stream = null, ac = null, node = null, src = null, sink = null;
    var floor = 0.004, calib = 0, frames = [], preRoll = [], preLen = 0;
    var capturing = null;             // {chunks, len, voicedMs, quietMs, during, startedAt}
    var above = 0, queue = [], working = false;
    var phase = 'off';                // off | listen | think | speak
    var speech = {buf: '', q: [], playing: null, spoken: '', done: true, at: 0, gen: 0, noVoice: false, told: false, said: 0};
    var echoStrikes = 0, bargeOff = false, held = '', idleTimer = null, lastVoice = 0, sttFails = 0, turnFails = 0;
    var turns = 0, capTimer = null, hideTimer = null, stt = null, waiting = [], sending = null, me = Math.random().toString(36).slice(2);   // stt: the one transcription in flight; waiting: parts in line for it, oldest first
    var say = function (t, err) { o.say(t || '', !!err); };
    var ss = function () { return window.speechSynthesis; };

    function paint() {
      o.button.setAttribute('aria-pressed', on ? 'true' : 'false');
      o.button.setAttribute('data-phase', phase);
      o.button.setAttribute('aria-label', on ? 'End live voice chat' : 'Live voice chat: talk hands-free and hear the answers');
    }
    function setPhase(p) { phase = p; paint(); }
    function hint() {
      if (!on) return;
      if (phase === 'listen') say('Live: listening. Just talk; say “stop listening” or press Live to end.' + (speech.noVoice ? ' Answers are shown as text: ' + o.device() + ' has no voice that works offline here.' : ''));
      else if (phase === 'think') say('Live: ' + o.name() + ' is answering… say “stop” to cancel.');
      else if (phase === 'speak') say('Live: reading the answer aloud' + (bargeOff ? '. Press Live to end.' : '; talk to interrupt.'));
    }
    function armIdle() {
      clearTimeout(idleTimer);
      // whichever comes first: three quiet minutes, or the ten-minute limit since the person last spoke (GPT R2)
      var wait = Math.min(CFG.idleOffMs, Math.max(250, lastVoice + CFG.hardOffMs - Date.now()));
      idleTimer = setTimeout(function () {
        if (!on) return;
        if (phase === 'listen' && !capturing && !working && !waiting.length && !queue.length && !(stt && stt.seq === seq)) stop('Live ended after three quiet minutes. Press Live to talk again.');
        // an answer that never finishes (no end, no lost connection) cannot keep the microphone open for ever
        else if (Date.now() - lastVoice >= CFG.hardOffMs && !waiting.length && !queue.length && !working && !(stt && stt.seq === seq)) { if (o.busy()) o.interrupt(); stop('Live ended: nothing was said for ten minutes. Press Live to talk again.'); }
        else armIdle();
      }, wait);
    }

    // one Live per browser (VL-1 M2): a Live chat that starts in another window or tab ends this one
    var chan = null;
    try { if (typeof window.BroadcastChannel === 'function') chan = new window.BroadcastChannel('qosha-live'); } catch (e) { chan = null; }
    if (chan) chan.onmessage = function (e) { var d = e && e.data; if (on && d && d.type === 'start' && d.id !== me) stop('Live voice chat moved to another window, so it ended here.'); };
    // the app keeps the Chat page loaded but hidden while another page is shown (VERIFY-V1-FINAL M1): that counts too
    function frameHidden() { try { var f = window.frameElement; return !!f && (f.offsetParent === null || !!f.closest('[hidden]')); } catch (e) { return false; } }
    function away() { return document.visibilityState === 'hidden' || frameHidden(); }
    function watchAway() {
      if (!on) { clearTimeout(hideTimer); hideTimer = null; return; }
      if (away()) { if (!hideTimer) hideTimer = setTimeout(function () { hideTimer = null; if (on && away()) stop('Live ended because Chat was not on screen. Press Live to talk again.'); }, CFG.hiddenOffMs); }
      else { clearTimeout(hideTimer); hideTimer = null; }
    }
    document.addEventListener('visibilitychange', watchAway);
    setInterval(watchAway, 1000);

    // ---- start / stop ---------------------------------------------------------------------------------------------
    function start() {
      if (on) return;
      var why = o.blocked ? o.blocked() : '';
      if (why) { say(why, true); return; }
      var md = navigator.mediaDevices, AC = window.AudioContext || window.webkitAudioContext;
      if (!md || typeof md.getUserMedia !== 'function' || !AC) { say('This window can’t listen, so live voice chat isn’t available here. Type your message instead.', true); return; }
      srvCheck();
      var mine = ++seq;
      on = true; turns = 0; setPhase('listen'); say('Asking to use the microphone…');
      try { if (chan) chan.postMessage({type: 'start', id: me}); } catch (e) { /* one window only */ }
      clearTimeout(capTimer); capTimer = setTimeout(function () { if (on && mine === seq) { if (o.busy()) o.interrupt(); stop('Live ended: one Live chat lasts at most 30 minutes. Press Live to go on.'); } }, CFG.sessionMaxMs);
      clearTimeout(hideTimer); hideTimer = null; watchAway();
      stopAudio(); try { if (ss()) ss().cancel(); } catch (e) { /* nothing playing */ }
      // a first, silent utterance inside the person's own press: browsers that only let a page speak after a press
      // then allow the answers that come later
      try { if (ss() && typeof window.SpeechSynthesisUtterance === 'function') { var u0 = new window.SpeechSynthesisUtterance(' '); u0.volume = 0; ss().speak(u0); } } catch (e) { /* no voice here */ }
      md.getUserMedia({audio: {echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1}}).then(function (st) {
        if (!on || mine !== seq) { st.getTracks().forEach(function (t) { t.stop(); }); return; }
        stream = st;
        // anything that fails while the audio is set up ends Live and releases the microphone (GPT R1 #3)
        var broke = function (e) { clearTimeout(setupClock); if (on && mine === seq) stop('The microphone could not be started (' + ((e && (e.message || e.name)) || 'unknown problem') + '). Type your message instead.', true); };
        var setupClock = setTimeout(function () { broke(new Error('the audio did not start in time')); }, CFG.setupMs);
        var ready = function () {
          clearTimeout(setupClock);
          if (!on || mine !== seq) return;
          floor = 0.004; calib = 0; above = 0; preRoll = []; preLen = 0; capturing = null; echoStrikes = 0; bargeOff = false; sttFails = 0; turnFails = 0;
          lastVoice = Date.now(); armIdle(); setPhase('listen'); hint();
          if (ac.state === 'suspended') ac.resume().catch(function () {});
        };
        var legacy = function () {
          try {
            node = ac.createScriptProcessor(2048, 1, 1);
            node.onaudioprocess = function (e) { frame(new Float32Array(e.inputBuffer.getChannelData(0))); };
            sink = ac.createGain(); sink.gain.value = 0;
            src.connect(node); node.connect(sink); sink.connect(ac.destination);
          } catch (e) { broke(e); return; }
          ready();
        };
        try {
          st.getTracks().forEach(function (t) { t.addEventListener('ended', function () { if (on && mine === seq) stop('The microphone stopped, so Live ended. Nothing more was sent.', true); }); });
          ac = new AC();
          src = ac.createMediaStreamSource(st);
          if (ac.audioWorklet && typeof window.AudioWorkletNode === 'function') {
            var url = URL.createObjectURL(new Blob([TAP], {type: 'application/javascript'}));
            ac.audioWorklet.addModule(url).then(function () {
              URL.revokeObjectURL(url);
              if (!on || mine !== seq) return;
              try {
                node = new window.AudioWorkletNode(ac, 'qosha-tap', {numberOfInputs: 1, numberOfOutputs: 0});
                node.port.onmessage = function (e) { frame(e.data); };
                src.connect(node);
              } catch (e) { broke(e); return; }
              ready();
            }, function () { URL.revokeObjectURL(url); if (on && mine === seq) legacy(); });
          } else legacy();
        } catch (e) { broke(e); }
      }, function (e) {
        if (mine !== seq) return;
        var n = e && e.name;
        stop(n === 'NotAllowedError' || n === 'SecurityError' || n === 'PermissionDeniedError'
          ? 'Qosha can’t use the microphone: permission is turned off. Allow it (in your computer’s privacy settings for the microphone, and in the browser: the icon at the left of the address bar), then press Live again.'
          : n === 'NotFoundError' || n === 'DevicesNotFoundError' ? 'No microphone was found on ' + o.device() + '.'
          : 'The microphone could not be started (' + (n || 'unknown problem') + '). Type your message instead.', true);
      });
    }
    function stop(note, err) {
      if (!on) return;
      // R2/R6 (STATE-RULES.md): nothing captured is dropped silently. Words already turned into text go into the box,
      // unsent; parts not turned into text yet are counted and the person is told.
      var boxed = [], lost = 0;
      if (sending && !sending.handled && sending.text) { sending.handled = true; boxed.push(sending.text); }
      queue.forEach(function (u) { if (!u.handled && u.text) { u.handled = true; boxed.push(u.text); } });
      if (capturing && !capturing.done && capturing.text) { capturing.done = true; boxed.push(capturing.text); }   // an unfinished sentence already back (M5)
      waiting.forEach(function (u) { if (!u.done) lost++; });
      if (stt && stt.seq === seq && stt.u && !stt.u.done && waiting.indexOf(stt.u) < 0) lost++;
      if (capturing && !capturing.done && waiting.indexOf(capturing) < 0 && !(stt && stt.u === capturing) && capturing.voicedMs >= CFG.minSpeechMs) lost++;
      if (boxed.length) o.box(boxed.join(' '));
      var unsent = (boxed.length ? ' What you said last is in the box, not sent.' : '') + (lost ? ' ' + lost + (lost === 1 ? ' part' : ' parts') + ' of what you said could not be turned into text in time and ' + (lost === 1 ? 'was' : 'were') + ' not sent.' : '');
      // R1: a transcription still running keeps its slot until it returns (its result is ignored); only the line is cleared
      on = false; seq++; waiting = []; sending = null;
      clearTimeout(idleTimer); clearTimeout(capTimer); clearTimeout(hideTimer);
      shutUp();
      try { if (node && node.port) node.port.onmessage = null; if (node) { node.onaudioprocess = null; node.disconnect(); } } catch (e) { /* gone */ }
      try { if (src) src.disconnect(); if (sink) sink.disconnect(); } catch (e) { /* gone */ }
      try { if (stream) stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) { /* gone */ }
      try { if (ac) ac.close(); } catch (e) { /* gone */ }
      stream = ac = node = src = sink = null; capturing = null; queue = []; working = false; held = '';
      setPhase('off');
      say((note == null ? 'Live voice chat ended.' : note) + unsent, !!err || !!unsent);
    }

    // ---- hearing: every block from the microphone ------------------------------------------------------------------
    function resample(a, from) {
      if (from === RATE) return a;
      var ratio = from / RATE, n = Math.floor(a.length / ratio), out = new Float32Array(n);
      for (var i = 0; i < n; i++) { var s = Math.floor(i * ratio), e = Math.min(a.length, Math.floor((i + 1) * ratio)), sum = 0; for (var k = s; k < e; k++) sum += a[k]; out[i] = sum / Math.max(1, e - s); }
      return out;
    }
    function frame(raw) {
      if (!on || !ac) return;
      var sum = 0; for (var i = 0; i < raw.length; i++) sum += raw[i] * raw[i];
      var rms = Math.sqrt(sum / raw.length), ms = raw.length / ac.sampleRate * 1000, pcm = resample(raw, ac.sampleRate);
      var reading = phase === 'speak' && !!speech.playing;
      var line = reading ? Math.max(CFG.bargeMinRms, floor * CFG.bargeFactor) : Math.max(CFG.minRms, floor * CFG.startFactor);
      if (!capturing) {
        // the room's own noise, learned only while nobody talks and nothing is being read aloud
        if (!reading && rms < line) { calib++; floor = calib < 10 ? Math.max(floor * 0.5 + rms * 0.5, 0.0005) : floor * 0.97 + rms * 0.03; }
        preRoll.push(pcm); preLen += pcm.length;
        while (preLen - preRoll[0].length > CFG.preRollMs * RATE / 1000) preLen -= preRoll.shift().length;
        if (reading && (bargeOff || Date.now() - speech.at < CFG.bargeGraceMs)) { above = 0; return; }
        above = rms >= line ? above + ms : Math.max(0, above - ms);
        if (above >= (reading ? CFG.bargeMs : CFG.startMs)) {
          above = 0;
          capturing = {chunks: preRoll.slice(), len: preLen, voicedMs: 0, quietMs: 0, during: phase, startedAt: Date.now(), cut: null, probed: false, token: 0, text: null, force: false};
          preRoll = []; preLen = 0;
          if (reading) capturing.cut = pauseSpeech();   // barge-in: the voice stops at once
          lastVoice = Date.now(); armIdle();
        }
        return;
      }
      // the voice was stopped for this: the microphone no longer hears it, so the ordinary line applies
      var quiet = rms < Math.max(CFG.minRms, floor * CFG.startFactor) * 0.6;
      // a part that has paused and is being (or waiting to be) turned into text keeps no more silence: if the person goes
      // on, their next words join it; if not, the upload holds only what was said (no part padded with silence)
      if (!(quiet && capturing.probed)) { capturing.chunks.push(pcm); capturing.len += pcm.length; }
      if (quiet) capturing.quietMs += ms; else { capturing.quietMs = 0; capturing.voicedMs += ms; }
      var u = capturing;
      if (Date.now() - u.startedAt >= CFG.maxUtterMs) {
        // R3/R4 (STATE-RULES.md): at the limit, talking or pausing, what was heard so far is one part, sent exactly once and
        // in order; no upload is longer than the limit
        u.force = true; lastVoice = Date.now();
        var running = !!(stt && stt.u === u && stt.tok === u.token);   // a check of this whole part is already on its way
        if (quiet) {
          capturing = null;                           // the part stops growing; the next words start a new capture
          if (running) { u.probed = true; return; }   // its check covers it all: that result is sent as it is
          if (u.text != null) { finish(u); return; }  // its text is already back (it was waiting for the rest): send it now
          u.probed = true; probe(u);                  // not checked yet (or the check was for less): one check of the whole part
          return;
        }
        // talked on after any check started: that check no longer counts; the whole part is checked once, the rest goes on
        u.probed = true; u.token++;
        capturing = {chunks: [], len: 0, voicedMs: 0, quietMs: 0, during: phase, startedAt: Date.now(), cut: null, probed: false, token: 0, text: null, force: false};
        probe(u);
        return;
      }
      if (!quiet) {
        // talking again after a pause: what was understood of the first part is dropped, the whole is heard as one
        if (u.probed) { u.probed = false; u.token++; u.text = null; }
        return;
      }
      if (u.quietMs >= CFG.endMs && !u.probed) {
        if (u.voicedMs < CFG.minSpeechMs) { capturing = null; if (u.cut) { falseAlarm(); resumeSpeech(u.cut); } else kick(); return; }   // a click, a cough, or the voice's own tail
        u.probed = true; probe(u);
      } else if (u.probed && u.text != null && u.quietMs >= CFG.longEndMs) finish(u);
    }
    // the words so far, while the microphone stays open: a finished sentence ends the turn now, an unfinished one waits
    function probe(u) {
      if (u.done) return;
      if (stt) { if (waiting.indexOf(u) < 0) waiting.push(u); return; }   // one transcription at a time (VL-1 H1); the rest wait in line
      var mine = seq, tok = ++u.token, mineStt = stt = {seq: seq, u: u, tok: tok};
      if (phase === 'listen') say('Live: turning your speech into text…');
      var limitMs = CFG.sttBaseMs + CFG.sttPerSec * u.len / RATE * 1000;
      new Promise(function (res, rej) {   // R1b: whatever the route does, the slot is freed: a hung request is cancelled and counts as failed
        var ctl = typeof window.AbortController === 'function' ? new window.AbortController() : null;
        var tm = setTimeout(function () { try { if (ctl) ctl.abort(); } catch (e) { /* gone */ } rej(new Error('speech-to-text did not answer in time')); }, limitMs);
        o.transcribe({data_url: wavDataUrl(u.chunks, u.len), mime_type: 'audio/wav'}, ctl ? ctl.signal : undefined).then(function (r) { clearTimeout(tm); res(r); }, function (e) { clearTimeout(tm); rej(e); });
      }).then(function (r) {
        if (stt === mineStt) stt = null;
        if (on && mine === seq) lastVoice = Date.now();   // a check coming back is activity (R5): the 10-minute clock counts from here
        if (!on || mine !== seq || (capturing !== u && !u.force) || tok !== u.token) return;   // the person went on talking, or Live ended
        u.text = String((r && r.transcript) || '').trim();
        sttFails = 0;
        if (u.force || !u.text || finished(u.text) || u.quietMs >= CFG.longEndMs) finish(u);
        else if (phase === 'listen') say('Live: listening… (go on, or pause to send)');
      }, function (e) {
        if (stt === mineStt) stt = null;
        if (!on || mine !== seq || (capturing !== u && !u.force) || tok !== u.token) return;
        if (capturing === u) capturing = null;
        var why = (e && e.message) || 'unknown problem';
        // twice in a row: speech-to-text is not working here, so the microphone is not kept open for nothing
        if (++sttFails >= CFG.maxFails) { if (o.busy()) o.interrupt(); stop('Live ended: your speech could not be turned into text twice in a row (' + why + '). Nothing was sent. Type your message, or press Live to try again.', true); return; }
        if (u.cut) resumeSpeech(u.cut); else kick();
        say('Live: your speech could not be turned into text (' + why + '). Nothing was sent; still listening.', true);
      }).then(function () { if (on) nextWaiting(); });
    }
    // the next part in line: a cut-off part always (it is never lost); a capture only while it is still the one being heard
    // and the person has paused (if they went on talking, it is checked again at their next pause)
    function nextWaiting() {
      while (!stt && waiting.length) {
        var n = waiting.shift();
        if (!n.done && (n.force || (capturing === n && n.probed))) { probe(n); return; }
      }
    }
    function finish(u) { if (u.done) return; u.done = true; if (capturing === u) capturing = null; queue.push(u); pump(); }

    // ---- understanding: one utterance at a time --------------------------------------------------------------------
    function pump() {
      if (working || !queue.length || !on) return;
      working = true;
      var u = queue.shift(), mine = seq; sending = u;
      var next = function (said) { working = false; if (sending === u) sending = null; if (on && mine === seq) { if (said !== true && phase === 'listen') hint(); pump(); } };
      heard(u.text || '', u).then(next, function () { next(); });
    }
    function heard(t, u) {
      u.handled = true;   // settled here (sent, refused, put in the box), except while waiting for the last answer to stop below
      if (!t) { var told0 = false; if (u.cut) { told0 = falseAlarm(); resumeSpeech(u.cut); } else kick(); return Promise.resolve(told0); }   // no words: noise, or the voice's own sound
      // the answer itself, heard through the speakers: not the person. Twice in a row: voice interruption is switched off
      if (u.cut && !isPhrase(t, STOP_ANSWER) && !isPhrase(t, END_LIVE) && isEcho(t, speech.spoken)) {
        var told = falseAlarm();
        resumeSpeech(u.cut);
        return Promise.resolve(told);
      }
      if (isPhrase(t, END_LIVE)) { stop('Live voice chat ended.'); return Promise.resolve(true); }
      var answering = o.busy() || phase === 'speak' || !!u.cut;
      if (isPhrase(t, STOP_ANSWER)) {
        if (answering) { shutUp(); if (o.busy()) o.interrupt(); setPhase('listen'); say('Live: stopped. Still listening.'); return Promise.resolve(true); }
        kick();
        return Promise.resolve(false);   // "stop" with nothing to stop is not a message
      }
      if (u.cut) echoStrikes = 0;
      // a card is waiting for the person's own click: words said meanwhile wait in the box, nothing is sent
      if (held) { if (u.cut) resumeSpeech(u.cut); else kick(); o.box(t); say('Live: heard “' + t + '”. ' + held + ' Your words are in the box, not sent.', true); return Promise.resolve(true); }
      // talking while the answer is still being written stops it; only the new words are sent (the earlier message is
      // already in the conversation, so it is never sent a second time: GPT R1 #1)
      var text = t;
      shutUp();
      if (o.busy()) o.interrupt();
      u.handled = false;   // until it is sent or put in the box: if Live ends meanwhile, stop() puts it in the box (R2)
      return whenIdle().then(function (idle) {
        if (!on || u.handled) return true;
        u.handled = true;
        if (!idle) { o.box(text); setPhase('listen'); say('Live: heard “' + t + '”. The last answer is still stopping, so it was not sent: it is in the box.', true); return true; }
        var why = o.blocked ? o.blocked() : '';
        if (why) { o.box(text); stop('Heard: “' + t + '”. ' + why + ' Your words are in the box, not sent.', true); return true; }
        // a bound on spend (VL-1 M2): after maxTurns messages in one Live chat the next words wait in the box, unsent
        if (turns >= CFG.maxTurns) { o.box(text); stop('Live ended: ' + CFG.maxTurns + ' messages in one Live chat is the limit. Your last words are in the box, not sent; press Live to go on.', true); return true; }
        speechReset();
        if (o.send(text)) { turns++; setPhase('think'); say('Live: heard “' + t + '”. ' + o.name() + ' is answering… say “stop” to cancel.'); }
        else { speech.done = true; setPhase('listen'); }   // the page kept the words and said why
        return true;
      });
    }
    // the voice was stopped for something that was not the person talking (the answer's own sound, a cough). Twice in a
    // row: talking over the answer is switched off for this Live chat, so it can never stutter
    function falseAlarm() {
      if (++echoStrikes < 2 || bargeOff) return false;
      bargeOff = true;
      say('Live: the microphone hears the answer through the speakers, so talking over it is off for now. Use headphones to interrupt by voice, or press Stop.', true);
      return true;
    }
    function kick() { if (on && !speech.playing && speech.q.length && !capturing) playNext(); }
    function whenIdle() {
      return new Promise(function (res) {
        var t0 = Date.now();
        (function poll() { if (!on) res(false); else if (!o.busy()) res(true); else if (Date.now() - t0 > CFG.busyWaitMs) res(false); else setTimeout(poll, 100); })();
      });
    }

    // ---- speaking: the answer, sentence by sentence. First choice: Qosha's natural on-device voice (the page's
    // o.voice: status() and speak(text) -> audio made on this computer); the browser's own voice is the last resort.
    var srv = {ok: null, audio: null, pre: null};
    function srvCheck() {
      if (srv.ok !== null || !o.voice) { if (!o.voice) srv.ok = false; return; }
      srv.ok = false;   // until it answers
      o.voice.status().then(function (r) { srv.ok = !!(r && r.available); }, function () { srv.ok = false; });
    }
    function srvFetch(text) {
      if (srv.pre && srv.pre.text === text) { var p0 = srv.pre.p; srv.pre = null; return p0; }
      return o.voice.speak(text);
    }
    function stopAudio() {
      var a = srv.audio; srv.audio = null; srv.pre = null;
      if (a) { try { a.onended = a.onerror = null; a.pause(); if (a.src) URL.revokeObjectURL(a.src); } catch (e) { /* gone */ } }
    }
    function playServer() {
      var t = speech.q.shift(), g2 = speech.gen, ended = false;
      var end = function () { if (ended) return; ended = true; clearTimeout(guard); if (g2 !== speech.gen) return; stopAudio(); speech.playing = null; playNext(); };
      var guard = setTimeout(end, 15000 + t.length * 110);
      speech.playing = t; speech.spoken += ' ' + t; speech.at = Date.now();
      if (phase !== 'speak') { setPhase('speak'); hint(); }
      var mine = srvFetch(t);
      // the next sentence is made while this one plays, so there is no gap between sentences
      if (speech.q.length) { var nx = speech.q[0]; srv.pre = {text: nx, p: o.voice.speak(nx)}; srv.pre.p.catch(function () {}); }
      mine.then(function (blob) {
        if (g2 !== speech.gen || ended) return;
        var a = new Audio(URL.createObjectURL(blob));
        srv.audio = a; a.onended = end;
        a.onerror = end;
        speech.at = Date.now();
        var pl = a.play(); if (pl && pl.catch) pl.catch(end);
      }, function () {
        // the natural voice did not answer: this sentence and the rest go to the browser's own voice
        if (g2 !== speech.gen || ended) return;
        ended = true; clearTimeout(guard); srv.ok = false; speech.playing = null; speech.q.unshift(t); playNext();
      });
    }
    function voice() {
      var s = ss(); if (!s || typeof window.SpeechSynthesisUtterance !== 'function') return null;
      var vs = (s.getVoices() || []).filter(function (v) { return v && v.localService; });   // never a network voice
      var lang = String(navigator.language || 'en').slice(0, 2).toLowerCase();
      return vs.filter(function (x) { return x.default && String(x.lang).toLowerCase().indexOf(lang) === 0; })[0]
          || vs.filter(function (x) { return String(x.lang).toLowerCase().indexOf(lang) === 0; })[0] || vs[0] || null;
    }
    function speechReset() { speech.buf = ''; speech.q = []; speech.playing = null; speech.spoken = ''; speech.done = false; speech.said = 0; speech.capped = false; speech.gen++; }
    function shutUp() {
      speech.q = []; speech.buf = ''; speech.playing = null; speech.done = true; speech.gen++;
      stopAudio(); try { if (ss()) ss().cancel(); } catch (e) { /* nothing playing */ }
    }
    // barge-in: the voice stops now; what was not finished is kept in case it was a false alarm
    function pauseSpeech() {
      var cut = {q: (speech.playing ? [speech.playing] : []).concat(speech.q), gen: speech.gen};
      speech.q = []; speech.playing = null; speech.gen++;
      cut.gen = speech.gen;
      stopAudio(); try { if (ss()) ss().cancel(); } catch (e) { /* nothing playing */ }
      return cut;
    }
    function resumeSpeech(cut) {
      if (!on || !cut || cut.gen !== speech.gen) return;   // a new answer began meanwhile
      speech.q = cut.q.concat(speech.q);
      if (speech.q.length || !speech.done) { setPhase('speak'); playNext(); } else afterSpeech();
    }
    function enqueue(pieces) {
      pieces.forEach(function (p) {
        var t = speakable(p); if (t && o.clean) t = String(o.clean(t) || '').trim();   // the voice says what the screen shows (VL-1 M1)
        if (!t) return;
        if (speech.said >= 4000) { if (!speech.capped) { speech.capped = true; speech.q.push('The rest is on screen.'); } return; }
        speech.said += t.length; speech.q.push(t);
      });
      if (!speech.playing && !capturing) playNext();
    }
    function playNext() {
      if (!on || speech.playing) return;
      if (!speech.q.length) { afterSpeech(); return; }
      if (srv.ok) { playServer(); return; }
      var v = voice();
      if (!v) {
        // voices load late in some browsers: one short wait, then the answer stays text
        if (!speech.noVoice && ss() && !speech.waited) { speech.waited = true; var g = speech.gen; setTimeout(function () { if (g === speech.gen) playNext(); }, 1200); return; }
        speech.noVoice = true; speech.q = [];
        var first = !speech.told;
        if (first) { speech.told = true; say('Live: ' + o.device() + ' has no voice that works offline here, so answers are shown as text. Still listening.', true); }
        afterSpeech(first);
        return;
      }
      var t = speech.q.shift(), g2 = speech.gen, ended = false;
      var u = new window.SpeechSynthesisUtterance(t);
      u.voice = v; u.lang = v.lang;
      var end = function () { if (ended) return; ended = true; clearTimeout(guard); if (g2 !== speech.gen) return; speech.playing = null; playNext(); };
      // some browsers never report the end of an utterance: a generous clock moves on
      var guard = setTimeout(end, 4000 + t.length * 110);
      u.onstart = function () { if (g2 === speech.gen) speech.at = Date.now(); };
      u.onend = end;
      u.onerror = function (e) { if (e && (e.error === 'canceled' || e.error === 'interrupted')) { ended = true; clearTimeout(guard); return; } end(); };
      speech.playing = t; speech.spoken += ' ' + t; speech.at = Date.now();
      if (phase !== 'speak') { setPhase('speak'); hint(); }
      try { ss().speak(u); } catch (e) { end(); }
    }
    function afterSpeech(keepNote) {
      if (!on) return;
      speech.playing = null; speech.capped = false; speech.waited = false;
      if (!speech.done) { if (phase !== 'think') { setPhase('think'); if (!keepNote) hint(); } return; }   // more of the answer is still coming
      lastVoice = Date.now(); armIdle();
      setPhase('listen'); if (!working && !keepNote) hint();
    }

    // ---- what the page tells Live ----------------------------------------------------------------------------------
    function delta(text) {
      if (!on || speech.done) return;
      speech.buf += String(text || '');
      var r = takeSentences(speech.buf, false); speech.buf = r.rest;
      if (r.out.length) enqueue(r.out);
    }
    // the answer is complete; `full` is its text when nothing was streamed (Gemini's text-only answers)
    function done(full, failed) {
      if (!on) return;
      held = '';
      if (speech.done) { if (phase === 'think') afterSpeech(); return; }   // already stopped by the person
      if (failed) {
        speech.buf = ''; speech.done = true;
        // answers failing twice in a row (not ones the person stopped): Live ends rather than listen for nothing
        if (++turnFails >= CFG.maxFails) { stop('Live ended: the last two answers failed. The chat shows what happened; press Live to try again.', true); return; }
        if (!speech.playing && !speech.q.length) afterSpeech();
        return;
      }
      turnFails = 0;
      if (full && !speech.spoken && !speech.q.length && !speech.buf) speech.buf = String(full);
      var r = takeSentences(speech.buf, true); speech.buf = '';
      speech.done = true;
      if (r.out.length) enqueue(r.out);
      if (!speech.playing && !speech.q.length && !capturing) afterSpeech();
    }
    // a card needs the person's own click (an approval, a question): said once, and nothing spoken is sent meanwhile
    function hold(what) {
      if (!on) return;
      held = what || 'Qosha is waiting for your answer on screen.';
      enqueue([held]);
    }
    function release() { held = ''; }
    // the person pressed Stop on the page: the voice stops too
    function quiet() { if (!on) return; shutUp(); if (phase !== 'listen') { setPhase('listen'); hint(); } }

    o.button.addEventListener('click', function () { if (on) stop(); else start(); });
    paint();
    return {
      start: start, stop: stop, delta: delta, done: done, hold: hold, release: release, quiet: quiet,
      // read-only view of the state, for checks (nothing can be changed through it)
      state: function () { return {phase: phase, capturing: !!capturing, playing: !!speech.playing, queued: speech.q.length, done: speech.done, noVoice: !!speech.noVoice, spokenChars: speech.spoken.length, buf: speech.buf.length}; },
      on: function () { return on; }, phase: function () { return phase; },
      _cfg: TEST ? CFG : undefined
    };
  }

  window.QoshaLive = {button: button, attach: attach, speakable: speakable, finished: finished, takeSentences: takeSentences, isEcho: isEcho, isPhrase: isPhrase,
                      END_LIVE: END_LIVE, STOP_ANSWER: STOP_ANSWER, _cfg: TEST ? CFG : undefined};   // the tests shorten the clocks; elsewhere fixed (VL-1 L1)
})();
