/* Qosha desktop notifications for the inbox watch (21 Nov 2026). Loaded once by the dashboard shell (index.js) in the
   top window. Every minute (and when the window comes back) it asks /inbox-watch/notices for what is new and shows a
   native notification through the browser's own Notification API; the Qosha app allows notifications for Qosha's own
   address only (desktop/src/policy.js), and the system shows them as Qosha's (Mac Notification Center, Windows).
   What it shows is the sender and subject as the mailbox has them and a fixed sentence per kind; the server never
   hands it the model's words. A click brings Qosha to the front and opens that email (or the digest) on Home.
   Each notification shows once: the last one shown is kept in this computer's local storage for Qosha's address. */
(function () {
  'use strict';
  if (window.__qoshaNotify || window.top !== window) return;
  window.__qoshaNotify = true;
  var KEY = 'qosha.iw.seq', API = '/api/plugins/qosha/inbox-watch/notices';
  var ICON = '/dashboard-plugins/qosha/assets/brand/icons/apple-touch-icon.png';
  var busy = false, off = false;
  function tok() { return String(window['__HERMES_SESSION_TOKEN__'] || ''); }
  function seen() { try { return parseInt(window.localStorage.getItem(KEY) || '', 10); } catch (e) { return NaN; } }
  function mark(n) { try { if (!(seen() >= n)) window.localStorage.setItem(KEY, String(n)); } catch (e) { /* none */ } }
  function can() { return typeof window.Notification === 'function' && window.Notification.permission === 'granted'; }
  function home(payload) {
    try { window.focus(); } catch (e) { /* none */ }
    try { window.sessionStorage.setItem('qosha.inbox.open', JSON.stringify(Object.assign({at: Date.now()}, payload))); } catch (e) { return; }
    var onHome = window.location.pathname.replace(/\/+$/, '') === '' && !/(?:^|[?&])view=/.test(window.location.search);
    if (!onHome) {
      if (typeof window.qoshaGo === 'function') window.qoshaGo('/'); else window.location.href = '/';
    }
  }
  function show(title, body, tag, payload) {
    try {
      var n = new window.Notification(title, {body: body, tag: tag, icon: ICON});
      n.onclick = function (ev) { try { ev.preventDefault(); } catch (e) { /* none */ } home(payload); try { n.close(); } catch (e) { /* none */ } };
    } catch (e) { /* the system refused: Home still shows it */ }
  }
  function words(x) {
    if (x.kind === 'digest') {
      var c = Number(x.count) || 0, u = Number(x.urgent) || 0;
      return ['Your inbox this morning', (u ? u + (u === 1 ? ' email needed you, ' : ' emails needed you, ') : '') + c + (c === 1 ? ' other came in.' : ' others came in.') + ' Click to see them.', {digest: true}];
    }
    return [String(x.from || 'New email').slice(0, 80), String(x.subject || '(no subject)').slice(0, 160) + ' · ' + String(x.why || ''),
            {open: String(x.msg || ''), subject: String(x.subject || ''), from: String(x.from || '')}];
  }
  function read() {
    if (busy || off || !tok()) return;
    busy = true;
    var last = seen();
    window.fetch(API + '?after=' + (isNaN(last) ? 0 : last), {credentials: 'same-origin', cache: 'no-store', headers: {'X-Hermes-Session-Token': tok()}})
      .then(function (r) { if (r.status === 404) off = true; return r.ok ? r.json() : null; })
      .then(function (d) {
        if (!d || !Array.isArray(d.items)) return;
        if (isNaN(last)) { mark(Number(d.seq) || 0); return; }      // first time on this computer: nothing old pops up
        var items = d.items.filter(function (x) { return Number(x.seq) > last; });
        if (!items.length || !can()) return;       // not allowed yet: they wait (they are on Home meanwhile)
        mark(Math.max.apply(null, items.map(function (x) { return Number(x.seq) || 0; })));
        var mails = items.filter(function (x) { return x.kind === 'mail'; });
        items.filter(function (x) { return x.kind === 'digest'; }).slice(-1).forEach(function (x) { var w = words(x); show(w[0], w[1], 'qosha-iw-' + x.seq, w[2]); });
        if (mails.length > 3) { show('Qosha', mails.length + ' emails need you. Click to see them.', 'qosha-iw-many', {digest: true}); return; }
        mails.forEach(function (x) { var w = words(x); show(w[0], w[1], 'qosha-iw-' + x.seq, w[2]); });
      }, function () { /* Qosha is restarting: the next minute tries again */ })
      .then(function () { busy = false; });
  }
  setTimeout(read, 4000);
  setInterval(read, 60000);
  window.addEventListener('focus', function () { setTimeout(read, 500); });
})();
