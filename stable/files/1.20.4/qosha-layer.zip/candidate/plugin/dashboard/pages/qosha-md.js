/* Qosha: Markdown in chat answers (U-E3 item 1, UAT 2 Nov: formatted like the engine's chat).
   Built from DOM nodes only: every piece of the answer becomes a text node, never markup, so an answer can't add
   HTML, scripts, styles, images or event handlers. A small, closed set of formatting: paragraphs, headings, bold,
   italics, strikethrough, inline code, code blocks, bullet and numbered lists (nested), quotes, rules, tables and
   links. Links only for http(s) and mailto; they open outside the chat (new tab, no opener, no referrer).
   QoshaMd.render(text, clean) -> DocumentFragment; `clean` (optional) rewrites the words of each text node. */
(function () {
  'use strict';
  var MAX_DEPTH = 8;            // nesting of quotes/lists/inline formatting
  var MAX_LEN = 100000;         // longer answers are shown as plain text
  var MAX_NODES = 5000;         // elements per answer; past it the answer is shown as plain text (GPT R-touchups1 HIGH)
  var MAX_COLS = 20, MAX_ROWS = 200;   // a bigger table is shown as its text
  var made = 0;
  function Over() {}

  function node(tag, cls) {
    if (++made > MAX_NODES) throw new Over();
    var n = document.createElement(tag); if (cls) n.className = cls; return n;
  }
  function safeHref(u) {
    u = String(u || '').trim();
    if (/[\x00-\x20\x7f<>"'`\\]/.test(u)) return null;
    if (/^https?:\/\/[^/?#]/i.test(u)) return u;
    if (/^mailto:[^@\s/]+@[^@\s/]+$/i.test(u)) return u;
    return null;
  }
  function link(href, kids) {
    var a = node('a');
    a.setAttribute('href', href);
    a.setAttribute('target', '_blank');
    a.setAttribute('rel', 'noopener noreferrer nofollow');
    kids.forEach(function (k) { a.appendChild(k); });
    return a;
  }

  // ---- inline ----------------------------------------------------------------------------------------------------
  // earliest match wins; alternatives in order: code, link, bold (** or __), strikethrough, italics (*), bare address
    // every span is bounded, so a long answer can't make the search slow (GPT R-touchups1 HIGH)
  var INLINE = /`([^`\n]{1,1000})`|\[([^\]\n]{1,500})\]\(<?([^)\s>]{1,2000})>?\)|\*\*(?=\S)([\s\S]{0,1000}?\S)\*\*|__(?=\S)([\s\S]{0,1000}?\S)__|~~(?=\S)([\s\S]{0,1000}?\S)~~|\*(?=[^\s*])([^*\n]{0,1000}?[^\s*])\*|(https?:\/\/[^\s<>"'`]{1,2000})/g;
  function inline(s, clean, depth, noLink) {
    var out = [], last = 0, m;
    var text = function (t) { if (t) out.push(document.createTextNode(clean(t))); };
    if (depth > MAX_DEPTH) { text(s); return out; }
    var re = new RegExp(INLINE.source, 'g');
    while ((m = re.exec(s))) {
      if (m[0] === '') { re.lastIndex++; continue; }
      text(s.slice(last, m.index));
      last = re.lastIndex;
      var n;
      if (m[1] != null) { n = node('code'); n.textContent = m[1]; }
      else if (m[2] != null) {
        var href = noLink ? null : safeHref(m[3]);
        if (!href) { out = out.concat(inline(m[2], clean, depth + 1, true)); continue; }
        n = link(href, inline(m[2], clean, depth + 1, true));
      }
      else if (m[4] != null || m[5] != null) { n = node('strong'); inline(m[4] != null ? m[4] : m[5], clean, depth + 1, noLink).forEach(function (k) { n.appendChild(k); }); }
      else if (m[6] != null) { n = node('del'); inline(m[6], clean, depth + 1, noLink).forEach(function (k) { n.appendChild(k); }); }
      else if (m[7] != null) { n = node('em'); inline(m[7], clean, depth + 1, noLink).forEach(function (k) { n.appendChild(k); }); }
      else if (m[8] != null) {
        var u = m[8].replace(/[.,;:!?)\]*]+$/, ''), tail = m[8].slice(u.length);
        if (noLink || u.length < 9 || !safeHref(u)) { text(m[8]); continue; }
        out.push(link(u, [document.createTextNode(u)]));
        text(tail);
        continue;
      }
      out.push(n);
    }
    text(s.slice(last));
    return out;
  }
  function fill(n, s, clean, depth) { inline(s, clean, depth || 0, false).forEach(function (k) { n.appendChild(k); }); return n; }

  // ---- blocks ----------------------------------------------------------------------------------------------------
  // patterns with no two neighbouring repeats that can match the same characters (linear on any line)
  var FENCE = /^ {0,3}(`{3,}(?!`)|~{3,}(?!~))/;
  function isFence(line) { var m = FENCE.exec(line); return !!m && (m[1].charAt(0) === '~' || line.indexOf('`', m[0].length) < 0); }
  var HEAD = /^ {0,3}(#{1,6})(?:[ \t]+(.*))?$/;
  var QUOTE = /^ {0,3}>[ ]?(.*)$/;
  var ITEM = /^([ \t]*)([-*+]|\d{1,9}[.)])[ \t]+(.*)$/;
  function isRule(line) { var t = line.replace(/[ \t]/g, ''); return /^ {0,3}[-*_]/.test(line) && t.length >= 3 && /^(-+|\*+|_+)$/.test(t); }
  function heading(line) {
    var m = HEAD.exec(line);
    if (!m) return null;
    var t = (m[2] || '').trim(), j = t.length;
    while (j > 0 && t.charAt(j - 1) === '#') j--;
    if (j < t.length && (j === 0 || /[ \t]/.test(t.charAt(j - 1)))) t = t.slice(0, j).trim();   // closing #s
    return {level: m[1].length, text: t};
  }
  function indentOf(s) { var m = /^[ \t]*/.exec(s)[0]; return m.replace(/\t/g, '    ').length; }
  // a table row's cells: "\|" is a pipe inside a cell (GPT R-touchups1)
  function cells(line) {
    var t = line.trim(), out = [], cur = '';
    if (t.charAt(0) === '|') t = t.slice(1);
    for (var i = 0; i < t.length; i++) {
      var c = t.charAt(i);
      if (c === '\\' && t.charAt(i + 1) === '|') { cur += '|'; i++; }
      else if (c === '|') { out.push(cur.trim()); cur = ''; }
      else cur += c;
    }
    if (cur.trim() || t.charAt(t.length - 1) !== '|') out.push(cur.trim());
    return out;
  }
  function isSep(line) {
    if (line == null || line.indexOf('-') < 0) return false;
    var c = cells(line);
    return c.length > 0 && c.every(function (x) { return /^:?-{2,}:?$/.test(x); });
  }
  function isTable(line, next) {
    if (line.indexOf('|') < 0 || !isSep(next)) return false;
    var n = cells(line).length;
    return n >= 1 && n <= MAX_COLS && cells(next).length === n;
  }
  function starts(line, next) {
    return isFence(line) || !!heading(line) || isRule(line) || QUOTE.test(line) || ITEM.test(line) || isTable(line, next);
  }
  // a fenced block from lines[i] (the opening fence); returns [pre, next index]
  function fenced(lines, i, strip, firstOff) {
    var m = FENCE.exec(lines[i].slice(firstOff != null ? firstOff : Math.min(strip, indentOf(lines[i])))), fence = m[1], body = [];
    i++;
    while (i < lines.length) {
      var l = lines[i], k = 0;
      while (k < strip && (l.charAt(k) === ' ' || l.charAt(k) === '\t')) k++;
      l = l.slice(k);
      var t = l.replace(/^ {0,3}/, '');
      if (t.length >= fence.length && t.charAt(0) === fence.charAt(0) && /^[`~]+[ \t]*$/.test(t) && t.replace(/[ \t]/g, '').length >= fence.length &&
          t.replace(/[ \t]/g, '').split('').every(function (ch) { return ch === fence.charAt(0); })) { i++; break; }
      body.push(l); i++;
    }
    var pre = node('pre'), code = node('code');
    code.textContent = body.join('\n');   // code is shown exactly as written
    pre.appendChild(code);
    return [pre, i];
  }

  function blocks(lines, clean, depth) {
    var frag = document.createDocumentFragment(), i = 0, m;
    if (depth > MAX_DEPTH) { var p0 = node('p'); p0.appendChild(document.createTextNode(clean(lines.join('\n')))); frag.appendChild(p0); return frag; }
    while (i < lines.length) {
      var line = lines[i];
      if (!line.trim()) { i++; continue; }
      if (isFence(line)) { var fb = fenced(lines, i, 0); frag.appendChild(fb[0]); i = fb[1]; continue; }
      var hd = heading(line);
      if (hd) {
        var h = node(hd.level <= 1 ? 'h3' : hd.level === 2 ? 'h4' : 'h5');
        frag.appendChild(fill(h, hd.text, clean, depth)); i++;
        continue;
      }
      if (isRule(line)) { frag.appendChild(node('hr')); i++; continue; }
      if (QUOTE.test(line)) {
        var q = [];
        while (i < lines.length && (m = QUOTE.exec(lines[i]))) { q.push(m[1]); i++; }
        var bq = node('blockquote'); bq.appendChild(blocks(q, clean, depth + 1)); frag.appendChild(bq);
        continue;
      }
      if (isTable(line, lines[i + 1])) {
        var head = cells(line), rows = [];
        i += 2;
        while (i < lines.length && rows.length < MAX_ROWS && lines[i].trim() && lines[i].indexOf('|') >= 0) rows.push(cells(lines[i++]));
        var wrap = node('div', 'md-table'), table = node('table'), thead = node('thead'), tr = node('tr');
        head.forEach(function (c) { var th = node('th'); th.setAttribute('scope', 'col'); tr.appendChild(fill(th, c, clean, depth)); });
        thead.appendChild(tr); table.appendChild(thead);
        var tbody = node('tbody');
        rows.forEach(function (r) {
          var row = node('tr');
          for (var k = 0; k < head.length; k++) row.appendChild(fill(node('td'), r[k] || '', clean, depth));
          tbody.appendChild(row);
        });
        table.appendChild(tbody); wrap.appendChild(table); frag.appendChild(wrap);
        continue;
      }
      if (ITEM.test(line)) { var res = list(lines, i, clean, depth); frag.appendChild(res[0]); i = res[1]; continue; }
      var para = [line.trim()];
      i++;
      while (i < lines.length && lines[i].trim() && !starts(lines[i], lines[i + 1])) para.push(lines[i++].trim());
      frag.appendChild(fill(node('p'), para.join('\n'), clean, depth));
    }
    return frag;
  }
  function list(lines, i, clean, depth) {
    var first = ITEM.exec(lines[i]), base = indentOf(lines[i]), ordered = /\d/.test(first[2]);
    var ul = node(ordered ? 'ol' : 'ul');
    if (ordered) { var start = parseInt(first[2], 10); if (start !== 1 && start < 1e6) ul.setAttribute('start', String(start)); }
    var li = null, text = [];
    function flush() { if (li && text.length) li.appendChild(fill(node('span'), text.join('\n'), clean, depth + 1)); text = []; }
    while (i < lines.length) {
      var line = lines[i], m = ITEM.exec(line), ind = indentOf(line);
      if (!line.trim()) {   // a blank line ends the list unless the next line carries on with it
        var j = i + 1;
        while (j < lines.length && !lines[j].trim()) j++;
        if (j < lines.length && (indentOf(lines[j]) > base || (ITEM.test(lines[j]) && indentOf(lines[j]) === base && /\d/.test(ITEM.exec(lines[j])[2]) === ordered))) { i = j; continue; }
        break;
      }
      if (m && ind === base && /\d/.test(m[2]) === ordered) {
        flush(); li = node('li'); ul.appendChild(li);
        if (isFence(m[3])) {   // "- ```js": the item is a code block, kept verbatim (GPT R-touchups2)
          var off = line.length - m[3].length, fb0 = fenced(lines, i, off, off);
          li.appendChild(fb0[0]); i = fb0[1]; text = [];
          continue;
        }
        text = [m[3]]; i++;
        continue;
      }
      if (m && ind > base && li) {
        var sub = list(lines, i, clean, depth + 1);
        flush(); li.appendChild(sub[0]); i = sub[1];
        continue;
      }
      if (ind > base && li && isFence(line.trim())) {   // a code block inside the item, kept verbatim (GPT R-touchups1)
        flush(); var fb = fenced(lines, i, ind); li.appendChild(fb[0]); i = fb[1];
        continue;
      }
      if (ind > base && li) { text.push(line.trim()); i++; continue; }
      break;
    }
    flush();
    return [ul, i];
  }

  function render(text, clean) {
    clean = typeof clean === 'function' ? clean : function (t) { return t; };
    var frag = document.createDocumentFragment();
    text = String(text == null ? '' : text).replace(/\r\n?/g, '\n');
    var plain = function () { var p = document.createElement('p'); p.textContent = clean(text); frag = document.createDocumentFragment(); frag.appendChild(p); return frag; };
    if (text.length > MAX_LEN) return plain();
    made = 0;
    try { frag.appendChild(blocks(text.split('\n'), clean, 0)); }
    catch (e) { if (e instanceof Over) return plain(); throw e; }
    return frag;
  }
  window.QoshaMd = {render: render};
})();
