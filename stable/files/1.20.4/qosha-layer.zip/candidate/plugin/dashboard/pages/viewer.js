/* Qosha file viewer (night job 4, UAT 21:35 2 Nov: "files inside the Qosha side panel need to behave as close as
   possible to how artifacts behave on Claude"). One panel, used by Chat (beside the conversation) and Files.

   Safety (non-negotiable):
   - Anything from a file that can run (HTML, SVG, Markdown, tables, documents) is drawn in an <iframe sandbox> WITHOUT
     allow-same-origin: an opaque origin, so it can't read Qosha's session token, cookies, local storage or call its API.
     No allow-top-navigation, no allow-popups (Markdown links open a new tab only when the person clicks them).
   - Each frame starts with a Content-Security-Policy: no network at all (connect, images, fonts, frames, forms), only
     inline script/style. The diagram frame alone may load one pinned, integrity-checked script from cdn.jsdelivr.net.
   - A frame that navigates away from its file (a link, a script, a refresh tag) is put back and the person is told.
   - Markdown, code, tables and documents are built from escaped text: nothing from the file becomes markup unescaped.
   - Bytes come from Qosha's own no-follow file routes (files_api.py), only inside the Qosha files folder; big files get
     a plain message instead of a preview.
*/
(function () {
  'use strict';
  var Q = window.Qosha;
  var API = '/api/plugins/qosha/files/';
  var TEXT_MAX = 2 * 1024 * 1024;          // text previews up to 2 MB
  var ROWS_MAX = 1000, COLS_MAX = 60;
  var POLL_MS = 1500;
  var MERMAID = {src: 'https://cdn.jsdelivr.net/npm/mermaid@11.4.1/dist/mermaid.min.js',
                 sri: 'sha384-rbtjAdnIQE/aQJGEgXrVUlMibdfTSa4PQju4HDhN3sR2PmaKFzhEafuePsl9H/9I'};
  var CSP = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; " +
            "font-src data:; media-src data: blob:; connect-src 'none'; form-action 'none'; frame-src 'none'; " +
            "child-src 'none'; worker-src 'none'; base-uri 'none'; object-src 'none'";
  var CSP_MERMAID = CSP.replace("script-src 'unsafe-inline'", "script-src 'unsafe-inline' " + MERMAID.src);
  var EXT = {
    html: 'html', htm: 'html', svg: 'svg', md: 'markdown', markdown: 'markdown', mmd: 'mermaid', mermaid: 'mermaid',
    csv: 'csv', tsv: 'csv', xlsx: 'xlsx', docx: 'docx', pptx: 'pptx', pdf: 'pdf',
    png: 'image', jpg: 'image', jpeg: 'image', gif: 'image', webp: 'image', bmp: 'image', avif: 'image', ico: 'image',
    txt: 'text', log: 'text'
  };
  var CODE = ['js', 'mjs', 'cjs', 'ts', 'tsx', 'jsx', 'py', 'rb', 'go', 'rs', 'java', 'kt', 'swift', 'c', 'h', 'cpp', 'hpp', 'cs',
              'php', 'sh', 'bash', 'zsh', 'css', 'scss', 'json', 'yaml', 'yml', 'toml', 'ini', 'xml', 'sql', 'r', 'lua', 'pl', 'dart'];
  CODE.forEach(function (e) { EXT[e] = 'code'; });
  var IMAGE_TYPE = {png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp',
                    bmp: 'image/bmp', avif: 'image/avif', ico: 'image/x-icon'};
  var HAS_SOURCE = {html: 1, svg: 1, markdown: 1, mermaid: 1, csv: 1};
  var ext = function (name) { var m = /\.([A-Za-z0-9]+)$/.exec(name || ''); return m ? m[1].toLowerCase() : ''; };
  function kindOf(name) { return EXT[ext(name)] || 'other'; }
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // ---- requests (the session header from Qosha's page helper; never a token in a URL) ----------------------------
  function bytes(url) {
    var headers = {}, t = Q.token();
    if (t) headers['X-Hermes-Session-Token'] = t;
    return fetch(url, {credentials: 'same-origin', cache: 'no-store', headers: headers}).then(function (r) {
      if (!r.ok) { var e = new Error('read'); e.status = r.status; throw e; }
      return r.arrayBuffer();
    });
  }
  function decode(buf) { return new TextDecoder('utf-8', {fatal: false}).decode(buf); }

  // ---- sandboxed documents ---------------------------------------------------------------------------------------
  var BASE_CSS = 'body{font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#10231A;background:#fff;margin:0;padding:24px 28px;overflow-wrap:anywhere}' +
    'h1,h2,h3,h4{line-height:1.3;margin:1.2em 0 .5em}h1{font-size:1.8em}h2{font-size:1.4em}h3{font-size:1.15em}' +
    'pre{background:#F3F5F2;border-radius:10px;padding:12px 14px;overflow:auto;font:13px/1.5 ui-monospace,Menlo,monospace}' +
    'code{font:.9em ui-monospace,Menlo,monospace;background:#F3F5F2;border-radius:6px;padding:1px 5px}pre code{background:none;padding:0}' +
    'blockquote{margin:0;padding:4px 16px;border-left:3px solid #C9A24B;color:#3C5247}' +
    'table{border-collapse:collapse;margin:8px 0;font-size:14px}th,td{border:1px solid #D9DED9;padding:6px 10px;text-align:left;vertical-align:top}' +
    'th{background:#F3F5F2;font-weight:600}a{color:#0B6E4F}img{max-width:100%}hr{border:0;border-top:1px solid #D9DED9;margin:20px 0}' +
    '.slide{border:1px solid #D9DED9;border-radius:14px;padding:16px 20px;margin:0 0 16px}.slide h2{margin-top:0;font-size:13px;color:#5B6B62;text-transform:none}' +
    '.tabs{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 12px}.tabs a{padding:4px 12px;border-radius:999px;background:#F3F5F2;text-decoration:none;color:#10231A}' +
    '.note{color:#5B6B62;font-size:13px}';
  function frameDoc(body, extraHead, csp) {
    return '<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="' + esc(csp || CSP) + '">' +
      '<meta name="viewport" content="width=device-width,initial-scale=1"><style>' + BASE_CSS + '</style>' + (extraHead || '') + '</head><body>' + body + '</body></html>';
  }
  // The wrapper: Qosha's own small document holding the file's document in an inner frame loaded from a blob: URL the
  // wrapper makes (a srcdoc child would be blocked by its own frame-src rule). frame-src allows blob: only, so when the
  // file tries to go anywhere else (a link, a script, a refresh tag) the browser stops it before any request is sent.
  function jsString(t) { return JSON.stringify(t).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029'); }
  function wrapDoc(doc, sandbox, csp) {
    var wcsp = csp.replace("frame-src 'none'", 'frame-src blob:').replace("child-src 'none'", 'child-src blob:');
    return '<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="' + esc(wcsp) + '">' +
      '<style>html,body{margin:0;height:100%;overflow:hidden;background:#fff}iframe{border:0;width:100%;height:100%;display:block}</style></head><body>' +
      '<script>(function(){var u=URL.createObjectURL(new Blob([' + jsString(doc) + '],{type:"text/html;charset=utf-8"}));' +
      'var f=document.createElement("iframe");f.setAttribute("sandbox",' + jsString(sandbox) + ');f.setAttribute("referrerpolicy","no-referrer");' +
      'var n=0,k=0;f.addEventListener("load",function(){n++;if(n<2)return;n=0;k++;try{parent.postMessage({qoshaViewer:"kept"},"*")}catch(e){}' +
      'if(k<=3){f.src=u;return;}var m=document.createElement("p");m.style.cssText="font:15px -apple-system,sans-serif;padding:24px;color:#3C5247";' +
      'm.textContent="This file kept trying to open other addresses, so Qosha stopped showing it. You can download it.";f.replaceWith(m);});' +
      'f.src=u;document.body.appendChild(f);})();</script></body></html>';
  }
  // the file's own HTML, with the policy placed first (after a doctype, so the page keeps its rendering mode)
  var NO_RTC = '<script>(function(){["RTCPeerConnection","webkitRTCPeerConnection","RTCDataChannel","RTCIceCandidate","RTCSessionDescription"].forEach(function(n){' +
    'try{Object.defineProperty(window,n,{value:undefined,writable:false,configurable:false});}catch(e){}});})();</script>';
  function htmlDoc(src, run) {
    var meta = '<meta http-equiv="Content-Security-Policy" content="' + esc(CSP) + '">' + (run ? NO_RTC : '');
    var m = /^\s*(<!doctype[^>]*>)/i.exec(src);
    return m ? m[1] + meta + src.slice(m[0].length) : meta + src;
  }

  // ---- Markdown: escaped first, then a small, closed set of formatting (no raw HTML from the file) -------------
  function inline(s) {
    var codes = [];
    s = s.replace(/`([^`\n]+)`/g, function (_, c) { codes.push(c); return '\u0000' + (codes.length - 1) + '\u0000'; });
    s = esc(s);
    s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, function (_, alt) { return '[' + alt + ']'; });   // images: no network
    s = s.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, function (_, t, u) {
      var raw = u.replace(/&amp;/g, '&');
      return /^(https?:|mailto:)/i.test(raw) ? '<a href="' + u + '" target="_blank" rel="noopener noreferrer">' + t + '</a>' : t;
    });
    s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/__([^_]+)__/g, '<strong>$1</strong>')
         .replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>').replace(/~~([^~]+)~~/g, '<del>$1</del>');
    return s.replace(/\u0000(\d+)\u0000/g, function (_, i) { return '<code>' + esc(codes[+i]) + '</code>'; });
  }
  function markdown(src, diagrams) {
    var lines = src.replace(/\r\n?/g, '\n').split('\n'), out = [], i = 0, list = null;
    function closeList() { if (list) { out.push('</' + list + '>'); list = null; } }
    while (i < lines.length) {
      var l = lines[i], m;
      if ((m = /^\s*(```|~~~)\s*([\w+-]*)/.exec(l))) {
        closeList();
        var fence = m[1], lang = m[2].toLowerCase(), body = [];
        i++;
        while (i < lines.length && lines[i].trim().indexOf(fence) !== 0) body.push(lines[i++]);
        i++;
        if (lang === 'mermaid' && diagrams) { diagrams.push(body.join('\n')); out.push('<pre class="mermaid">' + esc(body.join('\n')) + '</pre>'); }
        else out.push('<pre><code>' + esc(body.join('\n')) + '</code></pre>');
        continue;
      }
      if (/^\s*$/.test(l)) { closeList(); i++; continue; }
      if ((m = /^(#{1,6})\s+(.*)$/.exec(l))) { closeList(); out.push('<h' + m[1].length + '>' + inline(m[2]) + '</h' + m[1].length + '>'); i++; continue; }
      if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(l)) { closeList(); out.push('<hr>'); i++; continue; }
      if (/^\s*>/.test(l)) {
        closeList();
        var q = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) q.push(lines[i++].replace(/^\s*>\s?/, ''));
        out.push('<blockquote>' + q.map(inline).join('<br>') + '</blockquote>');
        continue;
      }
      if (/^\s*\|.*\|\s*$/.test(l) && i + 1 < lines.length && /^\s*\|?[\s:|-]+\|?\s*$/.test(lines[i + 1]) && lines[i + 1].indexOf('-') >= 0) {
        closeList();
        var cells = function (r) { return r.trim().replace(/^\||\|$/g, '').split('|').map(function (c) { return inline(c.trim()); }); };
        var t = '<table><thead><tr>' + cells(l).map(function (c) { return '<th>' + c + '</th>'; }).join('') + '</tr></thead><tbody>';
        i += 2;
        while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) t += '<tr>' + cells(lines[i++]).map(function (c) { return '<td>' + c + '</td>'; }).join('') + '</tr>';
        out.push(t + '</tbody></table>');
        continue;
      }
      if ((m = /^\s*([-*+]|\d+[.)])\s+(.*)$/.exec(l))) {
        var want = /\d/.test(m[1]) ? 'ol' : 'ul';
        if (list !== want) { closeList(); out.push('<' + want + '>'); list = want; }
        var item = m[2].replace(/^\[( |x|X)\]\s+/, function (_, x) { return x === ' ' ? '☐ ' : '☑ '; });
        out.push('<li>' + inline(item) + '</li>');
        i++;
        continue;
      }
      closeList();
      var para = [l];
      i++;
      while (i < lines.length && !/^\s*$/.test(lines[i]) && !/^(#{1,6}\s|\s*```|\s*~~~|\s*>|\s*([-*+]|\d+[.)])\s)/.test(lines[i])) para.push(lines[i++]);
      out.push('<p>' + para.map(inline).join('<br>') + '</p>');
    }
    closeList();
    return out.join('\n');
  }
  function mermaidHead() {
    return '<script src="' + MERMAID.src + '" integrity="' + MERMAID.sri + '" crossorigin="anonymous"></script>' +
      '<script>window.addEventListener("load",function(){if(!window.mermaid){var n=document.createElement("p");n.className="note";' +
      'n.textContent="The diagram could not be drawn here (its drawing library did not load). The source is shown instead.";document.body.prepend(n);return;}' +
      'mermaid.initialize({startOnLoad:false,securityLevel:"strict"});mermaid.run({querySelector:"pre.mermaid"}).catch(function(){});});</script>';
  }

  // ---- code: escaped text with a few colours (strings, comments, numbers, keywords) ------------------------------
  var KW = /\b(function|return|var|let|const|if|else|for|while|do|switch|case|break|continue|new|class|extends|import|from|export|default|try|catch|finally|throw|async|await|yield|def|lambda|pass|elif|in|is|not|and|or|None|True|False|null|true|false|undefined|this|self|public|private|protected|static|void|int|string|bool|struct|enum|interface|type|package|func|fn|mut|impl|use|match|select|insert|update|delete|where|join|create|table)\b/g;
  function highlight(src) {
    var re = /(\/\*[\s\S]*?\*\/|\/\/[^\n]*|#[^\n]*|"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'|`(?:[^`\\]|\\.)*`|\b\d+(?:\.\d+)?\b)/g;
    var out = '', last = 0, m;
    while ((m = re.exec(src))) {
      out += esc(src.slice(last, m.index)).replace(KW, '<span class="k">$1</span>');
      var t = m[0], c = /^(\/\*|\/\/|#)/.test(t) ? 'c' : /^\d/.test(t) ? 'n' : 's';
      out += '<span class="' + c + '">' + esc(t) + '</span>';
      last = m.index + t.length;
    }
    return out + esc(src.slice(last)).replace(KW, '<span class="k">$1</span>');
  }

  // ---- tables ----------------------------------------------------------------------------------------------------
  function parseCsv(src, sep) {
    var rows = [], row = [], cell = '', q = false, i = 0, n = src.length;
    for (; i < n && rows.length <= ROWS_MAX; i++) {
      var ch = src[i];
      if (q) {
        if (ch === '"') { if (src[i + 1] === '"') { cell += '"'; i++; } else q = false; }
        else cell += ch;
      } else if (ch === '"' && cell === '') q = true;
      else if (ch === sep) { row.push(cell); cell = ''; }
      else if (ch === '\n' || ch === '\r') { if (ch === '\r' && src[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; }
      else cell += ch;
    }
    if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
    return rows;
  }
  function tableHtml(rows, truncated) {
    if (!rows.length) return '<p class="note">This table is empty.</p>';
    var cols = Math.min(COLS_MAX, rows.reduce(function (a, r) { return Math.max(a, r.length); }, 0));
    var h = '<table><thead><tr>';
    for (var c = 0; c < cols; c++) h += '<th>' + esc(rows[0][c] == null ? '' : rows[0][c]) + '</th>';
    h += '</tr></thead><tbody>';
    rows.slice(1, ROWS_MAX).forEach(function (r) {
      h += '<tr>';
      for (var c2 = 0; c2 < cols; c2++) h += '<td>' + esc(r[c2] == null ? '' : r[c2]) + '</td>';
      h += '</tr>';
    });
    h += '</tbody></table>';
    if (truncated || rows.length > ROWS_MAX) h += '<p class="note">Showing the first ' + ROWS_MAX + ' rows. Download the file to see all of it.</p>';
    return h;
  }

  // ---- Office files: a small reader for the zip container (the browser's own inflate) + XML text --------------
  var ZIP_ENTRY_MAX = 40 * 1024 * 1024, ZIP_TOTAL_MAX = 60 * 1024 * 1024, ZIP_ENTRIES_MAX = 2000;
  function unzip(buf) {
    var dv = new DataView(buf), n = buf.byteLength, eocd = -1;
    for (var i = n - 22; i >= Math.max(0, n - 65557); i--) if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    if (eocd < 0) throw new Error('not a zip');
    var count = Math.min(ZIP_ENTRIES_MAX, dv.getUint16(eocd + 10, true)), off = dv.getUint32(eocd + 16, true), entries = {}, budget = ZIP_TOTAL_MAX;
    for (var k = 0; k < count && off + 46 <= n; k++) {
      if (dv.getUint32(off, true) !== 0x02014b50) break;
      var method = dv.getUint16(off + 10, true), csize = dv.getUint32(off + 20, true), usize = dv.getUint32(off + 24, true);
      var nlen = dv.getUint16(off + 28, true), xlen = dv.getUint16(off + 30, true), clen = dv.getUint16(off + 32, true);
      var local = dv.getUint32(off + 42, true);
      var name = decode(buf.slice(off + 46, off + 46 + nlen));
      entries[name] = {method: method, csize: csize, usize: usize, local: local};
      off += 46 + nlen + xlen + clen;
    }
    return {
      names: Object.keys(entries),
      text: function (name) {
        var e = entries[name];
        if (!e) return Promise.resolve(null);
        if (e.usize > ZIP_ENTRY_MAX || e.usize > budget) return Promise.reject(new Error('too large'));
        var start = e.local + 30 + dv.getUint16(e.local + 26, true) + dv.getUint16(e.local + 28, true);
        var raw = buf.slice(start, start + e.csize);
        if (e.method === 0) { budget -= raw.byteLength; return budget < 0 ? Promise.reject(new Error('too large')) : Promise.resolve(decode(raw)); }
        if (e.method !== 8 || typeof DecompressionStream !== 'function') return Promise.reject(new Error('method'));
        var reader = new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();
        var parts = [], total = 0;
        function pump() {
          return reader.read().then(function (r) {
            if (r.done) return decode(new Blob(parts).size ? concat(parts, total) : new ArrayBuffer(0));
            total += r.value.byteLength;
            budget -= r.value.byteLength;   // every entry of the document draws on one budget
            if (total > ZIP_ENTRY_MAX || budget < 0) { reader.cancel(); throw new Error('too large'); }
            parts.push(r.value);
            return pump();
          });
        }
        return pump();
      }
    };
  }
  function concat(parts, total) {
    var u = new Uint8Array(total), o = 0;
    parts.forEach(function (p) { u.set(p, o); o += p.byteLength; });
    return u.buffer;
  }
  function inTurn(names, read) {   // one entry at a time, so a crafted file can't start hundreds of inflations at once
    var out = [];
    return names.reduce(function (p, n) { return p.then(function () { return read(n).then(function (t) { out.push(t); }); }); }, Promise.resolve())
      .then(function () { return out; });
  }
  function xml(s) { return new DOMParser().parseFromString(s || '<x/>', 'application/xml'); }
  function byLocal(node, name) {
    var out = [], all = node.getElementsByTagName('*');
    for (var i = 0; i < all.length; i++) if (all[i].localName === name) out.push(all[i]);
    return out;
  }
  function textOf(node, tname) { return byLocal(node, tname).map(function (t) { return t.textContent; }).join(''); }
  function attr(node, name) {
    for (var i = 0; i < node.attributes.length; i++) if (node.attributes[i].localName === name) return node.attributes[i].value;
    return null;
  }
  function colIndex(ref) {
    var m = /^([A-Z]+)/.exec(ref || ''), n = 0;
    if (!m) return -1;
    for (var i = 0; i < m[1].length; i++) n = n * 26 + (m[1].charCodeAt(i) - 64);
    return n - 1;
  }
  function xlsxHtml(z) {
    return inTurn(['xl/sharedStrings.xml', 'xl/workbook.xml'], z.text).then(function (r) {
      var shared = r[0] ? byLocal(xml(r[0]), 'si').map(function (si) { return textOf(si, 't'); }) : [];
      var names = r[1] ? byLocal(xml(r[1]), 'sheet').map(function (s) { return s.getAttribute('name') || ''; }) : [];
      var sheets = z.names.filter(function (n) { return /^xl\/worksheets\/sheet\d+\.xml$/.test(n); })
        .sort(function (a, b) { return parseInt(a.replace(/\D/g, ''), 10) - parseInt(b.replace(/\D/g, ''), 10); }).slice(0, 20);
      return inTurn(sheets, z.text).then(function (docs) {
        var tabs = docs.length > 1 ? '<nav class="tabs">' + docs.map(function (_, i) { return '<a href="#s' + i + '">' + esc(names[i] || 'Sheet ' + (i + 1)) + '</a>'; }).join('') + '</nav>' : '';
        return tabs + docs.map(function (d, i) {
          var rows = [], cut = false;
          byLocal(xml(d), 'row').forEach(function (rw) {
            if (rows.length >= ROWS_MAX) { cut = true; return; }
            var row = [];
            byLocal(rw, 'c').forEach(function (c) {
              var ci = colIndex(c.getAttribute('r'));
              if (ci < 0 || ci >= COLS_MAX) return;
              var t = c.getAttribute('t'), v = byLocal(c, 'v')[0], val = v ? v.textContent : '';
              if (t === 's') val = shared[parseInt(val, 10)] || '';
              else if (t === 'inlineStr') val = textOf(c, 't');
              else if (t === 'b') val = val === '1' ? 'TRUE' : 'FALSE';
              row[ci] = val;
            });
            rows.push(row);
          });
          return '<h2 id="s' + i + '">' + esc(names[i] || 'Sheet ' + (i + 1)) + '</h2>' + tableHtml(rows, cut);
        }).join('');
      });
    });
  }
  function docxHtml(z) {
    return z.text('word/document.xml').then(function (s) {
      if (!s) throw new Error('no document');
      var body = byLocal(xml(s), 'body')[0], out = [], blocks = 0;
      if (!body) return '';
      for (var i = 0; i < body.childNodes.length && blocks < 5000; i++) {
        var n = body.childNodes[i];
        if (n.nodeType !== 1) continue;
        blocks++;
        if (n.localName === 'p') {
          var style = byLocal(n, 'pStyle')[0], sv = style ? attr(style, 'val') || '' : '';
          var html = byLocal(n, 'r').map(function (r) {
            var t = esc(textOf(r, 't')), b = byLocal(r, 'b')[0], it = byLocal(r, 'i')[0];
            if (b && attr(b, 'val') !== '0' && attr(b, 'val') !== 'false') t = '<strong>' + t + '</strong>';
            if (it && attr(it, 'val') !== '0' && attr(it, 'val') !== 'false') t = '<em>' + t + '</em>';
            return t;
          }).join('');
          var h = /^(?:Heading|heading)\s?(\d)$/.exec(sv) || (sv === 'Title' ? [0, '1'] : null);
          if (h) out.push('<h' + Math.min(6, +h[1]) + '>' + html + '</h' + Math.min(6, +h[1]) + '>');
          else if (byLocal(n, 'numPr').length) out.push('<ul><li>' + html + '</li></ul>');
          else out.push(html ? '<p>' + html + '</p>' : '');
        } else if (n.localName === 'tbl') {
          out.push(tableHtml(byLocal(n, 'tr').map(function (tr) { return byLocal(tr, 'tc').map(function (tc) { return textOf(tc, 't'); }); })));
        }
      }
      return out.join('\n').replace(/<\/ul>\n<ul>/g, '\n');
    });
  }
  function pptxHtml(z) {
    var slides = z.names.filter(function (n) { return /^ppt\/slides\/slide\d+\.xml$/.test(n); })
      .sort(function (a, b) { return parseInt(a.replace(/\D/g, ''), 10) - parseInt(b.replace(/\D/g, ''), 10); }).slice(0, 300);
    return inTurn(slides, z.text).then(function (docs) {
      return docs.map(function (d, i) {
        var paras = byLocal(xml(d), 'p').map(function (p) { return textOf(p, 't'); }).filter(function (t) { return t.trim(); });
        return '<section class="slide"><h2>Slide ' + (i + 1) + '</h2>' + (paras.length
          ? '<h3>' + esc(paras[0]) + '</h3>' + paras.slice(1).map(function (t) { return '<p>' + esc(t) + '</p>'; }).join('')
          : '<p class="note">No text on this slide.</p>') + '</section>';
      }).join('') || '<p class="note">No slides found.</p>';
    });
  }

  // ---- the panel -------------------------------------------------------------------------------------------------
  var CSS = '.qv{position:relative;display:flex;flex-direction:column;min-width:0;min-height:0;background:var(--surface);border:1px solid var(--line);border-radius:20px;overflow:hidden}' +
    '.qv[hidden]{display:none!important}' +
    '.qv.full{position:fixed;inset:8px;z-index:60;border-radius:16px;box-shadow:0 24px 64px rgba(1,11,7,.28)}' +
    '.qv-grip{position:absolute;left:0;top:0;bottom:0;width:8px;cursor:col-resize;z-index:2;touch-action:none}' +
    '.qv-grip:hover,.qv-grip:focus-visible{background:linear-gradient(90deg,var(--focus) 0 2px,transparent 2px)}' +
    '.qv.full .qv-grip{display:none}' +
    '.qv-top{display:flex;align-items:center;gap:6px;padding:10px 12px 10px 16px;border-bottom:1px solid var(--line);flex-wrap:wrap}' +
    '.qv-name{flex:1 1 140px;min-width:0;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border:0;background:transparent;text-align:left;padding:4px 6px;border-radius:8px;color:var(--ink);cursor:text}' +
    '.qv-name:hover{background:var(--hover)}' +
    '.qv-name-in{flex:1 1 140px;min-width:0;font:inherit;padding:4px 6px;border:1px solid var(--focus);border-radius:8px;background:var(--surface);color:var(--ink)}' +
    '.qv-top select{font:inherit;font-size:13px;padding:4px 6px;border-radius:8px;border:1px solid var(--line);background:var(--surface);color:var(--ink);max-width:190px}' +
    '.qv-ib{border:0;background:transparent;width:32px;height:32px;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;color:var(--ink2);cursor:pointer}' +
    '.qv-ib:hover{background:var(--hover);color:var(--ink)}.qv-ib svg{width:18px;height:18px}.qv-ib[disabled]{opacity:.4;cursor:default}' +
    '.qv-seg{display:inline-flex;border:1px solid var(--line);border-radius:999px;padding:2px}' +
    '.qv-seg button{border:0;background:transparent;padding:3px 10px;border-radius:999px;font-size:13px;color:var(--ink2);cursor:pointer}' +
    '.qv-seg button[aria-pressed="true"]{background:var(--btn);color:var(--btnInk)}' +
    '.qv-note{margin:0;padding:8px 16px;font-size:13px;background:var(--band);color:var(--ink2);border-bottom:1px solid var(--line);display:flex;gap:8px;align-items:center;flex-wrap:wrap}' +
    '.qv-note:empty{display:none}.qv-note button{font-size:13px}' +
    '.qv-body{flex:1;min-height:0;overflow:auto;position:relative;background:#fff}' +
    '.qv-body iframe{border:0;width:100%;height:100%;display:block;background:#fff}' +
    '.qv-body img{display:block;max-width:100%;margin:16px auto}' +
    '.qv-msg{padding:24px;color:var(--ink2)}' +
    '.qv-code{margin:0;padding:16px;font:13px/1.55 ui-monospace,Menlo,monospace;white-space:pre;color:#10231A;tab-size:4;counter-reset:l}' +
    '.qv-code .k{color:#7B3FA0}.qv-code .s{color:#0B6E4F}.qv-code .c{color:#7A8A80;font-style:italic}.qv-code .n{color:#B5562B}' +
    '.qv-live{font-size:12px;color:var(--ink2);padding:0 4px}' +
    '.qv-card{display:flex;align-items:center;gap:10px;margin-top:10px;padding:10px 12px;border:1px solid var(--line);border-radius:14px;background:var(--surface);cursor:pointer;text-align:left;width:100%;max-width:420px;font:inherit;color:var(--ink);white-space:normal}' +
    '.qv-card:hover{border-color:var(--ink2);background:var(--hover)}' +
    '.qv-card .ic{flex:none;width:36px;height:36px;border-radius:10px;background:var(--well);color:var(--wellInk);display:flex;align-items:center;justify-content:center}' +
    '.qv-card .ic svg{width:18px;height:18px}.qv-card b{display:block;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
    '.qv-card span.t3{display:block;font-size:12px;color:var(--ink2)}.qv-card .tx{min-width:0;flex:1}' +
    '@media (prefers-reduced-motion:no-preference){.qv{transition:box-shadow 200ms}}';
  var ICONS = {
    copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
    download: '<path d="M12 4v11"/><path d="m7 10 5 5 5-5"/><path d="M5 20h14"/>',
    window: '<path d="M14 4h6v6"/><path d="M20 4 11 13"/><path d="M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/>',
    full: '<path d="M4 9V4h5"/><path d="M20 9V4h-5"/><path d="M4 15v5h5"/><path d="M20 15v5h-5"/>',
    close: '<path d="M6 6l12 12"/><path d="M18 6 6 18"/>',
    file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>'
  };
  function svg(name) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICONS[name] + '</svg>'; }
  function ib(name, label, fn) {
    var b = Q.el('button', {type: 'button', class: 'qv-ib', 'aria-label': label, title: label, onclick: fn});
    b.innerHTML = svg(name);   // constant markup only
    return b;
  }
  var styled = false;
  function style() {
    if (styled) return;
    styled = true;
    document.head.appendChild(Q.el('style', null, CSS));
  }
  function when(at) { return Q.when(at).replace(/ (?=[AP]M\b)/g, ' '); }
  function who(src) { return src === 'before restore' ? 'before a restore' : src === 'restored' ? 'restored' : src === 'before' ? 'before a change' : src === 'qosha' ? 'by Qosha' : 'changed'; }

  // create(host, opts): opts.root (files folder), opts.onClose(), opts.onRename(newPath), opts.onState(open)
  function create(host, opts) {
    style();
    opts = opts || {};
    var allowed = {};   // files whose page scripts / PDF viewer the person turned on in this page (GPT R-files2 HIGH)
    var st = {path: null, name: '', info: null, version: null, view: 'preview', text: null, buf: null, seq: 0,
              timer: null, urls: [], pending: false, sha: null, mtime: null, frame: null};
    var nameBtn = Q.el('button', {type: 'button', class: 'qv-name', title: 'Rename', 'aria-label': 'File name, press to rename'});
    var verSel = Q.el('select', {'aria-label': 'Version'});
    var seg = Q.el('div', {class: 'qv-seg', role: 'group', 'aria-label': 'Show'});
    var prevB = Q.el('button', {type: 'button', 'aria-pressed': 'true', onclick: function () { setView('preview'); }}, 'Preview');
    var codeB = Q.el('button', {type: 'button', 'aria-pressed': 'false', onclick: function () { setView('code'); }}, 'Code');
    seg.appendChild(prevB); seg.appendChild(codeB);
    var live = Q.el('span', {class: 'qv-live', 'aria-live': 'polite'});
    var copyB = ib('copy', 'Copy', copy), dlB = ib('download', 'Download', download), winB = ib('window', 'Open in its own window', ownWindow);
    var fullB = ib('full', 'Full screen', function () { full(!panel.classList.contains('full')); });
    var closeB = ib('close', 'Close', close);
    var note = Q.el('div', {class: 'qv-note', role: 'status'});
    var body = Q.el('div', {class: 'qv-body'});
    var grip = Q.el('div', {class: 'qv-grip', role: 'separator', 'aria-orientation': 'vertical', 'aria-label': 'Resize the file panel', tabindex: '0'});
    var panel = Q.el('section', {class: 'qv', 'aria-label': 'File', hidden: true}, grip,
      Q.el('div', {class: 'qv-top'}, nameBtn, live, verSel, seg, copyB, dlB, winB, fullB, closeB), note, body);
    host.appendChild(panel);
    nameBtn.addEventListener('click', startRename);
    window.addEventListener('message', function (ev) {
      if (!st.frame || ev.source !== st.frame.contentWindow || !ev.data || ev.data.qoshaViewer !== 'kept') return;
      say('This file tried to open another address. Qosha stopped it; nothing was loaded or sent.');
    });
    verSel.addEventListener('change', function () { var v = verSel.value; showVersion(v === 'now' ? null : parseInt(v, 10)); });
    panel.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && panel.classList.contains('full')) { ev.stopPropagation(); full(false); } });

    // resizing: the panel's width (a CSS variable on the host) by dragging its left edge or with the arrow keys
    var W_KEY = 'qosha.viewerWidth';
    function setWidth(px) {
      var max = Math.max(360, window.innerWidth - 360);
      px = Math.max(320, Math.min(max, Math.round(px)));
      host.style.setProperty('--qv-w', px + 'px');
      document.documentElement.style.setProperty('--qv-w', px + 'px');
      try { localStorage.setItem(W_KEY, String(px)); } catch (e) { /* not kept */ }
    }
    try { var saved = parseInt(localStorage.getItem(W_KEY), 10); if (saved > 0) setWidth(saved); } catch (e) { /* default */ }
    grip.addEventListener('pointerdown', function (ev) {
      ev.preventDefault();
      grip.setPointerCapture(ev.pointerId);
      var right = panel.getBoundingClientRect().right;
      body.style.pointerEvents = 'none';   // the frame must not swallow the drag
      function move(e) { setWidth(right - e.clientX); }
      function up() { body.style.pointerEvents = ''; grip.removeEventListener('pointermove', move); grip.removeEventListener('pointerup', up); }
      grip.addEventListener('pointermove', move);
      grip.addEventListener('pointerup', up);
    });
    grip.addEventListener('keydown', function (ev) {
      var w = panel.getBoundingClientRect().width;
      if (ev.key === 'ArrowLeft') { setWidth(w + 40); ev.preventDefault(); }
      if (ev.key === 'ArrowRight') { setWidth(w - 40); ev.preventDefault(); }
    });

    function say(t, actions) {
      Q.clear(note);
      if (t) note.appendChild(document.createTextNode(t));
      (actions || []).forEach(function (a) { note.appendChild(a); });
    }
    function message(t) { clearBody(); body.appendChild(Q.el('p', {class: 'qv-msg'}, t)); }
    function clearBody() {
      st.urls.forEach(function (u) { URL.revokeObjectURL(u); });
      st.urls = [];
      st.frame = null;
      Q.clear(body);
    }
    function full(on) {
      panel.classList.toggle('full', !!on);
      fullB.setAttribute('aria-label', on ? 'Leave full screen' : 'Full screen');
      fullB.title = on ? 'Leave full screen' : 'Full screen';
    }
    function setView(v) {
      st.view = v;
      prevB.setAttribute('aria-pressed', v === 'preview' ? 'true' : 'false');
      codeB.setAttribute('aria-pressed', v === 'code' ? 'true' : 'false');
      draw();
    }
    // a sandboxed frame: scripts only when the kind needs them; never same-origin, never top navigation
    // The file's document runs in an inner frame inside a small wrapper document of Qosha's own. The wrapper's policy
    // (frame-src 'none') is checked before any request when the inner frame tries to navigate (a link, a script, a
    // refresh tag), so the file can't load another address or carry its contents away (GPT R-files1 HIGH 1). The
    // wrapper puts the file back (at most 3 times) and tells the page; both frames are sandboxed without same-origin.
    function frame(doc, scripts, popups, csp) {
      var inner = (scripts ? 'allow-scripts allow-forms' : '') + (popups ? ' allow-popups allow-popups-to-escape-sandbox' : '');
      var f = document.createElement('iframe');
      f.setAttribute('sandbox', 'allow-scripts' + (scripts ? ' allow-forms' : '') + (popups ? ' allow-popups allow-popups-to-escape-sandbox' : ''));
      f.setAttribute('referrerpolicy', 'no-referrer');
      f.setAttribute('title', 'Preview of ' + st.name);
      f.setAttribute('loading', 'eager');
      f.srcdoc = wrapDoc(doc, inner.trim(), csp || CSP);
      clearBody();
      st.frame = f;
      body.appendChild(f);
      return f;
    }
    function blobUrl(type) {
      var u = URL.createObjectURL(new Blob([st.buf], {type: type}));
      st.urls.push(u);
      return u;
    }
    function draw() {
      var k = kindOf(st.name), text = st.text;
      seg.hidden = !HAS_SOURCE[k];
      copyB.disabled = text == null;
      if (st.buf == null) return;
      if (st.view === 'code' && HAS_SOURCE[k] && text != null) { codeView(text); return; }
      try {
        if (k === 'html') {
          // a page's scripts stay off until the person turns them on for this file: off, the page can't reach the
          // internet at all; on, Qosha still blocks its links, requests and forms, but a script could still find a way
          // out (for example a live-call connection), so the person decides
          var run = !!allowed[st.path];
          frame(htmlDoc(text, run), run, false);
          if (!run) say('This page\'s scripts are off, so it can\'t reach the internet. Turning them on makes it interactive: ' +
                        'Qosha still blocks its links, requests and forms, but a page\'s scripts could still find a way to send what ' +
                        'is on the page to the internet. Turn them on only for files you trust. ',
                        [Q.el('button', {type: 'button', class: 'btn sm', onclick: function () { allowed[st.path] = true; say(''); draw(); }}, 'Turn on scripts for this file')]);
        }
        else if (k === 'svg') frame(frameDoc('<div style="display:flex;justify-content:center">' + svgInline(text) + '</div>'), false, false);
        else if (k === 'markdown') {
          var dg = [], h = markdown(text, dg);
          if (dg.length) frame(frameDoc(h, mermaidHead(), CSP_MERMAID), true, true, CSP_MERMAID);
          else frame(frameDoc(h), false, true);
        } else if (k === 'mermaid') frame(frameDoc('<pre class="mermaid">' + esc(text) + '</pre>', mermaidHead(), CSP_MERMAID), true, false, CSP_MERMAID);
        else if (k === 'csv') frame(frameDoc(tableHtml(parseCsv(text, ext(st.name) === 'tsv' ? '\t' : ','), text.length >= TEXT_MAX)), false, false);
        else if (k === 'code' || k === 'text') codeView(text);
        else if (k === 'image') {
          clearBody();
          body.appendChild(Q.el('img', {src: blobUrl(IMAGE_TYPE[ext(st.name)] || 'application/octet-stream'), alt: st.name}));
        } else if (k === 'pdf') {
          var head = new Uint8Array(st.buf.slice(0, 5));
          if (String.fromCharCode.apply(null, head) !== '%PDF-') { message('This file is named .pdf but is not a PDF, so it is not shown. You can download it.'); return; }
          // the browser's own PDF viewer can't be sandboxed and can send a PDF form: shown only when the person asks
          if (!allowed[st.path]) {
            message('PDF previews use your browser\'s PDF viewer, which can send a filled-in PDF form to the internet. Show it only if you trust this file, or download it.');
            body.appendChild(Q.el('p', {class: 'qv-msg'}, Q.el('button', {type: 'button', class: 'btn sm', onclick: function () { allowed[st.path] = true; draw(); }}, 'Show this PDF')));
            return;
          }
          clearBody();
          body.appendChild(Q.el('iframe', {src: blobUrl('application/pdf'), title: 'Preview of ' + st.name}));
        } else if (k === 'xlsx' || k === 'docx' || k === 'pptx') {
          message('Opening…');
          var mine = st.seq;
          var z = unzip(st.buf);
          (k === 'xlsx' ? xlsxHtml(z) : k === 'docx' ? docxHtml(z) : pptxHtml(z)).then(function (h) {
            if (mine !== st.seq) return;
            frame(frameDoc((k === 'docx' || k === 'pptx' ? '<p class="note">A readable preview: layout, pictures and styles may differ from the original.</p>' : '') + h), false, false);
          }, function () { if (mine === st.seq) message('Qosha could not read this file for a preview. You can download it.'); });
        } else if (text != null && !/\u0000/.test(text.slice(0, 4096))) codeView(text);
        else message('There is no preview for this kind of file. You can download it.');
      } catch (e) {
        message('Qosha could not show a preview of this file. You can download it.');
      }
    }
    function svgInline(text) {   // the drawing as its own document part, inside a frame where nothing runs
      var i = text.search(/<svg[\s>]/i);
      return i >= 0 ? text.slice(i) : text;
    }
    function codeView(text) {
      clearBody();
      var pre = Q.el('pre', {class: 'qv-code'});
      pre.innerHTML = highlight(text);   // escaped text with colour spans (highlight() escapes everything it emits)
      body.appendChild(pre);
    }

    // ---- loading and versions ----------------------------------------------------------------------------------
    function fillVersions(vs) {
      Q.clear(verSel);
      vs = Array.isArray(vs) ? vs.slice().reverse() : [];
      verSel.appendChild(Q.el('option', {value: 'now'}, vs.length ? 'Latest' + (vs.length > 1 ? ' (v' + vs[0].n + ')' : '') : 'Latest'));
      vs.slice(st.version == null ? 1 : 0).forEach(function (v) {
        if (typeof v.n !== 'number') return;
        verSel.appendChild(Q.el('option', {value: String(v.n)}, 'v' + v.n + ' · ' + when(v.at) + ' · ' + who(v.source)));
      });
      verSel.value = st.version == null ? 'now' : String(st.version);
      verSel.hidden = vs.length < 2 && st.version == null;
    }
    function readInfo() {
      return Q.api('GET', API + 'info?path=' + encodeURIComponent(st.path));
    }
    function load(keepView) {
      var mine = ++st.seq, path = st.path;
      return readInfo().then(function (inf) {
        if (mine !== st.seq || path !== st.path) return;
        st.info = inf;
        fillVersions(inf.versions);
        if (!inf.viewable) {
          st.buf = null; st.text = null;
          message('This file is too large to preview here (' + Math.round(inf.size / 1048576) + ' MB; the limit is ' + Math.round(inf.limit / 1048576) + ' MB). You can download it.');
          return;
        }
        st.sha = inf.sha256 || null; st.mtime = inf.mtime;
        return bytes(API + 'download?path=' + encodeURIComponent(path)).then(function (buf) {
          if (mine !== st.seq || path !== st.path) return;
          setBytes(buf);
          if (!keepView) st.view = 'preview';
          setView(st.view);
        });
      }).catch(function (err) {
        if (mine !== st.seq) return;
        st.buf = null; st.text = null;
        message(err && err.status === 404 ? 'This file is no longer there.' :
                err && (err.status === 400 || err.status === 403) ? 'Only files in your Qosha files folder can be opened here.' :
                'Qosha could not open this file right now. Try again in a moment.');
      });
    }
    function setBytes(buf) {
      st.buf = buf;
      var k = kindOf(st.name);
      st.text = (k === 'image' || k === 'pdf' || k === 'xlsx' || k === 'docx' || k === 'pptx' || buf.byteLength > TEXT_MAX) ? null : decode(buf);
      if (st.text == null && (k === 'html' || k === 'svg' || k === 'markdown' || k === 'csv' || k === 'code' || k === 'text' || k === 'mermaid') && buf.byteLength > TEXT_MAX) {
        st.buf = null;
        message('This file is too large to preview here (the limit for text is 2 MB). You can download it.');
      }
    }
    function showVersion(n) {
      st.version = n;
      if (n == null) { say(''); load(true); return; }
      var mine = ++st.seq;
      bytes(API + 'version?path=' + encodeURIComponent(st.path) + '&n=' + n).then(function (buf) {
        if (mine !== st.seq) return;
        setBytes(buf);
        draw();
        var restoreB = Q.el('button', {type: 'button', class: 'btn sm', onclick: function () { restore(n); }}, 'Restore this version');
        var backB = Q.el('button', {type: 'button', class: 'btn ghost sm', onclick: function () { verSel.value = 'now'; showVersion(null); }}, 'Back to latest');
        say('You are looking at version ' + n + '. ', [restoreB, backB]);
      }, function () { if (mine === st.seq) message('That version is no longer kept.'); });
    }
    function restore(n) {
      Q.api('POST', API + 'restore', {path: st.path, n: n}).then(function () {
        st.version = null;
        say('Version ' + n + ' restored. It is now the latest version; the one before is still in the list.');
        load(true);
      }, function (err) { say('Qosha could not restore that version' + (err && err.status === 404 ? ': it is no longer kept.' : '. Try again.')); });
    }
    function poll() {
      clearTimeout(st.timer);
      st.timer = setTimeout(function () {
        if (!st.path || panel.hidden) return;
        if (document.hidden || st.version != null || st.pending) { poll(); return; }
        var path = st.path;
        readInfo().then(function (inf) {
          if (path !== st.path) return;
          if ((inf.sha256 && inf.sha256 !== st.sha) || (!inf.sha256 && inf.mtime !== st.mtime)) {
            live.textContent = 'Updated';
            setTimeout(function () { if (live.textContent === 'Updated') live.textContent = ''; }, 2500);
            return load(true);
          }
          fillVersions(inf.versions);
        }).catch(function () { /* the next tick tries again */ }).then(poll);
      }, POLL_MS);
    }

    // ---- actions -----------------------------------------------------------------------------------------------
    function copy() {
      if (st.text == null) return;
      var done = function () { say('Copied.'); setTimeout(function () { if (note.textContent === 'Copied.') say(''); }, 2000); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(st.text).then(done, fallback);
      else fallback();
      function fallback() {
        var ta = Q.el('textarea', {style: 'position:fixed;left:-9999px'});
        ta.value = st.text; document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); done(); } catch (e) { say('Copying is not available here.'); }
        ta.remove();
      }
    }
    function download() {
      if (!st.path) return;
      var url = st.version == null ? API + 'download?path=' + encodeURIComponent(st.path) : API + 'version?path=' + encodeURIComponent(st.path) + '&n=' + st.version;
      bytes(url).then(function (buf) {
        var u = URL.createObjectURL(new Blob([buf], {type: 'application/octet-stream'}));   // saved, never rendered here
        var a = Q.el('a', {href: u, download: st.name, hidden: true});
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(function () { URL.revokeObjectURL(u); }, 30000);
      }, function () { say('Qosha could not download this file right now.'); });
    }
    // its own window: a blank Qosha page holding the same sandboxed frame (or the picture / PDF), never the file as
    // a page of Qosha's own origin
    function ownWindow() {
      if (st.buf == null) return;
      var w = window.open('', '_blank');
      if (!w) { say('The new window was blocked. Allow pop-ups for Qosha, or use Full screen.'); return; }
      try { w.opener = null; } catch (e) { /* fine */ }
      var d = w.document;
      d.open(); d.write('<!doctype html><meta charset="utf-8"><title></title><style>html,body{margin:0;height:100%}iframe{border:0;width:100%;height:100%;display:block}img{max-width:100%;display:block;margin:auto}</style>'); d.close();
      d.title = st.name + ' · Qosha';
      var src = st.frame, k = kindOf(st.name);
      if (src) {
        var f = d.createElement('iframe');
        f.setAttribute('sandbox', src.getAttribute('sandbox'));
        f.setAttribute('referrerpolicy', 'no-referrer');
        f.srcdoc = src.srcdoc;
        d.body.appendChild(f);
      } else if (k === 'image' || (k === 'pdf' && allowed[st.path])) {
        var u = URL.createObjectURL(new Blob([st.buf], {type: k === 'pdf' ? 'application/pdf' : (IMAGE_TYPE[ext(st.name)] || 'application/octet-stream')}));
        var n = d.createElement(k === 'pdf' ? 'iframe' : 'img');
        n.src = u;
        d.body.appendChild(n);
      } else {
        var pre = d.createElement('pre');
        pre.style.cssText = 'margin:0;padding:16px;font:13px/1.55 ui-monospace,Menlo,monospace;white-space:pre-wrap';
        pre.textContent = st.text || '';
        d.body.appendChild(pre);
      }
    }
    function startRename() {
      if (!st.path) return;
      var input = Q.el('input', {class: 'qv-name-in', type: 'text', 'aria-label': 'New file name', maxlength: '255'});
      input.value = st.name;
      nameBtn.replaceWith(input);
      input.focus();
      var dot = st.name.lastIndexOf('.');
      input.setSelectionRange(0, dot > 0 ? dot : st.name.length);
      var done = false;
      function finish(save) {
        if (done) return;
        done = true;
        var v = input.value.trim();
        input.replaceWith(nameBtn);
        if (!save || !v || v === st.name) return;
        if (v === '.' || v === '..' || /[\/\\\x00-\x1f]/.test(v) || v.charAt(0) === '.' || v.length > 255) { say('That name is not allowed: no / or \\, and it can\'t start with a dot.'); return; }
        Q.api('POST', API + 'rename', {path: st.path, name: v}).then(function (r) {
          if (!r || typeof r.path !== 'string') return;
          var old = st.path;
          st.path = r.path; st.name = v;
          nameBtn.textContent = v;
          say('Renamed to ' + v + '.');
          if (opts.onRename) opts.onRename(old, r.path);
          load(true);
        }, function (err) { say(err && err.status === 409 ? 'Something with that name is already here. Pick another name.' : 'Qosha could not rename this file.'); });
      }
      input.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter') { ev.preventDefault(); finish(true); }
        if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); finish(false); nameBtn.focus(); }
      });
      // after this click has finished: the button it replaced held the focus, and its removal must not end the rename
      setTimeout(function () {
        if (done) return;
        input.focus();
        input.setSelectionRange(0, dot > 0 ? dot : st.name.length);
        input.addEventListener('blur', function () { finish(true); });
      }, 0);
    }
    function open(path, o) {
      if (typeof path !== 'string' || !path) return;
      var same = path === st.path;
      st.path = path;
      st.name = path.slice(path.lastIndexOf('/') + 1);
      nameBtn.textContent = st.name;
      panel.setAttribute('aria-label', 'File: ' + st.name);
      if (!same) { st.version = null; st.sha = null; st.view = 'preview'; say(''); message('Opening…'); }
      st.pending = false;
      live.textContent = '';
      panel.hidden = false;
      if (opts.onState) opts.onState(true);
      load(same);
      poll();
      if (!(o && o.quiet)) closeB.focus({preventScroll: true});
    }
    // while the assistant is still writing a new file: its words are shown before they land on disk
    function pending(path, text) {
      if (path !== st.path || typeof text !== 'string' || text.length > TEXT_MAX) return;
      st.pending = true;
      live.textContent = 'Qosha is writing…';
      st.buf = new TextEncoder().encode(text).buffer; st.text = text;
      if (st.version == null) draw();
    }
    function refresh(path) {
      if (path !== st.path) return;
      st.pending = false;
      live.textContent = 'Updated';
      setTimeout(function () { if (live.textContent === 'Updated') live.textContent = ''; }, 2500);
      if (st.version == null) load(true); else readInfo().then(function (inf) { fillVersions(inf.versions); }, function () {});
    }
    function unpend() {
      if (!st.pending || !st.path) return;
      st.pending = false;
      live.textContent = '';
      if (st.version == null) load(true);
    }
    function close() {
      clearTimeout(st.timer);
      full(false);
      panel.hidden = true;
      clearBody();
      st.path = null; st.buf = null; st.text = null; st.seq++;
      if (opts.onState) opts.onState(false);
      if (opts.onClose) opts.onClose();
    }
    return {open: open, close: close, refresh: refresh, pending: pending, unpend: unpend, panel: panel,
            current: function () { return panel.hidden ? null : st.path; }};
  }

  // a card for the conversation: the file's name and what happened; pressing it opens the file beside the chat
  function card(name, detail, onOpen) {
    var b = Q.el('button', {type: 'button', class: 'qv-card', 'aria-label': 'Open ' + name, onclick: onOpen});
    var ic = Q.el('span', {class: 'ic'});
    ic.innerHTML = svg('file');   // constant markup only
    var t3 = Q.el('span', {class: 't3'}, detail);
    b.appendChild(ic);
    b.appendChild(Q.el('span', {class: 'tx'}, Q.el('b', null, name), t3));
    b.setDetail = function (d) { t3.textContent = d; };
    return b;
  }

  window.QoshaViewer = {create: create, card: card, kindOf: kindOf, style: style,
                        _test: {markdown: markdown, htmlDoc: htmlDoc, parseCsv: parseCsv, CSP: CSP}};
})();
