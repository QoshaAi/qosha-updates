/* Qosha pages: keep the dashboard session token current (LABPOLISH, 5 Nov). The dashboard makes a new session token
   every time it starts and writes it into its own page as window.__HERMES_SESSION_TOKEN__; Qosha's pages read it from
   that parent page on every request. A Qosha window left open across a lab restart kept the old token, so every request
   got 401 until the app was reopened. Loaded first in every Qosha page, this wraps the page's fetch: when a request that
   carried the token is refused with 401, it reads the dashboard's page again (same origin, never cached), and if the
   token there is new it puts it back in the parent page (where every Qosha page and the dashboard read it) and sends
   the request once more. The token is never stored, logged, shown or put in a URL. A refused request is retried only
   when the token really changed: the dashboard refused it before any route ran, so nothing happens twice. The same
   check runs when the window becomes visible again or gets focus (at most every 30 s, not in a page's first 30 s), so
   the chat connection, which reads the token when it connects, finds the new one too.
   LABPOLISH2 (checker, 5 Nov): the token goes only to this Qosha's own origin. A request carrying it to another origin
   is refused before it leaves the page; a request carrying it never follows a redirect (redirect "manual": the page
   gets the redirect as a failure, and the token goes nowhere else); and only a 401 this origin answered directly, with
   no redirect, starts a renewal and a retry. */
(function () {
  'use strict';
  if (window.__qoshaSessionRenewal) return;
  var HEADER = 'X-Hermes-Session-Token';
  var VALID = /^[\x21-\x7e]{16,512}$/;
  var IN_PAGE = /window\.__HERMES_SESSION_TOKEN__\s*=\s*"([\x21-\x21\x23-\x5b\x5d-\x7e]{16,512})"/;
  var send = window.fetch.bind(window);
  var renewing = null, lastCheck = Date.now();   // a page just loaded has the token the dashboard serves now

  // the dashboard page that holds the token: the nearest same-origin parent with one (none when opened on its own)
  function holder() {
    try {
      var f = window;
      while (f.parent && f.parent !== f) {
        f = f.parent;
        if (typeof f.__HERMES_SESSION_TOKEN__ === 'string' && VALID.test(f.__HERMES_SESSION_TOKEN__)) return f;
      }
    } catch (e) { /* a parent of another origin: no token here */ }
    return null;
  }
  // a Request, also one made in another frame (instanceof would miss it: GPT LABPOLISH2 r1)
  function isRequest(x) { return !!x && typeof x === 'object' && Object.prototype.toString.call(x) === '[object Request]'; }
  // what fetch would send, read the way fetch reads it, never touching a body: the URL, and the headers (init's when it
  // names any, they replace a Request's own; any form fetch takes: a plain object, pairs, a Map, Headers from any frame,
  // a one-shot iterator). init.headers is read exactly once; `given` says the request must go out with these `headers`
  // (an iterator cannot be read twice: GPT LABPOLISH2 r2). null when fetch itself would refuse them.
  function inspect(input, init) {
    try {
      var req = isRequest(input);
      var named = init ? init.headers : undefined;
      var given = named !== undefined && named !== null;
      var h = new Headers(given ? named : (req ? input.headers : {}));
      return {url: new URL(req ? input.url : String(input), window.location.href), headers: h, token: h.get(HEADER), req: req, given: given};
    } catch (e) { return null; }
  }
  function copy(init) {
    var out = {};
    if (init) for (var j in init) if (Object.prototype.hasOwnProperty.call(init, j)) out[j] = init[j];
    return out;
  }
  // a 401 Qosha's dashboard gave itself: a plain same-origin answer, not one reached through a redirect
  function ownRefusal(r) {
    if (r.status !== 401 || r.type !== 'basic' || r.redirected) return false;
    try { return new URL(r.url).origin === window.location.origin; } catch (e) { return false; }
  }
  // read the dashboard's own page again and adopt its token if it changed; resolves to the current token (or null)
  function renew() {
    if (renewing) return renewing;
    var f = holder();
    if (!f) return Promise.resolve(null);
    var mine = renewing = send('/', {method: 'GET', credentials: 'same-origin', cache: 'no-store', redirect: 'manual'}).then(function (r) {
      var type = (r.headers.get('content-type') || '').toLowerCase();
      var origin = '';
      try { origin = new URL(r.url || '/', window.location.href).origin; } catch (e) { origin = ''; }
      if (!r.ok || r.type !== 'basic' || r.redirected || origin !== window.location.origin || type.indexOf('text/html') !== 0) return null;
      return r.text().then(function (html) {
        var m = IN_PAGE.exec(html.slice(0, 65536));
        if (!m || !VALID.test(m[1])) return null;
        try { if (f.__HERMES_SESSION_TOKEN__ !== m[1]) f.__HERMES_SESSION_TOKEN__ = m[1]; } catch (e) { return null; }
        return m[1];
      });
    }).catch(function () { return null; });
    var done = function () { if (renewing === mine) renewing = null; };
    mine.then(done, done);
    lastCheck = Date.now();
    return mine;
  }
  window.fetch = function (input, init) {
    var seen = inspect(input, init);
    // fetch refuses these headers or this address itself (and the headers may have been read already): refuse the same way
    if (!seen) return Promise.reject(new TypeError('Failed to fetch: this address or these headers are not valid.'));
    var sent = seen.token, u = seen.url;
    var once = copy(init);
    if (seen.given) once.headers = new Headers(seen.headers);   // exactly the headers read above
    if (sent === null) return send(input, init === undefined ? init : once);
    if (u.origin !== window.location.origin) return Promise.reject(new TypeError('The Qosha session goes only to this Qosha.'));
    if (once.redirect !== 'error') once.redirect = 'manual';   // never carry the token along a redirect (a Request's own too)
    var first = send(input, once);
    // a retry resends the same input: only a URL (a Request's body can be read once), only Qosha's API
    if (seen.req || u.pathname.indexOf('/api/') !== 0) return first;
    return first.then(function (r) {
      if (!ownRefusal(r)) return r;
      return renew().then(function (fresh) {
        if (!fresh || fresh === sent) return r;
        var headers = new Headers(seen.headers);
        headers.set(HEADER, fresh);
        var again = copy(once);
        again.headers = headers;
        return send(input, again);
      }, function () { return r; });
    });
  };
  function recheck() {
    if (document.visibilityState === 'hidden' || Date.now() - lastCheck < 30000) return;
    renew();
  }
  document.addEventListener('visibilitychange', recheck);
  window.addEventListener('focus', recheck);
  // focus can come back to the dashboard page itself (its side panel) rather than to this page: listen there too. One
  // listener per dashboard page: the page loaded last replaces the one before it (GPT LABPOLISH r1)
  // (the dashboard page does this itself once Qosha's shell there has it: index.js renewOnFocus; this covers a window
  // opened before that shell was installed)
  (function () {
    var f = holder();
    if (!f) return;
    try { if (f.__qoshaTopRenewal) return; } catch (e) { return; }
    var mine = function () { try { recheck(); } catch (e) { /* a page that is gone */ } };
    try {
      if (typeof f.__qoshaRenewOnFocus === 'function') f.removeEventListener('focus', f.__qoshaRenewOnFocus);
      f.addEventListener('focus', mine);
      f.__qoshaRenewOnFocus = mine;
    } catch (e) { /* no readable dashboard page */ }
  })();
  window.__qoshaSessionRenewal = {renew: renew};
})();
