/* Qosha's right-click menu (19 Nov 2026; Renato: "right-click does nothing anywhere in Qosha").
   The Qosha app is a plain window onto this computer's Qosha and shows no menu of its own on right-click; a normal
   browser has its own, so there this file does nothing. Loaded once by the dashboard (index.js) into the top page, it
   watches the top page and every Qosha page inside it (same-address frames at any depth, also ones that come later or
   change page) and draws one small menu in the top page: Cut, Copy, Paste, Select all, plus Copy link on a link and
   Copy image on an image. A page's own right-click menu wins.
   Round 2 (GPT review r11913c rclick #1-#5): the menu never takes the focus. The field or page that had it keeps it
   (a rename being typed stays open, the caret stays where it was), and while the menu is open its keys (Up/Down,
   Home/End, Enter/Space, Escape) are handled first, at the window, and go nowhere else: Escape closes only the menu,
   never a dialog under it. Any other key closes the menu and goes on to the field. Paste checks that the field is
   still the same and unchanged when the clipboard answers, else pastes nothing; a picture on the clipboard is handed
   to the page's own paste handling (Chat attaches it). Where the window does not let the clipboard be read, Paste
   says which keys paste. Nothing is stored or sent anywhere.
   Round 3 (GPT review rclick2 #1-#4): a field inside a page component (Home's message box, in a shadow root) is found
   through the event's composed path; a waiting Paste is dropped when the field loses focus or the page moves to
   another conversation; after Enter or Space chooses an item, that key is held back until it is released (a held key
   never reaches the field); Copy image puts only the picture itself on the clipboard, and where the window refuses
   that it says so and leaves the clipboard as it was.
   Round 4 (GPT review rclick3 #1-#4): the held key is followed by its physical key until its own release, whatever
   other key is pressed meanwhile; Copy image only from a picture that has finished loading; Cut and Paste do nothing
   if the field changed while the menu was open (dictation, say), and say so. A picture handed to Chat that it is still
   reading when the conversation changes is dropped there (chat.html addFiles). */
(function () {
  'use strict';
  var TOP = window;
  if (TOP.__qoshaRclick) return;
  TOP.__qoshaRclick = true;
  // only in the app: a browser keeps its own menu (spelling, translate, inspect...)
  if (!/\bElectron\/\d/.test(TOP.navigator.userAgent || '')) return;
  var MAC = /Mac/.test(TOP.navigator.platform || '') || /Mac OS X/.test(TOP.navigator.userAgent || '');
  var KEY = MAC ? '⌘' : 'Ctrl+';
  var PASTE_KEYS = MAC ? '⌘V' : 'Ctrl+V';
  // a window that offers its own edit commands (the engine's desktop preload) is used for them; the Qosha app has none
  var bridge = null;
  try { if (TOP.hermesDesktop && typeof TOP.hermesDesktop.contextMenuEdit === 'function') bridge = TOP.hermesDesktop; } catch (e) { bridge = null; }

  var D = TOP.document, menu = null, hint = null, hintTimer = 0, ctx = null, list = [], active = -1, say = null, watched = [];
  var held = null;   // the key that chose an item ({code, key}), held back until its own release
  var CSS = '' +
    '.qrc-menu{position:fixed;z-index:2147483646;min-width:196px;max-width:300px;padding:6px;margin:0;box-sizing:border-box;' +
    'background:#FFFFFF;color:#0B0B0B;border:1px solid #E2E1DB;border-radius:14px;' +
    'box-shadow:0 1px 2px rgba(11,11,11,.06),0 12px 32px rgba(11,11,11,.12);' +
    'font:400 14px/1.3 "Google Sans Flex","Google Sans","Helvetica Neue",Arial,sans-serif;font-stretch:95%;' +
    '-webkit-user-select:none;user-select:none;outline:none}' +
    '.qrc-menu button{display:flex;align-items:center;justify-content:space-between;gap:24px;width:100%;min-height:32px;' +
    'padding:6px 10px;margin:0;border:0;border-radius:9px;background:transparent;color:inherit;font:inherit;text-align:left;' +
    'cursor:default;outline:none}' +
    '.qrc-menu button:hover:not([aria-disabled="true"]),.qrc-menu button.qrc-on{background:#F5F4F0}' +
    '.qrc-menu button.qrc-on{box-shadow:inset 0 0 0 2px #0B3326}' +
    '.qrc-menu button[aria-disabled="true"]{color:#8A8984}' +
    '.qrc-menu .qrc-k{color:#5E5D59;font-size:12px;letter-spacing:.02em}' +
    '.qrc-menu button[aria-disabled="true"] .qrc-k{color:#A9A8A3}' +
    '.qrc-menu hr{height:1px;margin:5px 4px;border:0;background:#E2E1DB}' +
    '.qrc-say{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);border:0;white-space:nowrap}' +
    '.qrc-hint{position:fixed;z-index:2147483646;max-width:320px;padding:9px 14px;border-radius:12px;background:#0B3326;color:#FFFFFF;' +
    'font:400 13px/1.35 "Google Sans Flex","Google Sans","Helvetica Neue",Arial,sans-serif;box-shadow:0 10px 28px rgba(11,11,11,.18)}' +
    ':root.qosha-dark .qrc-menu{background:#0F3024;color:#F3F8F5;border-color:#315745;box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 12px 32px rgba(1,11,7,.45)}' +
    ':root.qosha-dark .qrc-menu button:hover:not([aria-disabled="true"]),:root.qosha-dark .qrc-menu button.qrc-on{background:#153E30}' +
    ':root.qosha-dark .qrc-menu button.qrc-on{box-shadow:inset 0 0 0 2px #E2C893}' +
    ':root.qosha-dark .qrc-menu button[aria-disabled="true"]{color:#7F9A8C}' +
    ':root.qosha-dark .qrc-menu .qrc-k{color:#ACC5B7}' +
    ':root.qosha-dark .qrc-menu hr{background:#315745}' +
    ':root.qosha-dark .qrc-hint{background:#E3EEE7;color:#0B3326}' +
    '@media (prefers-reduced-motion:no-preference){.qrc-menu button{transition:background-color 120ms cubic-bezier(.2,0,0,1)}}';

  function style() {
    if (D.getElementById('qosha-rclick-style')) return;
    var s = D.createElement('style');
    s.id = 'qosha-rclick-style';
    s.textContent = CSS;
    (D.head || D.documentElement).appendChild(s);
  }

  // ---- what was right-clicked -------------------------------------------------------------------------------------
  // the parent, also out of a shadow root to its host (Home's message box lives in one)
  function up(n) {
    var p = n && n.parentNode;
    return p && p.nodeType === 11 && p.host ? p.host : p;
  }
  function closestEl(node, test) {
    for (var n = node; n && n.nodeType === 1; n = up(n)) if (test(n)) return n;
    return null;
  }
  // the element that really has the focus, inside shadow roots too
  function deepActive(doc) {
    var a = doc.activeElement;
    while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement;
    return a;
  }
  var TEXT_INPUT = /^(text|search|url|tel|email|password|number|)$/;
  function editableOf(node) {
    return closestEl(node, function (n) {
      var tag = n.tagName;
      if (tag === 'TEXTAREA') return !n.disabled;
      if (tag === 'INPUT') return !n.disabled && TEXT_INPUT.test((n.getAttribute('type') || '').toLowerCase());
      return n.isContentEditable === true;
    });
  }
  function rootEditable(el) {
    if (!el || !el.isContentEditable) return el;
    var r = el;
    while (up(r) && up(r).nodeType === 1 && up(r).isContentEditable) r = up(r);
    return r;
  }
  function isField(el) { return !!el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT'); }
  function readOnly(el) { return isField(el) ? !!el.readOnly : false; }
  function hasSelection(c) {
    if (isField(c.edit)) return !!c.field && c.field[0] !== c.field[1] && c.edit.type !== 'password';
    return !!(c.sel && c.sel.length);
  }

  function snapshot(doc, win, target) {
    var edit = rootEditable(editableOf(target));
    var link = closestEl(target, function (n) { return n.tagName === 'A' && n.hasAttribute('href'); });
    var img = closestEl(target, function (n) { return n.tagName === 'IMG'; });
    var c = {doc: doc, win: win, target: target, edit: edit, link: null, img: null, sel: '', ranges: [], field: null};
    if (link) {
      try {
        var u = new win.URL(link.getAttribute('href'), doc.baseURI);
        if (/^(https?|mailto):$/.test(u.protocol)) c.link = u.href;
      } catch (e) { c.link = null; }
    }
    if (img && (img.currentSrc || img.src)) c.img = img;
    if (isField(edit)) {
      try { c.field = [edit.selectionStart, edit.selectionEnd, edit.selectionDirection]; } catch (e) { c.field = null; }
    }
    try {
      var s = win.getSelection();
      c.sel = s ? String(s) : '';
      for (var i = 0; s && i < s.rangeCount; i++) c.ranges.push(s.getRangeAt(i).cloneRange());
    } catch (e) { c.sel = ''; }
    c.state = editState(c);   // the field as the menu found it: Cut and Paste act only if it is still so
    return c;
  }

  // put focus and the selection back where they were when the menu opened (a click on the menu may have moved them)
  function restore(c) {
    try {
      if (c.edit) { if (deepActive(c.doc) !== c.edit) c.edit.focus({preventScroll: true}); }
      else if (c.win.focus) c.win.focus();
      if (isField(c.edit) && c.field) c.edit.setSelectionRange(c.field[0], c.field[1], c.field[2] || 'none');
      else if (c.ranges.length) {
        var s = c.win.getSelection();
        s.removeAllRanges();
        c.ranges.forEach(function (r) { s.addRange(r); });
      }
    } catch (e) { /* the page changed under the menu: act on what is there now */ }
  }

  // ---- the actions ------------------------------------------------------------------------------------------------
  function exec(c, cmd) {
    if (bridge) { try { bridge.contextMenuEdit(cmd); return true; } catch (e) { /* the page's own below */ } }
    try { return c.doc.execCommand(cmd); } catch (e) { return false; }
  }
  // put a given text (and, for an image, HTML) on the clipboard through the page's own copy command
  function copyData(c, text, html) {
    var done = false;
    function onCopy(e) {
      e.stopImmediatePropagation();
      e.preventDefault();
      if (e.clipboardData) {
        e.clipboardData.setData('text/plain', text || '');
        if (html) e.clipboardData.setData('text/html', html);
        done = true;
      }
    }
    c.win.addEventListener('copy', onCopy, true);
    try { c.doc.execCommand('copy'); } catch (e) { done = false; }
    c.win.removeEventListener('copy', onCopy, true);
    if (!done && text) {
      try { c.win.navigator.clipboard.writeText(text).then(null, function () {}); done = true; } catch (e) { done = false; }
    }
    return done;
  }
  function doCopy(c) {
    if (changedSince(c, 'copied')) return;   // the same check as Cut: never other words than the ones chosen (GPT review rclick4 #3)
    restore(c);
    if (!exec(c, 'copy')) {
      var t = isField(c.edit) && c.field ? c.edit.value.slice(c.field[0], c.field[1]) : c.sel;
      if (t) copyData(c, t);
    }
  }
  // the field changed while the menu was open (dictation, a script): the remembered selection no longer means the
  // same words, so Copy, Cut and Paste do nothing and say so (GPT review rclick3 #4, rclick4 #3)
  function changedSince(c, what) {
    if (!c.edit || editState(c) === c.state) return false;
    pasteHint(c, 'The text changed while the menu was open, so nothing was ' + what + '.');
    return true;
  }
  function doCut(c) {
    if (changedSince(c, 'cut')) return;
    restore(c);
    exec(c, 'cut');
  }
  // the field as it is now: the same element, still on the page, with the same text and selection
  function editState(c) {
    var el = c.edit;
    if (!el || !el.isConnected) return null;
    if (isField(el)) return [el.value, el.selectionStart, el.selectionEnd].join('\u0000');
    var s = '';
    try {
      var sel = c.win.getSelection(), r = sel && sel.rangeCount ? sel.getRangeAt(0) : null;
      s = r && el.contains(r.startContainer) ? [r.startOffset, r.endOffset, r.startContainer === r.endContainer].join(',') : 'none';
    } catch (e) { s = '?'; }
    return el.innerHTML + '\u0000' + s;
  }
  function insertNow(c, text) {
    var ok = false;
    try { ok = c.doc.execCommand('insertText', false, text); } catch (e) { ok = false; }
    if (!ok && isField(c.edit)) {
      var el = c.edit;
      el.setRangeText(text, el.selectionStart, el.selectionEnd, 'end');
      el.dispatchEvent(new c.win.InputEvent('input', {bubbles: true, inputType: 'insertFromPaste', data: text}));
    }
  }
  // what the clipboard holds: {text, files}; pictures as files, where the window lets the clipboard be read
  function readClipboard(c) {
    var clip = c.win.navigator.clipboard;
    if (!clip) return Promise.reject(new Error('no clipboard'));
    if (typeof clip.read !== 'function') return clip.readText().then(function (t) { return {text: t || '', files: []}; });
    return clip.read().then(function (items) {
      var text = '', files = [], waits = [];
      Array.prototype.forEach.call(items || [], function (it) {
        (it.types || []).forEach(function (type) {
          if (/^image\//.test(type)) {
            waits.push(it.getType(type).then(function (b) {
              files.push(new c.win.File([b], 'pasted image.' + (type.split('/')[1] || 'png').replace(/[^a-z0-9]/gi, ''), {type: type}));
            }));
          } else if (type === 'text/plain' && !text) {
            waits.push(it.getType(type).then(function (b) { return b.text(); }).then(function (t) { text = text || t; }));
          }
        });
      });
      return Promise.all(waits).then(function () { return {text: text, files: files}; });
    });
  }
  function doPaste(c) {
    if (changedSince(c, 'pasted')) return;
    restore(c);
    if (bridge) { exec(c, 'paste'); return; }
    var ok = false;
    try { ok = c.doc.execCommand('paste'); } catch (e) { ok = false; }
    if (ok) return;
    var before = editState(c), where = c.win.location.href, left = false;
    var onLeave = function () { left = true; };
    if (c.edit) c.edit.addEventListener('blur', onLeave);     // New chat, another conversation, a click elsewhere
    var p;
    try { p = readClipboard(c); } catch (e) { p = Promise.reject(e); }
    var done = function () { if (c.edit) c.edit.removeEventListener('blur', onLeave); };
    p.then(function (got) {
      done();
      // the person may have typed, moved the caret, left the field or gone to another conversation while the clipboard
      // was read: paste nothing then
      var moved = left || c.win.location.href !== where;
      if (before === null || moved || editState(c) !== before || deepActive(c.doc) !== c.edit) {
        pasteHint(c, 'The text changed before the clipboard could be read, so nothing was pasted. To paste, press ' + PASTE_KEYS + '.');
        return;
      }
      if (got.files.length) {
        // pictures go through the page's own paste handling (Chat attaches them), as a keyboard paste would
        var dt = new c.win.DataTransfer();
        got.files.forEach(function (f) { dt.items.add(f); });
        if (got.text) dt.setData('text/plain', got.text);
        var ev;
        try { ev = new c.win.ClipboardEvent('paste', {clipboardData: dt, bubbles: true, cancelable: true}); } catch (e) { ev = null; }
        if (ev && !c.edit.dispatchEvent(ev)) return;          // the page took it
        if (!got.text) { pasteHint(c); return; }               // a picture this field cannot take: the keys say how
      }
      if (got.text) insertNow(c, got.text);
      else pasteHint(c);
    }, function () { done(); pasteHint(c); });
  }
  function doSelectAll(c) {
    restore(c);
    if (isField(c.edit)) { c.edit.select(); return; }
    if (c.edit) {
      var r = c.doc.createRange();
      r.selectNodeContents(c.edit);
      var s = c.win.getSelection();
      s.removeAllRanges();
      s.addRange(r);
      return;
    }
    exec(c, 'selectAll');
  }
  function doCopyLink(c) {
    restore(c);
    copyData(c, c.link);
  }
  function doCopyImage(c) {
    var img = c.img;
    restore(c);
    if (bridge && typeof bridge.contextMenuCopyImage === 'function') { try { bridge.contextMenuCopyImage(); return; } catch (e) { /* below */ } }
    // only the picture itself: never its name or address as text (pasted into Chat, that would be a file name, not
    // the picture). Where the window cannot put a picture on the clipboard, say so and leave the clipboard as it was.
    // a picture still loading (or broken) has nothing to copy yet: a blank one would replace what the clipboard has
    if (!img || !img.complete || !img.naturalWidth || !img.naturalHeight) { pasteHint(c, NO_IMAGE); return; }
    var cv = null;
    try {
      cv = c.doc.createElement('canvas');
      cv.width = img.naturalWidth; cv.height = img.naturalHeight;
      var g = cv.getContext('2d');
      g.drawImage(img, 0, 0);
      g.getImageData(0, 0, 1, 1);          // a picture from another site cannot be read
    } catch (e) { cv = null; }
    var clip = c.win.navigator.clipboard;
    if (!cv || !cv.width || !clip || typeof clip.write !== 'function' || !c.win.ClipboardItem) { pasteHint(c, NO_IMAGE); return; }
    var item;
    try {
      item = new c.win.ClipboardItem({'image/png': new Promise(function (ok, no) {
        cv.toBlob(function (b) { if (b) ok(b); else no(new Error('no picture')); }, 'image/png');
      })});
    } catch (e) { pasteHint(c, NO_IMAGE); return; }
    try { clip.write([item]).then(null, function () { pasteHint(c, NO_IMAGE); }); } catch (e) { pasteHint(c, NO_IMAGE); }
  }
  var NO_IMAGE = 'Copy image isn\u2019t available here.';

  function pasteHint(c, text) {
    hideHint();
    hint = D.createElement('div');
    hint.className = 'qrc-hint';
    hint.id = 'qosha-rclick-hint';
    hint.setAttribute('role', 'status');
    hint.textContent = text || 'To paste here, press ' + PASTE_KEYS + '.';
    style();
    D.body.appendChild(hint);
    var p = c.at || {x: 24, y: 24};
    var w = hint.offsetWidth, h = hint.offsetHeight, vw = TOP.innerWidth, vh = TOP.innerHeight;
    hint.style.left = Math.max(8, Math.min(p.x, vw - w - 8)) + 'px';
    hint.style.top = Math.max(8, Math.min(p.y + 8, vh - h - 8)) + 'px';
    hintTimer = TOP.setTimeout(hideHint, 6000);
  }
  function hideHint() {
    TOP.clearTimeout(hintTimer);
    if (hint && hint.parentNode) hint.parentNode.removeChild(hint);
    hint = null;
  }

  // ---- the menu ---------------------------------------------------------------------------------------------------
  function items(c) {
    var out = [], sel = hasSelection(c), editable = !!c.edit && !readOnly(c.edit);
    if (c.link) out.push({label: 'Copy link', run: doCopyLink}, '-');
    if (c.img) out.push({label: 'Copy image', run: doCopyImage}, '-');
    if (editable) out.push({label: 'Cut', key: KEY + 'X', off: !sel, run: doCut});
    out.push({label: 'Copy', key: KEY + 'C', off: !sel, run: doCopy});
    if (editable) out.push({label: 'Paste', key: KEY + 'V', run: doPaste});
    out.push('-', {label: 'Select all', key: KEY + 'A', run: doSelectAll});
    return out;
  }

  // the highlighted item: shown, and read out (focus stays where the person was)
  function mark(i) {
    if (!menu) return;
    var on = list.filter(function (x) { return !x.it.off; });
    if (!on.length) return;
    var k = on.indexOf(list[active]);
    k = i === 'first' ? 0 : i === 'last' ? on.length - 1 : (k + i + on.length) % on.length;
    list.forEach(function (x) { x.b.classList.remove('qrc-on'); x.b.removeAttribute('aria-current'); });
    active = list.indexOf(on[k]);
    on[k].b.classList.add('qrc-on');
    on[k].b.setAttribute('aria-current', 'true');
    if (say) say.textContent = on[k].it.label + (on[k].it.key ? ', ' + on[k].it.key : '') + ' (' + (k + 1) + ' of ' + on.length + ')';
  }
  function choose(x) {
    if (!x || x.it.off) return;
    var cc = ctx;
    close();
    if (cc) x.it.run(cc);
  }

  function close() {
    if (!menu) return;
    if (menu.parentNode) menu.parentNode.removeChild(menu);
    menu = null; ctx = null; list = []; active = -1; say = null;
  }

  function open(c, x, y) {
    close();
    hideHint();
    style();
    ctx = c;
    c.at = {x: x, y: y};
    menu = D.createElement('div');
    menu.className = 'qrc-menu';
    menu.id = 'qosha-rclick';   // the dashboard leaves this one usable while a Qosha page covers its own (index.js)
    menu.setAttribute('role', 'menu');
    menu.setAttribute('aria-label', 'Edit');
    items(c).forEach(function (it) {
      if (it === '-') {
        if (menu.lastChild && menu.lastChild.tagName !== 'HR') menu.appendChild(D.createElement('hr'));
        return;
      }
      var b = D.createElement('button');
      b.type = 'button';
      b.setAttribute('role', 'menuitem');
      b.tabIndex = -1;
      var l = D.createElement('span');
      l.textContent = it.label;
      b.appendChild(l);
      if (it.key) {
        var k = D.createElement('span');
        k.className = 'qrc-k';
        k.setAttribute('aria-hidden', 'true');
        k.textContent = it.key;
        b.appendChild(k);
        b.setAttribute('aria-keyshortcuts', (MAC ? 'Meta+' : 'Control+') + it.key.slice(-1));
      }
      if (it.off) b.setAttribute('aria-disabled', 'true');
      var entry = {it: it, b: b};
      list.push(entry);
      b.addEventListener('click', function (e) { e.preventDefault(); choose(entry); });
      menu.appendChild(b);
    });
    if (menu.lastChild && menu.lastChild.tagName === 'HR') menu.removeChild(menu.lastChild);
    say = D.createElement('div');
    say.className = 'qrc-say';
    say.setAttribute('role', 'status');
    say.setAttribute('aria-live', 'polite');
    menu.appendChild(say);
    menu.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    // a press on the menu never takes the focus from the field or page (a rename being typed stays open)
    menu.addEventListener('mousedown', function (e) { e.preventDefault(); });
    menu.addEventListener('pointerdown', function (e) { e.preventDefault(); });
    D.body.appendChild(menu);
    // inside the window, never cut off at the right or bottom edge
    var w = menu.offsetWidth, h = menu.offsetHeight, vw = TOP.innerWidth, vh = TOP.innerHeight;
    var left = x + w + 4 > vw ? Math.max(4, x - w) : x;
    var top = y + h + 4 > vh ? Math.max(4, vh - h - 4) : y;
    menu.style.left = Math.round(left) + 'px';
    menu.style.top = Math.round(top) + 'px';
    mark('first');
    if (say) say.textContent = 'Edit menu. ' + say.textContent + '. Arrow keys to move, Enter to choose, Escape to close.';
  }

  // the click point in the top page's coordinates: add each frame's place on its parent page
  function topPoint(win, x, y) {
    try {
      for (var w = win; w !== TOP; w = w.parent) {
        var fe = w.frameElement;
        if (!fe) return null;
        var r = fe.getBoundingClientRect();
        x += r.left + fe.clientLeft; y += r.top + fe.clientTop;
      }
    } catch (e) { return null; }
    return {x: x, y: y};
  }

  function onContext(doc, e) {
    var win = doc.defaultView;
    if (e.defaultPrevented) { close(); return; }            // the page drew its own menu
    if (menu && menu.contains(e.target)) return;
    // the innermost element, also inside a page component's shadow root (Home's message box)
    var path = typeof e.composedPath === 'function' ? e.composedPath() : [];
    var t0 = path.length ? path[0] : e.target;
    var t = t0 && t0.nodeType === 1 ? t0 : t0 && up(t0);
    if (!t || !win || t.nodeType !== 1) return;
    var x = e.clientX, y = e.clientY;
    if (!(x > 0 || y > 0)) {                                // from the keyboard (menu key, Shift+F10): at the element
      var r = t.getBoundingClientRect();
      x = r.left + Math.min(24, r.width / 2); y = r.top + Math.min(20, r.height);
    }
    var p = topPoint(win, x, y);
    if (!p) return;
    e.preventDefault();
    open(snapshot(doc, win, t), p.x, p.y);
  }
  function onDown(e) {
    if (hint) hideHint();
    if (!menu || menu.contains(e.target)) return;
    if (e.button === 2) return;                              // a new right-click moves the menu (onContext)
    close();
  }
  // the person scrolling closes it (the page scrolling itself, an answer coming in, does not); focus never moved
  function onWheel(e) {
    if (menu && !(e.target && e.target.nodeType === 1 && menu.contains(e.target))) close();
  }
  // while the menu is open its keys are handled here first and go nowhere else (GPT r11913c rclick #2): this runs at
  // the window, in the capture phase, before any page or dialog handler
  var MOD = /^(Shift|Control|Alt|Meta|CapsLock|Fn|OS)$/;
  // the key that chose an item: the same physical key (its code), else the same key value where there is no code
  function isHeld(e) {
    if (!held) return false;
    if (held.code && e.code) return e.code === held.code;
    return e.key === held.key || (held.key === ' ' && e.key === 'Spacebar');
  }
  function onKey(e) {
    // while the chosen key is down its repeats go nowhere; other keys (Control, Shift...) leave the hold as it is
    // (GPT review rclick3 #2). A fresh press of it (not a repeat) means its release was missed: it acts as usual.
    if (isHeld(e)) {
      if (e.repeat) {
        e.preventDefault();
        e.stopImmediatePropagation();
        return;
      }
      held = null;
    }
    if (hint && !MOD.test(e.key)) hideHint();
    if (!menu || MOD.test(e.key)) return;
    var k = e.key;
    if (k === 'ArrowDown') mark(1);
    else if (k === 'ArrowUp') mark(-1);
    else if (k === 'Home') mark('first');
    else if (k === 'End') mark('last');
    else if (k === 'Enter' || k === ' ' || k === 'Spacebar') { held = {code: e.code || '', key: k === 'Spacebar' ? ' ' : k}; choose(list[active]); }
    else if (k === 'Escape' || k === 'Esc') close();
    else { close(); return; }                                // any other key (Tab, a letter, a shortcut) goes on as usual
    e.preventDefault();
    e.stopImmediatePropagation();
  }

  // the chosen key's release (and its keypress) end the hold; they go nowhere either
  function onKeyRest(e) {
    if (!isHeld(e)) return;
    if (e.type === 'keyup') held = null;
    e.preventDefault();
    e.stopImmediatePropagation();
  }

  // ---- watch the top page and every Qosha page inside it ----------------------------------------------------------
  function watchDoc(doc) {
    if (!doc || watched.indexOf(doc) >= 0) return;
    var win = doc.defaultView;
    if (!win) return;
    watched.push(doc);
    if (watched.length > 200) watched = watched.slice(-100);
    // bubbling, on the window: runs after the page's own handlers, so a menu the page draws itself wins
    win.addEventListener('contextmenu', function (e) { onContext(doc, e); });
    win.addEventListener('keydown', onKey, true);
    win.addEventListener('keypress', onKeyRest, true);
    win.addEventListener('keyup', onKeyRest, true);
    doc.addEventListener('mousedown', onDown, true);
    doc.addEventListener('wheel', onWheel, {capture: true, passive: true});
    doc.addEventListener('touchmove', onWheel, {capture: true, passive: true});
    win.addEventListener('resize', function () { close(); });
    frames(doc);
    try {
      new win.MutationObserver(function (recs) {
        for (var i = 0; i < recs.length; i++) {
          var added = recs[i].addedNodes;
          for (var j = 0; j < added.length; j++) {
            var n = added[j];
            if (n.nodeType !== 1) continue;
            if (n.tagName === 'IFRAME') frame(n);
            else frames(n);
          }
        }
      }).observe(doc.documentElement, {childList: true, subtree: true});
    } catch (e) { /* frames that load later still come through their load event */ }
  }
  function frames(root) {
    var fl = root.getElementsByTagName ? root.getElementsByTagName('iframe') : [];
    for (var i = 0; i < fl.length; i++) frame(fl[i]);
  }
  function frame(f) {
    if (!f.__qoshaRclick) {
      f.__qoshaRclick = true;
      f.addEventListener('load', function () { tryFrame(f); });   // every page the frame shows
    }
    tryFrame(f);
  }
  function tryFrame(f) {
    var doc = null;
    try { doc = f.contentDocument; } catch (e) { doc = null; }     // another site, or a sealed file preview: its own
    if (!doc || !doc.documentElement) return;
    try { if (doc.defaultView.location.origin !== TOP.location.origin) return; } catch (e) { return; }
    watchDoc(doc);
  }

  // the window losing focus (another app) closes the menu; focus moving between Qosha's own frames does not
  TOP.addEventListener('blur', function () { TOP.setTimeout(function () { if (!D.hasFocus()) { close(); held = null; } }, 0); });
  function begin() { watchDoc(D); }
  if (D.body) begin(); else D.addEventListener('DOMContentLoaded', begin);
})();
