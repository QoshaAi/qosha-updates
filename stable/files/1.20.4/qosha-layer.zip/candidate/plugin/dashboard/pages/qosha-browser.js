/* Qosha's browser, as the person sees and steers it from Qosha's own pages (MYCHROME).

   Everything here talks to the connector's approval port (/v1/browser-ui): the person-only channel. The assistant has no
   way to call it. What comes back about a web page (an address, a button's words, a picture) is shown as plain text or
   as an <img>, never as HTML.

     QoshaBrowser.url(v)                 the address of the channel, or '' when v is not Qosha's own
     QoshaBrowser.ask(url, body)         one call: {do: 'state' | 'show' | 'hide' | 'resume' | 'stop' | 'done' | ...}
                                         Resume is {do: 'resume', seen: <the epoch of the state the person saw>}; a
                                         refusal throws an Error whose .code is the answer's error ('paused_again' ...)
     QoshaBrowser.ctl(state)             'idle' | 'working' | 'paused' | 'stopped': what the person's controls left it in
     QoshaBrowser.front(state)           true when Qosha's tab is in front, where the person can watch
     QoshaBrowser.picture(url, id, alt, note)  a picture with its note, shown when it arrives (nothing when it can't)
     QoshaBrowser.line(state)            one plain sentence: what Qosha's browser is doing now

   The state ({do: 'state'}) is the app's mirror of the one control state kept by Qosha's extension:
     epoch    goes up with every control (Pause, Take over, the person's click in Qosha's tab, Stop, Resume, Done ...)
     mode     'idle' | 'working' | 'paused' | 'stopped'
     taken    the person took over Qosha's tab and has not pressed Resume since (a Stop on top keeps it)
     busy     an approved step is running
     paused, stopped, working   the same, as flags (stopped is also true from the moment Stop is pressed in the app)
     QoshaBrowser.steps(url, actions)    the list of steps, each with its time, what was done, where, and its picture
*/
(function () {
  'use strict';
  var B = window.QoshaBrowser = {};
  var SHOT = ['data:image/jpeg;base64,', 'data:image/svg+xml;charset=utf-8,'];
  var shots = {};

  function el(tag, attrs) {
    var n = document.createElement(tag), k, i, c;
    for (k in (attrs || {})) {
      if (!Object.prototype.hasOwnProperty.call(attrs, k)) continue;
      if (k === 'class') n.className = attrs[k];
      else if (k === 'text') n.textContent = attrs[k];
      else if (attrs[k] === true) n.setAttribute(k, '');
      else if (attrs[k] !== false && attrs[k] != null) n.setAttribute(k, String(attrs[k]));
    }
    for (i = 2; i < arguments.length; i++) {
      c = arguments[i];
      if (c == null) continue;
      n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return n;
  }

  // only the connector on this computer, and only its browser channel
  B.url = function (v) {
    return typeof v === 'string' && /^http:\/\/(127\.0\.0\.1|localhost):\d{1,5}\/v1\/browser-ui$/.test(v) ? v : '';
  };

  B.ask = function (url, body) {
    if (!B.url(url)) return Promise.reject(new Error('Qosha\u2019s browser isn\u2019t set up on this computer.'));
    return fetch(url, {method: 'POST', mode: 'cors', credentials: 'omit', cache: 'no-store',
                       headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body || {})})
      .then(function (r) {
        return r.text().then(function (t) {
          var j = {};
          try { j = t ? JSON.parse(t) : {}; } catch (e) { j = {}; }
          if (!r.ok) {
            var err = new Error(String(j.plain || j.detail || 'Qosha\u2019s browser didn\u2019t answer. Try again.'));
            err.code = String(j.error || '');
            throw err;
          }
          return j;
        });
      }, function () { throw new Error('Qosha\u2019s browser didn\u2019t answer. Try again.'); });
  };

  // a picture is only ever a JPEG or a drawn copy made by Qosha's own extension; anything else is not shown
  B.shot = function (url, id) {
    id = String(id || '');
    if (!/^[0-9a-f]{8,64}$/.test(id)) return Promise.resolve('');
    if (!shots[id]) {
      shots[id] = B.ask(url, {do: 'shot', id: id}).then(function (r) {
        var s = r && typeof r.shot === 'string' ? r.shot : '';
        return SHOT.some(function (p) { return s.indexOf(p) === 0; }) ? s : '';
      }, function () { delete shots[id]; return ''; });
    }
    return shots[id];
  };

  B.picture = function (url, id, alt, note) {
    var img = el('img', {class: 'bxshot', alt: alt || 'Picture of the page', decoding: 'async'});
    var fig = el('div', {class: 'bxfig', hidden: true}, img, note ? el('p', {class: 'bxurl'}, note) : null);
    B.shot(url, id).then(function (s) { if (s) { img.src = s; fig.hidden = false; } });
    return fig;
  };

  var CTL = {idle: 1, working: 1, paused: 1, stopped: 1};
  B.ctl = function (s) {
    s = s || {};
    if (s.stopped) return 'stopped';            // also from the moment Stop was pressed in the app, before Chrome says so
    if (CTL[s.mode] === 1) return s.mode;
    return s.paused ? 'paused' : s.working ? 'working' : 'idle';   // a helper from before the one control state
  };

  // front or background: 'view' (mode now names the control state); a helper from before still says it in 'mode'
  B.front = function (s) {
    s = s || {};
    return s.view === 'front' || s.mode === 'front';
  };

  // My Chrome is in use: chosen in Settings, or still holding something after the person chose Qosha's own Chrome
  // (tabs, a pause or Stop, a step under way): its strip, its Resume, Stop and Done stay shown
  B.mine = function (s) {
    if (!s) return false;
    var c = B.ctl(s);
    return s.engine === 'extension' || s.tabs > 0 || !!s.busy || !!s.taken || c === 'paused' || c === 'stopped' || c === 'working';
  };

  B.line = function (s) {
    s = s || {};
    if (!B.mine(s)) return '';
    if (!s.connected) return 'Qosha\u2019s extension in your Chrome is not connected. Open Chrome, or see Settings \u2192 Browser.';
    var n = Number(s.tabs) || 0, tabs = n === 1 ? '1 tab' : n + ' tabs', ctl = B.ctl(s);
    var taken = 'You took over Qosha\u2019s tab. Press Resume to let Qosha go on.';
    if (ctl === 'paused') return 'Paused. ' + (s.taken !== false ? taken : 'Qosha does nothing in the browser until you press Resume.');
    if (ctl === 'stopped') {
      return (s.busy ? 'Stopping. ' : 'Stopped. ')
        + (s.taken ? taken : 'Qosha does nothing more in the browser until you press Resume.');
    }
    var where = B.front(s) ? 'in front, where you can watch' : 'in the background';
    if (ctl === 'working' || s.busy) return 'Qosha is working in your Chrome ' + where + (n ? ' (' + tabs + ').' : '.');
    if (n) return 'Qosha has ' + tabs + ' open in your Chrome, ' + where + '.';
    return '';
  };

  function clock(t) {
    var d = new Date((Number(t) || 0) * 1000);
    if (isNaN(d.getTime())) return '';
    var h = d.getHours(), m = d.getMinutes();
    return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
  }

  function site(u) {
    try { var x = new URL(String(u || '')); return x.protocol === 'http:' || x.protocol === 'https:' ? x.host : ''; }
    catch (e) { return ''; }
  }
  B.site = site;

  // one step: "14:02  clicked \u201CSign in\u201D  on example.com", the full address under it, and its picture when there is one
  B.step = function (url, a) {
    a = a || {};
    var li = el('li', {class: 'bxstep'});
    var head = el('p', {class: 'bxwhat'}, el('span', {class: 'bxt'}, clock(a.t)), ' ', String(a.action || ''));
    if (a.target) head.appendChild(el('span', {class: 'bxtarget'}, ' \u201C' + String(a.target) + '\u201D'));
    li.appendChild(head);
    if (a.url) li.appendChild(el('p', {class: 'bxurl'}, String(a.url)));
    if (a.shot) {
      li.appendChild(B.picture(url, a.shot, 'Picture of the page at this step', a.shot_kind === 'photo' ? 'Picture of Qosha\u2019s tab.'
        : 'Drawn copy of this part of the page (Chrome gives no picture of a tab in the background).'));
    }
    return li;
  };

  B.steps = function (url, actions) {
    var ol = el('ol', {class: 'bxsteps'});
    (Array.isArray(actions) ? actions : []).forEach(function (a) { ol.appendChild(B.step(url, a)); });
    return ol;
  };

  B.el = el;
})();
