"""The welcome questions on Home (backlog item 7; Ren 17 Nov 2026: a prompt card on Home, the interview as a pop-up
tile). Mounted at /api/plugins/qosha/welcome.

GET  /state            what Home should offer (interview, review or nothing), the person's current profile lines, the
                       name this computer knows them by, the time zone setting
POST /state {state}    "later" | "declined" | "redo"  (Later is offered once more, then only on request)
POST /save  {rows, timezone}
                       rows: [{target: "user"|"memory", old: <exact current line or null>, text: <new line or null>}]
                       old + no text = remove that line; old + text = replace it; no old + text = add.

Memory is written with the engine's own memory store (tools.memory_tool.load_on_disk_store -> MemoryStore.apply_batch:
atomic per file, the engine's own size limit and content scan, its own file lock). Nothing is written before Save.
Lines in Qosha's own notes (MEMORY.md) may only be the welcome's "Important people:" line: the page can never touch
what Qosha wrote there itself. The time zone is the engine's `timezone` setting; the welcome's own state is the Qosha
setting `qosha_welcome` in config.yaml (state, at, later). No answer here changes any "Always allow" choice."""
from __future__ import annotations

import os
import threading
from datetime import datetime, timezone as _tz

from fastapi import APIRouter, Body
from fastapi.responses import JSONResponse

router = APIRouter()
_LOCK = threading.Lock()
PEOPLE = "Important people:"
STATES = ("later", "declined", "redo")
MAX_LINE = 400


def _j(content, status=200):
    return JSONResponse(status_code=status, content=content, headers={"Cache-Control": "no-store"})


def _store():
    from tools.memory_tool import load_on_disk_store
    return load_on_disk_store()


def _entries(store, target):
    try:
        return [e for e in store._entries_for(target) if isinstance(e, str) and e.strip()]
    except Exception:
        return []


def _cfg():
    from hermes_cli.config import load_config
    return load_config()


def _save_cfg(cfg):
    from hermes_cli.config import save_config
    save_config(cfg)


def _welcome(cfg) -> dict:
    w = cfg.get("qosha_welcome")
    return dict(w) if isinstance(w, dict) else {}


def _first_name() -> str:
    """The first name this computer's account carries (Mac/Linux: the account's full name; Windows: the display
    name), or "" when there is none. Only offered as a chip; never saved unless the person picks it and saves."""
    full = ""
    try:
        if os.name == "nt":
            import ctypes
            size = ctypes.c_ulong(0)
            ctypes.windll.secur32.GetUserNameExW(3, None, ctypes.byref(size))          # 3 = NameDisplay
            if size.value:
                buf = ctypes.create_unicode_buffer(size.value + 1)
                if ctypes.windll.secur32.GetUserNameExW(3, buf, ctypes.byref(size)):
                    full = buf.value
            if not full:
                full = os.environ.get("USERNAME", "")
        else:
            import pwd
            full = (pwd.getpwuid(os.getuid()).pw_gecos or "").split(",")[0]
    except Exception:
        full = ""
    full = " ".join(full.replace("\\", " ").split())
    if not full or "@" in full:
        return ""
    first = full.split(" ")[0]
    return first[:40] if first[:1].isalpha() else ""


def _ai_ready() -> bool:
    """An AI account or key of the person's own is there (same rule as the Connect-your-AI panel)."""
    try:
        from agent.credential_pool import load_pool
        if any(len(load_pool(p).entries()) for p in ("anthropic", "openai-codex")):
            return True
    except Exception:
        pass
    try:
        from hermes_cli.config import load_env
        env = load_env()
        if any(env.get(k) for k in ("OPENROUTER_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GOOGLE_API_KEY", "GEMINI_API_KEY")):
            return True
    except Exception:
        pass
    try:   # Gemini through the person's Google subscription (the sign-in page's own check)
        import sys
        si = sys.modules.get("qosha_signin_api")
        if si is not None and si._gcli().connected():
            return True
    except Exception:
        pass
    return False


@router.get("/state")
def state():
    try:
        store = _store()
        user, mem = _entries(store, "user"), _entries(store, "memory")
        cfg = _cfg()
        w = _welcome(cfg)
        st = str(w.get("state") or "")
        later = int(w.get("later") or 0)
        filled = bool(user)
        # what Home offers: "interview" (6 questions), "review" (memory already filled, e.g. moved from cloud Qosha),
        # or "" (done, declined, or put off twice: from then on only when asked)
        if st == "redo":
            offer = "interview"
        elif st in ("done", "declined") or (st == "later" and later >= 2):
            offer = ""
        else:
            offer = "review" if filled else "interview"
        return _j({"state": st, "later": later, "offer": offer, "ai_ready": _ai_ready(),
                   "user": user, "people": [e for e in mem if e.startswith(PEOPLE)],
                   "name_hint": _first_name(), "timezone": str(cfg.get("timezone") or ""),
                   "user_limit": getattr(store, "user_char_limit", None) or 1375})
    except Exception as e:
        return _j({"error": "unavailable", "detail": type(e).__name__}, 503)


@router.post("/state")
def set_state(body: dict = Body(...)):
    st = str((body or {}).get("state") or "")
    if st not in STATES:
        return _j({"error": "bad_state"}, 400)
    with _LOCK:
        cfg = _cfg()
        w = _welcome(cfg)
        if st == "later":
            w["later"] = int(w.get("later") or 0) + 1
        if st == "redo":
            w["later"] = 0
        w["state"] = st
        w["at"] = datetime.now(_tz.utc).isoformat(timespec="seconds")
        cfg["qosha_welcome"] = w
        _save_cfg(cfg)
    return _j({"ok": True, "state": st, "later": w.get("later", 0)})


def _clean(text):
    if text is None:
        return None
    t = " ".join(str(text).split())
    return t or None


@router.post("/save")
def save(body: dict = Body(...)):
    rows = (body or {}).get("rows") or []
    if not isinstance(rows, list) or len(rows) > 40:
        return _j({"error": "bad_rows"}, 400)
    tz = _clean((body or {}).get("timezone"))
    if tz:
        try:
            from zoneinfo import ZoneInfo
            ZoneInfo(tz)
        except Exception:
            return _j({"error": "bad_timezone", "plain": "That time zone is not known."}, 400)
    with _LOCK:
        store = _store()
        cur = {"user": _entries(store, "user"), "memory": _entries(store, "memory")}
        ops = {"user": [], "memory": []}
        for r in rows:
            if not isinstance(r, dict):
                return _j({"error": "bad_row"}, 400)
            target = r.get("target")
            if target not in ops:
                return _j({"error": "bad_target"}, 400)
            old, text = _clean(r.get("old")), _clean(r.get("text"))
            for v in (old, text):
                if v and len(v) > MAX_LINE:
                    return _j({"error": "too_long", "plain": "One line is too long. Keep each answer short."}, 400)
            if target == "memory" and any(v and not v.startswith(PEOPLE) for v in (old, text)):
                return _j({"error": "not_allowed"}, 400)      # Qosha's own notes stay Qosha's
            if old and old not in cur[target]:
                return _j({"error": "changed", "plain": "Something in Qosha's memory changed meanwhile. Reopen and try again."}, 409)
            if old and not text:
                ops[target].append({"action": "remove", "old_text": old})
            elif old and text and text != old:
                ops[target].append({"action": "replace", "old_text": old, "content": text})
            elif not old and text and text not in cur[target]:
                ops[target].append({"action": "add", "content": text})
        results = {}
        for target, lst in ops.items():
            if not lst:
                continue
            res = store.apply_batch(target, lst)
            if not (isinstance(res, dict) and res.get("success") is True):
                plain = "Qosha's memory is full: remove a line or shorten one, then save again." \
                    if "limit" in str(res).lower() or "exceed" in str(res).lower() else \
                    "Qosha could not save this to its memory."
                return _j({"error": "memory", "plain": plain, "detail": str((res or {}).get("error") or "")[:300],
                           "saved": results}, 400)
            results[target] = len(lst)
        cfg = _cfg()
        if tz:
            cfg["timezone"] = tz
        w = _welcome(cfg)
        w.update({"state": "done", "at": datetime.now(_tz.utc).isoformat(timespec="seconds"), "later": 0})
        cfg["qosha_welcome"] = w
        _save_cfg(cfg)
        if tz:
            try:
                import hermes_time
                hermes_time.reset_cache()
            except Exception:
                pass
        after = _store()
    return _j({"ok": True, "changed": results, "user": _entries(after, "user"),
               "people": [e for e in _entries(after, "memory") if e.startswith(PEOPLE)], "timezone": tz or ""})
