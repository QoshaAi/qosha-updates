/* Home composer (2 Nov): one card on Home, like the engine's own home screen, with Qosha as the
   orchestrator. Ask Qosha (the main brain with all its tools), Claude, ChatGPT, Gemini (text only) or All (side by
   side, as Ask All does); a mode for the new chat; Account (once called Provider) / Model / Effort for the chosen one (with Qosha chosen,
   the same main-brain setting as before: one place); attach files (saved in the Qosha files folder, attached to the
   first message); dictation and voice mode from pages/qosha-voice.js (the same code as the Chat page's text box: the
   engine's own speech-to-text, and the chat reads the answer aloud with the computer's own voice). Enter or Send opens the Qosha chat with the text sent (U-E1); nothing is
   sent before the person sends. A custom element with its own (open) shadow root: the page's re-renders never touch
   what is inside, so text, choices and a recording survive them. Text only, never HTML from data. No request on page
   load: the setting and the choices arrive with the page's own status read.
   CONTRACT G1: where the status read says `gemini_chat` (a cloud Qosha with Gemini connected), Gemini is a chat model
   like Claude and ChatGPT: every mode, files and skills, the models the person's Gemini app offers (CONTRACT G3; no
   effort), and the same hand-off to the
   chat page. Everywhere else Gemini stays text only, exactly as before. */
(function () {
  'use strict';
  if (window.customElements && customElements.get('qosha-composer')) return;

  var NAMES = {qosha: 'Qosha', claude: 'Claude', chatgpt: 'ChatGPT', gemini: 'Gemini', all: 'All 3'};
  var PROV = {claude: 'anthropic', chatgpt: 'openai-codex'};
  // the modes, in the agreed order; `pre` is what the new chat is told before the person's first message
  var MODES = [
    {id: 'orchestrate', label: 'Orchestrate', tip: 'The full assistant with all its tools and helpers.', pre: ''},
    {id: 'chat', label: 'Chat', tip: 'Plain conversation: answers and drafts, no tools.',
     pre: 'Mode: Chat. Answer in plain conversation. Don’t use tools or take any action unless I ask for it in this chat.'},
    {id: 'code', label: 'Code', tip: 'Coding tools working in a project folder inside the Qosha files folder.',
     pre: 'Mode: Code. Work as a careful programmer inside one project folder in my Qosha files folder (Code/<a short name>); create it if needed and keep every file there. Run and check what you write, and tell me what you changed.'},
    {id: 'research', label: 'Research', tip: 'Web search and reading, ending in a write-up with sources.',
     pre: 'Mode: Research. Search the web and read the best sources, then finish with a short write-up in plain words and a list of the sources you used (title and link).'},
    {id: 'design', label: 'Design', tip: 'Makes a page or mockup file that opens in the file viewer.',
     pre: 'Mode: Design. Make the page or mockup as one self-contained HTML file in my Qosha files folder (Designs/), then tell me its name so I can open it in Files.'},
    {id: 'review', label: 'Review', tip: 'A critique or second opinion of a file or text.',
     pre: 'Mode: Review. Give a critique or second opinion of what I share: what works, what to fix, most important first. Don’t change any file.'},
    {id: 'automations', label: 'Automations', tip: 'Sets up a scheduled task (still held by the approval guard).',
     pre: 'Mode: Automations. Set this up as a scheduled automation with your automation tool, delivered here (local). Anything it would send, pay, delete or share still waits for my approval.'},
    {id: 'long', label: 'Long-running', tip: 'A background task that keeps going and reports back in Tasks.',
     pre: 'Mode: Long-running. Treat this as a background task: add it to my Tasks board, keep working until it is done even if I close this chat, update the task as you go and finish with a short summary there. If you can’t reach the Tasks board, say so.'}
  ];
  // where a mode makes sense: Gemini answers text only (no tools); All is the council (one brief, one combined answer)
  var GEMINI_MODES = {chat: 1, review: 1};
  // Gemini as a chat model (CONTRACT G1): its two models, as a person reads them; the first is the default
  var GEM_MODELS = [], GEM_DEFAULT = '';   // CONTRACT G3: what the person's own Gemini app offers, from the status read
  var ALL_MODES = {orchestrate: 1, chat: 1, research: 1, review: 1};
  var SUGG = [
    {to: 'qosha', title: 'Qosha', sub: 'Your assistant, with all your tools.', q: 'Summarize today’s inbox and draft replies for the ones that need me.'},
    {to: 'claude', title: 'Claude', sub: 'Analysis, writing and planning.', q: 'Turn my open tasks into a plan for this week.'},
    {to: 'chatgpt', title: 'ChatGPT', sub: 'A review or a second opinion.', q: 'Give me a second opinion on my latest customer email reply.'}
  ];
  var STORE = 'qosha.composer.picks';

  function token() {
    try { var f = window; while (f.parent && f.parent !== f) { f = f.parent; var t = f.__HERMES_SESSION_TOKEN__; if (typeof t === 'string' && /^[\x21-\x7e]+$/.test(t)) return t; } }
    catch (e) { /* no readable dashboard parent */ }
    return null;
  }
  function call(method, path, body, raw) {
    var h = {}; var t = token(); if (t) h['X-Hermes-Session-Token'] = t;
    var init = {method: method, credentials: 'same-origin', cache: 'no-store', headers: h};
    if (raw) init.body = raw;
    else if (body) { h['Content-Type'] = 'application/json'; init.body = JSON.stringify(body); }
    return fetch(path, init).then(function (r) {
      return r.json().catch(function () { return null; }).then(function (j) {
        if (!r.ok) { var e = new Error((j && (j.message || j.detail || j.error)) || ('HTTP ' + r.status)); e.status = r.status; throw e; }
        return j;
      });
    }, function () { throw new Error('Qosha is not answering on this computer right now'); });
  }
  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') n.textContent = attrs[k];
      else if (k === 'on') Object.keys(attrs.on).forEach(function (ev) { n.addEventListener(ev, attrs.on[ev]); });
      else if (attrs[k] != null && attrs[k] !== false) n.setAttribute(k, attrs[k] === true ? '' : String(attrs[k]));
    });
    (kids || []).forEach(function (c) { if (c != null) n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return n;
  }
  function svg(d, cls) {
    var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('aria-hidden', 'true'); s.setAttribute('class', cls || 'ic');
    d.forEach(function (x) { var p = document.createElementNS('http://www.w3.org/2000/svg', x[0]); Object.keys(x[1]).forEach(function (k) { p.setAttribute(k, x[1][k]); }); s.appendChild(p); });
    return s;
  }
  var IC = {
    plus: [['path', {d: 'M12 5v14M5 12h14'}]],
    up: [['path', {d: 'M12 19V5M6 11l6-6 6 6'}]],
    x: [['path', {d: 'M6 6l12 12M18 6 6 18'}]],
    file: [['path', {d: 'M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8z'}], ['path', {d: 'M14 3v5h5'}]],
    star: [['path', {d: 'M12 3l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.4 6.8 19.1l1-5.8L3.5 9.2l5.9-.9z'}]],
    down: [['path', {d: 'm6 9 6 6 6-6'}]]
  };
  // "Use this skill" on the Skills page hands the skill over through this tab's session storage (like Home's question to
  // Chat): taken once, by the next Home, only if fresh; never in the address
  var SKILL_KEY = 'qosha.skill.next', SKILL_RE = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}$/;
  function takeSkill() {
    var raw = null;
    try { raw = window.sessionStorage.getItem(SKILL_KEY); window.sessionStorage.removeItem(SKILL_KEY); } catch (e) { return null; }
    try {
      var h = raw ? JSON.parse(raw) : null;
      var age = h && typeof h.at === 'number' && isFinite(h.at) ? Date.now() - h.at : -1;
      if (!h || typeof h.slug !== 'string' || !SKILL_RE.test(h.slug) || age < 0 || age > 120000) return null;
      var title = typeof h.title === 'string' ? h.title.replace(/[\x00-\x1f\x7f\u2028\u2029]/g, ' ').trim().slice(0, 120) : '';
      return {slug: h.slug, title: title || h.slug};
    } catch (e) { return null; }
  }

  // Home v2 (approved 8 Nov 2026, handoff qosha-home-redesign): a bone card with the mode tabs (4 + More) and the mode's
  // description on one row, a white field holding the text and the toolbar (attach, who answers with each one's mark, the
  // model pill and its popover, dictation, Talk, Send), and the route line under it. Every control keeps a 44 px target:
  // the smaller shapes in the design are drawn inside it (::before), so the look matches and touch stays easy.
  var CSS = [
    ':host{display:block;margin-top:24px}',
    '.wrap{--c-card:#F5F4F0;--c-field:#FFFFFF;--c-fline:#B9C4BE;--c-fline2:#8A9690;--c-ink:#0B0B0B;--c-ink2:#3E4B45;--c-ink3:#5A6761;--c-line:#E3E7E4;--c-track:#ECEBE6;--c-hover:rgba(11,51,38,.06);--c-forest:#0B3326;--c-on:#0B3326;--c-onInk:#FFFFFF;--c-ring:#0B3326;--c-gold:#B8955A;--c-goldHi:#DCB87A;--c-moss:#2F7A55;--c-idle:#C9D1CD;--c-warn:#8A4B0F;--c-pop:#FFFFFF}',
    '.wrap.dark{--c-card:#153E30;--c-field:#0F3024;--c-fline:#527765;--c-fline2:#8BC7AA;--c-ink:#F3F8F5;--c-ink2:#CFE6DA;--c-ink3:#ACC5B7;--c-line:#315745;--c-track:#12382B;--c-hover:rgba(255,255,255,.08);--c-forest:#E3EEE7;--c-on:#E3EEE7;--c-onInk:#0B3326;--c-ring:#8BC7AA;--c-gold:#E2C893;--c-goldHi:#E2C893;--c-moss:#8BC7AA;--c-idle:#315745;--c-warn:#F2C48D;--c-pop:#153E30}',
    '*{box-sizing:border-box}',
    '.sr{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}',
    'button,select{font:inherit;color:inherit}',
    'button{cursor:pointer;border:0;background:transparent;padding:0}',
    'button:focus-visible,select:focus-visible{outline:2px solid var(--c-ring);outline-offset:2px}',
    '.ic{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;flex:none}',
    '.lg{display:block;width:16px;height:16px;flex:none;border-radius:4px}',
    // the card
    '.card{border-radius:22px;background:var(--c-card);color:var(--c-ink);padding:8px;box-shadow:0 0 0 1px rgba(220,184,122,.5),0 30px 60px -24px rgba(0,0,0,.7),inset 0 1px 0 rgba(255,255,255,.4)}',
    '.wrap.dark .card{box-shadow:0 0 0 1px rgba(220,184,122,.4),0 30px 60px -24px rgba(0,0,0,.7)}',
    // mode tabs + the mode description on the same row
    '.tabrow{display:flex;align-items:center;gap:2px 16px;padding:0 8px 2px}',
    '.modes{flex:none;display:flex;align-items:center;flex-wrap:wrap;gap:2px}',
    '.mode,.morebtn{position:relative;isolation:isolate;display:inline-flex;align-items:center;gap:2px;height:44px;padding:0 10px;font-size:13.5px;color:var(--c-ink2);white-space:nowrap}',
    '.mode::before,.morebtn::before{content:"";position:absolute;inset:7px 0;z-index:-1;border-radius:8px;transition:background-color 160ms}',
    '.mode:hover::before,.morebtn:hover::before{background:var(--c-hover)}',
    '.mode[aria-checked=true],.morebtn.active{color:var(--c-forest);font-weight:500}',
    '.modes > .mode[aria-checked=true]::before,.morebtn.active::before{background:var(--c-field);box-shadow:0 0 0 1px var(--c-line)}',
    '.mode[aria-disabled=true]{opacity:.5;cursor:not-allowed}',
    '.morebtn .ic{width:18px;height:18px}',
    '.more{position:relative}',
    '.menu{position:absolute;left:0;top:40px;z-index:6;display:flex;flex-direction:column;min-width:200px;padding:6px;border-radius:12px;background:var(--c-pop);border:1px solid var(--c-line);box-shadow:0 16px 32px -12px rgba(6,37,27,.3)}',
    '.menu[hidden]{display:none}',
    '.menu .mode{justify-content:flex-start;width:100%;color:var(--c-ink);font-weight:400}',
    '.menu .mode::before{inset:2px 0}',
    '.menu .mode[aria-checked=true]::before{background:var(--c-card)}',
    '.menu .mode[aria-checked=true]{color:var(--c-forest);font-weight:500}',
    '.mnote{flex:1 1 240px;min-width:0;margin:0;padding-right:6px;font-size:12.5px;line-height:17px;color:var(--c-ink3);text-align:right;text-wrap:balance}',
    '.mnote b{font-weight:500;color:var(--c-ink2)}',
    // the field
    '.field{display:block;margin-top:2px;background:var(--c-field);border:1px solid var(--c-fline);border-radius:16px;cursor:text;transition:border-color 150ms,box-shadow 150ms}',
    '.field:hover{border-color:var(--c-fline2)}',
    '.field:focus-within{border-color:var(--c-forest);box-shadow:0 0 0 3px rgba(11,51,38,.14)}',
    '.wrap.dark .field:focus-within{box-shadow:0 0 0 3px rgba(139,199,170,.25)}',
    'textarea{display:block;width:100%;min-height:96px;max-height:220px;resize:none;border:0;outline:0;background:transparent;color:var(--c-ink);caret-color:var(--c-forest);font:inherit;font-size:17px;line-height:25px;padding:16px 18px 6px}',
    'textarea::placeholder{color:#6B7671}',
    '.wrap.dark textarea::placeholder{color:var(--c-ink3)}',
    '.files,.skill{display:flex;flex-wrap:wrap;gap:6px;padding:12px 16px 0}',
    '.files:empty,.skill:empty{display:none}',
    '.fchip{display:inline-flex;align-items:center;gap:6px;max-width:100%;min-height:32px;padding:0 4px 0 10px;border-radius:10px;background:var(--c-card);font-size:12.5px;color:var(--c-ink2)}',
    '.fchip span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:220px}',
    '.fchip.bad{color:var(--c-warn)}',
    '.fchip button{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:8px}',
    '.fchip .ic,.schip .ic{width:16px;height:16px}',
    '.schip{display:inline-flex;align-items:center;gap:8px;max-width:100%;min-height:44px;padding:0 0 0 14px;border-radius:999px;background:var(--c-on);color:var(--c-onInk);font-size:13px;font-weight:500}',
    '.schip span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:320px}',
    '.schip button{display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;border-radius:999px;color:inherit}',
    '.schip button:focus-visible{outline:2px solid var(--c-gold);outline-offset:-4px}',
    // the toolbar inside the field
    '.tools{display:flex;align-items:center;gap:4px;padding:4px 8px 6px}',
    '.sp{flex:1}',
    '.ib{position:relative;isolation:isolate;flex:none;display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;color:var(--c-ink2)}',
    '.ib::before{content:"";position:absolute;inset:4px;z-index:-1;border-radius:999px;border:1px solid transparent;transition:background-color 160ms}',
    '.ib.ol::before{border-color:var(--c-line)}',
    '.ib:hover{color:var(--c-ink)}',
    '.ib:hover::before{background:var(--c-card)}',
    '.vb[aria-pressed=true]{color:var(--c-onInk)}',
    '.vb[aria-pressed=true]::before{background:var(--c-on);border-color:var(--c-on)}',
    '.vb[aria-pressed=true] .ic{animation:qcpulse 1.2s ease-in-out infinite}',
    '.vb.busy{opacity:.6}',
    '.ib .ic{width:20px;height:20px}',
    // who answers: a segmented control with each one's mark
    '.seg{position:relative;isolation:isolate;display:flex;align-items:center;flex-wrap:wrap;gap:2px;padding:0 3px;min-width:0}',
    '.seg::before{content:"";position:absolute;inset:4px 0;z-index:-1;border-radius:999px;background:var(--c-card)}',
    '.chip{position:relative;isolation:isolate;display:inline-flex;align-items:center;justify-content:center;gap:6px;height:44px;min-width:44px;padding:0 9px;font-size:13px;color:var(--c-ink2);white-space:nowrap}',
    '.chip::before{content:"";position:absolute;inset:7px 0;z-index:-1;border-radius:999px;transition:background-color 160ms}',
    '.chip:hover::before{background:var(--c-hover)}',
    '.chip[aria-checked=true]{color:var(--c-onInk)}',
    '.chip[aria-checked=true]::before{background:var(--c-on)}',
    '.chip[aria-checked=true] img.lg{box-shadow:0 0 0 1px rgba(255,255,255,.5)}',
    '.chip[aria-disabled=true]{opacity:.62;cursor:not-allowed}',
    '.chip small{font-size:11px;font-weight:400;opacity:.85}',
    '.lg-oa{color:#000000}',
    '.chip[aria-checked=true] .lg-oa,.wrap.dark .lg-oa{color:#FFFFFF}',
    // pills: the model and Talk
    '.qpill{position:relative;isolation:isolate;flex:none;display:inline-flex;align-items:center;gap:6px;height:44px;padding:0 10px 0 12px;font-size:13px;color:var(--c-ink);white-space:nowrap}',
    '.qpill::before{content:"";position:absolute;inset:4px 0;z-index:-1;border-radius:999px;border:1px solid var(--c-line);background:var(--c-field);transition:border-color 160ms}',
    '.qpill:hover::before{border-color:var(--c-fline2)}',
    '.qpill .ic{width:18px;height:18px;color:var(--c-ink3)}',
    '.qpill[aria-expanded=true]::before{border-color:var(--c-forest)}',
    '.vb.voice{padding:0 12px 0 10px;width:auto}',
    '.vb.voice .ic{color:var(--c-moss)}',
    '.vb.voice[aria-pressed=true] .ic{color:var(--c-onInk)}',
    '.vb.voice[aria-pressed=true]::before{background:var(--c-on);border-color:var(--c-on)}',
    '.tlk{font-size:13px}',
    // send
    '.go{position:relative;isolation:isolate;flex:none;display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;color:#FFFFFF}',
    '.go::before{content:"";position:absolute;inset:2px;z-index:-1;border-radius:999px;background:#0B3326;transition:background-color 160ms,transform 160ms}',
    '.wrap.dark .go::before{background:#2B8A66}',
    '.go.idle::before{background:var(--c-idle)}',
    '.go:hover::before{transform:scale(1.04)}',
    '.go:active::before{transform:scale(.94)}',
    '.go .ic{width:21px;height:21px}',
    // the model popover
    '.mp{position:relative;flex:none}',
    '.mpop{position:absolute;right:0;bottom:calc(100% + 4px);z-index:5;width:384px;max-width:calc(100vw - 32px);padding:14px;border-radius:16px;background:var(--c-pop);color:var(--c-ink);border:1px solid var(--c-line);box-shadow:0 20px 40px -12px rgba(6,37,27,.3)}',
    '.mpop[hidden]{display:none}',
    '.mpop h4{margin:0 0 6px;font-size:12px;line-height:16px;font-weight:500;letter-spacing:.08em;text-transform:uppercase;color:var(--c-ink3)}',
    '.pickers{display:flex;flex-direction:column;gap:2px}',
    '.pk{display:grid;grid-template-columns:70px minmax(0,1fr);align-items:center;gap:10px;min-height:44px;font-size:13px;color:var(--c-ink2)}',
    '.pk label,.pk .k{font-size:13px;color:var(--c-ink2)}',
    '.pk select{width:100%;height:44px;min-width:0;padding:0 10px;border-radius:10px;border:1px solid var(--c-fline);background:var(--c-field);color:var(--c-ink);font-size:13.5px}',
    '.pk .v{font-size:13.5px;color:var(--c-ink)}',
    '.eff{position:relative;isolation:isolate;display:flex}',
    '.eff::before{content:"";position:absolute;inset:4px 0;z-index:-1;border-radius:10px;background:var(--c-card)}',
    '.eff button{position:relative;isolation:isolate;flex:1 1 auto;height:44px;padding:0 6px;font-size:12.5px;color:var(--c-ink2);white-space:nowrap}',
    '.eff button::before{content:"";position:absolute;inset:7px 3px;z-index:-1;border-radius:8px}',
    '.eff button[aria-checked=true]{color:var(--c-forest);font-weight:500}',
    '.eff button[aria-checked=true]::before{background:var(--c-field);box-shadow:0 0 0 1px var(--c-line)}',
    '.eff button[disabled]{opacity:.5;cursor:default}',
    '.mpop .note{margin:6px 0 0;font-size:12px;line-height:17px;color:var(--c-ink3)}',
    // the route line and the status line
    '.route{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:8px 12px 4px;font-size:12.5px;line-height:18px;color:var(--c-ink3)}',
    '.route b{font-weight:500;color:var(--c-ink2)}',
    '.st{min-height:0;margin:0;padding:0 12px;font-size:13px;line-height:18px;color:var(--c-ink)}',
    '.st:not(:empty){padding:2px 12px 6px}',
    '.st.err{color:var(--c-warn)}',
    // starter cards on the green
    '.sugg{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:20px}',
    '.sg{display:flex;flex-direction:column;align-items:flex-start;justify-content:center;gap:6px;min-height:44px;padding:14px 16px;border-radius:16px;border:1px solid rgba(255,255,255,.26);background:rgba(6,37,27,.55);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);color:#FFFFFF;text-align:left;transition:background-color 160ms}',   // one soft white hairline (Ren, 17 Nov 11:55, option B)
    '.sg:hover{background:rgba(255,255,255,.08)}',
    '.sg:focus-visible{outline:2px solid #DCB87A;outline-offset:2px}',
    '.sg .who{display:flex;align-items:center;gap:8px;font-size:12.5px;line-height:18px;color:#A9BAB2}',
    '.sg .av{display:grid;place-items:center;width:22px;height:22px;border-radius:6px;background:#FFFFFF;flex:none}',
    '.sg .av .lg-oa{color:#000000}',
    '.sg .t{font-size:14.5px;line-height:21px}',
    '@keyframes qcpulse{0%,100%{opacity:1}50%{opacity:.45}}',
    '@media (prefers-reduced-motion:reduce){.field,.chip::before,.mode::before,.ib::before,.go::before,.sg,.qpill::before{transition:none}.vb[aria-pressed=true] .ic{animation:none}.go:hover::before,.go:active::before{transform:none}}',
    '@media (max-width:760px){.tabrow{flex-wrap:wrap;padding-bottom:6px}.mnote{flex-basis:100%;text-align:left;padding:0 2px}}',
    '@media (max-width:760px){.tools{flex-wrap:wrap}.seg{order:-1;flex-basis:100%}.sp{display:none}.mp{margin-left:auto}.sugg{grid-template-columns:minmax(0,1fr)}.route{flex-wrap:wrap}}',
    // phones (visual QA MED 10): the assistants stay on one line that scrolls sideways instead of wrapping into a blob;
    // the mode tabs scroll too, with a soft fade on the right as the hint
    '@media (max-width:520px){.seg{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none;max-width:100%}.seg > *{flex:none}.seg::-webkit-scrollbar{display:none}.seg::before{border-radius:22px}.modes{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none;max-width:100%;-webkit-mask-image:linear-gradient(90deg,#000 85%,transparent);mask-image:linear-gradient(90deg,#000 85%,transparent)}.modes::-webkit-scrollbar{display:none}.tabrow{flex-wrap:wrap}}',
    '@media (max-width:640px){.card{padding:6px}textarea{min-height:84px;font-size:16px}.mpop{position:fixed;left:16px;right:16px;bottom:16px;width:auto}.pk{grid-template-columns:minmax(0,1fr);gap:0;padding-top:4px}.eff button{padding:0 4px}}'
  ].join('\n');

  // each one's mark, next to its name (Home v2): Qosha's own tile; Claude, ChatGPT and Gemini in their brand colours
  var MARKS = {
    claude: [['path', {fill: '#D97757', d: 'm4.7144 15.9555 4.7174-2.6471.079-.2307-.079-.1275h-.2307l-.7893-.0486-2.6956-.0729-2.3375-.0971-2.2646-.1214-.5707-.1215-.5343-.7042.0546-.3522.4797-.3218.686.0608 1.5179.1032 2.2767.1578 1.6514.0972 2.4468.255h.3886l.0546-.1579-.1336-.0971-.1032-.0972L6.973 9.8356l-2.55-1.6879-1.3356-.9714-.7225-.4918-.3643-.4614-.1578-1.0078.6557-.7225.8803.0607.2246.0607.8925.686 1.9064 1.4754 2.4893 1.8336.3643.3035.1457-.1032.0182-.0728-.164-.2733-1.3539-2.4467-1.445-2.4893-.6435-1.032-.17-.6194c-.0607-.255-.1032-.4674-.1032-.7285L6.287.1335 6.6997 0l.9957.1336.419.3642.6192 1.4147 1.0018 2.2282 1.5543 3.0296.4553.8985.2429.8318.091.255h.1579v-.1457l.1275-1.706.2368-2.0947.2307-2.6957.0789-.7589.3764-.9107.7468-.4918.5828.2793.4797.686-.0668.4433-.2853 1.8517-.5586 2.9021-.3643 1.9429h.2125l.2429-.2429.9835-1.3053 1.6514-2.0643.7286-.8196.85-.9046.5464-.4311h1.0321l.759 1.1293-.34 1.1657-1.0625 1.3478-.8804 1.1414-1.2628 1.7-.7893 1.36.0729.1093.1882-.0183 2.8535-.607 1.5421-.2794 1.8396-.3157.8318.3886.091.3946-.3278.8075-1.967.4857-2.3072.4614-3.4364.8136-.0425.0304.0486.0607 1.5482.1457.6618.0364h1.621l3.0175.2247.7892.522.4736.6376-.079.4857-1.2142.6193-1.6393-.3886-3.825-.9107-1.3113-.3279h-.1822v.1093l1.0929 1.0686 2.0035 1.8092 2.5075 2.3314.1275.5768-.3218.4554-.34-.0486-2.2039-1.6575-.85-.7468-1.9246-1.621h-.1275v.17l.4432.6496 2.3436 3.5214.1214 1.0807-.17.3521-.6071.2125-.6679-.1214-1.3721-1.9246L14.38 17.959l-1.1414-1.9428-.1397.079-.674 7.2552-.3156.3703-.7286.2793-.6071-.4614-.3218-.7468.3218-1.4753.3886-1.9246.3157-1.53.2853-1.9004.17-.6314-.0121-.0425-.1397.0182-1.4328 1.9672-2.1796 2.9446-1.7243 1.8456-.4128.164-.7164-.3704.0667-.6618.4008-.5889 2.386-3.0357 1.4389-1.882.929-1.0868-.0062-.1579h-.0546l-6.3385 4.1164-1.1293.1457-.4857-.4554.0608-.7467.2307-.2429 1.9064-1.3114Z'}]],
    chatgpt: [['path', {fill: 'currentColor', d: 'M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.872zm16.5963 3.8558L13.1038 8.364 15.1192 7.2a.0757.0757 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.407-.667zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813zm1.0976-2.3654l2.602-1.4998 2.6069 1.4998v2.9994l-2.5974 1.4997-2.6067-1.4997Z'}]],
    gemini: [['path', {d: 'M11.04 19.32Q12 21.51 12 24q0-2.49.93-4.68.96-2.19 2.58-3.81t3.81-2.55Q21.51 12 24 12q-2.49 0-4.68-.93a12.3 12.3 0 0 1-3.81-2.58 12.3 12.3 0 0 1-2.58-3.81Q12 2.49 12 0q0 2.49-.96 4.68-.93 2.19-2.55 3.81a12.3 12.3 0 0 1-3.81 2.58Q2.49 12 0 12q2.49 0 4.68.96 2.19.93 3.81 2.55t2.55 3.81'}]]
  };
  var markSeq = 0;
  function mark(k) {
    if (k === 'qosha') return el('img', {class: 'lg', src: 'assets/brand/icons/qosha-icon.svg', alt: '', width: '16', height: '16'});
    if (!MARKS[k]) return null;
    var NS = 'http://www.w3.org/2000/svg', s = document.createElementNS(NS, 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', '16'); s.setAttribute('height', '16'); s.setAttribute('aria-hidden', 'true');
    s.setAttribute('class', 'lg' + (k === 'chatgpt' ? ' lg-oa' : ''));
    var fill = null;
    if (k === 'gemini') {   // a gradient per mark: ids are shared within the shadow root
      var id = 'qcgem' + (++markSeq), defs = document.createElementNS(NS, 'defs'), g = document.createElementNS(NS, 'linearGradient');
      [['id', id], ['x1', '0'], ['y1', '1'], ['x2', '1'], ['y2', '0']].forEach(function (a) { g.setAttribute(a[0], a[1]); });
      [['0', '#4285F4'], ['.55', '#9B72CB'], ['1', '#D96570']].forEach(function (st) { var x = document.createElementNS(NS, 'stop'); x.setAttribute('offset', st[0]); x.setAttribute('stop-color', st[1]); g.appendChild(x); });
      defs.appendChild(g); s.appendChild(defs); fill = 'url(#' + id + ')';
    }
    MARKS[k].forEach(function (x) { var p = document.createElementNS(NS, x[0]); Object.keys(x[1]).forEach(function (a) { p.setAttribute(a, x[1][a]); }); if (fill) p.setAttribute('fill', fill); s.appendChild(p); });
    return s;
  }
  var VISIBLE_MODES = 4;   // Orchestrate, Chat, Code, Research on the row; the rest under More

  class Composer extends HTMLElement {}

  Composer.prototype.connectedCallback = function () {
    if (this._ready) { this._theme(); return; }
    this._ready = true;
    var self = this;
    this.target = 'qosha'; this.mode = 'orchestrate'; this.files = []; this.saving = false; this.account = '';
    this.ok = {claude: true, chatgpt: false, gemini: false}; this.okKnown = false; this.gemChat = false;
    try { this.picks = JSON.parse(window.localStorage.getItem(STORE) || '{}') || {}; } catch (e) { this.picks = {}; }
    var root = this.attachShadow({mode: 'open'});
    root.appendChild(el('style', {text: CSS}));
    this.ta = el('textarea', {id: 'hero-q', rows: '3', autocomplete: 'off', 'aria-describedby': 'qc-det'});
    this.fileIn = el('input', {type: 'file', multiple: true, hidden: true, tabindex: '-1', 'aria-hidden': 'true'});
    this.chipsBox = el('div', {class: 'seg chips', role: 'radiogroup', 'aria-label': 'Who answers'});
    var V = window.QoshaVoice, vb = V ? V.buttons() : null;   // the shared dictation / voice mode (pages/qosha-voice.js)
    this.mic = vb ? vb.mic : null; this.voice = vb ? vb.voice : null;
    if (this.mic) this.mic.classList.add('ib');
    if (this.voice) { this.voice.classList.add('qpill'); this.voice.appendChild(el('span', {class: 'tlk', 'aria-hidden': 'true', text: 'Talk'})); }
    this.modesBox = el('div', {class: 'modes', role: 'radiogroup', 'aria-label': 'Mode for a new chat'});
    this.mnote = el('p', {class: 'mnote', id: 'qc-mnote'});
    this.filesBox = el('div', {class: 'files', 'aria-label': 'Attached files', role: 'list'});
    this.skillBox = el('div', {class: 'skill'});
    this.skill = takeSkill();
    this.pickers = el('div', {class: 'pickers'});
    this.pillText = el('span', {text: 'Loading…'});
    this.pill = el('button', {class: 'qpill', type: 'button', 'aria-haspopup': 'dialog', 'aria-expanded': 'false', 'aria-controls': 'qc-pop'}, [this.pillText, svg(IC.down)]);
    this.popNote = el('p', {class: 'note'});
    this.pop = el('div', {class: 'mpop', id: 'qc-pop', role: 'dialog', 'aria-label': 'Model settings', hidden: true}, [el('h4', {text: 'Model settings'}), this.pickers, this.popNote]);
    this.det = el('span', {id: 'qc-det'});
    this.go = el('button', {class: 'go idle', type: 'submit'}, [svg(IC.up)]);
    this.st = el('p', {class: 'st', role: 'status', 'aria-live': 'polite'});
    var field = el('div', {class: 'field'}, [
      this.skillBox, this.filesBox,
      el('label', {class: 'sr', for: 'hero-q', text: 'Ask Qosha'}), this.ta,
      el('div', {class: 'tools'}, [el('button', {class: 'ib ol att', type: 'button', 'aria-label': 'Attach files', title: 'Attach files'}, [svg(IC.plus)]),
        this.fileIn, this.chipsBox, el('span', {class: 'sp'}), el('div', {class: 'mp'}, [this.pill, this.pop]), this.mic, this.voice, this.go])
    ]);
    var form = el('form', {class: 'card', 'aria-label': 'Ask Qosha'}, [
      el('div', {class: 'tabrow'}, [this.modesBox, this.mnote]),
      field,
      el('div', {class: 'route'}, [this.det]),
      this.st
    ]);
    form.addEventListener('submit', function (e) { e.preventDefault(); self.send(); });
    form.querySelector('.att').addEventListener('click', function () { self.fileIn.click(); });
    field.addEventListener('click', function (e) { if (e.target === field) self.ta.focus(); });   // the whole field is the text box
    this.fileIn.addEventListener('change', function () { var fs = Array.prototype.slice.call(self.fileIn.files || []); self.fileIn.value = ''; self.attach(fs); });
    this.ta.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); self.send(); }
    });
    this.ta.addEventListener('input', function () { self.grow(); });
    // the model popover and the More menu: one open at a time; a click elsewhere or Escape closes them
    this.pill.addEventListener('click', function (e) { self.popOpen(self.pop.hidden, e.detail === 0); });   // keyboard: focus moves in
    root.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (!self.pop.hidden) { e.stopPropagation(); self.popOpen(false); self.pill.focus(); }
      else if (self.menu && !self.menu.hidden) { e.stopPropagation(); self.menuOpen(false); self.moreBtn.focus(); }
    });
    this._outside = function (e) {
      var path = e.composedPath ? e.composedPath() : [];
      if (!self.pop.hidden && path.indexOf(self.pop) < 0 && path.indexOf(self.pill) < 0) self.popOpen(false);
      if (self.menu && !self.menu.hidden && path.indexOf(self.menu) < 0 && path.indexOf(self.moreBtn) < 0) self.menuOpen(false);
    };
    document.addEventListener('click', this._outside, true);
    if (V) this.vox = V.attach({mic: this.mic, voice: this.voice, box: this.ta, grow: function () { self.grow(); },
      say: function (t, err) { self.say(t, err); },
      transcribe: function (body) { return call('POST', '/api/audio/transcribe', body); },
      // Talk is hands-free (Ren, 17 Nov 22:20: it only answered after a second press): it opens a new chat with live
      // voice chat on, which hears when the person stops and reads the answer while it is written
      voiceClick: function () { self.talkLive(); },
      voiceLabel: 'Talk: a hands-free voice chat. Just talk; Qosha hears when you stop and answers aloud',
      blocked: function (kind) { return kind === 'voice' && self.target === 'all' ? 'Voice mode talks with one assistant: pick Qosha, Claude, ChatGPT or Gemini.' : ''; },
      heard: function (t) {
        // a typed draft is never replaced (GPT R19 #2): the spoken words join it and nothing is sent until Send
        var cur = self.ta.value.replace(/\s+$/, '');
        if (cur.trim()) { self.ta.value = cur + '\n' + t; self.grow(); self.say('Heard: “' + t + '”. Your typed text is still in the box, so nothing was sent: check it, then press Send.', true); return; }
        self.ta.value = t; self.grow(); self.say('Heard: “' + t + '”. Sending…'); self.send({voice: true});
      }});
    var sugg = el('div', {class: 'sugg'}, SUGG.map(function (g) {
      return el('button', {class: 'sg', type: 'button', 'aria-label': g.title + ': ' + g.sub + ' Suggestion: ' + g.q,
        on: {click: function () { self.pick(g.to, true); self.ta.value = g.q; self.grow(); self.ta.focus(); self.say('Suggestion in the box. Nothing is sent until you press Send.'); }}},
        [el('span', {class: 'who'}, [el('span', {class: 'av'}, [mark(g.to)]), g.title + ' · ' + g.sub.replace(/\.$/, '')]), el('span', {class: 't', text: g.q})]);
    }));
    this.wrap = el('div', {class: 'wrap'}, [form, sugg]);   // the theme lives here: the page's re-renders reset the host's attributes
    root.appendChild(this.wrap);
    this.drawChips(); this.drawModes(); this.drawPickers();
    window.addEventListener('qosha-brain', function () { self.drawPickers(); self.drawChips(); });
    window.addEventListener('qosha-status-brain', function (ev) {
      var a = (ev.detail || {}).assistants;
      if (a && typeof a === 'object') { self.ok = {claude: a.claude !== false, chatgpt: !!a.chatgpt, gemini: !!a.gemini || a.gemini_chat === true}; self.okKnown = true; self.setGemChat(a); self.drawChips(); self.drawPickers(); }
    });
    var known = window.qoshaAssistants;   // a status read that landed before this composer connected
    if (known && typeof known === 'object' && !this.okKnown) { this.ok = {claude: known.claude !== false, chatgpt: !!known.chatgpt, gemini: !!known.gemini || known.gemini_chat === true}; this.okKnown = true; this.setGemChat(known); this.drawChips(); this.drawPickers(); }
    if (window.qoshaBrain) this.drawPickers();
    this._theme();
    this.drawSkill();
    if (this.skill) {
      this.say(this.skill.title + ' is selected. Type what you need, then send.');
      // focus once the page has drawn (the composer sits in the page's first screen)
      window.requestAnimationFrame(function () { try { self.ta.focus({preventScroll: false}); } catch (e) { /* not shown */ } });
    }
  };
  Composer.prototype.popOpen = function (on, moveFocus) {
    if (on && this.menu && !this.menu.hidden) this.menuOpen(false);
    this.pop.hidden = !on; this.pill.setAttribute('aria-expanded', on ? 'true' : 'false');
    if (on && moveFocus) { var f = this.pop.querySelector('select:not([disabled]),.eff [aria-checked=true],button'); if (f) f.focus(); }
  };
  Composer.prototype.menuOpen = function (on) {
    if (!this.menu) return;
    if (on && !this.pop.hidden) this.popOpen(false);
    this.menu.hidden = !on; this.moreBtn.setAttribute('aria-expanded', on ? 'true' : 'false');
  };
  // ---- a skill picked on the Skills page ------------------------------------------------------------------
  Composer.prototype.drawSkill = function () {
    var self = this, box = this.skillBox, s = this.skill;
    while (box.firstChild) box.removeChild(box.firstChild);
    this.drawChips();   // the box's placeholder names the skill
    if (!s) return;
    box.appendChild(el('div', {class: 'schip'}, [svg(IC.star), el('span', {text: 'Skill: ' + s.title, title: s.title}),
      el('button', {type: 'button', 'aria-label': 'Remove the skill ' + s.title, title: 'Remove the skill',
        on: {click: function () { self.skill = null; self.drawSkill(); self.say('Skill removed. Qosha picks its own skills.'); self.ta.focus(); }}}, [svg(IC.x)])]));
  };
  Composer.prototype._theme = function () {
    var q = this.closest('.q'), self = this;
    var set = function () { if (self.wrap) self.wrap.classList.toggle('dark', !!(q && q.classList.contains('t-dark'))); };
    set();
    if (q && !this._mo) { this._mo = new MutationObserver(set); this._mo.observe(q, {attributes: true, attributeFilter: ['class']}); }
  };
  Composer.prototype.grow = function () { this.ta.style.height = 'auto'; this.ta.style.height = Math.min(this.ta.scrollHeight, 220) + 'px'; if (this.go) this.go.classList.toggle('idle', !this.ta.value.trim()); };
  Composer.prototype.say = function (t, err) { this.st.textContent = t || ''; this.st.classList.toggle('err', !!err); };

  // ---- who answers --------------------------------------------------------------------------------------------
  // CONTRACT G1: Gemini is a chat model only where the status read says so; the modes follow at once
  Composer.prototype.setGemChat = function (a) {
    var list = (a && Array.isArray(a.gemini_models) ? a.gemini_models : []).filter(function (m) {
      return m && typeof m.id === 'string' && /^gemini-[a-z0-9.-]{1,40}$/.test(m.id) && typeof m.label === 'string' && m.label;
    }).map(function (m) { return {id: m.id, label: m.label.slice(0, 60)}; });
    var on = !!(a && a.gemini_chat === true) && list.length > 0;
    var same = on === this.gemChat && JSON.stringify(list) === JSON.stringify(GEM_MODELS);
    if (on) {
      GEM_MODELS = list;
      GEM_DEFAULT = list.filter(function (m) { return m.id === a.gemini_default; })[0] ? a.gemini_default : list[list.length - 1].id;
    }
    if (same) return;
    this.gemChat = on;
    if (this.target === 'gemini' && this.modesBox) this.drawModes();
    if (this.target === 'gemini' && this.pickers) this.drawPickers();
  };
  Composer.prototype.gemPick = function () {   // the Gemini model picked in this browser, else the default
    var saved = (this.picks.gemini || {}).model;
    return (GEM_MODELS.filter(function (m) { return m.id === saved; })[0] || {id: GEM_DEFAULT}).id;
  };
  Composer.prototype.brainWho = function () {
    var b = window.qoshaBrain || {};
    return b.provider === 'openai-codex' ? 'chatgpt' : b.provider === 'anthropic' ? 'claude' : '';
  };
  Composer.prototype.available = function (k) {
    if (k === 'qosha' || k === 'all') return true;   // Qosha stays choosable: its Provider picker is where a fix is made
    return !!this.ok[k];
  };
  Composer.prototype.offNote = function (k) {
    if (k === 'chatgpt') return 'ChatGPT is not signed in on this computer yet, so it can’t answer here. Ask Qosha or Claude.';
    if (k === 'gemini') return 'Gemini is not set up on this computer yet, so it can’t answer here. Ask Qosha or Claude.';
    if (k === 'qosha') return 'Qosha’s main assistant (ChatGPT) is not signed in right now. Pick Claude as the provider below.';
    return '';
  };
  Composer.prototype.drawChips = function () {
    var self = this, box = this.chipsBox;
    while (box.firstChild) box.removeChild(box.firstChild);
    Object.keys(NAMES).forEach(function (k) {
      var on = self.target === k, ok = self.available(k);
      var kids = [mark(k), NAMES[k]];
      if (!ok && k !== 'qosha') kids.push(el('small', {text: k === 'chatgpt' ? 'Not signed in' : 'Not set up'}));
      var b = el('button', {class: 'chip', type: 'button', role: 'radio', 'data-to': k, 'aria-checked': on ? 'true' : 'false',
        tabindex: on ? '0' : '-1', 'aria-disabled': ok ? null : 'true',
        'aria-label': NAMES[k] + (k === 'all' ? ': the council: Claude, ChatGPT and Gemini, one combined report' : '') + (ok ? '' : (k === 'qosha' ? '' : (k === 'chatgpt' ? ': not signed in' : ': not set up'))),
        title: k === 'qosha' ? 'Qosha: your assistant with all its tools, using the main assistant below' : k === 'all' ? 'The council: Claude, ChatGPT and Gemini, one combined report' : k === 'gemini' ? (self.gemChat ? 'Gemini: your Gemini app subscription, with all your tools' : 'Gemini answers in text only') : NAMES[k]}, kids);
      b.addEventListener('click', function () { self.pick(k); });
      box.appendChild(b);
    });
    box.onkeydown = function (e) {
      var keys = ['ArrowRight', 'ArrowDown', 'ArrowLeft', 'ArrowUp', 'Home', 'End'];
      if (keys.indexOf(e.key) < 0) return;
      e.preventDefault();
      var order = Object.keys(NAMES).filter(function (k) { return self.available(k) || k === self.target; });
      var i = order.indexOf(self.target);
      var n = e.key === 'Home' ? 0 : e.key === 'End' ? order.length - 1 : (i + (e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : order.length - 1)) % order.length;
      self.pick(order[n]);
      var f = box.querySelector('[data-to="' + order[n] + '"]'); if (f) f.focus();
    };
    this.ta.placeholder = this.skill ? 'What should ' + this.skill.title + ' do?'
      : (this.target === 'all' ? 'Ask the council: Claude, ChatGPT and Gemini' : 'Ask ' + NAMES[this.target] + ' — what should it accomplish?');
    this.go.setAttribute('aria-label', 'Send to ' + (this.target === 'all' ? 'the council' : NAMES[this.target]));
    this.drawRoute();
  };
  Composer.prototype.pick = function (k, quiet) {
    if (!NAMES[k]) return;
    var a = this.shadowRoot.activeElement, inChips = !!(a && this.chipsBox.contains(a));
    if (!this.available(k)) { this.say(this.offNote(k), true); return; }
    this.target = k;
    var m = this.modeOk(this.mode);
    if (!m.ok) { this.mode = (k === 'gemini') ? 'chat' : 'orchestrate'; if (!quiet) this.say(NAMES[k] + (k === 'gemini' ? ' is text only, so the mode is now Chat.' : ': the mode is now Orchestrate.')); }
    else if (!quiet) this.say('');
    this.drawChips(); this.drawModes(); this.drawPickers();
    var f = this.chipsBox.querySelector('[data-to="' + k + '"]');
    if (f && inChips) f.focus();   // the group was redrawn: keep the keyboard on the chosen chip
  };

  // ---- modes ------------------------------------------------------------------------------------------------
  Composer.prototype.modeOk = function (id) {
    var m = MODES.filter(function (x) { return x.id === id; })[0];
    if (this.target === 'gemini' && !this.gemChat && !GEMINI_MODES[id]) return {ok: false, why: 'Gemini answers in text only, so ' + m.label + ' needs Qosha, Claude or ChatGPT. With Gemini, use Chat or Review.'};
    if (this.target === 'all' && !ALL_MODES[id]) return {ok: false, why: 'All asks the council one question for one combined answer, so ' + m.label + ' needs one assistant: pick Qosha, Claude or ChatGPT.'};
    return {ok: true};
  };
  Composer.prototype.drawModes = function () {
    var self = this, box = this.modesBox;
    var a = this.shadowRoot && this.shadowRoot.activeElement, wasMore = !!(a && a === this.moreBtn), menuWasOpen = !!(this.menu && !this.menu.hidden);
    while (box.firstChild) box.removeChild(box.firstChild);
    var cur = MODES.filter(function (x) { return x.id === self.mode; })[0];
    var curHidden = MODES.indexOf(cur) >= VISIBLE_MODES;
    var radio = function (m, i) {
      var on = self.mode === m.id, ok = self.modeOk(m.id);
      // one tab stop: the chosen mode, or the first tab when the chosen one sits under More (More is its own stop)
      var stop = on ? !curHidden : (curHidden && i === 0);
      var b = el('button', {class: 'mode', type: 'button', role: 'radio', 'data-mode': m.id, 'aria-checked': on ? 'true' : 'false',
        tabindex: stop ? '0' : '-1', title: ok.ok ? m.tip : ok.why, 'aria-disabled': ok.ok ? null : 'true',
        'aria-label': m.label + ': ' + (ok.ok ? m.tip : ok.why), text: m.label});
      b.addEventListener('click', function () { self.setMode(m.id); if (i >= VISIBLE_MODES && self.mode === m.id) { self.menuOpen(false); self.moreBtn.focus(); } });
      return b;
    };
    MODES.slice(0, VISIBLE_MODES).forEach(function (m, i) { box.appendChild(radio(m, i)); });
    this.moreBtn = el('button', {class: 'morebtn' + (curHidden ? ' active' : ''), type: 'button', 'aria-haspopup': 'true', 'aria-expanded': menuWasOpen ? 'true' : 'false',
      'aria-controls': 'qc-more', 'aria-label': curHidden ? 'More modes (' + cur.label + ' chosen)' : 'More modes'}, [curHidden ? cur.label : 'More', svg(IC.down)]);
    this.moreBtn.addEventListener('click', function () { self.menuOpen(self.menu.hidden); if (!self.menu.hidden) { var f = self.menu.querySelector('[aria-checked=true]') || self.menu.querySelector('.mode'); if (f) f.focus(); } });
    this.menu = el('div', {class: 'menu', id: 'qc-more', hidden: !menuWasOpen}, MODES.slice(VISIBLE_MODES).map(function (m, j) { return radio(m, VISIBLE_MODES + j); }));
    box.appendChild(el('span', {class: 'more'}, [this.moreBtn, this.menu]));
    if (wasMore) this.moreBtn.focus();
    box.onkeydown = function (e) {
      if (['ArrowRight', 'ArrowDown', 'ArrowLeft', 'ArrowUp', 'Home', 'End'].indexOf(e.key) < 0) return;
      var t = self.shadowRoot.activeElement;
      if (!t || !t.getAttribute('data-mode')) return;   // the More button keeps its own keys
      e.preventDefault();
      var order = MODES.map(function (x) { return x.id; }).filter(function (id) { return self.modeOk(id).ok; });
      var i = order.indexOf(self.mode);
      var n = e.key === 'Home' ? 0 : e.key === 'End' ? order.length - 1 : (i + (e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : order.length - 1)) % order.length;
      var hidden = MODES.map(function (x) { return x.id; }).indexOf(order[n]) >= VISIBLE_MODES;
      self.setMode(order[n]);
      if (hidden) self.menuOpen(true);
      var f = box.querySelector('[data-mode="' + order[n] + '"]'); if (f) f.focus();
    };
    this.mnote.textContent = '';
    this.mnote.appendChild(el('b', {text: cur.label + ': '}));
    this.mnote.appendChild(document.createTextNode(cur.tip + ' Applies to the first message of a new chat.'));
    this.drawRoute();
  };
  Composer.prototype.setMode = function (id) {
    var ok = this.modeOk(id);
    if (!ok.ok) { this.say(ok.why, true); return; }
    var a = this.shadowRoot.activeElement, inModes = !!(a && this.modesBox.contains(a) && a !== this.moreBtn);
    this.mode = id; this.say(''); this.drawModes();
    var f = inModes && this.modesBox.querySelector('[data-mode="' + id + '"]'); if (f) f.focus();
  };
  // the route line under the card: who it goes to, in which mode, on which account
  Composer.prototype.drawRoute = function () {
    if (!this.det || !this.modesBox) return;
    var self = this, cur = MODES.filter(function (x) { return x.id === self.mode; })[0];
    var who = this.target === 'all' ? 'the council' : NAMES[this.target];
    this.det.textContent = '';
    this.det.appendChild(document.createTextNode('Sends to '));
    this.det.appendChild(el('b', {text: who + ' · ' + cur.label}));
    if (this.account) this.det.appendChild(document.createTextNode(' · Account: ' + this.account));
  };

  // ---- provider / model / effort ------------------------------------------------------------------------------
  Composer.prototype.provData = function (pid) {
    var ps = (window.qoshaBrain || {}).providers || [];
    return ps.filter(function (p) { return p.id === pid; })[0] || null;
  };
  Composer.prototype.pickFor = function (k) {   // Claude / ChatGPT chips: this browser's own choice, else the brain's defaults
    var pid = PROV[k], p = this.provData(pid), saved = this.picks[k] || {};
    if (!p) return null;
    var defs = ((window.qoshaBrain || {}).defaults || {})[pid] || {};
    var model = p.models.filter(function (m) { return m.id === saved.model; })[0] || p.models.filter(function (m) { return m.id === defs.model; })[0] || p.models[0];
    var ids = (model.efforts || []).map(function (e) { return e.id; });
    var effort = ids.indexOf(saved.effort) >= 0 ? saved.effort : ids.indexOf(defs.effort) >= 0 ? defs.effort : (ids.indexOf('medium') >= 0 ? 'medium' : ids[0]);
    return {model: model.id, effort: effort};
  };
  function sel(id, label, items, cur, onChange, disabled) {
    var s = el('select', {id: id, disabled: disabled || null});
    items.forEach(function (it) { var o = el('option', {value: it.id, text: it.label}); if (it.id === cur) o.selected = true; s.appendChild(o); });
    s.addEventListener('change', function () { onChange(s.value); });
    return el('div', {class: 'pk'}, [el('label', {for: id, text: label}), s]);
  }
  function fixed(label, text) { return el('div', {class: 'pk'}, [el('span', {class: 'k', text: label}), el('span', {class: 'v', text: text})]); }
  // effort as a segmented control (Home v2): a radio group with the model's own levels
  function effort(items, cur, onChange, disabled) {
    var g = el('div', {class: 'eff', id: 'qc-effort', role: 'radiogroup', 'aria-labelledby': 'qc-effort-k', 'data-value': cur});
    items.forEach(function (it) {
      var on = it.id === cur;
      var b = el('button', {type: 'button', role: 'radio', 'data-effort': it.id, 'aria-checked': on ? 'true' : 'false', tabindex: on ? '0' : '-1', disabled: disabled || null, text: it.label});
      b.addEventListener('click', function () { if (it.id !== g.getAttribute('data-value')) onChange(it.id); });
      g.appendChild(b);
    });
    g.onkeydown = function (e) {
      var keys = ['ArrowRight', 'ArrowDown', 'ArrowLeft', 'ArrowUp']; if (keys.indexOf(e.key) < 0 || disabled) return;
      e.preventDefault();
      var ids = items.map(function (x) { return x.id; }), i = ids.indexOf(g.getAttribute('data-value'));
      var n = (i + (e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : ids.length - 1)) % ids.length;
      onChange(ids[n]);
    };
    return el('div', {class: 'pk'}, [el('span', {class: 'k', id: 'qc-effort-k', text: 'Effort'}), g]);
  }
  function labelOf(list, id) { var x = (list || []).filter(function (y) { return y.id === id; })[0]; return x ? x.label : ''; }
  Composer.prototype.drawPickers = function () {
    var self = this, box = this.pickers, b = window.qoshaBrain || null, t = this.target;
    var act = this.shadowRoot && this.shadowRoot.activeElement;
    var focusId = act && act.tagName === 'SELECT' ? act.id : null;
    var focusEff = act && act.getAttribute && act.getAttribute('data-effort') ? true : false;
    while (box.firstChild) box.removeChild(box.firstChild);
    var signin = (b && b.signin) || {};
    var pill = '', account = '', note = '';
    if (t === 'all') {
      box.appendChild(fixed('Account', 'Each assistant’s own sign-in'));
      box.appendChild(fixed('Model', 'Each assistant’s own'));
      box.appendChild(fixed('Effort', 'Each assistant’s own'));
      pill = 'Each assistant’s own'; account = 'each assistant’s own'; note = 'All asks Claude, ChatGPT and Gemini the same brief, each on its own model, and gives you one combined answer.';
    } else if (t === 'gemini' && this.gemChat) {
      // Gemini as a chat model: its two models, no effort; the pick is remembered in this browser, as for Claude
      var gm = this.gemPick();
      box.appendChild(fixed('Account', signin.gemini || 'Gemini'));
      box.appendChild(sel('qc-model', 'Model', GEM_MODELS, gm, function (v) { self.picks.gemini = {model: v}; self.keep(); self.drawPickers(); }));
      pill = labelOf(GEM_MODELS, gm); account = signin.gemini || 'Gemini';
      note = 'Applies to the chats you start here with Gemini, remembered in this browser.';
    } else if (t === 'gemini') {
      box.appendChild(fixed('Account', signin.gemini || 'Gemini'));
      box.appendChild(fixed('Model', 'Gemini’s own default'));
      box.appendChild(fixed('Effort', 'Not offered for Gemini'));
      pill = 'Gemini · default'; account = signin.gemini || 'Gemini'; note = 'Gemini answers in text only, with its own default model.';
    } else if (!b || !b.providers) {
      box.appendChild(fixed('Model', b ? b.label : 'Loading…'));
      pill = b ? b.label : 'Loading…';
    } else if (t === 'qosha') {
      var provs = b.providers.map(function (p) { return {id: p.id, label: p.signin || p.name}; });
      var p = this.provData(b.provider);
      note = 'Qosha’s main assistant: a change here is saved for Qosha and every new chat.';
      if (!p) { box.appendChild(fixed('Model', b.label)); box.appendChild(sel('qc-prov', 'Account', [{id: '', label: 'Choose…'}].concat(provs), '', function (v) { self.saveBrain(v); }, this.saving)); pill = b.label; }
      else {
        var m = p.models.filter(function (x) { return x.id === b.model; })[0];
        box.appendChild(sel('qc-prov', 'Account', provs, b.provider, function (v) { self.saveBrain(v); }, this.saving));
        box.appendChild(sel('qc-model', 'Model', p.models.map(function (x) { return {id: x.id, label: x.label}; }), b.model, function (v) { self.saveBrain(b.provider, v); }, this.saving));
        var efs = (m && m.efforts) || [];
        if (efs.length) box.appendChild(effort(efs, b.effort, function (v) { self.saveBrain(b.provider, b.model, v); }, this.saving));
        else box.appendChild(fixed('Effort', 'Not available for this model'));
        pill = (m ? m.label : b.label) + (efs.length && labelOf(efs, b.effort) ? ' · ' + labelOf(efs, b.effort) : '');
        account = p.signin || p.name;
      }
    } else {
      var pid = PROV[t], pd = this.provData(pid), pk = this.pickFor(t);
      if (!this.available(t) || !pd || !pk) {
        box.appendChild(fixed('Account', t === 'chatgpt' ? 'ChatGPT · not signed in' : (signin[pid] || NAMES[t])));
        pill = t === 'chatgpt' ? 'Not signed in' : NAMES[t]; account = t === 'chatgpt' ? 'not signed in' : (signin[pid] || NAMES[t]);
      } else {
        box.appendChild(fixed('Account', pd.signin || signin[pid] || NAMES[t]));
        var mm = pd.models.filter(function (x) { return x.id === pk.model; })[0];
        box.appendChild(sel('qc-model', 'Model', pd.models.map(function (x) { return {id: x.id, label: x.label}; }), pk.model, function (v) {
          self.picks[t] = {model: v, effort: pk.effort}; self.keep(); self.drawPickers(); }));
        if ((mm.efforts || []).length) box.appendChild(effort(mm.efforts, pk.effort, function (v) {
          self.picks[t] = {model: pk.model, effort: v}; self.keep(); self.drawPickers(); }));
        pill = mm.label + ((mm.efforts || []).length && labelOf(mm.efforts, pk.effort) ? ' · ' + labelOf(mm.efforts, pk.effort) : '');
        account = pd.signin || signin[pid] || NAMES[t];
        note = 'Applies to the chats you start here with ' + NAMES[t] + ', remembered in this browser.';
      }
    }
    this.pillText.textContent = pill;
    this.pill.setAttribute('aria-label', 'Model settings: ' + pill + (account ? ', account ' + account : ''));
    this.popNote.textContent = note; this.popNote.hidden = !note;
    this.account = account; this.drawRoute();
    if (focusId) { var f = this.shadowRoot.getElementById(focusId); if (f) f.focus(); }
    else if (focusEff) { var g = this.shadowRoot.querySelector('#qc-effort [aria-checked=true]'); if (g) g.focus(); }
  };
  Composer.prototype.keep = function () { try { window.localStorage.setItem(STORE, JSON.stringify(this.picks)); } catch (e) { /* not remembered */ } };
  // Qosha chip: the main brain itself (POST /brain, the same setting the old dialog saved)
  Composer.prototype.saveBrain = function (provider, model, effort) {
    var self = this, b = window.qoshaBrain || {}, p = this.provData(provider);
    if (!p || !p.models.length || this.saving || !window.qoshaBrainPicker) return;
    var defs = (b.defaults || {})[provider] || {};
    var m = p.models.filter(function (x) { return x.id === model; })[0] || p.models.filter(function (x) { return x.id === defs.model; })[0] || p.models[0];
    var ids = (m.efforts || []).map(function (e) { return e.id; });
    if (!ids.length) { this.say('This model can’t be chosen right now: its effort levels could not be read.', true); this.drawPickers(); return; }
    var ef = ids.indexOf(effort) >= 0 ? effort : ids.indexOf(b.effort) >= 0 ? b.effort : ids.indexOf('medium') >= 0 ? 'medium' : ids[0];
    this.saving = true; this.drawPickers(); this.say('Saving the main assistant…');
    window.qoshaBrainPicker.save(provider, m.id, ef).then(function (d) {
      self.say('Saved. Qosha and new chats use ' + d.label + '.');
    }, function (e) { self.say(e.message + ' Nothing was changed.', true); }).then(function () { self.saving = false; self.drawPickers(); self.drawChips(); });
  };

  // ---- attach ----------------------------------------------------------------------------------------------
  Composer.prototype.drawFiles = function () {
    var self = this, box = this.filesBox;
    while (box.firstChild) box.removeChild(box.firstChild);
    this.files.forEach(function (f, i) {
      var label = f.state === 'up' ? f.name + ' (saving…)' : f.state === 'bad' ? f.name + ': ' + f.err : f.name;
      box.appendChild(el('div', {class: 'fchip' + (f.state === 'bad' ? ' bad' : ''), role: 'listitem'}, [svg(IC.file), el('span', {text: label, title: label}),
        el('button', {type: 'button', 'aria-label': 'Remove ' + f.name, on: {click: function () { self.files.splice(i, 1); self.drawFiles(); self.ta.focus(); }}}, [svg(IC.x)])]));
    });
  };
  Composer.prototype.attach = function (list) {
    var self = this;
    if (!list.length) return;
    if (this.files.length + list.length > 10) { this.say('Up to 10 files per message.', true); return; }
    var stamp = new Date(), pad = function (n) { return (n < 10 ? '0' : '') + n; };
    var pre = stamp.getFullYear() + '-' + pad(stamp.getMonth() + 1) + '-' + pad(stamp.getDate()) + ' ' + pad(stamp.getHours()) + pad(stamp.getMinutes()) + pad(stamp.getSeconds()) + ' ';
    var items = list.map(function (file) {
      var clean = String(file.name || 'file').replace(/[\/\\\x00-\x1f]/g, '-').replace(/^\.+/, '').slice(-120) || 'file';
      var it = {name: clean, state: 'up', path: '', file: file}; self.files.push(it); return it;
    });
    this.drawFiles(); this.say('Saving ' + items.length + (items.length > 1 ? ' files' : ' file') + ' in the Qosha files folder…');
    var base = '/api/plugins/qosha/files';
    var folder = call('GET', base + '/list').then(function (r) {
      var dir = String(r.root || '') + '/Attachments';
      return call('POST', base + '/mkdir', {path: dir}).then(function () { return dir; }, function (e) { if (e.status === 409) return dir; throw e; });
    });
    Promise.all(items.map(function (it) {
      return folder.then(function (dir) {
        var fd = new FormData(); fd.append('file', it.file, it.name); fd.append('path', dir + '/' + pre + it.name); fd.append('overwrite', 'false');
        return call('POST', base + '/upload', null, fd).then(function (r) { it.path = String(r.path || ''); it.state = 'ok'; });
      }).catch(function (e) { it.state = 'bad'; it.err = e.message || 'not saved'; }).then(function () { delete it.file; self.drawFiles(); });
    })).then(function () {
      var bad = items.filter(function (x) { return x.state === 'bad'; }).length;
      self.say(bad ? 'Some files could not be saved; remove them or try again.' : 'Attached. They go with your message to the new chat.', !!bad);
    });
  };

  // ---- Talk: live voice chat in a new chat, with the assistant, model and effort picked here --------------------
  // Nothing is sent from here: the chat page starts live voice chat (qosha-live.js), and every rule of its Live button
  // holds there. A typed draft stays in this box.
  Composer.prototype.talkLive = function () {
    var self = this, comp = window.comp, t = this.target;
    if (this.vox && this.vox.recording()) { this.say('Stop the recording first (press the microphone again).', true); return; }
    if (!comp || this.sending) return;
    if (t === 'all') { this.say('Voice chat talks with one assistant: pick Qosha, Claude, ChatGPT or Gemini.', true); return; }
    if (this.saving) { this.say('One moment: the main assistant is being saved.', true); return; }
    if (!this.available(t)) { this.say(this.offNote(t), true); return; }
    var extra = {live: true};
    if (PROV[t]) { var pk = this.pickFor(t); if (pk) { extra.model = pk.model; extra.effort = pk.effort; } }
    if (t === 'gemini' && this.gemChat) extra.model = this.gemPick();
    if (t !== 'qosha') { comp.askInChat('', t, extra); return; }
    this.sending = true;   // the same status read as Send: a signed-out ChatGPT main assistant is caught here
    Promise.resolve(comp.brainReady ? comp.brainReady() : null).then(function () {
      var b = window.qoshaBrain;
      if (b && b.provider === 'openai-codex' && !self.ok.chatgpt) { self.say(self.offNote('qosha'), true); return; }
      comp.askInChat('', '', extra);
    }).then(function () { self.sending = false; }, function () { self.sending = false; });
  };

  // ---- send ------------------------------------------------------------------------------------------------
  Composer.prototype.send = function (opts) {
    var self = this, comp = window.comp;
    // the message's leading whitespace is kept (an indented code sample stays one; GPT R8 #2); only the end is trimmed
    var text = this.ta.value.replace(/\s+$/, ''), voice = !!(opts && opts.voice);
    if (this.vox && this.vox.recording() && !voice) { this.say('Stop the recording first (press the microphone again).', true); return; }
    if (!comp || this.sending) return;
    if (this.saving) { this.say('One moment: the main assistant is being saved.', true); return; }
    if (!text.trim()) {
      if (this.files.length) { this.say('Write what Qosha should do with the attached files, then send.', true); return; }
      comp.openCommand && comp.openCommand('');   // an empty box still opens search / jump, as before
      return;
    }
    if (this.files.some(function (f) { return f.state === 'up'; })) { this.say('One moment: the files are still being saved.', true); return; }
    if (this.files.some(function (f) { return f.state === 'bad'; })) { this.say('Remove the files that could not be saved, then send.', true); return; }
    var t = this.target, m = this.modeOk(this.mode);
    if (!m.ok) { this.say(m.why, true); return; }
    if (!this.available(t)) { this.say(this.offNote(t), true); return; }
    var files = this.files.map(function (f) { return {name: f.name, path: f.path}; });
    var gemText = t === 'gemini' && !this.gemChat;   // Gemini as a chat model takes skills and files like Claude
    if (this.skill && (gemText || t === 'all')) { this.say((t === 'gemini' ? 'Gemini' : 'All 3') + ' can’t use skills. Pick Qosha, Claude or ChatGPT, or remove the skill.', true); return; }
    if (files.length && (gemText || t === 'all')) { this.say((t === 'gemini' ? 'Gemini' : 'All 3') + ' takes text only, so attached files can’t go with it. Pick Qosha, Claude or ChatGPT, or remove the files.', true); return; }
    var clear = function () { self.ta.value = ''; self.grow(); self.files = []; self.drawFiles(); self.skill = null; self.drawSkill(); self.say(''); };
    // the chat takes up to 60,000 characters from here; longer is refused here and stays in the box, never cut (GPT R17 #3)
    if (text.length > 60000) { this.say('This is too long to send from here (over 60,000 characters). Shorten it, or paste it in the chat.', true); return; }
    if (t === 'all') {
      // P0 council (8 Nov): All asks Claude, ChatGPT and Gemini the same brief on the server and posts ONE combined
      // answer in a Qosha chat (saved), instead of three side-by-side answers; the mode (Review) goes with it
      if (comp.askInChat(text, 'all', {mode: this.mode}) !== false) clear();   // cleared only once handed over (GPT R19 #3)
      return;
    }
    var extra = {mode: this.mode, voice: voice || undefined, files: files.length ? files : undefined,
                 skill: this.skill ? this.skill.slug : undefined, skillTitle: this.skill ? this.skill.title : undefined};
    if (t === 'qosha') {
      // U-E1: the Qosha chat with the question sent to the main assistant; the chat reads the setting itself (the
      // engine's own main model when it can't). Home waits for the status read first, so a ChatGPT main assistant that is
      // signed out is caught here and nothing goes to another assistant by mistake.
      this.sending = true;   // one hand-off at a time (GPT R-composer1: two Enters while the status read is slow)
      Promise.resolve(comp.brainReady ? comp.brainReady() : null).then(function () {
        var b = window.qoshaBrain;
        if (b && b.provider === 'openai-codex' && !self.ok.chatgpt) { self.say(self.offNote('qosha'), true); return; }
        if (comp.askInChat(text, '', extra) !== false) clear();
      }).then(function () { self.sending = false; }, function () { self.sending = false; });
      return;
    }
    if (PROV[t]) { var pk = this.pickFor(t); if (pk) { extra.model = pk.model; extra.effort = pk.effort; } }
    if (t === 'gemini' && this.gemChat) extra.model = this.gemPick();   // the same hand-off as Claude and ChatGPT, no effort
    if (comp.askInChat(text, t, extra) !== false) clear();
  };

  customElements.define('qosha-composer', Composer);
})();
