"""Skills and Connections for the Qosha side panel (night job 3, 2 Nov). Mounted at /api/plugins/qosha/.

GET  /skills                         {"skills": [{slug,title,plain,when,category,area,source,licence,new,companions,
                                     library}], "changes": [{date,text}], "updated"}: the Qosha skill library (its
                                     SKILLS-MANIFEST.json under <home>/skills/qosha-library; a skill with a lab_path sits
                                     at the engine's own path) and the engine's own skills. Only skills the assistant can
                                     use are listed; there is no on/off (founder decision, 3 Nov 08:03: every skill listed
                                     is installed and ready). source: "qosha" (Qosha original) | "open" (open source) |
                                     "local" (added on this computer, licence not known) | "mine" (made by the person:
                                     approved in Decisions waiting, skills/made-by-you);
                                     new: added in the library's latest update (within 30 days); when: the skill's own
                                     one-line "when to use it" (SKILL.md description)
GET  /connections                    {"connections": [{name,label,what,held,needs_account,kind,status,detail,category,
                                     builtin,reads,account,last_used,waiting}], "summary": {connected,needs_sign_in,
                                     waiting}}: the catalogue next to the guard (plugin/qosha_guard/mcp_catalog.json;
                                     missing → 503) and the engine's mcp_servers entries; status ready | needs_sign_in |
                                     off | error. Connections tab (3 Nov): reads = what runs without an Approve (plain
                                     words); last_used = the newest call to one of the app's tools in the engine's
                                     session store (read-only); waiting = its actions in Decisions waiting; Google mail
                                     and calendar = the Qosha connector's own status (signed in, account; never a token)
POST /connections/{name}/connect     local app: switched on. App with its own sign-in: starts the engine's own sign-in
                                     (OAuth) and answers {"flow_id","authorization_url"} for the person's browser; the
                                     app is switched on only once the sign-in has finished (GET flows/{id})
GET  /connections/flows/{flow_id}    {"status": "pending|approved|error", "connected": bool}
POST /connections/{name}/disconnect  removes the stored sign-in (the engine's helper; its contents are never read) and
                                     switches the app off

Every answer is JSON with plain words; the engine's own names never reach the page. Changes to apps take effect in the
next chat (the engine reads mcp_servers when a session starts).
"""
from __future__ import annotations

import importlib.util
import json
import re
import sqlite3
import sys
import threading
import time
import urllib.request
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path

from fastapi import APIRouter, Body, Request
from fastapi.responses import JSONResponse

router = APIRouter()
_LOCK = threading.RLock()
LIBRARY = "qosha-library"
SLUG_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}$")
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")
FLOW_RE = re.compile(r"^[A-Za-z0-9_-]{8,128}$")
_BRAND = [(re.compile(r"hermes agent", re.I), "Qosha"), (re.compile(r"nous research", re.I), "Qosha AI"),
          (re.compile(r"\bhermes\b", re.I), "Qosha")]
# the engine's own skills about itself are not listed (they can't be switched off and talk about the engine)
_HIDDEN = re.compile(r"hermes|nous", re.I)
_flows = {}   # flow_id -> (server name, Disconnect count when it started), for flows this page started
_dis = {}     # server name -> how many Disconnects: only a Disconnect makes an open sign-in invalid (GPT R-skillsmcp5 #1)
_gen = {}     # server name -> generation: Disconnect moves it on, so an older sign-in can never switch the app back on
_off_gen = {}  # server name -> the generation its last Disconnect set (cleanup runs only while that is still current)
_tentative = {}  # server name -> Connects waiting for the engine to start a sign-in: cleanup pauses meanwhile
_started = {}    # server name -> generation of the newest Connect whose sign-in started: only that retires a cleanup
SWEEP_SECONDS = 330.0   # the engine's sign-in waits up to 300 s for the browser; a late token is removed until then
SWEEP_POLL = 2.0


def _engine_flow(flow_id: str):
    """The engine's own record of a sign-in in progress (has .worker_done and .mark_error), or None."""
    try:
        from hermes_cli import web_server
        return web_server._mcp_oauth_flows.get(flow_id)
    except Exception:
        return None


def _sweep(name: str, gen: int, flow_ids: list, home: Path):
    """After a Disconnect: wait for the cancelled sign-ins to stop, then remove any sign-in one of them stored late.
    Paused while a Connect waits for the engine; it resumes if that Connect is refused, and it stops for good only
    once a newer Connect's sign-in has started (GPT R-touchups2 #3), or after a removal made once the cancelled
    sign-ins had stopped (R-final6 #1: never while paused)."""
    import time
    from tools.mcp_oauth import remove_oauth_tokens
    deadline = time.monotonic() + SWEEP_SECONDS
    while True:
        flows = [f for f in (_engine_flow(i) for i in flow_ids) if f is not None]
        done = all(getattr(f, "worker_done", True) for f in flows)
        with _LOCK:
            if _started.get(name, 0) > gen:
                return                               # a newer Connect's sign-in owns the app now
            paused = bool(_tentative.get(name))
            if not paused:
                remove_oauth_tokens(name, hermes_home=home)
        now = time.monotonic()
        if (not paused and (done or now >= deadline)) or now >= deadline + SWEEP_SECONDS:
            return
        time.sleep(SWEEP_POLL)


class Problem(Exception):
    def __init__(self, status, error, detail):
        super().__init__(detail)
        self.status, self.error, self.detail = status, error, detail


def _answer(fn):
    @wraps(fn)
    def handle(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Problem as exc:
            return JSONResponse(status_code=exc.status, content={"error": exc.error, "detail": exc.detail})
        except Exception as exc:   # never the engine's own text: it can carry internal names and paths
            return JSONResponse(status_code=503, content={"error": "unavailable",
                                                          "detail": "Qosha could not do that right now (%s). Try again." % type(exc).__name__})
    return handle


def _home() -> Path:
    from hermes_constants import get_hermes_home
    return Path(get_hermes_home())


def _plain(text) -> str:
    text = str(text or "")
    for rx, sub in _BRAND:
        text = rx.sub(sub, text)
    return text.strip()


# --- The engine's sign-in return page (night job 5, SKILLS-MCP-DONE blocker 3, option a). After signing in to an app,
# the person's browser lands on the engine's /api/mcp/oauth/callback/<app> (hermes_cli/web_routers/mcp.py), whose
# small HTML pages name the upstream. Only that route's handler is wrapped, on the engine's own app, when the dashboard
# loads this plugin: text/html answers get the _BRAND words replaced and Content-Length fixed. The OAuth handling,
# status codes, other headers and every other route are untouched; anything not text/html passes through as is.
CALLBACK_PATH = "/api/mcp/oauth/callback/{server_name:path}"
_SIGNIN_MAX = 256 * 1024                               # a bigger page passes through unchanged
# only the words a person reads: text between tags; tags, attributes, scripts and styles keep their bytes (GPT R-touchups1)
_HTML_SPLIT = re.compile(r"(<script\b[\s\S]*?</script\s*>|<style\b[\s\S]*?</style\s*>|<!--[\s\S]*?-->|<[^>]*>)", re.I)


def _rebrand_html(text: str) -> str:
    parts = _HTML_SPLIT.split(text)
    for i in range(0, len(parts), 2):                  # even items are text between tags
        for rx, sub in _BRAND:
            parts[i] = rx.sub(sub, parts[i])
    return "".join(parts)                              # <title>…</title>: its words are text between tags


def _rebrand_asgi(inner):
    async def signin_page(scope, receive, send):
        if scope.get("type") != "http":
            return await inner(scope, receive, send)
        held = {"start": None, "chunks": []}

        async def relay(message):
            kind = message.get("type")
            if kind == "http.response.start":
                ctype = next((v for k, v in message.get("headers", []) if k.lower() == b"content-type"), b"")
                if ctype.lower().startswith(b"text/html"):
                    held["start"], held["ctype"] = message, ctype   # hold it until the whole body is here
                    return
            elif kind == "http.response.body" and held["start"] is not None:
                held["chunks"].append(message.get("body", b""))
                held["size"] = held.get("size", 0) + len(message.get("body", b""))
                if held["size"] > _SIGNIN_MAX:             # not one of the engine's small pages: pass it on as is
                    start, held["start"] = held["start"], None
                    await send(start)
                    chunks, held["chunks"] = held["chunks"], []
                    return await send({"type": "http.response.body", "body": b"".join(chunks),
                                       "more_body": bool(message.get("more_body"))})
                if message.get("more_body"):
                    return
                start, body = held["start"], b"".join(held["chunks"])
                held["start"] = None
                try:
                    m = re.search(rb"charset=([A-Za-z0-9_.:-]+)", held["ctype"], re.I)
                    charset = m.group(1).decode("ascii") if m else "utf-8"
                    new = _rebrand_html(body.decode(charset)).encode(charset)
                except Exception:
                    new = body                         # can't read it: send the engine's bytes unchanged
                headers = [(k, str(len(new)).encode("latin-1") if k.lower() == b"content-length" else v)
                           for k, v in start["headers"]]
                await send(dict(start, headers=headers))
                return await send({"type": "http.response.body", "body": new, "more_body": False})
            await send(message)

        return await inner(scope, receive, relay)
    signin_page._qosha_signin_page = True
    return signin_page


def install_signin_page(app) -> int:
    """Wrap the engine's callback route(s) on app; returns how many were wrapped now (0 if already done)."""
    done = 0
    for route in list(getattr(getattr(app, "router", None), "routes", None) or []):
        if getattr(route, "path", None) != CALLBACK_PATH or not hasattr(route, "app"):
            continue
        if getattr(route.app, "_qosha_signin_page", False):
            continue
        route.app = _rebrand_asgi(route.app)
        done += 1
    return done


def _install_on_engine():
    # The dashboard imports this plugin while hermes_cli.web_server is loading (its app and the MCP routes already
    # exist); outside the dashboard (tests that load this file alone) there is no engine app and nothing happens.
    import sys
    app = getattr(sys.modules.get("hermes_cli.web_server"), "app", None)
    if app is not None:
        try:
            install_signin_page(app)
        except Exception:
            pass                                       # never break the plugin's own routes over a page's wording


_install_on_engine()


def _config():
    from hermes_cli.config import load_config
    return load_config()


def _save(cfg):
    from hermes_cli.config import save_config
    save_config(cfg)


# ------------------------------------------------------------------------------------------------------------ skills
def _manifest_doc() -> dict:
    path = _home() / "skills" / LIBRARY / "SKILLS-MANIFEST.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _manifest(doc=None):
    doc = _manifest_doc() if doc is None else doc
    skills = doc.get("skills")
    return [s for s in skills if isinstance(s, dict) and isinstance(s.get("slug"), str)] if isinstance(skills, list) else []


DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
AREAS = ("money", "sales", "marketing", "people", "operations")
# the engine's skill folders under the library's own words for a kind of skill (Skills tab, 3 Nov)
ENGINE_KINDS = {"productivity": "Work", "note-taking": "Work", "apple": "Work", "software-development": "Developer",
                "autonomous-ai-agents": "Developer", "devops": "Developer", "creative": "Design", "media": "Video",
                "research": "Research", "web": "Research", "email": "Email", "social-media": "Marketing"}


def _newest(doc) -> str:
    """The date of the library's latest update, if it is recent: skills added that day are "new"."""
    import datetime as dt
    days = []
    for d in (s.get("added") for s in _manifest(doc)):
        if not (isinstance(d, str) and DATE_RE.match(d)):
            continue
        try:
            days.append(dt.date.fromisoformat(d))
        except ValueError:
            pass                                        # one bad date never hides the others (GPT R-skillstab1 #7)
    newest = max((d for d in days if d <= dt.date.today()), default=None)
    return newest.isoformat() if newest and (dt.date.today() - newest).days <= 30 else ""


def _changes(doc) -> list:
    out, changes = [], doc.get("changes")
    for c in changes if isinstance(changes, list) else []:
        if isinstance(c, dict) and isinstance(c.get("date"), str) and DATE_RE.match(c["date"]) and isinstance(c.get("text"), str):
            out.append({"date": c["date"], "text": _plain(c["text"])[:300]})
    return sorted(out, key=lambda c: c["date"], reverse=True)[:10]


def _disabled() -> set:
    """Skills switched off in config.yaml (skills.disabled): not usable, so not listed."""
    try:
        from hermes_cli.skills_config import get_disabled_skills
        return set(get_disabled_skills(_config()))
    except Exception:
        return set()


def _bundled() -> set:
    """The skills that came with the engine: its own record, <home>/skills/.bundled_manifest ("name:hash" per line)."""
    try:
        lines = (_home() / "skills" / ".bundled_manifest").read_text(encoding="utf-8").splitlines()
    except OSError:
        return set()
    return {ln.split(":", 1)[0].strip() for ln in lines if ln.strip()}


def _frontmatter(folder: Path):
    """(name, description) from a skill's SKILL.md, read with the engine's own parser so the name is the one the engine
    knows it by (else the folder name: GPT R-skillstab2) and the description (when to use it) is on one line; ("", "")
    when there is no SKILL.md."""
    try:
        text = (folder / "SKILL.md").read_text(encoding="utf-8")
    except OSError:
        return "", ""
    try:
        from agent.skill_utils import parse_frontmatter
        meta = parse_frontmatter(text)[0]
    except Exception:
        meta = {}
    name = meta.get("name") if isinstance(meta.get("name"), str) and meta.get("name").strip() else folder.name
    desc = meta.get("description")
    return str(name).strip()[:64], " ".join(desc.split())[:300] if isinstance(desc, str) else ""


def _library():
    """The library's skills: the manifest's words; skills in the folder but missing from it are listed plainly."""
    root = _home() / "skills" / LIBRARY
    doc = _manifest_doc()
    newest = _newest(doc)
    off = _disabled()
    out, seen = [], set()
    for s in _manifest(doc):
        lab_path = str(s.get("lab_path") or "")
        if lab_path and re.fullmatch(r"[a-z0-9-]+/[a-z0-9-]+", lab_path) and lab_path.split("/")[1] == s["slug"]:
            folder = _home() / "skills" / lab_path      # rebranded engine skill, kept at the engine's own path
        else:
            folder = root / Path(str(s.get("folder") or s["slug"])).name
        if not (folder / "SKILL.md").is_file():
            continue
        name, when = _frontmatter(folder)
        name = name or s["slug"]
        seen.add(folder.name)
        if name in off:
            continue                                    # switched off in config.yaml by hand: the assistant can't use it
        area = str(s.get("area") or "").lower()
        comp = s.get("companion_of")
        comp = [c for c in (comp if isinstance(comp, list) else [comp]) if isinstance(c, str) and NAME_RE.match(c)][:5]
        out.append({"slug": name, "title": _plain(s.get("title") or name), "plain": _plain(s.get("plain")), "when": _plain(when),
                    "category": _plain(s.get("category") or "Other"), "area": area if area in AREAS else "",
                    "source": "qosha" if str(s.get("licence") or "") == "Qosha" else "open",
                    "licence": _plain(s.get("licence_text") or s.get("licence")),
                    "new": bool(newest) and s.get("added") == newest,
                    "companions": comp, "library": True})
    if root.is_dir():
        for folder in sorted(root.iterdir()):
            if folder.name in seen or not (folder / "SKILL.md").is_file():
                continue
            name, when = _frontmatter(folder)
            if name in off:
                continue
            out.append({"slug": name, "title": name, "plain": _plain(when), "when": _plain(when), "category": "Other", "area": "",
                        "source": "open", "licence": "", "new": False, "companions": [], "library": True})
    return out


def _engine_skills():
    try:
        import tools.skills_tool as _st   # find_all_skills from v0.22, _find_all_skills before
        found = (getattr(_st, "find_all_skills", None) or getattr(_st, "_find_all_skills"))()   # only usable skills
    except Exception:
        return []
    bundled = _bundled()
    out = []
    for s in found:
        name = str(s.get("name") or "")
        if not name or _HIDDEN.search(name) or str(s.get("category") or "") == LIBRARY:
            continue
        folder = str(s.get("category") or "").split("/")[0]
        cat = ENGINE_KINDS.get(folder) or folder.replace("-", " ").strip().capitalize() or "Other"
        desc = _plain(s.get("description"))[:400]
        # a skill that came with the engine (its own record of them) is open source under the engine's MIT licence; any
        # other skill was added on this computer and its licence is not known (GPT R-skillstab1 #5)
        shipped = name in bundled
        # saved by the person through Decisions waiting (skill.save): skills/made-by-you/<name>
        mine = folder == "made-by-you" and not shipped
        out.append({"slug": name, "title": name.replace("-", " ").capitalize(), "plain": desc, "when": desc,
                    "category": "Made by you" if mine else _plain(cat), "area": "",
                    "source": "mine" if mine else ("open" if shipped else "local"),
                    "licence": "MIT" if shipped else "", "new": False, "companions": [], "library": False})
    return out


def _all_skills():
    out, seen = [], set()
    for s in _library() + _engine_skills():
        if s["slug"] in seen or not SLUG_RE.match(s["slug"]):
            continue
        seen.add(s["slug"])
        out.append(s)
    return out


@router.get("/skills")
@_answer
def skills():
    items = _all_skills()
    items.sort(key=lambda s: (not s["library"], s["category"].lower(), s["title"].lower()))
    doc = _manifest_doc()
    updated = doc.get("updated") if isinstance(doc.get("updated"), str) and DATE_RE.match(doc["updated"]) else ""
    return {"skills": items, "changes": _changes(doc), "updated": updated}


# ------------------------------------------------------------------------------------------------------- connections
CATALOG = Path(__file__).resolve().parents[1] / "qosha_guard" / "mcp_catalog.json"


def _catalog():
    """The app catalogue that ships next to the approval guard (plugin/qosha_guard/mcp_catalog.json): the same file the
    guard decides from. Missing or unreadable: a plain error, never an empty or guessed list (fails closed)."""
    try:
        data = json.loads(CATALOG.read_text(encoding="utf-8"))
        servers = data.get("servers")
        if not isinstance(servers, list):
            raise ValueError("no servers")
    except (OSError, ValueError, AttributeError):
        raise Problem(503, "no_catalog", "Qosha's list of apps is missing or damaged on this computer. Reinstall Qosha's apps.")
    return [s for s in servers if isinstance(s, dict) and isinstance(s.get("name"), str) and NAME_RE.match(s["name"])]


def _has_signin(name: str) -> bool:
    """Whether a sign-in is stored for this app: the file's existence only, its contents are never read."""
    try:
        return _signin_path(name).is_file()
    except Exception:
        return False


def _signin_path(name: str) -> Path:
    from tools.mcp_oauth import HermesTokenStorage
    return HermesTokenStorage(name, hermes_home=_home())._tokens_path()


def _signed_in_at(name: str):
    """When this app's sign-in was last saved: the file's time only (its contents are never read); None if there is none."""
    try:
        path = _signin_path(name)
        return datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).astimezone().date() if path.is_file() else None
    except Exception:
        return None


def _oauth(entry: dict) -> bool:
    return isinstance(entry, dict) and bool(entry.get("url")) and entry.get("auth") == "oauth"


def _status(server: dict, entry, google=None):
    if not isinstance(entry, dict):
        return ("error", "This app is not set up on this computer. Reinstall Qosha's apps.") if entry is not None else \
               ("off", "Not set up on this computer.")
    enabled = entry.get("enabled", True) is not False
    if server.get("needs_account"):
        if not _oauth(entry):
            return ("needs_sign_in", "Signs in with a key from your own account. Not available here yet.") if not enabled else ("ready", "")
        if not _has_signin(server["name"]):
            return ("needs_sign_in", "Connect it with your own account.")
        return ("ready", "") if enabled else ("off", "Signed in, switched off.")
    if server.get("google_connector") and enabled and google is not None:
        if not google.get("reachable"):
            return ("error", "Qosha's connector on this computer is not answering, so Google can't be reached right now.")
        if not google.get("signed_in"):
            return ("needs_sign_in", "Google is not signed in on this computer yet.")
    return ("ready", "") if enabled else ("off", "Switched off.")


# Connections tab (founder, 3 Nov 17:52): categories with counts on the page; anything else lands in "Other"
CATEGORIES = ("Your files and Google", "Money", "Sales", "Marketing", "Work tools", "Developer")


def _reads(server: dict):
    """The app's tools that run without an Approve, in plain words ("read file"); [] when every action waits."""
    tools = server.get("read_tools")
    if not isinstance(tools, list):
        return []
    return [_plain(re.sub(r"[_-]+", " ", t)).lower() for t in tools if isinstance(t, str) and NAME_RE.match(t)][:40]


def _account(server: dict, google=None) -> str:
    if server.get("google_connector"):
        if google and google.get("signed_in") and google.get("account"):
            return "Your Google account %s, held by Qosha's connector on this computer (Qosha's chats never see the sign-in)." % _plain(google["account"])
        return "Your Google account, once it is signed in through Qosha's connector on this computer."
    if server.get("needs_account"):
        name = _plain(server.get("label") or server["name"]).replace(" (optional)", "")
        when = _signed_in_at(server["name"])
        if when is not None:
            # which login it is would mean reading the sign-in itself, which Qosha never does (GPT R-conntab1 #3)
            # the file's date is when the sign-in was last saved (a refresh saves it too), not necessarily a new login
            return "Your own %s account, connected on %s's own page (sign-in last saved %s). Qosha does not read the sign-in, so it can't show which login it is; check in %s." % (
                name, name, "%d %s %d" % (when.day, when.strftime("%b"), when.year), name)
        return "Your own %s account. You sign in on %s's own page, and each person connects their own." % (name, name)
    if server.get("files_folder_only"):
        return "No account: it works only inside your Qosha files folder on this computer."
    return "No account: it runs on this computer."


_GOOGLE = {"at": 0.0, "value": None}
_GOOGLE_LOCK = threading.Lock()
GOOGLE_SECONDS = 30.0


def _google_status():
    """Google's sign-in as the Qosha connector reports it (GET /v1/status: connected and account only, never a token).
    The call carries the dashboard's own connector key, as every Google read from this dashboard does (connector_client);
    the key never leaves this process. One read at a time, kept GOOGLE_SECONDS. Not answering: reachable False."""
    with _GOOGLE_LOCK:
        if _GOOGLE["value"] is not None and time.monotonic() - _GOOGLE["at"] < GOOGLE_SECONDS:
            return dict(_GOOGLE["value"])
        value = _google_status_now()
        _GOOGLE.update(at=time.monotonic(), value=value)
        return dict(value)


def _google_status_now():
    try:
        mod = sys.modules.get("qosha_assistants_connector_client")
        if mod is None:
            spec = importlib.util.spec_from_file_location("qosha_assistants_connector_client", CATALOG.parent / "connector_client.py")
            mod = importlib.util.module_from_spec(spec)
            sys.modules["qosha_assistants_connector_client"] = mod
            spec.loader.exec_module(mod)
        req = urllib.request.Request(mod.URL + "/v1/status", headers=mod._request_headers())
        with urllib.request.urlopen(req, timeout=10) as r:
            st = json.loads(r.read())
        return {"reachable": True, "signed_in": bool(st.get("connected")), "account": str(st.get("account") or "")}
    except Exception:
        return {"reachable": False, "signed_in": False, "account": ""}


def _last_used(home: Path) -> dict:
    """server name -> ISO time of its newest tool call, from the engine's session store (opened read-only; the
    engine names an app's tools mcp__<server>__<tool>). Unreadable: {} (the page says "Not used yet")."""
    out = {}
    db = home / "state.db"
    if not db.is_file():
        return out
    try:
        conn = sqlite3.connect("file:%s?mode=ro" % db.as_posix(), uri=True, timeout=1)
        try:
            rows = conn.execute("SELECT tool_name, MAX(timestamp) FROM messages WHERE tool_name LIKE 'mcp\\_\\_%' ESCAPE '\\' "
                                "GROUP BY tool_name").fetchall()
        finally:
            conn.close()
    except Exception:
        return out
    for name, ts in rows:
        server = str(name or "")[5:].split("__", 1)[0]
        try:
            ts = float(ts)
        except (TypeError, ValueError):
            continue
        if server and ts > out.get(server, 0):
            out[server] = ts
    return {k: datetime.fromtimestamp(v, timezone.utc).astimezone().isoformat(timespec="seconds") for k, v in out.items()}


GOOGLE_KINDS = ("email.send", "email.reply", "calendar.create", "calendar.update", "calendar.delete")


def _waiting(home: Path, google_name: str) -> dict:
    """server name -> how many of its actions wait in Decisions waiting (app actions by their app; Google's email and
    calendar cards under Qosha's own Google connection)."""
    out = {}
    try:
        store = sys.modules.get("qosha_guard.store")
        if store is None:
            from qosha_guard import store   # loaded by path in decisions_api
        for d in store.list_decisions("pending", 1000000, home):   # all of them (GPT R-conntab1 #5)
            if d.get("kind") == "app.action":
                name = str((d.get("payload") or {}).get("server") or "")
            elif d.get("kind") in GOOGLE_KINDS and google_name:
                name = google_name
            else:
                continue
            out[name] = out.get(name, 0) + 1
    except Exception:
        return {}
    return out


def _connection(server: dict, servers: dict, google=None, used=None, waiting=None):
    status, detail = _status(server, servers.get(server["name"]), google)
    category = server.get("category") if server.get("category") in CATEGORIES else "Other"
    return {"name": server["name"], "label": _plain(server.get("label") or server["name"]), "what": _plain(server.get("what")),
            "held": _plain(server.get("held")), "needs_account": bool(server.get("needs_account")),
            "kind": "remote" if server.get("kind") == "remote" else "local", "vendor": _plain(server.get("vendor")),
            "status": status, "detail": detail, "category": category, "builtin": not server.get("needs_account"),
            "enabled": isinstance(servers.get(server["name"]), dict) and servers[server["name"]].get("enabled", True) is not False,
            "google": bool(server.get("google_connector")), "reads": _reads(server), "account": _account(server, google),
            "last_used": (used or {}).get(re.sub(r"[^A-Za-z0-9_]", "_", server["name"])),
            "waiting": int((waiting or {}).get(server["name"], 0))}


def _servers(cfg=None):
    servers = (cfg or _config()).get("mcp_servers")
    return servers if isinstance(servers, dict) else {}


def _known(name: str):
    if not NAME_RE.match(name or ""):
        raise Problem(404, "not_found", "There is no app with that name in Qosha.")
    server = next((s for s in _catalog() if s["name"] == name), None)
    if server is None:
        raise Problem(404, "not_found", "There is no app with that name in Qosha.")
    return server


def _set_enabled(name: str, on: bool):
    with _LOCK:
        cfg = _config()
        servers = _servers(cfg)
        if not isinstance(servers.get(name), dict):
            raise Problem(409, "not_installed", "This app is not set up on this computer. Reinstall Qosha's apps.")
        servers[name]["enabled"] = bool(on)
        cfg["mcp_servers"] = servers
        _save(cfg)


# ---- local installs (17 Nov 2026): Google is connected on this computer by Qosha's one-step sign-in
# (qosha_guard/google_connect.py, the same code as the chat tool qosha_connect_google); this page shows and drives it.
def _local() -> bool:
    import os
    return not os.environ.get("QOSHA_BOX") and not os.environ.get("QOSHA_LAB") and not os.environ.get("QOSHA_CONNECTOR_URL")


def _gc():
    mod = sys.modules.get("qosha_google_connect_page")
    if mod is None:
        spec = importlib.util.spec_from_file_location("qosha_google_connect_page", CATALOG.parent / "google_connect.py")
        mod = importlib.util.module_from_spec(spec)
        sys.modules["qosha_google_connect_page"] = mod
        spec.loader.exec_module(mod)
    return mod


def _local_google() -> dict:
    """{"signed_in", "account"} from the files the sign-in wrote (names only; no token is read)."""
    from urllib.parse import unquote
    home = _home()
    account = ""
    try:
        files = sorted(_gc().workspace_mcp_dir().glob("*.json"), key=lambda f: f.stat().st_mtime, reverse=True)
        account = unquote(files[0].stem) if files else ""
    except Exception:
        pass
    return {"signed_in": (home / "google_token.json").is_file(), "account": account}


def _local_rows(rows: list) -> list:
    g = _local_google()
    servers = _servers()
    for r in rows:
        r["local"] = True
        if r.get("google"):
            r["builtin"] = False
            r["label"] = "Google (Gmail, Calendar, Drive)"
            r["what"] = ("Reads and writes your Gmail, Calendar, Drive, Docs, Sheets, Contacts and Tasks, straight between "
                         "Google and this computer.")
            r["held"] = "Sending or replying to email, calendar changes and invite answers, sharing and deleting: Qosha asks you first in the chat (Allow this time / Always allow)."
            r["reads"] = ["read and search email", "read calendar and meeting links", "search and read Drive files", "write drafts"]
            r["account"] = g["account"]
            r["enabled"] = g["signed_in"]
            r["status"], r["detail"] = ("ready", "Gmail, Calendar, Drive, Docs, Sheets, Contacts and Tasks.") if g["signed_in"] else \
                ("needs_sign_in", "Connect your Google account: Gmail, Calendar, Drive, Docs and Sheets.")
            try:   # a Google sign-in waiting in the browser: a reopened page shows it again (with the link and Cancel)
                w = _gc().waiting_signin()
            except Exception:
                w = None
            if w:
                r["signin"] = {"flow_id": w["flow_id"], "authorization_url": w["auth_url"], "waiting_line": w["line"]}
        elif not isinstance(servers.get(r["name"]), dict):
            r["status"], r["detail"] = "off", "Not added on this computer yet. Ask Qosha in the chat to add it."
    return rows


@router.get("/connections")
@_answer
def connections():
    servers, catalog, home = _servers(), _catalog(), _home()
    google_name = next((s["name"] for s in catalog if s.get("google_connector")), "")
    google = _google_status() if google_name and not _local() else None
    used, waiting = _last_used(home), _waiting(home, google_name)
    rows = [_connection(s, servers, google if s.get("google_connector") else None, used, waiting) for s in catalog]
    if _local():
        rows = _local_rows(rows)
    return {"connections": rows, "summary": {"connected": sum(r["status"] == "ready" for r in rows),
                                             "needs_sign_in": sum(r["status"] == "needs_sign_in" for r in rows),
                                             "waiting": sum(r["waiting"] for r in rows)}}


def _engine_detail(exc) -> str:
    code = getattr(exc, "status_code", 0)
    if code == 409:
        return "A sign-in for this app is already open. Finish it in the other window, or wait a few minutes and try again."
    if code == 429:
        return "Too many sign-ins are open at once. Finish or close one, then try again."
    return "The sign-in could not start (error %s). Try again in a moment." % (code or type(exc).__name__)


@router.post("/connections/{name}/connect")
async def connect(name: str, request: Request):
    try:
        server = _known(name)
        if _local() and server.get("google_connector"):
            # 17 Nov evening: answers AT ONCE with Google's address, like the other sign-ins; the page opens it and polls
            # /connections/flows/<id>. The loopback server waits in the background (10 min, one sign-in at a time; a
            # second press gets the same one). The dashboard no longer opens the browser itself here: on Windows a hidden
            # process opens it BEHIND the Qosha window; the page asks for that second path (/google-open) only when its
            # own window.open was blocked.
            from starlette.concurrency import run_in_threadpool
            r = await run_in_threadpool(lambda: _gc().start_flow(open_browser=False))
            if not r.get("ok"):
                raise Problem(409, "google_not_connected", str(r.get("plain") or "Google did not connect."))
            url = str(r.get("auth_url") or "")
            if not url.startswith("https://accounts.google.com/") or not FLOW_RE.match(str(r.get("flow_id") or "")):
                raise Problem(502, "sign_in_failed", "Google's sign-in could not start. Try again in a moment.")
            return {"name": name, "status": "signing_in", "flow_id": r["flow_id"], "authorization_url": url,
                    "provider": "google", "reused": bool(r.get("reused")), "seconds_left": r.get("seconds_left"),
                    "account_hint": r.get("account_hint") or "", "waiting_line": r.get("waiting_line") or ""}
        entry = _servers().get(name)
        if not isinstance(entry, dict):
            raise Problem(409, "not_installed", "This app is not set up on this computer. Reinstall Qosha's apps.")
        if not server.get("needs_account"):
            _set_enabled(name, True)
            return {"name": name, "status": "ready"}
        if not _oauth(entry):
            raise Problem(400, "key_sign_in", "This app signs in with a key from your own account; that isn't available "
                                              "from this page yet.")
        with _LOCK:   # reserved before the engine is asked (GPT R-skillsmcp2): a Disconnect meanwhile moves it on
            before = _gen.get(name, 0)
            _gen[name] = mine = before + 1
            dis0 = _dis.get(name, 0)   # a competing start never invalidates a sign-in already open (R-skillsmcp5 #1)
            _tentative[name] = _tentative.get(name, 0) + 1
        try:
            return await _start_signin(name, request, before, mine, dis0)
        finally:
            with _LOCK:
                _tentative[name] = max(0, _tentative.get(name, 0) - 1)
    except Problem as exc:
        return JSONResponse(status_code=exc.status, content={"error": exc.error, "detail": exc.detail})
    except Exception as exc:
        return JSONResponse(status_code=503, content={"error": "unavailable",
                                                      "detail": "Qosha could not do that right now (%s). Try again." % type(exc).__name__})


async def _start_signin(name: str, request: Request, before: int, mine: int, dis0: int):
    from hermes_cli.web_routers import mcp as engine_mcp
    home = _home()

    def refused(problem):
        # a start that didn't happen gives its reservation back, so a sign-in already open stays valid (GPT
        # R-skillsmcp3 #4); a Disconnect that moved the generation on meanwhile is never undone
        with _LOCK:
            if _gen.get(name, 0) == mine:
                _gen[name] = before
        return problem
    try:
        snap = await engine_mcp.auth_mcp_server(name, request)
    except Exception as exc:
        raise refused(Problem(502, "sign_in_failed", _engine_detail(exc)))
    url = str(snap.get("authorization_url") or "")
    flow = str(snap.get("flow_id") or "")
    if snap.get("status") == "error" or not url.startswith("https://") or not FLOW_RE.match(flow):
        raise refused(Problem(502, "sign_in_failed", "The app's sign-in page could not be reached. Check the "
                                                     "internet connection and try again."))
    with _LOCK:
        superseded = _dis.get(name, 0) != dis0
        if not superseded:
            _flows[flow] = (name, dis0)
            _started[name] = max(_started.get(name, 0), mine)
    if superseded:   # disconnected while the sign-in was starting: cancel it; never tracked, never switched on
        f = _engine_flow(flow)
        if f is not None:
            try:
                f.mark_error("Cancelled: the app was disconnected")
            except Exception:
                pass
        with _LOCK:   # cleanup for the Disconnect that cancelled this start; it retires itself once a newer Connect's
            off = _off_gen.get(name)   # sign-in starts (#3), so a tentative Connect doesn't skip it (R-final6 #2)
            sweep = off is not None and off > mine and _started.get(name, 0) <= off
        if sweep:
            threading.Thread(target=_sweep, args=(name, off, [flow], home), daemon=True,
                             name="qosha-disconnect-" + name).start()
        raise Problem(409, "disconnected", "The app was disconnected while its sign-in was starting. Press Connect "
                                           "to try again.")
    return {"name": name, "status": "signing_in", "flow_id": flow, "authorization_url": url}


def _google_flow_answer(flow_id: str):
    """The local Google sign-in's state in the same shape as the other sign-ins' (pending / approved / error)."""
    name = next((s["name"] for s in _catalog() if s.get("google_connector")), "qosha_google")
    r = _gc().flow_status(flow_id)
    st = r.get("status")
    if st == "waiting":
        return {"name": name, "status": "pending", "connected": False, "seconds_left": r.get("seconds_left"),
                "refused": r.get("refused", 0), "account_hint": r.get("account_hint") or "",
                "waiting_line": r.get("waiting_line") or ""}
    if st == "connected":
        return {"name": name, "status": "approved", "connected": True, "account": r.get("email") or ""}
    if st == "unknown":
        raise Problem(404, "not_found", "This sign-in has expired. Press Connect again.")
    return {"name": name, "status": "error", "connected": False, "reason": st,
            "detail": r.get("plain") or "The Google sign-in did not finish. Press Connect Google to try again."}


@router.post("/connections/google-open/{flow_id}")
@_answer
def google_open(flow_id: str):
    """Second path: this computer opens the waiting Google sign-in's own address (never an address sent by the page)."""
    if not _local() or not FLOW_RE.match(flow_id or ""):
        raise Problem(404, "not_found", "This sign-in has expired. Press Connect again.")
    r = _gc().open_in_browser(flow_id)
    if not r.get("ok"):
        raise Problem(404, "not_found", "This sign-in has expired. Press Connect again.")
    return {"opened": bool(r.get("browser_opened"))}


@router.post("/connections/google-cancel/{flow_id}")
@_answer
def google_cancel(flow_id: str):
    """Cancel on the page: ends that waiting Google sign-in (its late answer is refused)."""
    if not _local() or not FLOW_RE.match(flow_id or ""):
        raise Problem(404, "not_found", "This sign-in has expired.")
    return {"cancelled": bool(_gc().cancel_flow(flow_id))}


@router.get("/connections/flows/{flow_id}")
async def flow_status(flow_id: str, request: Request):
    try:
        if _local() and flow_id.startswith("g") and FLOW_RE.match(flow_id or "") and flow_id not in _flows:
            return _google_flow_answer(flow_id)
        held = _flows.get(flow_id) if FLOW_RE.match(flow_id or "") else None
        name, gen = held if held else (None, None)
        if not name or _dis.get(name, 0) != gen:
            _flows.pop(flow_id, None)
            raise Problem(404, "not_found", "This sign-in has expired. Press Connect again.")
        from hermes_cli.web_routers import mcp as engine_mcp
        try:
            snap = await engine_mcp.mcp_oauth_flow_status(flow_id, request)
        except Exception:
            _flows.pop(flow_id, None)
            raise Problem(404, "not_found", "This sign-in has expired. Press Connect again.")
        status = snap.get("status")
        if status == "approved":
            _flows.pop(flow_id, None)
            with _LOCK:                               # checked and switched on together: a Disconnect can't slip between
                if _dis.get(name, 0) != gen:          # disconnected while this sign-in was running
                    raise Problem(404, "not_found", "This sign-in has expired. Press Connect again.")
                _set_enabled(name, True)
            return {"name": name, "status": "approved", "connected": True}
        if status == "error":
            _flows.pop(flow_id, None)
            return {"name": name, "status": "error", "connected": False,
                    "detail": "The sign-in did not finish. Press Connect to try again."}
        return {"name": name, "status": "pending", "connected": False}
    except Problem as exc:
        return JSONResponse(status_code=exc.status, content={"error": exc.error, "detail": exc.detail})
    except Exception as exc:
        return JSONResponse(status_code=503, content={"error": "unavailable",
                                                      "detail": "Qosha could not do that right now (%s). Try again." % type(exc).__name__})


@router.post("/connections/{name}/disconnect")
@_answer
def disconnect(name: str):
    """Switches the app off, cancels every sign-in for it still in progress (none can switch it back on: a new
    generation), removes the stored sign-in, and keeps removing one a cancelled sign-in stores late."""
    server = _known(name)
    if _local() and server.get("google_connector"):
        # the sign-in files of this computer are removed (the bundled skill's token and the Workspace tools' copy); a
        # sign-in still waiting is stopped first, so its late answer can't connect Google again
        try:
            _gc().cancel_flow()
        except Exception:
            pass
        home = _home()
        for f in [home / "google_token.json", home / "google_oauth_pending.json"] + list(_gc().workspace_mcp_dir().glob("*.json")):
            try:
                f.unlink()
            except FileNotFoundError:
                pass
        return {"name": name, "status": "needs_sign_in"}
    entry = _servers().get(name)
    if not isinstance(entry, dict):
        raise Problem(409, "not_installed", "This app is not set up on this computer. Reinstall Qosha's apps.")
    signed = server.get("needs_account") and _oauth(entry)
    if signed:
        from tools.mcp_oauth import remove_oauth_tokens
    with _LOCK:   # switched off and sign-in removed under the same lock: a newer Connect can't finish in between and
        _gen[name] = _gen.get(name, 0) + 1       # lose its sign-in (GPT R-skillsmcp5 #2)
        gen = _off_gen[name] = _gen[name]
        _dis[name] = _dis.get(name, 0) + 1
        stale = [fid for fid, held in list(_flows.items()) if held[0] == name]
        for fid in stale:
            _flows.pop(fid, None)
        _set_enabled(name, False)
        if signed:
            remove_oauth_tokens(name, hermes_home=_home())
    for fid in stale:
        f = _engine_flow(fid)
        if f is not None:
            try:
                f.mark_error("Cancelled: the app was disconnected")
            except Exception:
                pass
    if signed:
        if stale:
            threading.Thread(target=_sweep, args=(name, gen, stale, _home()), daemon=True,
                             name="qosha-disconnect-" + name).start()
    servers = _servers()
    return {"name": name, "status": _connection(server, servers)["status"]}
