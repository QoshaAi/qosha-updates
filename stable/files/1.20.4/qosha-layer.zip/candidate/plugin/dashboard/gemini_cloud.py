"""Gemini in the cloud box (GEMINICLOUD, 5 Nov): Qosha-provided Gemini on Vertex AI, asked with the box's own Google
identity (Workload Identity: the box's Kubernetes service account, read from the metadata server; no stored key).
Text only, like Ask Gemini on a Mac: no tools, no files, nothing saved here. Used by assistants_api.py when QOSHA_BOX=1.

Spend: each answer is capped (MAX_OUT tokens) and so is each day's number of questions (DAILY_CAP, counted in the
box's notebook), on top of the project's budget alert. Requests carry the label qosha_box=<person> for billing.
Never logs or returns the access token.
"""
from __future__ import annotations

import fcntl
import json
import logging
import os
import threading
import time
import urllib.error
import urllib.request
from datetime import date
from pathlib import Path

METADATA = "http://169.254.169.254/computeMetadata/v1"
API = "https://aiplatform.googleapis.com"   # the global endpoint (gemini-3.5-flash-lite: global, us, eu only)
MODEL = "gemini-3.5-flash-lite"             # council D38: the cheapest that answers short chat well
LOCATION = "global"
MAX_OUT = 2048
DAILY_CAP = 200
TIMEOUT = 120

_LOCK = threading.Lock()
_TOKEN = {"value": "", "until": 0.0}
_PROJECT = {"id": ""}


class Unavailable(Exception):
    """Gemini can't answer; the message is plain words for the page (no token, no internal detail)."""


def _meta(path: str, timeout: float = 3) -> str:
    req = urllib.request.Request(METADATA + path, headers={"Metadata-Flavor": "Google"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode()


def _token() -> str:
    with _LOCK:
        if _TOKEN["value"] and time.monotonic() < _TOKEN["until"]:
            return _TOKEN["value"]
        d = json.loads(_meta("/instance/service-accounts/default/token"))
        _TOKEN.update(value=d["access_token"], until=time.monotonic() + max(0, int(d.get("expires_in", 0)) - 120))
        return _TOKEN["value"]


def _project() -> str:
    if not _PROJECT["id"]:
        _PROJECT["id"] = _meta("/project/project-id").strip()
    return _PROJECT["id"]


def ready() -> bool:
    """The box can get its own Google identity and knows its project (no model call, so no cost)."""
    try:
        return bool(_token() and _project())
    except Exception:
        return False


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME", "/opt/data"))


def _count_today() -> int:
    """One more question today; refuses past DAILY_CAP (the file lives in the box's own notebook)."""
    f = _home() / "qosha" / "gemini-usage.json"
    today = date.today().isoformat()
    f.parent.mkdir(parents=True, exist_ok=True)
    with _LOCK, open(f.with_name(".gemini-usage.lock"), "a") as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)   # also between processes sharing the notebook (GPT partA-r2)
        try:
            u = json.loads(f.read_text())
        except (OSError, ValueError):
            u = {}
        n = int(u.get(today, 0)) if isinstance(u, dict) else 0
        if n >= DAILY_CAP:
            raise Unavailable("today's Gemini limit (%d questions) is reached; it resets tomorrow" % DAILY_CAP)
        tmp = f.with_name(".gemini-usage.%d.tmp" % os.getpid())
        tmp.write_text(json.dumps({today: n + 1}))
        os.replace(tmp, f)
        return n + 1


def ask(question: str) -> dict:
    try:
        token, project = _token(), _project()
    except Exception:
        raise Unavailable("Gemini is not available in this cloud Qosha right now")
    _count_today()
    url = "%s/v1/projects/%s/locations/%s/publishers/google/models/%s:generateContent" % (API, project, LOCATION, MODEL)
    body = {"contents": [{"role": "user", "parts": [{"text": question}]}],
            "generationConfig": {"maxOutputTokens": MAX_OUT},
            "labels": {"qosha_box": (os.environ.get("QOSHA_PERSON") or "unknown").lower()[:63]}}
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                 headers={"Authorization": "Bearer " + token, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            d = json.loads(r.read())
    except urllib.error.HTTPError as e:
        # the page shows this text word for word: plain words there, the HTTP code only in the log
        logging.getLogger("qosha.gemini_cloud").warning("Gemini (cloud) turned the question away: HTTP %d", e.code)
        raise Unavailable("Gemini turned the question away just now. Try again in a moment.")
    except Exception:
        raise Unavailable("Gemini could not be reached")
    parts = (((d.get("candidates") or [{}])[0].get("content") or {}).get("parts")) or []
    answer = "".join(p.get("text", "") for p in parts if isinstance(p, dict) and not p.get("thought")).strip()
    if not answer:
        raise Unavailable("Gemini gave no answer")
    return {"assistant": "gemini", "answer": answer[:20000]}
