"""Pictures, videos and files inside Qosha's chat (Ren, 20 Nov 2026: "it needs to behave exactly the same way claude
does"). Read-only routes under /api/plugins/qosha/media, used by pages/qosha-media.js:

    GET  /media/info?path=ABS            {ok, name, size, kind: image|video|audio|file, ext} or {ok: false, error, detail}
    GET  /media/file?path=ABS[&download=1]   the bytes (Range supported); inline only for pictures, video and audio
    POST /media/reveal {path}            shows the file in Finder / File Explorer
    POST /media/open {path}              opens it in the computer's own app (pictures, video, audio, documents only)

Safety:
- Only files inside Qosha's own folders: the Qosha files folder (where the person's attachments are saved) and the
  engine's own media caches (cache/images, cache/screenshots, cache/videos, cache/audio, cache/documents, and their
  older names image_cache, browser_screenshots, video_cache, audio_cache, document_cache). The real path (links and
  Windows junctions resolved) must be inside one of them; a regular file; no sign-in or secret names on the way.
- The session header is required like every Qosha route (the page fetches into a blob: no token in any URL).
- Never served inline: SVG, HTML and anything else that can run (they download as octet-stream, sandboxed).
- Mac and Windows alike (drive letters, backslashes, case-insensitive names on Windows).
"""
from __future__ import annotations

import os
import re
import stat
import subprocess
import sys
from pathlib import Path
from typing import Optional
from urllib.parse import quote, unquote, urlsplit

from fastapi import APIRouter, Body, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse

router = APIRouter()
# the feature switch (slices: off until the last slice turns pictures in the chat on)
ENABLED = True
WIN = os.name == "nt"
MAX_BYTES = 500 * 1024 * 1024
CHUNK = 1024 * 1024

IMAGE = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif", "webp": "image/webp",
         "bmp": "image/bmp", "avif": "image/avif", "heic": "image/heic"}
VIDEO = {"mp4": "video/mp4", "m4v": "video/mp4", "webm": "video/webm", "mov": "video/quicktime", "ogv": "video/ogg"}
AUDIO = {"mp3": "audio/mpeg", "m4a": "audio/mp4", "aac": "audio/aac", "wav": "audio/wav", "ogg": "audio/ogg",
         "oga": "audio/ogg", "opus": "audio/ogg", "flac": "audio/flac"}
# opened in the computer's own app on request (never programs, scripts, shortcuts or installers)
OPENABLE = set(IMAGE) | set(VIDEO) | set(AUDIO) | {"pdf", "txt", "md", "csv", "tsv", "rtf", "doc", "docx", "xls", "xlsx",
                                                   "ppt", "pptx", "odt", "ods", "odp", "pages", "numbers", "key", "json"}
# the engine's never-exposed names (as files_api.py), plus anything shaped like a key or sign-in file
_SECRET = re.compile(r"(^\.env|\.env$|\.envrc|config\.ya?ml|auth\.json|auth\.lock|credentials|\.anthropic_oauth|google_token|google_oauth|"
                     r"webhook_subscriptions|bws_cache|\.git-credentials|connector\.key|token|secret|password|netrc|"
                     r"\.pem$|\.key$|\.p12$|\.pfx$|id_rsa|id_ed|id_ecdsa|mcp-tokens|^pairing$)", re.I)
CACHE_DIRS = ("cache/images", "image_cache", "cache/screenshots", "browser_screenshots", "cache/videos", "video_cache",
              "cache/audio", "audio_cache", "cache/documents", "document_cache")


class Refused(Exception):
    def __init__(self, status: int, error: str, detail: str):
        super().__init__(detail)
        self.status, self.error, self.detail = status, error, detail


def _home() -> Path:
    """The home of the profile this request is serving (the engine scopes get_hermes_home per request, as access.py's
    export does): another profile's caches are not this chat's (verification pass MEDIA-3)."""
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        h = os.environ.get("HERMES_HOME")
        return Path(h) if h else Path.home() / ".hermes"


def _norm(p: str) -> str:
    return os.path.normcase(os.path.normpath(p))


def files_root() -> Optional[str]:
    """The configured files folder; the home's files/ only when no folder is configured (a configured folder that is
    missing, e.g. a disconnected drive, is never replaced by another one: review r2 MH7)."""
    files = os.environ.get("HERMES_DASHBOARD_FILES_ROOT", "").strip()
    if files:
        return os.path.realpath(files) if os.path.isabs(files) and os.path.isdir(files) else None
    f = _home() / "files"
    return os.path.realpath(str(f)) if f.is_dir() else None


def roots() -> list:
    """The real paths of Qosha's own folders that exist on this computer. A cache folder counts only where it really
    is (inside the home, no link anywhere on its way): a cache that is a link to the home itself or elsewhere would
    open everything it points to (review r1 #3)."""
    out = []
    fr = files_root()
    if fr:
        out.append(fr)
    h = _home()
    try:
        hr = os.path.realpath(str(h))
    except OSError:
        return out
    for d in CACHE_DIRS:
        c = os.path.join(str(h), *d.split("/"))
        try:
            if not os.path.isdir(c):
                continue
            r = os.path.realpath(c)
            if _norm(r) != _norm(os.path.join(hr, *d.split("/"))):
                continue                                    # a link somewhere on the way: not a cache of this home
            if r not in out:
                out.append(r)
        except OSError:
            continue
    return out


def _clean_input(path) -> str:
    if not isinstance(path, str) or not path or len(path) > 4096 or "\x00" in path:
        raise Refused(400, "bad_path", "That is not a file path.")
    p = path.strip().strip('"').strip("'").strip("`")
    # never a network or device path: Windows would contact another computer just to resolve it (review r1 #2)
    if p.startswith("\\\\") or p.startswith("//") or p.startswith("\\/") or p.startswith("/\\"):
        raise Refused(403, "outside", "Qosha shows files from its own folders only.")
    if p.lower().startswith("file:"):
        u = urlsplit(p)
        if u.netloc and u.netloc.lower() not in ("localhost",):
            raise Refused(403, "outside", "Qosha shows files from its own folders only.")
        p = unquote(u.path)
        if WIN and re.match(r"^/[A-Za-z]:", p):
            p = p[1:]
    if p.startswith("~"):
        p = os.path.expanduser(p)
    if p.startswith("\\\\") or p.startswith("//") or p.startswith("\\/") or p.startswith("/\\"):   # after decoding too (r2 MH2)
        raise Refused(403, "outside", "Qosha shows files from its own folders only.")
    if not os.path.isabs(p):
        raise Refused(400, "not_absolute", "Only full file paths can be shown.")
    return p


def _project_check(real: str, project: Optional[str]) -> None:
    """Qosha's project rule (qosha_guard/projects_scope.py): a project chat works inside its own project's folder.
    `project` is the project folder of the chat showing the answer (chat.html sends its own project's folder; the text
    of an answer can't change it). Inside the files folder's Projects/, a file is shown only to a chat of that project;
    a project chat sees no other part of the files folder (review r1 #5). Without a project, Projects/ is not shown."""
    fr = files_root()
    if not fr:
        if project:   # a project chat with no files folder: its project can't be checked, so nothing is shown (MEDIA-1)
            raise Refused(403, "project", "This chat's project folder isn't one of Qosha's projects.")
        return
    try:
        in_files = os.path.commonpath([_norm(real), _norm(fr)]) == _norm(fr)
    except ValueError:                                   # another drive (Windows): not in the files folder
        in_files = False
    base = os.path.join(fr, "Projects")
    in_projects, slug = False, None
    if in_files:
        # the separators of this system only: on a Mac a backslash is part of a file's name (MEDIA-2)
        parts = [x for x in re.split(r"[\\/]" if os.name == "nt" else "/", os.path.relpath(real, fr)) if x]
        try:   # the Projects folder by identity, whatever the spelling (case-insensitive volumes: review r2 MH5)
            in_projects = len(parts) >= 2 and os.path.isdir(base) and os.path.samefile(os.path.join(fr, parts[0]), base)
        except OSError:
            in_projects = False
        slug = parts[1] if in_projects else None
    chat_slug = None
    if project:
        try:
            pr = os.path.realpath(project)
        except (OSError, ValueError):
            pr = ""
        if not pr or _norm(os.path.dirname(pr)) != _norm(base):
            raise Refused(403, "project", "This chat's project folder isn't one of Qosha's projects.")
        chat_slug = os.path.basename(pr)
    if in_projects and chat_slug != slug:
        raise Refused(403, "project", "This file belongs to another project.")
    if chat_slug and in_files and not in_projects:
        raise Refused(403, "project", "A project chat shows files from its own project only.")


def resolve(path, project: Optional[str] = None) -> tuple:
    """(real path, root, kind, ext, size) for an allowed regular file, or Refused."""
    if not ENABLED:
        raise Refused(404, "off", "Pictures in the chat are not switched on in this version.")
    p = _clean_input(path)
    try:
        real = os.path.realpath(p)
    except (OSError, ValueError):
        raise Refused(404, "not_found", "That file isn't there.")
    root = None
    for r in roots():
        try:
            if os.path.commonpath([_norm(real), _norm(r)]) == _norm(r) and _norm(real) != _norm(r):
                root = r
                break
        except ValueError:          # different drives on Windows
            continue
    if root is None:
        raise Refused(403, "outside", "Qosha shows files from its own folders only.")
    _project_check(real, project)
    rel = os.path.relpath(real, root)
    if any(_SECRET.search(part) for part in re.split(r"[\\/]", rel)):
        raise Refused(403, "sensitive", "That file can't be shown here.")
    try:
        st = os.stat(real)
    except FileNotFoundError:
        raise Refused(404, "not_found", "That file isn't there any more.")
    except OSError:
        raise Refused(404, "not_found", "That file can't be read.")
    if not stat.S_ISREG(st.st_mode):
        raise Refused(409, "not_a_file", "That is not a file.")
    ext = os.path.splitext(real)[1].lower().lstrip(".")
    kind = "image" if ext in IMAGE else "video" if ext in VIDEO else "audio" if ext in AUDIO else "file"
    return real, root, kind, ext, st.st_size


def _err(exc: Refused) -> JSONResponse:
    return JSONResponse(status_code=exc.status, content={"ok": False, "error": exc.error, "detail": exc.detail},
                        headers={"Cache-Control": "no-store"})


@router.get("/info")
def info(path: str, project: Optional[str] = None):
    try:
        real, _root, kind, ext, size = resolve(path, project)
        return JSONResponse({"ok": True, "name": os.path.basename(real), "size": size, "kind": kind, "ext": ext,
                             "openable": ext in OPENABLE}, headers={"Cache-Control": "no-store"})
    except Refused as exc:
        return _err(exc)


def _range(header: Optional[str], size: int):
    m = re.match(r"^bytes=(\d*)-(\d*)$", (header or "").strip())
    if not m or (not m.group(1) and not m.group(2)):
        return None
    if m.group(1):
        start = int(m.group(1))
        end = int(m.group(2)) if m.group(2) else size - 1
    else:
        n = int(m.group(2))
        start, end = max(0, size - n), size - 1
    if start >= size or end < start:
        raise Refused(416, "range", "That part of the file doesn't exist.")
    return start, min(end, size - 1)


@router.get("/file")
def file(request: Request, path: str, download: int = 0, project: Optional[str] = None):
    try:
        real, _root, kind, ext, size = resolve(path, project)
        if size > MAX_BYTES:
            raise Refused(413, "too_large", "That file is too large to show here (the limit is 500 MB).")
        mime = IMAGE.get(ext) or VIDEO.get(ext) or AUDIO.get(ext)
        inline = bool(mime) and not download
        headers = {"X-Content-Type-Options": "nosniff", "Cache-Control": "no-store", "Accept-Ranges": "bytes",
                   "Content-Security-Policy": "sandbox; default-src 'none'",
                   "Content-Disposition": ("inline" if inline else "attachment") + "; filename*=UTF-8''" +
                                          quote(os.path.basename(real), safe="")}
        rng = _range(request.headers.get("range"), size)
        start, end = rng if rng else (0, size - 1)
        f = open(real, "rb")
        f.seek(start)
        left = end - start + 1 if size else 0

        def chunks():
            n = left
            with f:
                while n > 0:
                    b = f.read(min(CHUNK, n))
                    if not b:
                        break
                    n -= len(b)
                    yield b
        if rng:
            headers["Content-Range"] = "bytes %d-%d/%d" % (start, end, size)
        headers["Content-Length"] = str(left)
        return StreamingResponse(chunks(), status_code=206 if rng else 200,
                                 media_type=mime if inline else "application/octet-stream", headers=headers)
    except Refused as exc:
        return _err(exc)
    except OSError:
        return _err(Refused(500, "unavailable", "The file could not be read."))


def _run(cmd):
    kw = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
    if WIN:
        kw["creationflags"] = 0x08000000
    subprocess.Popen(cmd, **kw)


@router.post("/reveal")
def reveal(body: dict = Body(default={})):
    try:
        real, *_ = resolve((body or {}).get("path"), (body or {}).get("project"))
        _run(["explorer", "/select,", real] if WIN else ["/usr/bin/open", "-R", real])
        return {"ok": True}
    except Refused as exc:
        return _err(exc)


@router.post("/open")
def open_in_app(body: dict = Body(default={})):
    try:
        real, _root, _kind, ext, _size = resolve((body or {}).get("path"), (body or {}).get("project"))
        if ext not in OPENABLE:
            raise Refused(403, "not_openable", "That kind of file is not opened from the chat; use Show in folder.")
        if WIN:
            os.startfile(real)          # the file's own app (the extension is a document or media type, never a program)
        else:
            _run(["/usr/bin/open", real])
        return {"ok": True}
    except Refused as exc:
        return _err(exc)
    except OSError:
        return _err(Refused(500, "unavailable", "The file could not be opened."))
