"""Other assistants for the Qosha page (UAT 2 Nov; council C6 → D17). Mounted at /api/plugins/qosha/assistants.

GET  /            which assistants this Qosha can reach: Claude (always), ChatGPT (signed in to the lab's own
                  ChatGPT subscription session), Gemini (the connector can run the person's signed-in Gemini; in the
                  cloud box: Qosha-provided Gemini on Vertex AI, gemini_cloud.py).
                  `gemini_chat` (CONTRACT G1, G3): Gemini is a full chat model here, like Claude and ChatGPT.
                  `gemini_app` (CONTRACT G3, the cloud box): the person's own Gemini app in the box: its state
                  ("ready", "signed_out", "attention", "off"), the Google address it is signed in to, the plan label
                  and the models the app offers. Never a token, a cookie or anything else of the sign-in.
(The sign-in view is OPENED by the box's Google connector, POST /qosha-box/gemini-signin, which checks the person's
 sign-in itself: council G3-D2. This server can't open one.)
POST /gemini/signin/done    close it and read from the app who is signed in and which models it offers
POST /gemini/look           read that again (Connections' "Check again")
POST /ask         {"assistant": "gemini", "question": "..."}: Gemini's text answer through the connector. ChatGPT and
                  Claude are asked through the dashboard's own chat sessions, where every tool goes through the
                  approval guard; Gemini gets no tools at all.
"""
from __future__ import annotations

import importlib.util
import json
import logging
import os
import sys
import threading
import time
from pathlib import Path

from fastapi import APIRouter, Body
from fastapi.responses import JSONResponse
from hermes_constants import get_hermes_home

router = APIRouter()
log = logging.getLogger("qosha.assistants")
_GUARD_DIR = Path(__file__).resolve().parent.parent / "qosha_guard"


def _client():
    mod = sys.modules.get("qosha_assistants_connector_client")
    if mod is not None:
        return mod
    spec = importlib.util.spec_from_file_location("qosha_assistants_connector_client", _GUARD_DIR / "connector_client.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["qosha_assistants_connector_client"] = mod
    spec.loader.exec_module(mod)
    return mod


def chatgpt_signed_in() -> bool:
    """The lab's own ChatGPT subscription session exists in its auth store (`cli auth add openai-codex`)."""
    try:
        store = json.loads((Path(get_hermes_home()) / "auth.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    pool = (store.get("credential_pool") or {}).get("openai-codex") or []
    provider = ((store.get("providers") or {}).get("openai-codex") or {}).get("tokens") or {}
    return bool(pool) or bool(provider.get("access_token") or provider.get("refresh_token"))


# Gemini's readiness for the home chips (a hint only: asking still goes through the connector and fails in plain words
# if Gemini is down). One check at a time (pages ask together on load); its answer is shared: "ready" is reused for
# 60 s, "not ready" for 10 s, and a "not ready" check is tried once more before it is stored. A caller never waits more
# than 15 s for another caller's check; then it gets the last known answer. So a burst costs one check, never one per
# caller (GPT R-gemstatus), and after a real outage the chip shows it on the first read 60 s or more after the last good
# check (UAT 10:40 (2); Gemini visual review round 2).
_GEM = {"ok": False, "at": float("-inf")}
_GEM_LOCK = threading.Lock()
GEM_FRESH, GEM_DOWN_FRESH, GEM_WAIT = 60.0, 10.0, 15.0


_CLOUD_LOCK = threading.Lock()


def _cloud():
    """Gemini in the cloud box: Qosha-provided, on Vertex AI with the box's own identity (GEMINICLOUD, 5 Nov). Loaded
    once, and published only after it has fully loaded (two first requests never see a half-loaded module)."""
    with _CLOUD_LOCK:
        mod = sys.modules.get("qosha_gemini_cloud")
        if mod is not None:
            return mod
        spec = importlib.util.spec_from_file_location("qosha_gemini_cloud", Path(__file__).with_name("gemini_cloud.py"))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        sys.modules["qosha_gemini_cloud"] = mod
        return mod


def _helper():
    """P0 council (8 Nov 2026): the cloud box's Gemini seat helper (agy on the person's Google AI Pro sign-in), when this
    box has one. With it, Gemini never goes through the metered Vertex path (Ren: subscription sign-ins only)."""
    url = os.environ.get("QOSHA_GEMINI_HELPER_URL", "")
    if not url:
        return None
    mod = sys.modules.get("qosha_council_integration")   # holds the key in memory (it left the environment)
    key = mod.gemini_helper_key() if mod is not None else os.environ.get("QOSHA_GEMINI_HELPER_KEY", "")
    return url.rstrip("/"), key


def _helper_call(method, path, body=None, timeout=10):
    import urllib.request
    url, key = _helper()
    req = urllib.request.Request(url + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json", "X-Qosha-Key": key})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


# CONTRACT G3: what the helper last said about the person's Gemini app (its status carries no part of the sign-in).
_APP = {"app": {"state": "off"}}
_APP_STATES = ("ready", "signed_out", "attention", "off")
_APP_WHY = {"sign_in_needed": "Gemini is signed out of Google. Sign in again.",
            "page_changed": "Gemini's page has changed and Qosha can't read it yet. Gemini is paused until Qosha is "
                            "updated; Claude and ChatGPT work as usual."}


# SIGNIN2 (16 Nov 2026): why the last sign-in the person made was not used, in plain words. Until then the box threw
# such a sign-in away and nothing said why once the page was loaded again.
_LAST_WORDS = {"other_account": "Your last sign-in was not used: Gemini here must be signed in with your own Qosha address.",
               "signed_out": "Your last sign-in was not used: when Qosha looked, nobody was signed in to Google. If Google "
                             "was still asking something in the window, finish that before you press Done.",
               "not_checked": "The sign-in window closed before Qosha checked your sign-in.",
               "failed": "Qosha could not finish checking your last sign-in: Gemini's page did not get ready in time."}
_LAST_RETRY = " Qosha kept that sign-in for a short while: press \u201cCheck again\u201d; no need to sign in again."
_LAST_AGAIN = " Press \u201cConnect Gemini\u201d to sign in again."


def _last_signin(app) -> dict:
    """The helper's record of the last sign-in check, for the Connections page: when, the words, and whether "Check
    again" can still use that sign-in. Nothing when the last sign-in was kept, or there was none."""
    d = app.get("last_signin") if isinstance(app, dict) else None
    if not isinstance(d, dict) or d.get("result") != "not_kept":
        return {}
    try:
        at = int(d.get("at") or 0)
    except (TypeError, ValueError):
        at = 0
    retry = d.get("retry") is True
    reason = str(d.get("reason") or "")
    words = _LAST_WORDS.get(reason, _LAST_WORDS["failed"])
    if retry:
        words += _LAST_RETRY
    elif reason != "other_account":
        words += _LAST_AGAIN
    try:
        until = int(d.get("retry_until") or 0) if retry else 0
    except (TypeError, ValueError):
        until = 0
    # "until": when the kept sign-in goes (the page shows the time; a second failed check adds none)
    return {"at": at if 0 < at < 4102444800 else 0, "words": words, "retry": retry,
            "until": until if 0 < until < 4102444800 else 0}


def _note_app(app) -> dict:
    """Keep the helper's word on the Gemini app (only the fields the pages use, each checked) and hand the plugin
    the app's model ids, so the engine's model list is the app's."""
    out = {"state": "off"}
    if isinstance(app, dict) and app.get("state") in _APP_STATES:
        out = {"state": app["state"], "signin_open": app.get("signin_open") is True}
        if app["state"] in ("ready", "attention"):
            models = [{"id": m["id"], "label": m["label"][:60]} for m in app.get("models") or []
                      if isinstance(m, dict) and isinstance(m.get("id"), str) and isinstance(m.get("label"), str)][:12]
            out.update({"email": str(app.get("email") or "")[:200], "plan": str(app.get("plan") or "")[:40],
                        "models": models, "default": str(app.get("default") or "")[:60]})
        if app["state"] == "attention":
            out["why"] = _APP_WHY.get(str(app.get("why") or ""), _APP_WHY["page_changed"])
        last = _last_signin(app)
        if last:
            out["last"] = last
    _APP["app"] = out
    mod = sys.modules.get("qosha_gemini_chat")
    try:
        if mod is not None:
            mod.set_models([m["id"] for m in out.get("models") or []] if out["state"] == "ready" else [])
    except Exception:
        pass
    return out


def _local() -> bool:
    return not os.environ.get("QOSHA_BOX") and not os.environ.get("QOSHA_LAB") and not os.environ.get("QOSHA_CONNECTOR_URL")


def _gcli():
    """Gemini through Google's own command-line tool on the person's subscription (qosha_guard/gemini_cli.py)."""
    import importlib.util
    mod = sys.modules.get("qosha_gemini_cli")
    if mod is None:
        spec = importlib.util.spec_from_file_location("qosha_gemini_cli", Path(__file__).resolve().parent.parent / "qosha_guard" / "gemini_cli.py")
        mod = importlib.util.module_from_spec(spec)
        sys.modules["qosha_gemini_cli"] = mod
        spec.loader.exec_module(mod)
    return mod


def _gemini_check() -> bool:
    if _local():
        return _gcli().connected()
    if _helper():
        try:
            d = _helper_call("GET", "/v1/status")
            _note_app(d.get("app"))
            return bool(d.get("gemini"))
        except Exception:
            _note_app(None)
            return False
    if os.environ.get("QOSHA_BOX") == "1":
        return bool(_cloud().ready())
    return bool(_client().assistants().get("gemini"))


def _gemini_ready() -> bool:
    if not _GEM_LOCK.acquire(timeout=GEM_WAIT):
        return bool(_GEM["ok"])
    try:
        age = time.monotonic() - _GEM["at"]
        if age < (GEM_FRESH if _GEM["ok"] else GEM_DOWN_FRESH):
            return bool(_GEM["ok"])
        ok = False
        for _ in range(2):
            try:
                ok = _gemini_check()
            except Exception:
                ok = False
            if ok:
                break
        _GEM.update(ok=ok, at=time.monotonic())
        return ok
    finally:
        _GEM_LOCK.release()


def _where():
    """Where this Qosha runs, for the words on the pages: the cloud box (QOSHA_BOX=1), a Mac, or another computer."""
    if os.environ.get("QOSHA_BOX") == "1":
        return "cloud"
    return "mac" if sys.platform == "darwin" else "computer"


def _gemini_chat(gemini: bool) -> bool:
    """CONTRACT G1, G3: Gemini is a full chat model here (the engine runs its tools behind the guard) only when this
    Qosha has the Gemini helper, the helper says the person's Gemini app is signed in and readable ("ready"), and the
    plugin has pinned the engine to Qosha's relay (qosha_guard/gemini_chat.py ready()). It does not depend on the
    text-only Gemini (`gemini`), which is another sign-in."""
    if not _helper() or _APP["app"].get("state") != "ready" or not _APP["app"].get("models"):
        return False
    mod = sys.modules.get("qosha_gemini_chat")
    try:
        return bool(mod is not None and mod.ready())
    except Exception:
        return False


@router.get("")
@router.get("/")
def assistants():
    gemini = _gemini_ready()
    out = {"claude": True, "chatgpt": chatgpt_signed_in(), "gemini": gemini, "gemini_chat": _gemini_chat(gemini),
           "gemini_app": dict(_APP["app"]), "where": _where()}
    if _local():
        out["claude"] = _claude_here()   # on a person's own computer Claude answers only once it is connected
    else:
        out["chatgpt_signin"] = "python3 lab/qoshalab.py cli auth add openai-codex --type oauth --no-browser"
    return out


def _claude_here() -> bool:
    """A Claude sign-in in the engine's own store, or an Anthropic key saved in Qosha's key file (yes/no only)."""
    try:
        from agent.credential_pool import load_pool
        if len(load_pool("anthropic").entries()) > 0:
            return True
    except Exception:
        pass
    try:
        from hermes_cli.config import load_env
        return bool(load_env().get("ANTHROPIC_API_KEY"))
    except Exception:
        return False


def _updater_mod():
    """qosha_guard/updater.py as the dashboard loaded it (plugin_api.py: "qosha_updater"), else loaded by path."""
    import importlib.util as _ilu, sys as _sys
    from pathlib import Path as _P
    m = _sys.modules.get("qosha_updater")
    if m is None:
        p = _P(__file__).resolve().parent.parent / "qosha_guard" / "updater.py"
        spec = _ilu.spec_from_file_location("qosha_updater_direct", str(p))
        m = _ilu.module_from_spec(spec)
        spec.loader.exec_module(m)
        _sys.modules["qosha_updater_direct"] = m
    return m


class _direct:
    """A direct chat counted as busy by a waiting update (updater.direct_chat); a no-op if the updater can't load."""

    def __enter__(self):
        # the updater must count this answer as busy; if it can't, the answer does not start (review r2 #12)
        self.c = _updater_mod().direct_chat()
        self.c.__enter__()
        return self

    def __exit__(self, *exc):
        if self.c is not None:
            self.c.__exit__(*exc)
        return False


def _access_mod():
    """qosha_guard/access.py, loaded by path once (this file is loaded by path in the dashboard)."""
    import importlib.util as _ilu, sys as _sys
    from pathlib import Path as _P
    m = _sys.modules.get("qosha_access_dash")
    if m is None:
        p = _P(__file__).resolve().parent.parent / "qosha_guard" / "access.py"
        spec = _ilu.spec_from_file_location("qosha_access_dash", str(p))
        m = _ilu.module_from_spec(spec)
        spec.loader.exec_module(m)
        _sys.modules["qosha_access_dash"] = m
    return m


@router.post("/ask")
def ask(body: dict = Body(...)):
    assistant = str((body or {}).get("assistant", ""))
    question = str((body or {}).get("question", "")).strip()
    if assistant != "gemini":
        return JSONResponse(status_code=400, content={"error": "ask_in_chat", "detail": "Claude and ChatGPT answer in chat sessions"})
    if not question or len(question) > 6000:
        return JSONResponse(status_code=400, content={"error": "bad_question", "detail": "1 to 6000 characters"})
    try:   # CONTRACT-ACCESS: a revoked or unconfirmed Qosha asks no model, here either
        _acc = _access_mod()
        if _acc.admit_stopped():
            return JSONResponse(status_code=403, content={"error": "access_ended", "detail": _acc.text_for(_acc.status())})
    except Exception:
        return JSONResponse(status_code=403, content={"error": "access_ended", "detail": "Qosha can't confirm your access."})
    try:
        if _local():
            # "use no tools", as the cloud helper's words below: text-only Gemini cannot use the person's tools
            with _direct():             # an update never stops Qosha in the middle of this answer
                r = _gcli().ask("A question from the person, via Qosha. Answer in plain text only; use no tools.\n\n" + question)
            if r.get("ok"):
                if _access_mod().stopped():      # access ended while it answered: the answer is not shown
                    return JSONResponse(status_code=403, content={"error": "access_ended", "detail": "Your access to Qosha has ended."})
                return {"assistant": "gemini", "answer": r["answer"]}
            # the reason goes in the log (never the question); the page shows the plain words in `detail`
            log.warning("Ask Gemini (this computer) did not answer: %s", str(r.get("error") or "unknown")[:40])
            return JSONResponse(status_code=503, content={"error": r.get("error") or "gemini_unavailable", "detail": r.get("plain") or "Gemini could not answer."})
        if _helper():
            # the helper adds nothing to what it is given (the council's seats get identical bytes); a single
            # "Ask Gemini" says here that it is text only
            d = _helper_call("POST", "/v1/ask", {"question": "A question from the person, via Qosha. Answer in plain "
                                                             "text only; use no tools.\n\n" + question, "timeout": 110},
                             timeout=120)
            return {"assistant": "gemini", "answer": str(d.get("answer", ""))[:20000]}
        if os.environ.get("QOSHA_BOX") == "1":
            return _cloud().ask(question)
        return _client().ask("gemini", question)
    except Exception as exc:   # the connector's own refusal, or unreachable: say so, never invent an answer
        # the page shows `detail`: a plain sentence only (an exception's text can carry internal names and paths)
        # (the cloud box's Unavailable carries plain words by design and is kept as it was)
        log.warning("Ask Gemini did not answer: %s", type(exc).__name__)
        plain = str(exc)[:300] if type(exc).__name__ == "Unavailable" else "Gemini could not be reached just now. Try again in a moment."
        return JSONResponse(status_code=503, content={"error": "gemini_unavailable", "detail": plain})


# --- CONTRACT G3: connecting the person's own Gemini app (the cloud box) ---
GEMINI_VIEW = "/qosha-box/gemini-view/vnc_lite.html?path=qosha-box/gemini-view/ws&autoconnect=1&scale=1&reconnect=0"
_SIGNIN_WORDS = {"busy": "Gemini is answering a chat right now. Try again in a moment.",
                 "gemini_not_connected": "This Qosha has no browser for the Gemini app.",
                 "sign_in_open": "Gemini's sign-in window is still open. Press Done first.",
                 "failed": "The sign-in window could not be opened. Try again."}


def _gemini_app_call(path: str, timeout: float):
    if not _helper():
        return JSONResponse(status_code=404, content={"error": "not_here", "detail": "This Qosha has no Gemini app sign-in."})
    import urllib.error
    try:
        d = _helper_call("POST", path, {}, timeout=timeout)
    except urllib.error.HTTPError as e:
        try:
            err = str(json.loads(e.read()).get("error") or "failed")
        except Exception:
            err = "failed"
        # an ordinary answer: the page shows these words as they are (the pages' own error text for a failed request
        # is general on purpose and would hide them)
        return {"refused": True, "error": err, "detail": _SIGNIN_WORDS.get(err, _SIGNIN_WORDS["failed"])}
    except Exception:
        return {"refused": True, "error": "failed", "detail": _SIGNIN_WORDS["failed"]}
    return d if isinstance(d, dict) else {}


def _after_look(d):
    if isinstance(d, JSONResponse) or d.get("refused"):
        return d
    app = _note_app(d.get("app"))
    _GEM["at"] = float("-inf")                 # the next read of the assistants asks the helper again
    out = {"gemini_app": app, "gemini_chat": _gemini_chat(True)}
    note = _NOTES.get(str(d.get("note") or ""))
    if d.get("note"):
        # the new sign-in was not used; the old one (if any) is as it was. SIGNIN2: the words say why, and whether
        # "Check again" can still use it
        out["note"] = (app.get("last") or {}).get("words") or note or _NOTES["failed"]
    return out


_NOTES = {"other_account": "That sign-in was not used: Gemini here must be signed in with your own Qosha address.",
          "signed_out": "That sign-in was not finished: nobody is signed in to Google in the window. Try again.",
          "failed": "That sign-in could not be checked. Try again."}


@router.post("/gemini/signin/done")
def gemini_signin_done():
    return _after_look(_gemini_app_call("/v1/signin/done", 220))


@router.post("/gemini/look")
def gemini_look():
    return _after_look(_gemini_app_call("/v1/look", 220))
