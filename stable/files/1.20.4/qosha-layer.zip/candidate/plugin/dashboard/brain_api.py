"""The assistant's main brain (UAT 2 Nov). Mounted at /api/plugins/qosha/brain.

GET  /   the engine's main model setting in plain words, and what can be chosen:
         {"provider", "model", "effort", "label", "providers": [{"id", "name", "models": [{"id", "label",
         "efforts": [{"id", "label"}]}]}], "defaults": {"anthropic": {...}, "openai-codex": {...}}, "note"}
POST /   {"provider", "model", "effort"}: saves it as the engine's main model (model.provider/model.default, the
         engine's own assignment helpers) and its reasoning effort (agent.reasoning_effort). New chats, the home's
         main ask, projects and automations use it; a chat already open keeps its model.

Only Claude (provider anthropic) and ChatGPT (provider openai-codex) can be the main brain, and only when the
engine lists that provider as signed in on this computer; models are the ones the engine's own catalogue lists for that
account. Gemini answers in Ask Gemini and Ask All only (text only, no tools). Whatever the brain, every
tool step still goes through the same approval guard (pre_tool_call hook): this route only picks the model.
Nothing else in the config changes. The save works on the raw config file (the engine's own write-back primitives):
the whole expected file is computed first, the file must still be as it was read (else 409, someone else changed it),
it is written with the engine's comment-preserving atomic writer, read back and compared as a whole; any difference or
error, also while reading the result back, puts the previous bytes (or the absence of the file) back, unless someone
else has written the file after us (then nothing is put over their change and the person is told); the restore itself
is checked. The engine has no lock shared by its config writers (its Models page and chat gateway write the same way),
so a write landing in the instant between our last check and our atomic rename can be lost, exactly as between the
engine's own writers; every other interleaving is refused or rolled back.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import re
import stat
import threading
from pathlib import Path

from fastapi import APIRouter, Body
from fastapi.responses import JSONResponse

router = APIRouter()
_LOCK = threading.Lock()

NAMES = {"anthropic": "Claude", "openai-codex": "ChatGPT"}
EFFORT_NAMES = {"low": "Low", "medium": "Medium", "high": "High", "xhigh": "Extra high", "max": "Max"}
EFFORT_ORDER = ("low", "medium", "high", "xhigh", "max")
PREFERRED = {"anthropic": "claude-opus-5-5", "openai-codex": "gpt-6.1-sol"}
DEFAULT_EFFORT = "medium"   # the engine's own default when agent.reasoning_effort is unset
NOTE = "Gemini answers questions in Ask Gemini and Ask All, but it can’t take actions for you (like reading your email or adding a task), so it can’t be the main assistant."
_FAMILY = {"fable": 0, "opus": 1, "sonnet": 2, "haiku": 3}


def model_label(provider: str, model: str) -> str:
    """Plain model names: claude-opus-5-5 → "Opus 5.5", gpt-6.1-sol → "GPT-6.1 Sol", gpt-5.6-sol-900k → "GPT-5.6 Sol (900K)"."""
    m = str(model or "")
    if provider == "anthropic":
        r = re.match(r"^claude-([a-z]+)-(\d+)(?:-(\d{1,2}))?(?:-\d{8})?$", m)
        if r:
            return "%s %s%s" % (r.group(1).title(), r.group(2), "." + r.group(3) if r.group(3) else "")
    if provider == "openai-codex":
        r = re.match(r"^gpt-(\d+(?:\.\d+)?)(?:-([a-z]+))?(?:-(\d+k))?$", m)
        if r:
            return "GPT-%s%s%s" % (r.group(1), " " + r.group(2).title() if r.group(2) else "",
                                   " (%s)" % r.group(3).upper() if r.group(3) else "")
    return m


def _claude_key(model: str):
    r = re.match(r"^claude-([a-z]+)-(\d+)(?:-(\d{1,2}))?(?:-\d{8})?$", model)
    if not r:
        return (1, 0, 0, 9, model)
    return (0, -int(r.group(2)), -int(r.group(3) or 0), _FAMILY.get(r.group(1), 9), model)


def efforts_for(provider: str, model: str) -> list:
    """Effort levels the engine sends for this model (from the engine's own helpers); none if they can't be read."""
    ids = ["low", "medium", "high"]
    try:
        if provider == "openai-codex":
            from agent.reasoning_effort import codex_supported_efforts
            ids = [e for e in EFFORT_ORDER if e in codex_supported_efforts(model)]
        elif provider == "anthropic":
            from agent import anthropic_adapter as aa
            if aa._supports_xhigh_effort(model):
                ids.append("xhigh")
            if aa._supports_adaptive_thinking(model):
                ids.append("max")
    except Exception:
        return []
    return [{"id": e, "label": EFFORT_NAMES[e]} for e in EFFORT_ORDER if e in ids]


# The models offered are a fixed, local list (c18 final gate: building the engine's live catalogue made it look for
# credentials and reach the network). These are models the lab's own accounts served on 2 Nov 2026 (the engine's
# catalogue, read once by hand); the model already in the config is always offered too.
OFFERED = {"anthropic": ["claude-opus-5-5", "claude-sonnet-5-5", "claude-haiku-5-5"],
           "openai-codex": ["gpt-6.1-sol", "gpt-6.1-terra", "gpt-6-astra"]}


def _chatgpt_signed_in() -> bool:
    """The lab's own ChatGPT sign-in exists in its auth store (a local file read; no lookup, no network)."""
    try:
        from hermes_constants import get_hermes_home
        store = json.loads((Path(get_hermes_home()) / "auth.json").read_text(encoding="utf-8"))
    except Exception:
        return False
    pool = (store.get("credential_pool") or {}).get("openai-codex") or []
    tokens = ((store.get("providers") or {}).get("openai-codex") or {}).get("tokens") or {}
    return bool(pool) or bool(tokens.get("access_token") or tokens.get("refresh_token"))


def _engine_catalogue() -> dict:
    """{"providers": [...]} from the fixed list (Claude always; ChatGPT when signed in on this computer). Tests point
    QOSHA_BRAIN_CATALOG_FILE at a fixed catalogue instead."""
    fixture = os.environ.get("QOSHA_BRAIN_CATALOG_FILE", "").strip()
    # test runs only: never in the lab (qoshalab sets QOSHA_LAB=1 for every lab process)
    if fixture and os.environ.get("QOSHA_BRAIN_TEST") == "1" and os.environ.get("QOSHA_LAB") != "1":
        return json.loads(Path(fixture).read_text(encoding="utf-8"))
    cur = current()
    providers = []
    for pid in ("anthropic", "openai-codex"):
        models = list(OFFERED[pid])
        if cur["provider"] == pid and cur["model"] and cur["model"] not in models:
            models.insert(0, cur["model"])
        providers.append({"slug": pid, "authenticated": True if pid == "anthropic" else _chatgpt_signed_in(), "models": models})
    return {"providers": providers}


_LIVE_NAMES: dict = {}   # provider slug -> its name, from the engine's own picker (local installs)


def _local() -> bool:
    return not os.environ.get("QOSHA_BOX") and not os.environ.get("QOSHA_LAB")


def _live_catalogue() -> dict:
    """Local installs (Ren, 17 Nov: "everything our chatbox offers working"; OpenRouter on as in the engine): every
    provider the engine's own model picker lists as signed in, with the engine's full model list for each."""
    from hermes_cli.inventory import build_model_options_payload, load_picker_context
    payload = build_model_options_payload(load_picker_context(), explicit_only=False, include_unconfigured=False,
                                          refresh=False)
    out = {}
    for p in payload.get("providers") or []:
        slug = str(p.get("slug") or "")
        models = [m if isinstance(m, str) else str((m or {}).get("id") or "") for m in (p.get("models") or [])]
        models = [m for m in models if m]
        if slug and p.get("authenticated") and models:
            out[slug] = models
            _LIVE_NAMES[slug] = str(p.get("name") or slug)
    return out


def name_of(pid: str) -> str:
    return NAMES.get(pid) or _LIVE_NAMES.get(pid) or pid


def catalogue() -> dict:
    """{provider: [model ids]}: on a local install, every provider signed in there (the engine's own list); on the
    lab and boxes, Claude and ChatGPT only, as before."""
    if _local():
        try:
            live = _live_catalogue()
            if live:
                if "anthropic" in live:
                    live["anthropic"] = sorted(live["anthropic"], key=_claude_key)
                return live
        except Exception:
            pass
    out = {}
    for p in (_engine_catalogue() or {}).get("providers") or []:
        slug = str((p or {}).get("slug") or "")
        if slug not in NAMES or not p.get("authenticated"):
            continue
        models = [m for m in (p.get("models") or []) if isinstance(m, str) and m]
        if slug == "anthropic":
            models = sorted(models, key=_claude_key)
        if models:
            out[slug] = models
    return out


def _load():
    from hermes_cli.config import load_config
    return load_config()


def current() -> dict:
    cfg = _load()
    mc = cfg.get("model")
    provider = str(mc.get("provider") or "") if isinstance(mc, dict) else ""
    model = str((mc.get("default") or mc.get("name") or "") if isinstance(mc, dict) else (mc or ""))
    agent = cfg.get("agent") if isinstance(cfg.get("agent"), dict) else {}
    effort = agent.get("reasoning_effort")
    effort = str(effort).strip().lower() if isinstance(effort, str) and effort.strip() else DEFAULT_EFFORT
    return {"provider": provider, "model": model, "effort": effort}


def _order(cat: dict) -> list:
    first = [p for p in ("anthropic", "openai-codex", "openrouter") if p in cat]
    return first + sorted(p for p in cat if p not in first)


def label(provider: str, model: str, effort: str) -> str:
    if provider in _LIVE_NAMES and provider not in NAMES:
        return "%s · %s · %s" % (name_of(provider), model_label(provider, model), EFFORT_NAMES.get(effort, effort.title()))
    if provider not in NAMES:
        return "Another model (%s)" % model if model else "Not chosen yet"
    return "%s · %s · %s" % (NAMES[provider], model_label(provider, model), EFFORT_NAMES.get(effort, effort.title()))


def summary() -> dict:
    """The setting in plain words, from config.yaml only (no model list, no lookups): for the home page's status read."""
    cur = current()
    defaults = {}
    for pid in NAMES:
        defaults[pid] = {"model": cur["model"], "effort": cur["effort"]} if cur["provider"] == pid and cur["model"] \
            else {"model": PREFERRED[pid], "effort": None}
    return dict(cur, label=label(cur["provider"], cur["model"], cur["effort"]), defaults=defaults)


# How each assistant is signed in on this lab, in the Provider picker's words (2 Nov: "Provider shows how it
# is signed in"). Claude and ChatGPT use subscription sign-ins, not paid API keys; ChatGPT was signed in to
# the Qosha AI workspace (10:30); Gemini answers through the connector's signed-in Gemini, text only (D17/D18).
SIGNIN = {"anthropic": "Claude subscription", "openai-codex": "ChatGPT · Qosha AI workspace",
          "gemini": "Gemini · Google sign-in on this computer"}


def home() -> dict:
    """For the Home composer, inside the page's own status read (no extra request on load): the setting in plain words
    plus the choices its pickers offer. The choices are the fixed local list (no lookups, no network)."""
    d = summary()
    try:
        cat = catalogue()
        d["providers"] = [{"id": pid, "name": name_of(pid), "signin": SIGNIN.get(pid, name_of(pid)),
                           "models": [{"id": m, "label": model_label(pid, m), "efforts": efforts_for(pid, m)} for m in cat[pid]]}
                          for pid in _order(cat)]
    except Exception:
        d["providers"] = None   # the pickers show the setting only; nothing is offered that can't be checked
    d["signin"] = dict(SIGNIN)
    if os.environ.get("QOSHA_BOX") == "1":   # the cloud box: Gemini is Qosha's own (Vertex AI, council D38)
        d["signin"]["gemini"] = "Gemini · provided by Qosha"
    return d


def state() -> dict:
    cur = current()
    cat = catalogue()
    providers = [{"id": pid, "name": name_of(pid),
                  "models": [{"id": m, "label": model_label(pid, m), "efforts": efforts_for(pid, m)} for m in cat[pid]]}
                 for pid in _order(cat)]
    defaults = {}
    for pid, models in cat.items():
        if cur["provider"] == pid and cur["model"] in models:
            defaults[pid] = {"model": cur["model"], "effort": cur["effort"]}
        else:
            defaults[pid] = {"model": PREFERRED[pid] if PREFERRED.get(pid) in models else models[0], "effort": None}
    return dict(cur, label=label(cur["provider"], cur["model"], cur["effort"]), providers=providers,
                defaults=defaults, note=NOTE)


@router.get("")
@router.get("/")
def get_brain():
    try:
        return state()
    except Exception:
        return JSONResponse({"error": "brain_unavailable", "message": "The assistant's settings could not be read."}, status_code=503)


def _canon(d) -> str:
    return json.dumps(d, sort_keys=True, default=str)


def _put_back(path: Path, before, mode) -> None:
    """The file exactly as it was: its bytes and mode, or no file at all."""
    if before is None:
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        return
    tmp = path.with_name("." + path.name + ".qosha-restore-%d" % os.getpid())
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode or 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(before)
        os.fchmod(f.fileno(), mode or 0o600)
    os.replace(tmp, path)


def _read(path: Path):
    try:
        return path.read_bytes()
    except FileNotFoundError:
        return None


@router.post("")
@router.post("/")
def set_brain(body: dict = Body(...)):
    body = body if isinstance(body, dict) else {}
    provider = str(body.get("provider") or "")
    model = str(body.get("model") or "")
    effort = str(body.get("effort") or "").lower()
    if provider not in NAMES and not _local():
        return JSONResponse({"error": "provider_not_allowed",
                             "message": "Only Claude or ChatGPT can be the main assistant. " + NOTE}, status_code=400)
    try:
        cat = catalogue()
    except Exception:
        return JSONResponse({"error": "catalogue_unavailable", "message": "The list of models could not be read."}, status_code=503)
    if provider not in cat:
        return JSONResponse({"error": "not_signed_in", "message": name_of(provider) + " is not signed in on this computer."}, status_code=409)
    if model not in cat[provider]:
        return JSONResponse({"error": "model_not_offered", "message": "That model isn’t offered for this account."}, status_code=400)
    if effort not in [e["id"] for e in efforts_for(provider, model)]:
        return JSONResponse({"error": "effort_not_offered", "message": "That effort level isn’t offered for this model."}, status_code=400)
    if _local() and not hasattr(__import__("hermes_cli.web_server", fromlist=["x"]), "_apply_main_model_assignment"):
        # engine v0.22+: its own main-model save (POST /api/model/set's code), then the effort through its config writer
        try:
            import asyncio
            from hermes_cli.web_models import ModelAssignment
            from hermes_cli.web_routers.models import set_model_assignment
            r = asyncio.run(set_model_assignment(ModelAssignment(scope="main", provider=provider, model=model,
                                                                 reasoning_effort=effort, confirm_expensive_model=True)))
            if isinstance(r, dict) and r.get("ok") is False:
                return JSONResponse({"error": "not_saved", "message": "Not saved: " + str(r.get("confirm_message") or r.get("error") or "")[:200]}, status_code=409)
            got = current()
            if (got["provider"], got["model"]) != (provider, model):
                return JSONResponse({"error": "not_saved", "message": "Not saved: the engine kept another model."}, status_code=500)
            if got["effort"] != effort:
                # engine v0.23's main assignment keeps the old effort (it takes one only for helper models): write it
                from hermes_cli.config import get_config_path
                from hermes_cli.config_backend import write_config_key
                write_config_key(get_config_path(), "agent.reasoning_effort", effort)
                if current()["effort"] != effort:
                    return JSONResponse({"error": "not_saved", "message": "Not saved: the effort level stayed the same."}, status_code=500)
            return state()
        except Exception as exc:
            return JSONResponse({"error": "not_saved", "message": "Not saved (%s)." % type(exc).__name__}, status_code=500)
    try:
        from hermes_cli.config import get_config_path, read_user_config_raw
        from utils import atomic_roundtrip_yaml_save
        import hermes_cli.web_server as ws   # the engine's own main-model assignment helpers (its Models page path)
    except Exception:
        return JSONResponse({"error": "not_saved", "message": "Not saved: the assistant's settings can’t be changed right now."}, status_code=503)
    with _LOCK:
        path = Path(get_config_path())
        before = _read(path)
        mode = stat.S_IMODE(os.stat(path).st_mode) if before is not None else None
        try:
            raw = read_user_config_raw(path) if before is not None else {}
            expected = copy.deepcopy(raw)
            provider_n, model_n = ws._normalize_main_model_assignment(provider, model)
            if (provider_n, model_n) != (provider, model):
                return JSONResponse({"error": "model_not_offered", "message": "That model isn’t offered for this account."}, status_code=400)
            expected["model"] = ws._apply_main_model_assignment(copy.deepcopy(raw.get("model") or {}), provider_n, model_n)
            agent = copy.deepcopy(raw.get("agent")) if isinstance(raw.get("agent"), dict) else {}
            agent["reasoning_effort"] = effort
            expected["agent"] = agent
        except Exception:
            return JSONResponse({"error": "not_saved", "message": "Not saved: the assistant's settings can’t be changed right now."}, status_code=500)
        # the new file is prepared beside the real one first, so its exact bytes are known before it is published
        tmp = path.with_name("." + path.name + ".qosha-new-%d" % os.getpid())
        try:
            if os.path.lexists(tmp):
                os.unlink(tmp)
            if before is not None:
                fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode or 0o600)
                with os.fdopen(fd, "wb") as f:
                    f.write(before)
            atomic_roundtrip_yaml_save(tmp, expected)
            if before is not None:
                os.chmod(tmp, mode)
            candidate = tmp.read_bytes()
            if _canon(read_user_config_raw(tmp)) != _canon(expected):
                raise ValueError("the prepared file holds more than the change")
        except Exception:
            _drop(tmp)
            return JSONResponse({"error": "not_saved", "message": "Not saved: the new settings could not be prepared. Nothing was changed."}, status_code=500)
        published = False
        try:
            if _read(path) != before:
                return JSONResponse({"error": "conflict", "message": "Not saved: the settings changed meanwhile. Try again."}, status_code=409)
            os.replace(tmp, path)
            published = True
        except Exception:
            return JSONResponse({"error": "not_saved", "message": "Not saved: the settings file could not be replaced. Nothing was changed."}, status_code=500)
        finally:
            if not published:
                _drop(tmp)
        try:
            if _read(path) != candidate:
                raise ValueError("someone else wrote the file after us")
            if _canon(read_user_config_raw(path)) != _canon(expected):
                raise ValueError("the file holds more than the change")
            got = current()
            if (got["provider"], got["model"], got["effort"]) != (provider, model, effort):
                raise ValueError("read back something else")
            # which file this save replaced and which it wrote (sha256), so a caller can later tell its own write apart
            return dict(state(), revision={"before": hashlib.sha256(before).hexdigest() if before is not None else None,
                                           "after": hashlib.sha256(candidate).hexdigest()})
        except Exception:
            return _undo(path, before, mode, candidate)


def _drop(tmp: Path) -> None:
    try:
        os.unlink(tmp)
    except OSError:
        pass


def _undo(path: Path, before, mode, candidate: bytes):
    """Put the previous file back, but only if what is there now is exactly the file this save published: a write by
    someone else after ours is never overwritten (then the person is told). If that can't be checked, or the restore
    fails, the file is left as it is and the answer says so. The result is checked."""
    try:
        now = _read(path)
    except Exception:
        return JSONResponse({"error": "not_restored", "message": "Not saved, and the settings file could not be checked or put back. Open Settings → Config to check the main model."}, status_code=500)
    if now != candidate:
        return JSONResponse({"error": "conflict", "message": "Not saved: the settings were changed by something else at the same time; nothing was put back over that change. Check the main assistant and try again."}, status_code=409)
    try:
        _put_back(path, before, mode)
        if _read(path) != before:
            raise OSError("restore check failed")
    except Exception:
        return JSONResponse({"error": "not_restored", "message": "Not saved, and the settings file could not be put back as it was. Open Settings → Config to check the main model."}, status_code=500)
    return JSONResponse({"error": "not_saved", "message": "Not saved: the settings file would have changed in other places, so it was put back as it was."}, status_code=500)
