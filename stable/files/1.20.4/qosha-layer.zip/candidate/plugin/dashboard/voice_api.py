"""Qosha's natural on-device voice for read-aloud. Mounted at /api/plugins/qosha/voice.

GET  /status            {"available": bool, "engine": "kokoro"}
POST /speak {text,lang?} audio/wav of that one sentence, made on this computer (nothing is sent anywhere)

The voice runs in its own small Python environment (kokoro-onnx), as one worker process that keeps the model loaded
(qosha_guard/voice_worker.py). Where it lives is written at install time in <home>/qosha/voice.json:
    {"python": "<tts env python>", "model": "<kokoro .onnx>", "voices": "<voices .bin>"}
No file, or a worker that won't start: "available" is false and the page falls back to the browser's own voice.
The language follows the text: Portuguese and Spanish are recognised by their common words and letters, else English.
"""
from __future__ import annotations

import base64
import json
import re
import subprocess
import threading
import time
from pathlib import Path

from fastapi import APIRouter, Body
from fastapi.responses import JSONResponse, Response

router = APIRouter()
_LOCK = threading.Lock()
_W = {"proc": None, "failed_at": 0.0}
WORKER = Path(__file__).resolve().parent.parent / "qosha_guard" / "voice_worker.py"

_PT = re.compile(r"\b(você|voce|não|nao|obrigad[oa]|está|estao|estão|uma?|para|com|que|isso|aqui|hoje|amanhã|também|tudo bem|olá|oi|fatura|reunião|agenda|sim|por favor|quer|vou|seu|sua)\b|[ãõç]", re.I)
_ES = re.compile(r"\b(usted|gracias|está|están|una?|para|con|que|esto|aquí|hoy|mañana|también|hola|factura|reunión|sí|por favor|quiere|voy|tu|el|los|las|del)\b|[ñ¿¡]", re.I)
_EN = re.compile(r"\b(the|and|you|your|is|are|this|that|with|for|have|what|will|can|here|today)\b", re.I)


_LAST = {"lang": "en"}


def detect(text: str) -> str:
    """The language of this sentence; a sentence with no clear sign ("Ok.", a name, a number) keeps the language of
    the one before it, so the voice does not change in the middle of an answer."""
    pt, es, en = len(_PT.findall(text)), len(_ES.findall(text)), len(_EN.findall(text))
    top = max(pt, es, en)
    if top == 0 or [pt, es, en].count(top) > 1:
        if pt == es == top and top > en and _LAST["lang"] == "en":
            _LAST["lang"] = "pt"   # words shared by Portuguese and Spanish, no earlier sign: Portuguese
        return _LAST["lang"]
    _LAST["lang"] = "pt" if pt == top else ("es" if es == top else "en")
    return _LAST["lang"]


def _cfg():
    try:
        from hermes_constants import get_hermes_home
        d = json.loads((Path(get_hermes_home()) / "qosha" / "voice.json").read_text(encoding="utf-8"))
        if all(Path(str(d.get(k) or "")).is_file() for k in ("python", "model", "voices")):
            return d
    except Exception:
        pass
    return None


def _worker():
    """The running worker, started on first use; None when there is no voice here."""
    p = _W["proc"]
    if p is not None and p.poll() is None:
        return p
    if time.time() - _W["failed_at"] < 60:
        return None
    cfg = _cfg()
    if not cfg or not WORKER.is_file():
        return None
    try:
        import os
        env = {k: v for k, v in os.environ.items() if not k.startswith(("PYTHON", "VIRTUAL_ENV", "UV_"))}   # the voice has its own Python
        log = open(Path(cfg["model"]).parent / "voice-worker.log", "ab")
        p = subprocess.Popen([cfg["python"], "-I", str(WORKER), cfg["model"], cfg["voices"]], stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=log, text=True, bufsize=1, env=env, cwd=str(Path(cfg["model"]).parent))
        first = p.stdout.readline()
        if '"ready"' not in first:
            p.kill()
            raise RuntimeError("worker did not start: " + first[:120])
        _W["proc"] = p
        return p
    except Exception as exc:
        _W["failed_at"] = time.time(); _W["why"] = type(exc).__name__ + ": " + str(exc)[:200]
        return None


@router.get("/status")
def status():
    ok = _cfg() is not None
    if ok and _W["proc"] is None and not _W.get("warming"):   # the page asks when voice starts: load the voice now, not at the first sentence
        _W["warming"] = True

        def _warm():
            try:
                with _LOCK:
                    _worker()
            finally:
                _W["warming"] = False
        threading.Thread(target=_warm, daemon=True).start()
    return {"available": ok, "engine": "kokoro", "running": bool(_W["proc"] is not None and _W["proc"].poll() is None), "why": _W.get("why")}


@router.post("/speak")
def speak(body: dict = Body(...)):
    text = str((body or {}).get("text") or "").strip()
    if not text or len(text) > 1200:
        return JSONResponse({"error": "bad_text"}, status_code=400)
    lang = str((body or {}).get("lang") or "") or detect(text)
    with _LOCK:   # one sentence at a time through the one worker
        p = _worker()
        if p is None:
            return JSONResponse({"error": "no_voice"}, status_code=503)
        try:
            p.stdin.write(json.dumps({"id": 1, "text": text, "lang": lang}) + "\n"); p.stdin.flush()
            r = json.loads(p.stdout.readline() or "{}")
        except Exception:
            _W["proc"] = None
            return JSONResponse({"error": "voice_stopped"}, status_code=503)
    if not r.get("ok"):
        return JSONResponse({"error": "voice_failed"}, status_code=500)
    return Response(content=base64.b64decode(r["wav_b64"]), media_type="audio/wav",
                    headers={"Cache-Control": "no-store", "X-Qosha-Voice": str(r.get("voice")), "X-Qosha-Voice-Ms": str(r.get("ms")), "X-Qosha-Voice-Lang": lang})
