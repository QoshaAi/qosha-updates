"""Projects for the Qosha Projects page (UAT 2 Nov; council C9 → D20). Mounted at /api/plugins/qosha/projects.

A project is a record in the engine's own projects store (<lab home>/projects.db: name, description, archived), with
its own folder <files root>/Projects/<slug>/ inside the lab's locked files folder (HERMES_DASHBOARD_FILES_ROOT). Its
instructions are <folder>/.hermes.md, which the engine itself loads into the system prompt of every chat (and
automation, through its workdir) whose working folder is the project folder. Its chats are the sessions started with
that folder as their cwd. The two options, helpers (agents) and programmed tasks, are off by default, kept in the
store's project_meta, and enforced outside the model by the Qosha guard (qosha_guard/projects_scope.py). Programmed
tasks can't be switched on yet: the lab runs no scheduler, and the guard refuses scheduled work in the lab's folders.

GET    ""               {"projects": [...]} (?archived=1 for the archived ones)
POST   ""               {"name", "description", "instructions"} → the new project
GET    /{id}            {"id","slug","name","description","instructions","files_dir","archived","agents","tasks"}
PATCH  /{id}            any of name, description, instructions, agents, tasks, archived
GET    /{id}/files      the project folder's files (never another folder; the instructions file is not listed)
GET    /{id}/chats      {"chats": [...]}: sessions whose working folder is exactly the project folder

Folders are created and the instructions file written relative to directory descriptors opened without following
links, so a link planted in the files folder can't redirect a write. Nothing is ever deleted here (archive only).
"""
from __future__ import annotations

import errno
import os
if os.name == "nt":   # Qosha on Windows: stand-in for folder descriptors (qosha_winfd.py in the plugin folder)
    import sys as _wsys, importlib.util as _wilu
    _wmod = _wsys.modules.get("qosha_winfd")
    if _wmod is None:
        _wspec = _wilu.spec_from_file_location("qosha_winfd", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "qosha_winfd.py"))
        _wmod = _wilu.module_from_spec(_wspec)
        _wsys.modules["qosha_winfd"] = _wmod
        _wspec.loader.exec_module(_wmod)
    os = _wmod.OS
import re
import secrets
import stat
import sys
import importlib.util
from pathlib import Path

from fastapi import APIRouter, Body
from fastapi.responses import JSONResponse

router = APIRouter()
ROOT_ENV = "HERMES_DASHBOARD_FILES_ROOT"
FOLDER = "Projects"
INSTRUCTIONS = ".hermes.md"          # the engine's own per-folder instructions file (agent/prompt_builder.py)
ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,80}$")
SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")
CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
MAX_NAME, MAX_DESC, MAX_INSTR = 80, 500, 20000
OPTIONS = ("agents", "tasks")
_DIR_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0)


class Refused(Exception):
    def __init__(self, status: int, error: str, detail: str):
        super().__init__(detail)
        self.status, self.error, self.detail = status, error, detail


def _answer(exc: Refused) -> JSONResponse:
    return JSONResponse(status_code=exc.status, content={"error": exc.error, "detail": exc.detail})


def meta_key(pid: str, option: str) -> str:
    return "qosha.project.%s.%s" % (pid, option)


def files_root() -> str:
    """The locked files folder, computed exactly as the Files routes do (its parent resolved)."""
    raw = os.environ.get(ROOT_ENV, "").strip()
    if not raw or not os.path.isabs(raw):
        raise Refused(503, "not_set_up", "The Qosha files folder is not set up on this computer.")
    raw = raw.rstrip("/")
    return os.path.join(os.path.realpath(os.path.dirname(raw)), os.path.basename(raw))


def project_dir(root: str, slug: str) -> str:
    if not SLUG_RE.match(slug or ""):
        raise Refused(500, "bad_slug", "This project's folder name is not valid.")
    return root + "/" + FOLDER + "/" + slug


def _open_parent(root: str, create: bool) -> int:
    """root/Projects, opened without following a link (created when asked)."""
    try:
        if create and not os.path.lexists(root):
            os.makedirs(root, 0o755, exist_ok=True)
        fd = os.open(root, _DIR_FLAGS)
    except OSError:
        raise Refused(503, "not_set_up", "The Qosha files folder is not available.")
    try:
        if create:
            try:
                os.mkdir(FOLDER, 0o755, dir_fd=fd)
            except FileExistsError:
                pass
        try:
            nfd = os.open(FOLDER, _DIR_FLAGS, dir_fd=fd)
        except OSError as exc:
            if exc.errno == errno.ENOENT:
                raise Refused(404, "no_folder", "This project's folder is missing.")
            if exc.errno in (errno.ELOOP, errno.ENOTDIR):
                raise Refused(409, "not_a_folder", "The Projects folder has been replaced by a shortcut; nothing was "
                                                   "read or written there.")
            raise Refused(500, "unavailable", "The Projects folder could not be opened.")
        return nfd
    finally:
        os.close(fd)


def ident(fd: int) -> str:
    st = os.fstat(fd)
    return "%d:%d" % (st.st_dev, st.st_ino)


def _open_project_dir(root: str, slug: str, create: bool, expect: str = "") -> int:
    """root/Projects/<slug>, each step opened relative to the last and never through a link; when the folder's identity
    was recorded at creation, a different folder put in its place is refused (GPT R-projects1)."""
    fd = _open_project_dir_raw(root, slug, create)
    if expect and ident(fd) != expect:
        os.close(fd)
        raise Refused(409, "replaced", "This project's folder was replaced outside Qosha, so nothing was read or written "
                                       "there. Its files may have been moved; create a new project if needed.")
    return fd


def _open_project_dir_raw(root: str, slug: str, create: bool) -> int:
    if not SLUG_RE.match(slug or ""):
        raise Refused(500, "bad_slug", "This project's folder name is not valid.")
    fd = _open_parent(root, create)
    try:
        if create:
            try:
                os.mkdir(slug, 0o755, dir_fd=fd)
            except FileExistsError:
                pass
        try:
            return os.open(slug, _DIR_FLAGS, dir_fd=fd)
        except OSError as exc:
            if exc.errno == errno.ENOENT:
                raise Refused(404, "no_folder", "This project's folder is missing.")
            if exc.errno in (errno.ELOOP, errno.ENOTDIR):
                raise Refused(409, "not_a_folder", "This project's folder has been replaced by a shortcut; "
                                                   "nothing was read or written there.")
            raise Refused(500, "unavailable", "This project's folder could not be opened.")
    finally:
        os.close(fd)


def _new_folder(conn, root: str, name: str):
    """A slug whose folder this call creates itself: a folder that already exists (made by someone else, perhaps with
    planted instructions) is never adopted by a new project."""
    pdb = _pdb()
    base = pdb._slugify(name)
    if not SLUG_RE.match(base):
        raise Refused(400, "bad_name", "Choose a name with some letters or numbers.")
    fd = _open_parent(root, create=True)
    try:
        for n in range(1, 200):
            sfx = "" if n == 1 else "-%d" % n
            slug = (base[: 64 - len(sfx)]).rstrip("-_") + sfx
            if conn.execute("SELECT 1 FROM projects WHERE slug = ?", (slug,)).fetchone() is not None:
                continue
            try:
                os.mkdir(slug, 0o755, dir_fd=fd)
            except FileExistsError:
                continue
            try:
                return slug, os.open(slug, _DIR_FLAGS, dir_fd=fd)     # the folder made here, kept open
            except OSError:
                raise Refused(409, "replaced", "The new project folder was replaced while it was being made.")
    finally:
        os.close(fd)
    raise Refused(409, "exists", "Too many projects with that name.")


def read_instructions(root: str, slug: str, expect: str = "") -> str:
    try:
        dfd = _open_project_dir(root, slug, create=False, expect=expect)
    except Refused as exc:
        if exc.status == 404:
            return ""
        raise
    try:
        try:
            fd = os.open(INSTRUCTIONS, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | getattr(os, "O_CLOEXEC", 0), dir_fd=dfd)
        except OSError as exc:
            if exc.errno == errno.ENOENT:
                return ""
            raise Refused(409, "not_a_file", "The instructions file has been replaced by a shortcut; save the "
                                             "instructions again to replace it.")
        try:
            if not stat.S_ISREG(os.fstat(fd).st_mode):   # opened without blocking: a planted pipe is refused here
                raise Refused(409, "not_a_file", "The instructions are not a plain file.")
            data = os.read(fd, MAX_INSTR * 4 + 1)
        finally:
            os.close(fd)
        return data.decode("utf-8", "replace")[:MAX_INSTR]
    finally:
        os.close(dfd)


def write_instructions(root: str, slug: str, text: str, expect: str = "", dfd: int = -1) -> None:
    own = dfd < 0
    if own:
        dfd = _open_project_dir(root, slug, create=False, expect=expect)
    try:
        if not text:
            try:
                st = os.stat(INSTRUCTIONS, dir_fd=dfd, follow_symlinks=False)
                if stat.S_ISDIR(st.st_mode):
                    raise Refused(409, "is_folder", "A folder is in the way of the instructions file.")
                os.unlink(INSTRUCTIONS, dir_fd=dfd)       # a link is removed itself, never what it points to
            except FileNotFoundError:
                pass
            return
        tmp = ".qosha-instructions-%s.tmp" % secrets.token_hex(6)
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0), 0o644,
                     dir_fd=dfd)
        try:
            with os.fdopen(fd, "wb", closefd=False) as f:
                f.write(text.encode("utf-8"))
            # the staged file must still be the one written here (not swapped) when it is published
            st_tmp = os.stat(tmp, dir_fd=dfd, follow_symlinks=False)
            st_fd = os.fstat(fd)
            if not stat.S_ISREG(st_tmp.st_mode) or (st_tmp.st_dev, st_tmp.st_ino) != (st_fd.st_dev, st_fd.st_ino):
                raise Refused(409, "replaced", "The instructions were changed while saving; nothing was saved. Try again.")
            try:
                st = os.stat(INSTRUCTIONS, dir_fd=dfd, follow_symlinks=False)
                if stat.S_ISDIR(st.st_mode):
                    raise Refused(409, "is_folder", "A folder is in the way of the instructions file.")
            except FileNotFoundError:
                pass
            os.replace(tmp, INSTRUCTIONS, src_dir_fd=dfd, dst_dir_fd=dfd)   # replaces a link itself, not its target
        except BaseException:
            try:
                os.unlink(tmp, dir_fd=dfd)
            except OSError:
                pass
            raise
        finally:
            os.close(fd)
    finally:
        if own:
            os.close(dfd)


def _pdb():
    from hermes_cli import projects_db
    return projects_db


def _text(value, limit: int, field: str, required: bool = False) -> str:
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise Refused(400, "bad_" + field, "The %s must be text." % field)
    value = value.replace("\r\n", "\n").strip() if field != "instructions" else value.replace("\r\n", "\n").replace("\x00", "")
    if field != "instructions" and CONTROL.search(value):
        raise Refused(400, "bad_" + field, "The %s contains characters that are not allowed." % field)
    if field == "name" and "\n" in value:
        raise Refused(400, "bad_name", "The name must be one line.")
    if required and not value.strip():
        raise Refused(400, "bad_" + field, "Give the project a %s." % field)
    if len(value) > limit:
        raise Refused(400, "too_long", "The %s is too long (at most %d characters)." % (field, limit))
    return value


def _options(conn, pid: str) -> dict:
    out = {}
    for o in OPTIONS:
        row = conn.execute("SELECT value FROM project_meta WHERE key = ?", (meta_key(pid, o),)).fetchone()
        out[o] = bool(row) and row[0] == "1"
    return out


def _set_meta(conn, key: str, value: str) -> None:
    from hermes_cli.sqlite_util import write_txn
    with write_txn(conn):
        conn.execute("INSERT INTO project_meta (key, value) VALUES (?, ?) "
                     "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, value))


def _set_option(conn, pid: str, option: str, on: bool) -> None:
    _set_meta(conn, meta_key(pid, option), "1" if on else "0")


def _find(conn, pid: str):
    if not isinstance(pid, str) or not ID_RE.match(pid):
        raise Refused(404, "not_found", "That project does not exist.")
    for p in _pdb().list_projects(conn, include_archived=True):
        if p.id == pid:                                   # the exact id only (never a slug or a name)
            return p
    raise Refused(404, "not_found", "That project does not exist.")


def _ident_of(conn, pid: str) -> str:
    row = conn.execute("SELECT value FROM project_meta WHERE key = ?", (meta_key(pid, "folder"),)).fetchone()
    return row[0] if row else ""


def _record(conn, p, root: str, with_instructions: bool) -> dict:
    out = {"id": p.id, "slug": p.slug, "name": p.name, "description": p.description or "",
           "archived": bool(p.archived), "created_at": p.created_at, "files_dir": project_dir(root, p.slug)}
    out.update(_options(conn, p.id))
    if with_instructions:
        out["instructions"] = read_instructions(root, p.slug, _ident_of(conn, p.id))
    return out


@router.get("")
def list_projects(archived: str = "0"):
    try:
        root = files_root()
        pdb = _pdb()
        with pdb.connect_closing() as conn:
            want = archived == "1"
            rows = [p for p in pdb.list_projects(conn, include_archived=True) if bool(p.archived) == want]
            rows.sort(key=lambda p: (p.name.lower(), p.created_at))
            return {"projects": [_record(conn, p, root, False) for p in rows]}
    except Refused as exc:
        return _answer(exc)


@router.post("")
def create(body: dict = Body(...)):
    try:
        root = files_root()
        name = _text(body.get("name"), MAX_NAME, "name", required=True)
        desc = _text(body.get("description"), MAX_DESC, "description")
        instr = _text(body.get("instructions"), MAX_INSTR, "instructions")
        pdb = _pdb()
        with pdb.connect_closing() as conn:
            for p in pdb.list_projects(conn, include_archived=False):
                if p.name.strip().lower() == name.strip().lower():
                    raise Refused(409, "exists", "A project with that name already exists.")
            slug, dfd = _new_folder(conn, root, name)            # a fresh folder, never through a link, kept open
            try:
                folder = project_dir(root, slug)
                pid = pdb.create_project(conn, name=name, slug=slug, description=desc or None, primary_path=folder,
                                         folders=[folder], allow_duplicate_path=False)
                for o in OPTIONS:
                    _set_option(conn, pid, o, False)              # off by default
                _set_meta(conn, meta_key(pid, "folder"), ident(dfd))   # later opens must find this very folder
                if instr.strip():
                    write_instructions(root, slug, instr, dfd=dfd)
            finally:
                os.close(dfd)
            return _record(conn, _find(conn, pid), root, True)
    except Refused as exc:
        return _answer(exc)
    except ValueError as exc:
        return _answer(Refused(400, "bad_request", str(exc)[:200]))


@router.get("/{pid}")
def get(pid: str):
    try:
        root = files_root()
        pdb = _pdb()
        with pdb.connect_closing() as conn:
            return _record(conn, _find(conn, pid), root, True)
    except Refused as exc:
        return _answer(exc)


@router.patch("/{pid}")
def update(pid: str, body: dict = Body(...)):
    try:
        root = files_root()
        pdb = _pdb()
        unknown = set(body) - {"name", "description", "instructions", "agents", "tasks", "archived"}
        if unknown:
            raise Refused(400, "bad_request", "Unknown field: " + sorted(unknown)[0][:40])
        with pdb.connect_closing() as conn:
            p = _find(conn, pid)
            # every field is checked before anything changes (GPT R-projects1: no half-applied request)
            name = _text(body["name"], MAX_NAME, "name", required=True) if "name" in body else None
            desc = _text(body["description"], MAX_DESC, "description") if "description" in body else None
            instr = _text(body["instructions"], MAX_INSTR, "instructions") if "instructions" in body else None
            for o in OPTIONS + ("archived",):
                if o in body and not isinstance(body[o], bool):
                    raise Refused(400, "bad_request", "On or off only.")
            if body.get("tasks") is True:
                raise Refused(409, "coming_next", "Programmed tasks inside a project are coming next: this "
                              "pilot's lab doesn't run a scheduler, so they would never start.")
            if name is not None:
                for q in pdb.list_projects(conn, include_archived=False):
                    if q.id != p.id and q.name.strip().lower() == name.strip().lower():
                        raise Refused(409, "exists", "A project with that name already exists.")
            if instr is not None and p.archived and body.get("archived") is not False:
                raise Refused(409, "archived", "Restore the project before changing it.")
            # the project's own folder must still be there before anything changes (GPT R-projects2)
            os.close(_open_project_dir(root, p.slug, create=False, expect=_ident_of(conn, p.id)))
            # then the changes
            if instr is not None:
                write_instructions(root, p.slug, instr, expect=_ident_of(conn, p.id))
            if name is not None or desc is not None:
                pdb.update_project(conn, p.id, name=name, description=desc)
            for o in OPTIONS:
                if o in body:
                    _set_option(conn, p.id, o, body[o])
            if "archived" in body:
                (pdb.archive_project if body["archived"] else pdb.restore_project)(conn, p.id)
            return _record(conn, _find(conn, p.id), root, True)
    except Refused as exc:
        return _answer(exc)
    except ValueError as exc:
        return _answer(Refused(400, "bad_request", str(exc)[:200]))


def _files_module():
    mod = sys.modules.get("qosha_files_api")
    if mod is None:
        path = Path(__file__).with_name("files_api.py")
        spec = importlib.util.spec_from_file_location("qosha_files_api", path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules["qosha_files_api"] = mod
        spec.loader.exec_module(mod)
    return mod


@router.get("/{pid}/files")
def files(pid: str):
    try:
        root = files_root()
        pdb = _pdb()
        with pdb.connect_closing() as conn:
            p = _find(conn, pid)
            ident_ = _ident_of(conn, p.id)
        folder = project_dir(root, p.slug)
        fd = _open_project_dir(root, p.slug, create=False, expect=ident_)   # refuses a replaced folder or a link
        os.close(fd)
        listing = _files_module().listing(path=folder)                    # no-follow listing of exactly this folder
        if isinstance(listing, JSONResponse):
            return listing
        if listing.get("path") != folder:
            raise Refused(500, "unavailable", "The project folder could not be read.")
        return {"files_dir": folder, "entries": listing.get("entries", [])}
    except Refused as exc:
        return _answer(exc)


@router.get("/{pid}/chats")
def chats(pid: str):
    try:
        root = files_root()
        pdb = _pdb()
        with pdb.connect_closing() as conn:
            p = _find(conn, pid)
        folder = project_dir(root, p.slug)
        from hermes_state import SessionDB
        db = SessionDB()
        try:
            rows = db.list_sessions_rich(cwd_prefix=folder, limit=100, offset=0, include_archived=False,
                                         order_by_last_active=True, compact_rows=True)
        finally:
            try:
                db.close()
            except Exception:
                pass
        out = []
        for r in rows:
            cwd = str(r.get("cwd") or "").rstrip("/")
            if cwd != folder:                      # exactly this folder: "alpha" never shows "alpha-2" (Gemini C9)
                continue
            if str(r.get("source") or "") == "cron":
                continue
            out.append({"id": str(r.get("id")), "title": r.get("title") or "",
                        "last_active": r.get("last_active") or r.get("started_at"),
                        "message_count": r.get("message_count")})
        return {"chats": out}
    except Refused as exc:
        return _answer(exc)
