"""Qosha from the first byte (P0, 3 Nov 21:45 MST): the dashboard's index.html (every page: Home, Chat, Files, Skills,
Connections, Settings and the engine's own pages share it) gets Qosha's critical CSS, loading screen and readiness
script before any engine script or stylesheet. The engine's shell stays hidden until index.js marks the page
data-qosha-ready; the loading screen is all that can paint before that. Used by the lab (qoshalab.py brand_web) on
the built screens and by the first-paint gate (tests/c18_first_paint_gate.py) on its throwaway copy. Pure text in,
text out; run again after every web build (it replaces its own earlier block)."""
import re
from pathlib import Path

HEAD = ('<!-- qosha-first-paint -->', '<!-- /qosha-first-paint -->')
BODY = ('<!-- qosha-splash -->', '<!-- /qosha-splash -->')
SPLIT = '<!-- qosha-first-paint:body -->'
BLOCK_FILE = Path(__file__).resolve().parent / 'first-paint.html'


def strip(html):
    """The page without Qosha's first-paint block (as the engine built it, apart from the icons)."""
    for a, b in (HEAD, BODY):
        html = re.sub(r'[ \t]*' + re.escape(a) + r'.*?' + re.escape(b) + r'\n?', '', html, flags=re.S)
    return html


def apply(html, block=None):
    """Qosha's block at the top of <head> (right after the charset) and its loading screen at the top of <body>."""
    block = BLOCK_FILE.read_text(encoding='utf-8') if block is None else block
    head, body = block.split(SPLIT, 1)
    head, body = head.strip(), body.strip()
    if not (head.startswith(HEAD[0]) and head.endswith(HEAD[1]) and body.startswith(BODY[0]) and body.endswith(BODY[1])):
        raise ValueError('first-paint block is not marked')
    html = strip(html)
    html, n = re.subn(r'(<meta charset="[^"]*"\s*/?>)', lambda m: m.group(1) + '\n    ' + head, html, count=1, flags=re.I)
    if not n:
        html, n = re.subn(r'(<head[^>]*>)', lambda m: m.group(1) + '\n    ' + head, html, count=1, flags=re.I)
    html, m = re.subn(r'(<body[^>]*>)', lambda x: x.group(1) + '\n    ' + body, html, count=1, flags=re.I)
    if not n or not m:
        raise ValueError('index.html has no <head> or <body>')
    # nothing of the engine's may come before it: no script, stylesheet or preload above Qosha's block
    top = html[:html.index(HEAD[0])]
    if re.search(r'<script|<link[^>]+rel="(?:stylesheet|modulepreload|preload)"|<style', top, flags=re.I):
        raise ValueError('an engine script or stylesheet sits above the first-paint block')
    return html
