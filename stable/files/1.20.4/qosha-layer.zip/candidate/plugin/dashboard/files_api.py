"""File changes for the Qosha Files page (UAT 2 Nov (2); GPT R-pages rounds 1-2). Mounted at
/api/plugins/qosha/files.

The engine's own upload checks "does the file exist?" and then replaces it, and its delete follows links. The Files
folder is shared with the assistant, which can create files or swap a folder for a link at any moment, so the page's
writes go through these two routes instead. Both work only inside the lab's locked files folder
(HERMES_DASHBOARD_FILES_ROOT), walk it from that folder one directory at a time with no-follow descriptors, and never
write or delete through a link.

GET  /list?path=      one folder: folders, files and shortcuts (links are listed as shortcuts, never followed).
GET  /download?path=  one regular file, opened without following a link and streamed from that descriptor.
POST /mkdir    {"path": "..."}: a new folder, created relative to its parent's descriptor.
POST /upload   multipart form: file, path (absolute, inside the files folder), overwrite ("true" or "false").
               overwrite=false commits with a hard link, which fails if the name exists at that instant: a file that
               appeared meanwhile is never replaced (409).
POST /delete   {"path": "...", "recursive": false}. A link is removed itself, never what it points to; a folder is
               removed entry by entry through descriptors, so a link inside it is never followed.
The engine's own /api/files routes check a resolved pathname and then use the pathname again, so a link swapped in
between could reach outside the folder (GPT R-pages 3); the page uses only these routes.
"""
from __future__ import annotations

import errno
import os
if os.name == "nt":   # Qosha on Windows: stand-in for folder descriptors (qosha_winfd.py in the plugin folder)
    import sys as _wsys, importlib.util as _wilu
    _wmod = _wsys.modules.get("qosha_winfd")
    if _wmod is None:
        _wspec = _wilu.spec_from_file_location("qosha_winfd", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "qosha_winfd.py"))
        _wmod = _wilu.module_from_spec(_wspec)
        _wsys.modules["qosha_winfd"] = _wmod
        _wspec.loader.exec_module(_wmod)
    os = _wmod.OS
import secrets
import stat

from typing import Optional
from urllib.parse import quote

from fastapi import APIRouter, Body, File, Form, UploadFile
from fastapi.responses import JSONResponse, StreamingResponse

router = APIRouter()
ROOT_ENV = "HERMES_DASHBOARD_FILES_ROOT"
MAX_BYTES = 100 * 1024 * 1024   # the engine's own limit for its Files page
CHUNK = 1024 * 1024
# the engine's never-exposed names (hermes_cli/web_server.py _SENSITIVE_MANAGED_*), plus Qosha's own secrets
_SENSITIVE = {".env", ".envrc", "auth.json", "auth.lock", "credentials", "config.yaml", ".anthropic_oauth.json",
              "google_token.json", "google_oauth_pending.json", "google_oauth.json", "webhook_subscriptions.json",
              "bws_cache.json", "bws_cache.enc.json", ".git-credentials", "credentials.json", "connector.key"}
_SENSITIVE_DIRS = {"mcp-tokens", "pairing"}


def _sensitive(name: str) -> bool:
    low = name.lower()
    return low in _SENSITIVE or low.startswith(".env.") or low in _SENSITIVE_DIRS
_DIR_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0)


class Refused(Exception):
    def __init__(self, status: int, error: str, detail: str):
        super().__init__(detail)
        self.status, self.error, self.detail = status, error, detail


def _answer(exc: Refused) -> JSONResponse:
    return JSONResponse(status_code=exc.status, content={"error": exc.error, "detail": exc.detail})


def _root() -> str:
    """The locked files folder, as the engine reports it (its parent resolved), and opened without following a link."""
    raw = os.environ.get(ROOT_ENV, "").strip()
    if not raw or not os.path.isabs(raw):
        raise Refused(503, "not_set_up", "The Qosha files folder is not set up on this computer.")
    raw = raw.rstrip("/")
    return os.path.join(os.path.realpath(os.path.dirname(raw)), os.path.basename(raw))


def _name_ok(name: str) -> bool:
    return bool(name) and name not in (".", "..") and "/" not in name and "\x00" not in name and len(name.encode()) <= 255


def _parts(root: str, path, allow_root: bool = False) -> list:
    """The path's names below the root; refuses anything that is not plainly inside it."""
    if allow_root and (path is None or path == "" or path == root):
        return []
    if not isinstance(path, str) or not path.startswith(root + "/"):
        raise Refused(400, "outside", "Only the Qosha files folder can be used.")
    parts = path[len(root) + 1:].split("/")
    if not all(_name_ok(p) for p in parts):
        raise Refused(400, "bad_path", "That name or path is not allowed.")
    if any(_sensitive(p) for p in parts):
        raise Refused(403, "sensitive", "That item can't be opened here.")
    return parts


def _open_root(root: str) -> int:
    try:
        return os.open(root, _DIR_FLAGS)
    except OSError as exc:
        if exc.errno in (errno.ELOOP, errno.ENOTDIR):
            raise Refused(503, "not_set_up", "The Qosha files folder is not a plain folder.")
        raise Refused(503, "not_set_up", "The Qosha files folder is not available.")


def _open_dir(root: str, parts: list) -> int:
    """A descriptor for root/parts[0]/..., each step opened relative to the last and never through a link."""
    fd = _open_root(root)
    try:
        for p in parts:
            try:
                nfd = os.open(p, _DIR_FLAGS, dir_fd=fd)
            except OSError as exc:
                if exc.errno == errno.ENOENT:
                    raise Refused(404, "not_found", "That folder is no longer there.")
                if exc.errno in (errno.ELOOP, errno.ENOTDIR):
                    raise Refused(409, "not_a_folder", "That is not a folder (it may be a shortcut).")
                raise Refused(500, "unavailable", "The folder could not be opened.")
            os.close(fd)
            fd = nfd
        return fd
    except BaseException:
        os.close(fd)
        raise


def _commit(dfd: int, tmp: str, name: str, overwrite: bool) -> None:
    if not overwrite:
        try:   # linkat fails if the name exists right now: nothing that appeared meanwhile is replaced
            os.link(tmp, name, src_dir_fd=dfd, dst_dir_fd=dfd, follow_symlinks=False)
        except FileExistsError:
            raise Refused(409, "exists", "Something with that name is already here.")
        os.unlink(tmp, dir_fd=dfd)
        return
    try:
        st = os.stat(name, dir_fd=dfd, follow_symlinks=False)
        if stat.S_ISDIR(st.st_mode):
            raise Refused(409, "is_folder", "A folder with that name is already here.")
    except FileNotFoundError:
        pass
    os.replace(tmp, name, src_dir_fd=dfd, dst_dir_fd=dfd)   # replaces a link itself, never the file it points to


@router.post("/upload")
async def upload(file: UploadFile = File(...), path: str = Form(...), overwrite: str = Form("false")):
    dfd = None
    tmp = None
    try:
        root = _root()
        parts = _parts(root, path)
        name = parts[-1]
        if name.startswith(".") or name.lower() in _SENSITIVE:
            raise Refused(400, "bad_name", "That file name is not allowed here.")
        dfd = _open_dir(root, parts[:-1])
        tmp = ".qosha-upload-" + secrets.token_hex(8)
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0), 0o644, dir_fd=dfd)
        total = 0
        with os.fdopen(fd, "wb") as out:
            while True:
                chunk = await file.read(CHUNK)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_BYTES:
                    raise Refused(413, "too_large", "That file is too large (the limit is 100 MB).")
                out.write(chunk)
            out.flush()
            os.fsync(out.fileno())
        _commit(dfd, tmp, name, overwrite.strip().lower() in ("1", "true", "yes"))
        tmp = None
        return {"ok": True, "path": path}
    except Refused as exc:
        return _answer(exc)
    except OSError:
        return _answer(Refused(500, "unavailable", "The file could not be saved."))
    finally:
        if tmp is not None and dfd is not None:
            try:
                os.unlink(tmp, dir_fd=dfd)
            except OSError:
                pass
        if dfd is not None:
            os.close(dfd)
        await file.close()


def _remove_tree(pfd: int, name: str) -> None:
    """Remove pfd/name; a link or file is unlinked itself, a folder is emptied through its own descriptor first."""
    try:
        cfd = os.open(name, _DIR_FLAGS, dir_fd=pfd)
    except OSError as exc:
        if exc.errno in (errno.ELOOP, errno.ENOTDIR):
            os.unlink(name, dir_fd=pfd)
            return
        raise
    try:
        for entry in list(os.scandir(cfd)):
            if entry.is_dir(follow_symlinks=False):
                _remove_tree(cfd, entry.name)
            else:
                os.unlink(entry.name, dir_fd=cfd)
    finally:
        os.close(cfd)
    os.rmdir(name, dir_fd=pfd)


@router.post("/delete")
def delete(body: dict = Body(...)):
    dfd = None
    try:
        root = _root()
        parts = _parts(root, (body or {}).get("path"))
        recursive = (body or {}).get("recursive") is True
        name = parts[-1]
        dfd = _open_dir(root, parts[:-1])
        try:
            st = os.stat(name, dir_fd=dfd, follow_symlinks=False)
        except FileNotFoundError:
            raise Refused(404, "not_found", "That item is no longer there.")
        if not stat.S_ISDIR(st.st_mode):
            os.unlink(name, dir_fd=dfd)   # a file, or a link: the link itself
        elif recursive:
            _remove_tree(dfd, name)
        else:
            try:
                os.rmdir(name, dir_fd=dfd)
            except OSError as exc:
                if exc.errno == errno.ENOTEMPTY:
                    raise Refused(409, "not_empty", "That folder is not empty.")
                raise
        return {"ok": True, "path": body.get("path")}
    except Refused as exc:
        return _answer(exc)
    except OSError:
        return _answer(Refused(500, "unavailable", "That item could not be deleted."))
    finally:
        if dfd is not None:
            os.close(dfd)


def _kind(mode: int) -> str:
    if stat.S_ISDIR(mode):
        return "folder"
    if stat.S_ISREG(mode):
        return "file"
    if stat.S_ISLNK(mode):
        return "link"
    return "other"


@router.get("/list")
def listing(path: Optional[str] = None):
    dfd = None
    try:
        root = _root()
        parts = _parts(root, path, allow_root=True)
        dfd = _open_dir(root, parts)
        here = root + ("/" + "/".join(parts) if parts else "")
        entries = []
        for entry in os.scandir(dfd):
            name = entry.name
            if name.startswith(".") or _sensitive(name):
                continue
            try:
                st = entry.stat(follow_symlinks=False)
            except OSError:
                continue
            kind = _kind(st.st_mode)
            if kind == "other":
                continue
            entries.append({"name": name, "path": here + "/" + name, "kind": kind,
                            "size": st.st_size if kind == "file" else None, "mtime": st.st_mtime})
        return {"root": root, "path": here, "entries": entries}
    except Refused as exc:
        return _answer(exc)
    except OSError:
        return _answer(Refused(500, "unavailable", "The folder could not be read."))
    finally:
        if dfd is not None:
            os.close(dfd)


@router.get("/download")
def download(path: str):
    dfd = None
    fd = None
    try:
        root = _root()
        parts = _parts(root, path)
        dfd = _open_dir(root, parts[:-1])
        try:   # never through a link; O_NONBLOCK so a planted pipe can't hang the request
            fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | getattr(os, "O_CLOEXEC", 0), dir_fd=dfd)
        except OSError as exc:
            if exc.errno == errno.ENOENT:
                raise Refused(404, "not_found", "That file is no longer there.")
            raise Refused(409, "not_a_file", "That is not a file (it may be a shortcut).")
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode):
            raise Refused(409, "not_a_file", "That is not a file.")
        if st.st_size > MAX_BYTES:
            raise Refused(413, "too_large", "That file is too large to download here (the limit is 100 MB).")
        handle, fd = os.fdopen(fd, "rb"), None
        size = st.st_size

        def chunks():   # the file as it was when opened: never more than that size, even if it grows meanwhile
            left = size
            with handle:
                while left > 0:
                    block = handle.read(min(CHUNK, left))
                    if not block:
                        break
                    left -= len(block)
                    yield block

        name = parts[-1]
        return StreamingResponse(chunks(), media_type="application/octet-stream", headers={
            "Content-Disposition": "attachment; filename*=UTF-8''" + quote(name, safe=""),
            "X-Content-Type-Options": "nosniff", "Cache-Control": "no-store"})   # no length: a file cut short meanwhile ends early
    except Refused as exc:
        return _answer(exc)
    except OSError:
        return _answer(Refused(500, "unavailable", "The file could not be read."))
    finally:
        if fd is not None:
            os.close(fd)
        if dfd is not None:
            os.close(dfd)


@router.post("/mkdir")
def mkdir(body: dict = Body(...)):
    dfd = None
    try:
        root = _root()
        parts = _parts(root, (body or {}).get("path"))
        name = parts[-1]
        if name.startswith("."):
            raise Refused(400, "bad_name", "A folder name can't start with a dot.")
        dfd = _open_dir(root, parts[:-1])
        try:
            os.mkdir(name, 0o755, dir_fd=dfd)
        except FileExistsError:
            raise Refused(409, "exists", "Something with that name is already here.")
        return {"ok": True, "path": body.get("path")}
    except Refused as exc:
        return _answer(exc)
    except OSError:
        return _answer(Refused(500, "unavailable", "The folder could not be created."))
    finally:
        if dfd is not None:
            os.close(dfd)


# ---- the file viewer (night job 4: files that behave like Claude's artifacts) -------------------------------------
# /info reports one file (and keeps a version when it changed since the last one), /versions lists them, /version
# returns one, /restore writes one back, /rename renames a file in its folder. Same confinement as above: inside the
# files folder only, walked without following a link, never replacing something that appeared meanwhile.
import hashlib
import importlib.util as _ilu
from pathlib import Path as _Path
from fastapi.responses import Response

VIEW_MAX = 20 * 1024 * 1024     # the viewer opens files up to 20 MB; bigger ones are downloaded instead
_SEEN: dict = {}                # path below the folder -> ((inode, size, mtime_ns), sha256) of its last read


def _versions():
    p = _Path(__file__).resolve().parent.parent / "qosha_guard" / "versions.py"
    if not p.is_file():
        return None
    spec = _ilu.spec_from_file_location("qosha_file_versions", p)
    mod = _ilu.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


try:
    _V = _versions()
except Exception:   # the viewer still opens files; it just keeps no versions
    _V = None


def _file_parts(path):
    root = _root()
    parts = _parts(root, path)
    if any(p.startswith(".") for p in parts):
        raise Refused(400, "bad_path", "That name or path is not allowed.")
    return root, parts


def _stat_file(root, parts):
    dfd = _open_dir(root, parts[:-1])
    try:
        try:
            st = os.stat(parts[-1], dir_fd=dfd, follow_symlinks=False)
        except FileNotFoundError:
            raise Refused(404, "not_found", "That file is no longer there.")
        if not stat.S_ISREG(st.st_mode):
            raise Refused(409, "not_a_file", "That is not a file (it may be a shortcut).")
        return st
    finally:
        os.close(dfd)


@router.get("/info")
def info(path: str):
    try:
        root, parts = _file_parts(path)
        st = _stat_file(root, parts)
        rel = "/".join(parts)
        out = {"name": parts[-1], "path": path, "size": st.st_size, "mtime": st.st_mtime,
               "viewable": st.st_size <= VIEW_MAX, "limit": VIEW_MAX, "versions": []}
        if _V is not None and st.st_size <= _V.MAX_BYTES:
            seen = _SEEN.get(rel)
            stamp = (st.st_ino, st.st_size, st.st_mtime_ns)
            if seen and seen[0] == stamp:   # the viewer asks every 1.5 s: an unchanged file is not read again
                out["sha256"] = seen[1]
            else:
                data = _V.read_confined(root, rel)
                if data is not None:
                    out["sha256"] = hashlib.sha256(data).hexdigest()
                    if len(_SEEN) > 500:
                        _SEEN.clear()
                    _SEEN[rel] = (stamp, out["sha256"])
                    try:
                        _V.record(rel, data, "change")
                    except Exception:
                        pass
            out["versions"] = _V.list_versions(rel)
        return out
    except Refused as exc:
        return _answer(exc)
    except OSError:
        return _answer(Refused(500, "unavailable", "The file could not be read."))


@router.get("/version")
def version(path: str, n: int):
    try:
        root, parts = _file_parts(path)
        data = _V.read_version("/".join(parts), n) if _V is not None else None
        if data is None:
            raise Refused(404, "not_found", "That version is not kept.")
        return Response(content=data, media_type="application/octet-stream",
                        headers={"X-Content-Type-Options": "nosniff", "Cache-Control": "no-store"})
    except Refused as exc:
        return _answer(exc)


@router.post("/restore")
def restore(body: dict = Body(...)):
    dfd = None
    tmp = None
    try:
        root, parts = _file_parts((body or {}).get("path"))
        n = (body or {}).get("n")
        if not isinstance(n, int) or isinstance(n, bool):
            raise Refused(400, "bad_version", "Pick a version to restore.")
        rel = "/".join(parts)
        data = _V.read_version(rel, n) if _V is not None else None
        if data is None:
            raise Refused(404, "not_found", "That version is not kept.")
        # the current bytes must be kept before they are replaced; if that can't be confirmed, nothing is replaced
        # (GPT R-files1/2 MEDIUM)
        cur = _V.read_confined(root, rel)
        st0 = None
        try:
            st0 = _stat_file(root, parts)
        except Refused as exc:
            if exc.status != 404:
                raise
        if st0 is not None and cur is None:   # there but unreadable or over the version limit: never replaced unkept
            raise Refused(409, "too_large", "The current file can't be kept as a version (it may be too large), so nothing was restored.")
        if cur is not None:
            try:
                _V.record(rel, cur, "before restore")
            except Exception:
                pass
            kept = _V.list_versions(rel)
            if not kept or kept[-1].get("sha256") != hashlib.sha256(cur).hexdigest():
                raise Refused(409, "busy", "Qosha could not keep the current file first, so nothing was restored. Try again.")
        dfd = _open_dir(root, parts[:-1])
        tmp = ".qosha-restore-" + secrets.token_hex(8)
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0), 0o644, dir_fd=dfd)
        with os.fdopen(fd, "wb") as out:
            out.write(data)
            out.flush()
            os.fsync(out.fileno())
        if st0 is not None:   # changed since it was kept: refuse rather than overwrite a change no version holds (GPT R-files3)
            try:
                st1 = os.stat(parts[-1], dir_fd=dfd, follow_symlinks=False)
            except FileNotFoundError:
                st1 = None
            if st1 is None or (st1.st_ino, st1.st_size, st1.st_mtime_ns) != (st0.st_ino, st0.st_size, st0.st_mtime_ns):
                raise Refused(409, "changed", "The file changed while Qosha was restoring it, so nothing was restored. Try again.")
        _commit(dfd, tmp, parts[-1], True)   # replaces a link itself, never what it points to; refuses a folder
        tmp = None
        try:
            _V.record(rel, data, "restored")
        except Exception:
            pass
        return {"ok": True, "path": body.get("path"), "versions": _V.list_versions(rel)}
    except Refused as exc:
        return _answer(exc)
    except OSError:
        return _answer(Refused(500, "unavailable", "That version could not be restored."))
    finally:
        if tmp is not None and dfd is not None:
            try:
                os.unlink(tmp, dir_fd=dfd)
            except OSError:
                pass
        if dfd is not None:
            os.close(dfd)


def _renameatx():
    try:
        import ctypes
        import ctypes.util
        libc = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True)
        fn = libc.renameatx_np
        fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        fn.restype = ctypes.c_int
        return fn, ctypes
    except Exception:
        return None, None


_RENAMEATX, _CT = _renameatx()
_RENAME_EXCL = 0x00000004


def _rename_excl(dfd: int, old: str, new: str, st) -> None:
    """Rename old to new in one folder without ever replacing anything (GPT R-files1 MEDIUM 5). macOS renameatx_np with
    RENAME_EXCL does it in one step; where that is missing, renaming is refused."""
    if os.name == "nt":   # Windows' own rename never replaces: it fails when the new name is taken
        try:
            os.rename(old, new, src_dir_fd=dfd, dst_dir_fd=dfd)
            return
        except FileExistsError:
            raise Refused(409, "exists", "Something with that name is already here.")
        except FileNotFoundError:
            raise Refused(404, "not_found", "That file is no longer there.")
    if _RENAMEATX is not None:
        if _RENAMEATX(dfd, os.fsencode(old), dfd, os.fsencode(new), _RENAME_EXCL) == 0:
            return
        err = _CT.get_errno()
        if err == errno.EEXIST:
            raise Refused(409, "exists", "Something with that name is already here.")
        if err == errno.ENOENT:
            raise Refused(404, "not_found", "That file is no longer there.")
        raise OSError(err, "rename failed")
    # no one-step rename without replacing on this system: refuse rather than risk losing a change (GPT R-files2 MEDIUM)
    raise Refused(501, "unsupported", "Renaming is not available on this computer. Rename the file in your computer's own file manager.")


@router.post("/rename")
def rename(body: dict = Body(...)):
    dfd = None
    try:
        root, parts = _file_parts((body or {}).get("path"))
        new = (body or {}).get("name")
        if not isinstance(new, str) or not _name_ok(new) or new.startswith(".") or _sensitive(new) or any(ord(ch) < 32 or ord(ch) == 127 for ch in new):
            raise Refused(400, "bad_name", "That file name is not allowed here.")
        dfd = _open_dir(root, parts[:-1])
        st = os.stat(parts[-1], dir_fd=dfd, follow_symlinks=False)
        if not stat.S_ISREG(st.st_mode):
            raise Refused(409, "not_a_file", "Only files can be renamed here.")
        if new == parts[-1]:
            return {"ok": True, "path": body.get("path")}
        _rename_excl(dfd, parts[-1], new, st)
        new_path = root + "/" + "/".join(parts[:-1] + [new])
        if _V is not None:
            try:
                _V.move("/".join(parts), "/".join(parts[:-1] + [new]))
            except Exception:
                pass
        return {"ok": True, "path": new_path}
    except FileNotFoundError:
        return _answer(Refused(404, "not_found", "That file is no longer there."))
    except Refused as exc:
        return _answer(exc)
    except OSError:
        return _answer(Refused(500, "unavailable", "That file could not be renamed."))
    finally:
        if dfd is not None:
            os.close(dfd)


@router.get("/recent")
def recent(since: float = 0.0, session: str = ""):
    """Files the assistant changed since `since`, by their full path inside the files folder (newest first)."""
    try:
        root = _root()
        rows = _V.recent(since, session=session[:100]) if _V is not None else []
        return {"root": root, "files": [{"path": root + "/" + r["rel"], "at": r["at"]} for r in rows]}
    except Refused as exc:
        return _answer(exc)
    except OSError:
        return _answer(Refused(500, "unavailable", "The list could not be read."))
