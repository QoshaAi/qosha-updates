# App logos on the Connections page: sources

Fetched 17 Nov 2026 (about 10:50 MST). Local files only: Qosha never loads these from the internet.
Used by `../../pages/connections.html` (the `LOGOS` table, keyed by the app's catalog name). "Your files" has no file: it keeps its folder icon.

Terms in short: the Simple Icons files are CC0 1.0 as drawings; every logo stays the trademark of its company, shown here only to name that company's app next to its name. The files taken from a company's own site are that company's copyright and trademark, with no separate licence: before a public release, check each company's brand terms (not legal advice). No logo was drawn by hand or changed in shape; changes are limited to resizing, file format and (Simple Icons) the brand fill colour.

| App (catalog name) | File | Source | Note |
|---|---|---|---|
| qosha_google | google.png | https://www.gstatic.com/images/branding/googleg/1x/googleg_standard_color_128dp.png | Google's own "G" from its static server, resized 128 to 96 px. Google trademark; brand terms: https://about.google/brand-resource-center/ |
| github | github.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/github.svg ; icon file CC0 1.0; brand colour #181717 from its data file added as fill | GitHub trademark; https://github.com/logos |
| airwallex | airwallex.png | https://grw-landing.airwallex.com/favicon.ico (the icon www.airwallex.com links to) | Airwallex's own site icon, 48 px layer converted to PNG and scaled to 96 px (soft at high zoom). Airwallex trademark |
| apollo | apollo.png | https://www.apollo.io/icon.svg | Apollo.io's own site icon (a PNG inside their SVG), extracted and resized 256 to 96 px. Apollo trademark |
| atlassian | atlassian.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/atlassian.svg ; icon file CC0 1.0; brand colour #0052CC from its data file added as fill | Used for "Jira and Confluence" (one Atlassian connection). Atlassian trademark; https://atlassian.design/foundations/logos |
| canva | canva.png | https://static.canva.com/static/images/android-192x192-2.png | Canva's own app icon from its static server, resized to 96 px. Canva trademark |
| clay | clay.png | https://cdn.prod.website-files.com/61477f2c24a826836f969afe/6a3a92abeec5075ebf511920_dot-com_favicon_2026_512.png | Clay's own site icon (192 px, linked from www.clay.com), resized to 96 px. Clay trademark |
| docusign | docusign.png | https://www.docusign.com/assets/images/apple-touch-icon-180x180.png | Docusign's own site icon, resized to 96 px. Docusign trademark |
| emergent | emergent.png | https://cdn.prod.website-files.com/6a0edf12ef1a8562ed56d806/6a16a2346df663de29658539_emergent.png | Emergent's own site icon (linked from www.emergent.sh), resized to 96 px. Emergent trademark |
| expensify | expensify.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/expensify.svg ; icon file CC0 1.0; brand colour #0185FF from its data file added as fill | Expensify trademark; https://use.expensify.com/press-kit |
| quickbooks | quickbooks.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/quickbooks.svg ; icon file CC0 1.0; brand colour #2CA01C from its data file added as fill | Intuit trademark; https://design.intuit.com/quickbooks/brand |
| monday | monday.png | https://cdn.prod.website-files.com/656da6fea306219773d04208/65af6bd6e742d497b5f23f69_645898132bbaac20f1963919_256x256.png | monday.com's own site icon (linked from monday.com), resized to 96 px. monday.com trademark |
| myob | myob.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/myob.svg ; icon file CC0 1.0; brand colour #7B14EF from its data file added as fill | MYOB trademark |
| notion | notion.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/notion.svg ; icon file CC0 1.0; brand colour #000000 from its data file added as fill | Notion trademark |
| paypal | paypal.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/paypal.svg ; icon file CC0 1.0; brand colour #002991 from its data file added as fill | PayPal trademark; https://newsroom.paypal-corp.com/media-resources |
| ramp | ramp.png | https://ramp.com/apple-touch-icon.png | Ramp's own site icon, resized to 96 px. Ramp trademark |
| ringcentral | ringcentral.png | https://www.ringcentral.com/content/dam/rc-www/en_us/images/favicon/ringcentral_2.0_icon_favicon.png | RingCentral's own site icon; only a 32 px file was found, scaled to 96 px (soft at high zoom). RingCentral trademark |
| shopify | shopify.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/shopify.svg ; icon file CC0 1.0; brand colour #7AB55C from its data file added as fill | Shopify trademark; https://www.shopify.com/brand-assets |
| slack | slack.svg | https://commons.wikimedia.org/wiki/File:Slack_icon_2019.svg | Slack's four-colour mark as hosted on Wikimedia Commons (Simple Icons no longer carries Slack; Slack's own site blocked the larger files). Check the Commons page for its licence tag; Slack trademark, brand terms: https://slack.com/media-kit |
| square | square.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/square.svg ; icon file CC0 1.0; brand colour #3E4348 from its data file added as fill | Square (Block) trademark |
| stripe | stripe.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/stripe.svg ; icon file CC0 1.0; brand colour #635BFF from its data file added as fill | Stripe trademark; https://stripe.com/newsroom/information |
| tiktok_ads | tiktok.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/tiktok.svg ; icon file CC0 1.0; brand colour #000000 from its data file added as fill | One colour (black) version of the TikTok note. TikTok trademark |
| trello | trello.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/trello.svg ; icon file CC0 1.0; brand colour #0052CC from its data file added as fill | Atlassian trademark; https://atlassian.design/foundations/logos |
| wix | wix.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/wix.svg ; icon file CC0 1.0; brand colour #0C6EFC from its data file added as fill | Wix trademark; https://www.wix.com/about/design-assets |
| xero | xero.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/xero.svg ; icon file CC0 1.0; brand colour #13B5EA from its data file added as fill | Xero trademark; https://www.xero.com/uk/about/media/downloads |
| zapier | zapier.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/zapier.svg ; icon file CC0 1.0; brand colour #FF4F00 from its data file added as fill | Zapier trademark |
| zoom | zoom.svg | Simple Icons v16.38.0, https://github.com/simple-icons/simple-icons/blob/16.38.0/icons/zoom.svg ; icon file CC0 1.0; brand colour #0B5CFF from its data file added as fill | Zoom trademark; https://brand.zoom.us/usage-legal/ |
| recraft | recraft.png | https://www.recraft.ai/apps/apple-icon.png | Recraft's own site icon, resized to 96 px. Recraft trademark |
| apify | apify.svg | https://apify.com/icon0.svg | Apify's own site icon (SVG, unchanged). Apify trademark |
