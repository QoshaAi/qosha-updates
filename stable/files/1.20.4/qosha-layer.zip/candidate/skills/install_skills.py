#!/usr/bin/env python3
"""Install the Qosha skill library into an engine home (night job 3).

    install_skills.py [--home DIR] [--backups DIR] [--dry-run] [--customer]

Copies skills/qosha-library (and SKILLS-MANIFEST.json) to <home>/skills/qosha-library, replacing only that folder; the
previous copy is moved to <backups>/skills-library-<timestamp>. Every library skill ends up enabled: a library slug found
in config.yaml skills.disabled / skills.platform_disabled is removed (config.yaml backed up first; untouched otherwise).
Refuses the upstream engine's default home (~/.hermes). No network, no restart: the engine rescans skills on its own.

In-place skills (skills round 2): a manifest entry with "lab_path" (e.g. "productivity/docx") is a rebranded engine
skill with the same name as one the engine ships. The engine's scan keeps the first copy it finds by path, so that
skill goes to <home>/skills/<lab_path> instead of the library folder; the engine's copy there is moved to
<backups>/skills-engine-<timestamp>/<lab_path> first. The engine's own sync keeps a changed copy (it never overwrites
it).

Lab install (default, decision D23): every library skill, including those whose licence is still "pending"; it says how
many pending skills it installed. --customer: only skills the manifest lists as licence_status "confirmed" with an
allowed licence are copied (pending/unknown ones are refused and named); the staged copy must then pass
package_check.problems() and hold each skill's LICENSE (and NOTICE where the manifest records one) before it replaces
anything. Any failure leaves the home unchanged.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))   # package_check.py sits beside this file (also under python -I)
SRC = HERE / "qosha-library"
MANIFEST = HERE / "SKILLS-MANIFEST.json"
FOLDER = "qosha-library"


def library_slugs() -> list:
    return sorted(p.name for p in SRC.iterdir() if (p / "SKILL.md").exists())


def in_place() -> dict:
    """slug -> lab_path for rebranded engine skills that replace the engine's copy at its own path."""
    out = {}
    for s in manifest().get("skills", []):
        lp = s.get("lab_path")
        if lp:
            parts = Path(lp).parts
            if Path(lp).is_absolute() or ".." in parts or len(parts) != 2 or parts[-1] != s["slug"]:
                raise SystemExit("bad lab_path for %s: %r" % (s["slug"], lp))
            out[s["slug"]] = lp
    return out


def place_in_place(skills_dir: Path, slugs: list, backups: Path, stamp: str) -> list:
    """Copy each in-place skill over the engine's copy (old copy moved to backups). Returns placed lab paths."""
    placed = []
    places = in_place()
    for s in slugs:
        lp = places.get(s)
        if not lp:
            continue
        dest = skills_dir / lp
        tmp = dest.with_name(".%s-new-%s" % (s, stamp))
        shutil.copytree(SRC / s, tmp, symlinks=False)
        if dest.exists():
            old = backups / ("skills-engine-%s" % stamp) / lp
            old.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(dest), str(old))
        dest.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.replace(tmp, dest)
        placed.append(lp)
    return placed


def manifest() -> dict:
    return json.loads(MANIFEST.read_text("utf-8"))


def customer_split(slugs: list) -> tuple:
    """(allowed, refused[(slug, why)]) by the manifest's licence fields, the same rule as package_check."""
    from package_check import ALLOWED
    known = {s["slug"]: s for s in manifest().get("skills", [])}
    ok, refused = [], []
    for s in slugs:
        e = known.get(s)
        if e is None:
            refused.append((s, "not in the manifest"))
        elif e.get("licence_status") != "confirmed":
            refused.append((s, "licence %s" % (e.get("licence_status") or "unknown")))
        elif e.get("licence") not in ALLOWED:
            refused.append((s, "licence %r not allowed" % e.get("licence")))
        else:
            ok.append(s)
    return ok, refused


def licence_files_missing(copy: Path, slugs: list) -> list:
    known = {s["slug"]: s for s in manifest().get("skills", [])}
    out = []
    for s in slugs:
        d = copy / s
        if known.get(s, {}).get("licence") == "Qosha":
            continue   # Qosha's own work: no upstream licence text to carry
        if not any((d / n).is_file() for n in ("LICENSE", "LICENSE.txt", "LICENSE.md")):
            out.append("%s: no LICENSE file in the copy" % s)
        if "NOTICE" in (known.get(s, {}).get("source") or "") and not (d / "NOTICE").is_file():
            out.append("%s: no NOTICE file in the copy" % s)
    return out


def enable_all(home: Path, slugs: list, backups: Path, stamp: str, dry: bool) -> list:
    cfg = home / "config.yaml"
    if not cfg.exists():
        return []
    import yaml  # the engine's own dependency
    data = yaml.safe_load(cfg.read_text("utf-8")) or {}
    skills = data.get("skills") or {}
    changed = []
    disabled = skills.get("disabled") or []
    if isinstance(disabled, list):
        keep = [x for x in disabled if x not in slugs]
        changed += [x for x in disabled if x in slugs]
        skills["disabled"] = keep
    for plat, names in (skills.get("platform_disabled") or {}).items():
        if isinstance(names, list):
            changed += ["%s:%s" % (plat, x) for x in names if x in slugs]
            skills["platform_disabled"][plat] = [x for x in names if x not in slugs]
    if changed and not dry:
        backups.mkdir(parents=True, exist_ok=True)
        shutil.copy2(cfg, backups / ("config.yaml.before-skills-%s" % stamp))
        data["skills"] = skills
        tmp = cfg.with_name(".config.yaml.skills-tmp")
        tmp.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), "utf-8")
        os.chmod(tmp, cfg.stat().st_mode & 0o777)
        os.replace(tmp, cfg)
    return changed


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--home", default=os.environ.get("HERMES_HOME", ""))
    ap.add_argument("--backups", default="")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--customer", action="store_true", help="customer package: confirmed licences only")
    a = ap.parse_args(argv)
    if not a.home:
        print("no --home and HERMES_HOME is not set", file=sys.stderr)
        return 2
    home = Path(a.home).expanduser().resolve()
    if home == (Path.home() / ".hermes").resolve():
        print("refusing: that is the upstream engine's own home, not a Qosha home", file=sys.stderr)
        return 2
    if not (home / "config.yaml").exists():
        print("refusing: %s has no config.yaml (not an engine home)" % home, file=sys.stderr)
        return 2
    backups = Path(a.backups).expanduser() if a.backups else home.parent / "backups"
    stamp = time.strftime("%Y%m%d-%H%M%S")
    slugs = library_slugs()
    refused = []
    if a.customer:
        slugs, refused = customer_split(slugs)
        for s, why in refused:
            print("refused for customers: %s (%s)" % (s, why))
    skills_dir = home / "skills"
    dest = skills_dir / FOLDER
    places = in_place()
    lib_slugs = [s for s in slugs if s not in places]
    if a.dry_run:
        print("would install %d skills into %s and %d in place (backup of the old copies under %s)" % (
            len(lib_slugs), dest, len(slugs) - len(lib_slugs), backups))
        print("would enable:", enable_all(home, slugs, backups, stamp, True))
        return 0
    skills_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    staging_root = skills_dir / (".%s-new-%s" % (FOLDER, stamp))   # holds staging/qosha-library while it is checked
    staging_root.mkdir(mode=0o700)
    staging = staging_root / FOLDER
    if a.customer:
        staging.mkdir(mode=0o700)
        for s in slugs:
            shutil.copytree(SRC / s, staging / s, symlinks=False)   # every skill is checked, in-place ones too
        from package_check import problems
        bad = problems(staging_root, manifest()) + licence_files_missing(staging, slugs)
        if bad:
            shutil.rmtree(staging_root)
            for b in bad:
                print("NOT FOR CUSTOMERS:", b)
            print(json.dumps({"mode": "customer", "installed": 0, "refused": len(refused), "problems": len(bad),
                              "ok": False}))
            return 1
    else:
        shutil.copytree(SRC, staging, symlinks=False)
    for s in places:   # in-place skills live at the engine's own path, not in the library folder
        if (staging / s).exists():
            shutil.rmtree(staging / s)
    shutil.copy2(MANIFEST, staging / "SKILLS-MANIFEST.json")
    if dest.exists():
        backups.mkdir(parents=True, exist_ok=True)
        shutil.move(str(dest), str(backups / ("skills-library-%s" % stamp)))
    os.replace(staging, dest)
    staging_root.rmdir()
    placed = place_in_place(skills_dir, slugs, backups, stamp)
    changed = enable_all(home, slugs, backups, stamp, False)
    installed = sorted([p.name for p in dest.iterdir() if (p / "SKILL.md").exists()] +
                       [Path(lp).name for lp in placed if (skills_dir / lp / "SKILL.md").exists()])
    ok = installed == slugs
    if a.customer:
        print(json.dumps({"mode": "customer", "installed": len(installed), "refused": len(refused), "dest": str(dest),
                          "in_place": len(placed), "re_enabled": changed, "ok": ok}))
    else:
        pending = sum(1 for s in manifest().get("skills", []) if s["slug"] in installed
                      and s.get("licence_status") != "confirmed")
        print("lab install (not a customer package): %d skills, %d with a pending licence" % (len(installed), pending))
        print(json.dumps({"mode": "lab", "installed": len(installed), "expected": len(slugs), "pending": pending,
                          "dest": str(dest), "in_place": len(placed), "re_enabled": changed, "ok": ok}))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
