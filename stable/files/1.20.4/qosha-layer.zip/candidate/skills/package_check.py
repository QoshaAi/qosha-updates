#!/usr/bin/env python3
"""Customer-package licence check for the Qosha skill library (decision D23, council C12).

Usage: package_check.py <package-or-skills-folder>
Fails (exit 1) when the folder holds any qosha-library skill that the manifest does not list as licence_status
"confirmed" with a licence on the allowlist, or a skill folder the manifest does not know at all. Run it on every
customer package before it leaves the building; the company's own test lab may hold "pending" skills.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ALLOWED = {"MIT", "Apache-2.0", "BSD-2-Clause", "BSD-3-Clause", "ISC", "CC0-1.0", "CC-BY-4.0", "Qosha"}
MANIFEST = Path(__file__).with_name("SKILLS-MANIFEST.json")


def problems(root: Path, manifest: dict) -> list:
    known = {s["folder"].split("/")[-1]: s for s in manifest.get("skills", [])}
    out = []
    for skill_md in sorted(root.rglob("SKILL.md")):
        if "qosha-library" not in skill_md.parts:
            continue
        slug = skill_md.parent.name
        entry = known.get(slug)
        if entry is None:
            out.append("%s: not in the manifest" % skill_md.parent)
        elif entry.get("licence_status") != "confirmed":
            out.append("%s: licence %s" % (slug, entry.get("licence_status") or "unknown"))
        elif entry.get("licence") not in ALLOWED:
            out.append("%s: licence %r is not on the allowlist" % (slug, entry.get("licence")))
    return out


def main(argv: list) -> int:
    if len(argv) != 2 or not Path(argv[1]).is_dir():
        print(__doc__.strip().splitlines()[2], file=sys.stderr)
        return 2
    manifest = json.loads(MANIFEST.read_text("utf-8"))   # the build's own manifest, never a copy inside the package
    found = problems(Path(argv[1]), manifest)
    for p in found:
        print("NOT FOR CUSTOMERS:", p)
    print("package_check: %d problem(s)" % len(found))
    return 1 if found else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
