---
name: product-price-monitor
description: Use to watch a product's price and alert you on a target.
version: 0.1.0
author: Qosha (based on MIT/Apache-licensed work; see NOTICE)
license: MIT
platforms:
- linux
- macos
- windows
metadata:
  hermes:
    tags:
    - Prices
    - Availability
    - Shopping
    - Travel
    - Alerts
    related_skills:
    - maps
---
# Product Price Monitor

## In Qosha

In Qosha, keep watch files in the person's files folder (Your files), not in the engine folder. Alerts stay in Qosha: the automation delivers into Chat and Your files (deliver "local"). Do not set up any other delivery route. If the person also wants an alert by email, show each alert email in Chat and ask whether to send it; call the Gmail send only after the owner's yes to that alert (never on Always allow alone), as in step 6. A yes to the watch never approves future emails. Create the automation only after the person says yes to the exact plan (step 3). Never buy, book or reserve anything: a purchase is put to the person on Qosha's approval card in the chat first.

Monitor a concrete purchasable item and alert on a normalized all-in price or availability condition. Handle variants, taxes, fees, currencies, stock, cancellation terms, and duplicate alerts explicitly. Setup runs once in the foreground; the recurring check runs as a `cronjob` tick (the `price-watch` automation blueprint scaffolds this).

## When to Use

- "Alert me when this laptop drops below $1,000."
- "Watch these flights for a fare under $500."
- "Tell me when this hotel has a refundable room."
- "Track ticket/listing availability."
- A cron tick fires for an existing price watch (steps 4-6).

Don't use for: one-off "what does this cost right now" lookups (use `web_search`/`web_extract` directly).

## Procedure — Setup (foreground, once)

### 1. Define the exact item

Record source URL/provider, product/listing ID where available, variant, quantity, location, dates, travelers/guests, membership/login assumptions, condition, seller, and acceptable substitutes. Done when two variants cannot be confused.

### 2. Define the alert condition

Specify currency, all-in vs pre-tax price, maximum price, availability/stock rule, shipping, refundability, cabin/room/ticket class, cooldown, and where the alert appears (Qosha Chat and Your files; optionally an alert email, sent only after the owner says yes in the chat to that alert). Done when synthetic examples have deterministic alert decisions.

### 3. Establish a live baseline, then schedule

Fetch a bounded live result with `web_extract` or `browser_navigate` and record retrieval time, source price, fees/taxes, availability, and terms. Do not schedule until one foreground fetch works. Write the watch contract (item, condition, baseline observation) to a state file under `<your files folder>/price-watches/<watch-slug>.json`.

Before creating anything recurring, show the person the exact plan: the item and variant, the alert condition, how often it checks, where alerts appear (Chat and Your files; an alert email goes only after the owner says yes in the chat to that alert, never on Always allow alone), and the state file. Create the job only after the person says yes to that plan; if they change anything, show the new plan and ask again:

```
cronjob(action="create",
        schedule="every 6h",
        prompt="Load the product-price-monitor skill and run the tick for the watch contract at <your files folder>/price-watches/<watch-slug>.json.",
        deliver="local")
```

Pick a cadence that respects rate limits and site terms. Done when the baseline matches the exact item contract, the person said yes to the plan shown, and the job exists.

## Procedure — Tick (each scheduled run)

### 4. Fetch and normalize

Re-fetch the source. Convert currency only with a timestamped rate and retain the source currency. Separate base price, mandatory fees, shipping/taxes, total, and availability. Exclude volatile page metadata. A failed fetch means unknown state: report or skip, but never overwrite the last good observation with an error page. Done when the observation is comparable to the baseline or explicitly marked failed.

### 5. Compare and suppress duplicates

Alert on threshold entry, qualifying availability, material lower price, or recovery as requested. Store the last good observation and last alert fingerprint in the state file. Replaying the same offer must send no second alert; respect the cooldown. Done when the alert decision is deterministic against stored state.

### 6. Deliver or stay silent

When a condition is met, the alert is delivered into Chat and Your files and includes: exact item/variant, observed all-in price and source currency, availability/terms, threshold, retrieval timestamp, source link, and important uncertainty. Never claim inventory is reserved. If the person asked for alert emails, show the alert email in Chat and ask whether to send it; run the send only after their yes to that alert (never on Always allow alone), and never say it was sent before the step's own result shows it. When nothing qualifies, stay silent — no "still watching" noise unless a periodic all-clear was requested. Done when the state file reflects this run.

## Pitfalls

- Comparing a base fare with an all-in threshold.
- Alerting on the wrong size, seller, cabin, dates, or room terms.
- Overwriting a last-known-good value with an error page.
- Polling aggressively enough to trigger blocking or violate site terms.
- Scheduling before a single foreground fetch has succeeded.

## Verification

- [ ] The watch contract pins the item so two variants cannot be confused.
- [ ] One foreground fetch succeeded before any job was created.
- [ ] The person said yes to the exact plan (item, condition, frequency, delivery) before the job was created.
- [ ] Alerts arrive in Chat and Your files; any alert email went only after the owner's yes in the chat to that alert.
- [ ] Alert decisions replay deterministically from the state file; duplicates suppressed.
- [ ] Failed fetches never replaced last-known-good state.
- [ ] Alerts carry all-in price, source currency, timestamp, and source link.
