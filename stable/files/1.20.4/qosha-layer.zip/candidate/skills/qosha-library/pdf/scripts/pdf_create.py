#!/usr/bin/env python3
"""Create a PDF from a JSON spec using reportlab platypus.

Spec format (UTF-8 JSON):
{
  "title": "Example Report",
  "author": "example-author",
  "page_size": "A4",            // or "letter" (default: A4)
  "page_numbers": true,          // default true
  "elements": [
    {"type": "heading", "text": "Section 1", "level": 1},
    {"type": "paragraph", "text": "Body text..."},
    {"type": "table", "rows": [["H1", "H2"], ["a", "b"]], "header": true},
    {"type": "image", "path": "chart.png", "width": 400},
    {"type": "pagebreak"}
  ]
}
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys


def _reconfigure_stdio() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass


# GUARDFIX3: a path named by an input file (or handed to another program) must stay in the person's Files folder
# ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error."""
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: Paragraph text is reportlab markup; <img src=...> reads any file or URL and <onDraw>/<index> call canvas
# methods by name. Only plain formatting tags (and a link's href, which is never fetched) are accepted.
_TAG_ATTRS = {"b": (), "i": (), "u": (), "strike": (), "strong": (), "em": (), "br": (), "super": (), "sup": (),
              "sub": (), "greek": (), "font": ("color", "size", "fontsize", "face", "name", "fontname", "backcolor"),
              "span": ("color", "size", "fontsize", "face", "name", "fontname", "backcolor"),
              "a": ("href", "color", "name", "fg", "underline")}
_FONT_NAME = re.compile(r"^[A-Za-z][A-Za-z0-9 _-]{0,63}$")   # a font NAME, never a path


def _safe_markup(text) -> str:
    text = "" if text is None else str(text)
    if re.search(r"<\s*/?\s*(img|ondraw|index|seq)", text, re.I):
        sys.exit("refusing: <img>, <onDraw>, <index> and <seq> markup is not allowed in text "
                 "(put images in an \"image\" element)")
    # how reportlab's (HTMLParser) tags start; quoted attribute values may hold '>'
    for m in re.finditer(r"</?([A-Za-z][^\s/<>]*)((?:\"[^\"]*\"|'[^']*'|[^'\"<>])*)", text):
        tag, rest = m.group(1).lower(), m.group(2)
        if tag not in _TAG_ATTRS:
            sys.exit("refusing: markup tag <%s> is not allowed in text (put images in an \"image\" element)" % tag)
        for key, val in re.findall(r"([A-Za-z_][\w:.-]*)\s*(?:=\s*(\"[^\"]*\"|'[^']*'|[^\s/>]+))?", rest):
            key, val = key.lower(), (val or "").strip("\"'")
            if key not in _TAG_ATTRS[tag]:
                sys.exit("refusing: attribute %r of <%s> is not allowed in text" % (key, tag))
            if key in ("face", "name", "fontname") and tag != "a" and not _FONT_NAME.match(val):
                sys.exit("refusing: font %r is not a font name" % val)
    return text


def build_pdf(spec: dict, out_path: str) -> int:
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, letter
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.units import inch
        from reportlab.platypus import (
            Image,
            PageBreak,
            Paragraph,
            SimpleDocTemplate,
            Spacer,
            Table,
            TableStyle,
        )
    except ImportError:
        print("Missing dependency: install with 'python3 -m pip install reportlab'", file=sys.stderr)
        return 2

    page_size = letter if str(spec.get("page_size", "A4")).lower() == "letter" else A4
    styles = getSampleStyleSheet()
    story = []
    for el in spec.get("elements", []):
        etype = el.get("type")
        if etype == "heading":
            level = min(max(int(el.get("level", 1)), 1), 3)
            story.append(Paragraph(_safe_markup(el.get("text", "")), styles[f"Heading{level}"]))
        elif etype == "paragraph":
            story.append(Paragraph(_safe_markup(el.get("text", "")), styles["BodyText"]))
            story.append(Spacer(1, 6))
        elif etype == "table":
            rows = el.get("rows", [])
            if not rows:
                continue
            table = Table(rows, repeatRows=1 if el.get("header", True) else 0)
            style = [
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]
            if el.get("header", True):
                style += [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ]
            table.setStyle(TableStyle(style))
            story.append(table)
            story.append(Spacer(1, 10))
        elif etype == "image":
            kwargs = {}
            if el.get("width"):
                kwargs["width"] = float(el["width"])
            if el.get("height"):
                kwargs["height"] = float(el["height"])
            src = _inside(el["path"])   # GUARDFIX3: a spec image stays in Files (no file:// or http URL either)
            if not os.path.isfile(src):
                sys.exit("refusing: image %s is not a file in your Files folder" % el["path"])
            img = Image(src, **kwargs)
            if "width" in kwargs and "height" not in kwargs:
                # keep aspect ratio
                ratio = img.imageHeight / img.imageWidth
                img.drawWidth = kwargs["width"]
                img.drawHeight = kwargs["width"] * ratio
            story.append(img)
            story.append(Spacer(1, 10))
        elif etype == "pagebreak":
            story.append(PageBreak())
        else:
            print(f"Warning: unknown element type {etype!r}, skipped", file=sys.stderr)

    def draw_page_number(canvas, doc):
        if spec.get("page_numbers", True):
            canvas.saveState()
            canvas.setFont("Helvetica", 9)
            canvas.drawCentredString(page_size[0] / 2.0, 0.5 * inch, f"Page {doc.page}")
            canvas.restoreState()

    doc = SimpleDocTemplate(
        out_path,
        pagesize=page_size,
        title=spec.get("title", ""),
        author=spec.get("author", ""),
    )
    doc.build(story, onFirstPage=draw_page_number, onLaterPages=draw_page_number)
    print(json.dumps({"output": out_path, "elements": len(spec.get("elements", []))}))
    return 0


def main() -> int:
    _reconfigure_stdio()
    parser = argparse.ArgumentParser(description="Create a PDF from a JSON spec (reportlab).")
    parser.add_argument("spec", help="Path to UTF-8 JSON spec file")
    parser.add_argument("-o", "--output", required=True, help="Output PDF path")
    args = parser.parse_args()
    # GUARDFIX3 (bare names too): every file argument resolves inside Files (reads may also use this skill's folder);
    # the real path is what is opened and saved, so a link named like a plain file cannot lead out of Files.
    with open(_inside(args.spec), encoding="utf-8") as fh:
        spec = json.load(fh)
    return build_pdf(spec, _inside(args.output, write=True))


if __name__ == "__main__":
    sys.exit(main())
