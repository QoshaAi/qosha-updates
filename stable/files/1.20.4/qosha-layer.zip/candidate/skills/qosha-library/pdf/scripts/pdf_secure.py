#!/usr/bin/env python3
"""Encrypt or decrypt a PDF with passwords (AES-256 via pypdf).

Note: permission flags set at encryption time are advisory — viewers may honor
them, but any PDF library can strip them. Only the user password gates content.
"""
from __future__ import annotations

import argparse
import json
import os
import sys


# GUARDFIX3: a path named by an input file (or handed to another program) must stay in the person's Files folder
# ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error."""
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass
    parser = argparse.ArgumentParser(description="Encrypt/decrypt PDFs (pypdf, AES-256).")
    parser.add_argument("pdf", help="Input PDF path")
    parser.add_argument("-o", "--output", required=True, help="Output PDF path")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--encrypt", action="store_true", help="Encrypt the PDF")
    mode.add_argument("--decrypt", action="store_true", help="Remove encryption (password required)")
    parser.add_argument("--user-password", help="User (open) password for --encrypt")
    parser.add_argument("--owner-password", help="Owner password for --encrypt (defaults to user password)")
    parser.add_argument("--password", help="Known password for --decrypt")
    args = parser.parse_args()
    # GUARDFIX3 (bare names too): every file argument resolves inside Files (reads may also use this skill's folder);
    # the real path is what is opened and saved, so a link named like a plain file cannot lead out of Files.
    args.pdf = _inside(args.pdf)
    out_real = _inside(args.output, write=True)

    try:
        from pypdf import PdfReader, PdfWriter
    except ImportError:
        print("Missing dependency: install with 'python3 -m pip install pypdf'", file=sys.stderr)
        return 2

    reader = PdfReader(args.pdf)
    if args.encrypt:
        if not args.user_password:
            print("Error: --encrypt requires --user-password", file=sys.stderr)
            return 2
        if reader.is_encrypted:
            print("Error: input already encrypted; decrypt first", file=sys.stderr)
            return 3
        writer = PdfWriter()
        writer.append(reader)
        writer.encrypt(
            user_password=args.user_password,
            owner_password=args.owner_password or args.user_password,
            algorithm="AES-256",
        )
        action = "encrypted"
    else:
        if not reader.is_encrypted:
            print("Error: input is not encrypted", file=sys.stderr)
            return 3
        if args.password is None or not reader.decrypt(args.password):
            print("Error: wrong or missing --password", file=sys.stderr)
            return 4
        writer = PdfWriter()
        writer.append(reader)
        action = "decrypted"

    with open(out_real, "wb") as fh:
        writer.write(fh)
    print(json.dumps({"output": args.output, "action": action, "page_count": len(reader.pages)}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
