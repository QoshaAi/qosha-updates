#!/usr/bin/env python3
"""Export PDF pages as PNG images at a chosen DPI.

Rasterizer fallback chain: pypdfium2 (pip) -> pdftoppm (poppler-utils).
When neither is available, exits 0 with {"rendered": false, "missing": [...]}
so callers can branch instead of crashing.

Typical uses: visual verification with a vision model, and exporting
image-only (scanned) pages for hand-off to the references/ocr-extraction.md in this skill.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path


# GUARDFIX3: a path named by an input file (or handed to another program) must stay in the person's Files folder
# ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error."""
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


def parse_pages(spec: str, page_count: int) -> list[int]:
    """'1-3,5,9-' (1-based, inclusive) -> sorted page list."""
    pages: set[int] = set()
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            start_s, _, end_s = part.partition("-")
            start = int(start_s) if start_s else 1
            end = int(end_s) if end_s else page_count
            pages.update(range(start, end + 1))
        else:
            pages.add(int(part))
    bad = [p for p in pages if not 1 <= p <= page_count]
    if bad:
        raise ValueError(f"pages out of range 1-{page_count}: {sorted(bad)}")
    return sorted(pages)


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass
    parser = argparse.ArgumentParser(description="Export PDF pages as PNG images.")
    parser.add_argument("pdf", help="Input PDF path")
    parser.add_argument("--pages", default="1-", help="1-based ranges, e.g. '1-3,5' (default: all)")
    parser.add_argument("--dpi", type=int, default=150, help="Render DPI (default 150)")
    parser.add_argument("--out-dir", required=True, help="Directory for PNG files")
    parser.add_argument("--prefix", default="page", help="Output filename prefix (default 'page')")
    parser.add_argument("--password", help="Password for encrypted PDFs")
    args = parser.parse_args()
    # GUARDFIX3: the prefix is a file-name start, not a path (it is joined to --out-dir, which the guard does not see)
    if not re.match(r"^[A-Za-z0-9._ -]{0,64}$", args.prefix or "") or args.prefix in (".", ".."):
        sys.exit("refusing: --prefix must be a plain name (letters, digits, . _ -), not a path")
    args.out_dir = _inside(args.out_dir, write=True)
    # GUARDFIX3 (bare names too): every file argument resolves inside Files (reads may also use this skill's folder);
    # the real path is what is opened and saved, so a link named like a plain file cannot lead out of Files.
    args.pdf = _inside(args.pdf)

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import _raster

    if not _raster.available_backends():
        json.dump({"rendered": False, "missing": _raster.missing_hints()}, sys.stdout)
        print()
        return 0

    try:
        from pypdf import PdfReader
    except ImportError:
        print("Missing dependency: install with 'python3 -m pip install pypdf'", file=sys.stderr)
        return 2
    reader = PdfReader(args.pdf)
    if reader.is_encrypted:
        if args.password is None or not reader.decrypt(args.password):
            print("File is encrypted; pass --password.", file=sys.stderr)
            return 3
    page_count = len(reader.pages)

    try:
        pages = parse_pages(args.pages, page_count)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 4

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    files = []
    for pageno in pages:
        img = _raster.rasterize_page(args.pdf, pageno, dpi=args.dpi, password=args.password)
        if img is None:
            json.dump({"rendered": False, "missing": _raster.missing_hints()}, sys.stdout)
            print()
            return 0
        out_path = Path(_inside(out_dir / f"{args.prefix}{pageno:03d}.png", write=True))
        img.save(out_path)
        files.append(str(out_path))
    json.dump({"rendered": True, "dpi": args.dpi, "page_count": page_count,
               "files": files}, sys.stdout, ensure_ascii=False, indent=2)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
