# Natural-language PDF text editing with nano-pdf (merged from the nano-pdf skill)
# nano-pdf

**Not available in Qosha.** The nano-pdf command-line tool is not installed, it
sends the PDF to an outside AI service using an API key, and no Qosha
Connection or approval step covers that. Do not install it, run it, or ask for
a key.

## What to do instead

1. **Local edits the `pdf` skill supports** (when its libraries are present):
   stamp a correction or label at set coordinates (`pdf_stamp.py`), replace or
   remove whole pages (`pdf_split.py` + `pdf_merge.py`), or fill form fields
   (`pdf_fill_form.py`). Save the result as a new file in Your files.
2. **Rebuild the document** with `pdf_create.py` when the owner has the
   content (or it can be extracted with `pdf_read.py --text`).
3. **Proposed change list.** When the text itself must change, write a short
   list in Your files: page number (1-based, as shown in the PDF viewer), the
   current wording, and the new wording. The owner makes the edits in their
   own PDF app or in the source document.

Always confirm the page by reading its text (`pdf_read.py --text`) before
proposing a change; never guess a page by trying neighbouring pages.
