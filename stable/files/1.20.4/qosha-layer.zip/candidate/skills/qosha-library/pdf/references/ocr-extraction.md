# OCR & Document Text Extraction (merged from the ocr-and-documents skill)

Scripts referenced below live in this skill's scripts/ directory.
# PDF & Document Extraction

For DOCX: see the `docx` skill (create/edit) or use `python-docx` for structured reads.
For PPTX: see the `powerpoint` skill (full create/read/edit support).
For PDF manipulation (merge, split, forms, watermarks, creation): see the `pdf` skill.
This skill covers **text extraction from PDFs and scanned documents**.

> **Coming from a `read_file` EXTRACTION COVERAGE WARNING?** `read_file` auto-converts local PDFs but reads the text layer only; the warning footer lists the pages that yielded no text (scanned images). For a handful of pages, render each page into the working folder inside Your files (`pdf_page_image.py file.pdf --pages N --dpi 150 --out-dir <Your files>/pdf-work/pages/`, with `TMPDIR` set inside Your files) and read it where the browser tool can show the image. If no visual view is available, tell the owner those pages could not be read and offer that they paste the text. For bulk OCR of many pages, see marker-pdf below (Step 2), which is usually not available.

## Step 1: Remote URL Available?

If the document has a URL, **always try `web_extract` first**:

```
web_extract(urls=["https://arxiv.org/pdf/2402.03300"])
web_extract(urls=["https://example.com/report.pdf"])
```

This handles PDF-to-markdown conversion via Firecrawl with no local dependencies.

Only use local extraction when: the file is local, web_extract fails, or you need batch processing.

## Step 2: Choose Local Extractor

| Feature | pymupdf (~25MB) | marker-pdf (~3-5GB) |
|---------|-----------------|---------------------|
| **Text-based PDF** | ✅ | ✅ |
| **Scanned PDF (OCR)** | ❌ | ✅ (90+ languages) |
| **Tables** | ✅ (basic) | ✅ (high accuracy) |
| **Equations / LaTeX** | ❌ | ✅ |
| **Code blocks** | ❌ | ✅ |
| **Forms** | ❌ | ✅ |
| **Headers/footers removal** | ❌ | ✅ |
| **Reading order detection** | ❌ | ✅ |
| **Images extraction** | ✅ (embedded) | ✅ (with context) |
| **Images → text (OCR)** | ❌ | ✅ |
| **EPUB** | ✅ | ✅ |
| **Markdown output** | ✅ (via pymupdf4llm) | ✅ (native, higher quality) |
| **Install size** | ~25MB | ~3-5GB (PyTorch + models) |
| **Speed** | Instant | ~1-14s/page (CPU), ~0.2s/page (GPU) |

**Decision**: Use pymupdf unless you need OCR, equations, forms, or complex layout analysis.

If the owner needs marker capabilities but marker-pdf (or its models) is not already in this workspace:
> "This document needs OCR (reading text from scanned pages), and the OCR tool is not available in this workspace. Options: paste the text, upload a text or Word export, share a public link to the document, or I can try the light reader, which works for normal PDFs but not scanned pages or equations."

---

## Before either extractor: check, never install

```bash
python3 -c "import importlib.util as u; print({m: bool(u.find_spec(m)) for m in ['pymupdf','pymupdf4llm','marker']})"
```

If the extractor you need shows `False`, stop: tell the owner which package is
missing, do not install it, and offer the fallback (the owner pastes the text,
or uploads a text or Word export they made themselves).

## pymupdf (lightweight)

Only when the check shows `pymupdf` (and `pymupdf4llm` for `--markdown`) is present.
Write `--images` output to a folder inside Your files.

**Via helper script**:
```bash
python scripts/extract_pymupdf.py document.pdf              # Plain text
python scripts/extract_pymupdf.py document.pdf --markdown    # Markdown
python scripts/extract_pymupdf.py document.pdf --tables      # Tables
python scripts/extract_pymupdf.py document.pdf --images out/ # Extract images
python scripts/extract_pymupdf.py document.pdf --metadata    # Title, author, pages
python scripts/extract_pymupdf.py document.pdf --pages 0-4   # Specific pages
```

**Inline**:
```bash
python -c "
import pymupdf
doc = pymupdf.open('document.pdf')
for page in doc:
    print(page.get_text())
"
```

---

## marker-pdf (high-quality OCR)

Only when the check shows `marker` is already installed. First point every
temporary and cache folder inside Your files, resolve them with `realpath`, and
confirm they are inside Your files:

```bash
W="<Your files>/pdf-work"; mkdir -p "$W/tmp" "$W/cache"
export TMPDIR="$W/tmp" HF_HOME="$W/cache/hf" XDG_CACHE_HOME="$W/cache"
python3 scripts/extract_marker.py --check
```

marker needs its models (about 2.5GB) in that cache. If they are not already
there it would download them, which counts as installing: stop and tell the
owner OCR is not available in this workspace. Use `--output_dir` inside Your
files.

**Via helper script**:
```bash
python scripts/extract_marker.py document.pdf                # Markdown
python scripts/extract_marker.py document.pdf --json         # JSON with metadata
python scripts/extract_marker.py document.pdf --output_dir out/  # Save images
python scripts/extract_marker.py scanned.pdf                 # Scanned PDF (OCR)
```

Never use `--use_llm`: it sends the document to an outside AI service with an
API key, which no Qosha Connection covers. The `marker_single` / `marker` CLIs
are not used here; the helper script covers the same job with the folders set
above.

---

## Arxiv Papers

```
# Abstract only (fast)
web_extract(urls=["https://arxiv.org/abs/2402.03300"])

# Full paper
web_extract(urls=["https://arxiv.org/pdf/2402.03300"])

# Search
web_search(query="arxiv GRPO reinforcement learning 2026")
```

## Split, Merge & Search

pymupdf handles these natively — use `execute_code` or inline Python:

```python
# Split: extract pages 1-5 to a new PDF
import pymupdf
doc = pymupdf.open("report.pdf")
new = pymupdf.open()
for i in range(5):
    new.insert_pdf(doc, from_page=i, to_page=i)
new.save("pages_1-5.pdf")
```

```python
# Merge multiple PDFs
import pymupdf
result = pymupdf.open()
for path in ["a.pdf", "b.pdf", "c.pdf"]:
    result.insert_pdf(pymupdf.open(path))
result.save("merged.pdf")
```

```python
# Search for text across all pages
import pymupdf
doc = pymupdf.open("report.pdf")
for i, page in enumerate(doc):
    results = page.search_for("revenue")
    if results:
        print(f"Page {i+1}: {len(results)} match(es)")
        print(page.get_text("text"))
```

No extra dependencies needed — pymupdf covers split, merge, search, and text extraction in one package.

---

## Notes

- `web_extract` is always first choice for URLs
- pymupdf is the safe default — instant, no models, works everywhere
- marker-pdf is for OCR, scanned docs, equations, complex layouts — only when it is already installed with its models; never install it
- Both helper scripts accept `--help` for full usage
- marker-pdf would download ~2.5GB of models on first use; that is an install, so stop instead
- For Word docs: use the `docx` skill (better than OCR — parses actual structure); if `python-docx` is missing, name it and stop
- For PowerPoint: see the `powerpoint` skill (uses python-pptx)
