#!/usr/bin/env python3
"""Merge multiple PDFs into one, optionally adding a bookmark per source file."""
from __future__ import annotations

import argparse
import json
import os
import sys


# GUARDFIX3: a path named by an input file (or handed to another program) must stay in the person's Files folder
# ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error."""
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass
    parser = argparse.ArgumentParser(description="Merge PDFs (pypdf).")
    parser.add_argument("inputs", nargs="+", help="Input PDF paths, in order")
    parser.add_argument("-o", "--output", required=True, help="Output PDF path")
    parser.add_argument("--bookmarks", action="store_true",
                        help="Add a top-level bookmark per input file (its basename)")
    args = parser.parse_args()
    # GUARDFIX3 (bare names too): every file argument resolves inside Files (reads may also use this skill's folder);
    # the real path is what is opened and saved, so a link named like a plain file cannot lead out of Files.
    reals = [_inside(p) for p in args.inputs]
    out_real = _inside(args.output, write=True)

    try:
        from pypdf import PdfReader, PdfWriter
    except ImportError:
        print("Missing dependency: install with 'python3 -m pip install pypdf'", file=sys.stderr)
        return 2

    writer = PdfWriter()
    total = 0
    for path, real in zip(args.inputs, reals):
        reader = PdfReader(real)
        if reader.is_encrypted:
            print(f"Error: {path} is encrypted; decrypt it first with pdf_secure.py --decrypt", file=sys.stderr)
            return 3
        start = total
        for page in reader.pages:
            writer.add_page(page)
            total += 1
        if args.bookmarks:
            writer.add_outline_item(os.path.splitext(os.path.basename(path))[0], start)
    with open(out_real, "wb") as fh:
        writer.write(fh)
    print(json.dumps({"output": args.output, "inputs": len(args.inputs), "page_count": total}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
