#!/usr/bin/env python3
"""Extract text from documents using pymupdf. Lightweight (~25MB), no models.

Usage:
    python extract_pymupdf.py document.pdf
    python extract_pymupdf.py document.pdf --markdown
    python extract_pymupdf.py document.pdf --pages 0-4
    python extract_pymupdf.py document.pdf --images output_dir/
    python extract_pymupdf.py document.pdf --tables
    python extract_pymupdf.py document.pdf --metadata
"""
import os
import sys
import json


# GUARDFIX3: a path named by an input file (or handed to another program) must stay in the person's Files folder
# ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error."""
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


def extract_text(path, pages=None):
    try:
        import pymupdf
    except ImportError:   # Qosha (GUARDFIX2): PyMuPDF is AGPL and not shipped; plain text comes from pypdf instead
        from pypdf import PdfReader
        reader = PdfReader(path)
        n = len(reader.pages)
        for i in (range(n) if pages is None else pages):
            if i < n:
                print(f"\n--- Page {i+1}/{n} ---\n")
                print(reader.pages[i].extract_text() or "")
        return
    doc = pymupdf.open(path)
    page_range = range(len(doc)) if pages is None else pages
    for i in page_range:
        if i < len(doc):
            print(f"\n--- Page {i+1}/{len(doc)} ---\n")
            print(doc[i].get_text())

def extract_markdown(path, pages=None):
    import pymupdf4llm
    md = pymupdf4llm.to_markdown(path, pages=pages)
    print(md)

def extract_tables(path):
    import pymupdf
    doc = pymupdf.open(path)
    for i, page in enumerate(doc):
        tables = page.find_tables()
        for j, table in enumerate(tables.tables):
            print(f"\n--- Page {i+1}, Table {j+1} ---\n")
            df = table.to_pandas()
            print(df.to_markdown(index=False))

def extract_images(path, output_dir):
    import pymupdf
    from pathlib import Path
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    doc = pymupdf.open(path)
    count = 0
    for i, page in enumerate(doc):
        for img_idx, img in enumerate(page.get_images(full=True)):
            xref = img[0]
            pix = pymupdf.Pixmap(doc, xref)
            if pix.n >= 5:
                pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
            # GUARDFIX3: a link with this exact name could already sit in the folder
            out_path = _inside(os.path.join(output_dir, f"page{i+1}_img{img_idx+1}.png"), write=True)
            pix.save(out_path)
            count += 1
    print(f"Extracted {count} images to {output_dir}/")

def show_metadata(path):
    try:
        import pymupdf
    except ImportError:   # Qosha (GUARDFIX2): pypdf instead of the AGPL PyMuPDF
        from pypdf import PdfReader
        reader = PdfReader(path)
        meta = {str(k).lstrip("/").lower(): str(v) for k, v in (reader.metadata or {}).items()}
        print(json.dumps({"pages": len(reader.pages), **{k: meta.get(k, "") for k in
                          ("title", "author", "subject", "creator", "producer")}, "format": "PDF"}, indent=2))
        return
    doc = pymupdf.open(path)
    print(json.dumps({
        "pages": len(doc),
        "title": doc.metadata.get("title", ""),
        "author": doc.metadata.get("author", ""),
        "subject": doc.metadata.get("subject", ""),
        "creator": doc.metadata.get("creator", ""),
        "producer": doc.metadata.get("producer", ""),
        "format": doc.metadata.get("format", ""),
    }, indent=2))

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Extract text/tables/images/metadata from documents using pymupdf (lightweight, no models)."
    )
    parser.add_argument("path", help="Document to read")
    parser.add_argument("--pages", help="Page selection: N or START-END (0-indexed)")
    parser.add_argument("--markdown", action="store_true", help="Markdown output via pymupdf4llm")
    parser.add_argument("--tables", action="store_true", help="Extract tables as markdown")
    parser.add_argument("--images", nargs="?", const="./images", metavar="OUTPUT_DIR",
                        help="Extract embedded images to OUTPUT_DIR (default ./images)")
    parser.add_argument("--metadata", action="store_true", help="Show document metadata as JSON")
    args = parser.parse_args()
    if args.images is not None:   # GUARDFIX3: the guard sees --images only as a read; images go into Files only
        args.images = _inside(args.images, write=True)
    # GUARDFIX3 (bare names too): every file argument resolves inside Files (reads may also use this skill's folder);
    # the real path is what is opened and saved, so a link named like a plain file cannot lead out of Files.
    args.path = _inside(args.path)

    pages = None
    if args.pages:
        if "-" in args.pages:
            start, end = args.pages.split("-")
            pages = list(range(int(start), int(end) + 1))
        else:
            pages = [int(args.pages)]

    if args.metadata:
        show_metadata(args.path)
    elif args.tables:
        extract_tables(args.path)
    elif args.images is not None:
        extract_images(args.path, args.images)
    elif args.markdown:
        extract_markdown(args.path, pages=pages)
    else:
        extract_text(args.path, pages=pages)
