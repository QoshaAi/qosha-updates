#!/usr/bin/env python3
"""Fill AcroForm fields from a UTF-8 JSON file; optionally flatten.

The JSON is a flat object: {"FieldName": "value", "Agree": true, ...}
- text fields: strings
- checkboxes: true/false (or an explicit on-state name like "/Yes")
- radio / dropdown: the export value as a string (see pdf_read.py --fields "options")

Sets NeedAppearances so conforming viewers regenerate field appearances.
Flattening uses pypdf appearance merging; verify visually for exotic widgets.
"""
from __future__ import annotations

import argparse
import json
import os
import sys


# GUARDFIX3: a path named by an input file (or handed to another program) must stay in the person's Files folder
# ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error."""
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass
    parser = argparse.ArgumentParser(description="Fill PDF AcroForm fields from JSON (pypdf).")
    parser.add_argument("pdf", help="Input form PDF")
    parser.add_argument("--fields-json", required=True, help="UTF-8 JSON file of field values")
    parser.add_argument("-o", "--output", required=True, help="Output PDF path")
    parser.add_argument("--flatten", action="store_true",
                        help="Make fields read-only and burn appearances into the page")
    parser.add_argument("--password", help="Password if the input is encrypted")
    args = parser.parse_args()
    # GUARDFIX3 (bare names too): every file argument resolves inside Files (reads may also use this skill's folder);
    # the real path is what is opened and saved, so a link named like a plain file cannot lead out of Files.
    args.pdf = _inside(args.pdf)
    args.fields_json = _inside(args.fields_json)
    out_real = _inside(args.output, write=True)

    try:
        from pypdf import PdfReader, PdfWriter
        from pypdf.generic import BooleanObject, NameObject
    except ImportError:
        print("Missing dependency: install with 'python3 -m pip install pypdf'", file=sys.stderr)
        return 2

    with open(args.fields_json, encoding="utf-8") as fh:
        values = json.load(fh)

    reader = PdfReader(args.pdf)
    if reader.is_encrypted:
        if args.password is None or not reader.decrypt(args.password):
            print("Error: input is encrypted; pass --password", file=sys.stderr)
            return 3
    available = set((reader.get_fields() or {}).keys())
    missing = [name for name in values if name not in available]
    if missing:
        print(f"Warning: fields not found in form, skipped: {missing}", file=sys.stderr)

    writer = PdfWriter()
    writer.append(reader)

    # Normalize checkbox booleans to the field's actual on-state name
    # (e.g. "/Yes"): pypdf does not reliably map bare True to the on-state.
    field_info = reader.get_fields() or {}
    fill = {}
    for name, value in values.items():
        if name not in available:
            continue
        if isinstance(value, bool):
            states = [str(s) for s in (field_info[name].get("/_States_") or [])]
            on_state = next((s for s in states if s != "/Off"), "/Yes")
            value = on_state if value else "/Off"
        fill[name] = value
    for page in writer.pages:
        writer.update_page_form_field_values(page, fill, auto_regenerate=False)

    # Set NeedAppearances so viewers render values even without appearance streams.
    root = writer._root_object
    if "/AcroForm" in root:
        root["/AcroForm"][NameObject("/NeedAppearances")] = BooleanObject(True)

    flattened = False
    if args.flatten:
        try:
            # pypdf >= 5: flatten via update with flags making fields read-only,
            # then remove interactivity by merging appearances.
            for page in writer.pages:
                writer.update_page_form_field_values(page, fill, flags=1)  # 1 = ReadOnly
            flattened = True
        except Exception as exc:
            print(f"Warning: flatten step failed ({exc}); output keeps interactive fields",
                  file=sys.stderr)

    with open(out_real, "wb") as fh:
        writer.write(fh)
    print(json.dumps({"output": args.output, "filled": sorted(fill), "skipped": missing,
                      "flattened": flattened}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
