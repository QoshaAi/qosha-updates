#!/usr/bin/env python3
"""Stamp/watermark every page of a PDF with page 1 of another PDF."""
from __future__ import annotations

import argparse
import json
import os
import sys


# GUARDFIX3: a path named by an input file (or handed to another program) must stay in the person's Files folder
# ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error."""
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass
    parser = argparse.ArgumentParser(
        description="Overlay (stamp) or underlay (watermark) a one-page PDF onto every page.")
    parser.add_argument("pdf", help="Input PDF path")
    parser.add_argument("--stamp", required=True, help="One-page PDF to apply (page 1 is used)")
    parser.add_argument("-o", "--output", required=True, help="Output PDF path")
    parser.add_argument("--under", action="store_true",
                        help="Place stamp under the page content (background watermark)")
    parser.add_argument("--password", help="Password if the input is encrypted")
    args = parser.parse_args()
    # GUARDFIX3 (bare names too): every file argument resolves inside Files (reads may also use this skill's folder);
    # the real path is what is opened and saved, so a link named like a plain file cannot lead out of Files.
    args.pdf = _inside(args.pdf)
    args.stamp = _inside(args.stamp)
    out_real = _inside(args.output, write=True)

    try:
        from pypdf import PdfReader, PdfWriter
    except ImportError:
        print("Missing dependency: install with 'python3 -m pip install pypdf'", file=sys.stderr)
        return 2

    reader = PdfReader(args.pdf)
    if reader.is_encrypted:
        if args.password is None or not reader.decrypt(args.password):
            print("Error: input is encrypted; pass --password", file=sys.stderr)
            return 3
    stamp_page = PdfReader(args.stamp).pages[0]

    writer = PdfWriter()
    writer.append(reader)
    for page in writer.pages:
        page.merge_page(stamp_page, over=not args.under)
    with open(out_real, "wb") as fh:
        writer.write(fh)
    print(json.dumps({"output": args.output, "page_count": len(writer.pages),
                      "mode": "under" if args.under else "over"}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
