#!/usr/bin/env python3
"""Extract page ranges from a PDF, optionally rotating and/or compressing pages."""
from __future__ import annotations

import argparse
import json
import os
import sys


# GUARDFIX3: a path named by an input file (or handed to another program) must stay in the person's Files folder
# ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error."""
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


def parse_pages(spec: str, page_count: int) -> list[int]:
    """Parse a 1-based page spec like '1-3,5,9-' into 0-based indices."""
    indices: list[int] = []
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            start_s, _, end_s = part.partition("-")
            start = int(start_s) if start_s else 1
            end = int(end_s) if end_s else page_count
        else:
            start = end = int(part)
        if start < 1 or end > page_count or start > end:
            raise ValueError(f"Page range {part!r} out of bounds (1-{page_count})")
        indices.extend(range(start - 1, end))
    return indices


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass
    parser = argparse.ArgumentParser(
        description="Split/extract pages from a PDF (pypdf). Pages are 1-based: '1-3,5,9-'.")
    parser.add_argument("pdf", help="Input PDF path")
    parser.add_argument("--pages", required=True, help="1-based page spec, e.g. '1-3,5,9-'")
    parser.add_argument("-o", "--output", required=True, help="Output PDF path")
    parser.add_argument("--rotate", type=int, default=0,
                        help="Rotate extracted pages clockwise (multiple of 90)")
    parser.add_argument("--compress", action="store_true",
                        help="Deflate content streams (modest savings; does not recompress images)")
    parser.add_argument("--password", help="Password if the input is encrypted")
    args = parser.parse_args()
    # GUARDFIX3 (bare names too): every file argument resolves inside Files (reads may also use this skill's folder);
    # the real path is what is opened and saved, so a link named like a plain file cannot lead out of Files.
    args.pdf = _inside(args.pdf)
    out_real = _inside(args.output, write=True)

    if args.rotate % 90 != 0:
        print("Error: --rotate must be a multiple of 90", file=sys.stderr)
        return 2

    try:
        from pypdf import PdfReader, PdfWriter
    except ImportError:
        print("Missing dependency: install with 'python3 -m pip install pypdf'", file=sys.stderr)
        return 2

    reader = PdfReader(args.pdf)
    if reader.is_encrypted:
        if args.password is None or not reader.decrypt(args.password):
            print("Error: input is encrypted; pass --password", file=sys.stderr)
            return 3
    try:
        indices = parse_pages(args.pages, len(reader.pages))
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2

    writer = PdfWriter()
    for idx in indices:
        page = reader.pages[idx]
        if args.rotate:
            page.rotate(args.rotate)
        writer.add_page(page)
    if args.compress:
        for page in writer.pages:
            page.compress_content_streams()
    with open(out_real, "wb") as fh:
        writer.write(fh)
    print(json.dumps({"output": args.output, "page_count": len(indices), "rotated": args.rotate}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
