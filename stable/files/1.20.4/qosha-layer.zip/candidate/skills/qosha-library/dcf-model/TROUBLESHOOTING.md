# DCF Model Troubleshooting Guide

**When to read this file:** If recalc.py or validate_dcf.py shows errors OR valuation results seem unreasonable OR case selector not working properly.

## Model Returns Error Values

### #REF! Errors
- Usually caused by formulas referencing wrong rows after headers were inserted
- Solution: Rebuild with correct row references, or start over following layout planning
- Prevention: Define all row positions BEFORE writing formulas

### #DIV/0! Errors
- Division by zero or empty cells. First decide which kind it is; never hide every one with a blanket zero.
- **A zero that is a valid result**: display ratios where a zero denominator has a real meaning, such as "% of ΔRevenue" in a year revenue did not change, or a growth rate from a zero base. Show a label instead of an error: `=IF([Divisor]=0,"n/a",[Numerator]/[Divisor])`. Use 0 only when 0 is the true answer, and never feed the label into later calculations.
- **An invalid or missing input**: anything in the valuation chain, such as diluted shares (per-share value), D + E (WACC weights), WACC minus terminal growth (terminal value), or a missing historical figure. Do not wrap these in IF-to-zero, which would turn a broken valuation into a believable number. Find the missing or wrong input, fix it, or ask the person for it. If it cannot be fixed (for example a private company with no share count), show "n/a" with the reason, as in the valuation summary, and say so in the delivery reply.
- Before delivery, list every remaining "n/a" and confirm none sits in Enterprise Value, Equity Value or the WACC.

### #VALUE! Errors
- Wrong data type in calculation (text instead of number)
- Solution: Verify all inputs are formatted as numbers

## Valuation Seems Unreasonable

### Implied price far too high
- Check terminal value isn't >80% of EV
- Verify terminal growth < WACC
- Review if growth assumptions are realistic
- Consider if margins are too optimistic

### Implied price far too low
- Verify total debt, cash and other claims in the equity bridge are correct (cash added, debt subtracted)
- Check if WACC is too high
- Review if projections are too conservative
- Consider if terminal growth is too low

## Case Selector Not Working

### Selected Case block not updating when switching scenarios
- Verify case selector cell contains 1, 2, or 3
- Check the Selected Case CHOOSE formulas pick the same row and year column from each scenario block, with the selector cell
- Ensure absolute references ($B$6) are used for selector
- Test by manually changing the selector cell and verifying projection values update
