---
name: report-pack
description: Use when the owner wants the usual numbers on a rhythm.
version: 1.0.0
author: Qosha
license: Qosha original (owned by Qosha AI LLC)
metadata:
  hermes:
    tags:
    - Reporting
    - Finance
    - Briefing
    related_skills:
    - report-builder
    - business-pulse
    - cash-flow-snapshot
    - invoice-chase
---
# Deliver the regular report pack

Bring the numbers the owner already tracks, with just enough context to act, in one briefing: "what moved, and is the
business otherwise fine?" report-builder supplies the tracked numbers from the owner's saved reports; business-pulse
supplies the picture around them. This skill combines them and recalculates nothing.

## When to Use
- "Run my report pack."
- "Numbers please, the usual."
- "Have this ready every Monday morning."
- "Send me the weekly figures with a quick note on how things look."

Not for: defining or changing which numbers are tracked (use report-builder) or a one-off health check (use
business-pulse).

## What it needs
- **Required:** the name of a saved report from report-builder, or a description of a new pack (report-builder sets it
  up).
- **Data:** whatever connected apps or uploaded CSV or Excel files report-builder uses; business-pulse reads whatever
  accounting, payments, store or CRM apps are connected. Reading only.
- **From Memory:** saved reports, whether a schedule was offered and the answer, preferred file format, time zone,
  and how much context the owner wants. Qosha default, which the owner can change: one short paragraph of context.
  New or changed settings are used for this run; save them to Memory only after showing the exact entry and the
  owner says yes.

## Steps
1. **Get the tracked numbers from report-builder.** It owns the definition, the data, the maths and the workbook.
   - A saved pack runs with no questions.
   - A new pack gets report-builder's single confirmation, nothing more.
   - Done when the figures, their baselines and the workbook link are back.
2. **Get the context from business-pulse** for the same period: cash, sales direction, pipeline, items to watch, and
   the most pressing issue. Use its figures exactly as returned, so there is only one set of numbers.
3. **Merge both into one briefing,** in one message. Never two separate deliveries.
   - Tracked figures first, each with its baseline and currency code.
   - Then the context note, at the length the owner set.
   - Name any source that was unavailable.
4. **Raise scheduling once,** and only after a run the owner found useful.
   - Ask in plain words with a day and time, e.g. "Want this every Friday at 3pm?"
   - On a yes, create the Automation and confirm its day, time and time zone.
   - After an explicit no, offer to remember that, showing the exact fact to be saved. Save it only on a yes.
   - No answer saves nothing. Don't repeat the offer in this chat; it may come back once after a later useful run.
     Silence is never stored as a refusal.
5. **On scheduled runs, ask nothing.** No questions, confirmations or offers. Anything that would have needed a
   question is delivered as a named gap.
6. **On interactive runs, end with a few follow-ups that fit:** cash-flow-snapshot for a cash concern, invoice-chase
   when overdue invoices showed up, report-builder to change the tracked numbers. Leave out any the owner declined.

## Where results go
- **Chat:** one briefing: tracked figures with baselines, the context note, and a link to the workbook.
- **Your files:** one page (HTML unless Memory says otherwise) where tracked figures and context are visibly separate,
  watch items stand out and unavailable sources are named; and report-builder's Excel workbook.
- Add: "Not financial advice."

## What waits for the approval card
Nothing needs an approval card by default: this skill only reads, and no app is written to. If the owner asks to
pass the pack on, use only what Qosha can do today:

- **Send the briefing by Gmail:** one exact send on Qosha's approval card in the chat with the briefing in the message body, or
  copy-ready text in Chat (a Gmail draft only when the person asks for one).
- **Send it from Outlook:** after the person allows it on the card, Qosha puts a draft in the owner's mailbox; the owner attaches anything
  they want and presses Send.
- **The workbook or page as an attachment:** Both can go as attachments of one exact Gmail send (the Google tool `send_gmail_message` with its `attachments`); the card shows every file. Both also stay in Your files.
- **Share the pack** (a Drive link, a shared file, access for someone else): Qosha can't share yet, so this never
  goes on Qosha's approval card in the chat. Say so, and leave the workbook and page in Your files for the owner to share themselves.
- Never upload or share a file to get around these limits.

Qosha reports each item as prepared, waiting on the approval card, or handed to the owner. Whether it went out shows in the step's own result after the owner allows it on the card in the chat; this skill never says it was sent, posted or paid.

Creating the Automation needs the owner's yes to the plan shown (what, when, where results go). A yes to the schedule
never approves a send.

## When an app isn't connected
- **No apps at all:** ask once for an export (CSV or Excel) and build from the file. A schedule can still be kept.
- **No mailbox:** emailing the briefing needs Gmail through Qosha's Google sign-in or Outlook in Connections. With
  neither connected, prepare no email decision: give the briefing as text to copy, and leave the workbook and page in
  Your files for the owner to send.
- A later scheduled run with no fresh file says a new export is needed; it never shows old figures as current.
- To add data sources, connect an accounting app (QuickBooks, Xero), payments (Stripe, Square) or store (Shopify) in
  Connections.
- Never ask for passwords or keys in chat.

## Be careful
- A source fails on a scheduled run: the briefing still arrives, with that figure shown as "n/a" and its source
  named. Incomplete data never cancels a delivery.
- Pack and pulse cover different scopes (one shop versus the whole company): pulse figures stay context and are never
  used to divide pack figures.
- Never say a schedule exists unless the Automation does.
- Show times in the owner's time zone, with the zone named.
- Never estimate a missing figure or reuse last period's.

## How to check it worked
- With a saved pack, "numbers please, the usual": no questions; one message with figures, context and workbook link.
- Accept a Friday afternoon schedule: it shows in Automations; its run asks nothing and offers nothing.
- Say no to the schedule and agree to it being remembered, run twice more: the offer doesn't come back. Ignore the
  offer instead: Memory gains nothing.
- Break one connection before a scheduled run: the briefing still arrives and names that source as unavailable.
- The pulse cash figure and the pack's figures never disagree, because the pack never recalculates the pulse.
