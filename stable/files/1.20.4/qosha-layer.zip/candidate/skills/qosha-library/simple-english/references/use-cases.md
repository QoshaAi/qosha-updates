# Use cases beyond documentation

STE was built for aircraft maintenance manuals. The same properties — one meaning per word, short sentences, condition-first commands — transfer to any text where misreading has a cost. Today many STE users work outside aerospace and defense.

Each case below names the mode and the adaptations.

## Error messages and CLI output

Mode: procedural. This is the highest-value target: an error message is a 2 a.m. instruction to a stressed reader.

Pattern: state what happened (past simple), state the cause if known, give the command or condition to fix it.

> **Before:** Oops! Something went wrong while attempting to establish a connection. Please ensure your credentials are properly configured and try again.
> **After:** The connection failed. Make sure that your credentials are correct. Then connect again.

Give the exact cause (for example, which password was wrong) only when the error data gives it. Do not add a cause, a name or a setting that the source does not have.

## Runbooks and standard operating procedures

Mode: strict-leaning procedural. This is STE's home turf — an on-call runbook is a maintenance manual.

- Every step imperative, one instruction per step, conditions first.
- Warnings before the step, command first, risk second.
- 20-word limit enforced hard: an operator under pager stress reads each sentence once.

## Incident reports and postmortems

Mode: descriptive. Simple past only — a timeline in present perfect ("we have identified...") hides when things happened.

> **Before:** We have identified an issue that may have impacted some users' ability to access the service.
> **After:** We found a problem. Some users possibly could not get access to the service.

Keep the uncertainty the source has: "may have impacted" becomes "possibly". Do not claim what the author knows or does not know: if details are missing (how many users, for how long), list them separately as questions for the author. Add times, counts or a cause only when the source gives them. For example, if the incident notes say "requests failed from 14:02 to 14:31 UTC" and "the 14:00 deploy removed the cache warmup step", the report can state those facts plainly, in the simple past.

## Commit messages and PR descriptions

Mode: descriptive body, imperative subject. Convention already matches STE: imperative subject line, plain past facts in the body. Apply the substitution table and the 25-word limit to the body. Delete "this PR aims to".

## API changelogs and release notes

Mode: descriptive. One entry, one change, one sentence where possible. "Breaking:" entries follow the warning pattern — command first: "Update your calls to `v2/users`. The `name` field split into `first_name` and `last_name`."

## Instructions for AI agents (prompts, AGENTS.md, skills)

Mode: procedural. A system prompt is a procedure executed by a reader with no ability to ask questions — the exact reader STE was designed for.

- One instruction per sentence keeps rules independently quotable and hard to half-follow.
- One word, one meaning prevents the model from treating "check", "verify", and "validate" as three different operations.
- Condition-first ("If the build fails, stop") beats trailing conditions, which models drop.
- A model reads "should" as optional. If the author means a requirement, write "must". If the author means a recommendation, keep it as a recommendation ("We recommend X because Y."). If the strength is not clear, ask the author. Never delete a rule or advice to remove "should".

## Support macros and status-page updates

Mode: descriptive, 25-word limit. Non-native readers are the majority of many user bases. Replace "we sincerely apologize for any inconvenience this may have caused" with the facts that the source gives: what stopped, for how long, and what happens next. If the update says "the API was unavailable for 18 minutes and uploads from that time are queued", write "The API was down for 18 minutes. Uploads from this time are in a queue." If the source does not give a duration or a count, do not add one.

## Translation and localization prep

Mode: strict. STE's original purpose was making English readable for non-native maintenance crews, and it doubles as pre-editing for machine translation. One meaning per word plus complete grammar (articles, "that") removes most translation ambiguity. If your docs get localized, STE cuts the error rate and the cost.

## UI copy and empty states

Mode: procedural, hard length limits. Buttons and labels are technical names (exempt). Body copy follows the rules: "No projects yet. Create a project to start." Nothing else survives at this length anyway.

## Where STE does not fit

Marketing pages, launch posts, blog voice, brand writing. STE deletes persuasion on purpose. Write those in your own voice — then use STE for the docs the landing page links to.
