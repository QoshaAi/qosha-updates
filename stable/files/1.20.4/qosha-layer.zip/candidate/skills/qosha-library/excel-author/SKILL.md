---
name: excel-author
description: Use for careful, checkable financial Excel workbooks.
version: 1.0.0
author: Qosha (based on MIT/Apache-licensed work; see NOTICE)
license: Apache-2.0
platforms:
- linux
- macos
- windows
metadata:
  hermes:
    tags:
    - excel
    - openpyxl
    - finance
    - spreadsheet
    - modeling
    related_skills:
    - xlsx
    - dcf-model
    - 3-statement-model
---
# excel-author

## In Qosha

In Qosha, anything that sends, posts, pays, deletes, shares or changes a calendar is put to the person on Qosha's approval card in the chat first; never claim it was done directly. Keep files in Your files.

Produce an .xlsx file in Your files using `openpyxl`. Follow the banker-grade conventions below so the model is auditable, flexible, and reviewable by someone other than the person who built it. This skill assumes headless Python; upstream credit is in NOTICE.

## Output contract

- Write to `<Your files>/models/<name>.xlsx`, where `<Your files>` is the full path of the Your files folder. Create `models/` if it does not exist. Never write to `./out` or any other folder outside Your files.
- Tell the person where the file is in Your files in your final message.
- One logical model per file. Do not append to or overwrite an existing workbook unless explicitly asked; save changes as a new file name (for example `<name>-v2.xlsx`).

## Before you start: check the tools

Neither tool is installed today, and you must never install them. Check each one and say plainly what is missing:

```bash
python3 -c "import openpyxl"                 # needed to write any workbook
command -v libreoffice || command -v soffice # needed only to calculate formulas
```

- **openpyxl missing:** stop. Tell the person the `openpyxl` library is missing, so a workbook can't be built here. Offer a fallback: the same model laid out as CSV files or a table in Your files, with every formula written out in words.
- **LibreOffice missing:** you can still build the workbook, but its formulas will not be calculated here (see "Recalculating"). Say so; never report calculated results you did not get.

## Core conventions (non-negotiable)

### Blue / black / green cell color
- **Blue** (`Font(color="0000FF")`) — hardcoded input a human entered. Revenue drivers, WACC inputs, terminal growth, market data.
- **Black** (default) — formula that calculates something. Every derived cell is a live Excel formula.
- **Green** (`Font(color="006100")`) — a cell that only pulls a value from another sheet or file (for example `=Revenue_FY2024`).

A reviewer can then scan the sheet and immediately see what's an assumption vs. what's computed.

### Formulas over hardcodes
Every calculation cell MUST be a formula string, never a number computed in Python and pasted as a value.

```python
# WRONG — silent bug waiting to happen
ws["D20"] = revenue_prior_year * (1 + growth)

# CORRECT — flexes when the user changes the assumption
ws["D20"] = "=D19*(1+Growth_Rate)"
```

The only hardcoded numbers permitted:
1. Raw historical inputs (actual revenues, reported EBITDA, etc.)
2. Assumption drivers the user is meant to flex (growth rates, WACC inputs, terminal g)
3. Current market data (share price, debt balance)

Every one of them gets a cell comment with its source or reason (see below). If you catch yourself computing a value in Python and writing the result, stop.

### Named ranges for cross-sheet references
Use a named range for any figure referenced from another sheet, a deck, or a memo, and never write a raw `Sheet!A1` reference across sheets.

```python
from openpyxl.workbook.defined_name import DefinedName
wb.defined_names["WACC"] = DefinedName("WACC", attr_text="Inputs!$C$8")
# then elsewhere:
calc["D30"] = "=D29/(1+WACC)"
```

(On openpyxl older than 3.1, use `wb.defined_names.append(DefinedName(...))` instead of the dictionary form.)

### Checks tab
Include a `Checks` tab that ties everything and surfaces TRUE/FALSE, with every check pointing at a sheet that exists in the workbook:
- Balance sheet balances (total assets = total liabilities + total equity)
- Cash flow ties to period-over-period cash change on the balance sheet
- Sum-of-parts ties to consolidated totals
- The sensitivity table's center cell equals the base-case output
- An `ALL CHECKS PASS` cell that is TRUE only when every check is TRUE

Example (the balance sheet tab is named `BS` and holds the named totals):
```python
checks = wb.create_sheet("Checks")
checks["A2"] = "BS balances"
checks["B2"] = "=ABS(Total_Assets-(Total_Liabilities+Total_Equity))<0.01"  # TRUE/FALSE
```

### Cell comments on every hardcoded input
Add the comment AS you create the cell, not later.

```python
from openpyxl.comments import Comment
ws["C2"] = 1_250_000_000
ws["C2"].font = Font(color="0000FF")
ws["C2"].comment = Comment("Source: 10-K FY2024, p.47, revenue line", "model")
```

Format: `Source: [System/Document], [Date], [Reference], [URL if applicable]`. For an assumption the person chose, write `Assumption: [who set it], [date], [reason]`.

Never defer sourcing. Never write `TODO: add source`.

## Skeleton: a small consistent model

Every sheet the formulas use exists, every input has a comment, every cross-sheet value goes through a name, and the check points at the balance sheet. Replace the figures with the person's own.

```python
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.comments import Comment
from openpyxl.workbook.defined_name import DefinedName

BLUE = Font(color="0000FF")
GREEN = Font(color="006100")
HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
HEADER_FONT = Font(color="FFFFFF", bold=True)

def name(wb, nm, ref):
    wb.defined_names[nm] = DefinedName(nm, attr_text=ref)

def blue_input(ws, cell, value, note):
    ws[cell] = value
    ws[cell].font = BLUE
    ws[cell].comment = Comment(note, "model")

wb = Workbook()

# --- Inputs tab: only blue, commented inputs ---
inp = wb.active
inp.title = "Inputs"
inp["A1"] = "KEY INPUTS"
inp["A1"].font = HEADER_FONT
inp.merge_cells("A1:C1")
for col in range(1, 4):
    inp.cell(row=1, column=col).fill = HEADER_FILL
inp["B3"] = "Revenue FY2024"
blue_input(inp, "C3", 1_250_000_000, "Source: 10-K FY2024, p.47, revenue line")
inp["B4"] = "Revenue growth"
blue_input(inp, "C4", 0.12, "Assumption: owner, 2026-11-03, plan for next year")
name(wb, "Revenue_FY2024", "Inputs!$C$3")
name(wb, "Growth_Rate", "Inputs!$C$4")

# --- Projection tab: green links in, black formulas ---
proj = wb.create_sheet("Projection")
proj["B2"] = "Revenue FY2024"
proj["C2"] = "=Revenue_FY2024"          # pulls from Inputs: green
proj["C2"].font = GREEN
proj["B3"] = "Projected revenue FY2025"
proj["C3"] = "=C2*(1+Growth_Rate)"      # calculation: black

# --- BS tab: balance sheet totals (inputs here are illustrative) ---
bs = wb.create_sheet("BS")
bs["B2"] = "Total assets"
blue_input(bs, "C2", 900_000_000, "Source: balance sheet FY2024, total assets")
bs["B3"] = "Total liabilities"
blue_input(bs, "C3", 500_000_000, "Source: balance sheet FY2024, total liabilities")
bs["B4"] = "Total equity"
blue_input(bs, "C4", 400_000_000, "Source: balance sheet FY2024, total equity")
name(wb, "Total_Assets", "BS!$C$2")
name(wb, "Total_Liabilities", "BS!$C$3")
name(wb, "Total_Equity", "BS!$C$4")

# --- Checks tab ---
chk = wb.create_sheet("Checks")
chk["A2"] = "BS balances"
chk["B2"] = "=ABS(Total_Assets-(Total_Liabilities+Total_Equity))<0.01"
chk["A10"] = "ALL CHECKS PASS"
chk["B10"] = "=AND(B2:B9)"

out = Path("<Your files>") / "models" / "model.xlsx"   # full path of Your files
out.parent.mkdir(parents=True, exist_ok=True)
wb.save(out)
```

## Section headers with merged cells

openpyxl quirk: when you merge, set the value on the top-left cell and style the full range separately.

```python
ws["A7"] = "CASH FLOW PROJECTION"
ws["A7"].font = HEADER_FONT
ws.merge_cells("A7:H7")
for col in range(1, 9):  # A..H
    ws.cell(row=7, column=col).fill = HEADER_FILL
```

## Sensitivity tables

Build with loops, not hardcoded formulas per cell. Rules:

- **Odd number of rows/cols** (5×5 or 7×7) — guarantees a true center cell.
- **Headers are formulas, not typed rates.** The center row/col headers link to the model's base-case WACC and terminal growth; the others step away from them by a blue "step" input. Changing a base input moves the whole table.
- **Every cell references its own row and column header**, never a number typed into the formula.
- **Every cell computes the full output**: here the implied share price = (present value of forecast cash flows + present value of terminal value − net debt) ÷ diluted shares.
- **Center cell = base case.** It must equal the model's `Implied_Share_Price`; add that tie to the Checks tab.
- **Highlight the center cell** with medium-blue fill (`"BDD7EE"`) and bold.

The model must already define these named ranges: `WACC`, `Terminal_g` (inputs), `FCF_range` (forecast free cash flows), `Year_offset` (1, 2, 3… for the same columns), `FCF_final` (last forecast year's cash flow), `Final_year` (its year number), `Net_debt`, `Diluted_shares`, `Implied_Share_Price` (the base-case price cell).

```python
from openpyxl.utils import get_column_letter, quote_sheetname, absolute_coordinate
from openpyxl.comments import Comment
from openpyxl.workbook.defined_name import DefinedName

BOLD = Font(bold=True)
N = 5                                   # 5x5: WACC (rows) x terminal growth (cols)
mid = N // 2
start_row = 40
hdr_row = start_row + 1                 # growth headers live on this row
first_row = start_row + 2               # WACC headers live in column A from here

ws.cell(row=start_row, column=1).value = "Implied share price ($)"
ws.cell(row=start_row, column=1).font = BOLD

# Blue step inputs, documented
ws["H40"] = "WACC step"
ws["I40"] = 0.005
ws["I40"].font = BLUE
ws["I40"].comment = Comment("Assumption: sensitivity step, 0.5 percentage points", "model")
ws["H41"] = "Growth step"
ws["I41"] = 0.005
ws["I41"].font = BLUE
ws["I41"].comment = Comment("Assumption: sensitivity step, 0.5 percentage points", "model")

# Growth headers (row) and WACC headers (column A): formulas off the base case
for j in range(N):
    ws.cell(row=hdr_row, column=2 + j).value = f"=Terminal_g+({j - mid})*$I$41"
for i in range(N):
    ws.cell(row=first_row + i, column=1).value = f"=WACC+({i - mid})*$I$40"

# Each cell: full price, using its own headers
for i in range(N):
    r = first_row + i
    w = f"$A{r}"                                  # this row's WACC header
    for j in range(N):
        c = 2 + j
        g = f"{get_column_letter(c)}${hdr_row}"   # this column's growth header
        ws.cell(row=r, column=c).value = (
            f"=(SUMPRODUCT(FCF_range/(1+{w})^Year_offset)"
            f"+FCF_final*(1+{g})/({w}-{g})/(1+{w})^Final_year"
            f"-Net_debt)/Diluted_shares"
        )

# Highlight center cell (base case), name it, and tie it to the model through the name
center = ws.cell(row=first_row + mid, column=2 + mid)
center.fill = PatternFill("solid", fgColor="BDD7EE")
center.font = BOLD
wb.defined_names["Sensitivity_Center"] = DefinedName(
    "Sensitivity_Center",
    attr_text=f"{quote_sheetname(ws.title)}!{absolute_coordinate(center.coordinate)}",
)
chk["A3"] = "Sensitivity center = base case"
chk["B3"] = "=ABS(Sensitivity_Center-Implied_Share_Price)<0.01"   # names only, no Sheet!A1
```

## Recalculating

openpyxl writes formula strings but does not compute them. Excel recalculates when the person opens the file, but checks you run here need computed values.

- **LibreOffice available:** recalculate a copy, never the original, and keep LibreOffice's scratch files inside Your files. `scripts/recalc.py` overwrites the file it is given and makes its scratch folder in the system temp folder unless `TMPDIR` says otherwise. Each run gets a new output name it never overwrites, and its own new, empty scratch folder; clean up only what this run created:

  ```bash
  F="<Your files>/models"
  OUT="$F/model-calculated-$(date +%Y%m%d-%H%M%S).xlsx"     # fresh name for this run
  if [ -e "$OUT" ]; then echo "$OUT already exists; stopping"; exit 1; fi
  SCRATCH="$(mktemp -d "$F/.recalc-XXXXXX")" || exit 1      # new, empty, owned by this run
  cp "$F/model.xlsx" "$OUT"
  STATUS=0
  TMPDIR="$SCRATCH" python3 "${HERMES_SKILL_DIR}/scripts/recalc.py" "$OUT" || STATUS=$?
  rmdir "$SCRATCH" || echo "scratch folder $SCRATCH not empty; left in place"
  if [ "$STATUS" -ne 0 ]; then rm -f "$OUT"; echo "recalculation failed"; fi
  ```

  `rmdir` removes the folder only if it is empty, so nothing else is ever deleted. If the run failed, only the copy this run made is removed and you tell the person the workbook was not calculated.

  Only when the person asked to replace the original may you run it on `model.xlsx` itself.
- **LibreOffice not available (the case today):** don't run `recalc.py`. Deliver the workbook and tell the person plainly: "The formulas are written but not calculated here; they calculate when you open the file in Excel. I haven't seen the results, so please open it and check the Checks tab shows TRUE." Never quote a calculated number, a check result or a share price you did not get.

## Model layout planning

Before writing any formula:
1. Define ALL section row positions
2. Write ALL headers and labels
3. Write ALL section dividers and blank rows
4. THEN write formulas using the locked row positions

This prevents the cascading-formula-breakage pattern where inserting a header row after formulas are written shifts every downstream reference.

## Check the workbook, then the owner

### Workbook checks (every time, before handing over)
Re-open the saved file with openpyxl and confirm:
- Every name used in a formula exists in `wb.defined_names`, and every sheet a formula mentions exists.
- No calculation cell holds a typed number; every blue cell has a comment.
- The Checks tab has a check for each tie listed above, plus `ALL CHECKS PASS`.
- If you recalculated a copy: open it with `data_only=True` and confirm no cell shows an Excel error (`#REF!`, `#NAME?`, `#DIV/0!`, `#VALUE!`, `#N/A`) and every check is TRUE. Report any failure plainly.
- If you could not recalculate: say the results are uncalculated (see above), and list what the person should look at when they open it.

### Owner checkpoints (large models: DCFs, 3-statement, LBO)
Stop and show the person intermediate results before continuing. Catching a wrong margin assumption before you've built downstream sensitivity tables saves an hour.
- After Inputs block → show raw inputs and their sources, confirm before projecting
- After Revenue projections → confirm top line + growth
- After FCF build → confirm the full schedule
- After WACC → confirm inputs
- After valuation → confirm the equity bridge (net debt, diluted shares)
- THEN build sensitivity tables

## When NOT to use this skill

- The person wants a workbook changed inside Google Sheets: Qosha can read Sheets but not edit them. Build the workbook in Your files for them to open or copy in; a write into another connected spreadsheet app happens only if that app is connected and offers it, and then it waits on Qosha's approval card in the chat until they allow it on the card.
- Pure tabular data export with no formulas — a CSV file in Your files is simpler.
- Dashboards / charts with heavy interactivity — use a real BI tool.

## Attribution

The conventions here (blue/black/green, formulas over hardcodes, named ranges, sensitivity rules) are adapted from Apache-2.0 licensed work; the full credit is in NOTICE.
