# Citation formats per output target

The ledger is format-agnostic: `sources.py render --style ...` emits the block,
this file says where it goes and what the inline marker looks like.

## Markdown / chat answers

Inline `[n]` immediately after the sentence. Block at the end:

```
## Sources

[1] https://example.com/a — Page title
[2] https://example.com/b
```

`--style plain` gives a bare `Sources:` header for chat replies where a
markdown heading would be noise.

## PDF (`pdf` / `pdf-files` skills)

Keep the inline `[n]` markers and end the document with a Sources section
rendered with `--style markdown` (or `plain`). Use one numbering system only:
the ledger ids. Keep the Markdown draft in Your files as the source of truth so
`verify` still runs on it.

## Word (.docx, `docx` / `word-documents` skills)

Qosha's Word tools don't make real Word footnotes, and nothing here converts
Markdown footnotes into Word footnotes. Use the supported form: inline `[n]`
markers in the text and a "Sources" heading at the end with one paragraph per
source, taken from `render --style plain` (or `markdown`). Keep the Markdown
draft in Your files as the source of truth, run `verify` on it, and build the
.docx from that same text so the numbers match.

## Slides (.pptx, `powerpoint` / `slide-decks` skills)

Inline `[n]` in the bullet, one "Sources" slide at the end rendered with
`--style plain`. Never put a URL in a body bullet — it wrecks the layout and
can't be clicked in a projected deck.

## Spreadsheets (.xlsx, `xlsx` / `spreadsheets` skills)

Add a `source` column holding the id, plus a `Sources` sheet built from
`render --style plain`. Do not paste URLs into data cells.

## Wiki / multi-page output (`knowledge-wiki` skill)

Per-page Sources block, ids shared across pages from one ledger. Because ids
are ledger identities, `[7]` means the same page everywhere in the wiki — that
consistency is the reason not to reset the ledger between pages of one build.

## Research papers

Find papers with the `arxiv` skill and cite them here like any other source
(inline `[n]` plus a Sources section). If the person wants a bibliography file,
`--style bibtex` writes `@misc` entries keyed `source<N>` into a `.bib` file in
Your files. Nothing in Qosha checks LaTeX `\cite{}` keys against that file, and
journal or conference formatting is not covered; say so if asked.

## Code and config artifacts

No citations inside generated code. If provenance matters, put it in a doc
header or a note beside the file in Your files — not in comments scattered
through source.
