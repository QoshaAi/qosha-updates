---
name: infographic
description: Use to turn facts or a report into an infographic.
version: 1.56.1
author: Qosha (based on MIT/Apache-licensed work; see NOTICE)
license: MIT
platforms:
- linux
- macos
- windows
metadata:
  hermes:
    tags:
    - infographic
    - visual-summary
    - creative
    - image-generation
---
# Infographic Generator

## In Qosha

In Qosha, anything that sends, posts, pays, deletes, shares or changes a calendar is put to the person on Qosha's approval card in the chat first; never claim it was done directly. Keep files in Your files.

Adapted from an MIT-licensed open-source infographic skill (credit in NOTICE) for Qosha's tool ecosystem.

Two dimensions: **layout** (information structure) × **style** (visual aesthetics). Freely combine any layout with any style.

## When to Use

Trigger this skill when the user asks to create an infographic, visual summary, information graphic, or uses terms like "信息图", "可视化", or "高密度信息大图". The user provides content (text, file path, URL, or topic) and optionally specifies layout, style, aspect ratio, or language.

## Options

| Option | Values |
|--------|--------|
| Layout | 21 options (see Layout Gallery), default: bento-grid |
| Style | 21 options (see Style Gallery), default: craft-handmade |
| Aspect | Named: landscape (16:9), portrait (9:16), square (1:1). Custom: any W:H ratio (e.g., 3:4, 4:3, 2.35:1). The local SVG build keeps the exact ratio; see Step 6 for the Canva path |
| Language | en, zh, ja, etc. |

## Layout Gallery

| Layout | Best For |
|--------|----------|
| `linear-progression` | Timelines, processes, tutorials |
| `binary-comparison` | A vs B, before-after, pros-cons |
| `comparison-matrix` | Multi-factor comparisons |
| `hierarchical-layers` | Pyramids, priority levels |
| `tree-branching` | Categories, taxonomies |
| `hub-spoke` | Central concept with related items |
| `structural-breakdown` | Exploded views, cross-sections |
| `bento-grid` | Multiple topics, overview (default) |
| `iceberg` | Surface vs hidden aspects |
| `bridge` | Problem-solution |
| `funnel` | Conversion, filtering |
| `isometric-map` | Spatial relationships |
| `dashboard` | Metrics, KPIs |
| `periodic-table` | Categorized collections |
| `comic-strip` | Narratives, sequences |
| `story-mountain` | Plot structure, tension arcs |
| `jigsaw` | Interconnected parts |
| `venn-diagram` | Overlapping concepts |
| `winding-roadmap` | Journey, milestones |
| `circular-flow` | Cycles, recurring processes |
| `dense-modules` | High-density modules, data-rich guides |

Full definitions: `references/layouts/<layout>.md`

## Style Gallery

| Style | Description |
|-------|-------------|
| `craft-handmade` | Hand-drawn, paper craft (default) |
| `claymation` | 3D clay figures, stop-motion |
| `kawaii` | Japanese cute, pastels |
| `storybook-watercolor` | Soft painted, whimsical |
| `chalkboard` | Chalk on black board |
| `cyberpunk-neon` | Neon glow, futuristic |
| `bold-graphic` | Comic style, halftone |
| `aged-academia` | Vintage science, sepia |
| `corporate-memphis` | Flat vector, vibrant |
| `technical-schematic` | Blueprint, engineering |
| `origami` | Folded paper, geometric |
| `pixel-art` | Retro 8-bit |
| `ui-wireframe` | Grayscale interface mockup |
| `subway-map` | Transit diagram |
| `ikea-manual` | Minimal line art |
| `knolling` | Organized flat-lay |
| `lego-brick` | Toy brick construction |
| `pop-laboratory` | Blueprint grid, coordinate markers, lab precision |
| `morandi-journal` | Hand-drawn doodle, warm Morandi tones |
| `retro-pop-grid` | 1970s retro pop art, Swiss grid, thick outlines |
| `hand-drawn-edu` | Macaron pastels, hand-drawn wobble, stick figures |

Full definitions: `references/styles/<style>.md`

Only the 21 styles above exist. If a layout file or the owner names another style, map it to a shipped one and say so: cartoon or hand-drawn → `hand-drawn-edu`; isometric 3D or blueprint → `technical-schematic`; graphic novel or comic → `bold-graphic`; paper cut-out → `craft-handmade`; pop art → `retro-pop-grid`; old notebook or sketchbook → `aged-academia`. `comic-strip` is a layout, not a style.

## Recommended Combinations

| Content Type | Layout + Style |
|--------------|----------------|
| Timeline/History | `linear-progression` + `craft-handmade` |
| Step-by-step | `linear-progression` + `ikea-manual` |
| A vs B | `binary-comparison` + `corporate-memphis` |
| Hierarchy | `hierarchical-layers` + `craft-handmade` |
| Overlap | `venn-diagram` + `craft-handmade` |
| Conversion | `funnel` + `corporate-memphis` |
| Cycles | `circular-flow` + `craft-handmade` |
| Technical | `structural-breakdown` + `technical-schematic` |
| Metrics | `dashboard` + `corporate-memphis` |
| Educational | `bento-grid` + `chalkboard` |
| Journey | `winding-roadmap` + `storybook-watercolor` |
| Categories | `periodic-table` + `bold-graphic` |
| Product Guide | `dense-modules` + `morandi-journal` |
| Technical Guide | `dense-modules` + `pop-laboratory` |
| Trendy Guide | `dense-modules` + `retro-pop-grid` |
| Educational Diagram | `hub-spoke` + `hand-drawn-edu` |
| Process Tutorial | `linear-progression` + `hand-drawn-edu` |

Default: `bento-grid` + `craft-handmade`

## Keyword Shortcuts

When user input contains these keywords, **auto-select** the associated layout and offer associated styles as top recommendations in Step 3. Skip content-based layout inference for matched keywords.

If a shortcut has **Prompt Notes**, append them to the generated prompt (Step 5) as additional style instructions.

| User Keyword | Layout | Recommended Styles | Default Aspect | Prompt Notes |
|--------------|--------|--------------------|----------------|--------------|
| 高密度信息大图 / high-density-info | `dense-modules` | `morandi-journal`, `pop-laboratory`, `retro-pop-grid` | portrait | — |
| 信息图 / infographic | `bento-grid` | `craft-handmade` | landscape | Minimalist: clean canvas, ample whitespace, no complex background textures. Simple cartoon elements and icons only. |

## Output Structure

All files go in Your files:

```
infographic/{topic-slug}/
├── source-{slug}.{ext}
├── analysis.md
├── structured-content.md
├── content-final.md        (the text to show, in the confirmed language; Step 4b)
├── prompts/infographic.md   (design brief)
├── infographic.svg          (the infographic itself)
├── infographic.html         (the SVG in a page with no scripts, opens beside the chat)
├── canva-export.{png,pdf}   (only on the Canva path, if Canva offers an export; Step 7)
└── check.md                 (what Step 7 checked, and what it could not)
```

Slug: 2-4 words kebab-case from topic. Conflict: append `-YYYYMMDD-HHMMSS`.

## Core Principles

- Preserve source data faithfully — no summarization or rephrasing; the one allowed change is translation into the confirmed language in Step 4b (but **strip any credentials, API keys, tokens, or secrets** before including in outputs)
- Define learning objectives before structuring content
- Structure for visual communication (headlines, labels, visual elements)

## Workflow

### Step 1: Analyze Content

**Load references**: Read `references/analysis-framework.md` from this skill.

1. Save source content (file path or paste → `source.md` using `write_file`)
   - **Backup rule**: If `source.md` exists, rename to `source-backup-YYYYMMDD-HHMMSS.md`
2. Analyze: topic, data type, complexity, tone, audience
3. Detect source language and user language
4. Extract design instructions from user input
5. Save analysis to `analysis.md`
   - **Backup rule**: If `analysis.md` exists, rename to `analysis-backup-YYYYMMDD-HHMMSS.md`

See `references/analysis-framework.md` for detailed format.

### Step 2: Generate Structured Content → `structured-content.md`

Transform content into infographic structure:
1. Title and learning objectives
2. Sections with: key concept, content (verbatim), visual element, text labels
3. Data points (all statistics/quotes copied exactly)
4. Design instructions from user

**Rules**: Markdown only. No new information. Preserve data faithfully. Strip any credentials or secrets from output.

See `references/structured-content-template.md` for detailed format.

### Step 3: Recommend Combinations

**3.1 Check Keyword Shortcuts first**: If user input matches a keyword from the **Keyword Shortcuts** table, auto-select the associated layout and prioritize associated styles as top recommendations. Skip content-based layout inference.

**3.2 Otherwise**, recommend 3-5 layout×style combinations based on:
- Data structure → matching layout
- Content tone → matching style
- Audience expectations
- User design instructions

### Step 4: Confirm Options

Ask in Chat, in one short message, and wait for the answer before building:

**Q1 — Combination**: Present 3+ layout×style combos with rationale. Ask user to pick one.

**Q2 — Aspect**: Ask for aspect ratio preference (landscape/portrait/square or custom W:H). Say that the local SVG keeps any ratio exactly; only the Canva path may round to Canva's own sizes.

**Q3 — Language** (only if source ≠ user language): Ask which language the text content should use.

### Step 4b: Prepare the Final Text → `content-final.md`

`structured-content.md` keeps the source wording. Everything after this step uses `content-final.md` instead.

- **Same language as the source:** `content-final.md` is an exact copy of `structured-content.md`.
- **Another language confirmed in Q3:** translate every title, label and content line of `structured-content.md` into that language. Keep every number, unit, percentage, date, currency amount and proper name exactly as written; keep the meaning, add nothing and drop nothing. Quotes: translate them and mark them as translations, or keep the original wording if the owner prefers.
- Check `content-final.md` against `structured-content.md` line by line: the same sections, the same items, and every number, date and name identical. Fix any difference before going on.
- If the owner wants to see the translated text first, show it in Chat and wait for a yes.

### Step 5: Generate Prompt → `prompts/infographic.md`

**Backup rule**: If `prompts/infographic.md` exists, rename to `prompts/infographic-backup-YYYYMMDD-HHMMSS.md`

**Load references**: Read the selected layout from `references/layouts/<layout>.md` and style from `references/styles/<style>.md`.

Combine:
1. Layout definition from `references/layouts/<layout>.md`
2. Style definition from `references/styles/<style>.md`
3. Base template from `references/base-prompt.md`
4. Final text from `content-final.md` (Step 4b), word for word
5. No other text: every word on the graphic comes from `content-final.md`

Fill `{{CONTENT}}` and `{{TEXT_LABELS}}` from `content-final.md` and `{{LANGUAGE}}` with the confirmed language. The base template's "keep information concise" is about layout and emphasis; it never allows shortening or rewording the text from `content-final.md`.

**Aspect ratio resolution** for `{{ASPECT_RATIO}}`:
- Named presets → ratio string: landscape→`16:9`, portrait→`9:16`, square→`1:1`
- Custom W:H ratios → use as-is (e.g., `3:4`, `4:3`, `2.35:1`)

Save the assembled brief to `prompts/infographic.md` using `write_file`. It is the design brief for Step 6.

### Step 6: Build the Infographic

**Default: a static SVG in Your files.** There is no image-generation tool, so build the graphic yourself:

- Write `infographic.svg` with a `viewBox` that matches the confirmed ratio exactly (for example 3:4 → `0 0 1200 1600`, 2.35:1 → `0 0 2350 1000`). Never round a custom ratio to a preset.
- Follow the layout file for structure and the style file for colours, shapes, line work and type. Painted, clay or photo looks become flat illustrated versions of that style; say this when offering such a style.
- Use only text and numbers from `content-final.md`, with labels exactly as written there. Use system font stacks; no remote fonts, images or links.
- Write `infographic.html`: the same SVG inline in a plain page, with no scripts.
- If a PNG is wanted and a sandbox tool can render the SVG at the confirmed size, save `infographic.png` beside it; otherwise say the SVG and HTML are the deliverables.

**Optional: Canva.** Only if Canva is connected in Connections and offers an action that creates a design. Check which action it offers and which sizes it accepts; if it cannot take the exact ratio, tell the owner before they choose. Prepare the exact content (the text of `content-final.md`) and size as a step on Qosha's approval card in the chat; it runs only after the owner presses Allow this time, and only the step's own result shows it was made. Keep the local SVG and HTML as well: they are the reference for Step 7. If Canva is not connected, say which app to connect and keep the local SVG. Never upload the file anywhere else.

### Step 7: Check the Result

Check the actual file before reporting. Fix anything wrong and check again.

**7a. The local SVG** (always):

1. **Numbers and labels**: read `infographic.svg` back and compare every number, date, name and label with `content-final.md`. Each must appear exactly as written there, once where intended; nothing added, dropped or changed.
2. **Language**: all text is in the confirmed language (the language of `content-final.md`).
3. **Size**: the `viewBox` matches the confirmed ratio.
4. **Readability**: no text smaller than about 1/60 of the image height for labels (larger for titles); no text running outside its box or over other text. Open `infographic.html` with the browser tool and look, if it can load the file. If it cannot, say the visual check was not done; a correct text read-back does not prove the layout looks right.

**7b. The Canva design** (only on the Canva path, after the step's own result confirms the design was made). Checking the local SVG does not check the Canva design; check the design itself:

- If Canva in Connections offers a read or export action, use it: read the design's text, or export it as PNG or PDF into this folder as `canva-export.png` or `canva-export.pdf`. An export into Your files is a read; nothing in Canva changes. Then run checks 1-4 above on what came back: every number, date, name and label against `content-final.md`, the language, the size Canva used against the confirmed ratio, and readability (open the export with the browser tool if it can load it).
- If Canva offers no read or export action, or the result can't be opened, write "Canva design not checked" in `check.md` and in the summary, and ask the owner to look at it in Canva.
- If the Canva design is wrong, never change it directly. Prepare the correction as a new item on Qosha's approval card in the chat (what changes, exactly); it runs only after the owner presses Allow this time, and then check again as above.

**7c.** Write what was checked, what passed and what was not checked (for the local SVG and, if used, the Canva design) to `check.md`.

### Step 8: Output Summary

Report: topic, layout, style, aspect, language, files in Your files, and the Step 7 results for the local SVG and, if used, the Canva design, including any check not done. Say the Canva design exists only if the step results confirmed it.

## References

- `references/analysis-framework.md` — Analysis methodology
- `references/structured-content-template.md` — Content format
- `references/base-prompt.md` — Prompt template
- `references/layouts/<layout>.md` — 21 layout definitions
- `references/styles/<style>.md` — 21 style definitions

## Pitfalls

1. **Data integrity is paramount** — never summarize, paraphrase, or alter source statistics. "73% increase" must stay "73% increase", not "significant increase".
2. **Strip secrets** — always scan source content for API keys, tokens, or credentials before including in any output file.
3. **One message per section** — each infographic section should convey one clear concept. Overloading sections reduces readability.
4. **Style consistency** — the style definition from the references file must be applied consistently across the entire infographic. Don't mix styles.
5. **Keep the ratio** — the SVG keeps any W:H exactly. Only an app path (Canva) may limit sizes; tell the owner before they choose, never silently.
6. **Not done until checked** — never report the infographic as finished before Step 7.
