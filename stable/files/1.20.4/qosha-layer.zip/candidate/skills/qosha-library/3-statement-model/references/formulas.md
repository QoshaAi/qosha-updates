# Formula Reference

**IMPORTANT:** Use the formulas outlined in this reference document unless otherwise specified by the user.

---

## Core Linkages

```
Balance Sheet:        Assets = Liabilities + Equity
Net Income:           IS Net Income → CF Operations (starting point)
Cash Flow:            ΔCash = CFO + CFI + CFF
Cash Tie-Out:         Ending Cash (CF) = Cash (BS Asset)
Cash Monthly/Annual:  Closing Cash (Monthly) = Closing Cash (Annual)
Retained Earnings:    Prior RE + Net Income - Dividends = Ending RE
Paid-in Capital:      Prior Common Stock/APIC + Cash Equity Issued + Equity-settled SBC = Ending Common Stock/APIC
Equity Raise:         ΔCommon Stock/APIC (BS) - Equity-settled SBC = Equity Issuance (CFF)
Year 0 Equity:        Equity Raised (Year 0) = Beginning Equity (Year 1)
```

## Gross Profit Calculation

**IMPORTANT:** Gross Profit must be calculated from Net Revenue, not Gross Revenue.

```
Net Revenue - Cost of Revenue = Gross Profit
```

| Term | Definition |
|------|------------|
| Gross Revenue | Total revenue before any deductions |
| Net Revenue | Gross Revenue - Returns - Allowances - Discounts |
| Cost of Revenue | Direct costs attributable to production of goods/services sold |
| Gross Profit | Net Revenue - Cost of Revenue |

**Note:** Always use Net Revenue (also called "Net Sales" or simply "Revenue" on most financial statements) as the starting point for profitability calculations. Gross Revenue overstates the true top-line performance.

## Margin Formulas

```
Gross Margin %      = Gross Profit / Net Revenue
EBITDA              = EBIT + D&A  (or = Gross Profit - OpEx)
EBITDA Margin %     = EBITDA / Net Revenue
EBIT Margin %       = EBIT / Net Revenue
Net Income Margin % = Net Income / Net Revenue
```

## Credit Metric Formulas

```
Total Debt            = Current Portion of Debt + Long-Term Debt
Net Debt              = Total Debt - Cash
Total Debt / EBITDA   = Total Debt / EBITDA (from IS)
Net Debt / EBITDA     = Net Debt / EBITDA (from IS)
Interest Coverage     = EBITDA / Interest Expense (from IS)
Net Int Exp % Debt    = Net Interest Expense / Long-Term Debt
Debt / Total Cap      = Total Debt / (Total Debt + Total Equity)
Debt / Equity         = Total Debt / Total Equity
Current Ratio         = Total Current Assets / Total Current Liabilities
Quick Ratio           = (Total Current Assets - Inventory) / Total Current Liabilities
```

## Forecast Formulas (% of Net Revenue Method)

```
Cost of Revenue (Forecast) = Net Revenue × Cost of Revenue % Assumption
S&M (Forecast)             = Net Revenue × S&M % Assumption
G&A (Forecast)             = Net Revenue × G&A % Assumption
R&D (Forecast)             = Net Revenue × R&D % Assumption
SBC (Forecast)             = Net Revenue × SBC % Assumption
```

## Working Capital Formulas

```
Accounts Receivable
  Prior AR
  + Revenue (from IS)
  - Cash Collections (plug)
  = Ending AR
  DSO = (AR / Revenue) × 365

Inventory
  Prior Inventory
  + Purchases (plug)
  - COGS (from IS)
  = Ending Inventory
  DIO = (Inventory / COGS) × 365

Accounts Payable
  Prior AP
  + Purchases (from Inventory calc)
  - Cash Payments (plug)
  = Ending AP
  DPO = (AP / COGS) × 365

Net Working Capital = AR + Inventory - AP
ΔWC = Current NWC - Prior NWC
```

## D&A Schedule Formulas

```
Beginning PP&E (Gross)
+ CapEx
= Ending PP&E (Gross)

Beginning Accumulated Depreciation
+ Depreciation Expense
= Ending Accumulated Depreciation

PP&E (Net) = Gross PP&E - Accumulated Depreciation
```

## Debt Schedule Formulas

```
Beginning Debt Balance
+ New Borrowings
- Repayments
= Ending Debt Balance

Interest Expense = Avg Debt Balance × Interest Rate
  (Use beginning balance to avoid circularity, or iterate if circular refs enabled)
```

## Retained Earnings Formula

```
Beginning Retained Earnings
+ Net Income (from IS)
- Dividends
= Ending Retained Earnings
```

Stock-based compensation reaches retained earnings only through net income (it is an expense on the IS). It is not added to retained earnings separately.

## Paid-in Capital (Common Stock / APIC) Formula

```
Beginning Common Stock / APIC
+ Cash Equity Issued (from Assumptions / financing plan; this is the CFF line)
+ Equity-settled SBC (from IS; non-cash, credited to paid-in capital)
= Ending Common Stock / APIC
```

Equity-settled SBC raises paid-in capital without bringing in cash. It is added back in CFO and is never counted as equity issuance in CFF. (Cash-settled awards are a liability, not equity; model them separately if the person has them.)

## NOL (Net Operating Loss) Schedule Formulas

```
NOL CARRYFORWARD SCHEDULE

Beginning NOL Balance (documented opening balance; see Starting Balance Rule)
+ NOL Generated (if Taxable Income before NOL < 0, then ABS(it), else 0)
- NOL Utilized (limited by taxable income and the applicable utilization limit)
= Ending NOL Balance

STARTING BALANCE RULE

First modeled period:
  Beginning NOL Balance = the documented carryforward at the start of the model
    (from tax returns, filed accounts or the accountant)
  Use 0 only when the business's actual history shows no carried losses
    (for example a newly formed business)
  Never reset an existing carryforward to zero
  After the first period: Beginning NOL = prior period Ending NOL
  NOL can only increase through realized losses; it cannot be assumed

TAXABLE INCOME BEFORE NOL

Taxable Income before NOL = EBT + / - book-tax differences
  (Use EBT when the person gives no book-tax differences, and label that as an assumption.)

NOL UTILIZATION CALCULATION

  If Taxable Income before NOL > 0:
    NOL Available = Beginning NOL Balance
    Utilization Limit = the applicable limit for this entity, jurisdiction and year
      (looked up at run time from the official source, recorded with source and date
       in Assumptions; some regimes cap it as a % of taxable income, some have none)
    NOL Utilized = MIN(NOL Available, Utilization Limit)
    Taxable Income = Taxable Income before NOL - NOL Utilized
  If Taxable Income before NOL ≤ 0:
    NOL Utilized = 0
    Taxable Income = 0
    NOL Generated = ABS(Taxable Income before NOL)

CURRENT TAX

Current Tax Expense (= Taxes Payable for the year) = MAX(0, Taxable Income × Tax Rate)
  (Tax Rate: the sourced statutory rate(s) for the jurisdiction and year, or a rate the
   person chose, labeled as an assumption. Losses create an NOL, not negative current tax.)

DEFERRED TAX ASSET (DTA) FOR NOL

DTA - NOL Carryforward = Ending NOL Balance × Tax Rate expected when the NOL is used
  (Whether a DTA may be recognized in full depends on the accounting framework and
   on whether future profits are likely; ask the person or their accountant.)
Recognized DTA = the part of that DTA that may be recognized at the period end
  (0 when none may be recognized)
ΔDTA = Current recognized DTA - Prior recognized DTA
Deferred Tax Expense = -ΔDTA
  (Always from the change in the RECOGNIZED balance, including changes in how much
   may be recognized. Example: opening recognized DTA 20, closing 0 because it can no
   longer be recognized: deferred tax expense = 20, and the cash-flow add-back is the
   same non-cash 20. Deferred tax is 0 only when the recognized balance is unchanged.)
  (DTA increases → deferred tax benefit: lowers tax expense, no cash)
  (DTA decreases → deferred tax expense: raises tax expense, no cash)

INCOME TAX EXPENSE (to IS)

Total Income Tax Expense = Current Tax Expense + Deferred Tax Expense
Net Income = EBT - Total Income Tax Expense

On the CF, the non-cash part is reversed: CFO line "- ΔDTA" (an increase in DTA is
subtracted; a decrease is added back).

Not legal or tax advice; check with a professional.
```

## Balance Sheet Structure

```
ASSETS
  Cash (from CF ending cash)
  Accounts Receivable (from WC)
  Inventory (from WC)
  Total Current Assets
  
  PP&E, Net (from DA)
  Deferred Tax Asset - NOL (from NOL schedule)
  Total Non-Current Assets
  Total Assets

LIABILITIES
  Accounts Payable (from WC)
  Current Portion of Debt (from Debt)
  Total Current Liabilities
  
  Long-Term Debt (from Debt)
  Total Liabilities

EQUITY
  Common Stock / APIC (from Paid-in Capital roll-forward)
  Retained Earnings (from RE schedule)
  Total Equity

CHECK: Assets - Liabilities - Equity = 0
```

## Cash Flow Statement Structure

```
CASH FROM OPERATIONS (CFO)
  Net Income (LINK: IS)
  + D&A (LINK: DA schedule)
  + Stock-Based Compensation (SBC) (LINK: IS or Assumptions)
  - ΔDTA (Deferred Tax Asset) (LINK: Tax/NOL schedule; reverses the non-cash deferred tax in net income: an increase is subtracted, a decrease is added back)
  - ΔAR (LINK: WC)
  - ΔInventory (LINK: WC)
  + ΔAP (LINK: WC)
  = CFO

CASH FROM INVESTING (CFI)
  - CapEx (LINK: DA schedule)
  = CFI

CASH FROM FINANCING (CFF)
  + Debt Issuance (LINK: Debt)
  - Debt Repayment (LINK: Debt)
  + Equity Issuance (LINK: Cash Equity Issued in the Paid-in Capital roll-forward; excludes equity-settled SBC)
  - Dividends (LINK: RE schedule)
  = CFF

Net Change in Cash = CFO + CFI + CFF
Beginning Cash
+ Net Change in Cash
= Ending Cash (LINK TO: BS Cash)
```

## Income Statement Structure

```
Net Revenue
  Growth %
(-) Cost of Revenue
  % of Net Revenue
────────────────
Gross Profit (= Net Revenue - Cost of Revenue)
  Gross Margin %

(-) S&M
  % of Net Revenue
(-) G&A
  % of Net Revenue
(-) R&D
  % of Net Revenue
(-) D&A
(-) SBC
  % of Net Revenue
────────────────
EBIT
  EBIT Margin %

EBITDA
  EBITDA Margin %

(-) Interest Expense
────────────────
EBT (Pre-Tax Income)
(-) Current Tax Expense (from Tax/NOL schedule)
(-) Deferred Tax Expense / (+) Benefit (from Tax/NOL schedule)
────────────────
Net Income (= EBT - Total Income Tax Expense)
  Net Income Margin %
```

NOL utilization and taxable income live only in the Tax/NOL schedule. They are never lines on the IS: the NOL reduces taxable income, not pretax income.

## Check Formulas

```
BS Balance Check:       = Assets - Liabilities - Equity  (must = 0)
Cash Tie-Out:           = BS Cash - CF Ending Cash       (must = 0)
RE Roll-Forward:        = Prior RE + NI - Div - BS RE  (must = 0)
Paid-in Capital:        = Prior CS/APIC + Cash Equity Issued + Equity-settled SBC - BS CS/APIC  (must = 0)
DTA Tie-Out:            = NOL Schedule DTA - BS DTA      (must = 0)
Equity Raise Tie-Out:   = ΔCommon Stock/APIC (BS) - Equity-settled SBC - Equity Issuance (CFF)  (must = 0)
Year 0 Equity Tie-Out:  = Equity Raised (Year 0) - Beginning Equity (Year 1)  (must = 0)
Cash Monthly vs Annual: = Closing Cash (Monthly) - Closing Cash (Annual)  (must = 0)
NOL Utilization Cap:    = NOL Utilized ≤ applicable limit (sourced, with date)  (must be TRUE)
NOL Non-Negative:       = Ending NOL Balance ≥ 0         (must be TRUE)
NOL Starting Balance:   = Beginning NOL (first period) = documented opening carryforward  (must be TRUE)
NOL Accumulation:       = NOL increases only when Taxable Income before NOL < 0
Net Income Tie-Out:     = EBT - Current Tax - Deferred Tax - IS Net Income  (must = 0)
```
