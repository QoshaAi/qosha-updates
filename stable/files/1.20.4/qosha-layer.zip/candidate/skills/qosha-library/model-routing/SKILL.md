---
name: model-routing
description: "Use to choose which AI model fits a task"
version: 1.0.0
author: Qosha
license: Qosha original (owned by Qosha AI LLC)
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [ai-models, cost, privacy, model-picker, second-opinion]
---

# Model routing

Help a person choose which AI model and provider should handle a task, weighing cost, speed, quality, context length and privacy. Recommend only from the model choices this workspace really has. Give a recommendation first, always.

## When to use

- "Which model should I use for this?", "is there a cheaper option?", "can another model double-check this?".
- A task is unusually large, sensitive, expensive or has failed several times with the current model.
- Not for changing spending caps or signing in to anything; those are the person's own steps.

## Ground rules

- **Check, don't remember.** Prices, context limits, speed and which models exist change often. Before stating any of them, open the provider's current pricing or models page, and say the date you checked. If you cannot check, say the recommendation is unconfirmed.
- **Only choices you have verified.** Recommend only from model options you can actually see for this workspace
  (for example a model setting the assistant can read). If you cannot see them, ask the person to paste the names of
  the models available to them, and recommend from that list. Never describe a picker, menu or setting you have not
  seen. Do not suggest personal accounts, personal logins or outside tools.
- **Spending limits: report only what you verified.** Do not promise a spending cap. If the business's actual
  settings show a limit and you can read it, say what it is and where you saw it; otherwise say you could not check
  it. Either way, say that a bigger model can cost several times more per task.
- **The person switches.** Qosha suggests; the person changes the model in their own settings. Qosha never changes a
  model or a limit on its own. Only if a connected app explicitly offers that exact change as an action does Qosha
  prepare it and put it in **Qosha's approval card in the chat**, where it runs only after the person presses **Allow this time**.
- **Privacy follows the business's terms, checked, not assumed.** Before recommending that a task or its data go to
  another provider, check that the provider is available to this workspace through the business's own account and
  that its business terms (data use, retention) fit the data; cite the page and date. If you cannot check, do not
  recommend the transfer: offer a redacted handoff instead (the task with names, contact details, money figures and
  other customer data removed, saved in Your files) that the person can take to another model themselves. Any
  outward transfer Qosha can do through a connected app is its own decision in **Qosha's approval card in the chat**. If the task
  holds sensitive data (health, money, personal details of customers), say exactly what would be sent.

## Steps

1. **Size the task**, not the prompt. A one-line request can be a hard job. Rate it on:
   - ambiguity (how much judgment is needed),
   - blast radius (what goes wrong if the answer is wrong),
   - how hard it is to check the answer,
   - context size (how much text, how many files),
   - privacy (what data must be sent).
2. **Pick the role before the model.**
   - Simple, clear, everything needed is here: stay on the current model. Switching has a cost.
   - Important or unclear plan: get a second opinion from a different provider before acting, if one is verified as
     available and allowed for this data (see Privacy); otherwise a redacted handoff.
   - Finished work to check: a different, verified provider reviews it against the requirements. Whoever made it never
     grades it.
   - Repeated failures: give a different, verified provider (or a redacted handoff) the problem, the evidence and every
     approach that failed; ask for a different, testable explanation.
   - Large, mechanical, well-defined work: a lighter, cheaper model, with clear checks.
3. **Pick the tier.** Heavy (ambiguous, wide impact, hard to check), moderate (bounded but needs judgment), light (clear inputs, mechanical). Match it to the verified model options after checking each provider's current page for price per million tokens (input and output), long-context pricing, context limit and any data-use terms.
4. **Estimate the cost** for this task in plain words (for example "about the same as now", "roughly three times more per run"), using the prices you just checked and a rough size of input and output. Say it is an estimate.
5. **Give the routing brief** (below). One alternative at most, and only for a real trade-off.
6. **After a run on another model**, check the real output. An empty answer, a timeout or a permission error is a failure, not a result. Do not retry on a bigger model on your own; report it.
7. **Treat another model's answer as evidence, not a verdict.** Weigh it against the facts. Two models agreeing is not proof; surface disagreements instead of picking a side by vote.

## Routing brief (under 200 words)

- **Recommendation:** stay on the current model, or switch to a named option from the verified list, in a named role (do the work, second opinion, review).
- **Why:** one or two reasons tied to this task, and any uncertainty.
- **Cost and limits:** checked on <date> from <provider page>; any spending limit only as read from the business's settings, or "limit not checked".
- **Privacy:** what data will be sent, to which provider, and the business terms checked (or: redacted handoff, nothing sent).
- **Next step:** the change the person makes in their own settings, or the exact task (or redacted handoff file) to hand over, the expected output and how it will be checked.

## What good looks like

- Every price, limit or model fact cites the provider's page and the date checked.
- The person hears that the switch may change cost, and a spending limit only when it was read from their settings.
- The model that made something is never the only one that reviews it.
- "Listed as an option", "available to this workspace under the business's terms" and "proven to work on this task" are treated as three separate facts.
- No paid call is spent just to decide which model to call.
