# Feedback reports

Disabled for the user's setup. Do not run `hyperframes feedback` in any form; telemetry is off
(HYPERFRAMES_NO_TELEMETRY=1, DO_NOT_TRACK=1, `hyperframes telemetry disable`). The original text is in feedback.md.orig.
