#!/usr/bin/env python3
"""Captions for video cuts: word JSON -> caption JSON -> SRT/ASS -> burned-in video.

Lifted from kajisho5/ffmpeg-skill caption.py (MIT; ASS styling, cue layout, safe margins), with a default
look: Fraunces for words, Space Mono for labels, a deep red #B4232F accent. Change these to the customer's brand.

Caption JSON shape (one entry per word):
  {"text": " word", "startMs": 1200, "endMs": 1480, "timestampMs": 1340, "confidence": 0.93}
  text carries its leading space; timestampMs is the word's midpoint. Entries made from an
  SRT are whole cues and also carry "cue": true (see "SRT input" below).

Subcommands
  to-json  --words transcript.json | --srt in.srt  -> --out captions.json
  write    --captions captions.json --srt out.srt --ass out.ass [--karaoke] [--map <video>_map.json]
  burn     --video in.mp4 --captions captions.json --out out.mp4 [--map <video>_map.json]

Word input (--words): transcribe.py's transcript.json, or any whisper-style JSON with
"segments" -> "words". Each word may be {"word","start","end"} (the standard shape, which
transcribe.py writes) or the short {"w","s","e"}. A top-level word list also works. Zero
words is an error, never an empty caption file.

Time base: caption JSON is in VO time (before cuts). Whenever the video was cut (pause
tightening, flub cuts), pass that video's own <video>_map.json to BOTH write and burn.
Each WORD is mapped to output time before words are grouped into cues: map pieces that
are continuous in VO time (a camera or framing change with nothing removed) are joined
first, so an intact word keeps its full length; words inside a removed range are
dropped, a word straddling a real cut is clipped to its surviving piece, and cues then
break naturally at the joins. Without --map, times are written unchanged (only correct
for an uncut video, or captions already timed to the finished video).

SRT input has whole-cue times, not word times, so it cannot say which words fell inside
a cut. to-json --srt marks every entry "cue": true, and write/burn REFUSE --map for such
captions (and for any entry holding more than one word) instead of showing removed
speech. A supplied .srt is usable only without --map: timed to the finished video, or
for an uncut video. For a cut video, caption from word times (transcribe.py) instead.

Burn-in renders each cue to a transparent PNG with Pillow and composites with ffmpeg's
overlay filter, so it works on ffmpeg builds without libass (Homebrew's 8.x has none).
Run with a Python that has Pillow: python3 caption.py ...
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
import math
import os


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: ffmpeg/ffprobe open a file only as a plain audio/video container or a single still image. A playlist
# (hls), concat list, dash manifest, image sequence or text file (tty) in Your files could otherwise make ffmpeg open
# other files, outside Your files.
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf,png_pipe,jpeg_pipe,webp_pipe,bmp_pipe,tiff_pipe,gif,apng")
FMT = ["-format_whitelist", MEDIA_FORMATS]


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f

HERE = Path(__file__).resolve().parent
FONTS = HERE.parent / "assets"  # Fraunces + Space Mono (OFL, google/fonts 6c1dbe2)
FRAUNCES = FONTS / "Fraunces[SOFT,WONK,opsz,wght].ttf"
SPACE_MONO = FONTS / "SpaceMono-Regular.ttf"
OXBLOOD = "#B4232F"
INK = "#F4EFE6"        # warm paper white for caption text
SHADOW = "#0B0B0B"
MAX_WORDS, MAX_CHARS, PAUSE_BREAK = 7, 34, 0.6


# ---------- shape conversion ----------

def _iter_words(data):
    if isinstance(data, list):
        if data and isinstance(data[0], dict) and "words" in data[0]:
            for seg in data:
                yield from seg.get("words", [])
        else:
            yield from data
        return
    if "words" in data and not data.get("segments"):
        yield from data["words"]
        return
    for seg in data.get("segments", []):
        yield from seg.get("words", []) or []


def words_to_captions(words_json: Path) -> list[dict]:
    data = json.loads(words_json.read_text())
    out = []
    for w in _iter_words(data):
        text = str(w.get("word", w.get("w", w.get("text", "")))).strip()
        if not text:
            continue
        s = w.get("start", w.get("s"))
        e = w.get("end", w.get("e"))
        if s is None or e is None:
            raise SystemExit(f"word {text!r} has no start/end time")
        s, e = float(s), float(e)
        prob = w.get("probability", w.get("p"))
        out.append({"text": " " + text, "startMs": round(s * 1000), "endMs": round(e * 1000),
                    "timestampMs": round((s + e) * 500),
                    "confidence": None if prob is None else round(float(prob), 3)})
    if not out:
        raise SystemExit(f"{words_json}: no timed words found (expected segments[].words[] with "
                         "word/start/end); refusing to write an empty caption file")
    out[0]["text"] = out[0]["text"].lstrip()
    return out


def join_continuous(tmap: list) -> list[dict]:
    """Join map pieces that are continuous in VO time AND output time.

    assemble.py writes one map piece per cutlist segment, so a camera or framing switch
    starts a new piece even where nothing was removed. Only a real cut (a jump in VO
    time) may clip a word, so adjacent continuous pieces are joined before mapping.
    """
    joined = []
    for p in sorted(tmap, key=lambda p: float(p["vo_in"])):
        vi, vo, oi = float(p["vo_in"]), float(p["vo_out"]), float(p["out_in"])
        oo = float(p.get("out_out", oi + (vo - vi)))
        if joined and abs(joined[-1]["vo_out"] - vi) < 0.002 and abs(joined[-1]["out_out"] - oi) < 0.002:
            joined[-1]["vo_out"], joined[-1]["out_out"] = vo, oo
        else:
            joined.append({"vo_in": vi, "vo_out": vo, "out_in": oi, "out_out": oo})
    return joined


def require_word_times(caps: list[dict]) -> None:
    """Refuse cue-level captions before mapping them across cuts."""
    bad = [c for c in caps if c.get("cue") or len(c["text"].split()) > 1]
    if bad:
        c = bad[0]
        raise SystemExit(
            f"{len(bad)} caption entr{'y has' if len(bad) == 1 else 'ies have'} whole-cue times, not word "
            f"times (first: {c['text'].strip()[:40]!r} at {c['startMs'] / 1000:.2f}s). Cue times cannot "
            "say which words a cut removed, so they are not mapped across cuts. Use word times "
            "(transcribe.py, then to-json --words), or captions timed to the finished video "
            "written and burned WITHOUT --map.")


def map_captions(caps: list[dict], tmap: list) -> list[dict]:
    """VO-time words -> output-time words through an assemble map, before cue grouping.

    Needs word-level captions (one word per entry). Pieces continuous in VO time are
    joined first, so a camera switch never shortens a word. A word wholly inside a
    removed range is dropped. A word that straddles a real cut keeps only its surviving
    part (clipped to the piece holding its start, else its end).
    """
    require_word_times(caps)
    pieces = join_continuous(tmap)
    out = []
    for c in caps:
        s, e = c["startMs"] / 1000, c["endMs"] / 1000
        hit = next((p for p in pieces if p["vo_in"] <= s < p["vo_out"]), None)
        if hit is None:
            hit = next((p for p in pieces if p["vo_in"] < e <= p["vo_out"]), None)
        if hit is None:
            continue
        s2, e2 = max(s, hit["vo_in"]), min(e, hit["vo_out"])
        if e2 - s2 <= 0.005:
            continue
        os_, oe = hit["out_in"] + (s2 - hit["vo_in"]), hit["out_in"] + (e2 - hit["vo_in"])
        d = dict(c)
        d["startMs"], d["endMs"] = round(os_ * 1000), round(oe * 1000)
        d["timestampMs"] = round((os_ + oe) * 500)
        out.append(d)
    out.sort(key=lambda c: c["startMs"])
    if out:
        out[0]["text"] = out[0]["text"].lstrip()
    return out


def load_map(path: Path | None) -> list | None:
    if not path:
        return None
    tmap = json.loads(path.read_text())
    if isinstance(tmap, dict):
        tmap = tmap.get("pieces") or tmap.get("map")
    if not tmap:
        raise SystemExit(f"{path}: empty or unreadable timeline map")
    # GUARDFIX3: map times end up in the burn filtergraph: finite numbers only
    for i, p in enumerate(tmap):
        for k in ("vo_in", "vo_out", "out_in", "out_out"):
            if k in p or k != "out_out":
                _finite(p[k], f"map piece {i} {k}")
    return tmap


def _srt_time(t: str) -> float:
    h, m, rest = t.replace(",", ".").split(":")
    return int(h) * 3600 + int(m) * 60 + float(rest)


def srt_to_captions(path: Path) -> list[dict]:
    """One caption per cue (SRT has no word times), marked "cue": true.

    Words inside a cue share its span, so these captions are only right on the timeline the
    SRT was timed to; map_captions refuses them.
    """
    out = []
    for block in re.split(r"\n\s*\n", path.read_text(encoding="utf-8-sig").strip()):
        lines = block.strip().splitlines()
        tl = next((i for i, l in enumerate(lines) if "-->" in l), None)
        if tl is None:
            continue
        a, b = (x.strip().split()[0] for x in lines[tl].split("-->"))
        s, e = _srt_time(a), _srt_time(b)
        text = " ".join(lines[tl + 1:]).strip()
        if text:
            out.append({"text": (" " if out else "") + text, "startMs": round(s * 1000), "endMs": round(e * 1000),
                        "timestampMs": round((s + e) * 500), "confidence": None, "cue": True})
    return out


def validate(caps: list[dict]) -> None:
    keys = {"text", "startMs", "endMs", "timestampMs", "confidence"}
    for i, c in enumerate(caps):
        if set(c) - {"cue"} != keys:
            raise SystemExit(f"caption {i} has keys {sorted(c)}; expected {sorted(keys)} (+ optional cue)")
        if not (isinstance(c["startMs"], int) and isinstance(c["endMs"], int) and c["endMs"] >= c["startMs"]):
            raise SystemExit(f"caption {i} has bad times")


# ---------- cue layout ----------

def cues_from_captions(caps: list[dict]) -> list[dict]:
    """Group words into readable cues: break on long pauses, sentence ends, word/char budgets."""
    cues, cur = [], []
    for c in caps:
        if cur:
            gap = (c["startMs"] - cur[-1]["endMs"]) / 1000
            text_len = len("".join(w["text"] for w in cur + [c]).strip())
            if gap > PAUSE_BREAK or len(cur) >= MAX_WORDS or text_len > MAX_CHARS \
                    or re.search(r"[.!?]$", cur[-1]["text"].strip()):
                cues.append(cur)
                cur = []
        cur.append(c)
    if cur:
        # no one-word widow: fold it into the previous cue when there is no real pause between them
        prev_len = len("".join(w["text"] for w in cues[-1] + cur).strip()) if cues else 0
        if cues and len(cur) == 1 and prev_len <= MAX_CHARS + 8 \
                and (cur[0]["startMs"] - cues[-1][-1]["endMs"]) / 1000 <= PAUSE_BREAK:
            cues[-1].extend(cur)
        else:
            cues.append(cur)
    return [{"start": w[0]["startMs"] / 1000, "end": w[-1]["endMs"] / 1000,
             "text": "".join(x["text"] for x in w).strip(), "words": w} for w in cues]


def fmt_srt(t: float) -> str:
    ms = round(t * 1000)
    return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}"


def fmt_ass(t: float) -> str:
    cs = round(t * 100)
    return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"


def ass_colour(hex_rgb: str, alpha: int = 0) -> str:
    r, g, b = hex_rgb[1:3], hex_rgb[3:5], hex_rgb[5:7]
    return f"&H{alpha:02X}{b}{g}{r}".upper()


def write_srt(cues, path: Path) -> None:
    path.write_text("".join(f"{i}\n{fmt_srt(c['start'])} --> {fmt_srt(c['end'])}\n{c['text']}\n\n"
                            for i, c in enumerate(cues, 1)), encoding="utf-8")


def write_ass(cues, path: Path, w: int = 1920, h: int = 1080, karaoke: bool = False) -> None:
    size = round(h * 0.052)
    margin_v = round(h * 0.09)  # inside the 80% title-safe box
    head = [
        "[Script Info]", "ScriptType: v4.00+", f"PlayResX: {w}", f"PlayResY: {h}", "WrapStyle: 0",
        "ScaledBorderAndShadow: yes", "", "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, "
        "Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        # Karaoke: Primary = sung (oxblood), Secondary = not yet sung (paper white)
        f"Style: Caption,Fraunces,{size},{ass_colour(OXBLOOD if karaoke else INK)},{ass_colour(INK)},{ass_colour(SHADOW)},"
        f"{ass_colour(SHADOW, 0x60)},0,0,0,0,100,100,0,0,1,{size * 0.06:.1f},{size * 0.04:.1f},2,{round(w * .1)},{round(w * .1)},{margin_v},1",
        f"Style: Label,Space Mono,{round(size * 0.55)},{ass_colour(OXBLOOD)},{ass_colour(INK)},{ass_colour(SHADOW)},"
        f"{ass_colour(SHADOW, 0x60)},0,0,0,0,100,100,1,0,1,{size * 0.03:.1f},0,7,{round(w * .1)},{round(w * .1)},{round(h * .1)},1",
        "", "[Events]", "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    ev = []
    for c in cues:
        if karaoke:
            body = "".join("{\\k%d}%s" % (max(1, round((x["endMs"] - x["startMs"]) / 10)), x["text"]) for x in c["words"])
        else:
            body = c["text"]
        ev.append(f"Dialogue: 0,{fmt_ass(c['start'])},{fmt_ass(c['end'])},Caption,,0,0,0,,{{\\fad(80,80)}}{body.strip()}")
    path.write_text("\n".join(head + ev) + "\n", encoding="utf-8")


# ---------- burn-in (no libass needed) ----------

def probe_wh(video: Path) -> tuple[int, int]:
    r = subprocess.run(["ffprobe", *FMT, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height",
                        "-of", "csv=p=0:s=x", str(video)], capture_output=True, text=True, check=True)
    w, h = r.stdout.strip().split("x")[:2]
    return int(w), int(h)


def render_png(text: str, w: int, h: int, out: Path) -> tuple[int, int]:
    from PIL import Image, ImageDraw, ImageFont
    size = round(h * 0.052)
    font = ImageFont.truetype(str(FRAUNCES), size)
    try:
        font.set_variation_by_axes([72, 600, 0, 0])  # opsz, wght, SOFT, WONK (axis order of the file)
    except Exception:
        pass
    max_w = int(w * 0.8)
    lines, line = [], ""
    for word in text.split():
        trial = (line + " " + word).strip()
        if font.getlength(trial) <= max_w or not line:
            line = trial
        else:
            lines.append(line); line = word
    lines.append(line)
    lh = round(size * 1.25)
    pad = round(size * 0.35)
    tw = int(max(font.getlength(l) for l in lines)) + 2 * pad
    th = lh * len(lines) + 2 * pad
    img = Image.new("RGBA", (tw, th + round(size * 0.12)), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for i, l in enumerate(lines):
        x = (tw - font.getlength(l)) / 2
        y = pad + i * lh
        d.text((x, y), l, font=font, fill=INK, stroke_width=max(2, round(size * 0.06)), stroke_fill=SHADOW)
    # accent rule under the cue (default deep red)
    rule_w = round(tw * 0.18)
    d.rectangle([(tw - rule_w) // 2, th, (tw + rule_w) // 2, th + max(3, round(size * 0.06))], fill=OXBLOOD)
    img.save(out)
    return img.size


def burn(video: Path, cues, out: Path) -> None:
    """Cues must already be in the video's own time (map words first)."""
    w, h = probe_wh(video)
    # temporary cue images live next to the output (inside Your files)
    out.parent.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix=".caption-burn-", dir=out.parent))
    inputs, graph, last = [*FMT, "-i", str(video)], [], "0:v"
    try:
        for i, c in enumerate(cues):
            s, e = c["start"], c["end"]
            if e <= s:
                continue
            png = work / f"cue{i:04d}.png"
            pw, ph = render_png(c["text"], w, h, png)
            inputs += [*FMT, "-i", str(png)]
            n = inputs.count("-i") - 1   # input index (each input is FMT + -i path)
            x, y = (w - pw) // 2, h - ph - round(h * 0.09)
            tag = f"v{i}"
            graph.append(f"[{last}][{n}:v]overlay={x}:{y}:enable='between(t,{s:.3f},{e:.3f})'[{tag}]")
            last = tag
        if not graph:
            raise SystemExit("no cues to burn")
        script = work / "graph.txt"
        script.write_text(";\n".join(graph))
        cmd = ["ffmpeg", "-v", "error", "-y", *inputs, "-filter_complex_script", str(script),
               "-map", f"[{last}]", "-map", "0:a?", "-c:v", "libx264", "-crf", "18", "-preset", "medium",
               "-pix_fmt", "yuv420p", "-c:a", "copy", str(out)]
        subprocess.run(cmd, check=True)
    finally:
        shutil.rmtree(work, ignore_errors=True)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("to-json"); g = a.add_mutually_exclusive_group(required=True)
    g.add_argument("--words", type=Path); g.add_argument("--srt", type=Path); a.add_argument("--out", type=Path, required=True)
    b = sub.add_parser("write"); b.add_argument("--captions", type=Path, required=True)
    b.add_argument("--srt", type=Path); b.add_argument("--ass", type=Path); b.add_argument("--karaoke", action="store_true")
    b.add_argument("--size", default="1920x1080")
    b.add_argument("--map", type=Path, help="<video>_map.json from assemble.py (captions are in VO time)")
    c = sub.add_parser("burn"); c.add_argument("--video", type=Path, required=True)
    c.add_argument("--captions", type=Path, required=True); c.add_argument("--out", type=Path, required=True)
    c.add_argument("--map", type=Path, help="timeline_map.json from assemble.py (captions are in VO time)")
    args = ap.parse_args()

    # GUARDFIX3: every file this run reads stays in Files (or this skill's folder), every file it writes in Files;
    # ffprobe/ffmpeg get the resolved absolute path (no leading '-', no protocol prefix).
    def _r(p):
        return Path(_inside(p)) if p else p

    def _w(p):
        return Path(_inside(p, write=True)) if p else p
    if args.cmd == "to-json":
        args.words, args.srt, args.out = _r(args.words), _r(args.srt), _w(args.out)
    elif args.cmd == "write":
        args.captions, args.map, args.srt, args.ass = _r(args.captions), _r(args.map), _w(args.srt), _w(args.ass)
    else:
        args.video, args.captions, args.map, args.out = _r(args.video), _r(args.captions), _r(args.map), _w(args.out)

    if args.cmd == "to-json":
        caps = words_to_captions(args.words) if args.words else srt_to_captions(args.srt)
        validate(caps)
        args.out.write_text(json.dumps(caps, indent=1))
        print(f"{args.out}\t{len(caps)} captions")
        return 0
    caps = json.loads(args.captions.read_text())
    validate(caps)
    tmap = load_map(args.map)
    if tmap:
        caps = map_captions(caps, tmap)
        if not caps:
            raise SystemExit("no caption words survive the cuts in the map; check the map belongs to this video")
    cues = cues_from_captions(caps)
    if args.cmd == "write":
        w, h = (int(x) for x in args.size.split("x"))
        if args.srt:
            write_srt(cues, args.srt)
        if args.ass:
            write_ass(cues, args.ass, w, h, args.karaoke)
        print(f"{len(cues)} cues from {len(caps)} captions")
        return 0
    burn(args.video, cues, args.out)
    print(f"{args.out}\t{len(cues)} cues burned")
    return 0


if __name__ == "__main__":
    sys.exit(main())
