#!/usr/bin/env python3
"""SUPERSEDED — do not use for cutaway cards. Use layout_cards.py.

    This script cannot do what cutaway cards need: no inset layout, no
    slide-in, no --exit-at for reference cards, no artwork auto-trim (it
    will happily frame a card's baked-in black margin). It also assumes
    TRANSPARENT assets; opaque cards get composited as a flat rectangle
    over the speaker.

    It is kept only for genuinely transparent, decorative elements
    (lower thirds, chapter markers) if those ever come back.

    The trap: this script takes --map and layout_cards.py does not, which
    makes it LOOK like the correct choice for VO-time anchoring. It isn't.
    Convert the times yourself, then call layout_cards.py --offset 0
    against the assembled video. See SKILL.md "Cutaway cards".

Composite transparent overlay elements onto the assembled video.

Renderer-agnostic: overlays can come from any tool that exports
transparency — PNG exports from a design app, ProRes 4444 MOVs (motion
graphics tools, After Effects), VP9-alpha WebM, GIF/APNG.

Spec (overlays.json):
{
  "overlays": [
    {"file": "overlays/term_card.png", "at": 92.5, "time_base": "vo",
     "duration": 6, "fade": 0.4, "position": "lower-third", "scale": 0.4},
    {"file": "overlays/quote.mov", "at": 41.0, "time_base": "output",
     "position": "center"}
  ]
}

Fields:
  file       required. png/gif/apng (needs duration) or mov/webm (intrinsic)
  at         required. start time in seconds
  time_base  "vo" (converted via timeline_map.json — survives pause
             tightening) or "output" (literal output-video time). Default vo.
  duration   required for still images (default 5.0 with warning);
             optional clamp for videos
  fade       alpha fade in/out seconds (default 0.4 for images, 0 for video)
  position   lower-third | center | top-left | top-right | bottom-center
             (default lower-third), or explicit "x"/"y" ffmpeg expressions
  scale      overlay width as fraction of video width (optional)
"""
import argparse
import json
import math
import os
import re
import subprocess
import sys

POSITIONS = {
    "lower-third": ("main_w*0.06", "main_h*0.72"),
    "center": ("(main_w-overlay_w)/2", "(main_h-overlay_h)/2"),
    "top-left": ("main_w*0.06", "main_h*0.08"),
    "top-right": ("main_w-overlay_w-main_w*0.06", "main_h*0.08"),
    "bottom-center": ("(main_w-overlay_w)/2", "main_h*0.80"),
}
IMAGE_EXT = {".png", ".gif", ".apng", ".jpg", ".jpeg", ".webp"}


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)


# GUARDFIX3: the spec is data from the person's Files. Nothing in it may reach the ffmpeg filtergraph except checked
# numbers and plain overlay expressions, and every overlay file it names must be inside the Files folder.
_EXPR_NAMES = {"main_w", "main_h", "overlay_w", "overlay_h", "W", "H", "w", "h", "t", "n",
               "abs", "floor", "ceil", "trunc", "sqrt", "sin", "cos"}


# GUARDFIX3: ffmpeg/ffprobe open a file only as a plain audio/video container or a single still image. A playlist
# (hls), concat list, dash manifest, image sequence or text file (tty) in Your files could otherwise make ffmpeg open
# other files, outside Your files.
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf,png_pipe,jpeg_pipe,webp_pipe,bmp_pipe,tiff_pipe,gif,apng")
FMT = ["-format_whitelist", MEDIA_FORMATS]


def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        die("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, what="overlay file"):
    """The real path of a file named by the spec or an argument (relative to the working folder), when it is inside
    the Files folder or, reading, this skill's folder after links and `..`; else exit."""
    if not isinstance(path, str) or not path or "\0" in path:
        die(f"{what} must be a path: {path!r}")
    real = os.path.realpath(os.path.join(os.getcwd(), os.path.expanduser(path)))
    skill = os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    if not any(real == r or real.startswith(r + os.sep) for r in ((_files_root(),) if write else (_files_root(), skill))):
        die(f"refusing: {what} {path} is outside your Files folder")
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        die(f"refusing: {what} {path} is a hard link")
    return real


def _num(v, what, lo=None, hi=None):
    """A finite number from the spec (a JSON number or numeric text), within [lo, hi]."""
    if isinstance(v, bool) or not isinstance(v, (int, float, str)):
        die(f"{what} must be a number, got {v!r}")
    try:
        f = float(v)
    except ValueError:
        die(f"{what} must be a number, got {v!r}")
    if not math.isfinite(f) or (lo is not None and f < lo) or (hi is not None and f > hi):
        die(f"{what} out of range: {v!r}")
    return f


def _pos_expr(v, what):
    """An overlay x/y: a number, or a plain arithmetic expression of main_w/main_h/overlay_w/overlay_h/t/n (no ':' ';'
    '[' ']' ',' '=' quotes or backslash, so it cannot end the overlay option or add a filter)."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return repr(float(_num(v, what)))
    if not isinstance(v, str) or not re.fullmatch(r"[A-Za-z0-9_+\-*/(). ]{1,80}", v):
        die(f"{what} must be a number or an overlay expression like main_w-overlay_w-10, got {v!r}")
    for name in re.findall(r"[A-Za-z_][A-Za-z0-9_]*", v):
        if name not in _EXPR_NAMES:
            die(f"{what}: '{name}' is not allowed in a position expression")
    return v


def probe(path, what):
    r = subprocess.run(["ffprobe", *FMT, "-v", "error", "-show_entries", what,
                        "-of", "json", path], capture_output=True, text=True)
    if r.returncode != 0:
        die(f"ffprobe failed on {path}: {r.stderr.strip()[:300]}")
    return json.loads(r.stdout)


def vo_to_output(t, tmap):
    """Map VO time to output time using timeline_map.json pieces."""
    for p in tmap:
        if p["vo_in"] <= t < p["vo_out"]:
            return p["out_in"] + (t - p["vo_in"]), None
    # t fell in a removed range (tightened pause or trimmed tail): snap forward
    nxt = [p for p in tmap if p["vo_in"] >= t]
    if nxt:
        p = min(nxt, key=lambda p: p["vo_in"])
        return p["out_in"], f"vo time {t:.2f}s was cut; snapped to {p['out_in']:.2f}s (output)"
    return None, f"vo time {t:.2f}s is beyond the edit — overlay skipped"


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--video", required=True, help="assembled video (final or preview)")
    p.add_argument("--overlays", required=True, help="overlays.json spec")
    p.add_argument("--map", default=None,
                   help="timeline_map.json (required for time_base 'vo')")
    p.add_argument("--out", required=True)
    p.add_argument("--preview", action="store_true")
    p.add_argument("--crf", type=int, default=None)
    args = p.parse_args()
    # GUARDFIX3: the spec, map and video are read from Files (or this skill's folder), the output written in Files;
    # ffmpeg/ffprobe get the real absolute paths (never read as an option).
    args.overlays = _inside(args.overlays, what="--overlays")
    args.map = _inside(args.map, what="--map") if args.map else None
    args.video, args.out = _inside(args.video, what="--video"), _inside(args.out, write=True, what="--out")

    with open(args.overlays) as f:
        spec = json.load(f)["overlays"]
    if not spec or not isinstance(spec, list) or not all(isinstance(o, dict) for o in spec):
        die("no overlays in spec")
    tmap = None
    if args.map:
        with open(args.map) as f:
            tmap = json.load(f)

    base = probe(args.video, "stream=width,height,codec_type:format=duration")
    vstream = next(s for s in base["streams"] if s.get("codec_type") == "video"
                   or "width" in s)
    W = int(vstream["width"])
    base_dur = float(base["format"]["duration"])

    cmd_inputs = [*FMT, "-i", args.video]
    filter_lines = []
    placed, warnings = [], []
    n_in = 1

    for ov in spec:
        path = _inside(ov.get("file"))
        if not os.path.exists(path):
            die(f"overlay file not found: {path}")
        ext = os.path.splitext(path)[1].lower()
        is_image = ext in IMAGE_EXT and ext not in (".gif", ".apng")
        is_animated_img = ext in (".gif", ".apng")

        # resolve start time
        at = _num(ov.get("at"), f"overlay {path}: at", 0)
        if ov.get("time_base", "vo") == "vo":
            if not tmap:
                die(f"overlay {path}: time_base 'vo' needs --map timeline_map.json")
            at, warn = vo_to_output(at, tmap)
            if at is None:
                warnings.append(warn)
                continue
            if warn:
                warnings.append(warn)
            at = _num(at, f"overlay {path}: mapped time", 0)

        # resolve duration
        if is_image or is_animated_img:
            dur = _num(ov.get("duration") or 5.0, f"overlay {path}: duration", 0, 86400)
            if "duration" not in ov:
                warnings.append(f"{path}: no duration given, using 5.0s")
        else:
            d = probe(path, "format=duration")
            dur = _num(d["format"]["duration"], f"overlay {path}: duration", 0)
            if ov.get("duration"):
                dur = min(dur, _num(ov["duration"], f"overlay {path}: duration", 0, 86400))
        if at >= base_dur:
            warnings.append(f"{path}: starts past end of video — skipped")
            continue
        dur = min(dur, base_dur - at)

        # input flags per format
        if is_image:
            cmd_inputs += ["-loop", "1", "-t", f"{dur + 0.1:.3f}", *FMT, "-i", path]
        elif is_animated_img:
            cmd_inputs += ["-t", f"{dur + 0.1:.3f}", *FMT, "-i", path]
        elif ext == ".webm":
            # native vp9 decoder drops alpha; libvpx-vp9 keeps it
            cmd_inputs += ["-c:v", "libvpx-vp9", *FMT, "-i", path]
        else:
            cmd_inputs += [*FMT, "-i", path]

        # per-overlay filter chain
        fade = _num(ov.get("fade", 0.4 if (is_image or is_animated_img) else 0.0), f"overlay {path}: fade", 0, 3600)
        chain = ["format=rgba"]
        if ov.get("scale"):
            chain.append(f"scale={max(2, int(W * _num(ov['scale'], f'overlay {path}: scale', 0, 10)))}:-2")
        if fade > 0:
            chain.append(f"fade=t=in:st=0:d={fade:.3f}:alpha=1")
            chain.append(f"fade=t=out:st={max(0.0, dur - fade):.3f}:d={fade:.3f}:alpha=1")
        chain.append(f"setpts=PTS-STARTPTS+{at:.4f}/TB")
        filter_lines.append(f"[{n_in}:v]{','.join(chain)}[ov{n_in}];")

        pos = ov.get("position", "lower-third")
        if "x" in ov and "y" in ov:
            x, y = _pos_expr(ov["x"], f"overlay {path}: x"), _pos_expr(ov["y"], f"overlay {path}: y")
        elif pos in POSITIONS:
            x, y = POSITIONS[pos]
        else:
            die(f"unknown position {pos!r} (use {', '.join(POSITIONS)} or x/y)")

        src = "[0:v]" if n_in == 1 else f"[b{n_in - 1}]"
        filter_lines.append(
            f"{src}[ov{n_in}]overlay=x={x}:y={y}:eof_action=pass:"
            f"enable='between(t,{at:.4f},{at + dur:.4f})'[b{n_in}];")
        placed.append({"file": path, "out_time": round(at, 2),
                       "duration": round(dur, 2), "position": pos})
        n_in += 1

    if not placed:
        die("nothing to composite: " + "; ".join(warnings))

    last = f"[b{n_in - 1}]"
    filter_lines[-1] = filter_lines[-1].replace(f"[b{n_in - 1}];", f"[b{n_in - 1}]")
    graph = "\n".join(filter_lines)

    crf = args.crf if args.crf is not None else (28 if args.preview else 18)
    preset = "ultrafast" if args.preview else "slow"
    cmd = (["ffmpeg", "-v", "error", "-y", "-stats"] + cmd_inputs +
           ["-filter_complex", graph,
            "-map", last, "-map", "0:a?",
            "-c:v", "libx264", "-preset", preset, "-crf", str(crf),
            "-pix_fmt", "yuv420p", "-c:a", "copy",
            "-movflags", "+faststart", args.out])
    r = subprocess.run(cmd)
    if r.returncode != 0:
        die("ffmpeg composite failed")

    print(json.dumps({"out": args.out, "placed": placed,
                      "warnings": warnings}, indent=2))


if __name__ == "__main__":
    main()
