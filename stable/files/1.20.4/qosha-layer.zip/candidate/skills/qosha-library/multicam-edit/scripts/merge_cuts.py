#!/usr/bin/env python3
"""Merge flub cuts into the keep-ranges (with silence cuts, if any).

Input flubs.json (written by the assistant from the transcript, approved by the
person before this runs):
{
  "cuts": [
    {"start": 134.2, "end": 141.8,
     "reason": "false start, retaken",
     "cut_text": "The concept of an—",
     "kept_text": "The concept of anomie describes..."}
  ]
}

Boundaries come from word timestamps, so each one is snapped to the
lowest-energy point of the VO within ±--snap-window — cuts land inside
pauses, never mid-word.

Output has the same shape as detect_silence.py's keep.json (assemble.py
--keep consumes it unchanged), plus a "seams" list: one entry per output join
created by a flub cut, {"before": <last kept VO time before the join>,
"after": <first kept VO time after it>}. In the rendered video, VO time
"before" is immediately followed by VO time "after"; everything between
them is deleted. Those joins are jump-cut points — hide them by changing
angle or framing exactly across the join: the segment before must end at or
after "before" and the new segment must run from there to after "after"
(see SKILL.md "Hide flub seams").

Temporary audio goes in a hidden folder next to --out.
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
import wave

import numpy as np
import math


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: ffmpeg/ffprobe open a file only as a plain audio/video container or a single still image. A playlist
# (hls), concat list, dash manifest, image sequence or text file (tty) in Your files could otherwise make ffmpeg open
# other files, outside Your files.
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf,png_pipe,jpeg_pipe,webp_pipe,bmp_pipe,tiff_pipe,gif,apng")
FMT = ["-format_whitelist", MEDIA_FORMATS]


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f

SR = 16000
ENV_HZ = 100
ENV_DECIM = SR // ENV_HZ


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)


def load_envelope(src, work_dir):
    with tempfile.TemporaryDirectory(dir=work_dir, prefix=".merge-") as td:
        wav = os.path.join(td, "vo.wav")
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", *FMT, "-i", src, "-vn",
                            "-ac", "1", "-ar", str(SR), "-c:a", "pcm_s16le", wav],
                           capture_output=True, text=True)
        if r.returncode != 0:
            die(f"ffmpeg failed: {r.stderr.strip()[:300]}")
        with wave.open(wav, "rb") as w:
            x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    x = np.abs(x.astype(np.float64) / 32768.0)
    kernel = np.ones(ENV_DECIM) / ENV_DECIM
    env = np.convolve(x, kernel, mode="same")[::ENV_DECIM]
    return env, len(x) / SR


def snap(t, env, window):
    """Move t to the lowest-envelope point within ±window seconds."""
    i0 = max(0, int((t - window) * ENV_HZ))
    i1 = min(len(env) - 1, int((t + window) * ENV_HZ))
    if i1 <= i0:
        return t
    return (i0 + int(np.argmin(env[i0:i1 + 1]))) / ENV_HZ


def merge_ranges(ranges):
    out = []
    for s, e in sorted(ranges):
        if out and s <= out[-1][1] + 0.01:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return out


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--vo", required=True, help="mastered VO (for boundary snapping)")
    p.add_argument("--flubs", required=True, help="flubs.json")
    p.add_argument("--keep", default=None,
                   help="existing keep.json from detect_silence.py (optional)")
    p.add_argument("--snap-window", type=float, default=0.25)
    p.add_argument("--out", required=True, help="merged keep.json for assemble.py")
    args = p.parse_args()
    # GUARDFIX3: paths stay in Files (ffmpeg gets the real path); numbers are finite.
    args.vo, args.flubs, args.keep = _inside(args.vo), _inside(args.flubs), _inside(args.keep)
    args.out = _inside(args.out, write=True)
    args.snap_window = _finite(args.snap_window, "--snap-window")

    with open(args.flubs) as f:
        flubs = json.load(f)["cuts"]
    if not flubs:
        die("flubs.json has no cuts")

    env, dur = load_envelope(args.vo, os.path.dirname(os.path.abspath(args.out)))

    silence_cuts = []
    if args.keep:
        with open(args.keep) as f:
            prev = json.load(f)
        dur = _finite(prev.get("vo_duration", dur), "keep vo_duration")
        cursor = 0.0
        for ks, ke in prev["keep"]:
            ks, ke = _finite(ks, "keep start"), _finite(ke, "keep end")
            if ks > cursor:
                silence_cuts.append([cursor, ks])
            cursor = ke
        if cursor < dur:
            silence_cuts.append([cursor, dur])

    flub_cuts = []
    for c in flubs:
        s, e = _finite(c["start"], "flub start"), _finite(c["end"], "flub end")
        if not (0 <= s < e <= dur + 0.5):
            die(f"flub cut {s}-{e} outside VO range 0-{dur:.1f}")
        s2, e2 = snap(s, env, args.snap_window), snap(e, env, args.snap_window)
        if e2 - s2 < 0.05:
            s2, e2 = s, e
        flub_cuts.append([round(min(s2, e2), 3), round(max(s2, e2), 3)])

    all_cuts = merge_ranges(silence_cuts + flub_cuts)

    # seams: output joins created by a merged cut that involves a flub (a
    # jump-cut risk). Record both surviving sides: the join sits between VO
    # time s (end of the kept piece before) and VO time e (start of the kept
    # piece after). A cut touching the start or end of the VO has no join.
    seams = []
    for s, e in all_cuts:
        if s <= 0.0 or e >= dur:
            continue
        if any(fs < e and fe > s for fs, fe in flub_cuts):
            seams.append({"before": round(s, 3), "after": round(e, 3)})

    keep = []
    cursor = 0.0
    for s, e in all_cuts:
        if s > cursor:
            keep.append([round(cursor, 3), round(s, 3)])
        cursor = max(cursor, e)
    if cursor < dur:
        keep.append([round(cursor, 3), round(dur, 3)])

    removed = sum(e - s for s, e in all_cuts)
    flub_removed = sum(e - s for s, e in flub_cuts)
    with open(args.out, "w") as f:
        json.dump({"vo_duration": round(dur, 3), "keep": keep, "seams": seams,
                   "removed_seconds": round(removed, 2),
                   "flub_cuts": [{"start": fc[0], "end": fc[1],
                                  "reason": orig.get("reason", ""),
                                  "cut_text": orig.get("cut_text", "")}
                                 for fc, orig in zip(flub_cuts, flubs)]}, f, indent=1)

    print(json.dumps({
        "flub_cuts": len(flub_cuts),
        "flub_seconds_removed": round(flub_removed, 2),
        "total_seconds_removed": round(removed, 2),
        "duration_after": round(dur - removed, 2),
        "seams_to_hide": seams,
        "out": args.out,
    }, indent=2))


if __name__ == "__main__":
    main()
