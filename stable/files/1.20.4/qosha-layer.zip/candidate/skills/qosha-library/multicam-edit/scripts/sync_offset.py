#!/usr/bin/env python3
"""Find where a clean VO sits inside a camera file's timeline.

Method: extract mono 16 kHz audio from both, compute 100 Hz amplitude
envelopes, z-score them, FFT cross-correlate for a coarse offset (10 ms),
then refine with full-band cross-correlation of a high-energy window
(sample-accurate). Robust to EQ/compression differences between the
processed VO and the camera's scratch audio because envelopes track
speech rhythm, not timbre.

Convention: camera_time = vo_time + offset_seconds.

With --vo-window START DUR the correlation runs on VO[START:START+DUR], so the
raw lag is camera_time - (vo_time - START); the full-VO offset is that lag
minus START. Temporary audio goes in --work-dir (default: current folder),
which should be the episode's work folder in Your files.
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
import wave

import numpy as np
import math


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: ffmpeg/ffprobe open a file only as a plain audio/video container or a single still image. A playlist
# (hls), concat list, dash manifest, image sequence or text file (tty) in Your files could otherwise make ffmpeg open
# other files, outside Your files.
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf,png_pipe,jpeg_pipe,webp_pipe,bmp_pipe,tiff_pipe,gif,apng")
FMT = ["-format_whitelist", MEDIA_FORMATS]


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f

SR = 16000          # working sample rate
ENV_HZ = 100        # envelope rate
ENV_DECIM = SR // ENV_HZ


def die(msg):
    print(json.dumps({"error": msg}), file=sys.stderr)
    sys.exit(1)


def extract_wav(src, dst):
    cmd = ["ffmpeg", "-v", "error", "-y", *FMT, "-i", src,
           "-vn", "-ac", "1", "-ar", str(SR), "-c:a", "pcm_s16le", dst]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        die(f"ffmpeg failed extracting audio from {src}: {r.stderr.strip()[:400]}")


def load_wav(path):
    with wave.open(path, "rb") as w:
        if w.getsampwidth() != 2:
            die(f"unexpected sample width in {path}")
        data = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    return data.astype(np.float64) / 32768.0


def envelope(x):
    """Rectify + box-filter + decimate to ENV_HZ."""
    ax = np.abs(x)
    kernel = np.ones(ENV_DECIM) / ENV_DECIM
    sm = np.convolve(ax, kernel, mode="same")
    env = sm[::ENV_DECIM]
    # z-score so correlation is scale-invariant
    std = env.std()
    if std < 1e-9:
        die("audio appears to be silence")
    return (env - env.mean()) / std


def xcorr_fft(a, b):
    """Full cross-correlation of a against b (lags: -len(b)+1 .. len(a)-1)."""
    n = len(a) + len(b) - 1
    nfft = 1 << (n - 1).bit_length()
    A = np.fft.rfft(a, nfft)
    B = np.fft.rfft(b, nfft)
    cc = np.fft.irfft(A * np.conj(B), nfft)[:n]
    # rearrange so index i corresponds to lag = i - (len(b) - 1)
    return np.concatenate((cc[-(len(b) - 1):], cc[:len(a)])) if len(b) > 1 else cc[:len(a)]


def confidence(cc, peak_idx, exclude=100):
    """Peak height vs. robust background level, excluding the peak neighborhood."""
    mask = np.ones(len(cc), dtype=bool)
    lo, hi = max(0, peak_idx - exclude), min(len(cc), peak_idx + exclude)
    mask[lo:hi] = False
    bg = cc[mask]
    if len(bg) < 10:
        return float("inf")
    mad = np.median(np.abs(bg - np.median(bg))) + 1e-12
    return float((cc[peak_idx] - np.median(bg)) / (1.4826 * mad))


def pick_energy_window(x, sr, dur):
    """Start (s) of the highest-energy window of length dur in x."""
    win = int(dur * sr)
    if len(x) <= win:
        return 0.0
    e = np.cumsum(x * x)
    seg = e[win:] - e[:-win]
    return float(np.argmax(seg)) / sr


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--camera", required=True, help="camera video file")
    p.add_argument("--vo", required=True, help="clean VO audio file")
    p.add_argument("--vo-window", nargs=2, type=float, metavar=("START", "DUR"),
                   help="only use this stretch of the VO (for time-edited VOs)")
    p.add_argument("--refine-dur", type=float, default=45.0,
                   help="length (s) of the window used for sample-accurate refine")
    p.add_argument("--json", action="store_true", help="print JSON only")
    p.add_argument("--work-dir", default=".",
                   help="folder for temporary audio (inside Your files)")
    args = p.parse_args()
    # GUARDFIX3: paths stay in Files (ffmpeg gets the real path); numbers are finite.
    args.camera, args.vo = _inside(args.camera), _inside(args.vo)
    args.work_dir = _inside(args.work_dir, write=True)
    args.refine_dur = _finite(args.refine_dur, "--refine-dur")
    if args.vo_window:
        args.vo_window = [_finite(v, "--vo-window") for v in args.vo_window]
    os.makedirs(args.work_dir, exist_ok=True)

    with tempfile.TemporaryDirectory(dir=args.work_dir, prefix=".sync-") as td:
        cam_wav = os.path.join(td, "cam.wav")
        vo_wav = os.path.join(td, "vo.wav")
        extract_wav(args.camera, cam_wav)
        extract_wav(args.vo, vo_wav)
        cam = load_wav(cam_wav)
        vo = load_wav(vo_wav)

    vo_trim_start = 0.0
    if args.vo_window:
        s, d = args.vo_window
        vo = vo[int(s * SR):int((s + d) * SR)]
        vo_trim_start = s
        if len(vo) < SR:
            die("--vo-window selects less than 1 s of audio")

    # --- coarse: envelope cross-correlation at 10 ms resolution ---
    cam_env = envelope(cam)
    vo_env = envelope(vo)
    cc = xcorr_fft(cam_env, vo_env)
    peak = int(np.argmax(cc))
    lag_env = peak - (len(vo_env) - 1)
    coarse = lag_env / ENV_HZ
    conf = confidence(cc, peak)

    # --- refine: full-band xcorr of a high-energy VO window, ±0.5 s ---
    w_start = pick_energy_window(vo, SR, min(args.refine_dur, len(vo) / SR))
    w = vo[int(w_start * SR):int((w_start + args.refine_dur) * SR)]
    cam_center = coarse + w_start
    pad = 0.5
    c0 = int(max(0, (cam_center - pad)) * SR)
    c1 = int(min(len(cam), (cam_center + args.refine_dur + pad) * SR))
    refined = coarse
    if c1 - c0 > SR and len(w) > SR:
        seg = cam[c0:c1]
        cc2 = xcorr_fft(seg, w)
        lag2 = int(np.argmax(np.abs(cc2))) - (len(w) - 1)
        refined = (c0 / SR + lag2 / SR) - w_start
        if abs(refined - coarse) > 0.2:   # refine wandered; distrust it
            refined = coarse

    # lag measured on the window: camera_time = (vo_time - vo_trim_start) + refined
    offset = refined - vo_trim_start  # camera_time = vo_time + offset

    out = {
        "camera": args.camera,
        "vo": args.vo,
        "offset_seconds": round(offset, 4),
        "coarse_offset_seconds": round(coarse - vo_trim_start, 3),
        "confidence": round(conf, 2),
        "camera_duration": round(len(cam) / SR, 3),
        "vo_duration_used": round(len(vo) / SR, 3),
        "note": "camera_time = vo_time + offset_seconds",
    }
    print(json.dumps(out, indent=None if args.json else 2))


if __name__ == "__main__":
    main()
