#!/usr/bin/env python3
"""Master a raw VO recording for online video.

Chain: highpass -> denoise (afftdn) -> de-ess -> gentle compression ->
two-pass loudnorm to target LUFS / true peak. Every stage can be bypassed;
if the person mixes in a DAW and only wants loudness conform, use
--no-denoise --no-compress --no-deess.

Two-pass loudnorm (measure, then apply with linear=true) hits the target
exactly without the dynamic pumping single-pass mode can introduce.
Output: 48 kHz 24-bit WAV.
"""
import argparse
import json
import re
import subprocess
import sys
import math
import os


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: ffmpeg/ffprobe open a file only as a plain audio/video container or a single still image. A playlist
# (hls), concat list, dash manifest, image sequence or text file (tty) in Your files could otherwise make ffmpeg open
# other files, outside Your files.
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf,png_pipe,jpeg_pipe,webp_pipe,bmp_pipe,tiff_pipe,gif,apng")
FMT = ["-format_whitelist", MEDIA_FORMATS]


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode, r.stdout, r.stderr


def build_chain(args):
    stages = [f"highpass=f={args.highpass}"]
    if not args.no_denoise:
        stages.append(f"afftdn=nr={args.denoise_db}:nf=-30")
    if not args.no_deess:
        stages.append("deesser=i=0.32")
    if not args.no_compress:
        stages.append("acompressor=threshold=-20dB:ratio=2.5:attack=8:release=180:knee=4")
    return stages


def loudnorm_params(args, measured=None):
    base = f"loudnorm=I={args.lufs}:TP={args.tp}:LRA={args.lra}"
    if measured:
        base += (f":measured_I={measured['input_i']}:measured_TP={measured['input_tp']}"
                 f":measured_LRA={measured['input_lra']}"
                 f":measured_thresh={measured['input_thresh']}"
                 f":offset={measured['target_offset']}:linear=true")
    return base


def parse_loudnorm_json(stderr, strict=True):
    # GUARDFIX3: ffmpeg -v info prints the input's metadata tags (comment, title ...) BEFORE loudnorm's own JSON, so
    # a tag can carry a fake {"input_i": ...} block. Take the LAST block (loudnorm prints it at the end) and, for the
    # values that go back into the pass-2 filtergraph, accept finite numbers only, re-formatted by us.
    m = re.findall(r"\{[^{}]*\"input_i\"[^{}]*\}", stderr, re.S)
    if not m:
        die("could not parse loudnorm measurement from ffmpeg output")
    try:
        d = json.loads(m[-1])
    except ValueError:
        die("could not parse loudnorm measurement from ffmpeg output")
    if not strict:
        return d
    return {k: _finite(d.get(k), "loudnorm " + k)
            for k in ("input_i", "input_tp", "input_lra", "input_thresh", "target_offset")}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--in", dest="src", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--lufs", type=float, default=-14.0)
    p.add_argument("--tp", type=float, default=-1.5)
    p.add_argument("--lra", type=float, default=11.0)
    p.add_argument("--highpass", type=int, default=70)
    p.add_argument("--denoise-db", type=int, default=12)
    p.add_argument("--no-denoise", action="store_true")
    p.add_argument("--no-deess", action="store_true")
    p.add_argument("--no-compress", action="store_true")
    args = p.parse_args()
    # GUARDFIX3: --in / --out stay in Files (ffmpeg gets the real path); the numbers reach the -af graph: finite.
    args.src, args.out = _inside(args.src), _inside(args.out, write=True)
    for k in ("lufs", "tp", "lra"):
        setattr(args, k, _finite(getattr(args, k), "--" + k))

    chain = build_chain(args)

    # pass 1: measure
    af1 = ",".join(chain + [loudnorm_params(args) + ":print_format=json"])
    code, _, err = run(["ffmpeg", "-v", "info", "-y", *FMT, "-i", args.src,
                        "-af", af1, "-f", "null", "-"])
    if code != 0:
        die(f"measurement pass failed: {err.strip()[-400:]}")
    measured = parse_loudnorm_json(err)

    # pass 2: apply
    af2 = ",".join(chain + [loudnorm_params(args, measured)])
    code, _, err = run(["ffmpeg", "-v", "error", "-y", *FMT, "-i", args.src,
                        "-af", af2, "-ar", "48000", "-c:a", "pcm_s24le", args.out])
    if code != 0:
        die(f"render pass failed: {err.strip()[-400:]}")

    # verify
    code, _, err = run(["ffmpeg", "-v", "info", "-y", *FMT, "-i", args.out,
                        "-af", "loudnorm=print_format=json", "-f", "null", "-"])
    final = parse_loudnorm_json(err, strict=False) if code == 0 else {}

    print(json.dumps({
        "out": args.out,
        "input_lufs": measured.get("input_i"),
        "input_true_peak": measured.get("input_tp"),
        "output_lufs": final.get("input_i", "n/a"),
        "output_true_peak": final.get("input_tp", "n/a"),
        "target": args.lufs,
        "stages": [s.split("=")[0] for s in build_chain(args)] + ["loudnorm"],
    }, indent=2))


if __name__ == "__main__":
    main()
