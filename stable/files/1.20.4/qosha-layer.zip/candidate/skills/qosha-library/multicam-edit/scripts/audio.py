#!/usr/bin/env python3
"""Music bed under the VO with sidechain ducking (lifted from kajisho5/ffmpeg-skill audio.py).

The VO drives a sidechain compressor on the music: while the speaker talks the bed dips, in the gaps
it comes back. The VO itself is never processed here (master it first with master_audio.py).

  python3 audio.py --video work/final.mp4 --music bed.wav --out work/final_mixed.mp4
      # the voice is the video's OWN audio track (the edited timeline, after pause and flub
      # cuts); the mix replaces that track and the video stream is copied
  python3 audio.py --voice work/vo_master.wav --music bed.wav --out work/mix.wav
      # audio-only mix of a VO file; only valid on a video if NO cuts were made

With --video, --voice is optional; if given it must match the video's length (within 0.1 s),
because an uncut VO under a cut video brings removed speech back and drifts out of sync.

Defaults: bed at -18 dB, duck threshold -30 dBFS, ratio 8, attack 20 ms, release 400 ms,
music fades out over the last 2 s. Check the result with loudness.py before export.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import math
import os


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: ffmpeg/ffprobe open a file only as a plain audio/video container or a single still image. A playlist
# (hls), concat list, dash manifest, image sequence or text file (tty) in Your files could otherwise make ffmpeg open
# other files, outside Your files.
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf,png_pipe,jpeg_pipe,webp_pipe,bmp_pipe,tiff_pipe,gif,apng")
FMT = ["-format_whitelist", MEDIA_FORMATS]


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f


def db_to_linear(db: float) -> float:
    return 10 ** (db / 20)


def duration(path: str) -> float:
    r = subprocess.run(["ffprobe", *FMT, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path],
                       capture_output=True, text=True, check=True)
    return float(r.stdout.strip())


def build_graph(dur: float, a: argparse.Namespace) -> str:
    music = [f"volume={a.music_db:g}dB", f"atrim=0:{dur:.3f}", "asetpts=PTS-STARTPTS"]
    if a.fade_out > 0:
        music.append(f"afade=t=out:st={max(0.0, dur - a.fade_out):.3f}:d={a.fade_out:g}")
    return ";".join([
        "[0:a]aformat=sample_rates=48000:channel_layouts=stereo,asplit=2[vo][sc]",
        f"[1:a]aformat=sample_rates=48000:channel_layouts=stereo,{','.join(music)}[bed]",
        # threshold is linear in sidechaincompress; ratio 1..20; attack/release in ms
        f"[bed][sc]sidechaincompress=threshold={db_to_linear(a.duck_threshold):.6g}:ratio={a.ratio:g}"
        f":attack={a.attack:g}:release={a.release:g}:makeup=1[ducked]",
        "[vo][ducked]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[mix]",
    ])


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--voice", help="VO file (default with --video: the video's own audio)")
    ap.add_argument("--music", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--video", help="mux the mix onto this video (video stream copied)")
    ap.add_argument("--music-db", type=float, default=-18.0)
    ap.add_argument("--duck-threshold", type=float, default=-30.0, help="dBFS on the VO that starts ducking")
    ap.add_argument("--ratio", type=float, default=8.0)
    ap.add_argument("--attack", type=float, default=20.0)
    ap.add_argument("--release", type=float, default=400.0)
    ap.add_argument("--fade-out", type=float, default=2.0)
    ap.add_argument("--loop-music", action="store_true")
    a = ap.parse_args()
    # GUARDFIX3: paths stay in Files (ffmpeg/ffprobe get the real path); the numbers reach the filtergraph: finite.
    a.voice, a.music, a.video = _inside(a.voice), _inside(a.music), _inside(a.video)
    a.out = _inside(a.out, write=True)
    for k in ("music_db", "duck_threshold", "ratio", "attack", "release", "fade_out"):
        setattr(a, k, _finite(getattr(a, k), "--" + k.replace("_", "-")))
    if not (1 <= a.ratio <= 20 and 0.01 <= a.attack <= 2000 and 0.01 <= a.release <= 9000):
        raise SystemExit("ratio 1..20, attack 0.01..2000 ms, release 0.01..9000 ms (sidechaincompress limits)")
    if not a.voice and not a.video:
        raise SystemExit("give --video (voice taken from its own audio) or --voice")
    if a.video:
        has_audio = subprocess.run(["ffprobe", *FMT, "-v", "error", "-select_streams", "a", "-show_entries",
                                    "stream=index", "-of", "csv=p=0", a.video],
                                   capture_output=True, text=True).stdout.strip()
        if not a.voice and not has_audio:
            raise SystemExit(f"{a.video} has no audio track to duck against; re-render it with its audio")
        if a.voice and abs(duration(a.voice) - duration(a.video)) > 0.1:
            raise SystemExit(f"--voice is {duration(a.voice):.2f}s but the video is {duration(a.video):.2f}s: "
                             "that VO is not the edited timeline. Omit --voice to use the video's own audio.")
    voice_src = a.voice or a.video
    dur = duration(voice_src)
    music_in = (["-stream_loop", "-1"] if a.loop_music else []) + [*FMT, "-i", a.music]
    cmd = ["ffmpeg", "-v", "error", "-y", *FMT, "-i", voice_src, *music_in]
    if a.video:
        cmd += [*FMT, "-i", a.video, "-filter_complex", build_graph(dur, a), "-map", "2:v:0", "-map", "[mix]",
                "-c:v", "copy", "-c:a", "aac", "-b:a", "320k", "-shortest", a.out]
    else:
        cmd += ["-filter_complex", build_graph(dur, a), "-map", "[mix]", "-c:a", "pcm_s24le", a.out]
    subprocess.run(cmd, check=True)
    print(f"{a.out}\tmixed {dur:.2f}s\tbed {a.music_db:g} dB, duck at {a.duck_threshold:g} dBFS ratio {a.ratio:g}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
