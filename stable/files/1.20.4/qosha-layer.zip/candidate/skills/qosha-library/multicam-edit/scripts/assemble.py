#!/usr/bin/env python3
"""Render the multicam edit: cutlist segments from A/B cameras + VO audio.

Builds an ffmpeg trim/concat filtergraph (written to a script file to avoid
command-length limits). Video is re-encoded (frame-accurate cuts require it);
the VO is the only audio track.

--keep keep.json (from detect_silence.py): applies pause-tightening. The
  keep-ranges are intersected with the cutlist, and each surviving piece is
  cut from BOTH the video and the VO at the same VO-time boundaries, so
  sync is preserved by construction. Audio pieces get 30 ms fades at joins
  so cuts never click. Also writes <out>_map.json (VO time -> output
  time) next to --out, for translating the person's preview timestamps.

--preview: 640px, ultrafast, crf 28 — renders in seconds for review.
--vfr-safe: normalizes to constant frame rate first (fixes drift on
  variable-frame-rate camera files).
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
import math


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: ffmpeg/ffprobe open a file only as a plain audio/video container or a single still image. A playlist
# (hls), concat list, dash manifest, image sequence or text file (tty) in Your files could otherwise make ffmpeg open
# other files, outside Your files.
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf,png_pipe,jpeg_pipe,webp_pipe,bmp_pipe,tiff_pipe,gif,apng")
FMT = ["-format_whitelist", MEDIA_FORMATS]


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f

FADE = 0.030  # audio fade at every cut join (s): 30 ms in and out, browser-use/video-use rule 3


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)


def probe(path):
    r = subprocess.run(
        ["ffprobe", *FMT, "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=r_frame_rate:format=duration", "-of", "json", path],
        capture_output=True, text=True)
    if r.returncode != 0:
        die(f"ffprobe failed on {path}: {r.stderr.strip()[:300]}")
    d = json.loads(r.stdout)
    num, den = d["streams"][0]["r_frame_rate"].split("/")
    fps = float(num) / float(den)
    return float(d["format"]["duration"]), fps


def probe_dims(path):
    """Displayed frame size, i.e. AFTER ffmpeg applies rotation metadata.

    Phone footage commonly stores a portrait frame plus a rotation tag; the
    decoder auto-rotates, so the raw stream width/height are transposed
    relative to what the filter chain actually sees. Crop math must use the
    displayed size or every punch-in lands in the wrong place.
    """
    r = subprocess.run(
        ["ffprobe", *FMT, "-v", "error", "-select_streams", "v:0",
         "-show_streams", "-of", "json", path],
        capture_output=True, text=True)
    if r.returncode != 0:
        die(f"ffprobe failed on {path}: {r.stderr.strip()[:300]}")
    s = json.loads(r.stdout)["streams"][0]
    w, h = int(s["width"]), int(s["height"])
    rot = 0
    try:
        rot = int(float(s.get("rotation", 0)))
    except (TypeError, ValueError):
        rot = 0
    if rot == 0:
        for sd in s.get("side_data_list", []) or []:
            if "rotation" in sd:
                try:
                    rot = int(float(sd["rotation"]))
                except (TypeError, ValueError):
                    pass
    if abs(rot) % 180 == 90:
        w, h = h, w
    return w, h


def intersect(segments, keep_ranges):
    """Split cutlist segments by keep ranges -> ordered surviving pieces."""
    pieces = []
    for seg in segments:
        for ks, ke in keep_ranges:
            s, e = max(seg["start"], ks), min(seg["end"], ke)
            if e - s > 0.02:
                # carry EVERY key, not just src/start/end. Rebuilding the dict
                # by hand silently dropped zoom/zoom_x/zoom_y, so passing --keep
                # discarded the entire punch-in system while still rendering a
                # clean, correct-length video. Nothing failed; the framing just
                # wasn't there. Only reproduced with tightening on, which is why
                # short un-tightened samples always looked right.
                piece = dict(seg)
                piece["start"], piece["end"] = s, e
                pieces.append(piece)
    pieces.sort(key=lambda p: p["start"])
    return pieces


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--a", required=True, help="A-roll video")
    p.add_argument("--b", default=None, help="B-roll video (omit for single-camera edits)")
    p.add_argument("--vo", required=True, help="mastered VO audio")
    p.add_argument("--offset-a", type=float, required=True)
    p.add_argument("--offset-b", type=float, default=None)
    p.add_argument("--cutlist", required=True)
    p.add_argument("--keep", default=None,
                   help="keep.json from detect_silence.py (pause tightening)")
    p.add_argument("--out", required=True)
    p.add_argument("--preview", action="store_true")
    p.add_argument("--vfr-safe", action="store_true")
    p.add_argument("--crf", type=int, default=None)
    p.add_argument("--target-height", type=int, default=None,
                   help="delivery height (e.g. 1080 from 4K sources). Default: "
                        "source height, or 360 in preview mode")
    args = p.parse_args()
    # GUARDFIX3: every path stays in Files (ffmpeg/ffprobe get the real path); every number is finite.
    args.a, args.b, args.vo = _inside(args.a), _inside(args.b), _inside(args.vo)
    args.cutlist, args.keep = _inside(args.cutlist), _inside(args.keep)
    args.out = _inside(args.out, write=True)
    # the timeline map is written next to the output: a link of that name pointing outside Files is refused up front
    map_path = _inside(os.path.splitext(args.out)[0] + "_map.json", write=True)
    args.offset_a = _finite(args.offset_a, "--offset-a")
    if args.offset_b is not None:
        args.offset_b = _finite(args.offset_b, "--offset-b")

    with open(args.cutlist) as f:
        cut = json.load(f)
    segments = cut["segments"]
    if not segments:
        die("cutlist has no segments")
    for i, seg in enumerate(segments):
        if seg.get("src") not in ("a", "b"):
            die(f"cutlist segment {i}: src must be \"a\" or \"b\"")
        for k in ("start", "end", "zoom", "zoom_x", "zoom_y"):
            if k in seg:
                seg[k] = _finite(seg[k], f"cutlist segment {i} {k}")
        if "start" not in seg or "end" not in seg:
            die(f"cutlist segment {i}: needs start and end")

    if args.keep:
        with open(args.keep) as f:
            keep_ranges = [(_finite(ks, "keep start"), _finite(ke, "keep end"))
                           for ks, ke in json.load(f)["keep"]]
        pieces = intersect(segments, keep_ranges)
        if not pieces:
            die("keep ranges and cutlist don't overlap — check inputs")
    else:
        pieces = [dict(s) for s in segments]

    uses_b = any(seg["src"] == "b" for seg in pieces)
    if uses_b and (args.b is None or args.offset_b is None):
        die("cutlist contains B segments but --b/--offset-b not given "
            "(for single-camera edits the cutlist must be A-only)")

    dur_a, fps_a = probe(args.a)
    W, H = probe_dims(args.a)
    offsets = {"a": args.offset_a}
    durs = {"a": dur_a}
    if args.b is not None:
        dur_b, _ = probe(args.b)
        offsets["b"] = args.offset_b
        durs["b"] = dur_b

    for seg in pieces:
        src = seg["src"]
        cs, ce = seg["start"] + offsets[src], seg["end"] + offsets[src]
        if cs < -0.05 or ce > durs[src] + 0.05:
            die(f"segment {seg} maps to {cs:.2f}-{ce:.2f}s in {src}-roll "
                f"(file is {durs[src]:.2f}s) — camera doesn't cover this range. "
                "Cap the cutlist with build_cutlist --end, or fix offsets.")

    if args.b is not None:
        inputs = {"a": 0, "b": 1}
        vo_idx = 2
        in_files = [*FMT, "-i", args.a, *FMT, "-i", args.b, *FMT, "-i", args.vo]
    else:
        inputs = {"a": 0}
        vo_idx = 1
        in_files = [*FMT, "-i", args.a, *FMT, "-i", args.vo]

    # Every piece is normalised to one delivery size before concat — pieces
    # cropped at different zoom levels are different sizes, and concat demands
    # uniformity.
    out_h = args.target_height or (360 if args.preview else H)
    out_h = max(2, out_h // 2 * 2)
    out_w = max(2, int(round(W * out_h / H)) // 2 * 2)

    lines = []
    pair_refs = []
    out_cursor = 0.0
    tmap = []
    for i, seg in enumerate(pieces):
        src = seg["src"]
        cs = max(0.0, seg["start"] + offsets[src])
        ce = min(durs[src], seg["end"] + offsets[src])
        plen = seg["end"] - seg["start"]
        pre = f"fps={fps_a:.5f}," if args.vfr_safe else ""
        # Punch-in: crop a window out of the source, then scale to the delivery
        # size. Cropping (not upscaling) is what makes this free — a 2x punch on
        # 4K footage delivered at 1080 is pixel-for-pixel native, a real second
        # camera angle you already shot. "zoom_x"/"zoom_y" (0-1, default centred
        # horizontally and a bit high) place the crop window; a head-and-
        # shoulders subject usually sits above centre.
        z = float(seg.get("zoom", 1.0))
        zf = ""
        if z > 1.001:
            cw = max(16, int(W / z) // 2 * 2)
            ch = max(16, int(H / z) // 2 * 2)
            cx = int(float(seg.get("zoom_x", 0.5)) * W - cw / 2)
            cy = int(float(seg.get("zoom_y", 0.5)) * H - ch / 2)
            cx = max(0, min(W - cw, cx))
            cy = max(0, min(H - ch, cy))
            zf = f"crop={cw}:{ch}:{cx}:{cy},"
        lines.append(
            f"[{inputs[src]}:v]trim=start={cs:.4f}:end={ce:.4f},"
            f"{pre}{zf}scale={out_w}:{out_h},setsar=1,"
            f"setpts=PTS-STARTPTS[v{i}];")
        if args.keep:
            fo = max(0.0, plen - FADE)
            lines.append(
                f"[{vo_idx}:a]atrim=start={seg['start']:.4f}:end={seg['end']:.4f},"
                f"asetpts=PTS-STARTPTS,"
                f"afade=t=in:d={FADE},afade=t=out:st={fo:.4f}:d={FADE}[a{i}];")
            pair_refs.append(f"[v{i}][a{i}]")
        else:
            pair_refs.append(f"[v{i}]")
        tmap.append({"src": src, "vo_in": round(seg["start"], 3),
                     "vo_out": round(seg["end"], 3),
                     "out_in": round(out_cursor, 3),
                     "out_out": round(out_cursor + plen, 3)})
        out_cursor += plen

    if args.keep:
        lines.append(f"{''.join(pair_refs)}concat=n={len(pieces)}:v=1:a=1[vc][aout];"
                     f"[vc]format=yuv420p[vout]")
        maps = ["-map", "[vout]", "-map", "[aout]"]
    else:
        lines.append(f"{''.join(pair_refs)}concat=n={len(pieces)}:v=1:a=0,"
                     f"format=yuv420p[vout]")
        maps = ["-map", "[vout]", "-map", f"{vo_idx}:a:0"]

    # the filtergraph script lives next to the output (inside Your files), not
    # in a system temp folder
    out_dir = os.path.dirname(os.path.abspath(args.out))
    os.makedirs(out_dir, exist_ok=True)
    fd, script = tempfile.mkstemp(suffix=".txt", prefix=".filtergraph_", dir=out_dir)
    with os.fdopen(fd, "w") as f:
        f.write("\n".join(lines))

    crf = args.crf if args.crf is not None else (28 if args.preview else 18)
    preset = "ultrafast" if args.preview else "slow"
    cmd = ["ffmpeg", "-v", "error", "-y", "-stats",
           *in_files,
           "-filter_complex_script", script,
           *maps,
           "-c:v", "libx264", "-preset", preset, "-crf", str(crf),
           "-c:a", "aac", "-b:a", "320k",
           "-movflags", "+faststart", "-shortest",
           args.out]
    r = subprocess.run(cmd)
    os.unlink(script)
    if r.returncode != 0:
        die("ffmpeg render failed")

    # named after the output file so preview/final/re-renders can't clobber
    # each other's maps — a map must always describe exactly one video
    map_path = _inside(map_path, write=True)   # GUARDFIX3: checked again just before the write
    with open(map_path, "w") as f:
        json.dump(tmap, f, indent=1)

    # Container validity is NOT decodability. A file can have a valid moov,
    # the correct duration and the expected byte count while most of its
    # frames are scrambled (for example a file-sync conflict during the
    # write). probe() passes on those files. Decode it before believing it.
    _v = subprocess.run(["ffmpeg", "-v", "error", *FMT, "-i", args.out, "-f", "null", "-"],
                        capture_output=True, text=True)
    if _v.returncode != 0 or _v.stderr.strip():
        die(f"decode verify FAILED on {args.out} — the file is corrupt, not "
            f"merely unplayable. Do NOT delete whatever it replaced.\n"
            f"{_v.stderr.strip()[:500]}")

    out_dur, _ = probe(args.out)
    print(json.dumps({"out": args.out, "duration": round(out_dur, 2),
                      "pieces": len(pieces),
                      "resolution": f"{out_w}x{out_h}",
                      "punch_ins": sum(1 for s in pieces if float(s.get("zoom", 1)) > 1.001),
                      "tightened": bool(args.keep),
                      "timeline_map": map_path,
                      "mode": "preview" if args.preview else "final"}))


if __name__ == "__main__":
    main()
