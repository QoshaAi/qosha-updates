#!/usr/bin/env python3
"""Transcribe the VO with word-level timestamps, and optionally align the
written script to the recording.

Two modes, one pass each:

TRANSCRIBE (default) — faster-whisper, word timestamps:
  transcript.md    one line per segment "[start-end] text" (cheap full read)
  transcript.json  {"language", "duration", "segments": [{"start","end","text",
                   "words": [{"word","start","end","probability"}]}]}
                   This is the standard word shape caption.py reads directly.

ALIGN (--align script.md) — stable-ts forced alignment of the KNOWN script
text against the audio. Returns an APPROXIMATE start/end for each script
sentence, plus "flagged": true where the aligner produced no usable word
timing (empty or zero-length words). Unflagged does NOT mean correct, and
flagged does NOT prove the speaker improvised: both are leads. Spot-check
placements by ear before anchoring a card. Output: script_align.json.

Language: alignment uses --language, else the language detected by the
transcription pass in this run, else the language stored in an existing
--out-json; if none is known it stops and asks for --language. Digit
spelling (below) is English-only and is skipped for other languages.

Rules encoded here:
- Feed the WAV. Lossy VBR input (MP3) causes progressive timestamp drift
  (documented whisper bug); the script warns on lossy inputs.
- In English, digits get spelled out before alignment ("1907" -> "nineteen
  oh seven"): alignment dictionaries can't time numerals, and numbers are
  exactly where cards tend to land.
- Timestamps are in VO time (pre-cut). Convert to output time through the
  render's <output>_map.json, never by eye.

Needs: faster-whisper (transcribe mode) and stable-ts (align mode), plus a
model already available locally. This script does not install anything: if
a package or model is missing it says so and stops. Then use a transcript the
person supplies, or skip the transcript-based passes.

Language auto-detected unless --language is given.
"""
import argparse
import json
import os
import re
import sys
import math


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


def _plain_media(path):
    """GUARDFIX3: faster-whisper / stable-ts decode with PyAV, which auto-detects the format: a playlist (hls), concat
    list or manifest in Your files could make it read media outside them. Only a file that a format-whitelisted ffprobe
    opens as plain audio/video goes on; without ffprobe nothing does."""
    import shutil
    import subprocess
    if not shutil.which("ffprobe"):   # GPT review: no guessing from the first bytes; without the check, no run
        sys.exit("refusing: ffprobe is needed to check the audio file first (install ffmpeg)")
    r = subprocess.run(["ffprobe", "-format_whitelist", MEDIA_FORMATS, "-v", "error", "-show_entries",
                        "format=format_name", "-of", "csv=p=0", "-i", path], capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit(f"refusing: {path} is not a plain audio or video file")


# GUARDFIX3: the formats ffprobe may open the input as (plain audio/video containers, no playlists or lists).
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf")


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f

LOSSY_EXT = {".mp3", ".m4a", ".aac", ".ogg", ".opus", ".wma"}

ONES = ("zero one two three four five six seven eight nine ten eleven twelve "
        "thirteen fourteen fifteen sixteen seventeen eighteen nineteen").split()
TENS = ("", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy",
        "eighty", "ninety")


def int_words(n):
    if n < 20:
        return ONES[n]
    if n < 100:
        return TENS[n // 10] + ("" if n % 10 == 0 else " " + ONES[n % 10])
    if n < 1000:
        s = ONES[n // 100] + " hundred"
        return s + ("" if n % 100 == 0 else " " + int_words(n % 100))
    if n < 1000000:
        s = int_words(n // 1000) + " thousand"
        return s + ("" if n % 1000 == 0 else " " + int_words(n % 1000))
    return str(n)   # beyond scope; leave for the failure flag to catch


def year_words(n):
    """Years the way they're actually spoken: 1907 -> nineteen oh seven."""
    if 1100 <= n <= 1999:
        head, tail = divmod(n, 100)
        if tail == 0:
            return int_words(head) + " hundred"
        if tail < 10:
            return int_words(head) + " oh " + ONES[tail]
        return int_words(head) + " " + int_words(tail)
    if 2000 <= n <= 2009:
        return "two thousand" + ("" if n == 2000 else " " + ONES[n - 2000])
    if 2010 <= n <= 2099:
        return "twenty " + int_words(n - 2000)
    return int_words(n)


def normalize_numbers(text):
    """Spell out the numeric forms that appear in spoken scripts.

    Covers: times (4:55 PM), years, plain integers, $N, N%, Nth. Anything
    exotic is left alone — the aligner's failure flag will surface it.
    """
    def time_sub(m):
        h, mm, ap = int(m.group(1)), m.group(2), m.group(3)
        out = int_words(h)
        if mm and mm != "00":
            mi = int(mm)
            out += " oh " + ONES[mi] if mi < 10 else " " + int_words(mi)
        if ap:
            out += " " + " ".join(ap.replace(".", "").lower())
        return out
    text = re.sub(r"\b(\d{1,2}):(\d{2})\s*([AaPp]\.?[Mm]\.?)?", time_sub, text)
    text = re.sub(r"\b(\d{1,2})\s*([AaPp])\.?[Mm]\.?\b",
                  lambda m: int_words(int(m.group(1))) + " " +
                  m.group(2).lower() + " m", text)
    text = re.sub(r"\$(\d+)", lambda m: int_words(int(m.group(1))) + " dollars",
                  text)
    text = re.sub(r"\b(\d+)\s*%", lambda m: int_words(int(m.group(1))) +
                  " percent", text)
    def ord_words(n):
        special = {1: "first", 2: "second", 3: "third", 5: "fifth", 8: "eighth",
                   9: "ninth", 12: "twelfth"}
        if n in special:
            return special[n]
        w = int_words(n)
        for a, b in (("ty", "tieth"), ("one", "first"), ("two", "second"),
                     ("three", "third"), ("five", "fifth"), ("eight", "eighth"),
                     ("nine", "ninth"), ("twelve", "twelfth")):
            if w.endswith(a):
                return w[:-len(a)] + b
        return w + "th"
    text = re.sub(r"\b(\d+)(st|nd|rd|th)\b",
                  lambda m: ord_words(int(m.group(1))), text)
    text = re.sub(r"\b(1[1-9]\d{2}|20\d{2})\b",
                  lambda m: year_words(int(m.group(1))), text)
    text = re.sub(r"\b\d+\b", lambda m: int_words(int(m.group(0))), text)
    return text


def strip_script(raw):
    """Reduce a script-master to spoken words only, split into sentences.

    Removes [bracketed cues], **bold** markers, headers, markdown — the same
    discipline as the teleprompter export: nothing survives that isn't said
    aloud. Returns a list of sentences (the alignment granularity, because
    cards anchor to sentences).
    """
    if "## Block" in raw:                      # drop any preamble before Block 1
        raw = raw.split("## Block", 1)[1]
        raw = raw.split("\n", 1)[1] if "\n" in raw else raw
    raw = re.sub(r"\\\[[^\]]*\\\]", " ", raw)  # escaped \[cues\]
    raw = re.sub(r"\[[^\]]*\]", " ", raw)      # [cues]
    raw = re.sub(r"^#+ .*$", " ", raw, flags=re.M)
    raw = re.sub(r"^\*\*[^*]+\*\*\s*$", " ", raw, flags=re.M)  # heading-bolds
    raw = re.sub(r"[*_`>|\\]", "", raw)
    raw = re.sub(r"\s+", " ", raw).strip()
    parts = re.split(r"(?<=[.!?…])\s+", raw)
    return [p.strip() for p in parts if len(p.strip()) > 1]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--vo", required=True, help="mastered VO audio — use the WAV")
    p.add_argument("--model", default="small",
                   help="tiny | base | small | medium (default small)")
    p.add_argument("--language", default=None, help="e.g. en, pt (default auto)")
    p.add_argument("--out-json", default="transcript.json")
    p.add_argument("--out-md", default="transcript.md")
    p.add_argument("--align", default=None, metavar="SCRIPT",
                   help="also force-align this script file (script-master.md)")
    p.add_argument("--align-out", default="script_align.json")
    p.add_argument("--failure-threshold", type=float, default=0.25)
    p.add_argument("--no-normalize", action="store_true")
    p.add_argument("--skip-transcript", action="store_true",
                   help="align only; skip the faster-whisper pass")
    args = p.parse_args()
    # GUARDFIX3: every path stays in Files, checked before the libraries load (so a refused path never reaches them);
    # --model is a plain model name, or a model folder inside Files.
    args.vo, args.align = _inside(args.vo), _inside(args.align)
    args.out_json, args.out_md = _inside(args.out_json, write=True), _inside(args.out_md, write=True)
    args.align_out = _inside(args.align_out, write=True)
    args.failure_threshold = _finite(args.failure_threshold, "--failure-threshold")
    if os.sep in args.model or args.model.startswith((".", "~")) or os.path.lexists(args.model):
        args.model = _inside(args.model)
        # GUARDFIX3 (GPT review): every file under a model folder must resolve inside Files too (no link out)
        for root, dirs, files in os.walk(args.model):
            for name in dirs + files:
                _inside(os.path.join(root, name))
    elif not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}", args.model):
        sys.exit("refusing: --model must be a model name (tiny, base, small, medium ...) or a folder in your Files")
    if args.language is not None and not re.fullmatch(r"[A-Za-z]{2,3}([_-][A-Za-z]{2,4})?", args.language):
        sys.exit("refusing: --language must be a language code such as en or pt")
    _plain_media(args.vo)

    ext = os.path.splitext(args.vo)[1].lower()
    if ext in LOSSY_EXT:
        print(f"WARNING: {ext} input. Lossy/VBR audio causes progressive "
              "timestamp drift (documented whisper bug). Use the mastered WAV.",
              file=sys.stderr)

    detected = None
    # ---------- transcription pass ----------
    if not args.skip_transcript:
        try:
            from faster_whisper import WhisperModel
        except ImportError:
            sys.exit("faster-whisper is not available here. Not installing it. Options: a "
                     "transcript the person supplies, or skip the flub/caption passes.")
        model = WhisperModel(args.model, device="cpu", compute_type="int8")
        segments, info = model.transcribe(
            args.vo, language=args.language, word_timestamps=True,
            vad_filter=True, beam_size=5)
        segs, md = [], []
        for s in segments:
            words = [{"word": w.word.strip(), "start": round(w.start, 3),
                      "end": round(w.end, 3),
                      "probability": round(float(getattr(w, "probability", 0.0) or 0.0), 3)}
                     for w in (s.words or [])]
            segs.append({"start": round(s.start, 3), "end": round(s.end, 3),
                         "text": s.text.strip(), "words": words})
            md.append(f"[{s.start:07.2f}-{s.end:07.2f}] {s.text.strip()}")
        with open(args.out_json, "w") as f:
            json.dump({"language": info.language,
                       "duration": round(info.duration, 2),
                       "segments": segs}, f, indent=1, ensure_ascii=False)
        with open(args.out_md, "w") as f:
            f.write("\n".join(md) + "\n")
        detected = info.language
        print(json.dumps({"transcribed": True, "language": info.language,
                          "segments": len(segs),
                          "duration": round(info.duration, 2)}))

    # ---------- alignment pass ----------
    if args.align:
        try:
            import stable_whisper
        except ImportError:
            sys.exit("stable-ts is not available here. Not installing it. Place cards "
                     "from transcript.json word times instead.")
        lang = args.language or detected
        if not lang and os.path.exists(args.out_json):
            try:
                lang = json.load(open(args.out_json)).get("language")
            except (OSError, ValueError):
                lang = None
        if not lang:
            sys.exit("alignment language unknown: pass --language (e.g. en, es, pt) "
                     "or run the transcription pass first")
        raw = open(args.align).read()
        sentences = strip_script(raw)
        english = lang.lower().startswith("en")
        aligned_text = [normalize_numbers(s) if (english and not args.no_normalize)
                        else s for s in sentences]
        amodel = stable_whisper.load_faster_whisper(args.model)
        result = amodel.align(args.vo, "\n".join(aligned_text),
                              language=lang,
                              original_split=True,
                              failure_threshold=args.failure_threshold)
        out, low = [], 0
        for i, seg in enumerate(result.segments):
            words = seg.words or []
            # A positive duration on every word only means the aligner produced
            # timing; it is not a measure of correctness.
            timed = bool(words) and all((w.end - w.start) > 0 for w in words)
            if not timed:
                low += 1
            out.append({"i": i,
                        "text": sentences[i] if i < len(sentences) else seg.text,
                        "start": round(seg.start, 3),
                        "end": round(seg.end, 3),
                        "flagged": not timed})
        with open(args.align_out, "w") as f:
            json.dump({"sentences": out, "language": lang,
                       "numbers_spelled_out": english and not args.no_normalize,
                       "note": "approximate times in VO time (pre-cut); spot-check by "
                               "ear; convert via the render's _map.json"}, f, indent=1,
                      ensure_ascii=False)
        print(json.dumps({"aligned": len(out), "flagged": low, "language": lang,
                          "out": args.align_out,
                          "hint": "all times are approximate: spot-check placements by "
                                  "ear. Flagged sentences had no usable timing (possibly "
                                  "changed from the script) — place those from the "
                                  "transcript instead"}))


if __name__ == "__main__":
    main()
