# Tuning reference

## Cut feel (build_cutlist.py)

| Param | Default | Effect | When to change |
|---|---|---|---|
| `--min-b` | 1.2 s | Shortest B shot kept | Raise to 1.5–2.0 if the edit feels twitchy; lower if real deliberate looks are being dropped |
| `--min-a` | 2.0 s | Shortest A gap between B shots (else they merge) | Raise if the edit ping-pongs |
| `--pre` | 0.15 s | Cut leads the head turn | 0.2–0.3 feels more anticipatory; 0 = cut exactly on detection |
| `--post` | 0.10 s | Hold after turning back | Raise if returns to A feel abrupt |

The cutlist is plain JSON — for one-off notes from the person ("kill the cut at 4:12",
"extend the 6:30 B shot"), edit `segments` directly instead of re-running detection.
Keep segments contiguous (each `start` = previous `end`).

## Gaze classification rubric

Judge head shape, not features (on dark or backlit shots there may be no visible features):

- **A (frontal):** head outline is a symmetric oval; both shoulders visible and level;
  no nose protrusion on either side.
- **B (turned):** nose/chin break the head outline to one side; head narrows
  (profile is narrower than frontal); the near shoulder rotates forward.
  Direction matters — only turns toward the **B camera** count, on whichever side
  calibration found it. The screen direction of that turn is recorded in `episode.json`.
- **X (unclear):** mid-turn, hand near face, leaned out of frame, or motion blur.
  X never flips the state; it holds the previous one.

If frontal-vs-turned is genuinely hard to see at tile size, re-run `make_sheets.py`
with `--tile-height 300 --cols 3 --rows 3` on the ambiguous range.

Sampling density: coarse pass 1.0 fps is the floor. If the speaker makes fast,
brief looks, sample the whole episode at 2 fps instead — more sheets, better recall.
The fine pass (4 fps, ±2 s around each transition) is what puts the cut on the
right frame; don't skip it.

Alternative signal: if A-roll classification is unreliable, classify the B-roll
instead — when the speaker faces the B camera, the B footage shows a frontal
head shape, which can be easier to judge than a profile in the A footage.

## Pause tightening (detect_silence.py)

| Param | Default | Effect |
|---|---|---|
| `--min-silence` | 0.7 s | Pauses shorter than this are untouched (breaths live here — don't go below ~0.5) |
| `--keep` | 0.35 s | Remaining pause after tightening; raise to 0.5 for slower essay pacing |
| `--threshold` | -40 dBFS | Silence floor. Words getting clipped → lower to -45. Breaths/room surviving as "speech" → raise to -35 |

Notes:
- Runs on the mastered VO — afftdn denoise drops the noise floor, which is what
  makes a -40 dBFS threshold reliable. On unmastered audio, expect to raise it.
- The kept pause splits 60/40: decay after the phrase, run-up before the next.
  Cuts land inside silence, plus assemble adds 30 ms audio fades at every join,
  so clicks shouldn't happen; if the person hears one, the threshold is cutting
  into speech — lower it.
- The person is the pacing authority. Show the removed-seconds summary and, if in
  doubt, preview a 2-minute slice before committing to the full render.
- If they say "it breathes wrong" → raise `--keep` before touching anything else.

## Flub pass (transcribe.py + merge_cuts.py)

- Model size: `tiny` catches obvious retakes and is 6x faster; `small` (default) is
  more reliable on mumbled false starts. Go `medium` only if the transcript looks
  degraded. Language auto-detect works; force `--language` (for example `en`, `es`)
  if it wobbles. Alignment uses the same language; number spelling-out is English only.
- The riskiest failure is cutting a *deliberate* repetition (rhetorical repetition is
  a real essay device). The transcript alone can't always tell — delivery can
  (intonation, pacing). When a repeat could be intentional, listen to the clip or
  leave it in and flag it. False negatives cost the person a manual note; false
  positives cost a mangled sentence in a finished video.
- Snap window (`--snap-window`, default 0.25 s): raise to 0.4 if cuts still sound
  tight; lower to 0.15 if cuts eat short words near boundaries.
- Cut boundaries: prefer cutting from flubbed-word start to keeper-word start —
  this removes the flub AND the awkward pause after it in one range.
- If the person says a cut choice was wrong, don't just fix that one — record the
  pattern in episode.json ("keeps first take when second is rushed", "repeats key
  terms deliberately") for the next episode.

## Sync (sync_offset.py)

- Confidence ≥ 8: trust it. 4–8: spot-check one match point. < 4: something is
  wrong — usually a time-edited VO (words removed in the DAW), near-silent scratch
  audio, or wrong file pairing.
- Time-edited VO: sync on an unedited stretch with `--vo-window START DUR`
  (e.g., `--vo-window 30 60`). Offsets from different stretches disagreeing by
  more than ~0.1 s confirms the VO timeline no longer matches the take; in that
  case sync per-section and assemble per-section.
- The refine step distrusts itself if it wanders > 0.2 s from the coarse peak and
  falls back to the coarse value (10 ms resolution — under half a frame at 30 fps).

## Audio chain (master_audio.py)

Defaults are conservative. Listening notes → flag mapping:

- "sounds processed / underwater" → `--no-denoise` (afftdn artifacts) or lower `--denoise-db 6`
- "essy / lisping" → `--no-deess` (or the source was already de-essed in their audio app)
- "flat / lifeless" → `--no-compress`; loudnorm alone preserves dynamics
- "still too quiet online" → many video sites turn loud uploads down to a fixed
  level (check the site's current guidance), so louder rarely helps.
- LRA 11 is generous for spoken word; `--lra 8` for a tighter, more broadcast feel.

Treat the person's ears as ground truth and this chain as a time-saver, not an
authority, especially if they already mix their own audio. Offer an A/B: master a
60 s slice first (`ffmpeg -t 60`), let them compare it with their own chain, then
process the full VO.

## Punch-ins (single-camera seam hiding)

- `"zoom"` on a cutlist segment scales then center-crops back to frame size.
  **Consecutive framing levels must differ by ≥0.45 to register as a cut.** Established
  levels: **1.0 / 1.45 / 2.0**. Set `zoom_x`/`zoom_y` to the episode's tuned head-centred
  framing (found from a still frame of this footage) rather than leaving the crop centred.
  A 1.05–1.10 step is **invisible**, so it does not hide a seam — it produces a jump cut
  with extra steps.
- Quality cost is nil when the source is 4K delivered at 1080: a 2× crop is
  pixel-for-pixel native, so 2.0 is free. Only above 2× are you throwing away pixels.
- Alternate zoomed/unzoomed across flub seams. Return to 1.0 at a natural phrase
  break, not mid-sentence.
- Punch-ins also work as a rhythm device on long single-camera stretches even
  without flubs — but only add them if the person asks; pacing is theirs.
- Works in two-camera edits too (e.g., a subtle push on a long A segment).

## Render (assemble.py)

- Preview ≠ final: preview is 640 px ultrafast crf 28. Judge cuts and sync on it,
  never image quality.
- Final: crf 18, preset slow, yuv420p, AAC 320k, faststart. For a different
  quality/size tradeoff: `--crf 16` (bigger, cleaner) to `--crf 20`.
- A/V drift appearing minutes in → VFR camera files → `--vfr-safe`.
- Color/exposure mismatch between cameras: out of scope here. If it bothers the
  person, add a per-input `eq=` stage — ask before touching color on dark,
  stylised footage; crushed blacks may be the intended look.

## Performance expectations

Sync: seconds. Sheets: ~1–2 min per 10 min of footage. Preview render: well under
a minute. Final render: roughly real-time to 2× real-time depending on machine
(preset slow at 1080p). If final render time is a complaint, `--preset medium`
via a one-line edit in assemble.py costs ~2% bitrate efficiency.
