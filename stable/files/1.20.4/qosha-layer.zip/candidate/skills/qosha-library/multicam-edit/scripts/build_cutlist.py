#!/usr/bin/env python3
"""Turn gaze classifications into an edit decision list.

NOTE on placing visual events (punch-ins, cutaways) in single-camera edits:
put them ON the longest available pause, not at even time intervals. A pause
with a visual change reads as a deliberate beat; the same pause with a static
frame reads as dead air. See scripts/plan_punches.py, which schedules by
pause length rather than by clock.

Input gaze.json: [{"t": <vo_seconds>, "state": "A"|"B"|"X"}, ...]
(coarse + fine samples mixed is fine; they're sorted and deduplicated).

Rules (all tunable):
  - X samples inherit the previous state (hysteresis — mid-turn frames
    shouldn't flip the edit back and forth)
  - B runs shorter than --min-b are dropped (a glance is not a cut)
  - B runs separated by less than --min-a merge (no flashing back to A)
  - B starts are pulled --pre earlier (cutting slightly before the head
    turn completes reads as intentional), ends pushed --post later

Output: cutlist.json — full timeline as alternating segments in VO time —
plus a human-readable cutlist.md shot log.

--snap-to pulls every segment boundary onto the nearest pause. Most boundaries
land in a pause anyway, because the schedule and the silence detector read the
same pauses — but by common cause, not by design. One that escapes lands
mid-word and reads as an edit rather than a breath. Snapping makes that
impossible instead of rare.
"""
import argparse
import json
import sys
import math
import os


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f


def load_pauses(path, min_len):
    """Pause centres and spans from a silences.json or keep.json.

    Accepts either shape: an explicit pause list, or keep-ranges whose gaps are
    the pauses. Returns [(start, end), ...] for pauses at least min_len long.
    """
    d = json.load(open(path))
    spans = []
    if isinstance(d, dict) and d.get("pauses"):
        for p in d["pauses"]:
            s, e = (p["start"], p["end"]) if isinstance(p, dict) else (p[0], p[1])
            spans.append((float(s), float(e)))
    elif isinstance(d, dict) and d.get("keep"):
        keep = [(float(a), float(b)) for a, b in d["keep"]]
        spans = [(a[1], b[0]) for a, b in zip(keep, keep[1:]) if b[0] > a[1]]
    elif isinstance(d, list):
        for p in d:
            s, e = (p["start"], p["end"]) if isinstance(p, dict) else (p[0], p[1])
            spans.append((float(s), float(e)))
    else:
        sys.exit(f"{path}: no 'pauses' or 'keep' key and not a list")
    return [(s, e) for s, e in spans if e - s >= min_len]


def snap(t, pauses, window):
    """Pull t into the nearest pause within window. Returns (t, moved, why)."""
    if not pauses:
        return t, 0.0, "no-pauses"
    for s, e in pauses:
        if s <= t <= e:
            return t, 0.0, "already-in-pause"
    best, dist = None, None
    for s, e in pauses:
        # target the pause centre; a boundary on the very edge of a pause is
        # only marginally better than one just outside it
        c = (s + e) / 2
        d = abs(c - t)
        if dist is None or d < dist:
            best, dist = c, d
    if dist is not None and dist <= window:
        return round(best, 3), round(best - t, 3), "snapped"
    return t, 0.0, "no-pause-in-window"


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--gaze", required=True)
    p.add_argument("--end", type=float, required=True, help="VO duration (s)")
    p.add_argument("--min-b", type=float, default=1.2)
    p.add_argument("--min-a", type=float, default=2.0)
    p.add_argument("--pre", type=float, default=0.15)
    p.add_argument("--post", type=float, default=0.10)
    p.add_argument("--snap-to", metavar="SILENCES_OR_KEEP_JSON", default=None,
                   help="pull every boundary onto the nearest pause")
    p.add_argument("--snap-window", type=float, default=1.5,
                   help="furthest a boundary may be moved to reach a pause")
    p.add_argument("--snap-min-pause", type=float, default=0.30,
                   help="ignore pauses shorter than this when snapping")
    p.add_argument("--out", default="cutlist.json")
    p.add_argument("--log", default=None)
    args = p.parse_args()
    # GUARDFIX3: paths stay in Files (an --out/--log link to a file outside is refused); numbers are finite.
    args.gaze, args.snap_to = _inside(args.gaze), _inside(args.snap_to)
    args.out, args.log = _inside(args.out, write=True), _inside(args.log, write=True)
    for k in ("end", "min_b", "min_a", "pre", "post", "snap_window", "snap_min_pause"):
        setattr(args, k, _finite(getattr(args, k), "--" + k.replace("_", "-")))

    pauses = (load_pauses(args.snap_to, args.snap_min_pause)
              if args.snap_to else [])

    with open(args.gaze) as f:
        samples = json.load(f)
    if not samples:
        sys.exit("gaze file is empty")

    # sort, dedupe (later entries win — fine pass overrides coarse)
    by_t = {}
    for s in sorted(samples, key=lambda s: s["t"]):
        by_t[round(_finite(s["t"], "gaze t"), 3)] = str(s["state"]).upper()
    ts = sorted(by_t)

    # resolve X via hysteresis
    states = []
    prev = "A"
    for t in ts:
        st = by_t[t]
        if st not in ("A", "B"):
            st = prev
        states.append((t, st))
        prev = st

    # collapse into B intervals; a run extends to the next differing sample
    b_runs = []
    run_start = None
    for i, (t, st) in enumerate(states):
        if st == "B" and run_start is None:
            run_start = t
        elif st == "A" and run_start is not None:
            b_runs.append([run_start, t])
            run_start = None
    if run_start is not None:
        b_runs.append([run_start, args.end])

    # merge close runs, then drop short ones
    merged = []
    for r in b_runs:
        if merged and r[0] - merged[-1][1] < args.min_a:
            merged[-1][1] = r[1]
        else:
            merged.append(r)
    kept = [r for r in merged if r[1] - r[0] >= args.min_b]
    dropped = len(merged) - len(kept)

    # apply pre/post roll, clamp, re-merge any resulting overlaps
    adj = []
    for r in kept:
        s = max(0.0, r[0] - args.pre)
        e = min(args.end, r[1] + args.post)
        if adj and s - adj[-1][1] < args.min_a:
            adj[-1][1] = e
        else:
            adj.append([s, e])

    # Snap boundaries onto pauses. Both ends of a shot move independently, then
    # any shot squeezed below min_b by the move is dropped rather than left as a
    # stub — a 0.3s shot is debris, not a decision.
    snap_report = []
    if pauses:
        snapped = []
        for s, e in adj:
            ns, ds, ws = snap(s, pauses, args.snap_window)
            ne, de, we = snap(e, pauses, args.snap_window)
            if ds:
                snap_report.append({"was": round(s, 3), "now": ns, "moved": ds, "why": ws})
            if de:
                snap_report.append({"was": round(e, 3), "now": ne, "moved": de, "why": we})
            if ne - ns >= args.min_b:
                snapped.append([ns, ne])
        adj = snapped

    # build full alternating timeline
    segments = []
    cursor = 0.0
    for s, e in adj:
        if s > cursor:
            segments.append({"src": "a", "start": round(cursor, 3), "end": round(s, 3)})
        segments.append({"src": "b", "start": round(s, 3), "end": round(e, 3)})
        cursor = e
    if cursor < args.end:
        segments.append({"src": "a", "start": round(cursor, 3), "end": round(args.end, 3)})
    if not segments:
        segments = [{"src": "a", "start": 0.0, "end": round(args.end, 3)}]

    # Report boundaries still outside a pause after snapping. Each is a place a
    # framing change will read as an edit rather than a breath — sometimes that
    # is the point, but it should be a decision, not a side effect.
    unsnapped = []
    if pauses:
        for seg in segments:
            for edge in ("start", "end"):
                t = seg[edge]
                if t in (0.0, round(args.end, 3)):
                    continue
                if not any(s <= t <= e for s, e in pauses):
                    unsnapped.append(round(t, 3))
        unsnapped = sorted(set(unsnapped))

    with open(args.out, "w") as f:
        json.dump({"end": args.end, "segments": segments,
                   "snapped": snap_report,
                   "boundaries_not_in_pause": unsnapped,
                   "params": {"min_b": args.min_b, "min_a": args.min_a,
                              "pre": args.pre, "post": args.post,
                              "snap_window": args.snap_window if pauses else None}},
                  f, indent=1)

    def fmt(t):
        return f"{int(t // 60)}:{t % 60:05.2f}"

    if args.log:
        lines = ["# Cut list", "",
                 f"{len(adj)} B-roll shots | {dropped} glance(s) dropped (< {args.min_b}s)", "",
                 "| # | src | in | out | dur |", "|---|-----|----|-----|-----|"]
        for i, seg in enumerate(segments, 1):
            lines.append(f"| {i} | {seg['src'].upper()} | {fmt(seg['start'])} | "
                         f"{fmt(seg['end'])} | {seg['end'] - seg['start']:.2f}s |")
        with open(args.log, "w") as f:
            f.write("\n".join(lines) + "\n")

    print(json.dumps({"segments": len(segments), "b_shots": len(adj),
                      "dropped_glances": dropped,
                      "boundaries_snapped": len(snap_report),
                      "boundaries_not_in_pause": len(unsnapped),
                      "out": args.out}))
    for u in unsnapped:
        print(f"  boundary {fmt(u)} is not inside a pause — it will read as an "
              f"edit, not a breath", file=sys.stderr)


if __name__ == "__main__":
    main()
