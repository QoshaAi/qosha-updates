#!/usr/bin/env python3
"""Schedule single-camera visual events (punch-ins) onto the VO's own pauses.

The rule this encodes, learned the hard way: **a pause with a visual change
is a beat; a pause with a static frame is a hole.** Scheduling cuts at even
clock intervals and snapping to whatever silence happens to be nearby leaves
the longest, most audible pauses sitting bare — which is exactly where a
viewer feels the edit go slack.

So this walks the timeline and, for each stretch that has gone too long
without a visual event, picks the *longest* pause in that stretch and cuts
there. Long pauses get first claim on cuts.

Framing levels must be far enough apart to register: 1.5 vs 1.9 is invisible
at a cut, so `--levels` defaults to 1.0/1.45/2.0 and adjacent segments are
always forced to differ by at least --min-delta.

Reads a silence map (from --silences, or computed from --vo) and any existing
event boundaries (e.g. dead-air cuts already in keep.json), and writes a
cutlist.json that assemble.py consumes.

--overrides applies authored beats on top of the mechanical schedule. A
framing decision that lives only in prose (a note saying "tightest frame
here") gets silently dropped; a file the pipeline consumes is a rule, and
the script reports what it applied and what it could not place.

An override with "hold_until" keeps its framing for the WHOLE interval
[at, hold_until): any mechanical boundary inside it gets the same framing,
and equal neighbours are merged. The cutlist always covers 0..--end without
gaps.

Authored boundaries (each override's start and its hold_until) are used
exactly as written: a hold asked for at 10-15 s is 10-15 s in the cutlist.
They are never moved to a nearby pause or folded away. Only when the person
explicitly asks for it does --snap-overrides move an override's START to the
nearest pause within --override-window seconds (never past its own
hold_until or a neighbouring override); hold_until is never moved, and the
report lists every start that moved ("requested" vs "resolved"). A mechanical cut point within 1 s of one is dropped
instead. A mechanical piece shorter than 1 s is folded into a mechanical
neighbour; an override's own piece is kept even when shorter than 1 s (it
was asked for, and the script says so). If a short piece sits between two
authored boundaries (or between one and the start or end of the timeline),
nothing can absorb it without moving the person's framing: the script exits
with status 1 and writes NO cutlist, naming the override to adjust. It also
exits 1 without writing if any override could not be applied. A cutlist is
written only when every override landed exactly as asked.

Temporary audio goes in a hidden folder next to --out.

  punch_overrides.json:
    [ {"at": "15:25", "zoom": 2.0, "why": "key line — tightest"},
      {"at": "16:58", "zoom": 2.0, "hold_until": "17:45", "why": "hard push"},
      {"at": "22:04", "zoom": 1.0, "why": "pull wide for the close"} ]

  "at" and "hold_until" accept seconds or MM:SS.

Without --snap-overrides an override that does not sit on a pause is still
applied exactly where asked; the script notes that it may read as an edit
rather than a beat.
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
import wave

import numpy as np
import math


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: ffmpeg/ffprobe open a file only as a plain audio/video container or a single still image. A playlist
# (hls), concat list, dash manifest, image sequence or text file (tty) in Your files could otherwise make ffmpeg open
# other files, outside Your files.
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf,png_pipe,jpeg_pipe,webp_pipe,bmp_pipe,tiff_pipe,gif,apng")
FMT = ["-format_whitelist", MEDIA_FORMATS]


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f

SR = 16000
ENV_HZ = 100
DECIM = SR // ENV_HZ


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)


def parse_time(t):
    """Accept 925, 925.5, 15:25 or 15:25.5."""
    t = str(t).strip()
    if ":" not in t:
        try:
            return float(t)
        except ValueError:
            die(f"unparseable time {t!r}")
    parts = t.split(":")
    if len(parts) not in (2, 3):
        die(f"unparseable time {t!r} — use seconds, MM:SS or HH:MM:SS")
    try:
        secs = float(parts[-1]) + int(parts[-2]) * 60
        if len(parts) == 3:
            secs += int(parts[0]) * 3600
    except ValueError:
        die(f"unparseable time {t!r}")
    return secs


def load_overrides(path, end):
    """[{at, zoom, hold_until, why}, ...] sorted, validated against the timeline."""
    d = json.load(open(path))
    items = d if isinstance(d, list) else d.get("overrides", [])
    if not items:
        die(f"{path}: no overrides found")
    out = []
    for i, o in enumerate(items):
        if "at" not in o or "zoom" not in o:
            die(f"{path}[{i}]: each override needs 'at' and 'zoom'")
        at = parse_time(o["at"])
        until = parse_time(o["hold_until"]) if o.get("hold_until") else None
        if not 0 <= at < end:
            die(f"{path}[{i}]: 'at' {o['at']} is outside the timeline (0–{end:.1f}s)")
        if until is not None and until <= at:
            die(f"{path}[{i}]: 'hold_until' is not after 'at'")
        if until is not None and until > end + 0.01:
            die(f"{path}[{i}]: 'hold_until' {o['hold_until']} is past the timeline end ({end:.1f}s)")
        out.append({"at": at, "zoom": _finite(o["zoom"], f"override {i} zoom"), "until": until,
                    "why": o.get("why", ""), "raw": o.get("at")})
    out.sort(key=lambda o: o["at"])
    for a, b in zip(out, out[1:]):
        if a["until"] and b["at"] < a["until"]:
            die(f"{path}: override at {a['raw']} holds past the next one at {b['raw']}")
    return out


def silences(vo, work_dir, floor_db=-40.0, min_dur=0.35):
    """[(midpoint, duration), ...] for every pause at least min_dur long."""
    with tempfile.TemporaryDirectory(dir=work_dir, prefix=".punch-") as td:
        w = os.path.join(td, "v.wav")
        r = subprocess.run(["ffmpeg", "-v", "error", "-y", *FMT, "-i", vo, "-vn",
                            "-ac", "1", "-ar", str(SR), "-c:a", "pcm_s16le", w],
                           capture_output=True, text=True)
        if r.returncode != 0:
            die(f"ffmpeg failed: {r.stderr.strip()[:300]}")
        with wave.open(w) as f:
            x = np.frombuffer(f.readframes(f.getnframes()), dtype=np.int16)
    x = np.abs(x.astype(np.float64) / 32768.0)
    env = np.convolve(x, np.ones(DECIM) / DECIM, mode="same")[::DECIM]
    db = 20 * np.log10(env + 1e-9)
    out, start = [], None
    for i, quiet in enumerate(db < floor_db):
        if quiet and start is None:
            start = i
        elif not quiet and start is not None:
            a, b = start / ENV_HZ, i / ENV_HZ
            if b - a >= min_dur:
                out.append(((a + b) / 2, b - a))
            start = None
    if start is not None:
        a, b = start / ENV_HZ, len(db) / ENV_HZ
        if b - a >= min_dur:
            out.append(((a + b) / 2, b - a))
    return out


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--vo", help="mastered VO (used if --silences absent)")
    p.add_argument("--silences", help="precomputed [[mid,dur],...] json")
    p.add_argument("--end", type=float, required=True, help="timeline end (VO s)")
    p.add_argument("--keep", default=None,
                   help="keep.json — its cut points already are visual events")
    p.add_argument("--max-gap", type=float, default=62.0,
                   help="longest stretch allowed without a visual event")
    p.add_argument("--levels", default="1.0,1.45,2.0")
    p.add_argument("--min-delta", type=float, default=0.45,
                   help="adjacent framings must differ by at least this")
    p.add_argument("--zoom-x", type=float, default=0.5)
    p.add_argument("--zoom-y", type=float, default=0.5)
    p.add_argument("--min-shot", type=float, default=6.0)
    p.add_argument("--overrides", default=None, metavar="PUNCH_OVERRIDES_JSON",
                   help="authored beats that win over the mechanical schedule")
    p.add_argument("--snap-overrides", action="store_true",
                   help="opt-in: move each override's start to the nearest pause within "
                        "--override-window (default: every override starts exactly where asked)")
    p.add_argument("--override-window", type=float, default=1.5,
                   help="with --snap-overrides: how far an override's start may move to reach a pause")
    p.add_argument("--out", default="cutlist.json")
    args = p.parse_args()
    # GUARDFIX3: paths stay in Files (ffmpeg gets the real path); numbers that reach the cutlist are finite.
    args.vo, args.silences, args.keep = _inside(args.vo), _inside(args.silences), _inside(args.keep)
    args.overrides, args.out = _inside(args.overrides), _inside(args.out, write=True)
    for k in ("end", "max_gap", "min_delta", "zoom_x", "zoom_y", "min_shot", "override_window"):
        setattr(args, k, _finite(getattr(args, k), "--" + k.replace("_", "-")))
    args.levels = ",".join(repr(_finite(v, "--levels")) for v in args.levels.split(","))

    if args.silences:
        sil = [tuple(_finite(v, "silence") for v in s) for s in json.load(open(args.silences))]
    elif args.vo:
        sil = silences(args.vo, os.path.dirname(os.path.abspath(args.out)))
    else:
        die("need --vo or --silences")
    sil = [s for s in sil if 2.0 < s[0] < args.end - 3.0]
    if not sil:
        die("no usable pauses found")

    events = []
    if args.keep:
        keep = [(_finite(s, "keep start"), _finite(e, "keep end")) for s, e in json.load(open(args.keep))["keep"]]
        prev = None
        for s, e in keep:
            if prev is not None:
                events.append(prev)
            prev = e
    events = sorted(set(round(e, 2) for e in events))

    # Fill every over-long stretch by claiming its LONGEST pause. Repeat until
    # no stretch exceeds max_gap or no candidate pause remains.
    chosen = list(events)
    for _ in range(400):
        pts = [0.0] + sorted(chosen) + [args.end]
        worst, span = None, 0.0
        for i in range(len(pts) - 1):
            if pts[i + 1] - pts[i] > span:
                span, worst = pts[i + 1] - pts[i], (pts[i], pts[i + 1])
        if span <= args.max_gap or worst is None:
            break
        lo, hi = worst
        pool = [s for s in sil
                if lo + args.min_shot < s[0] < hi - args.min_shot
                and all(abs(s[0] - c) > args.min_shot for c in chosen)]
        if not pool:
            break
        # longest pause wins; ties break toward the middle of the stretch
        mid = (lo + hi) / 2
        pool.sort(key=lambda s: (-round(s[1], 2), abs(s[0] - mid)))
        chosen.append(round(pool[0][0], 2))

    # Authored beats become boundaries in their own right, exactly where the
    # person asked. Only with --snap-overrides (opt-in) is a start nudged onto a
    # nearby pause; the nudge never crosses its own hold_until or a neighbouring
    # override, and hold_until itself never moves.
    overrides = load_overrides(args.overrides, args.end) if args.overrides else []
    ov_report = []
    for k, o in enumerate(overrides):
        lo = 0.0 if k == 0 else (overrides[k - 1]["until"] or overrides[k - 1]["at"])
        hi = min(x for x in [o["until"], overrides[k + 1]["at"] if k + 1 < len(overrides) else None,
                             args.end] if x is not None)
        near = [m for m, _ in sil if abs(m - o["at"]) <= args.override_window and lo < m < hi]
        if args.snap_overrides and near:
            o["t"] = round(min(near, key=lambda m: abs(m - o["at"])), 3)
        else:
            o["t"] = round(o["at"], 3)
        o["on_pause"] = any(abs(m - o["t"]) < 0.6 for m, _ in sil)
        if o["until"] is not None:
            o["until"] = round(min(o["until"], args.end), 3)

    # Authored boundaries win: drop any mechanical cut point within 1 s of one.
    end = round(args.end, 3)
    authored = sorted({o["t"] for o in overrides}
                      | {o["until"] for o in overrides if o["until"] and o["until"] < end})
    authored = [t for t in authored if 0.0 < t < end]
    mech = [c for c in chosen if 0.0 < c < end and all(abs(c - a) >= 1.0 for a in authored)]
    bounds = [0.0] + sorted(set(mech) | set(authored)) + [end]

    def owner(s):
        # An override owns every span that starts at its point or inside its
        # hold interval [t, until).
        for o in overrides:
            if abs(o["t"] - s) < 0.06:
                return o
            if o["until"] and o["t"] - 0.06 <= s < o["until"] - 0.06:
                return o
        return None

    def is_authored(t):
        return any(abs(t - a) < 0.06 for a in authored)

    def who(t):
        o = next((o for o in overrides if abs(o["t"] - t) < 0.06
                  or (o["until"] and abs(o["until"] - t) < 0.06)), None)
        return f"the override at {o['raw']}" if o else f"{t:.2f}s"

    # spans: [start, end, owning override or None]
    spans = [[bounds[i], bounds[i + 1], owner(bounds[i])] for i in range(len(bounds) - 1)]
    short_authored = []
    changed = True
    while changed:
        changed = False
        for i, (s, e, ow) in enumerate(spans):
            if e - s >= 1.0:
                continue
            if ow is not None:
                if (s, e) not in short_authored:
                    short_authored.append((s, e))
                continue
            # A mechanical piece shorter than 1 s: remove one of its MECHANICAL
            # boundaries (left first). Authored boundaries and 0/end never move.
            if i > 0 and not is_authored(s):
                spans[i - 1][1] = e
                del spans[i]
            elif i + 1 < len(spans) and not is_authored(e):
                spans[i + 1][0] = s
                del spans[i]
            else:
                left = "the start of the timeline" if i == 0 else who(s)
                right = "the end of the timeline" if i + 1 == len(spans) else who(e)
                die(f"cannot plan: only {e - s:.2f}s between {left} and {right}. Nothing can absorb "
                    f"it without moving an authored framing. Move that override (or its hold_until) "
                    f"so the gap is 0 or at least 1 s, then re-run. No cutlist was written"
                    + (f"; the existing {args.out} is from an earlier run and must not be used."
                       if os.path.exists(args.out) else "."))
            changed = True
            break

    LV = [float(v) for v in args.levels.split(",")]
    segs, prev = [], None
    for i, (s, e, forced) in enumerate(spans):
        # An override owns its segment(s) outright. Only where none applies does
        # the mechanical alternation choose; it keeps min_delta from the framing
        # before it AND from an override that starts right after it, so the
        # override's start is a visible cut.
        if forced:
            z = forced["zoom"]
        else:
            nxt = spans[i + 1][2]["zoom"] if i + 1 < len(spans) and spans[i + 1][2] else None
            ok = lambda v, d: (prev is None or abs(v - prev) >= d) and (nxt is None or abs(v - nxt) >= d)
            opts = [v for v in LV if ok(v, args.min_delta)] or [v for v in LV if ok(v, 0.001)] \
                or [v for v in LV if v != prev] or LV
            z = opts[i % len(opts)]
        prev = z
        seg = {"src": "a", "start": round(s, 3), "end": round(e, 3)}
        if z > 1.001:
            seg.update({"zoom": z, "zoom_x": args.zoom_x, "zoom_y": args.zoom_y})
        if forced:
            seg["override"] = forced["why"] or forced["raw"]
        # equal framing on both sides is an invisible cut: merge it
        if segs and abs(segs[-1].get("zoom", 1.0) - seg.get("zoom", 1.0)) < 0.001 \
                and segs[-1].get("override") == seg.get("override"):
            segs[-1]["end"] = seg["end"]
        else:
            segs.append(seg)
    if not segs:
        die("no segments produced")
    segs[0]["start"] = 0.0
    segs[-1]["end"] = end
    for a, b in zip(segs, segs[1:]):
        if abs(a["end"] - b["start"]) > 1e-6:
            die(f"internal error: gap or overlap between {a} and {b}")

    # Every override must be able to name the segment it created. One that can't
    # was silently dropped — which is the entire failure this flag exists to end.
    for o in overrides:
        seg = next((s for s in segs if abs(s["start"] - o["t"]) < 0.001), None)
        hold_ok = True
        if o["until"]:
            hold_ok = all(abs(s.get("zoom", 1.0) - o["zoom"]) < 0.001
                          for s in segs
                          if s["start"] < o["until"] - 0.06 and s["end"] > o["t"] + 0.06)
        if o["until"] and o["until"] < end - 0.001:
            # the hold must end exactly at hold_until: a boundary there, or the
            # framing simply continues (a following override with the same zoom)
            after = next((s for s in segs if s["start"] <= o["until"] + 0.001 < s["end"]), None)
            hold_ok = hold_ok and (any(abs(s["start"] - o["until"]) < 0.001 for s in segs)
                                   or bool(after and abs(after.get("zoom", 1.0) - o["zoom"]) < 0.001
                                           and after.get("override") not in (None, o["why"] or o["raw"])))
        ov_report.append({
            "at": o["raw"], "requested": round(o["at"], 3), "resolved": o["t"],
            "moved_to_pause": abs(o["t"] - o["at"]) > 0.001, "zoom": o["zoom"],
            "hold_until": o["until"],
            "landed_on_pause": o["on_pause"],
            "applied": bool(seg and abs(seg.get("zoom", 1.0) - o["zoom"]) < 0.001
                            and hold_ok),
            "why": o["why"],
        })

    failed = [o for o in ov_report if not o["applied"]]
    if failed:
        for o in failed:
            print(f"  FAILED override at {o['at']} (zoom {o['zoom']}) — not applied. {o['why']}",
                  file=sys.stderr)
        die("cannot plan: an override would be lost, so no cutlist was written"
            + (f"; the existing {args.out} is from an earlier run and must not be used."
               if os.path.exists(args.out) else "."))

    # write atomically: a cutlist on disk always comes from a complete, valid plan
    out_dir = os.path.dirname(os.path.abspath(args.out))
    fd, tmp = tempfile.mkstemp(prefix=".cutlist-", suffix=".json", dir=out_dir)
    with os.fdopen(fd, "w") as f:
        json.dump({"end": end, "segments": segs, "overrides": ov_report}, f, indent=1)
    os.replace(tmp, args.out)

    gaps = [segs[i + 1]["start"] - segs[i]["start"] for i in range(len(segs) - 1)]
    on_pause = sum(1 for s in segs[1:]
                   if any(abs(s["start"] - m) < 0.6 for m, _ in sil))
    applied = sum(1 for o in ov_report if o["applied"])
    print(json.dumps({
        "segments": len(segs),
        "punch_ins": sum(1 for s in segs if "zoom" in s),
        "cuts_landing_on_a_pause": f"{on_pause}/{len(segs) - 1}",
        "overrides_applied": f"{applied}/{len(ov_report)}" if ov_report else None,
        "avg_shot_seconds": round(sum(gaps) / len(gaps), 1) if gaps else 0,
        "longest_shot_seconds": round(max(gaps), 1) if gaps else 0,
        "out": args.out,
    }, indent=2))

    for s, e in short_authored:
        print(f"  note: {who(s)} keeps a {e - s:.2f}s piece ({s:.2f}-{e:.2f}s), shorter than 1 s, "
              f"because it was asked for; move it if that was not intended", file=sys.stderr)
    for o in ov_report:
        if o["moved_to_pause"]:
            print(f"  override at {o['at']} moved to {o['resolved']}s (--snap-overrides): "
                  f"its start is {o['resolved'] - o['requested']:+.2f}s from the request", file=sys.stderr)
        elif not o["landed_on_pause"] and o["resolved"] > 0:
            print(f"  override at {o['at']} applied exactly at {o['resolved']}s; there is no pause "
                  f"there, so it may read as an edit, not a beat", file=sys.stderr)


if __name__ == "__main__":
    main()
