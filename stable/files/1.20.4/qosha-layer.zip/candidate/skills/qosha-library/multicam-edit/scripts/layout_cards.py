#!/usr/bin/env python3
"""Composite a graphic card over footage as a split-screen or corner inset,
sliding in from the edge it occupies.

Why not full-frame: cutting entirely away from a narrator severs the viewer's
anchor. Keeping the speaker on screen makes the graphic read as reference
rather than interruption.

Two layouts, chosen by how much information the card carries:
  split  — 50/50. Footage cropped to fill the left panel, card on the right.
           For multi-panel or labelled cards that must stay legible.
  inset  — card in a corner at --inset-scale of frame width, thin keyline.
           For single-subject cards; keeps the full composition intact.

The card slides in from the edge it occupies, holds, then slides back out.
Slide duration is --slide seconds at each end.

Emits a clip covering exactly [--start, --start+--duration) of --video's
time (+ --offset). Audio: by default the clip KEEPS --video's own audio track
(the already-edited audio when --video is the assembled edit). --vo FILE
--with-audio uses that file instead (only for raw camera sources, where the
VO is on the same timeline); --no-audio writes video only.
"""
import argparse
import json
import os
import subprocess
import sys
import math
import re


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: ffmpeg/ffprobe open a file only as a plain audio/video container or a single still image. A playlist
# (hls), concat list, dash manifest, image sequence or text file (tty) in Your files could otherwise make ffmpeg open
# other files, outside Your files.
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf,png_pipe,jpeg_pipe,webp_pipe,bmp_pipe,tiff_pipe,gif,apng")
FMT = ["-format_whitelist", MEDIA_FORMATS]


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f


# Cards often composite as near-pure white against a dark frame. A few percent
# of pixels above 250 luma on a phone in a dark room reads as a flashlight
# rather than an object in the scene. colorlevels compresses the top
# of the range only — blacks and the halftone's tonal role are untouched, and the
# keyline comes down with the artwork so it doesn't become the brightest thing in
# frame. Applied after pad so it covers both.
WHITE_POINT = 0.90
WHITE_POINT_FILTER = (f"colorlevels=romax={WHITE_POINT}:gomax={WHITE_POINT}:"
                      f"bomax={WHITE_POINT},")


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)


def audio_source(args, video):
    """Report which audio the output carries, so a silent result is visible."""
    if args.no_audio:
        return "none (--no-audio)"
    if args.with_audio:
        return f"vo: {args.vo}"
    r = subprocess.run(["ffprobe", *FMT, "-v", "error", "-select_streams", "a",
                        "-show_entries", "stream=index", "-of", "csv=p=0", video],
                       capture_output=True, text=True)
    return "video's own track" if r.stdout.strip() else "none (the video has no audio track)"


def card_content_box(path, threshold=20):
    """Bounding box of the card's actual artwork, ignoring its black surround.

    AI-generated cards often arrive letterboxed inside their own
    black margin. Framing the FILE instead of the ARTWORK leaves a dead gap
    between the keyline and the image — the frame has to hug the content or
    it shouldn't be there at all.
    """
    try:
        from PIL import Image, ImageChops
    except ImportError:
        return None
    im = Image.open(path).convert("RGB")
    bg = Image.new("RGB", im.size, (0, 0, 0))
    diff = ImageChops.difference(im, bg).convert("L").point(
        lambda v: 255 if v > threshold else 0)
    box = diff.getbbox()
    if not box:
        return None
    x0, y0, x1, y1 = box
    # ignore a trim that reclaims almost nothing
    if (x1 - x0) > im.width * 0.985 and (y1 - y0) > im.height * 0.985:
        return None
    return (x0, y0, x1 - x0, y1 - y0, im.width, im.height)


def probe_dims(path):
    r = subprocess.run(
        ["ffprobe", *FMT, "-v", "error", "-select_streams", "v:0", "-show_streams",
         "-of", "json", path], capture_output=True, text=True)
    if r.returncode != 0:
        die(f"ffprobe failed on {path}")
    s = json.loads(r.stdout)["streams"][0]
    w, h = int(s["width"]), int(s["height"])
    rot = 0
    try:
        rot = int(float(s.get("rotation", 0)))
    except (TypeError, ValueError):
        pass
    if rot == 0:
        for sd in s.get("side_data_list", []) or []:
            if "rotation" in sd:
                try:
                    rot = int(float(sd["rotation"]))
                except (TypeError, ValueError):
                    pass
    if abs(rot) % 180 == 90:
        w, h = h, w
    return w, h


def build_card_chain(idx, spec, OW, OH, start, slide, no_trim):
    """Filter fragment + overlay expression for one card. Returns
    (filter_lines, overlay_expr_x, overlay_y, enable_window, info)."""
    path = spec["file"]
    layout = spec.get("layout", "inset")
    side = spec.get("side", "right")
    scale = float(spec.get("inset_scale", 0.40))
    trim = None if no_trim else card_content_box(path)

    if layout == "split":
        panel = OW // 2 // 2 * 2
        card_w, card_h = panel, OH
        card_x_final = panel if side == "right" else 0
        card_y = 0
        off = OW if side == "right" else -panel
    else:
        card_w = int(OW * scale) // 2 * 2
        aspect = (trim[3] / trim[2]) if trim else (9 / 16)
        card_h = max(2, int(card_w * aspect) // 2 * 2)
        margin = int(OW * 0.03)
        card_x_final = (OW - card_w - margin) if side == "right" else margin
        card_y = margin
        off = OW if side == "right" else -card_w

    t0 = float(spec["card_in"]) - start
    t_in = t0 + slide
    if spec.get("exit_at") is not None:
        t_out = float(spec["exit_at"]) - start
    else:
        t_out = t_in + float(spec.get("card_hold", 6.0))
    t_end = t_out + slide

    pre = f"crop={trim[2]}:{trim[3]}:{trim[0]}:{trim[1]}," if trim else ""
    lines = [f"[{idx + 1}:v]{pre}scale={card_w - 6}:{card_h - 6},"
             f"pad={card_w}:{card_h}:3:3:white,setsar=1[card{idx}];"]
    rise = f"clip((t-{t0:.3f})/{slide:.3f},0,1)"
    fall = f"clip((t-{t_out:.3f})/{slide:.3f},0,1)"
    xexpr = f"{off}+({card_x_final}-{off})*({rise}-{fall})"
    info = {"file": os.path.basename(path), "layout": layout,
            "on": round(float(spec["card_in"]), 2),
            "off": round(start + t_end, 2),
            "held": round(t_out - t_in, 2),
            "type": "reference" if spec.get("exit_at") is not None else "illustration",
            "trimmed": bool(trim)}
    return lines, xexpr, card_y, (t0, t_end), info


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--video", required=True, help="camera source")
    p.add_argument("--card", help="graphic PNG (single-card mode)")
    p.add_argument("--cards", help="JSON list of cards for one pass — each entry: "
                                   "{file, card_in, card_hold|exit_at, layout, "
                                   "side, inset_scale}. Use for real episodes; "
                                   "one ffmpeg pass instead of one per card.")
    p.add_argument("--offset", type=float, required=True,
                   help="camera_time = vo_time + offset")
    p.add_argument("--start", type=float, required=True, help="VO time of clip start")
    p.add_argument("--duration", type=float, required=True)
    p.add_argument("--card-in", type=float, default=None,
                   help="VO time the card starts sliding in (single-card mode)")
    p.add_argument("--card-hold", type=float, default=10.0,
                   help="seconds the card is fully on screen. Channel minimum 10.0 "
                        "for simple cards, 15.0 for dense/multi-panel ones — a "
                        "dense card kept small needs the extra time to be read.")
    p.add_argument("--no-trim", action="store_true",
                   help="don't auto-crop the card's black surround (keep the file "
                        "as-is, letterboxing and all)")
    p.add_argument("--exit-at", type=float, default=None, metavar="VO_TIME",
                   help="REFERENCE CARDS: start the slide-out at this VO time "
                        "instead of after a fixed hold. Use when the card is a "
                        "legend the narrator walks through — anchor it ~3s after "
                        "he names the last item on the card, so it's still on "
                        "screen while he's talking about it. Overrides --card-hold.")
    p.add_argument("--layout", choices=["split", "inset"], default="split")
    p.add_argument("--side", choices=["right", "left"], default="right")
    p.add_argument("--slide", type=float, default=0.35)
    p.add_argument("--inset-scale", type=float, default=0.38)
    p.add_argument("--zoom", type=float, default=1.0, help="punch-in on the footage")
    p.add_argument("--zoom-x", type=float, default=0.5)
    p.add_argument("--zoom-y", type=float, default=0.5)
    p.add_argument("--target-height", type=int, default=1080)
    p.add_argument("--vo", default=None,
                   help="separate VO on the same timeline as --video (raw camera sources only)")
    p.add_argument("--with-audio", action="store_true",
                   help="take audio from --vo instead of --video's own track")
    p.add_argument("--no-audio", action="store_true",
                   help="write video only (default keeps --video's own audio)")
    # Defaults are DELIVERABLE quality, not draft. This script re-encodes the
    # whole video, and on a finished episode it is the LAST pass — the file it
    # writes is the file that ships. Draft defaults would let the deliverable
    # silently inherit draft settings unless the caller happened to know to
    # override them. Opt DOWN to preview
    # quality explicitly; never rely on remembering to opt up.
    p.add_argument("--preview", action="store_true",
                   help="fast draft encode for review (360p, ultrafast, crf 28). "
                        "WITHOUT this flag the script renders at deliverable "
                        "quality: crf 18, preset slow, 1080p.")
    p.add_argument("--crf", type=int, default=None,
                   help="override; default 18 (final) / 28 (--preview)")
    p.add_argument("--preset", default=None,
                   help="override; default slow (final) / ultrafast (--preview)")
    p.add_argument("--out", required=True)
    args = p.parse_args()

    # GUARDFIX3: files read stay in Files (or this skill's folder), the output in Files; ffmpeg/ffprobe get the
    # resolved absolute paths. Numbers reach the filtergraph: finite only. The preset is a plain word.
    args.video, args.card, args.vo, args.cards = (_inside(args.video), _inside(args.card), _inside(args.vo),
                                                  _inside(args.cards))
    args.out = _inside(args.out, write=True)
    for k in ("offset", "start", "duration", "card_in", "card_hold", "exit_at", "slide", "inset_scale", "zoom",
              "zoom_x", "zoom_y"):
        if getattr(args, k) is not None:
            setattr(args, k, _finite(getattr(args, k), "--" + k.replace("_", "-")))
    if args.preset is not None and not re.fullmatch(r"[a-z]{1,16}", args.preset):
        die(f"refusing: --preset {args.preset!r} is not an x264 preset name")

    # Resolve encode quality the same way assemble.py does, so the two scripts
    # behave identically: final by default, draft only when asked.
    if args.crf is None:
        args.crf = 28 if args.preview else 18
    if args.preset is None:
        args.preset = "ultrafast" if args.preview else "slow"
    if args.preview and args.target_height == 1080:
        args.target_height = 360

    W, H = probe_dims(args.video)
    OH = args.target_height
    OW = int(round(W * OH / H)) // 2 * 2

    # ---- multi-card mode: every card composited in a single ffmpeg pass ----
    if args.cards:
        specs = json.load(open(args.cards))
        specs = specs["cards"] if isinstance(specs, dict) else specs
        if not specs:
            die("--cards file has no cards")
        # GUARDFIX3: each card file must be in Files (or this skill's folder); its times and scale must be finite
        # numbers (they are written into the filtergraph)
        for i, s in enumerate(specs):
            if not isinstance(s, dict) or "file" not in s:
                die(f"card {i}: each card needs a 'file'")
            s["file"] = _inside(s["file"])
            for k in ("card_in", "card_hold", "exit_at", "inset_scale"):
                if s.get(k) is not None:
                    s[k] = _finite(s[k], f"card {i} {k}")
        cam_start = args.start + args.offset
        inputs = ["-ss", f"{cam_start:.4f}", "-t", f"{args.duration:.4f}",
                  *FMT, "-i", args.video]
        for s in specs:
            inputs += ["-loop", "1", "-t", f"{args.duration:.4f}", *FMT, "-i", s["file"]]
        fg = [f"scale={OW}:{OH}", "setsar=1"]
        lines = [f"[0:v]{','.join(fg)}[stage0];"]
        infos = []
        for i, s in enumerate(specs):
            cl, xexpr, cy, (t0, t_end), info = build_card_chain(
                i, s, OW, OH, args.start, args.slide, args.no_trim)
            if t0 < 0 or t_end > args.duration:
                die(f"card {info['file']} window {t0:.1f}-{t_end:.1f}s falls "
                    f"outside the {args.duration}s clip")
            lines += cl
            lines.append(f"[stage{i}][card{i}]overlay=x='{xexpr}':y={cy}:"
                         f"enable='between(t,{t0:.3f},{t_end:.3f})'[stage{i + 1}];")
            infos.append(info)
        lines.append(f"[stage{len(specs)}]format=yuv420p[vout]")
        maps = ["-map", "[vout]"]
        if args.with_audio and not args.no_audio:
            if not args.vo:
                die("--with-audio needs --vo")
            inputs += ["-ss", f"{args.start:.4f}", "-t", f"{args.duration:.4f}",
                       *FMT, "-i", args.vo]
            maps += ["-map", f"{len(specs) + 1}:a"]
        elif not args.no_audio:
            maps += ["-map", "0:a?"]   # keep the edit's own audio
        cmd = (["ffmpeg", "-v", "error", "-y"] + inputs +
               ["-filter_complex", "".join(lines)] + maps +
               ["-c:v", "libx264", "-preset", args.preset, "-crf", str(args.crf),
                "-pix_fmt", "yuv420p", "-r", "30"] +
               ([] if args.no_audio else ["-c:a", "aac", "-b:a", "320k"]) +
               ["-movflags", "+faststart", args.out])
        if subprocess.run(cmd).returncode != 0:
            die("ffmpeg failed")
        print(json.dumps({"out": args.out, "cards": infos,
                          "audio": audio_source(args, args.video),
                          "resolution": f"{OW}x{OH}"}, indent=2))
        return

    if not args.card or args.card_in is None:
        die("single-card mode needs --card and --card-in (or use --cards)")

    trim = None if args.no_trim else card_content_box(args.card)

    dense = args.layout == "split" or args.inset_scale >= 0.44
    floor = 13.0 if dense else 6.0
    if args.exit_at is None and args.card_hold < floor:
        print(f"NOTE: card-hold {args.card_hold}s is below the {floor}s minimum for "
              f"{'dense' if dense else 'simple'} cards — it will read as a flash.",
              file=sys.stderr)

    t0 = args.card_in - args.start                 # card timing, clip-relative
    t_in_end = t0 + args.slide
    if args.exit_at is not None:
        t_out = args.exit_at - args.start
        if t_out <= t_in_end:
            die(f"--exit-at {args.exit_at} is before the card finishes sliding in")
    else:
        t_out = t_in_end + args.card_hold
    t_end = t_out + args.slide
    held = t_out - t_in_end
    if t0 < 0 or t_end > args.duration:
        die(f"card window {t0:.2f}-{t_end:.2f}s falls outside the {args.duration}s "
            f"clip — a card needs slide+hold+slide = "
            f"{2 * args.slide + args.card_hold:.1f}s of room after its cue")

    cam_start = args.start + args.offset
    if cam_start < 0:
        die("clip starts before the camera was rolling")

    # ---- footage chain ----
    fg = []
    if args.zoom > 1.001:
        cw = max(16, int(W / args.zoom) // 2 * 2)
        ch = max(16, int(H / args.zoom) // 2 * 2)
        cx = max(0, min(W - cw, int(args.zoom_x * W - cw / 2)))
        cy = max(0, min(H - ch, int(args.zoom_y * H - ch / 2)))
        fg.append(f"crop={cw}:{ch}:{cx}:{cy}")

    if args.layout == "split":
        # The card is a full-height black panel that slides OVER the footage.
        # Cropping the footage to half-width up front would leave an empty
        # black half on screen before the card arrives, which reads as a
        # broken render rather than a designed split.
        panel = OW // 2 // 2 * 2
        fg.append(f"scale={OW}:{OH}")
        card_w, card_h = panel, OH
        card_x_final = panel if args.side == "right" else 0
        card_y = 0
        off_screen = OW if args.side == "right" else -panel
    else:
        fg.append(f"scale={OW}:{OH}")
        card_w = int(OW * args.inset_scale) // 2 * 2
        # frame follows the artwork's real aspect, not the file's
        aspect = (trim[3] / trim[2]) if trim else (9 / 16)
        card_h = max(2, int(card_w * aspect) // 2 * 2)
        margin = int(OW * 0.03)
        card_x_final = (OW - card_w - margin) if args.side == "right" else margin
        card_y = margin
        off_screen = OW if args.side == "right" else -card_w

    fg.append("setsar=1")
    filt = [f"[0:v]{','.join(fg)}[stage];"]

    pre_crop = f"crop={trim[2]}:{trim[3]}:{trim[0]}:{trim[1]}," if trim else ""

    if args.layout == "split":
        inner_w = int(card_w * 0.88) // 2 * 2
        inner_h = max(2, int(inner_w * ((trim[3] / trim[2]) if trim else 9 / 16))
                      // 2 * 2)
        pad_x = (card_w - inner_w) // 2
        pad_y = max(0, (card_h - inner_h) // 2)
        filt.append(f"[1:v]{pre_crop}scale={inner_w}:{inner_h},"
                    f"pad={card_w}:{card_h}:{pad_x}:{pad_y}:black,"
                    f"drawbox=x={0 if args.side == 'right' else card_w - 3}:y=0:"
                    f"w=3:h={card_h}:color=white:t=fill,setsar=1[card];")
    else:
        # artwork scaled to fill, keyline sitting directly on its edge
        filt.append(f"[1:v]{pre_crop}scale={card_w - 6}:{card_h - 6},"
                    f"pad={card_w}:{card_h}:3:3:white,{WHITE_POINT_FILTER}"
                    f"setsar=1[card];")

    # Single expression, no nested if(): a rise ramp minus a fall ramp gives
    # 0 -> 1 -> 0 across the card's life. Nested if() chains here are
    # evaluated per output row and make the render pathologically slow.
    rise = f"clip((t-{t0:.3f})/{args.slide:.3f},0,1)"
    fall = f"clip((t-{t_out:.3f})/{args.slide:.3f},0,1)"
    xexpr = f"{off_screen}+({card_x_final}-{off_screen})*({rise}-{fall})"

    filt.append(f"[stage][card]overlay=x='{xexpr}':y={card_y}:"
                f"enable='between(t,{t0:.3f},{t_end:.3f})',format=yuv420p[vout]")

    inputs = ["-ss", f"{cam_start:.4f}", "-t", f"{args.duration:.4f}",
              *FMT, "-i", args.video, "-loop", "1", "-t", f"{args.duration:.4f}",
              *FMT, "-i", args.card]
    maps = ["-map", "[vout]"]
    if args.with_audio and not args.no_audio:
        if not args.vo:
            die("--with-audio needs --vo")
        inputs += ["-ss", f"{args.start:.4f}", "-t", f"{args.duration:.4f}",
                   *FMT, "-i", args.vo]
        maps += ["-map", "2:a"]
    elif not args.no_audio:
        maps += ["-map", "0:a?"]   # keep the edit's own audio

    cmd = (["ffmpeg", "-v", "error", "-y"] + inputs +
           ["-filter_complex", "".join(filt)] + maps +
           ["-c:v", "libx264", "-preset", args.preset, "-crf", str(args.crf),
            "-pix_fmt", "yuv420p", "-r", "30"] +
           ([] if args.no_audio else ["-c:a", "aac", "-b:a", "320k"]) +
           ["-movflags", "+faststart", args.out])
    if subprocess.run(cmd).returncode != 0:
        die("ffmpeg failed")

    print(json.dumps({"out": args.out, "layout": args.layout, "side": args.side,
                      "audio": audio_source(args, args.video),
                      "resolution": f"{OW}x{OH}",
                      "card_type": "reference (content-anchored exit)"
                                   if args.exit_at is not None else "illustration",
                      "card_on_screen": [round(args.card_in, 2),
                                         round(args.start + t_end, 2)],
                      "held_seconds": round(held, 2),
                      "art_trimmed": bool(trim),
                      "slide_seconds": args.slide}, indent=2))


if __name__ == "__main__":
    main()
