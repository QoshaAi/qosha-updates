#!/usr/bin/env python3
"""Sample a camera file into labeled contact sheets for the gaze pass.

Extracts frames at --fps between --start and --end (VO time; converted to
camera time via --offset), then tiles them into grid PNGs with each tile
labeled with its VO timestamp. Emits index.json mapping every tile to its
timestamp so classifications can be written back programmatically.
"""
import argparse
import json
import math
import os
import subprocess
import sys

from PIL import Image, ImageDraw, ImageFont


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: ffmpeg/ffprobe open a file only as a plain audio/video container or a single still image. A playlist
# (hls), concat list, dash manifest, image sequence or text file (tty) in Your files could otherwise make ffmpeg open
# other files, outside Your files.
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf,png_pipe,jpeg_pipe,webp_pipe,bmp_pipe,tiff_pipe,gif,apng")
FMT = ["-format_whitelist", MEDIA_FORMATS]


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)


def fmt_t(t):
    m = int(t // 60)
    return f"{m}:{t - 60 * m:04.1f}"


def load_font(size):
    for cand in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
        "/System/Library/Fonts/Menlo.ttc",
        "/System/Library/Fonts/Monaco.ttf",
        "C:/Windows/Fonts/consolab.ttf",
    ):
        if os.path.exists(cand):
            try:
                return ImageFont.truetype(cand, size)
            except OSError:
                pass
    return ImageFont.load_default()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--video", required=True)
    p.add_argument("--offset", type=float, required=True,
                   help="camera_time = vo_time + offset (from sync_offset.py)")
    p.add_argument("--start", type=float, required=True, help="VO time start (s)")
    p.add_argument("--end", type=float, required=True, help="VO time end (s)")
    p.add_argument("--fps", type=float, default=1.0, help="sample rate (frames/s)")
    p.add_argument("--out", required=True, help="output directory")
    p.add_argument("--cols", type=int, default=5)
    p.add_argument("--rows", type=int, default=4)
    p.add_argument("--tile-height", type=int, default=170)
    args = p.parse_args()
    # GUARDFIX3: --video / --out stay in Files (ffmpeg gets the real path; an --out link to a folder outside is
    # refused before anything in it is deleted); the numbers are finite (fps reaches the -vf graph).
    args.video, args.out = _inside(args.video), _inside(args.out, write=True)
    for k in ("offset", "start", "end", "fps"):
        setattr(args, k, _finite(getattr(args, k), "--" + k))
    if args.fps <= 0:
        die("--fps must be greater than 0")

    if args.end <= args.start:
        die("--end must be greater than --start")
    os.makedirs(args.out, exist_ok=True)
    frames_dir = _inside(os.path.join(args.out, "_frames"), write=True)
    os.makedirs(frames_dir, exist_ok=True)
    for f in os.listdir(frames_dir):
        os.remove(os.path.join(frames_dir, f))

    cam_start = args.start + args.offset
    cam_end = args.end + args.offset
    if cam_start < 0:
        die(f"VO time {args.start} maps to negative camera time {cam_start:.2f}; "
            "camera wasn't rolling yet")

    # -ss before -i (fast keyframe seek) then precise fps sampling
    cmd = ["ffmpeg", "-v", "error", "-y",
           "-ss", f"{cam_start:.3f}", "-to", f"{cam_end:.3f}", *FMT, "-i", args.video,
           "-vf", f"fps={args.fps},scale=-2:{args.tile_height}",
           "-qscale:v", "3",
           os.path.join(frames_dir, "f_%05d.jpg")]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        die(f"ffmpeg failed: {r.stderr.strip()[:400]}")

    frames = sorted(os.listdir(frames_dir))
    if not frames:
        die("no frames extracted — check offsets and time range")

    # frame n (1-indexed) is sampled at start + (n-1)/fps + 0.5/fps (fps filter
    # picks the frame nearest each interval midpoint; label with interval start
    # which is what build_cutlist expects)
    per_sheet = args.cols * args.rows
    n_sheets = math.ceil(len(frames) / per_sheet)
    font = load_font(15)
    label_h = 20
    index = []

    sample_img = Image.open(os.path.join(frames_dir, frames[0]))
    tw, th = sample_img.size

    for s in range(n_sheets):
        sheet = Image.new("RGB", (args.cols * tw, args.rows * (th + label_h)), (24, 24, 24))
        draw = ImageDraw.Draw(sheet)
        chunk = frames[s * per_sheet:(s + 1) * per_sheet]
        for i, fname in enumerate(chunk):
            gi = s * per_sheet + i
            t_vo = args.start + gi / args.fps
            col, row = i % args.cols, i // args.cols
            x, y = col * tw, row * (th + label_h)
            img = Image.open(os.path.join(frames_dir, fname))
            sheet.paste(img, (x, y))
            draw.rectangle([x, y + th, x + tw, y + th + label_h], fill=(24, 24, 24))
            draw.text((x + 4, y + th + 2), fmt_t(t_vo), fill=(255, 210, 60), font=font)
            index.append({"sheet": f"sheet_{s:03d}.png", "cell": i,
                          "t": round(t_vo, 2)})
        name = _inside(os.path.join(args.out, f"sheet_{s:03d}.png"), write=True)
        sheet.save(name)

    with open(_inside(os.path.join(args.out, "index.json"), write=True), "w") as f:
        json.dump({"fps": args.fps, "start": args.start, "end": args.end,
                   "tiles": index}, f, indent=1)

    print(json.dumps({"sheets": n_sheets, "tiles": len(index),
                      "dir": args.out,
                      "note": "read each sheet_*.png; tiles labeled with VO time"}))


if __name__ == "__main__":
    main()
