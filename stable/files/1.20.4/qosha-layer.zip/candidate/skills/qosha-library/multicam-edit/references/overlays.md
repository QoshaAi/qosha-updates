# Overlays reference

The overlay stage is renderer-agnostic by design: `composite_overlays.py` places any
transparent asset onto the assembled video (for cutaway cards use `layout_cards.py`; see
SKILL.md). The generator is the person's choice — start with what they already have, and
change only when a concrete element exceeds it.

## Where overlay files come from

| Source | Format | Notes |
|---|---|---|
| Files the person uploads to Your files | PNG with transparency, MOV | Use as-is. Ask for exports at video resolution. |
| A design app in Connections (for example Canva) | PNG with transparency | Check Connections first: use it only if it is connected, and only the actions it offers. Reading or exporting the person's own designs is fine; creating or changing anything in the app is a connected-app write and goes to **Qosha's approval card in the chat** for the person's **Allow this time** first. If it is not connected, say which kind of app to connect, or ask for uploaded files. |
| Pillow / ffmpeg drawtext (already here) | PNG | Fully automated simple cards; fine for plain text |
| A motion-graphics tool the person already has | MOV (ProRes 4444 alpha) | They render it and upload the file. Do not install a new tool for this. |
| After Effects / any NLE | MOV (ProRes 4444) or VP9-alpha WebM | Same compositing path, zero skill changes |

Animated GIF/APNG also work (GIF alpha is 1-bit — edges look crunchy; avoid for
quality work).

## The spec (overlays.json)

```json
{
  "overlays": [
    {"file": "overlays/term_anomie.png", "at": 92.5, "time_base": "vo",
     "duration": 6, "fade": 0.4, "position": "lower-third", "scale": 0.35},
    {"file": "overlays/quote_durkheim.mov", "at": 41.0, "time_base": "output",
     "position": "center"}
  ]
}
```

- `time_base: "vo"` is the default and usually correct: the moment is anchored to the
  narration ("when he says X"), and `composite_overlays.py --map <video>_map.json`
  converts it to output time, so pause tightening never desyncs overlays. Use the
  `_map.json` written next to the exact render being composited. If a VO
  timestamp falls inside a removed pause, it snaps forward to the next surviving
  moment and reports it.
- Still images need `duration` (default 5 s with a warning) and get a 0.4 s alpha
  fade in/out unless `fade` says otherwise. Videos play their intrinsic length
  (clamp with `duration`); `fade` can be added to them too.
- Positions: `lower-third` (default), `center`, `top-left`, `top-right`,
  `bottom-center`, or explicit `x`/`y` (ffmpeg expressions; `main_w`, `main_h`,
  `overlay_w`, `overlay_h` available).
- `scale`: overlay width as a fraction of video width — prefer exporting at the
  right size; scaling up degrades.

## Workflow

1. Collect timestamps from the person in whichever base they naturally give them
   (usually "at 1:32 when I say ...": that's VO time before tightening — confirm
   which if ambiguous).
2. Put assets in `$E/overlays/` (inside Your files), write `work/overlays.json`.
3. Composite onto the preview first:
   ```
   python3 "$S/composite_overlays.py" --video work/preview.mp4 \
     --overlays work/overlays.json --map work/preview_map.json \
     --preview --out work/preview_overlaid.mp4
   ```
   (When compositing onto a preview, remember preview is 640 px — positions are
   proportional so they hold, but small text may be illegible until the final.)
4. After approval, run the same command against `final.mp4` without `--preview`.
5. Record the spec in `episode.json`; recurring elements (episode title card,
   standard citation style) become reusable assets across episodes.

## Format gotchas (already handled by the script, listed for debugging)

- WebM alpha requires the `libvpx-vp9` decoder — ffmpeg's native VP9 decoder
  silently drops the alpha channel. The script sets this automatically.
- ProRes 4444 is the interchange standard for alpha video; files are large —
  that's normal, they're intermediates.
- Overlays are enabled only in their time window (`enable=between`), with
  `eof_action=pass`, so the base video is untouched outside it.
- Audio is stream-copied; compositing never re-encodes the VO.
