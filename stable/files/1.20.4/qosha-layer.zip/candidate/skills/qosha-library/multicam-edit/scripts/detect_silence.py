#!/usr/bin/env python3
"""Find long pauses in the VO and plan pause-tightening cuts.

Detects stretches below --threshold dBFS lasting at least --min-silence
seconds, and collapses each to --keep seconds of remaining pause. The kept
portion is split ~60/40: room-tone decay stays at the end of the phrase,
a short run-up stays before the next one — phrases never butt together.

Outputs keep.json: the ranges of VO time that SURVIVE (complement of the
cuts), consumed by assemble.py --keep, which applies identical cuts to the
VO and both camera streams so sync is preserved.

Run this on the MASTERED VO (post-denoise) — cleaner noise floor makes
detection far more reliable than on a raw recording.

--exempt protects ranges of VO time from tightening. Slow, deliberate
passages (an emotional ending, a dramatic pause) need their air; tightening
them like the rest strips exactly the silence that makes them land. Pass them
explicitly — a rule that lives only in prose gets dropped on the next run.

Temporary audio goes in a hidden folder next to --out.
"""
import argparse
import json
import os
import re
import subprocess
import sys
import tempfile
import wave

import numpy as np
import math


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: ffmpeg/ffprobe open a file only as a plain audio/video container or a single still image. A playlist
# (hls), concat list, dash manifest, image sequence or text file (tty) in Your files could otherwise make ffmpeg open
# other files, outside Your files.
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf,png_pipe,jpeg_pipe,webp_pipe,bmp_pipe,tiff_pipe,gif,apng")
FMT = ["-format_whitelist", MEDIA_FORMATS]


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f


def parse_time(t):
    """Accept 942.5, 15:42, 15:42.5 or 1:15:42.5."""
    t = str(t).strip()
    if re.fullmatch(r"\d+(\.\d+)?", t):
        return float(t)
    parts = t.split(":")
    if not 2 <= len(parts) <= 3:
        die(f"unparseable time {t!r} — use seconds, MM:SS or HH:MM:SS")
    try:
        secs = float(parts[-1])
        secs += int(parts[-2]) * 60
        if len(parts) == 3:
            secs += int(parts[0]) * 3600
    except ValueError:
        die(f"unparseable time {t!r}")
    return secs


def parse_exempt(specs):
    """['15:25-15:50', '4:16-4:46'] -> [(925.0, 950.0), (256.0, 286.0)] sorted."""
    out = []
    for spec in specs or []:
        for chunk in str(spec).split(","):
            chunk = chunk.strip()
            if not chunk:
                continue
            if "-" not in chunk:
                die(f"exempt range {chunk!r} must look like START-END")
            a, b = chunk.split("-", 1)
            s, e = parse_time(a), parse_time(b)
            if e <= s:
                die(f"exempt range {chunk!r} ends before it starts")
            out.append((s, e))
    out.sort()
    for (s1, e1), (s2, e2) in zip(out, out[1:]):
        if s2 < e1:
            die(f"exempt ranges overlap: {s1}-{e1} and {s2}-{e2}")
    return out

SR = 16000
ENV_HZ = 100
ENV_DECIM = SR // ENV_HZ


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)


def extract(src, dst):
    r = subprocess.run(["ffmpeg", "-v", "error", "-y", *FMT, "-i", src, "-vn",
                        "-ac", "1", "-ar", str(SR), "-c:a", "pcm_s16le", dst],
                       capture_output=True, text=True)
    if r.returncode != 0:
        die(f"ffmpeg failed: {r.stderr.strip()[:300]}")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--vo", required=True, help="mastered VO audio")
    p.add_argument("--threshold", type=float, default=-40.0,
                   help="dBFS below which audio counts as silence")
    p.add_argument("--min-silence", type=float, default=0.7,
                   help="only pauses at least this long (s) are tightened")
    p.add_argument("--keep", type=float, default=0.35,
                   help="pause duration (s) left after tightening")
    p.add_argument("--exempt", action="append", metavar="START-END",
                   help="protect a range from tightening; repeatable, or "
                        "comma-separated. Accepts seconds or MM:SS. "
                        "Use for sincere zones — they need their air.")
    p.add_argument("--out", default="keep.json")
    args = p.parse_args()
    # GUARDFIX3: --vo / --out stay in Files (ffmpeg gets the real path); the numbers are finite.
    args.vo, args.out = _inside(args.vo), _inside(args.out, write=True)
    for k in ("threshold", "min_silence", "keep"):
        setattr(args, k, _finite(getattr(args, k), "--" + k.replace("_", "-")))

    if args.keep >= args.min_silence:
        die("--keep must be smaller than --min-silence")

    exempt = parse_exempt(args.exempt)

    with tempfile.TemporaryDirectory(dir=os.path.dirname(os.path.abspath(args.out)),
                                     prefix=".silence-") as td:
        wav = os.path.join(td, "vo.wav")
        extract(args.vo, wav)
        with wave.open(wav, "rb") as w:
            x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    x = x.astype(np.float64) / 32768.0
    dur = len(x) / SR

    # 100 Hz envelope in dBFS
    kernel = np.ones(ENV_DECIM) / ENV_DECIM
    env = np.convolve(np.abs(x), kernel, mode="same")[::ENV_DECIM]
    db = 20 * np.log10(env + 1e-9)

    silent = db < args.threshold
    pauses = []
    start = None
    for i, s in enumerate(silent):
        if s and start is None:
            start = i
        elif not s and start is not None:
            pauses.append((start / ENV_HZ, i / ENV_HZ))
            start = None
    if start is not None:
        pauses.append((start / ENV_HZ, dur))

    # plan cuts: inside each long pause, keep 60% of --keep at the head
    # (phrase decay) and 40% at the tail (run-up), cut the middle
    cuts = []
    protected = []
    for s, e in pauses:
        if e - s < args.min_silence:
            continue
        # A pause that touches an exempt range at all is left whole. Trimming
        # the unprotected portion of a straddling pause would still shorten the
        # breath the sincere beat depends on, so the boundary is inclusive.
        hit = next(((xs, xe) for xs, xe in exempt if s < xe and e > xs), None)
        if hit:
            protected.append({"pause": [round(s, 3), round(e, 3)],
                              "inside": [round(hit[0], 3), round(hit[1], 3)]})
            continue
        # never tighten leading/trailing silence into nothing abrupt;
        # head/tail pauses get trimmed to --keep from the speech side
        if s <= 0.01:
            cuts.append((0.0, max(0.0, e - args.keep)))
        elif e >= dur - 0.01:
            cuts.append((min(dur, s + args.keep), dur))
        else:
            cuts.append((s + args.keep * 0.6, e - args.keep * 0.4))
    cuts = [(round(s, 3), round(e, 3)) for s, e in cuts if e - s > 0.05]

    # keep ranges = complement
    keep = []
    cursor = 0.0
    for s, e in cuts:
        if s > cursor:
            keep.append([round(cursor, 3), s])
        cursor = e
    if cursor < dur:
        keep.append([round(cursor, 3), round(dur, 3)])

    removed = sum(e - s for s, e in cuts)
    with open(args.out, "w") as f:
        json.dump({"vo_duration": round(dur, 3),
                   "keep": keep,
                   "removed_seconds": round(removed, 2),
                   "exempt_ranges": [[round(s, 3), round(e, 3)] for s, e in exempt],
                   "pauses_protected": protected,
                   "params": {"threshold": args.threshold,
                              "min_silence": args.min_silence,
                              "keep_pause": args.keep}}, f, indent=1)

    # Every exempt range must be able to name the pauses it saved. A range that
    # protected nothing is almost always a wrong timestamp, not a quiet passage.
    barren = [[round(s, 3), round(e, 3)] for s, e in exempt
              if not any(p["inside"] == [round(s, 3), round(e, 3)] for p in protected)]

    print(json.dumps({
        "pauses_found": len(pauses),
        "pauses_tightened": len(cuts),
        "pauses_protected": len(protected),
        "removed_seconds": round(removed, 2),
        "duration_before": round(dur, 2),
        "duration_after": round(dur - removed, 2),
        "out": args.out,
    }, indent=2))

    for p in protected:
        print(f"  protected {p['pause'][0]:.2f}-{p['pause'][1]:.2f}s "
              f"(exempt {p['inside'][0]:.2f}-{p['inside'][1]:.2f})", file=sys.stderr)
    for b in barren:
        print(f"  WARNING exempt range {b[0]:.2f}-{b[1]:.2f} protected no pauses "
              f"— check the timestamp", file=sys.stderr)


if __name__ == "__main__":
    main()
