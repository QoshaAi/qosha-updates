#!/usr/bin/env python3
"""Pre-export loudness gate: integrated -14 LUFS (±1 LU) and true peak <= -1.0 dBTP.

Lifted from kajisho5/ffmpeg-skill loudness.py (EBU R128 via ffmpeg loudnorm measurement).

  python3 loudness.py final.mp4                 # check; exit 0 = PASS, 1 = FAIL
  python3 loudness.py final.mp4 --json          # machine-readable
  python3 loudness.py mix.wav --fix mix_fixed.wav   # two-pass loudnorm to -14 LUFS / -1.5 dBTP, then re-check

Run it on the exact file you are about to export or upload. A FAIL blocks export.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import math
import os


# GUARDFIX3: a path named by an input file or argument (or handed to another program) must stay in the person's Files
# folder ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error. None stays None."""
    if path is None or str(path) == "":
        return None
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: ffmpeg/ffprobe open a file only as a plain audio/video container or a single still image. A playlist
# (hls), concat list, dash manifest, image sequence or text file (tty) in Your files could otherwise make ffmpeg open
# other files, outside Your files.
MEDIA_FORMATS = ("mov,matroska,webm,avi,flv,asf,mpeg,mpegts,mp3,wav,w64,aac,flac,ogg,m4v,h264,hevc,mpegvideo,aiff,"
                 "caf,mxf,ivf,png_pipe,jpeg_pipe,webp_pipe,bmp_pipe,tiff_pipe,gif,apng")
FMT = ["-format_whitelist", MEDIA_FORMATS]


def _finite(v, what):
    """GUARDFIX3: a number from an input file or argument that reaches the filtergraph or the timeline: finite only."""
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        sys.exit("refusing: %s is not a number: %r" % (what, v))
    if not math.isfinite(f):
        sys.exit("refusing: %s must be a finite number, not %r" % (what, v))
    return f

TARGET_I, TOL, MAX_TP, FIX_TP = -14.0, 1.0, -1.0, -1.5


def measure(path: str) -> dict:
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", *FMT, "-i", path, "-vn",
                        "-af", f"loudnorm=I={TARGET_I}:TP={FIX_TP}:LRA=11:print_format=json", "-f", "null", "-"],
                       capture_output=True, text=True)
    m = re.findall(r"\{[^{}]*\"input_i\"[^{}]*\}", r.stderr, re.S)
    if r.returncode != 0 or not m:
        raise SystemExit(f"loudness measurement failed (no audio stream?): {r.stderr.strip()[-400:]}")
    d = json.loads(m[-1])
    return {k: float(d[k]) for k in ("input_i", "input_tp", "input_lra", "input_thresh", "target_offset")}


def verdict(m: dict) -> dict:
    i_ok = abs(m["input_i"] - TARGET_I) <= TOL
    tp_ok = m["input_tp"] <= MAX_TP
    return {"integrated_lufs": m["input_i"], "true_peak_dbtp": m["input_tp"], "lra": m["input_lra"],
            "target": f"{TARGET_I} ±{TOL} LUFS, TP <= {MAX_TP} dBTP",
            "lufs_ok": i_ok, "true_peak_ok": tp_ok, "pass": i_ok and tp_ok}


def fix(src: str, dst: str, m: dict) -> None:
    m = {k: _finite(v, k) for k, v in m.items()}   # GUARDFIX3: only finite numbers reach the -af graph
    af = (f"loudnorm=I={TARGET_I}:TP={FIX_TP}:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}"
          f":measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true")
    is_video = subprocess.run(["ffprobe", *FMT, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=codec_type",
                               "-of", "csv=p=0", src], capture_output=True, text=True).stdout.strip() == "video"
    cmd = ["ffmpeg", "-v", "error", "-y", *FMT, "-i", src, "-af", af, "-ar", "48000"]
    cmd += (["-c:v", "copy", "-c:a", "aac", "-b:a", "320k"] if is_video else ["-c:a", "pcm_s24le"]) + [dst]
    subprocess.run(cmd, check=True)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("media")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--fix", metavar="OUT")
    a = ap.parse_args()
    # GUARDFIX3: the media and --fix output stay in Files (ffmpeg/ffprobe get the real path).
    a.media, a.fix = _inside(a.media), _inside(a.fix, write=True)
    v = verdict(measure(a.media))
    if a.fix:
        fix(a.media, a.fix, measure(a.media))
        v = {"before": v, "after": verdict(measure(a.fix)), "fixed_file": a.fix}
        v["pass"] = v["after"]["pass"]
    if a.json:
        print(json.dumps(v, indent=1))
    else:
        r = v.get("after", v)
        print(f"{'PASS' if v['pass'] else 'FAIL'}  {r['integrated_lufs']:.1f} LUFS (target {TARGET_I}±{TOL}), "
              f"true peak {r['true_peak_dbtp']:.1f} dBTP (max {MAX_TP})" + (f"  -> {a.fix}" if a.fix else ""))
    return 0 if v["pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
