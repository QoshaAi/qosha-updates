---
name: music-cut-planning
description: "Use to plan where video cuts land on a song"
version: 1.0.0
author: Qosha
license: Qosha original (owned by Qosha AI LLC)
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [video, music, editing, beats, cuts, audio]
---

# Music cut planning

Measure a song (beats, downbeats, phrases, energy changes, hard stops, silences) and choose where the picture should cut, then check a finished cut against the music with a contact sheet.

## When to use

- "Cut this to the music", "where should the cuts go", "does this edit sit on the beat".
- Planning a promo, reel or music video before editing, or checking one after.
- The person owns or has licensed the song. If the licence is unclear, say so before planning around it.

## Tools (all free and open)

- **ffmpeg / ffprobe** for decoding audio, silences, scene changes and still frames.
- **Python 3** with **numpy** (energy and onsets) and **Pillow** (drawing the contact sheet).
- **beat_this** (beat and downbeat tracker, needs **torch**) for beats and downbeats.
- **PySceneDetect** (`scenedetect` package) for shot cuts in a finished edit.
- Optional, word times: **mlx-whisper** on Apple Silicon Macs. Elsewhere, use a transcript the person gives you or skip word times.

If something is missing, say exactly what to install and ask before downloading anything: ffmpeg from ffmpeg.org or the system package manager; `python3 -m pip install numpy pillow "scenedetect[opencv]" torch`; beat_this following its project page (CPJKU/beat_this). Check each tool's current licence page before using it for a customer.

## Steps

1. **Get a clean audio file.** `ffmpeg -i song.mp3 -ac 1 -ar 44100 work/song.wav`. Note the length with `ffprobe -v error -show_entries format=duration -of csv=p=0 work/song.wav`.
2. **Beats and downbeats.** Run beat_this on the WAV. Record tempo (bpm), the beat times and the downbeat times. The tempo can come out half or double what a listener feels; say so.
3. **Onsets and energy.** In numpy, per video frame (for example 24 or 30 per second): loudness (RMS, scaled 0 to 1) and onsets (spectral flux peaks, each with a strength).
4. **Energy phases.** Group the song into 1-second blocks and label each run of blocks silent / low / mid / high. For each phase record onsets per second, its beats, and its own beat confidence: count the phase's onsets that fall within 70 ms of one of its beat times (on the beat) and the rest (off the beat); confidence = on / off. If there are no off-beat onsets, confidence counts as 1.3 or more only when there are at least 4 on-beat onsets, otherwise 0. Example: 26 on, 14 off gives 1.86.
5. **Phrases.** Where the beat grid is trustworthy, a phrase is every 4 bars of downbeats. Elsewhere, use energy-phase boundaries as phrase edges.
6. **Silences and hard stops.** Silences: `ffmpeg -i work/song.wav -af silencedetect=n=-50dB:d=0.5 -f null -` (at least 0.5 s below -50 dBFS). Hard stops: a loud stretch (0.5 s or more) that drops to near silence within 150 ms.
7. **Apply the calm-passage rule** (below) to choose cut points. Each cut point gets a time and a reason: beat, downbeat, phrase or energy.
8. **Write the plan** to `work/cut_plan.json` in Your files: tempo, beats, downbeats, phrases, energy phases, silences, hard stops, cut points with reasons, and words if measured. Add a one-paragraph plain summary for the person (for example "fast cuts in the chorus, long holds in the quiet bridge, cut to black at 2:41").
9. **Check a cut with a contact sheet** (below) at decision points: a chorus, a calm bridge, the ending. Not every second of a long song.

## The calm-passage rule

On calm music a beat tracker invents a steady beat that is not there (it can place beats every half second across a sustained pad with no rhythm at all). So:

- A phase is **calm** when it has fewer than 0.75 onsets per second, however loud it is.
- **Beats become cut points only** in phases that are not calm, have at least 4 beats, have their own beat confidence of at least 1.3, and only where a real onset sits within 70 ms of the beat.
- In calm passages, cut on **phrase and energy changes**, never on single beats. Hold shots longer; let slow moves and dissolves carry the time.
- **Hard stops** are where the picture stops too (a cut to black or a freeze), not a place to keep cutting.

## Contact sheet check

1. Before looking, write down what you expect (for example "shots change on the downbeats from 0:30 to 0:45").
2. Shot cuts in the edit: `scenedetect -i cut.mp4 detect-content list-scenes` (or the Python API).
3. Stills: one frame every few seconds with `ffmpeg -ss T -i cut.mp4 -frames:v 1 frame_T.jpg`.
4. Waveform: `ffmpeg -i cut.mp4 -filter_complex "showwavespic=s=1600x200" -frames:v 1 wave.png`.
5. With Pillow, stack one image: timecoded filmstrip on top, waveform below with beat ticks (taller on downbeats) and phrase lines, shot cuts drawn as lines across both, a lane of planned cut points by reason, and a word lane if you have word times. Save the numbers (shots, beats, cut points) next to it as JSON.
6. Compare the numbers to your expectation first, then look at the picture. Report each shot cut that is more than about 2 frames off its planned point, and each beat-cut that falls in a calm phase.

## What good looks like

- Every cut point has a reason, and no beat-cut sits inside a calm phase.
- Hard stops and long silences line up with a stop or hold in the picture.
- The report says plainly that beats, tempo and word times are machine-measured, not checked by ear.
- The plan is time data only; the edit itself is done by the person or a separate editing step.
