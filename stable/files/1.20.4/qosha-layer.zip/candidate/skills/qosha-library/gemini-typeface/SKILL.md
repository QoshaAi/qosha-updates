---
name: gemini-typeface
description: Use to apply the Gemini app's type style to a design.
version: 1.0.0
author: Qosha
license: Qosha original (owned by Qosha AI LLC)
---
# Gemini typeface

**When to use:** Apply the typeface and type scale Google's Gemini app uses (Google Sans Flex with Gemini's exact sizes, weights, widths and roundness) to any design or code project. Use when the user says /gemini-typeface, "Gemini font", or "type like Gemini".

Gemini's app sets almost all its text in **Google Sans Flex**, a variable font, and tunes it per style with four axes: weight (`wght`), width (`wdth`), optical size (`opsz`) and roundness (`ROND`). Code uses **Google Sans Code**. This skill reproduces that system on any project.

Source: read straight from gemini.google.com's live stylesheets on 2026-10-08 (Gemini's `--gem-sys-typography-*` design tokens). Re-check before relying on it for anything public. Google can change its app at any time.

## The fonts

| Role | Font | License | Get it |
|---|---|---|---|
| Everything (UI, body, headings) | Google Sans Flex | SIL Open Font License, free for commercial use | Google Fonts |
| Code | Google Sans Code | SIL Open Font License | Google Fonts |

Fallback stack, exactly as Gemini writes it: `"Google Sans Flex", "Google Sans", "Helvetica Neue", sans-serif`.

**Do not use Google Sans or Google Sans Text.** They are Google's own brand fonts, not licensed for other people's products, even though Google's font servers will hand them out. Google Sans Flex is the open rebuild of them and looks the same.

Axis ranges in Google Sans Flex: `opsz` 6–144, `slnt` −10–0, `wdth` 25–151, `wght` 1–1000, `ROND` 0–100.

## Web embed

```html
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Sans+Flex:opsz,slnt,wdth,wght,ROND@6..144,-10..0,25..151,1..1000,0..100&family=Google+Sans+Code:wght@300..800&display=swap">
```

Gemini sets the axes with `font-variation-settings`, for example `"wdth" 95, "opsz" 16, "ROND" 0`, and sets weight with normal `font-weight`.

## Gemini's type scale

Sizes in px at a 16px root. `wdth` 95 = slightly narrow, Gemini's default for reading text. `opsz` = the font size, so letter shapes adjust to how big they appear.

| Style | Size / line height | Weight | Tracking | wdth | opsz |
|---|---|---|---|---|---|
| Display L | 57 / 64 | 400 | −0.5px | 100 | 57 |
| Display M | 45 / 52 | 400 | −0.5px | 100 | 45 |
| Display S | 36 / 44 | 400 | 0 | 100 | 36 |
| Headline L | 32 / 40 | 400 | 0 | 100 | 32 |
| Headline M | 28 / 36 | 400 | 0 | 100 | 28 |
| Headline S | 24 / 32 | 400 | 0 | 100 | 24 |
| Title L | 22 / 28 | 400 | 0 | 100 | 22 |
| Title M | 16 / 24 | 500 | 0 | 95 | 16 |
| Title S | 14 / 20 | 500 | 0 | 95 | 14 |
| Body XL | 18 / 24 | 400 | 0 | 100 | 18 |
| Body L | 16 / 24 | 400 | 0 | 95 | 16 |
| Body M | 14 / 20 | 400 | 0 | 95 | 14 |
| Body S | 12 / 16 | 400 | 0.1px | 95 | 12 |
| Label L | 14 / 20 | 500 | 0 | 95 | 14 |
| Label M | 12 / 16 | 500 | 0.1px | 95 | 12 |
| Label S | 11 / 16 | 500 | 0.1px | 95 | 11 |

Two variants Gemini layers on top:

- **Emphasized.** Same sizes, heavier: 500 for display, headline, title L and body, 700 for labels and title M/S.
- **Rounded** (`ROND` 100). Softens the stroke ends. Gemini uses it only for big expressive moments like the greeting, at Display M, Headline L/S, Title L and Body XL, sometimes with weight 460. Keep `ROND` 0 everywhere else.

Chat answers (markdown) use: H1 22px/700, H2 20px/700, H3 and H4 16px/700, paragraph 16px/400, bold inside a paragraph 500.

## How to apply it

Work on files in Your files: the person uploads the project (or the stylesheets and pages to change), you edit a copy
there and save the revised files there. Never edit a project outside Your files. A change inside a connected app goes
through that app's own action, put on Qosha's approval card in the chat and run only after the person presses Allow this time on that exact
action; if the app offers no such action, hand over the CSS and steps for the person to apply.

1. Swap the project's font to Google Sans Flex with the fallback stack above. Code blocks go to Google Sans Code.
2. Map the project's existing text styles onto the nearest rows of the scale. Keep the project's own hierarchy. Don't invent new levels.
3. Use `wdth` 95 for body, labels and small titles, and `wdth` 100 for titles L and up.
4. Use rounded (`ROND` 100) only for one or two hero moments per page.
5. Design apps (Figma and similar): these are steps for the person, unless a connected design app offers the exact
   change as an action (then it goes on Qosha's approval card in the chat as above). Give them the steps: add Google Sans Flex from
   Google Fonts on their own machine, then set Width, Optical size and Rounded in the variable-font controls. Never
   install a font or any software yourself. As a fallback, save the CSS and a static preview page in Your files.
6. Check the result really renders in Google Sans Flex, not a fallback. `document.fonts.check()` is not enough: it
   can return true for a font that does not exist. Instead, in a browser on a page with representative text (a
   heading, body, a label and a code block):
   - after `await document.fonts.ready`, confirm a `FontFace` in `document.fonts` has family `Google Sans Flex` and
     `status === "loaded"` (and `Google Sans Code` for code);
   - confirm the face is actually used on that text: in the browser's developer tools, the element's Fonts panel
     ("Rendered fonts") must name Google Sans Flex. A width comparison with the same text set in the fallback only
     is a hint, not proof: different widths suggest the face is used, but equal widths prove nothing (fonts can
     share widths, especially code fonts).
   Report the result in one of three ways: "renders in Google Sans Flex" (loaded face and the Rendered fonts panel
   names it); "fallback is showing" (the face did not load, or the Rendered fonts panel names another font), with
   why, for example the font request was blocked; or "font use unverified" (the face loaded but the Rendered fonts
   panel could not be checked).

## Not part of this skill

Gemini's colors, spacing and icons. This skill is type only. Don't copy Gemini's logo, sparkle mark or colors onto someone else's brand.