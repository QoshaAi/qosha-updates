---
name: cash-flow-snapshot
description: Use when the owner asks how long cash will last.
version: 1.0.0
author: Qosha
license: Qosha original (owned by Qosha AI LLC)
metadata:
  hermes:
    tags:
    - Finance
    - Cash Flow
    - Forecast
    - Payroll
    related_skills:
    - invoice-chase
    - pay-the-bills
    - close-month
    - plan-payroll
    - spreadsheets
---
# Cash outlook

Answer the owner's cash question first, then show a dated forecast of money in and money out on three paths (likely,
slower, faster), and name the risks in money so the owner can act before a shortfall. Read only: nothing is sent,
paid or changed.

## When to Use
- "Can I make payroll on Friday?"
- "How long does our cash last?"
- "What does cash look like over the next few months?"
- pay-the-bills, plan-payroll or close-month asked for the cash answer.

Not for: a long-range financial model (use 3-statement-model) or collecting what customers owe (use
invoice-chase).

## What it needs
- **Starting cash and the date it was true:** from a connected accounting app or bank balance, otherwise asked. Never
  assumed. A balance older than today also needs the money in and out since that date (step 3).
- **Money in and out:** what customers owe (customer, open amount, due date), bills with due dates, regular costs
  (rent, payroll, subscriptions).
- **Payment history:** when invoices were paid against their due dates; for card or shop sales, the sale date against
  the payout date.
- **Optional:** next payroll date and amount from a payroll app (Gusto); card spend not yet booked from a card or spend
  app.
- **Fallback:** a spreadsheet or CSV of dated income and expense lines uploaded to Your files, or numbers pasted in chat.
- **Settings in Memory**, asked once and used for this run; saved only after showing the exact entry and the owner
  says yes. Qosha defaults the owner can change:
  - forecast length and step: 13 weeks, week by week, with a subtotal at each month end;
  - extra delay for the slower path: 21 days;
  - past payments needed before a payer's own history is used: 4;
  - smallest risk worth listing: list every risk;
  - also currency, country and year end.

## Steps
1. **Answer the question asked.** "Can I make payroll" needs a real starting balance and the payroll date. If nobody
   can give a starting balance, show only the change in cash, label it "starting balance unknown", and give no cash on
   hand or shortfall verdict. When called by pay-the-bills, reach at least past the next payroll and the latest bill
   due date. When called by close-month, learn timing and costs only from the signed-off version of the books it names.
2. **Gather in one pass** from every connected accounting, payments, store, payroll and card app. With two accounting
   apps, the owner names the record and every total comes from that one only. Name each source that failed or was
   missing and what the forecast lacks because of it.
   Then build **one list of dated money in and out**. The same money often shows in two apps: an invoice in the
   accounting app and its card payment in the payments app, a store order and its payout, a card charge and the bill
   it paid. Match these and count each once, keeping the line from the app of record and noting the match. A possible
   match that isn't clear is shown to the owner, not guessed. Done when no amount is counted twice.
3. **Bring the starting balance up to the forecast start (today).** A balance dated today is used as is. An older
   balance is carried forward with the actual receipts and payments booked between its date and today, shown as a
   short bridge (balance, plus in, minus out, cash today). If that activity can't be read or confirmed by the owner,
   label the result "balance from <date>, later activity unknown": show the forecast, but give no cash on hand or
   shortfall verdict.
4. **Money out.**
   - Bills not yet due go on their due dates.
   - A bill already past due and unpaid goes in today, or on a payment date the owner confirms. Mark it as an
     assumption and show its original due date. It never drops out of the forecast.
   - Payroll on its pay dates. Card spend not yet booked is a known outflow; count reimbursements once.
   - Find regular costs: the same supplier billed in each of the last 4 months at a similar amount (Qosha default; the
     owner can change both, kept in Memory). Show the list and use it only once the owner confirms it.
   - Add a regular cost on a date only where nothing already in the list covers it: an open bill from that supplier,
     a payroll run or a card line for the same period means no extra line. Show which ones were skipped and why.
5. **Money in, dated per payer.** A delay is days paid after the due date; a negative delay means paid early.
   - **Payer with enough history** (at least 4 past payments, Qosha default): likely at their median delay, slower at
     their longest, faster at their shortest.
   - **Payer with too little history:** likely at the business-wide median delay; slower at the likely date plus the
     extra delay (Qosha default 21 days); faster at the earlier of the due date and the likely date. Flag "little
     history".
   - **No payment history anywhere:** likely and faster at the due date, slower at the due date plus the extra delay.
     Flag each "no history, timing assumed".
   - Shop sales are dated by payout, not order. If payouts can't be read, ask for the payout schedule and say the
     timing came from the owner.
6. **Fix dates before today.** A receipt whose date falls before today moves to today, flagged overdue with its
   original due date. On the slower path the extra delay then counts from today, so slower is never earlier than
   likely. Check every receipt so faster is on or before likely, and likely on or before slower. Future due dates stay
   as they are.
7. **Build the three paths day by day.** For each path, put every line on its date and keep a running balance for each
   day. Note the cash just before each major payment (payroll, a large bill) and the lowest balance with its date: a
   shortfall before a later receipt must show even if the week ends positive. Then add up into weeks and months:
   total in, total out, running cash at the period end and the period's lowest point. The range is the slower and
   faster running cash, never a percentage of net, so it still works when net is negative. Receipts landing after the
   forecast ends are listed separately, not dropped.
8. **List the risks,** largest money first, each with payer, amount and date: cash below zero before a big payment
   (only with a real starting balance), a large receipt slipping past a key date, little or no history, missing sources.
9. **Offer a repeat run** once, as an Automation on a schedule the owner picks. Set it up only on their yes to the plan
   shown (what, when, where results go). Never say it is scheduled unless it is.

## Where results go
- **Chat:** the direct answer, the sources, the starting balance and its date (with the bridge to today if older),
  likely, slower and faster cash just before each key payment and at the lowest point, then the risks.
- **Your files:** an Excel workbook dated in its name (e.g. cash-outlook-2026-11-03.xlsx) with a day-by-day sheet,
  where every period total traces to its lines, every period appears even when empty (labelled empty), and each risk
  has its amount and date; plus a page (HTML; Word or PDF on request) to read the outlook at a glance.
- Every output ends: "Built from the named sources. Not accounting or financial advice; check with a bookkeeper before
  borrowing or financing decisions." An answer about payroll (for example "Can I make payroll?") also carries: "Not
  legal or tax advice; check with a professional."
- **Approval cards:** none.

## What waits for the approval card
Nothing; this skill only reads. Saving files to Your files needs no approval. A repeat Automation needs the owner's
yes to the plan shown; a Memory setting needs a yes to the exact entry shown.

## When an app isn't connected
- **No accounting app or bank balance:** ask for the starting balance and its date, or an upload of dated lines.
- **No payroll app:** ask for the next payroll date and amount, or take it from the books and mark it "estimated".
- **No payment or store app:** ask for the payout schedule.
- Suggest the kind of app to connect in Connections (QuickBooks, Xero, Zoho Books; Stripe, Square, PayPal, Shopify;
  Gusto). Never ask for passwords or keys in chat.

## Be careful
- Summary totals that disagree with their own rows, or a supplier list that goes negative because credits are netted
  in: total the detail rows and show credits separately.
- A list limited to the biggest customers is not the whole book: take totals from the balance sheet or label them
  "partial".
- Empty fields are unknown, not zero. A date that should already have happened (payment received, payout settled, the
  balance's as-of date) but lies in the future is a data error; treat it as missing.
- Payroll app and books disagree: use the payroll app's date and amount and say so.
- A payer who always pays on the same day gets one date on all three paths.
- Uploaded file with unclear columns: show the header row and confirm what each column means first.
- Amounts carry the currency code; a payout in another currency stays in that currency, never silently converted.

## How to check it worked
- Start 9,000 USD on day 0; invoice of 4,000 USD due day 10 from a payer with past delays of 2, 5, 7, 12 and 20 days;
  payroll 11,000 USD on day 14. Receipt lands day 17 (likely), 30 (slower), 12 (faster); the answer shows a
  2,000 USD shortfall at payroll on likely and slower, none on faster, and names that invoice.
- Same data without a starting balance: "starting balance unknown" and no shortfall claim. A balance dated 10 days ago
  with no readable activity since: the forecast shows, but no shortfall verdict.
- A customer payment that appears in both the accounting app and the payments app is counted once; rent already on an
  open bill gets no extra regular-cost line.
- Start 5,000 USD; payroll of 6,000 USD on day 3; a 4,000 USD receipt on day 5: the week ends positive, but the answer
  shows a 1,000 USD shortfall at payroll on day 3.
- Business-wide median delay of minus 5 days; invoice due day 30 from a payer with 2 past payments: likely and faster
  day 25, slower day 46, flagged "little history".
- No payment history at all: each receipt at its due date on likely and due date plus 21 days on slower, flagged.
- Starting cash 9,000, one unpaid bill of 12,000 due 10 days ago: the bill sits at today as an assumption and a
  3,000 shortfall shows; if the owner says it will be paid on day 20, the shortfall shows from day 20.
- At every period end slower cash is at most likely, which is at most faster, also when net is negative. No Qosha's approval card in the chat item is created and no amount shows a bare currency symbol.
