---
name: report-builder
description: Use when the owner wants the same numbers on repeat.
version: 1.0.0
author: Qosha
license: Qosha original (owned by Qosha AI LLC)
metadata:
  hermes:
    tags:
    - Reporting
    - Finance
    - Sales
    - Metrics
    related_skills:
    - report-pack
    - business-pulse
    - cash-flow-snapshot
    - spreadsheets
---
# Build a repeatable report

Turn a loose description ("track this weekly") into a written report definition, produce the figures with a short
explanation of what moved, and keep the definition so the next run needs no questions. Read only: nothing is sent or
changed in any app.

## When to Use
- "Track average order value by channel every fortnight."
- "Same report as last month."
- "Give me a monthly numbers pack: sales, margin, new customers."
- "Run the order value numbers."

Not for: a cash forecast (use cash-flow-snapshot) or several saved reports delivered together with a health note (use
report-pack).

## What it needs
- **Figures from any connected app:** accounting (QuickBooks, Xero, Zoho Books), payments (Stripe, Square, PayPal),
  store (Shopify, Square), CRM (HubSpot, Zoho). Apps of the same kind count as equals.
- **Fallback:** a CSV or Excel export uploaded to Your files; it gives the full report wherever the columns exist.
- **From Memory:** currency, financial year end, time zone, preferred output form, saved report definitions, and the
  chat summary length (Qosha default: no more than four points; the owner can change it). New or changed settings are
  used for this run; save to Memory only after showing the exact entry and the owner says yes.

## Steps
1. **Look for a saved report first.** Search Memory, then the definitions file in Your files, by name, nickname,
   cadence or main metric. One match: run it with zero questions. Several plausible matches: ask one short question,
   which one. No match: go to step 2.
2. **Write a definition for a new report.** For each metric: its formula and the app it comes from; any grouping (by
   channel, product, location); the baseline (an earlier period, a year ago, a goal, or none); the window each run
   covers; how often it runs.
   - Take what the request already says as given. Ask only real ambiguities, all together in one message, and keep
     each answer as a note.
   - Show the definition once. Apply a correction without asking again.
   - A request mixing unrelated purposes may be split into two reports.
3. **Gather without stalling.** A failing or empty source is recorded and skipped; never retry in a loop, never block
   the run. For a file, map each metric to a column, name each missing column with the metric it costs, and keep the
   mapping.
4. **Make the figures defensible before anyone sees them.** Check each separately:
   - **Comparable periods:** a period in progress is labelled "in progress" and set against the same stretch of its
     baseline. Periods follow the financial year unless told otherwise.
   - **Complete or labelled partial:** every defined group appears; a group with no activity shows 0; a top-N or
     capped list is never shown as a full total.
   - **Counted once:** each sale or payment counts once across apps; state the source for each measure. The books
     win when connected. With two accounting apps, the owner names the record.
   - **Adds up:** group rows reconcile to the total, or the gap is shown and explained.
5. **Write up what moved.** Each key figure with its baseline and currency code; the specific group and amount behind
   any notable change; anything the owner needs to decide; which sources were unavailable this run.
6. **Keep the definition.** Save it with its creation date, cadence and column mapping in the definitions file in Your
   files; save it to Memory only after showing the exact entry and the owner says yes. A later change is a dated
   revision kept beside the original.
7. **Offer a schedule** as an Automation, stating when it runs and where results go. Create it only after the owner's
   explicit yes. Never say it is scheduled unless it is.
8. **Suggest related skills** where useful (report-pack, business-pulse, cash-flow-snapshot), never one the owner
   already turned down.

## Where results go
- **Chat:** a summary no longer than the owner's setting (default four points).
- **Your files:** an Excel workbook (e.g. order-value-2026-11-03.xlsx) where every figure traces to the unaltered
  pulled data, numbers are readable, and each source and pull time is recorded; a report page (HTML unless Memory says
  Word or PDF); the definitions file.
- **Making the files:** the workbook through the spreadsheets skill (or xlsx); a Word or PDF page through the docx or
  pdf skill. First check that each one's tools load (openpyxl for Excel, python-docx for Word, reportlab and pypdf for
  PDF). If one is missing, name it, say that file was not made, and never install anything. Fall back to the HTML
  report page and CSV files labelled "CSV in place of the Excel workbook": the unaltered pulled data and the figures,
  each row keeping its source and pull time, so every figure still traces back.
- Every report page says: "Not financial or tax advice; check with your accountant before relying on it externally."
- **Approval cards:** none.

## What waits for the approval card
Nothing; this skill only reads. Files stay in Your files. Saving to Memory and creating an Automation need the owner's
yes to exactly what was shown.

## When an app isn't connected
- Run with what is connected and list each missing source with the metrics it costs.
- Offer an upload: a CSV or Excel export from the app that holds the numbers.
- Suggest the kind of app to connect in Connections (accounting, payments, store, CRM). Never ask for passwords or keys
  in chat.

## Be careful
- No data for a metric: show "n/a" with the source. Never estimate, hint at a guess, or reuse last period.
- A missing value is unknown, not zero, unless the owner gave zero or the source documents that empty means zero. Mark
  every figure that depends on an unknown "incomplete".
- A summary that disagrees with its own detail rows loses to the rows.
- Very long lists of what customers owe: narrow to the largest or oldest and label "partial", or pull per customer.
- Customer lists mixing customers and "total" rows: remove the total rows before ranking or concentration figures.
- CRM deal values are forecasts; revenue comes from the books. Each figure states its source.
- Workbook tools missing: never call a CSV an Excel file, and never drop the source and pull-time columns.
- No cash in the books: say cash is unavailable; never substitute what customers owe.
- Per-person pay, bank or card numbers never appear in a report.

## How to check it worked
- Define "average order value by sales channel, every fortnight"; the next day "the order value numbers" runs with no
  questions and the same metrics.
- Gross margin by channel from an export with no channel column: the missing column is named with the metric it costs,
  and the overall margin still appears.
- Run on day 18 of a quarter against the prior quarter: the baseline is the prior quarter's first 18 days and the
  current period says "in progress".
- A 2,400 card sale in both the books and the payment app counts once, with its source named.
- One store's blank returns cell shows "unknown" and its return rate is "incomplete"; another store's 0 shows 0.
- Group rows adding to 51,200 against a stated total of 51,950: the 750 gap is shown. A failed source still gives a
  report listing it as unavailable; a changed formula shows the original plus a dated revision.
