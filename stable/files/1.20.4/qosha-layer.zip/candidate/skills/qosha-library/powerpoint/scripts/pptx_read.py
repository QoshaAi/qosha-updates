#!/usr/bin/env python3
"""Read a .pptx file: JSON outline, notes, or export embedded images.

Modes:
  --outline      JSON with per-slide layout, texts, tables, notes,
                 chart data, and image inventory (default mode).
  --notes        JSON list of speaker notes per slide.
  --images DIR   Export every embedded picture to DIR as files.
"""
import argparse
import json
import os
import sys

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.util import Emu


# GUARDFIX3: a path named by an input file (or handed to another program) must stay in the person's Files folder
# ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error."""
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


def iter_shapes(shapes):
    """Yield shapes, descending into groups."""
    for shape in shapes:
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from iter_shapes(shape.shapes)
        else:
            yield shape


def chart_info(chart):
    info = {"type": str(chart.chart_type),
            "categories": [str(c) for c in chart.plots[0].categories],
            "series": []}
    for plot in chart.plots:
        for series in plot.series:
            try:
                name = series.name
            except (AttributeError, KeyError):
                name = None
            info["series"].append({"name": name,
                                   "values": list(series.values)})
    return info


def slide_record(index, slide):
    rec = {"index": index, "layout": slide.slide_layout.name,
           "texts": [], "tables": [], "images": [], "charts": [],
           "notes": None}
    for shape in iter_shapes(slide.shapes):
        if shape.has_text_frame and shape.text_frame.text.strip():
            rec["texts"].append(shape.text_frame.text)
        if shape.has_table:
            rec["tables"].append(
                [[cell.text for cell in row.cells]
                 for row in shape.table.rows])
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
            try:
                img = shape.image
                rec["images"].append({"filename": img.filename,
                                      "ext": img.ext,
                                      "size_bytes": len(img.blob)})
            except (KeyError, ValueError):
                rec["images"].append({"filename": None, "ext": None,
                                      "size_bytes": None,
                                      "note": "linked or unreadable"})
        if shape.has_chart:
            rec["charts"].append(chart_info(shape.chart))
    if slide.has_notes_slide:
        rec["notes"] = slide.notes_slide.notes_text_frame.text
    return rec


def export_images(prs, out_dir):
    os.makedirs(_inside(out_dir, write=True), exist_ok=True)  # GUARDFIX3: the folder itself too
    written = []
    for i, slide in enumerate(prs.slides):
        for j, shape in enumerate(iter_shapes(slide.shapes)):
            if shape.shape_type != MSO_SHAPE_TYPE.PICTURE:
                continue
            try:
                img = shape.image
            except (KeyError, ValueError):
                continue
            # GUARDFIX3: no writing through a link in DIR to a place outside Files
            path = os.path.join(out_dir, f"slide{i}_img{j}.{img.ext}")
            with open(_inside(path, write=True), "wb") as fh:
                fh.write(img.blob)
            written.append(path)
    return written


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(
        description="Read a .pptx: outline/notes as JSON, export images.")
    parser.add_argument("pptx", help="path to the .pptx file")
    parser.add_argument("--outline", action="store_true",
                        help="print full JSON outline (default)")
    parser.add_argument("--notes", action="store_true",
                        help="print speaker notes only")
    parser.add_argument("--images", metavar="DIR",
                        help="export embedded images into DIR")
    args = parser.parse_args(argv)

    prs = Presentation(_inside(args.pptx))  # GUARDFIX3: bare names too

    if args.images:
        written = export_images(prs, args.images)
        print(json.dumps({"ok": True, "exported": written}, indent=2))
        return 0
    if args.notes:
        notes = [slide.notes_slide.notes_text_frame.text
                 if slide.has_notes_slide else None
                 for slide in prs.slides]
        print(json.dumps({"ok": True, "notes": notes},
                         indent=2, ensure_ascii=True))
        return 0

    outline = {
        "ok": True,
        "slide_size_inches": [round(Emu(prs.slide_width).inches, 3),
                              round(Emu(prs.slide_height).inches, 3)],
        "slide_count": len(prs.slides._sldIdLst),
        "layouts_available": [lay.name for lay in prs.slide_layouts],
        "slides": [slide_record(i, s) for i, s in enumerate(prs.slides)],
    }
    print(json.dumps(outline, indent=2, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
