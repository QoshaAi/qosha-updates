#!/usr/bin/env python3
"""Render every slide of a .pptx to per-slide PNG images.

Pipeline: LibreOffice (soffice --headless --convert-to pdf) turns the deck
into a PDF, then poppler (pdftoppm, or pdftocairo as an alternate) splits
the PDF into one PNG per slide.

Output is JSON. When both tools are present:
  {"rendered": true, "files": ["render/slide-1.png", ...]}
When either tool is missing the script still exits 0 and reports:
  {"rendered": false, "missing": ["soffice"], "guidance": "..."}
so callers can degrade gracefully (fall back to pptx_read.py --outline).
"""
import argparse
import glob
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile


# GUARDFIX3: a path named by an input file (or handed to another program) must stay in the person's Files folder
# ($HERMES_HOME/files, or QOSHA_FILES_ROOT; else the working folder) or, reading, this skill's own folder.
def _files_root():
    r = os.environ.get("QOSHA_FILES_ROOT") or (
        os.path.join(os.environ["HERMES_HOME"], "files") if os.environ.get("HERMES_HOME") else "")
    if not r or not os.path.isdir(r):
        r = os.getcwd()
    r = os.path.realpath(r)
    if r == "/":
        sys.exit("refusing: no Files folder (set QOSHA_FILES_ROOT)")
    return r


def _inside(path, write=False, base=None):
    """The real path of `path` (relative to `base`, else the working folder) when it is inside the Files folder (or,
    reading, this skill's folder), after links and `..`; else exit with a clear error."""
    p = os.path.join(base or os.getcwd(), os.path.expanduser(str(path)))
    real = os.path.realpath(p)
    roots = [_files_root()] + ([] if write else [os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))])
    if not any(real == r or real.startswith(r + os.sep) for r in roots):
        sys.exit("refusing: %s is outside your Files folder" % path)
    if os.path.isfile(real) and os.stat(real).st_nlink > 1:   # GUARDFIX3: reads AND writes
        sys.exit("refusing: %s is a hard link" % path)
    return real


# GUARDFIX3: LibreOffice follows links inside a document while it converts or recalculates it (external workbook
# references, WEBSERVICE / INDIRECT / DDE formulas, linked images, OLE objects, ODF xlink:href, HTML <img src>) and
# writes what it read into the output, which the assistant then reads. Such a document could pull a file from outside
# the person's Files folder (e.g. /run/qosha/model/anthropic-api-key) into a recalculated cell or a rendered slide.
# So only a plain Office Open XML package goes to soffice: no links to outside content, no DTDs, no macros or OLE
# binaries, no external-reference formulas. soffice also runs in a fresh profile with link updates and macros off.
_LO_MAIN = {"pptx": "ppt/presentation.xml", "xlsx": "xl/workbook.xml"}
_LO_BAD_NAMES = ("externallink", "connections.xml", "querytable", "vbaproject", "activex", "oleobject",
                 "mimetype", "content.xml", "meta-inf/manifest.xml")
_LO_BAD_FUNCS = re.compile(rb"(?i)(?<![A-Za-z0-9_])(?:_xlfn\.|_xlws\.)?(?:WEBSERVICE|INDIRECT|DDE|DDEAUTO|FILTERXML|"
                           rb"RTD|IMAGE)\s*\(")
_LO_FORMULA = re.compile(rb"<(?:\w+:)?(?:f|formula|formula1|formula2|definedName)\b[^>]*>([^<]*)<")
_LO_MAX_BYTES = 500 * 1024 * 1024


def _lo_refuse(why):
    sys.exit("refusing: %s (LibreOffice would read content from outside your Files folder)" % why)


def _lo_check_package(zf, kind, depth=0):
    total = 0
    names = zf.namelist()
    if depth == 0 and ("[Content_Types].xml" not in names or _LO_MAIN[kind] not in names):
        _lo_refuse("not a plain .%s package" % kind)
    for info in zf.infolist():
        name, low = info.filename, info.filename.lower()
        total += info.file_size
        if total > _LO_MAX_BYTES:
            _lo_refuse("the package is too large when unpacked")
        if any(b in low for b in _LO_BAD_NAMES):
            _lo_refuse("it holds %s (external data, macros or an embedded object)" % name)
        if "/embeddings/" in "/" + low:
            data = zf.read(info)
            if depth >= 2 or not data.startswith(b"PK"):
                _lo_refuse("it holds an embedded object %s" % name)
            import io
            with zipfile.ZipFile(io.BytesIO(data)) as inner:
                _lo_check_package(inner, kind, depth + 1)
            continue
        data = zf.read(info)
        head = data[:512].lstrip()
        xmlish = low.endswith((".xml", ".rels", ".vml", ".svg")) or head.startswith((b"<?xml", b"<svg", b"<"))
        if not xmlish:
            continue                                   # images and other binary parts
        if b"<!DOCTYPE" in data or b"<!ENTITY" in data:
            _lo_refuse("%s declares a DTD or entities" % name)
        if re.search(rb"(?i)file:[/\\]|xlink:href", data):
            _lo_refuse("%s names a local file (file: link)" % name)
        if b"<svg" in data and re.search(rb"(?i)(?:href\s*=\s*[\"']|url\(\s*[\"']?)(?!#|data:)", data):
            _lo_refuse("%s is a picture that links to another file" % name)
        if low.endswith(".rels"):
            for m in re.finditer(rb"<(?:\w+:)?Relationship\b[^>]*>", data):
                rel = m.group(0)
                if re.search(rb"TargetMode\s*=\s*[\"']External[\"']", rel) and not (
                        re.search(rb"Type\s*=\s*[\"'][^\"']*/hyperlink[\"']", rel)
                        and re.search(rb"Target\s*=\s*[\"'](?:https?:|mailto:)", rel, re.I)):
                    _lo_refuse("%s links to outside content" % name)
            continue
        if _LO_BAD_FUNCS.search(data):
            _lo_refuse("%s uses a formula that reads other files or the web" % name)
        for f in _LO_FORMULA.findall(data):
            if b"|" in f or b"#$" in f or b"://" in f:
                _lo_refuse("%s holds an external reference formula" % name)


def _lo_safe_input(path, kind):
    """Refuse a document that would make LibreOffice read outside Files; return its real absolute path."""
    real = _inside(path)
    if not zipfile.is_zipfile(real):
        _lo_refuse("%s is not a .%s package" % (path, kind))
    try:
        with zipfile.ZipFile(real) as zf:
            _lo_check_package(zf, kind)
    except (zipfile.BadZipFile, OSError, RuntimeError) as exc:
        _lo_refuse("%s cannot be checked (%s)" % (path, exc))
    return real


_LO_PROFILE = """<?xml version="1.0" encoding="UTF-8"?>
<oor:items xmlns:oor="http://openoffice.org/2001/registry" xmlns:xs="http://www.w3.org/2001/XMLSchema" \
xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<item oor:path="/org.openoffice.Office.Common/Security/Scripting"><prop oor:name="MacroSecurityLevel" \
oor:op="fuse"><value>3</value></prop></item>
<item oor:path="/org.openoffice.Office.Common/Security/Scripting"><prop oor:name="DisableMacrosExecution" \
oor:op="fuse"><value>true</value></prop></item>
<item oor:path="/org.openoffice.Office.Common/Security/Scripting"><prop oor:name="BlockUntrustedRefererLinks" \
oor:op="fuse"><value>true</value></prop></item>
<item oor:path="/org.openoffice.Office.Calc/Content/Update"><prop oor:name="Link" oor:op="fuse"><value>1</value>\
</prop></item>
<item oor:path="/org.openoffice.Office.Writer/Content/Update"><prop oor:name="Link" oor:op="fuse"><value>0</value>\
</prop></item>
</oor:items>
"""


def _lo_profile_arg(tmp):
    """A fresh LibreOffice profile in `tmp` (macros off, link updates never); the -env argument that selects it."""
    user = os.path.join(tmp, "lo-profile", "user")
    os.makedirs(user, exist_ok=True)
    with open(os.path.join(user, "registrymodifications.xcu"), "w", encoding="utf-8") as fh:
        fh.write(_LO_PROFILE)
    return "-env:UserInstallation=" + pathlib.Path(os.path.join(tmp, "lo-profile")).as_uri()
import zipfile


def find_tools():
    """Return (soffice, splitter, missing) using shutil.which."""
    soffice = shutil.which("soffice")
    splitter = shutil.which("pdftoppm") or shutil.which("pdftocairo")
    missing = []
    if not soffice:
        missing.append("soffice")
    if not splitter:
        missing.append("pdftoppm (or pdftocairo)")
    return soffice, splitter, missing


def render(pptx_path, out_dir, prefix, dpi):
    soffice, splitter, missing = find_tools()
    if missing:
        return {
            "rendered": False, "missing": missing,
            "guidance": "Install LibreOffice (soffice) and poppler-utils "
                        "(pdftoppm/pdftocairo) to render slides. Without "
                        "them, verify decks with pptx_read.py --outline "
                        "instead.",
        }

    pptx_path = _lo_safe_input(pptx_path, "pptx")    # GUARDFIX3: absolute real path, checked content
    if not re.match(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$", prefix):
        raise SystemExit("refusing: --prefix must be a plain file name")
    _inside(out_dir, write=True)
    if out_dir.startswith("-"):                     # never an option to pdftoppm
        out_dir = os.path.join(".", out_dir)
    os.makedirs(out_dir, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        proc = subprocess.run(
            [soffice, _lo_profile_arg(tmp), "--headless", "--convert-to", "pdf",
             "--outdir", tmp, pptx_path],
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=300)
        pdfs = glob.glob(os.path.join(tmp, "*.pdf"))
        if proc.returncode != 0 or not pdfs:
            raise SystemExit(f"soffice PDF conversion failed: {proc.stderr}")
        pdf = pdfs[0]
        out_prefix = os.path.join(out_dir, prefix)
        proc = subprocess.run(
            [splitter, "-png", "-r", str(dpi), pdf, out_prefix],
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=300)
        if proc.returncode != 0:
            raise SystemExit(f"{os.path.basename(splitter)} failed: "
                             f"{proc.stderr}")

    files = sorted(glob.glob(out_prefix + "*.png"))
    return {"rendered": True, "files": files}


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(
        description="Render each slide of a .pptx to a PNG via "
                    "soffice + pdftoppm/pdftocairo.",
        epilog=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("pptx", help="path to the .pptx file")
    parser.add_argument("--outdir", default="render",
                        help="directory for PNGs (default: ./render)")
    parser.add_argument("--prefix", default="slide",
                        help="PNG filename prefix (default: slide)")
    parser.add_argument("--dpi", type=int, default=100,
                        help="render resolution (default: 100)")
    args = parser.parse_args(argv)

    result = render(args.pptx, args.outdir, args.prefix, args.dpi)
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
