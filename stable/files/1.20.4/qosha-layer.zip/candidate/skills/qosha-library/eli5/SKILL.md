---
name: eli5
description: Use to explain any idea in plain words at a chosen depth.
version: 1.0.0
author: Qosha
license: Qosha original (owned by Qosha AI LLC)
---
# ELI5

**When to use:** Explain a concept in plain language at a chosen depth level. Use when the user says "ELI5", "explain like I'm five", "dumb it down", "in plain English", "no jargon", "simpler", "what does this actually mean", "explain this for a non-technical audience", or asks for a version they could hand to a stakeholder, a kid, or someone outside the field. Also use when drafting explainer copy, onboarding docs, or narration that has to land with a general audience.

Explain the thing so the reader can restate it correctly in one sentence. Simplify the language, never the truth.

## Pick a level

Default to **L2** unless the user names one or the audience makes another obvious.

- **L1 — Kid.** Concrete objects and actions only. No abstractions, no numbers over 10. ~100 words.
- **L2 — Plain (default).** Smart adult, zero domain jargon, one analogy. ~150 words.
- **L3 — Bridge.** Reader is expert in an adjacent field. Map the new concept onto what they already know, and name where the mapping breaks. Length as needed.

## Steps

1. **Answer first.** One sentence, no preamble, no restating the question, no "great question."
2. **One analogy, maximum.** Drawn from ordinary physical experience. If the analogy needs its own explanation, cut it and go literal.
3. **Say what it is not** — but only if a common misconception actually exists. Otherwise skip.
4. **Name the jargon last.** Close with "the term for this is X" so the reader can search it later. Never open with the term.
5. **Stop.** No summary paragraph, no "in conclusion," no offer to go deeper unless there is a real next level worth naming.

## Rules

- Banned words: "basically", "essentially", "simply", "just", "at its core". They announce simplification instead of doing it.
- No bullet lists unless the thing is genuinely sequential or genuinely a set. Explanations are prose.
- If the simple version is false rather than incomplete, flag it in one clause: "that's the useful lie; the real version is …". Never ship a wrong model silently.
- No AI-101 framing, no "think of it like a helpful assistant."
- Match the user's language, including pt-BR. Analogies get localized, not translated.
- Don't lower the register of the *reader* — plain is not condescending. L1 is for actual children or when explicitly requested.

## Verification

Before sending, check:

- Could someone outside the field repeat the core idea in one sentence after reading it once?
- Is there any term left that would send them to a search engine mid-read?
- Does any analogy need its own analogy?
- Is the first sentence the answer, or throat-clearing?

If any check fails, rewrite rather than append.
