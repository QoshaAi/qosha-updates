"""Starts Qosha for this person (Windows: at sign-in from the per-user Run key; Mac: from a LaunchAgent).
    <engine python> -I launcher.py --root <Qosha folder> [--port 9219] [--open] [--once]
Keeps Qosha's dashboard running on 127.0.0.1:<port> (restarts it if it stops), logs in <root>/logs. If Qosha already
answers on the port, it does nothing (one copy per person). --open: also opens the Qosha app (or the browser).
--once: start it and return (no watching), for scripts."""
import argparse
import os
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

WIN = os.name == 'nt'


def up(port):
    try:
        with urllib.request.urlopen('http://127.0.0.1:%d/api/status' % port, timeout=3) as r:
            return r.status == 200
    except Exception:
        return False


def port_busy(port):
    s = socket.socket()
    try:
        s.settimeout(1)
        return s.connect_ex(('127.0.0.1', port)) == 0
    finally:
        s.close()


def env_for(root, port):
    home = root / 'home'
    e = {k: v for k, v in os.environ.items() if not k.upper().startswith(('PYTHON', 'HERMES_', 'PIP_'))}
    e.update({'HERMES_HOME': str(home), 'HERMES_KANBAN_HOME': str(home), 'HERMES_DESKTOP': '0',
              'HERMES_DASHBOARD_FILES_ROOT': str(home / 'files'), 'QOSHA_ASK_ACCESS': '1', 'QOSHA_LOCAL': '1',
              'PYTHONUTF8': '1', 'PYTHONIOENCODING': 'utf-8'})
    return e


def start(root, port, py):
    logs = root / 'logs'
    logs.mkdir(exist_ok=True)
    out = open(logs / 'dashboard.log', 'ab')
    out.write(('\n=== start %s ===\n' % time.strftime('%Y-%m-%d %H:%M:%S')).encode())
    out.flush()
    kw = {'creationflags': 0x08000000} if WIN else {'start_new_session': True}
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import engine_exec          # the engine's own start command, run with its Python directly
    p = subprocess.Popen(engine_exec.command(root, ['dashboard', '--host', '127.0.0.1', '--port', str(port),
                                                    '--skip-build', '--isolated', '--no-open']),
                         cwd=str(root / 'home'), env=env_for(root, port), stdout=out, stderr=subprocess.STDOUT,
                         stdin=subprocess.DEVNULL, **kw)
    (root / 'run').mkdir(exist_ok=True)
    (root / 'run' / 'dashboard.pid').write_text(str(p.pid))
    return p


def open_app(port, root, apps=None):
    url = 'http://127.0.0.1:%d/' % port
    # the app's own profile folder inside Qosha's: its window settings stay with this install, and it never meets
    # another copy of the app (Qosha Setup) that may be open
    args = ['--qosha-home=' + url, '--qosha-profile=' + str(root / 'app-profile')]
    if WIN:
        app = Path(os.environ.get('LOCALAPPDATA', '')) / 'Programs' / 'Qosha' / 'Qosha.exe'
        if app.is_file():
            subprocess.Popen([str(app)] + args, creationflags=0x00000008)   # DETACHED_PROCESS
        else:
            os.startfile(url)
    else:
        app = next((p for p in ([Path(apps) / 'Qosha.app'] if apps else [Path.home() / 'Applications' / 'Qosha.app', Path('/Applications/Qosha.app')])
                    if p.exists()), None)
        subprocess.Popen(['open', '-n', str(app), '--args'] + args if app else ['open', url])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--port', type=int, default=9219)
    ap.add_argument('--open', action='store_true')
    ap.add_argument('--once', action='store_true')
    ap.add_argument('--apps', help='Mac: the folder holding Qosha.app (default ~/Applications, then /Applications)')
    a = ap.parse_args()
    root = Path(a.root).resolve()
    py = Path(sys.executable)
    if WIN and py.name.lower() == 'pythonw.exe':
        py = py.with_name('python.exe')
    if up(a.port) or port_busy(a.port):
        if a.open:
            open_app(a.port, root, a.apps)
        return 0
    p = start(root, a.port, py)
    for _ in range(240):
        if up(a.port):
            break
        if p.poll() is not None:
            break
        time.sleep(0.5)
    if a.open:
        open_app(a.port, root, a.apps)
    if a.once:
        return 0 if up(a.port) else 1
    (root / 'run' / 'launcher.pid').write_text(str(os.getpid()))
    quick = 0
    while True:
        t0 = time.time()
        p.wait()
        quick = quick + 1 if time.time() - t0 < 60 else 0
        if quick >= 5:
            return 1                       # stops crashing in a loop; the log says why
        time.sleep(10)
        if up(a.port) or port_busy(a.port):
            return 0
        p = start(root, a.port, py)


if __name__ == '__main__':
    raise SystemExit(main())
