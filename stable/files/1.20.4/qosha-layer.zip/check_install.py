"""Checks an installed per-user Qosha through the engine's own pre_tool_call path (the plugin as the engine loads it,
the startup barrier, the approval guard and ask-for-access). Run with the engine's Python and Qosha's HERMES_HOME:
    <engine python> -I check_install.py --home <home> --outside <a folder outside Qosha> [--grant]
Prints one line per check: PASS/FAIL, what was expected, what came back. Exit 0 only if all pass.
--grant: also records an "Always allow" for the outside folder (as the person's answer would) to check it covers a
subfolder but not a sibling; the grant is removed again at the end (session only: it is not saved to config)."""
import argparse, json, os, sys
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('--home', required=True)
ap.add_argument('--outside', required=True)
a = ap.parse_args()
home = Path(a.home)
os.environ['HERMES_HOME'] = str(home)
os.environ['QOSHA_ASK_ACCESS'] = '1'
os.environ['HERMES_DASHBOARD_FILES_ROOT'] = str(home / 'files')
out = Path(a.outside)
(out / 'sub').mkdir(parents=True, exist_ok=True)
(out / 'note.txt').write_text('outside note\n')
(out / 'sub' / 'deep.txt').write_text('deep\n')
sib = out.parent / (out.name + '-sibling')
sib.mkdir(exist_ok=True)
(sib / 'x.txt').write_text('x\n')
(home / 'files' / 'mine.txt').write_text('mine\n')

from hermes_cli import plugins as P
P.discover_plugins()
from tools import approval
results = []


def d(tool, args):
    r = P._get_pre_tool_call_directive_details(tool, args, session_id='check', task_id='check')
    return {'action': r.action, 'rule_key': r.rule_key, 'message': (r.message or '')[:160]}


def check(name, tool, args, want_action, rule_prefix=None, msg_has=None):
    r = d(tool, args)
    ok = r['action'] == want_action and (rule_prefix is None or (r['rule_key'] or '').startswith(rule_prefix)) and \
        (msg_has is None or msg_has in r['message'])
    results.append(ok)
    print('%s %-34s want=%s%s got=%s' % ('PASS' if ok else 'FAIL', name, want_action,
                                         (' ' + rule_prefix) if rule_prefix else '', json.dumps(r)))
    return r


barrier = getattr(P._get_pre_tool_call_directive_details, '__qosha_barrier__', False)
results.append(bool(barrier))
print('%s startup barrier active             %s' % ('PASS' if barrier else 'FAIL', barrier))
check('F7a read inside Your files', 'read_file', {'path': str(home / 'files' / 'mine.txt')}, None)
check('F7a relative read (Your files)', 'read_file', {'path': 'mine.txt'}, None)
r = check('F7b read outside -> ask', 'read_file', {'path': str(out / 'note.txt')}, 'approve', 'folder-read:')
sk = approval.get_current_session_key()
approval.approve_session(sk, 'plugin_rule:' + r['rule_key'])
check('F7c same folder after grant', 'read_file', {'path': str(out / 'note.txt')}, None)
check('F7c subfolder after grant', 'read_file', {'path': str(out / 'sub' / 'deep.txt')}, None)
check('F7c sibling still asks (control)', 'read_file', {'path': str(sib / 'x.txt')}, 'approve', 'folder-read:')
check('F7d write outside -> ask', 'write_file', {'path': str(out / 'new.txt'), 'content': 'x'}, 'approve', 'folder-write:')
check('F7d write in Your files', 'write_file', {'path': str(home / 'files' / 'new.txt'), 'content': 'x'}, None)
check('F7e command -> ask', 'terminal', {'command': 'dir C:\\'}, 'approve', 'terminal:')
check('F7e delete command -> ask', 'terminal', {'command': 'del C:\\QoshaTest\\fast\\x.txt'}, 'approve', 'terminal:')
check('F7e code -> ask', 'execute_code', {'code': 'print(1)'}, 'approve', 'execute_code:')
check('F7f own .env blocked', 'read_file', {'path': str(home / '.env')}, 'block')
check('F7f config.yaml blocked', 'read_file', {'path': str(home / 'config.yaml')}, 'block')
check('F7f guard code write blocked', 'write_file', {'path': str(home / 'plugins' / 'qosha' / '__init__.py'),
                                                      'content': ''}, 'block')
check('F7f command naming .env blocked', 'terminal', {'command': 'type %s' % (home / '.env')}, 'block')
check('F6 direct send_message refused', 'send_message', {'action': 'send', 'target': 'someone@example.com',
                                                         'message': 'hello'}, 'block', None, None)
gapi = (home / 'skills' / 'productivity' / 'google-workspace' / 'scripts' / 'google_api.py').as_posix()
print('INFO google skill script present: %s' % os.path.exists(gapi))
check('F6 Gmail send -> Decision card', 'terminal',
      {'command': 'python %s gmail send --to someone@example.com --subject Hello --body "Hi there"' % gapi},
      'block', None, 'Held for approval')
try:
    import sqlite3
    db = home / 'qosha' / 'decisions.sqlite'
    n = sqlite3.connect(str(db)).execute("select count(*) from decisions").fetchone()[0] if db.exists() else 0
    print('INFO decisions recorded in %s: %s' % (db, n))
except Exception as exc:
    print('INFO decisions table not read: %s' % exc)
approval.clear_session(sk)
print('ALL PASS' if all(results) else 'SOME FAILED (%d of %d)' % (results.count(False), len(results)))
raise SystemExit(0 if all(results) else 1)
