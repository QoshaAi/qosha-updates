"""Point a Qosha home's own notes at THIS home instead of the old Mac lab's home (Ren, 17 Nov 2026).

Why: a Qosha home imported from a Mac lab (~/QoshaLab/home) keeps the lab's memories, skills and notes, and they name
the lab's folders. Qosha reads its memory in every chat, so on Ren's Mac it first reached for
/Users/Ren/QoshaLab/home/skills/productivity/google-workspace/scripts/google_api.py (named in memories/MEMORY.md)
instead of the same script in its own home. This rewrites "<lab home>/<rest>" to "<this home>/<rest>" in Qosha's
text notes; nothing else.

  python3 fix_lab_paths.py --home "<Qosha home>"            # dry run (default): lists files and counts, changes nothing
  python3 fix_lab_paths.py --home "<Qosha home>" --apply    # changes them; each changed file is backed up first
  options: --lab <old lab home> (repeatable; default: the one in <home>/.qosha-imported-from, and ~/QoshaLab/home)

What it looks at: SOUL.md, USER.md and the folders memories/, skills/, cron/, scripts/, hooks/ of the Qosha home: text
files only (up to 2 MB, no binary), never a file whose name looks like a secret (.env, auth, token, secret, credential,
key, .pem), never a link, never anything outside the home. It prints file names and counts only, never contents.
Rules:
  - "<lab home>" followed by "/" (or alone) becomes this home, in any of these spellings: /Users/<n>/QoshaLab/home,
    ~/QoshaLab/home, $HOME/QoshaLab/home, ${HOME}/QoshaLab/home.
  - In a code file (not .md/.txt/.json/memory), when this home's path has a space and the old path stood WITHOUT quotes,
    the change could break that line: it is left and counted as "left (needs quoting)".
  - Other mentions of "QoshaLab" (for example "the lab is the backup") are left and counted.
  - The lab itself is never read or changed; a --home inside a lab home is refused.
Backups: <home>/backups/fix-lab-paths-<date-time>/<same relative path>. Memory files are changed under the engine's own
lock file (<file>.lock), so a chat writing its memory at that moment is not mixed up. Running it twice changes nothing
the second time. Mac and Windows alike (the lab only existed on Macs; a Windows home simply has nothing to change).
"""
import argparse
import os
import re
import shutil
import sys
import time
from pathlib import Path

DIRS = ("memories", "skills", "cron", "scripts", "hooks")
FILES = ("SOUL.md", "USER.md")
PROSE = {".md", ".txt", ".json", ".jsonl", ""}
SECRET = re.compile(r"(^\.env|auth|token|secret|credential|\.key$|\.pem$|\.p12$|password|\.lock$)", re.I)
SKIP_DIRS = {"__pycache__", ".git", "node_modules", ".venv", "venv"}
MAX = 2 * 1024 * 1024


def lab_homes(home: Path, extra: list) -> list:
    out = [str(Path(x).expanduser()) for x in extra]
    mark = home / ".qosha-imported-from"
    if not extra and mark.is_file():
        t = mark.read_text(encoding="utf-8", errors="replace").strip()
        t = re.sub(r"\s+\d{4}-\d{2}-\d{2} \d{2}:\d{2}$", "", t)     # the installer writes "<lab>/home <date> <time>"
        if t:
            out.append(t)
    if not extra:
        out.append(str(Path.home() / "QoshaLab" / "home"))
    seen, uniq = set(), []
    for x in out:
        x = x.rstrip("/\\")
        if x and x not in seen:
            seen.add(x)
            uniq.append(x)
    return uniq


def spellings(lab: str) -> list:
    """Every way the lab home is written in notes: absolute, and ~ / $HOME / ${HOME} when it is under the home folder."""
    s = {lab}
    try:
        s.add(os.path.realpath(lab))
    except OSError:
        pass
    hm = str(Path.home())
    for x in list(s):
        if x.startswith(hm + "/"):
            rest = x[len(hm):]
            s.update({"~" + rest, "$HOME" + rest, "${HOME}" + rest})
    return sorted(s, key=len, reverse=True)


def candidates(home: Path):
    for name in FILES:
        p = home / name
        if p.is_file() and not p.is_symlink():
            yield p
    for d in DIRS:
        root = home / d
        if not root.is_dir() or root.is_symlink():
            continue
        for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
            dirnames[:] = [x for x in dirnames if x not in SKIP_DIRS and not os.path.islink(os.path.join(dirpath, x))]
            for fn in filenames:
                p = Path(dirpath) / fn
                if not p.is_symlink():
                    yield p


def readable_text(p: Path):
    if SECRET.search(p.name):
        return None
    try:
        if p.stat().st_size > MAX:
            return None
        b = p.read_bytes()
    except OSError:
        return None
    if b"\x00" in b:
        return None
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        return None


def rewrite(text: str, labs: list, new_home: str, prose: bool):
    """(new text, changed, left needing quotes)"""
    changed = left = 0
    space = bool(re.search(r"\s", new_home))
    pat = re.compile(r"(?<![\w./-])(%s)(?=$|[/\\\s\"'`)\],;:])((?:[/\\][^\s\"'`)\],;]*)?)" % "|".join(re.escape(x) for x in labs))

    def sub(m):
        nonlocal changed, left
        before = text[m.start() - 1] if m.start() > 0 else ""
        if space and not prose and before not in ("'", '"'):
            left += 1
            return m.group(0)
        tail = m.group(2)
        if os.sep != "/":
            tail = tail.replace("/", os.sep)
        changed += 1
        return new_home + tail
    return pat.sub(sub, text), changed, left


class memlock:
    """The engine's memory lock (<file>.lock), held while a memory file is replaced."""

    def __init__(self, path: Path):
        self.path = path.with_suffix(path.suffix + ".lock")
        self.fd = None

    def __enter__(self):
        try:
            self.fd = os.open(self.path, os.O_RDWR | os.O_CREAT, 0o600)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.fd, msvcrt.LK_LOCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fd, fcntl.LOCK_EX)
        except OSError:
            self.fd = None
        return self

    def __exit__(self, *exc):
        if self.fd is not None:
            try:
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(self.fd, msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self.fd, fcntl.LOCK_UN)
            finally:
                os.close(self.fd)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--home", required=True, help="the Qosha home to fix")
    ap.add_argument("--lab", action="append", default=[], help="an old lab home whose paths are rewritten (repeatable)")
    ap.add_argument("--apply", action="store_true", help="change the files (default: dry run, list only)")
    a = ap.parse_args(argv)
    home = Path(a.home).expanduser().resolve()
    if not (home / "config.yaml").is_file() and not (home / "memories").is_dir():
        print("! not a Qosha home: %s" % home)
        return 2
    labs = lab_homes(home, a.lab)
    for lab in labs:
        lr = os.path.realpath(lab)
        hr = str(home)
        if hr == lr or hr.startswith(lr.rstrip(os.sep) + os.sep):
            print("! refused: %s is inside the old lab home; the lab is the backup and is never changed" % home)
            return 2
    spells = sorted({s for lab in labs for s in spellings(lab)}, key=len, reverse=True)
    new_home = str(home)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup_root = home / "backups" / ("fix-lab-paths-" + stamp)
    total_files = total_changes = total_left = 0
    other = []
    print("%s: Qosha home %s; old lab home(s): %s" % ("CHANGING" if a.apply else "DRY RUN (nothing is changed)", home, ", ".join(labs)))
    for p in sorted(candidates(home)):
        text = readable_text(p)
        if text is None or "QoshaLab" not in text and not any(s in text for s in spells):
            continue
        rel = p.relative_to(home)
        prose = p.suffix.lower() in PROSE or rel.parts[0] == "memories"
        new, n, left = rewrite(text, spells, new_home, prose)
        rest = max(0, new.count("QoshaLab") - left)     # mentions that are not lab-home paths at all
        if n == 0:
            if rest or left:
                other.append((str(rel), rest, left))
            continue
        total_files += 1
        total_changes += n
        total_left += left
        print("  %s %s: %d lab path%s -> this home%s%s" % ("changed" if a.apply else "would change", rel, n, "" if n == 1 else "s",
                                                       ("; %d lab path%s left (needs quoting)" % (left, "" if left == 1 else "s")) if left else "",
                                                       ("; %d other mention%s of QoshaLab left as they are" % (rest, "" if rest == 1 else "s")) if rest else ""))
        if a.apply:
            dst = backup_root / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dst)
            mode = p.stat().st_mode & 0o7777
            tmp = p.with_name(p.name + ".fixlab-tmp%d" % os.getpid())
            lock = memlock(p) if rel.parts[0] == "memories" else None
            if lock:
                lock.__enter__()
            try:
                if lock and p.read_text(encoding="utf-8") != text:      # a chat wrote to it meanwhile: take that version
                    new, n, left = rewrite(p.read_text(encoding="utf-8"), spells, new_home, prose)
                    shutil.copy2(p, dst)
                with open(tmp, "w", encoding="utf-8", newline="") as fh:
                    fh.write(new)
                os.chmod(tmp, mode)
                os.replace(tmp, p)
            finally:
                if lock:
                    lock.__exit__(None, None, None)
    for rel, rest, left in other:
        total_left += left
        bits = (["%d lab path%s left (needs quoting)" % (left, "" if left == 1 else "s")] if left else []) + \
               (["%d other mention%s of QoshaLab" % (rest, "" if rest == 1 else "s")] if rest else [])
        print("  left as is %s: %s" % (rel, "; ".join(bits)))
    if a.apply:
        print("DONE: %d file%s changed, %d path%s rewritten%s" % (total_files, "" if total_files == 1 else "s", total_changes,
              "" if total_changes == 1 else "s", ("; backups in %s" % backup_root) if total_files else ""))
    else:
        print("DRY RUN: %d file%s would change, %d path%s would be rewritten (run again with --apply)" % (
            total_files, "" if total_files == 1 else "s", total_changes, "" if total_changes == 1 else "s"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
