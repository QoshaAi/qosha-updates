"""Carry the sign-ins made in another Qosha home ON THE SAME COMPUTER into this one (Ren, 17 Nov: "Carry them over").
    <engine environment python> -I import_signins.py --from <other home> --home <this home>
Copies ONLY sign-in state, with this-user-only permissions, and prints file NAMES, never contents:
  auth.json                               the engine's AI sign-ins (Claude, ChatGPT)
  google_token.json                       Google sign-in used by Qosha's Google connection
  google_client_secret.json               Qosha's Google app file
  google_workspace_mcp/credentials/*      Google sign-in used by the Workspace connector
  qosha/gemini_cli.json                   the marker that Gemini's own tool is signed in
  .env                                    only the settings (NAME=value lines) this home does not have yet
  config.yaml                             the main-model choice (the `model` section) and the "Always allow" answers
                                          (command_allowlist entries are added to the ones already here)
Nothing else is read or copied (no chats, files, memories). A file that is missing in the other home is skipped.
Run it while this Qosha is stopped (the installer does)."""
import argparse
import os
import shutil
import stat
import sys
from pathlib import Path

FILES = ('auth.json', 'google_token.json', 'google_client_secret.json', 'qosha/gemini_cli.json')
DIRS = ('google_workspace_mcp/credentials',)


def private(p: Path):
    try:
        os.chmod(p, stat.S_IRWXU if p.is_dir() else (stat.S_IRUSR | stat.S_IWUSR))
    except OSError:
        pass


def copy_file(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name('.' + dst.name + '.signin-tmp')
    shutil.copyfile(src, tmp)
    private(tmp)
    os.replace(tmp, dst)


def env_names(text):
    out = {}
    for line in text.splitlines():
        s = line.strip()
        if s and not s.startswith('#') and '=' in s:
            k, v = s.split('=', 1)
            out[k.replace('export ', '').strip()] = v.strip()
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--from', dest='src', required=True)
    ap.add_argument('--home', required=True)
    a = ap.parse_args()
    src, home = Path(a.src).resolve(), Path(a.home).resolve()
    if not src.is_dir() or not home.is_dir() or src == home:
        raise SystemExit('FAILED: need two different existing Qosha homes')
    done = []
    for rel in FILES:
        if (src / rel).is_file():
            copy_file(src / rel, home / rel)
            done.append(rel)
    for rel in DIRS:
        if (src / rel).is_dir():
            n = 0
            for f in sorted((src / rel).rglob('*')):
                if f.is_file():
                    copy_file(f, home / rel / f.relative_to(src / rel))
                    n += 1
            for d in [home / rel] + [p for p in (home / rel).rglob('*') if p.is_dir()]:
                private(d)
            private((home / rel).parent)
            done.append('%s/ (%d files)' % (rel, n))
    # .env: only names this home does not have (or has empty)
    se, de = src / '.env', home / '.env'
    if se.is_file():
        have = env_names(de.read_text(encoding='utf-8', errors='replace')) if de.is_file() else {}
        add = [(k, v) for k, v in env_names(se.read_text(encoding='utf-8', errors='replace')).items() if v and not have.get(k)]
        if add:
            with open(de, 'a', encoding='utf-8') as fh:
                fh.write('\n# carried over from the test copy on this computer\n' + ''.join('%s=%s\n' % kv for kv in add))
            private(de)
        done.append('.env (%d settings added, %d already here)' % (len(add), len(have)))
    # config.yaml: main model + "Always allow" answers
    sc, dc = src / 'config.yaml', home / 'config.yaml'
    if sc.is_file() and dc.is_file():
        try:
            from ruamel.yaml import YAML
            y = YAML()
            s = y.load(sc.read_text(encoding='utf-8')) or {}
            d = y.load(dc.read_text(encoding='utf-8')) or {}
            notes = []
            if isinstance(s.get('model'), dict) and s['model']:
                d['model'] = s['model']
                notes.append('main model')
            sa = [x for x in (s.get('command_allowlist') or []) if isinstance(x, str)]
            if sa:
                cur = [x for x in (d.get('command_allowlist') or []) if isinstance(x, str)]
                new = [x for x in sa if x not in cur]
                d['command_allowlist'] = cur + new
                notes.append('%d "Always allow" answers added' % len(new))
            if notes:
                import io
                buf = io.StringIO()
                y.dump(d, buf)
                tmp = dc.with_name('.config.yaml.signin-tmp')
                tmp.write_text(buf.getvalue(), encoding='utf-8')
                os.replace(tmp, dc)
                done.append('config.yaml (%s)' % ', '.join(notes))
        except Exception as exc:
            print('! config.yaml not merged: %s' % type(exc).__name__)
    print('sign-ins carried over: ' + ('; '.join(done) if done else 'nothing found to copy'))


if __name__ == '__main__':
    main()
