"""Runs the engine (or a script inside the engine's environment) the way the engine's own launcher does, but with its
Python directly (so no engine-named program shows in the task list). Standard library only; run with any Python 3.
    python3 engine_exec.py --root ROOT --save            # asks the engine's launcher once, saves run/runtime.json
    python3 engine_exec.py --root ROOT --script FILE [args...]
    python3 engine_exec.py --root ROOT --engine [args...]  # e.g. dashboard --port 9219
"""
import json
import os
import subprocess
import sys
from pathlib import Path

MARK = "runpy.run_module("


def launcher(root: Path) -> Path:
    b = root / 'engine' / '.hermes' / 'bin'
    for n in ('hermes.exe', 'hermes'):
        if (b / n).exists():
            return b / n
    raise SystemExit('the engine launcher is missing under %s' % b)


def save(root: Path) -> dict:
    env = dict(os.environ, HERMES_HOME=str(root / 'home'))
    r = subprocess.run([str(launcher(root)), '--print-runtime-command', 'x'], capture_output=True, text=True, env=env,
                       stdin=subprocess.DEVNULL)
    cmd = json.loads(r.stdout.strip().splitlines()[-1])
    code = cmd[3]
    if cmd[1:3] != ['-I', '-c'] or MARK not in code:
        raise SystemExit('unexpected engine runtime command')
    data = {'python': cmd[0], 'prefix': code.split(MARK, 1)[0], 'engine_code': code}
    (root / 'run').mkdir(exist_ok=True)
    (root / 'run' / 'runtime.json').write_text(json.dumps(data, indent=1))
    return data


def load(root: Path) -> dict:
    f = root / 'run' / 'runtime.json'
    return json.loads(f.read_text()) if f.exists() else save(root)


def env_python(root: Path):
    """The engine environment's own Python (the newest one the engine's package manager made), or None."""
    pat = 'installs/*/environments/*/venv/' + ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    found = sorted((root / 'home').glob(pat), key=lambda p: p.stat().st_mtime)
    return found[-1] if found else None


def command(root: Path, args, script=None):
    d = load(root)
    if script and env_python(root):
        return [str(env_python(root)), '-I', str(script)] + list(args)
    if script:
        code = d['prefix'] + ('import runpy, sys; sys.argv = [%r] + sys.argv[1:]; runpy.run_path(%r, run_name="__main__")'
                              % (str(script), str(script)))
        return [d['python'], '-I', '-c', code] + list(args)
    return [d['python'], '-I', '-c', d['engine_code']] + list(args)


def main():
    a = sys.argv[1:]
    if len(a) < 3 or a[0] != '--root':
        raise SystemExit(__doc__)
    root = Path(a[1]).resolve()
    env = dict(os.environ, HERMES_HOME=str(root / 'home'))
    if a[2] == '--save':
        print(json.dumps(save(root))[:200])
        return 0
    if a[2] == '--script':
        cmd = command(root, a[4:], script=a[3])
    elif a[2] == '--engine':
        cmd = command(root, a[3:])
    else:
        raise SystemExit(__doc__)
    return subprocess.run(cmd, env=env).returncode


if __name__ == '__main__':
    raise SystemExit(main())
