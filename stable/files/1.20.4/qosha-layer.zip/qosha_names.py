"""Qosha's name in the engine's chat error texts (fallback for strings the engine's locale overlay doesn't cover:
tui_gateway/user_messages.py and hermes_cli/auth.py write the engine's name into the text).
Installed beside the engine (a .pth in its environment imports it at every start). When tui_gateway.server is imported
it wraps _event_frame: in the engine's error events, and in the engine's own text for a turn that failed with no answer,
"Hermes"/"hermes" become "Qosha"/"qosha". What the person typed and what the assistant wrote (even a stopped or partial
answer) are never changed. Only active in a Qosha home (HERMES_HOME/plugins/qosha exists)."""
import importlib.abc
import os
import re
import sys

TARGET = "tui_gateway.server"
WAKE = "tools.wake_word"       # 1.20.4: /wake status hints (engine code that names its own command)
_WORD = re.compile(r"\bHermes Agent\b|\bHERMES\b|\bHermes\b|\bhermes\b")
_PATHISH = re.compile(r"[\\/]hermes[\\/]|\.hermes\b")


def _qosha_home() -> bool:
    """A Qosha home, or a named profile inside one (<home>/profiles/<name>: a profile made without cloning has no
    plugin copy of its own, verification 1.20.4 #9)."""
    home = os.environ.get("HERMES_HOME") or ""
    if not home:
        return False
    if os.path.isdir(os.path.join(home, "plugins", "qosha")):
        return True
    parent = os.path.dirname(os.path.normpath(home))
    return os.path.basename(parent) == "profiles" and os.path.isdir(os.path.join(os.path.dirname(parent), "plugins", "qosha"))


def rename(text):
    if not isinstance(text, str) or "ermes" not in text and "ERMES" not in text:
        return text

    def sub(m):
        w = m.group(0)
        return {"Hermes Agent": "Qosha", "HERMES": "QOSHA", "Hermes": "Qosha", "hermes": "qosha"}[w]
    # leave real paths alone (an engine folder name in a path is not a name shown as the product)
    parts = re.split(r"(\S*[\\/]\S*)", text)
    out = "".join(p if (i % 2 and _PATHISH.search(p)) else _WORD.sub(sub, p) for i, p in enumerate(parts))
    # no terminal commands in what the person reads: point to Qosha's Settings instead
    out = re.sub(r"Run `qosha model` to pick one.*?\.env\.?\)", "Open Settings in Qosha and add an AI account or key.", out, flags=re.S)
    out = re.sub(r"Check the model and provider with /model, or run `qosha setup` in a terminal to reconfigure\.?",
                 "Check the AI account and model in Qosha's Settings.", out)
    out = re.sub(r"Run 'qosha auth add [a-z0-9_-]+' to sign in, or set [^\n]*?(?:\.env\.?|(?=\n)|$)", "Open Settings in Qosha and sign in or add a key.", out)
    out = re.sub(r",? or run `qosha [a-z -]+`( in a terminal)?( to [a-z ]+)?", "", out)
    # any other sentence that tells the person to run a terminal command ('qosha model', `qosha doctor`, ...)
    if re.search(r"['`]qosha [a-z][a-z <>_-]*['`]", out):
        out = re.sub(r"[^.!?\n]*['`]qosha [a-z][a-z <>_-]*['`][^.!?\n]*[.!?]?", " Open Settings in Qosha to check the AI account and model.", out, count=1)
        out = re.sub(r"[^.!?\n]*['`]qosha [a-z][a-z <>_-]*['`][^.!?\n]*[.!?]?", " ", out)
    # the engine's chat commands (/retry, /model, ...) mean nothing in Qosha's chat: those sentences are dropped (the same
    # rule as the chat page's own plainProv), and a retry is said plainly instead
    had = bool(re.search(r"(?:^|\s)/retry\b", out))
    out = re.sub(r"[^.!?\n]*(?:^|\s)/(?:retry|model|login|setup|new|reset|logs)\b[^.!?\n]*[.!?]?", " ", out)
    out = re.sub(r"[ \t]{2,}", " ", out).strip()
    out = re.sub(r"[ \t]+\n", "\n", out)
    if had:
        out = out.rstrip() + ("\n" if "\n" in out else " ") + "You can send your message again."
    return re.sub(r"(?<!\.)\.\.(?!\.)", ".", out)


# Only text the ENGINE wrote as an account of a failure is renamed. The person's words and the assistant's answers
# (whole, partial or stopped) are never changed, whatever they say (Ren, 18 Nov 2026: "users should be able to type any
# word they want, including hermes"). Up to 1.19.10 every field of a stopped or failed turn was renamed, so a stopped
# answer that quoted the person ("new hermes versions") came out as "new qosha versions".
ERROR_EVENTS = ("error", "gateway.error", "turn.error")
ERROR_FIELDS = ("message", "detail", "error", "hint", "title")


def _engine_failure_text(payload) -> bool:
    """message.complete's text is the engine's own account of a failed turn, by the engine's own contract: a failed
    turn (status "error") carries `partial: true` exactly when its text is the assistant's kept answer
    (tui_gateway/prompt_turn._complete_turn_payload and session_auto_continue: "Desktop distinguishes retained answer
    text from error copy using this flag"), and always carries an `error` field. The one engine frame without that
    field is the compute host's {"text": "Error: <message>", "status": "error"}. Anything else (Qosha's council report,
    an answer kept with `partial`, a stopped turn) is not the engine's text and is never changed."""
    text = payload.get("text")
    if str(payload.get("status") or "") != "error" or payload.get("partial") or not isinstance(text, str):
        return False
    if not text.strip():
        return False
    return "error" in payload or text.startswith("Error: ")


def _fix(event, payload):
    if not isinstance(payload, dict):
        return payload
    if event in ERROR_EVENTS:
        fields = ERROR_FIELDS
    elif event == "message.complete" and str(payload.get("status") or "") == "error":
        fields = ("error", "text") if _engine_failure_text(payload) else ("error",)
    else:
        return payload
    out = dict(payload)
    for k in fields:
        if isinstance(out.get(k), str):
            out[k] = rename(out[k])
    return out


def patch(mod) -> None:
    orig = getattr(mod, "_event_frame", None)
    if orig is None or getattr(orig, "__qosha_names__", False):
        return

    def _event_frame(event, sid, payload=None):
        if payload is not None and _qosha_home():
            try:
                payload = _fix(event, payload)
            except Exception:
                pass
        return orig(event, sid, payload)

    _event_frame.__qosha_names__ = True
    mod._event_frame = _event_frame


def wake_hint(hint):
    """/wake status's remedy line, written by the engine as its own terminal command ("hermes pm install --extra ...",
    "run `hermes tools`"): Qosha's own step instead. Anything else that names the engine is renamed."""
    if not isinstance(hint, str) or not re.search(r"hermes", hint, re.I):
        return hint
    if re.search(r"\bpm\s+install\b", hint):
        return "The wake word engine isn't installed yet. Ask Qosha to set up the wake word."
    if re.search(r"speech-to-text|text-to-speech", hint):
        return "The wake word needs voice turned on (speech-to-text and text-to-speech). Ask Qosha to turn on voice."
    hint = re.sub(r"hey[_ -]?hermes", "the built-in wake word", hint, flags=re.I)
    return re.sub(r"(?i)hermes", "Qosha", rename(hint))


def wake_label(phrase):
    """How a wake phrase is shown (Ren, 21 Nov ~12:00 MST, card: 'Show "Hey Qosha"'): Qosha's default, written "hey
    kosha" so the detector hears it, is shown with the brand spelling; the engine's built-in phrase is never shown (it
    is listened for as "hey kosha", see patch_wake); a phrase the person typed is shown as they typed it."""
    if isinstance(phrase, str) and phrase.strip().lower() in ("hey kosha", "hey hermes"):
        return "Hey Qosha"
    if isinstance(phrase, str) and re.search(r"hermes", phrase, re.I):
        return "Hey Qosha"                    # the engine's name never shows, whatever was written
    return phrase


def patch_wake(mod) -> None:
    # In a Qosha home the engine's defaults are Qosha's: a config (or a named profile) with no wake phrase listens with
    # the open-vocabulary detector for "hey kosha", the way setup_home writes it, so the shown phrase is the heard one.
    d = getattr(mod, "_DEFAULTS", None)
    if isinstance(d, dict) and _qosha_home() and str(d.get("phrase") or "").lower() == "hey hermes":
        d["phrase"], d["provider"] = "hey kosha", "sherpa"
    # backstop (orchestrator, 21 Nov): a config that still holds the engine's built-in phrase, or "auto", listens for
    # "hey kosha" with the open-vocabulary detector; an explicit detector choice (openwakeword, porcupine) is kept
    gt = getattr(mod, "_get", None)
    if gt is not None and not getattr(gt, "__qosha_names__", False):
        def _get(cfg, key):
            v = gt(cfg, key)
            if _qosha_home():
                if key == "phrase" and isinstance(v, str) and v.strip().lower() == "hey hermes":
                    return "hey kosha"
                if key == "provider" and str(v or "").strip().lower() == "auto":
                    return "sherpa"
            return v
        _get.__qosha_names__ = True
        mod._get = _get
    wp = getattr(mod, "wake_phrase", None)
    if wp is not None and not getattr(wp, "__qosha_names__", False):
        def wake_phrase(cfg=None):
            r = wp(cfg)
            if not _qosha_home():
                return r
            try:        # the detector that really runs is openWakeWord's own model: it hears its built-in word,
                c = cfg if isinstance(cfg, dict) else mod.load_wake_word_config()   # whatever label is written
                oww = c.get("openwakeword") if isinstance(c.get("openwakeword"), dict) else {}
                if mod._provider(c) in ("openwakeword", "oww", "local"):
                    model = str(oww.get("model") or "").strip()
                    stem = os.path.splitext(re.split(r"[\\/]", model)[-1])[0]
                    if not model or model.lower() in getattr(mod, "_BUNDLED_MODEL_ALIASES", ()) or \
                            re.search(r"hermes", stem, re.I):
                        return "the built-in wake word"      # the bundled model, whatever its file is called
                    return stem.replace("_", " ")             # a custom model: its own name
            except Exception:
                pass
            return wake_label(r)
        wake_phrase.__qosha_names__ = True
        mod.wake_phrase = wake_phrase
    orig = getattr(mod, "check_wake_word_requirements", None)
    if orig is None or getattr(orig, "__qosha_names__", False):
        return

    def check_wake_word_requirements(*a, **kw):
        r = orig(*a, **kw)
        if isinstance(r, dict) and _qosha_home():
            try:
                r = dict(r, hint=wake_hint(r.get("hint")), phrase=wake_label(r.get("phrase")))
            except Exception:
                pass
        return r

    check_wake_word_requirements.__qosha_names__ = True
    mod.check_wake_word_requirements = check_wake_word_requirements
    hint = getattr(mod, "silent_audio_hint", None)           # "Grant the Hermes backend microphone access ..."
    if hint is not None and not getattr(hint, "__qosha_names__", False):
        def silent_audio_hint(*a, **kw):
            r = hint(*a, **kw)
            return rename(r) if _qosha_home() else r
        silent_audio_hint.__qosha_names__ = True
        mod.silent_audio_hint = silent_audio_hint


def patch_defaults(mod) -> None:
    """The engine's default settings (merged under every home's and profile's config.yaml): in a Qosha home a wake word
    with no phrase written listens for "hey kosha" with the open-vocabulary detector, as setup_home writes it."""
    ww = (getattr(mod, "DEFAULT_CONFIG", None) or {}).get("wake_word")
    if isinstance(ww, dict) and _qosha_home() and str(ww.get("phrase") or "").lower() == "hey hermes":
        ww["phrase"], ww["provider"] = "hey kosha", "sherpa"


def patch_i18n(facade) -> None:
    """A named profile without its own copy of Qosha's plugin (so the plugin's language pack is not loaded there) reads
    Qosha's English wording from the Qosha home it belongs to (verification 1.20.4 v2 #H9)."""
    # runs once the engine's translator (agent.i18n) is fully loaded: a pack registered while it is still loading
    # would reset a half-made module and fail
    mod = sys.modules.get("agent.i18n_layers")
    if mod is None or getattr(mod, "__qosha_names__", False):
        return
    home = os.environ.get("HERMES_HOME") or ""
    if not home or os.path.isdir(os.path.join(home, "plugins", "qosha")) or not _qosha_home():
        return
    root = os.path.dirname(os.path.dirname(os.path.normpath(home)))
    try:
        from pathlib import Path
        for lang, surface, f in mod.scan_locale_dir(Path(root) / "plugins" / "qosha" / "locales"):
            mod.register_pack(lang, surface, mod.load_locale_source(f), source="qosha:main-home")
        mod.__qosha_names__ = True
    except Exception:
        pass


PATCHES = {TARGET: patch, WAKE: patch_wake, "hermes_cli.config_defaults": patch_defaults, "agent.i18n": patch_i18n}


class _Loader(importlib.abc.Loader):
    def __init__(self, inner):
        self.inner = inner

    def create_module(self, spec):
        return self.inner.create_module(spec)

    def exec_module(self, module):
        self.inner.exec_module(module)
        PATCHES[module.__name__](module)


class _Finder(importlib.abc.MetaPathFinder):
    # two copies of this file may be loaded (environment and plugin): only one acts, the newest (1.20.4 adds the wake
    # and default-settings patches; an older copy already in place, e.g. the environment's from before the update,
    # would not apply them)
    _qosha_names_finder = 2

    def find_spec(self, name, path=None, target=None):
        if name not in PATCHES:
            return None
        for f in sys.meta_path:
            if f is self or getattr(f, "_qosha_names_finder", False) or not hasattr(f, "find_spec"):
                continue
            spec = f.find_spec(name, path, target)
            if spec is not None:
                if spec.loader is not None:
                    spec.loader = _Loader(spec.loader)
                return spec
        return None


for _name, _fn in PATCHES.items():
    if _name in sys.modules:
        _fn(sys.modules[_name])
_older = [f for f in sys.meta_path if getattr(f, "_qosha_names_finder", 0) and getattr(f, "_qosha_names_finder", 0) is not
          _Finder._qosha_names_finder and (getattr(f, "_qosha_names_finder", 0) is True or f._qosha_names_finder < 2)]
for _f in _older:
    sys.meta_path.remove(_f)
if not all(n in sys.modules for n in PATCHES) and not any(getattr(f, "_qosha_names_finder", 0) == 2 for f in sys.meta_path):
    sys.meta_path.insert(0, _Finder())
