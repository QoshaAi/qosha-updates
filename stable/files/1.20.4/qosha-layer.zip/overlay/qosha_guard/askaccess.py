"""Qosha asks the person before it touches anything outside its own folder (per-user installs: Windows, Mac).

Ren, 16 Nov 2026: "make Qosha ask the customer what they want to give access to. Don't make those choices for them."
So for the file tools and for commands/code there is no hard wall here: the engine's own approval prompt is raised
(pre_tool_call -> {"action": "approve"}), and the person answers Allow once / Always allow / Deny in the chat.
  - Qosha's own folder (HERMES_HOME/files, "Your files"): no question.
  - a file or folder elsewhere: asked; "Always allow" covers that folder and everything under it (read and write are
    separate grants; a write grant also covers reading).
  - a command or code: asked; "Always allow" covers exactly that command text, nothing else.
  - Qosha's own code, settings and sign-ins (the rest of HERMES_HOME): asked the same way (Ren, 17 Nov: Qosha keeps
    full access to its own code so it can fix and customize itself when the person asks).
Everything else (sending, paying, deleting via a connector, sharing, the browser) goes to Qosha's approval guard
(hook.pre_tool_call) exactly as before: a Decision card first.
"""
from __future__ import annotations

import hashlib
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger("qosha.askaccess")

READS = {"read_file", "search_files", "vision_analyze", "video_analyze"}
WRITES = {"write_file", "patch"}
CODE = {"terminal", "execute_code"}
PROCESS_QUIET = {"list", "poll", "log", "wait", "status"}
SECRET_NAMES = (".env", "auth.json", "state.db", "connector.key", "google_token.json", "google_client_secret.json",
                "decisions.sqlite")


def enabled() -> bool:
    return os.name == "nt" or os.environ.get("QOSHA_ASK_ACCESS") == "1"


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes"))


def _norm(p: str) -> str:
    return os.path.normcase(os.path.normpath(os.path.abspath(p)))


def _files_root() -> str:
    return _norm(os.environ.get("HERMES_DASHBOARD_FILES_ROOT") or str(_home() / "files"))


def _under(p: str, root: str) -> bool:
    return p == root or p.startswith(root.rstrip("\\/") + os.sep)


def _resolve(path: str) -> str:
    p = os.path.expandvars(os.path.expanduser(str(path).strip().strip('"')))
    if p.lower().startswith("file://"):
        p = p[7:]
    if not os.path.isabs(p):
        p = os.path.join(_files_root(), p)      # the file tools start in Your files (terminal.cwd)
    try:
        p = os.path.realpath(p)
    except (OSError, ValueError):
        pass
    return _norm(p)


def _own_data(p: str) -> bool:
    """Qosha's own data: inside HERMES_HOME but not Your files or the skills (readable)."""
    home = _norm(str(_home()))
    if not _under(p, home):
        return False
    return not (_under(p, _files_root()) or _under(p, _norm(str(_home() / "skills"))))


def _granted(kind: str, folder: str) -> bool:
    """An "Always allow" (or "this session") the person gave for this folder or a folder above it."""
    try:
        from tools import approval
        sk = approval.get_current_session_key()
    except Exception:
        return False
    kinds = ("write",) if kind == "write" else ("read", "write")
    cur = folder
    while True:
        for k in kinds:
            if approval.is_approved(sk, "plugin_rule:folder-%s:%s" % (k, cur)):
                return True
        parent = os.path.dirname(cur)
        if not parent or parent == cur:
            return False
        cur = parent


def _paths(tool: str, args: Dict[str, Any]) -> List[str]:
    if tool == "patch":
        out = [args["path"]] if isinstance(args.get("path"), str) and args.get("path") else []
        text = args.get("patch") or ""
        out += [a or b for a, b in re.findall(r"^\*\*\* (?:Update|Add|Delete) File: (.+?)\s*$|^\*\*\* Move to: (.+?)\s*$",
                                              str(text), re.M)]
        return out
    if tool == "search_files":
        return [args.get("path") or "."]
    if tool in ("vision_analyze", "video_analyze"):
        u = next((args.get(k) for k in ("image_url", "video_url", "url", "image", "path") if args.get(k)), "")
        u = str(u)
        if re.match(r"^(https?|data):", u, re.I):
            return []
        return [u] if u else []
    p = args.get("path")
    return [p] if isinstance(p, str) and p else []


def _ask(message: str, rule_key: str) -> Dict[str, str]:
    return {"action": "approve", "message": message, "rule_key": rule_key}


def _block(reason: str) -> Dict[str, str]:
    return {"action": "block", "message": "Not allowed by Qosha: " + reason}


def _mentions_own_data(text: str) -> bool:
    t = text.lower().replace("/", "\\")
    home = str(_home()).lower().replace("/", "\\")
    files = _files_root().lower().replace("/", "\\")
    skills = str(_home() / "skills").lower().replace("/", "\\")
    if home in t:
        rest = t.replace(files, "").replace(skills, "")
        if home in rest:
            return True
    return any(re.search(r"(^|[\\\s'\"=])" + re.escape(n) + r"($|[\s'\";|&)])", t) for n in SECRET_NAMES)


def decide(tool: str, args: Any) -> Optional[Dict[str, str]]:
    """None: not a file/command tool (Qosha's guard decides). Else allow ({}), ask or block."""
    a = args if isinstance(args, dict) else {}
    if tool in CODE:
        text = str(a.get("command") if tool == "terminal" else a.get("code") or "")
        if _mentions_own_data(text):
            h = hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:16]
            return _ask("This command touches Qosha's own settings, sign-ins or keys: %s" % text[:600], "own-cmd:%s" % h)
        h = hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:16]
        what = "Run this command" if tool == "terminal" else "Run this code"
        shown = text if len(text) <= 600 else text[:600] + " ..."
        return _ask("%s on this computer: %s   (Always allow = this exact %s only)"
                    % (what, shown, "command" if tool == "terminal" else "code"), "%s:%s" % (tool, h))
    if tool == "process":
        act = str(a.get("action") or "").lower()
        if act in PROCESS_QUIET:
            return {}
        h = hashlib.sha256(repr(sorted(a.items())).encode()).hexdigest()[:16]
        return _ask("Act on a running command (%s)" % (act or "unknown"), "process:%s" % h)
    if tool not in READS and tool not in WRITES:
        return None
    kind = "write" if tool in WRITES else "read"
    deleting = tool == "patch" and re.search(r"^\*\*\* Delete File:", str(a.get("patch") or ""), re.M)
    asks = []
    for raw in _paths(tool, a):
        p = _resolve(raw)
        if _own_data(p) and not _granted(kind, os.path.dirname(p)):
            return _ask("Qosha wants to %s its own files (code, settings or sign-ins): %s   (Always allow = this "
                        "folder and everything in it)" % ("read" if kind == "read" else "change", p),
                        "folder-%s:%s" % (kind, os.path.dirname(p)))
        if deleting:
            asks.append(p)
            continue
        if _under(p, _files_root()):
            continue
        folder = p if (kind == "read" and os.path.isdir(p)) else os.path.dirname(p)
        if not _granted(kind, folder):
            asks.append(folder if kind == "read" or not deleting else p)
    if not asks:
        return {}
    if deleting:
        h = hashlib.sha256(("|".join(asks)).encode()).hexdigest()[:16]
        return _ask("Delete these files: %s" % ", ".join(asks), "delete:%s" % h)
    folder = asks[0]
    verb = "read files in" if kind == "read" else "change files in"
    return _ask("Qosha wants to %s %s   (Always allow = this folder and everything in it)" % (verb, folder),
                "folder-%s:%s" % (kind, folder))


def wrap(guard):
    """The pre_tool_call registered in place of the guard on per-user installs: file and command tools ask the person;
    every other tool goes through Qosha's approval guard unchanged."""
    def pre_tool_call(tool_name: str = "", args: Any = None, **kw: Any):
        try:
            d = decide(tool_name or "", args)
        except Exception as exc:                      # can't tell: ask rather than guess
            log.warning("askaccess could not judge %s: %s", tool_name, type(exc).__name__)
            return _ask("Qosha could not tell what %s would touch. Allow it?" % tool_name,
                        "unknown:%s" % hashlib.sha256(repr(args).encode()).hexdigest()[:16])
        if d is None:
            return guard(tool_name=tool_name, args=args, **kw)
        if tool_name in CODE and d.get("action") == "approve":
            # a command that sends an email or changes the calendar through Qosha's Google tools still becomes a
            # Decision card (the approval before sending stays); Qosha's other refusals become the person's question
            try:
                g = guard(tool_name=tool_name, args=args, **kw)
            except Exception:
                g = None
            if isinstance(g, dict) and g.get("action") == "block" and \
                    not str(g.get("message") or "").startswith("Not allowed by Qosha"):
                return g
        if d:
            log.warning("qosha askaccess %s: %s", tool_name, d.get("action"))
        return d or None
    return pre_tool_call
