"""Qosha's nightly backup (MEM1-SAFE, backup only; Ren's card 20 Nov 2026: "Nightly backup only").

Once a local day Qosha asks the engine to make its usual full backup of the person's home
(<home>/backups/qosha-daily-YYYY-MM-DD-HHMMSS.zip; the engine writes it owner-only and keeps the 7 newest). Qosha reads
and writes nothing else: no notes are read, stored or shown, and it keeps no files or locks of its own.

daily_backup() returns a dict and never raises; logs carry fixed words only.
"""
from __future__ import annotations

import datetime as _dt
import logging
import os
import re
import stat
from pathlib import Path

log = logging.getLogger("qosha.memory")

DAILY_PREFIX = "qosha-daily-"
DAILY_KEEP = 7
GOOGLE_SIGN_IN_PREFIXES = ("google_token.tmp.",)
GOOGLE_SIGN_IN = frozenset({"google_token.json", "google_client_secret.json", "google_write_client_secret.json",
                            "google_oauth_pending.json", "google_workspace_mcp", "google_reconnect.json"})
_REPARSE = 0x400                          # FILE_ATTRIBUTE_REPARSE_POINT (symlinks, junctions, mount points)
_DAILY_NAME = re.compile(r"^qosha-daily-(\d{4})-(\d{2})-(\d{2})-(\d{6})\.zip$")


def _is_link(p) -> bool:
    """A symlink, a Windows junction or any reparse point. A missing path is not a link."""
    try:
        st = os.lstat(str(p))
    except FileNotFoundError:
        return False
    except OSError:
        return True
    return stat.S_ISLNK(st.st_mode) or bool(getattr(st, "st_file_attributes", 0) & _REPARSE)


def _local_day(now=None) -> str:
    if isinstance(now, _dt.datetime):
        t = now if now.tzinfo is None else now.astimezone()
    elif isinstance(now, (int, float)) and not isinstance(now, bool) and now >= 0:
        t = _dt.datetime.fromtimestamp(now)
    else:
        t = _dt.datetime.now()
    return t.strftime("%Y-%m-%d")


def _zip_ok(path: Path) -> bool:
    """A real archive: it opens, holds at least one file, no name twice, and every file's checksum is right."""
    try:
        import zipfile
        with zipfile.ZipFile(str(path)) as z:
            names = [i.filename for i in z.infolist()]
            return (len(names) == len(set(names)) and any(not i.is_dir() for i in z.infolist())
                    and z.testzip() is None)
    except Exception:  # noqa: BLE001
        return False


def _made_today(b: Path, days) -> bool:
    """Today's copy exists only when a plain file named for today really opens; a damaged one never stands in."""
    try:
        names = os.listdir(str(b))
    except OSError:
        return False
    for n in names:
        m = _DAILY_NAME.match(n)
        if not m or "%s-%s-%s" % m.groups()[:3] not in days:
            continue
        try:
            st = os.lstat(str(b / n))
        except OSError:
            continue
        if stat.S_ISREG(st.st_mode) and not getattr(st, "st_file_attributes", 0) & _REPARSE and st.st_size > 0 \
                and _zip_ok(b / n):
            return True
    return False


def daily_backup(home, now=None) -> dict:
    """At most one nightly backup per local day, made by the engine's own full-backup code."""
    try:
        if not home:
            return {"ok": False, "status": "unavailable"}
        h = Path(os.path.expanduser(str(home)))
        b = h / "backups"
        if _is_link(h) or _is_link(b):
            return {"ok": False, "status": "refused"}
        if _made_today(b, {_local_day(now), _local_day(None)}):
            return {"ok": True, "status": "exists"}
        try:
            from hermes_cli import backup as eb
            make = getattr(eb, "_create_prefixed_full_backup")
            probe = getattr(eb, "_backup_operation_lock")
            busy_err = getattr(eb, "BackupInProgressError", None)
        except (ImportError, AttributeError):
            return {"ok": False, "status": "unavailable"}
        try:
            with probe(h):                # another backup running now: leave it, try on a later pass
                pass
        except TypeError:
            return {"ok": False, "status": "unavailable"}
        except Exception as exc:  # noqa: BLE001
            if busy_err is not None and isinstance(exc, busy_err):
                return {"ok": False, "status": "busy"}
            raise
        try:
            # the Google sign-in files never go into a backup (1.20.9, CONTRACT-GEXEC)
            ex = getattr(eb, "_EXCLUDED_BACKUP_ROOT_DIRS", None)
            if ex is None:
                return {"ok": False, "status": "unavailable"}
            eb._EXCLUDED_BACKUP_ROOT_DIRS = frozenset(ex) | GOOGLE_SIGN_IN
            pre = getattr(eb, "_EXCLUDED_PREFIXES", None)
            if isinstance(pre, tuple) and not set(GOOGLE_SIGN_IN_PREFIXES) <= set(pre):
                eb._EXCLUDED_PREFIXES = pre + GOOGLE_SIGN_IN_PREFIXES
            out = make(h, DAILY_PREFIX, DAILY_KEEP, "daily", "daily backup")
        except (TypeError, ImportError):
            return {"ok": False, "status": "unavailable"}
        if not out:
            return {"ok": False, "status": "failed"}
        name = Path(out).name
        return {"ok": True, "status": "made", "name": name if _DAILY_NAME.match(name) else "a nightly copy"}
    except Exception:  # noqa: BLE001
        log.warning("Qosha nightly backup not made this time")
        return {"ok": False, "status": "failed"}
