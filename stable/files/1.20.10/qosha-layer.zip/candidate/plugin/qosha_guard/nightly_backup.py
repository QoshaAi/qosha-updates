"""Qosha's nightly backup (MEM1-SAFE, backup only; Ren's card 20 Nov 2026: "Nightly backup only").

Once a local day Qosha asks the engine to make its usual full backup of the person's home
(<home>/backups/qosha-daily-YYYY-MM-DD-HHMMSS.zip; the engine writes it owner-only and keeps the 7 newest). Qosha reads
and writes nothing else: no notes are read, stored or shown, and it keeps no files or locks of its own.

daily_backup() returns a dict and never raises; logs carry fixed words only.
"""
from __future__ import annotations

import datetime as _dt
import logging
import os
import re
import stat
from pathlib import Path

log = logging.getLogger("qosha.memory")

DAILY_PREFIX = "qosha-daily-"
DAILY_KEEP = 7
GOOGLE_SIGN_IN_PREFIXES = ("google_token.tmp.",)
# Every sign-in and credential the engine and Qosha keep (r1210, orchestrator 22 Nov: "Extend the same exclusion to all
# credential files"). Root entries of a home (or of profiles/<name>), credential trees, and outside Your files any file
# whose name says it holds a token or a credential (an Outlook/MSAL cache, a cookie store). After a restore the person
# signs in again (RESTORE-NOTE.txt in each backup says so).
_ROOT_SECRETS = frozenset({"auth.json", "auth.lock", ".env", ".op.env", "mcp-tokens", "vault", "pairing", "webapp",
                           "browser-profile", "browser_profiles", "whatsapp", "whatsapp-media", "honcho.json",
                           "mem0.json", "auth", ".anthropic_oauth.json", "webhook_subscriptions.json", "slack_tokens.json",
                           "feishu_comment_pairing.json", "teams_pipeline_store.json", ".copilot_jwt.json", "npmrc",
                           "chrome-debug", "browser_auth", "proxy"})
_ROOT_COPY = re.compile(r"(?i)^(auth\.json\..+|\.env\.bak.*|\.env\..+)$")
_TREE_SECRETS = (("platforms", "pairing"), ("platforms", "whatsapp", "session"), ("matrix", "store"),
                 ("platforms", "matrix", "store"), ("whatsapp", "session"), ("qosha", "appconn.key"),
                 ("qosha", "egress"))
_SECRET_NAME = re.compile(r"(?i)(^|[_.-])(tokens?|credentials?|secrets?|msal|cookies|login data|keychain|oauth|jwt)"
                          r"([_.-]|$)|\.(key|pem|p12|pfx)$|^\.env(\..*)?$")
RESTORE_NOTE = ("Qosha nightly backup.\n\nSign-ins are not in this backup: no Google, Microsoft, WhatsApp or other app "
                "sign-ins, no keys (.env, auth.json). After you restore it, open Qosha and connect your apps again "
                "(Settings > Connections), and add any keys again.\n")


def _credential(rel) -> bool:
    try:
        parts = tuple(x.casefold() for x in Path(str(rel).replace("\\", "/")).parts)   # Mac and Windows ignore case
    except Exception:
        return True
    if len(parts) >= 3 and parts[0] == "profiles":
        parts = parts[2:]
    if not parts:
        return False
    if parts[0] in _ROOT_SECRETS or parts[0] in GOOGLE_SIGN_IN or parts[0].startswith(GOOGLE_SIGN_IN_PREFIXES):
        return True
    if any(parts[:len(t)] == t for t in _TREE_SECRETS):
        return True
    if len(parts) == 1 and _ROOT_COPY.match(parts[0]):
        return True
    if parts[0] == "files":
        return False                           # the person's own files are theirs, whatever their names
    try:                                       # every store the engine itself counts as a credential (r1210 r2, GPT 8)
        from hermes_cli.profiles import profile_path_is_private
        if profile_path_is_private(parts):
            return True
    except Exception:
        pass
    return bool(_SECRET_NAME.search(parts[-1]))


def _wrap_exclusions(eb) -> bool:
    """The engine's per-file and per-folder exclusion checks also leave out every credential. False when they can't
    be wrapped: then no backup is made (never one with tokens)."""
    should, in_root = getattr(eb, "_should_exclude", None), getattr(eb, "_in_excluded_root_dir", None)
    if not callable(should) or not callable(in_root):
        return False
    if not getattr(should, "__qosha_creds__", False):
        def _should_exclude(rel_path, _o=should):
            return _credential(rel_path) or _o(rel_path)
        _should_exclude.__qosha_creds__ = True
        eb._should_exclude = _should_exclude
    if not getattr(in_root, "__qosha_creds__", False):
        def _in_excluded_root_dir(rel_path, _o=in_root):
            return _credential(rel_path) or _o(rel_path)
        _in_excluded_root_dir.__qosha_creds__ = True
        eb._in_excluded_root_dir = _in_excluded_root_dir
    return True
GOOGLE_SIGN_IN = frozenset({"google_token.json", "google_client_secret.json", "google_write_client_secret.json",
                            "google_oauth_pending.json", "google_workspace_mcp", "google_reconnect.json"})
_REPARSE = 0x400                          # FILE_ATTRIBUTE_REPARSE_POINT (symlinks, junctions, mount points)
_DAILY_NAME = re.compile(r"^qosha-daily-(\d{4})-(\d{2})-(\d{2})-(\d{6})\.zip$")


def _is_link(p) -> bool:
    """A symlink, a Windows junction or any reparse point. A missing path is not a link."""
    try:
        st = os.lstat(str(p))
    except FileNotFoundError:
        return False
    except OSError:
        return True
    return stat.S_ISLNK(st.st_mode) or bool(getattr(st, "st_file_attributes", 0) & _REPARSE)


def _local_day(now=None) -> str:
    if isinstance(now, _dt.datetime):
        t = now if now.tzinfo is None else now.astimezone()
    elif isinstance(now, (int, float)) and not isinstance(now, bool) and now >= 0:
        t = _dt.datetime.fromtimestamp(now)
    else:
        t = _dt.datetime.now()
    return t.strftime("%Y-%m-%d")


def _zip_ok(path: Path) -> bool:
    """A real archive: it opens, holds at least one file, no name twice, and every file's checksum is right."""
    try:
        import zipfile
        with zipfile.ZipFile(str(path)) as z:
            names = [i.filename for i in z.infolist()]
            return (len(names) == len(set(names)) and any(not i.is_dir() for i in z.infolist())
                    and z.testzip() is None)
    except Exception:  # noqa: BLE001
        return False


def _unsafe(path) -> bool:
    """An archive holding any sign-in or credential entry (or one that can't be listed). The connectors session's
    HIGH 11: such a zip is never kept or taken as today's backup."""
    try:
        import zipfile
        with zipfile.ZipFile(str(path)) as z:
            return any(_credential(n.rstrip("/")) for n in z.namelist() if n.rstrip("/"))
    except Exception:  # noqa: BLE001
        return True


_CONFIG_NAME = re.compile(r"^(profiles/[^/]+/)?config\.ya?ml$")


def _scrub(v, path="", parent=""):
    """A copy of a settings value with every key or token typed into it blanked: keys the engine names as secret, and
    every value under an MCP server's env or headers. ${NAME} references stay (r1210 r2, GPT 9)."""
    from hermes_cli.config import _ENV_PLACEHOLDER_RE, _is_secret_config_key
    if isinstance(v, dict):
        out = {}
        for k, x in v.items():
            kp = "%s.%s" % (path, k) if path else str(k)
            secret = parent in ("env", "headers") or (isinstance(k, str) and _is_secret_config_key(kp))
            if secret and not isinstance(x, (dict, list, bool)) and x is not None \
                    and not _ENV_PLACEHOLDER_RE.match(str(x)):
                out[k] = ""
            else:
                out[k] = _scrub(x, kp, str(k).lower())
        return out
    if isinstance(v, list):
        return [_scrub(x, path, parent) for x in v]
    return v


def _scrub_configs(out) -> None:
    """Rewrite the archive with its settings files scrubbed. A settings file that can't be read is left out. Raises on
    any other failure (the caller then keeps no archive)."""
    import zipfile
    import yaml
    src = str(out)
    tmp = src + ".qosha-tmp"
    with zipfile.ZipFile(src) as zi, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zo:
        for info in zi.infolist():
            data = zi.read(info)
            if _CONFIG_NAME.match(info.filename):
                try:
                    data = yaml.safe_dump(_scrub(yaml.safe_load(data.decode("utf-8")) or {}), sort_keys=False,
                                          allow_unicode=True).encode("utf-8")
                except Exception:  # noqa: BLE001
                    continue
            zo.writestr(info, data)
    os.replace(tmp, src)


def _set_aside(path, remove=False) -> None:
    """Out of the daily backups' names: removed when asked, else (or if removal fails) renamed .qosha-unsafe."""
    p = str(path)
    if remove:
        try:
            os.unlink(p)
            return
        except OSError:
            pass
    try:
        os.replace(p, p + ".qosha-unsafe")
    except OSError:
        log.warning("Qosha nightly backup: an unsafe copy could not be set aside")


def _made_today(b: Path, days) -> bool:
    """Today's copy exists only when a plain file named for today really opens; a damaged one never stands in."""
    try:
        names = os.listdir(str(b))
    except OSError:
        return False
    for n in names:
        m = _DAILY_NAME.match(n)
        if not m or "%s-%s-%s" % m.groups()[:3] not in days:
            continue
        try:
            st = os.lstat(str(b / n))
        except OSError:
            continue
        if stat.S_ISREG(st.st_mode) and not getattr(st, "st_file_attributes", 0) & _REPARSE and st.st_size > 0 \
                and _zip_ok(b / n):
            if _unsafe(b / n):            # an older copy with sign-ins in it: set aside, never today's backup
                _set_aside(b / n)
                continue
            return True
    return False


def daily_backup(home, now=None) -> dict:
    """At most one nightly backup per local day, made by the engine's own full-backup code."""
    try:
        if not home:
            return {"ok": False, "status": "unavailable"}
        h = Path(os.path.expanduser(str(home)))
        b = h / "backups"
        if _is_link(h) or _is_link(b):
            return {"ok": False, "status": "refused"}
        if _made_today(b, {_local_day(now), _local_day(None)}):
            return {"ok": True, "status": "exists"}
        try:
            from hermes_cli import backup as eb
            make = getattr(eb, "_create_prefixed_full_backup")
            probe = getattr(eb, "_backup_operation_lock")
            busy_err = getattr(eb, "BackupInProgressError", None)
        except (ImportError, AttributeError):
            return {"ok": False, "status": "unavailable"}
        try:
            with probe(h):                # another backup running now: leave it, try on a later pass
                pass
        except TypeError:
            return {"ok": False, "status": "unavailable"}
        except Exception as exc:  # noqa: BLE001
            if busy_err is not None and isinstance(exc, busy_err):
                return {"ok": False, "status": "busy"}
            raise
        try:
            # the Google sign-in files never go into a backup (1.20.9, CONTRACT-GEXEC)
            ex = getattr(eb, "_EXCLUDED_BACKUP_ROOT_DIRS", None)
            if ex is None or not _wrap_exclusions(eb):
                return {"ok": False, "status": "unavailable"}
            eb._EXCLUDED_BACKUP_ROOT_DIRS = frozenset(ex) | GOOGLE_SIGN_IN
            pre = getattr(eb, "_EXCLUDED_PREFIXES", None)
            if isinstance(pre, tuple) and not set(GOOGLE_SIGN_IN_PREFIXES) <= set(pre):
                eb._EXCLUDED_PREFIXES = pre + GOOGLE_SIGN_IN_PREFIXES
            out = make(h, DAILY_PREFIX, DAILY_KEEP, "daily", "daily backup")
        except (TypeError, ImportError):
            return {"ok": False, "status": "unavailable"}
        if not out:
            return {"ok": False, "status": "failed"}
        try:
            _scrub_configs(out)
        except Exception:  # noqa: BLE001
            _set_aside(out, remove=True)
            try:
                os.unlink(str(out) + ".qosha-tmp")
            except OSError:
                pass
            return {"ok": False, "status": "failed"}
        if _unsafe(out):                  # the walk let a sign-in through: never kept
            _set_aside(out, remove=True)
            return {"ok": False, "status": "failed"}
        try:
            import zipfile
            with zipfile.ZipFile(str(out), "a") as zf:
                if "RESTORE-NOTE.txt" not in zf.namelist():
                    zf.writestr("RESTORE-NOTE.txt", RESTORE_NOTE)
        except Exception:
            pass
        name = Path(out).name
        return {"ok": True, "status": "made", "name": name if _DAILY_NAME.match(name) else "a nightly copy"}
    except Exception:  # noqa: BLE001
        log.warning("Qosha nightly backup not made this time")
        return {"ok": False, "status": "failed"}
