/* "Qosha is using your computer" bar with Stop (cu20, 22 Nov 2026). Loaded once by the dashboard shell (index.js) in the
   top window, on every Qosha page. Every 3 s it reads /api/plugins/qosha/desktop/status:
   * Qosha used the computer in the last 2 minutes (a look, a click, typing): "Qosha is using your computer \u00b7 <app>"
     with Stop. Stop is a plain POST any Qosha page may make; it holds until the person lifts it.
   * Stopped: "Stopped. Qosha won't look at or use your computer until you let it" with "Let Qosha continue" (the Qosha
     app window only: the approval gate refuses it from anywhere else, and the bar then says so).
   * Setup asked for and the Mac still needs a permission: which one, and "Open the permission requests" (again).
   No bar otherwise. Text from the server is set as text, never as HTML. */
(function () {
  'use strict';
  if (window.__qoshaDesktop || window.top !== window) return;
  window.__qoshaDesktop = true;
  var API = '/api/plugins/qosha/desktop/';
  var bar = null, off = false, busy = false, last = '', probe = false;
  function tok() { return String(window['__HERMES_SESSION_TOKEN__'] || ''); }
  function call(path, method) {
    return window.fetch(API + path, {method: method || 'GET', credentials: 'same-origin', cache: 'no-store',
      headers: {'X-Hermes-Session-Token': tok(), 'Content-Type': 'application/json'}});
  }
  function el(tag, css, text) { var e = document.createElement(tag); if (css) e.style.cssText = css; if (text != null) e.textContent = text; return e; }
  var BTN = 'margin-left:12px;padding:6px 14px;border-radius:999px;border:1px solid currentColor;background:transparent;' +
            'color:inherit;font:600 13px/1 inherit;cursor:pointer';
  function ensure() {
    if (bar) return bar;
    bar = el('div', 'position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:2147483000;display:none;' +
             'align-items:center;gap:6px;max-width:min(720px,calc(100vw - 32px));padding:10px 12px 10px 16px;' +
             'border-radius:14px;background:var(--q-forest,#0B3326);color:#fff;box-shadow:0 6px 24px rgba(0,0,0,.22);' +
             'font:500 14px/1.35 "Google Sans Flex","Google Sans","Helvetica Neue",sans-serif');
    bar.id = 'qosha-desktop-bar';
    bar.setAttribute('role', 'status');
    bar.setAttribute('aria-live', 'polite');
    document.body.appendChild(bar);
    return bar;
  }
  function render(st) {
    var b = ensure(), key, msg = '', btn = null, btn2 = null, dot = 'background:var(--q-gold,#B8955A)';
    var act = st.activity || {};
    probe = !!((st.setup && (st.setup.state === 'installing' || st.setup.state === 'done')) || (st.installed && st.platform === 'darwin'));
    if (st.stopped) {
      key = 'stopped';
      msg = 'Stopped. Qosha won\u2019t look at or use your computer until you let it.';
      btn = ['Let Qosha continue', 'continue'];
      dot = 'background:#d98c7a';
    } else if (act.active) {
      key = 'active|' + (act.app || '');
      msg = 'Qosha is using your computer' + (act.app ? ' \u00b7 ' + act.app : '');
      btn = ['Stop', 'stop'];
    } else if (st.setup && st.setup.state === 'installing') {
      key = 'installing';
      msg = 'Setting up using apps on this computer\u2026';
    } else if (st.installed && st.needs && st.needs.length) {
      key = 'needs|' + st.needs.join(',');
      msg = 'To let Qosha use apps, turn on its screen helper (macOS shows it under its maker\u2019s name) in System Settings > Privacy & Security > ' + st.needs.join(' and ') + '.';
      btn = ['Open the permission requests', 'setup'];
      btn2 = ['Stop', 'stop'];          // Stop stays beside the hint (final verification, GPT)
    } else if (st.setup && st.setup.state === 'failed') {
      key = 'failed';
      msg = String(st.setup.say || 'Setting up didn\u2019t work.');
      btn = ['Try again', 'setup'];
    } else if (st.installed) {
      // Stop stays within reach once Qosha can use the computer (review r1, GPT CU-13): a small pill
      key = 'idle';
      msg = 'Qosha can use apps on this computer when you ask';
      btn = ['Stop', 'stop'];
      dot = 'background:#7fb59a';
    } else {
      key = 'none';
    }
    if (key === last) return;
    last = key;
    while (b.firstChild) b.removeChild(b.firstChild);
    if (key === 'none') { b.style.display = 'none'; return; }
    b.appendChild(el('span', 'width:9px;height:9px;border-radius:50%;flex:none;' + dot));
    b.appendChild(el('span', 'flex:1;min-width:0', msg));
    [btn, btn2].forEach(function (one) {
      if (!one) return;
      var x = el('button', BTN, one[0]);
      x.type = 'button';
      x.addEventListener('click', function () { press(one[1], x); });
      b.appendChild(x);
    });
    b.style.display = 'flex';
    b.style.padding = key === 'idle' ? '6px 8px 6px 12px' : '10px 12px 10px 16px';
    b.style.fontSize = key === 'idle' ? '12px' : '14px';
  }
  function press(what, x) {
    x.disabled = true;
    function again(text) { x.disabled = false; if (text) x.textContent = text; }
    call(what, 'POST').then(function (r) {
      if (r.status === 403) { again('Open the Qosha app to do this'); return null; }
      if (!r.ok) { again(what === 'stop' ? 'Stop (try again)' : 'Try again'); return null; }
      return r.json();
    }).then(function (st) {
      if (st && typeof st === 'object' && 'stopped' in st) { last = ''; render(st); } else if (st) { again(); }
      read();
    }, function () { again(what === 'stop' ? 'Stop (try again)' : 'Try again'); });
  }
  function read() {
    if (busy || off || !tok() || !document.body) return;
    busy = true;
    call('status' + (probe ? '?probe=1' : '')).then(function (r) {
      if (r.status === 404) off = true;
      return r.ok ? r.json() : null;
    }).then(function (st) { busy = false; if (st) render(st); }, function () { busy = false; });
  }
  read();
  setInterval(read, 3000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) read(); });
})();
