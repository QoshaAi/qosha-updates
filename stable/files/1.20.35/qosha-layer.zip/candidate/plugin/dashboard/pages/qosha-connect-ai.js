/* "Connect your AI" (Ren, 17 Nov 2026: "a big pop-up so people can sign in. They cannot be looking for it").
   One large centred panel, shown by itself on Home and Chat whenever no AI account of the person's own is in use (the
   built-in test endpoint does not count), and from the "Connect AI" buttons. Sign-ins are the engine's own flows:
   Claude (a code to paste back), ChatGPT (a code to enter on OpenAI's page; connects by itself), Gemini (Google's own
   sign-in through Google's command-line tool: the code Google shows is pasted back here), or any other key. After a sign-in the best model of that account becomes the main model. */
(function () {
  'use strict';
  var API = '/api/plugins/qosha';
  function tok() { try { var f = window; for (var i = 0; i < 6; i++) { if (typeof f.__HERMES_SESSION_TOKEN__ === 'string') return f.__HERMES_SESSION_TOKEN__; if (!f.parent || f.parent === f) break; f = f.parent; } } catch (e) {} return ''; }
  function api(m, path, body) {
    var h = {'X-Hermes-Session-Token': tok()}; if (body !== undefined) h['Content-Type'] = 'application/json';
    return fetch(path, {method: m, headers: h, credentials: 'same-origin', cache: 'no-store', body: body !== undefined ? JSON.stringify(body) : undefined}).then(function (r) {
      return r.text().then(function (t) { var d = null; try { d = t ? JSON.parse(t) : null; } catch (e) {} if (!r.ok) { var det = d && (d.plain || d.message || (typeof d.detail === 'string' ? d.detail : d.detail && (d.detail.plain || d.detail.message))); throw new Error(det || ('error ' + r.status)); } return d; });
    });
  }
  function el(tag, css, text) { var e = document.createElement(tag); if (css) e.setAttribute('style', css); if (text != null) e.textContent = text; return e; }
  var FONT = 'font-family:"Google Sans Flex","Helvetica Neue",Arial,sans-serif;';
  var BIG = FONT + 'display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:56px;padding:0 20px;border:0;border-radius:16px;background:#0B3326;color:#fff;font-size:17px;font-weight:500;cursor:pointer;box-shadow:inset 0 0 0 1px #DCB87A;';   // gold line just inside the edge (real buttons only: Ren, 17 Nov)
  var GHOST = FONT + 'min-height:44px;padding:0 16px;border:1px solid #848f8a;border-radius:999px;background:#fff;color:#0B0B0B;font-size:14px;cursor:pointer;box-shadow:inset 0 0 0 1px #B8955A;';
  var INPUT = FONT + 'width:100%;box-sizing:border-box;height:48px;padding:0 14px;border:1px solid #848f8a;border-radius:12px;font-size:15px;';
  var state = {brain: null, acc: null, listeners: []};
  // inside the dashboard the panel lives in the top window (it covers the whole app); pages in frames hand over to it
  var TOPW = null; try { if (window.top !== window && window.top.location.origin === window.location.origin) TOPW = window.top; } catch (e) { TOPW = null; }
  var CLOSED_MARK = 'qosha.ai.closed.v2';   // v2: a "closed" from the first version does not count
  function sig(a) { return a ? ['claude', 'chatgpt', 'gemini'].map(function (k) { return k + ':' + (a[k] ? 1 : 0); }).join(',') : ''; }
  function allOn(a) { return !!(a && a.claude && a.chatgpt && a.gemini); }
  function closedNow() { try { return !!state.acc && localStorage.getItem(CLOSED_MARK) === sig(state.acc); } catch (e) { return false; } }
  function markClosed() { try { localStorage.setItem(CLOSED_MARK, sig(state.acc) || 'closed'); } catch (e) {} }
  // connected = an account or key of the person's own is really there (the engine's default provider and model alone
  // are not an account: a fresh install said "Qosha is using ..." with nothing connected)
  function hasAccount(a) { return !!(a && (a.claude || a.chatgpt || a.gemini || (a.keys && a.keys.length))); }
  function connected(b) { return hasAccount(state.acc) && !!(b && b.provider && b.provider !== 'custom' && b.model); }
  function read() {
    return Promise.all([api('GET', API + '/brain').then(null, function () { return null; }), api('GET', API + '/signin/accounts').then(null, function () { return null; })]).then(function (r) {
      state.brain = r[0]; state.acc = r[1];
      state.listeners.forEach(function (fn) { try { fn(r[0]); } catch (e) {} });
      return r[0];
    });
  }
  // the best model of the account just connected becomes the main model, so the next message uses it
  function use(provider) {
    return api('GET', API + '/brain').then(function (b) {
      var p = ((b && b.providers) || []).filter(function (x) { return x.id === provider; })[0];
      if (!p || !p.models || !p.models.length) throw new Error('its models are not listed yet');
      var m = p.models[0], ef = (m.efforts || []).map(function (e) { return e.id; });
      return api('POST', API + '/brain', {provider: provider, model: m.id, effort: ef.indexOf('medium') >= 0 ? 'medium' : (ef[0] || 'medium')});
    });
  }
  var overlay = null, opener = null;
  // keyboard (17 Nov, accessibility QA): focus moves into the panel when it opens, Tab stays inside it, Escape closes it
  // (a close by the person, like X), and focus goes back to the button that opened it
  function stops() {
    return overlay ? Array.prototype.filter.call(overlay.querySelectorAll('button, input, select, textarea, a[href], [tabindex]:not([tabindex="-1"])'),
      function (e) { return !e.disabled && e.getClientRects().length > 0; }) : [];
  }
  function onKey(ev) {
    if (!overlay) return;
    if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); close(); return; }
    if (ev.key !== 'Tab') return;
    var f = stops(); if (!f.length) { ev.preventDefault(); return; }
    var a = document.activeElement, first = f[0], last = f[f.length - 1];
    if (!overlay.contains(a)) { ev.preventDefault(); first.focus(); }
    else if (ev.shiftKey && a === first) { ev.preventDefault(); last.focus(); }
    else if (!ev.shiftKey && a === last) { ev.preventDefault(); first.focus(); }
  }
  var onClose = [];   // things to end when the panel closes (a Gemini sign-in waiting for its code)
  function close() {
    markClosed();
    onClose.splice(0).forEach(function (fn) { try { fn(); } catch (e) {} });
    if (!overlay) return;
    overlay.remove(); overlay = null;
    document.removeEventListener('keydown', onKey, true);
    var o = opener; opener = null;
    try { if (o && o.isConnected && o.ownerDocument && o.ownerDocument.defaultView) { o.ownerDocument.defaultView.focus(); o.focus({preventScroll: true}); } } catch (e) { /* the opener is gone */ }
  }
  function done(msg, name) {
    msg.textContent = name + ' is connected. Setting it as your AI…';
    try { localStorage.removeItem(CLOSED_MARK); } catch (e) {}
    // the first account connected becomes the AI in use; a second one is only added (the one in use stays)
    (connected(state.brain) ? Promise.resolve() : use(name === 'Claude' ? 'anthropic' : name === 'ChatGPT' ? 'openai-codex' : name)).then(function () { window.location.reload(); },
      function (e) { msg.textContent = name + ' is connected, but its model could not be chosen (' + e.message + '). Reload and pick it by the message box.'; read(); });
  }
  function open(auto, from) {
    // `from`: the control that opened it (a page in a frame hands its own focused button over), for the way back
    var mine = null; try { mine = document.activeElement && document.activeElement !== document.body ? document.activeElement : null; } catch (e) { mine = null; }
    if (TOPW && TOPW.QoshaConnectAI && TOPW.QoshaConnectAI !== window.QoshaConnectAI) { TOPW.QoshaConnectAI.open(auto, from || mine); return; }
    if (overlay) return;
    opener = (from && from.focus ? from : null) || mine;
    overlay = el('div', 'position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(5,28,20,.55);' + FONT);
    overlay.id = 'qosha-connect-ai'; overlay.setAttribute('role', 'dialog'); overlay.setAttribute('aria-modal', 'true'); overlay.setAttribute('aria-label', 'Connect your AI');
    var card = el('div', 'position:relative;width:min(520px,100%);max-height:calc(100vh - 32px);overflow:auto;box-sizing:border-box;padding:32px;border-radius:28px;background:#fff;color:#0B0B0B;box-shadow:0 24px 64px rgba(11,51,38,.3);display:flex;flex-direction:column;gap:14px');
    card.appendChild(el('div', 'height:4px;width:48px;background:#B8955A;border-radius:2px'));
    var bX = el('button', FONT + 'position:absolute;top:18px;right:18px;width:40px;height:40px;border:1px solid #e0e6e3;border-radius:999px;background:#fff;color:#0B0B0B;font-size:22px;line-height:1;cursor:pointer;box-shadow:inset 0 0 0 1px #B8955A', '\u00d7');
    bX.type = 'button'; bX.id = 'qca-x'; bX.setAttribute('aria-label', 'Close'); bX.addEventListener('click', close);
    card.appendChild(bX);
    card.appendChild(el('h2', 'margin:0;font-size:28px;line-height:34px;font-weight:500;color:#0B3326', 'Connect your AI'));
    var intro = card.appendChild(el('p', 'margin:0 0 4px;font-size:16px;line-height:24px;color:#3e4b45', connected(state.brain)
      ? 'Qosha is using ' + (state.brain.label || state.brain.model) + '. Connect your other accounts too, or close this panel.'
      : 'Qosha needs an AI account to answer. Sign in with the one you have; it takes a minute.'));
    var msg = el('div', 'font-size:15px;line-height:22px;color:#0B0B0B;display:flex;flex-direction:column;gap:10px');
    var bClaude = el('button', BIG, 'Sign in with Claude'), bGpt = el('button', BIG, 'Sign in with ChatGPT'), bGem = el('button', BIG, 'Sign in with Gemini');
    bClaude.id = 'qca-claude'; bGpt.id = 'qca-chatgpt'; bGem.id = 'qca-gemini';
    [bClaude, bGpt, bGem].forEach(function (b) { b.type = 'button'; card.appendChild(b); });
    card.appendChild(msg);
    var row = el('div', 'display:flex;justify-content:space-between;align-items:center;gap:12px;margin-top:6px');
    var bKey = el('button', GHOST, 'I have a key'), bNo = el('button', GHOST, 'Close');
    bKey.id = 'qca-key'; bNo.id = 'qca-notnow'; bKey.type = bNo.type = 'button';
    row.appendChild(bKey); row.appendChild(bNo); card.appendChild(row);
    overlay.appendChild(card); document.body.appendChild(overlay);
    document.addEventListener('keydown', onKey, true);
    try { window.focus(); bX.focus({preventScroll: true}); } catch (e) { /* focus stays where it was */ }
    // each service with its state: "Claude: connected" with a small Disconnect; the others stay as buttons
    api('GET', API + '/signin/accounts').then(function (a) {
      if (!a || !overlay) return;
      var any = false;
      [['claude', 'Claude', bClaude], ['chatgpt', 'ChatGPT', bGpt], ['gemini', 'Gemini', bGem]].forEach(function (x) {
        if (!a[x[0]]) return;
        any = true;
        var rowc = el('div', 'display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:56px;padding:0 20px;border:1px solid #e0e6e3;border-radius:16px;background:#F5F4F0;color:#0B3326;font-size:17px;font-weight:500');
        rowc.id = 'qca-state-' + x[0];
        rowc.appendChild(el('span', null, x[1] + ': connected \u2713' + (x[0] === 'gemini' && a.gemini_how ? ' (' + a.gemini_how + ')' : '')));
        var d = el('button', FONT + 'border:0;background:transparent;color:#3e4b45;font-size:13px;text-decoration:underline;cursor:pointer;padding:8px', 'Disconnect'); d.type = 'button';
        d.addEventListener('click', function () {
          var ask = 'Disconnect ' + x[1] + ' from Qosha on this computer?';
          if (window.QoshaI18n && typeof window.QoshaI18n.tx === 'function') ask = window.QoshaI18n.tx(ask);   // the person's language
          if (!window.confirm(ask)) return;
          d.textContent = 'Disconnecting…';
          api('POST', API + '/signin/disconnect/' + x[0], {}).then(function () { try { localStorage.removeItem(CLOSED_MARK); } catch (e) {} window.location.reload(); }, function (e) { d.textContent = 'Not disconnected: ' + e.message; });
        });
        rowc.appendChild(d);
        x[2].parentNode.replaceChild(rowc, x[2]);
      });
      // Qosha's own Gemini tool (agy at the version Qosha tested) failed its daily self-check: say what is wrong in plain
      // words; "Repair" reinstalls the pinned version and checks again (never a switch to another provider)
      if (a.gemini_state && a.gemini_state !== 'ok') gemHealth(a.gemini_state, a.gemini_plain);
      if (a.keys && a.keys.length) { any = true; card.insertBefore(el('p', 'margin:0;font-size:14px;color:#3e4b45', 'Keys saved: ' + a.keys.join(', ') + '.'), msg); }
      // the status line follows the state
      var on = [['claude', 'Claude'], ['chatgpt', 'ChatGPT'], ['gemini', 'Gemini']].filter(function (x) { return a[x[0]]; }).map(function (x) { return x[1]; });
      if (on.length === 3) intro.textContent = 'You\u2019re signed in to all your AI accounts. You can close this now.';
      else if (on.length) intro.textContent = 'You\u2019re signed in to ' + (on.length === 2 ? on.join(' and ') : on[0]) + ' only. You can connect the others now, or close this and do it later.';
      if (on.length && state.brain && state.brain.label) card.insertBefore(el('p', 'margin:0;font-size:14px;color:#3e4b45', 'Qosha answers with ' + state.brain.label + '.'), msg);
    }, function () {});
    bNo.addEventListener('click', close);
    function gemHealth(st, plain) {
      var old = card.querySelector('#qca-gemini-health'); if (old) old.remove();
      if (!st || st === 'ok') return;
      var box = el('div', 'display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:56px;padding:10px 20px;border-radius:16px;background:#FBF3E6;color:#5a3d12;font-size:15px;line-height:22px');
      box.id = 'qca-gemini-health'; box.setAttribute('role', 'status');
      var txt = el('span', null, plain || (st === 'signed_out' ? 'Gemini needs you to sign in again.' : 'Gemini needs a repair.'));
      box.appendChild(txt);
      if (st !== 'signed_out') {
        var rb = el('button', GHOST, 'Repair'); rb.type = 'button'; rb.id = 'qca-gemini-repair';
        rb.addEventListener('click', function () {
          rb.disabled = true; rb.textContent = 'Repairing…';
          txt.textContent = 'Qosha is putting back the version of Google’s Gemini tool it tested (a download of about 90 MB; a minute or two)…';
          api('POST', API + '/signin/gemini/repair', {}).then(function (r) {
            if (!overlay) return;
            if (r && r.state === 'ok') { txt.textContent = 'Gemini is repaired ✓'; rb.remove(); setTimeout(function () { window.location.reload(); }, 1500); return; }
            if (r && r.state === 'signed_out') { gemHealth('signed_out', r.plain); return; }
            txt.textContent = (r && (r.install_plain || r.plain)) || 'Gemini still needs a repair.';
            rb.disabled = false; rb.textContent = 'Repair';
          }, function (e) { txt.textContent = 'The repair did not finish: ' + e.message; rb.disabled = false; rb.textContent = 'Repair'; });
        });
        box.appendChild(rb);
      }
      card.insertBefore(box, msg);
    }
    function say(t) { msg.textContent = ''; msg.appendChild(el('span', null, t)); }
    function codeBox(placeholder, btn, onGo, secret) {
      var inp = el('input', INPUT); inp.type = secret ? 'password' : 'text'; inp.placeholder = placeholder; inp.autocomplete = 'off';
      var go = el('button', BIG.replace('min-height:56px', 'min-height:48px'), btn); go.type = 'button';
      msg.appendChild(inp); msg.appendChild(go); inp.focus();
      go.addEventListener('click', function () { if (inp.value.trim()) onGo(inp.value.trim(), go); });
      return inp;
    }
    bClaude.addEventListener('click', function () {
      say('Opening Claude…');
      api('POST', API + '/signin/claude/start', {}).then(function (r) {
        try { window.open(r.url, '_blank', 'noopener'); } catch (e) {}
        say('1. Sign in to Claude in the tab that just opened. 2. Claude shows a code: copy it. 3. Paste it here.');
        var a = el('a', 'color:#0B3326', 'Open the Claude sign-in page again'); a.href = r.url; a.target = '_blank'; a.rel = 'noopener'; msg.appendChild(a);
        codeBox('Paste the code from Claude', 'Finish', function (code) {
          api('POST', API + '/signin/claude/finish', {id: r.id, code: code}).then(function () { say(''); done(msg, 'Claude'); }, function (e) { msg.firstChild.textContent = e.message; });
        });
      }, function (e) { say('Claude sign-in could not start: ' + e.message); });
    });
    bGpt.addEventListener('click', function () {
      say('Asking OpenAI for a code…');
      api('POST', '/api/providers/oauth/openai-codex/start', {}).then(function (r) {
        try { window.open(r.verification_url, '_blank', 'noopener'); } catch (e) {}
        say('1. In the tab that just opened, sign in to ChatGPT. 2. Enter this code there:');
        msg.appendChild(el('div', 'font-size:30px;font-weight:600;letter-spacing:.12em;color:#0B3326;padding:8px 0', r.user_code));
        var a = el('a', 'color:#0B3326', 'Open the ChatGPT page again'); a.href = r.verification_url; a.target = '_blank'; a.rel = 'noopener'; msg.appendChild(a);
        msg.appendChild(el('span', 'color:#5a6761', 'Qosha connects by itself when you are done. Leave this open.'));
        var t0 = Date.now();
        (function poll() {
          if (!overlay) return;
          api('GET', '/api/providers/oauth/openai-codex/poll/' + encodeURIComponent(r.session_id) + '?wait=20').then(function (s) {
            var st = s && s.status;
            if (st === 'pending' && Date.now() - t0 < 15 * 60000) return poll();
            if (st === 'approved') { say(''); done(msg, 'ChatGPT'); } else say('ChatGPT did not connect (' + (st || 'no answer') + '). Press Sign in with ChatGPT to try again.');
          }, function (e) { say('ChatGPT did not connect: ' + e.message); });
        })();
      }, function (e) { say('ChatGPT sign-in could not start: ' + e.message); });
    });
    function keyFor(envKey, provider, name) {
      return function (key) {
        api('PUT', '/api/env', {key: envKey, value: key, provider_setup: true}).then(function () { say(''); done(msg, provider === 'gemini' ? 'gemini' : provider); if (name) msg.textContent = name + ' is connected. Setting it as your AI…'; },
          function (e) { msg.firstChild.textContent = 'Not saved: ' + e.message; });
      };
    }
    // Gemini (17 Nov 2026, Renato's Windows sign-in): the whole sign-in happens here. Qosha runs Google's tool's own
    // sign-in in the background, shows Google's page in the browser, and takes the code Google shows in a field below.
    // Only when that cannot start does a separate window open (titled "Sign in to Gemini", brought to the front).
    function raw(m, path, body) {
      var h = {'X-Hermes-Session-Token': tok()}; if (body !== undefined) h['Content-Type'] = 'application/json';
      return fetch(path, {method: m, headers: h, credentials: 'same-origin', cache: 'no-store', body: body !== undefined ? JSON.stringify(body) : undefined})
        .then(function (r) { return r.text().then(function (t) { var d = null; try { d = t ? JSON.parse(t) : null; } catch (e) {} return {ok: r.ok, status: r.status, d: d || {}}; }); });
    }
    var gemId = null;   // the Gemini sign-in now waiting for its code
    // 20 Nov 2026 (Ren: "fix the antigravity issue"): Google's tool opens its sign-in page by itself each time a sign-in
    // starts, so a sign-in starts ONLY from the person's own press, one at a time; nothing restarts it by itself.
    var gemBusy = false;
    var gemOp = 0;      // the current press; closing the panel or a newer press makes an older answer start nothing
    // a one-time press token, asked for only inside a real click (a synthetic click gets none, and the server then
    // starts no sign-in): -> a promise of the token, or '' (20 Nov 2026)
    function gemPress(ev) {
      if (!ev || ev.isTrusted !== true) return Promise.resolve('');
      return raw('POST', API + '/signin/gemini/press', {}).then(function (r) { return (r.ok && r.d && r.d.press) || ''; }, function () { return ''; });
    }
    function gemOffer(why, terminal, note) {
      msg.textContent = '';
      var p = el('p', 'margin:0;padding:10px 14px;border-radius:12px;background:#FBF3E6;color:#5a3d12;font-size:15px;line-height:22px', why);
      p.id = 'qca-gemini-note'; p.setAttribute('role', 'alert'); msg.appendChild(p);
      var again = el('button', GHOST, 'Try again'); again.type = 'button'; again.id = 'qca-gemini-again';
      again.addEventListener('click', function (ev) { gemSignin(undefined, gemPress(ev)); });
      msg.appendChild(again);
      if (terminal) {
        var tw = el('button', GHOST, 'Sign in in a Terminal window instead'); tw.type = 'button'; tw.id = 'qca-gemini-terminal';
        tw.addEventListener('click', function (ev) { gemWindow(note, gemPress(ev)); });
        msg.appendChild(tw);
      }
    }
    function gemWindow(lead, pressP) {
      say((lead ? lead + ' ' : '') + 'Opening Google’s sign-in in a window of its own…');
      Promise.resolve(pressP).then(function (press) { return api('POST', API + '/signin/gemini/open', {press: press || ''}); }).then(function (x) {
        say(x && x.plain ? x.plain : 'The sign-in window could not be opened.');
        if (x && x.ok !== false) { var c = el('button', GHOST, 'Check again'); c.type = 'button'; c.id = 'qca-gemini-check'; c.addEventListener('click', gemStatus); msg.appendChild(c); }
      }, function (e) { say('The sign-in window could not be opened: ' + e.message); });
    }
    function gemSignin(note, pressP) {
      if (gemBusy) return;          // one start at a time: a second press while one is starting does nothing
      gemBusy = true;
      var myOp = ++gemOp;
      gemCancel();
      say(note ? note : 'Starting Google’s sign-in…');
      Promise.resolve(pressP).then(function (press) { return raw('POST', API + '/signin/gemini/login/start', {press: press || ''}); }).then(function (res) {
        // the panel closed, or the person chose something else meanwhile: start nothing, let go of what came back
        if (!overlay || myOp !== gemOp) { if (res.ok && res.d.id) raw('POST', API + '/signin/gemini/login/cancel', {id: res.d.id}); return; }
        gemBusy = false;
        if (res.d && res.d.error === 'terminal_waiting') {
          msg.textContent = '';
          say(res.d.plain || 'A Gemini sign-in is already open in a Terminal window.');
          var tc = el('button', GHOST, 'Cancel the Terminal sign-in'); tc.type = 'button'; tc.id = 'qca-gemini-terminal-cancel';
          tc.addEventListener('click', function () {
            raw('POST', API + '/signin/gemini/login/cancel', {terminal: true}).then(function () {
              say('Qosha stopped waiting for the Terminal sign-in. Press Sign in with Gemini to sign in here instead.');
            }, function () {});
          });
          msg.appendChild(tc);
          return;
        }
        if (!res.ok || !res.d.ok || !res.d.url) {
          // never opens a Terminal sign-in by itself: the person chooses
          msg.textContent = '';
          var nf = el('p', 'margin:0;padding:10px 14px;border-radius:12px;background:#FBF3E6;color:#5a3d12;font-size:15px;line-height:22px',
            (res.d && res.d.plain) || 'Google’s sign-in could not start here.');
          nf.id = 'qca-gemini-note'; nf.setAttribute('role', 'alert'); msg.appendChild(nf);
          var ag = el('button', GHOST, 'Try again'); ag.type = 'button'; ag.id = 'qca-gemini-again';
          ag.addEventListener('click', function (ev) { gemSignin(note, gemPress(ev)); }); msg.appendChild(ag);
          var tw = el('button', GHOST, 'Sign in in a Terminal window instead'); tw.type = 'button'; tw.id = 'qca-gemini-terminal';
          tw.addEventListener('click', function (ev) { gemWindow(note, gemPress(ev)); }); msg.appendChild(tw);
          return;
        }
        var r = res.d; gemId = r.id;
        msg.textContent = '';
        if (note) { var nt = el('p', 'margin:0;padding:10px 14px;border-radius:12px;background:#FBF3E6;color:#5a3d12;font-size:15px;line-height:22px', note); nt.id = 'qca-gemini-note'; nt.setAttribute('role', 'alert'); msg.appendChild(nt); }
        // Google's tool opens its sign-in page in the browser by itself; the button opens the same page again
        msg.appendChild(el('p', 'margin:0;font-size:15px;line-height:22px', 'Google’s sign-in page is opening in your browser. If you don’t see it, press “Open Google’s sign-in”.'));
        var ol = el('ol', 'margin:0;padding-left:22px;list-style:decimal;display:flex;flex-direction:column;gap:6px;font-size:15px;line-height:22px');
        ['Sign in with the Google account that has your Gemini plan.',
         'Google then shows a code. Copy it.',
         'Paste it below and press Done.'].forEach(function (t) { ol.appendChild(el('li', null, t)); });
        msg.appendChild(ol);
        var o = el('button', GHOST, 'Open Google’s sign-in'); o.type = 'button'; o.id = 'qca-gemini-open';
        o.addEventListener('click', function () { try { window.open(r.url, '_blank', 'noopener'); } catch (e) {} });
        msg.appendChild(o);
        var lab = el('label', 'font-size:14px;color:#3e4b45', 'Paste the code Google shows you'); lab.setAttribute('for', 'qca-gemini-code');
        var inp = el('input', INPUT); inp.type = 'text'; inp.id = 'qca-gemini-code'; inp.placeholder = 'Paste the code Google shows you'; inp.autocomplete = 'off'; inp.spellcheck = false;
        var go = el('button', BIG.replace('min-height:56px', 'min-height:48px'), 'Done'); go.type = 'button'; go.id = 'qca-gemini-done';
        var cx = el('button', GHOST, 'Cancel'); cx.type = 'button'; cx.id = 'qca-gemini-cancel';
        var st = el('div', 'font-size:15px;line-height:22px;color:#0B3326;min-height:22px'); st.id = 'qca-gemini-status'; st.setAttribute('aria-live', 'polite');
        msg.appendChild(lab); msg.appendChild(inp); msg.appendChild(go); msg.appendChild(st); msg.appendChild(cx);
        try { inp.focus({preventScroll: true}); } catch (e) {}
        inp.addEventListener('keydown', function (ev) { if (ev.key === 'Enter') { ev.preventDefault(); go.click(); } });
        cx.addEventListener('click', function () { gemCancel(); say('Gemini sign-in cancelled. Press Sign in with Gemini to start again.'); });
        go.addEventListener('click', function () {
          var code = inp.value.trim();
          if (!code) { st.textContent = 'Paste the code from Google first.'; inp.focus(); return; }
          go.disabled = true; inp.disabled = true; o.disabled = true; st.textContent = 'Checking the code with Google… (up to a minute)';
          raw('POST', API + '/signin/gemini/login/finish', {id: r.id, code: code}).then(function (f) {
            if (!overlay) return;
            if (f.ok && f.d.ok) {
              gemId = null;
              msg.textContent = ''; var okl = el('div', 'display:flex;align-items:center;min-height:56px;padding:0 20px;border:1px solid #e0e6e3;border-radius:16px;background:#F5F4F0;color:#0B3326;font-size:17px;font-weight:500', 'Gemini: connected ✓');
              okl.id = 'qca-gemini-connected'; msg.appendChild(okl);
              try { localStorage.removeItem(CLOSED_MARK); } catch (e) {}
              setTimeout(function () { window.location.reload(); }, 1500);
              return;
            }
            var why = (f.d && f.d.plain) || ('The sign-in did not finish (error ' + f.status + ').');
            if (f.d && f.d.error === 'bad_format') { st.textContent = why; go.disabled = false; inp.disabled = false; o.disabled = false; inp.focus(); return; }
            gemId = null;
            // never restarts by itself (a restart opens Google's page again): what went wrong, and the person's choice
            msg.textContent = '';
            var wn = el('p', 'margin:0;padding:10px 14px;border-radius:12px;background:#FBF3E6;color:#5a3d12;font-size:15px;line-height:22px', why);
            wn.id = 'qca-gemini-note'; wn.setAttribute('role', 'alert'); msg.appendChild(wn);
            var tr = el('button', GHOST, 'Try again'); tr.type = 'button'; tr.id = 'qca-gemini-again';
            tr.addEventListener('click', function (ev) { gemSignin(undefined, gemPress(ev)); }); msg.appendChild(tr);
          }, function (e) { st.textContent = 'Qosha could not reach its sign-in just now (' + e.message + '). Try Done again.'; go.disabled = false; inp.disabled = false; o.disabled = false; });
        });
      }, function () { gemBusy = false; gemOffer('Qosha could not start Google’s sign-in just now.', true, note); });
    }
    function gemCancel() {
      var id = gemId; gemId = null;
      if (id) raw('POST', API + '/signin/gemini/login/cancel', {id: id}).then(null, function () {});
    }
    onClose.push(gemCancel);
    onClose.push(function () { gemOp++; gemBusy = false; });
    // "Check again" after a Terminal sign-in: it only checks and tells; it never starts a sign-in
    function gemStatus() {
      say('Checking Gemini on your Google subscription…');
      api('POST', API + '/signin/gemini/check', {}).then(function (r) {
        if (!overlay) return;
        if (r.connected) { try { localStorage.removeItem(CLOSED_MARK); } catch (e) {} say('Gemini: connected ✓'); window.location.reload(); return; }
        say((r.plain || 'Gemini is not connected yet.') + ' Finish the sign-in in the Terminal window, then press Check again.');
        var c = el('button', GHOST, 'Check again'); c.type = 'button'; c.id = 'qca-gemini-check'; c.addEventListener('click', gemStatus); msg.appendChild(c);
      }, function (e) { say('Gemini could not be checked: ' + e.message); });
    }
    function gem(ev) {
      if (gemBusy) return;          // one press at a time: the check and the sign-in it may start
      gemBusy = true;
      var pressP = gemPress(ev);   // asked for at the press itself; used only if the check finds a clear sign-out
      var op = ++gemOp;
      gemCancel();
      say('Checking Gemini on your Google subscription…');
      api('POST', API + '/signin/gemini/check', {}).then(function (r) {
        if (!overlay || op !== gemOp) { return; }      // the panel closed or another press came: start nothing
        gemBusy = false;
        if (r.connected) { try { localStorage.removeItem(CLOSED_MARK); } catch (e) {} say('Gemini: connected ✓'); window.location.reload(); return; }
        if (!r.installed) {
          say('Gemini uses Google’s own sign-in tool, which is not on this computer yet. Ask Qosha in the chat: “install Google’s Antigravity command-line tool”, then press Sign in with Gemini again.');
          return;
        }
        // Google turns the tool itself away (not a sign-in problem): say that, never the sign-in steps
        if (r.error === 'tool_refused') { say(r.plain || 'Google no longer lets this tool use a personal Gemini plan. Qosha needs Google’s newer tool; ask Qosha to set it up.'); return; }
        // a sign-in starts only on a clear "signed out"; a check that could not run is not a reason to sign in again
        if (r.error === 'unreadable') { say((r.plain || 'Qosha could not check Gemini just now.') + ' Try again in a moment.'); return; }
        gemSignin(undefined, pressP);
      }, function (e) { if (op === gemOp) gemBusy = false; say('Gemini could not be checked: ' + e.message); });
    }
    bGem.addEventListener('click', gem);
    bKey.addEventListener('click', function () {
      gemOp++; gemBusy = false; gemCancel();     // another choice: a pending Gemini check or start does nothing now
      say('Pick the service and paste its key (OpenRouter gives every model with one key).');
      var sel = el('select', INPUT); msg.appendChild(sel);
      var ENV = {openrouter: 'OPENROUTER_API_KEY', anthropic: 'ANTHROPIC_API_KEY'};
      api('GET', '/api/model/options?include_unconfigured=true').then(function (r) {
        var list = ((r && r.providers) || []).filter(function (p) { return p && p.slug !== 'custom' && (p.key_env || ENV[p.slug]); });
        list.sort(function (a, b) { return (a.slug === 'openrouter' ? -1 : b.slug === 'openrouter' ? 1 : 0) || String(a.name).localeCompare(String(b.name)); });
        list.forEach(function (p) { var o = el('option', null, p.name); o.value = p.slug; o.setAttribute('data-env', p.key_env || ENV[p.slug]); sel.appendChild(o); });
        codeBox('Paste the key', 'Save key', function (key) { var o = sel.options[sel.selectedIndex]; keyFor(o.getAttribute('data-env'), o.value, o.textContent)(key); }, true);
      }, function (e) { say('The list of services could not be read: ' + e.message); });
    });
    if (auto === 'claude') bClaude.click(); if (auto === 'chatgpt') bGpt.click();
  }
  // a filled "Connect AI" button; when an account is in use it shows the model and opens the same panel
  function button(where) {
    var b = el('button', FONT + 'flex:none;display:inline-flex;align-items:center;gap:8px;min-height:40px;padding:0 16px;border-radius:999px;border:1px solid #0B3326;background:#0B3326;color:#fff;font-size:14px;font-weight:500;cursor:pointer;white-space:nowrap;max-width:260px;overflow:hidden;text-overflow:ellipsis', 'Connect AI');
    b.type = 'button'; b.className = 'qosha-connect-ai-btn'; b.setAttribute('data-where', where || '');
    b.addEventListener('click', function () { open(false, b); });
    var paint = function () {
      var a = state.acc || {}, N = [['claude', 'Claude'], ['chatgpt', 'ChatGPT'], ['gemini', 'Gemini']];
      var on = N.filter(function (x) { return a[x[0]]; }).map(function (x) { return x[1] + ' \u2713'; });
      var off = N.filter(function (x) { return !a[x[0]]; }).map(function (x) { return x[1]; });
      var none = !on.length;
      b.textContent = none ? 'Connect AI' : 'AI accounts \u00b7 ' + on.join(' ') + (off.length ? ' \u00b7 Connect ' + off.join(', ') : '');
      b.title = 'AI accounts: connect or manage Claude, ChatGPT, Gemini and keys';
      b.style.maxWidth = '420px';
      b.style.background = none ? '#0B3326' : '#fff'; b.style.color = none ? '#fff' : '#0B3326';
      b.style.boxShadow = 'inset 0 0 0 1px ' + (none ? '#DCB87A' : '#B8955A');
      b.setAttribute('aria-label', b.textContent);
    };
    state.listeners.push(paint); if (state.brain) paint(state.brain);
    return b;
  }
  window.QoshaConnectAI = {open: open, button: button, connected: function () { return connected(state.brain); }, refresh: read};
  function place() {
    var path = window.location.pathname;
    // Home (in its frame): an obvious button above the page, right-aligned
    if (/\/dashboard-plugins\/qosha\/index\.html$/.test(path) && !document.getElementById('qosha-ai-home')) {
      var hero = document.querySelector('.hero') || document.querySelector('main');
      if (hero && hero.parentNode) {
        var row = el('div', 'display:flex;justify-content:flex-end;padding:10px 0 12px;' + FONT); row.id = 'qosha-ai-home';
        row.appendChild(button('home')); hero.parentNode.insertBefore(row, hero);
      }
    }
    // every other page of the app (top window): a fixed button top-right; Home and Chat carry their own
    if (!TOPW && window.location.pathname.indexOf('/dashboard-plugins/') !== 0) {
      var top = document.getElementById('qosha-ai-top'), p = path.replace(/\/+$/, '') || '/';
      var own = (p === '/' && !/[?&]view=/.test(window.location.search)) || p === '/chat';
      if (!top) { top = button('top'); top.id = 'qosha-ai-top'; top.style.position = 'fixed'; top.style.top = '12px'; top.style.right = '20px'; top.style.zIndex = '2147482000'; document.body.appendChild(top); }
      top.style.display = own ? 'none' : 'inline-flex';
    }
    settingsGemini();
  }
  // Settings (contract AGYGUARD C9): Gemini's line in the Connections section of Settings, with the last daily
  // self-check of Qosha's own Gemini tool in plain words and, when it failed, a Repair button (or Sign in when only the
  // sign-in is missing). Settings is a page in a frame of this window (settings.html); the line is put there from here.
  var SETTINGS_RE = /\/dashboard-plugins\/qosha\/settings\.html$/;
  function settingsGemini() {
    if (TOPW) return;
    Array.prototype.forEach.call(document.querySelectorAll('iframe'), function (f) {
      var d = null;
      try { if (!SETTINGS_RE.test(f.contentWindow.location.pathname)) return; d = f.contentDocument; } catch (e) { return; }
      if (!d || d.readyState === 'loading' || d.getElementById('qs-gemini') || d.__qsGemAsked) return;
      var sec = d.querySelector('section[aria-labelledby="s-con"]'); if (!sec) return;
      d.__qsGemAsked = true;
      api('GET', API + '/signin/accounts').then(function (a) { settingsGeminiLine(d, sec, a); },
        function () { setTimeout(function () { d.__qsGemAsked = false; }, 30000); });
    });
  }
  function settingsGeminiLine(d, sec, a) {
    var box = d.getElementById('qs-gemini');
    if (!box) { box = d.createElement('div'); box.id = 'qs-gemini'; box.className = 'note upd'; box.style.marginTop = '12px'; sec.appendChild(box); }
    box.textContent = '';
    var st = a && a.gemini_state;
    if (!st) { box.hidden = true; return; }   // no check on this computer yet (a cloud box, a fresh install's first minute)
    box.hidden = false;
    var b = d.createElement('b'); b.textContent = 'Gemini'; box.appendChild(b);
    box.appendChild(d.createTextNode(' — Google’s Gemini tool, kept by Qosha at the version it tested, checked once a day.'));
    var line = d.createElement('div'); line.className = 'upd-line'; line.id = 'qs-gemini-line'; line.setAttribute('aria-live', 'polite'); box.appendChild(line);
    var acts = d.createElement('div'); acts.className = 'upd-acts'; box.appendChild(acts);
    function mk(text, pri, fn) { var x = d.createElement('button'); x.type = 'button'; x.className = 'ubtn' + (pri ? ' pri' : ''); x.textContent = text; x.addEventListener('click', fn); return x; }
    var at = a.gemini_checked_at ? new Date(a.gemini_checked_at * 1000) : null;
    var when = at ? ' (checked ' + at.toLocaleDateString([], {month: 'short', day: 'numeric'}) + ', ' + at.toLocaleTimeString([], {hour: 'numeric', minute: '2-digit'}) + ')' : '';
    if (st === 'ok') {
      line.textContent = 'Daily check: ok ✓ — version ' + (a.gemini_version || '?') + when + '.';
      return;
    }
    var err = d.createElement('span'); err.className = 'err';
    err.textContent = a.gemini_plain || (st === 'signed_out' ? 'Gemini needs you to sign in again.' : 'Gemini needs a repair.');
    line.appendChild(err); line.appendChild(d.createTextNode(when));
    if (st === 'signed_out') {
      var si = mk('Sign in', true, function () { open(false, si); }); si.id = 'qs-gemini-signin'; acts.appendChild(si);
      return;
    }
    var rb = mk('Repair', true, function () {
      rb.disabled = true; rb.textContent = 'Repairing…';
      line.textContent = 'Qosha is putting back the version of Google’s Gemini tool it tested (a download of about 90 MB; a minute or two)…';
      api('POST', API + '/signin/gemini/repair', {}).then(function (r) {
        var now = Math.floor(Date.now() / 1000);
        settingsGeminiLine(d, sec, {gemini_state: (r && r.state) || 'broken', gemini_version: (r && r.version) || '',
          gemini_plain: (r && (r.state === 'ok' ? '' : (r.install_plain || r.plain))) || '', gemini_checked_at: now});
        if (r && r.state === 'ok') { var ok = d.getElementById('qs-gemini-line'); if (ok) ok.textContent = 'Gemini is repaired ✓ — version ' + (r.version || '?') + '.'; read(); }
      }, function (e) { line.textContent = 'The repair did not finish: ' + e.message; rb.disabled = false; rb.textContent = 'Repair'; });
    });
    rb.id = 'qs-gemini-repair'; acts.appendChild(rb);
  }
  function start() {
    read().then(function (b) {
      place(); setInterval(place, 1500);
      if (TOPW) return;   // the top window decides when the panel opens
      var p = window.location.pathname.replace(/\/+$/, '') || '/';
      var homeOrChat = p === '/' || p === '/chat' || window.location.pathname.indexOf('/dashboard-plugins/') === 0;
      // opens by itself on Home and Chat until every account is connected or the person closed it for this state
      // a fresh install offering a one-time setup code shows that card first (17 Nov 2026); the panel waits until the
      // code is used or declined, then opens as before. An install without the setup route opens as before.
      if (homeOrChat && state.acc && !allOn(state.acc) && !closedNow()) {
        var tries = 0;
        var go = function () {
          fetch('/api/plugins/qosha/setup/status', {credentials: 'same-origin', headers: {'X-Hermes-Session-Token': (function () { try { var f = window; for (var i = 0; i < 6; i++) { if (typeof f.__HERMES_SESSION_TOKEN__ === 'string') return f.__HERMES_SESSION_TOKEN__; if (!f.parent || f.parent === f) break; f = f.parent; } } catch (e) {} return ''; })()}})
            .then(function (r) { return r.ok ? r.json() : {}; })
            .then(function (j) { if (j && j.status === 'offer' && tries++ < 360) setTimeout(go, 10000); else if (!closedNow()) open(); })
            .catch(function () { if (!closedNow()) open(); });
        };
        go();
      }
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
