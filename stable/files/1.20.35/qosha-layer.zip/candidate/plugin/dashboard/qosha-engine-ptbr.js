/* Qosha pt-BR v1 (22 Nov 2026, Ren: "Translation now, extras later"): the engine's own screens (Settings' engine pages,
   models, skills, channels, keys, logs, system, webhooks, pairing, MCP, dialogs, the side panel) in Brazilian
   Portuguese where their English is written straight into the code (not in their i18n tables, which the installer
   already gives Qosha's pt-BR). Loaded by first-paint.html ONLY when Qosha's language is pt-br; in English it is never
   loaded, so English stays byte for byte.
   How: an exact-match dictionary (i18n/engine-web-literals-pt-br.json, English -> pt-BR). A text node whose whole text
   (spaces aside) is a dictionary entry, or a placeholder / title / aria-label / alt with such a value, is replaced; a
   MutationObserver does the same for whatever the screens draw later. It never enters Qosha's own pages (they are
   separate documents in iframes), Qosha's own shell elements, code, logs, inputs' values, editable text or chat text,
   and never rewrites anything that is not an exact entry. Idempotent: a translated text is not an English entry. */
(function () {
  'use strict';
  if (window.__qoshaEnginePtbr) return;
  window.__qoshaEnginePtbr = true;
  var URL_DICT = '/dashboard-plugins/qosha/i18n/engine-web-literals-pt-br.json';
  var ATTRS = ['placeholder', 'title', 'aria-label', 'alt'];
  // the person's data and Qosha's own elements: never translated
  var SKIP = 'script,style,pre,code,kbd,samp,textarea,input,select,option,iframe,[contenteditable=""],[contenteditable="true"],' +
             '.xterm,.prose,[role="log"],[data-message-id],#qosha-splash,.qosha-nav,[data-qosha-nav],' +
             '[data-qosha-keep],[data-qosha-owner]';
  // (v1 fork L, 22 Nov: .font-mono is NOT skipped: the engine styles its uppercase buttons and count lines with it;
  // the dictionary only ever replaces an exact known UI phrase, and real code, logs and terminals are still skipped)
  var dict = null, pats = [];
  // keys whose only variable part is a number ("{n} tasks · all auto") or a date ({when}, the System page's curator
  // line, 23 Nov 2026): a pattern; nothing else is matched loosely
  function compile() {
    pats = [];
    for (var k in dict) {
      if (!Object.prototype.hasOwnProperty.call(dict, k) || k.indexOf('{') < 0) continue;
      var names = [], ok = true;
      var rx = k.replace(/[.*+?^$()|[\]\\]/g, '\\$&').replace(/\{([A-Za-z0-9_]+)\}/g, function (m, n) {
        if (!/^(n|n2|count|when)$/.test(n)) ok = false;
        names.push(n);
        // {when}: a date and time as the browser writes it (digits, separators, AM/PM, its narrow spaces), never words
        return n === 'when' ? '(\\d[\\d/.,:\\s\u202f\u00a0APMapm-]{3,40})' : '(\\d+)';
      });
      if (ok && names.length) pats.push({rx: new RegExp('^' + rx + '$'), names: names, pt: dict[k]});
    }
  }
  function look(core) {
    if (Object.prototype.hasOwnProperty.call(dict, core)) return dict[core];
    // the engine's own name before the brand sweep renames it (v1, 23 Nov 2026): the same whole sentence in Qosha's English
    if (core.indexOf('Hermes') >= 0) { var q = core.replace(/\bHermes\b/g, 'Qosha'); if (Object.prototype.hasOwnProperty.call(dict, q)) return dict[q]; }
    for (var i = 0; i < pats.length; i++) {
      var m = pats[i].rx.exec(core);
      if (!m) continue;
      var out = pats[i].pt;
      for (var j = 0; j < pats[i].names.length; j++) out = out.split('{' + pats[i].names[j] + '}').join(m[j + 1]);
      return out;
    }
    return null;
  }
  function on() { return window.__qoshaEngineLang === 'pt-br'; }
  function norm(s) { return s.replace(/\s+/g, ' ').trim(); }
  function skipped(el) {
    try { return !!(el && el.closest && el.closest(SKIP)); } catch (e) { return true; }
  }
  function text(node) {
    var v = node.nodeValue;
    if (!v || v.length > 600) return;
    var core = norm(v), tr = core ? look(core) : null;
    if (tr == null) return;
    if (skipped(node.parentElement)) return;
    var lead = v.match(/^\s*/)[0], trail = v.match(/\s*$/)[0];
    var out = lead + tr + trail;
    if (out !== v) node.nodeValue = out;
  }
  // a form field's placeholder / title / label is screen text; its value (the person's) is never read or changed
  var FIELDS = 'input,textarea,select';
  function attrs(el) {
    var field = el.matches && el.matches(FIELDS);
    for (var i = 0; i < ATTRS.length; i++) {
      var a = ATTRS[i];
      if (!el.hasAttribute(a)) continue;
      var v = el.getAttribute(a), core = norm(v || '');
      var t = core ? look(core) : null;
      if (t != null && !skipped(field ? el.parentElement : el)) {
        if (t !== v) el.setAttribute(a, t);
      }
    }
  }
  function sweep(root) {
    if (!dict || !on() || !root) return;
    if (root.nodeType === 3) { text(root); return; }
    if (root.nodeType !== 1 && root.nodeType !== 9 && root.nodeType !== 11) return;
    if (root.nodeType === 1) {
      if (root.matches && root.matches(FIELDS)) { attrs(root); return; }
      if (skipped(root)) return;
      attrs(root);
    }
    var w = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) {
        if (n.nodeType === 1 && n.matches && n.matches(FIELDS)) { attrs(n); return NodeFilter.FILTER_REJECT; }
        if (n.nodeType === 1 && n.matches && n.matches(SKIP)) return NodeFilter.FILTER_REJECT;   // the whole subtree
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    var n;
    while ((n = w.nextNode())) { if (n.nodeType === 3) text(n); else attrs(n); }
  }
  var pending = [], scheduled = false;
  function flush() {
    scheduled = false;
    var list = pending; pending = [];
    for (var i = 0; i < list.length; i++) sweep(list[i]);
  }
  function queue(n) { pending.push(n); if (!scheduled) { scheduled = true; (window.queueMicrotask || setTimeout)(flush); } }
  function start() {
    sweep(document.body);
    new MutationObserver(function (records) {
      if (!on()) return;
      for (var i = 0; i < records.length; i++) {
        var r = records[i];
        if (r.type === 'characterData') queue(r.target);
        else if (r.type === 'attributes') queue(r.target);
        else for (var j = 0; j < r.addedNodes.length; j++) queue(r.addedNodes[j]);
      }
    }).observe(document.body, {childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS});
  }
  function begin() { if (document.body) start(); else document.addEventListener('DOMContentLoaded', start); }
  try {
    var x = new XMLHttpRequest();
    x.open('GET', URL_DICT, true);
    x.onload = function () {
      try { if (x.status === 200) { dict = JSON.parse(x.responseText); delete dict._about; compile(); begin(); } } catch (e) { dict = null; }
    };
    x.send(null);
  } catch (e) { /* no dictionary: the screens stay as they are */ }
})();
