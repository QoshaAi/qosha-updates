"""Qosha from the first byte (P0, 3 Nov 21:45 MST): the dashboard's index.html (every page: Home, Chat, Files, Skills,
Connections, Settings and the engine's own pages share it) gets Qosha's critical CSS, loading screen and readiness
script before any engine script or stylesheet. The engine's shell stays hidden until index.js marks the page
data-qosha-ready; the loading screen is all that can paint before that. Used by the lab (qoshalab.py brand_web) on
the built screens and by the first-paint gate (tests/c18_first_paint_gate.py) on its throwaway copy. Pure text in,
text out; run again after every web build (it replaces its own earlier block)."""
import os
import re
import tempfile
import time
from pathlib import Path

HEAD = ('<!-- qosha-first-paint -->', '<!-- /qosha-first-paint -->')
BODY = ('<!-- qosha-splash -->', '<!-- /qosha-splash -->')
SPLIT = '<!-- qosha-first-paint:body -->'
BLOCK_FILE = Path(__file__).resolve().parent / 'first-paint.html'


def strip(html):
    """The page without Qosha's first-paint block (as the engine built it, apart from the icons)."""
    for a, b in (HEAD, BODY):
        html = re.sub(r'[ \t]*' + re.escape(a) + r'.*?' + re.escape(b) + r'\n?', '', html, flags=re.S)
    return html


# The saved language travels with the page (pt-BR v1, 23 Nov 2026; R8-13 and DC-L6 together): the loading screen
# reads it from the page itself, so it never asks Qosha's server while the page is being drawn (a slow or hung answer
# froze the page and the startup safety net with it). Qosha's server writes the person's display.language into the
# served index.html: at install and self-heal (apply), when the dashboard starts and whenever the setting changes
# (bake_served, from plugin_api). Only this one value is ever rewritten.
LANG_MARK = re.compile(r"var SAVED = '[a-z-]{0,10}';")


def _home():
    h = os.environ.get('HERMES_HOME')
    if h:
        return Path(h)
    d = Path(__file__).resolve().parent              # <home>/plugins/qosha/dashboard
    return d.parents[2] if len(d.parents) > 2 else None


def saved_language(home=None):
    """'pt-br' or 'en': display.language in <home>/config.yaml, read the plain way (no YAML library at install)."""
    try:
        home = Path(home) if home else _home()
        text = (home / 'config.yaml').read_text(encoding='utf-8', errors='replace') if home else ''
    except OSError:
        text = ''
    value, inside = '', False
    for raw in text.splitlines():
        line = raw.rstrip('\r')
        m = re.match(r'^display\s*:\s*(.*?)\s*(?:#.*)?$', line)
        if m:
            f = re.search(r'(?:\{|,)\s*language\s*:\s*([^,}]*)', m.group(1))     # display: {language: pt-br}
            if f:
                value = f.group(1)
            inside = not f
            continue
        if inside:
            if line.strip() and not line[0].isspace():
                inside = False
                continue
            m = re.match(r'^\s+language\s*:\s*(.*?)\s*(?:#.*)?$', line)
            if m:
                value = m.group(1)
    v = value.strip().strip('\'"').lower().replace('_', '-')
    return 'pt-br' if v.startswith('pt') else 'en'


def bake(html, language=None):
    """The page with the saved language written into its loading screen's script (only that one value changes)."""
    lang = 'pt-br' if (language or saved_language()) == 'pt-br' else 'en'
    return LANG_MARK.sub("var SAVED = '%s';" % lang, html, count=1)


def bake_served(dist=None, language=None):
    """Rewrites the served index.html's saved language when it differs. Never raises; True when the file holds it."""
    try:
        if dist is None:
            env = os.environ.get('HERMES_WEB_DIST')
            if env:
                dist = Path(env)
            else:
                import sys as _sys
                ws = _sys.modules.get('hermes_cli.web_server')
                dist = Path(getattr(ws, 'WEB_DIST')) if ws is not None and getattr(ws, 'WEB_DIST', None) else None
        if dist is None:
            return False
        f = Path(dist) / 'index.html'
        html = f.read_text(encoding='utf-8')
        if not LANG_MARK.search(html):
            return False
        new = bake(html, language)
        return new == html or _write_atomic(f, new)
    except Exception:
        return False


def apply(html, block=None, language=None):
    """Qosha's block at the top of <head> (right after the charset) and its loading screen at the top of <body>."""
    block = BLOCK_FILE.read_text(encoding='utf-8') if block is None else block
    head, body = block.split(SPLIT, 1)
    head, body = head.strip(), body.strip()
    if not (head.startswith(HEAD[0]) and head.endswith(HEAD[1]) and body.startswith(BODY[0]) and body.endswith(BODY[1])):
        raise ValueError('first-paint block is not marked')
    html = strip(html)
    html, n = re.subn(r'(<meta charset="[^"]*"\s*/?>)', lambda m: m.group(1) + '\n    ' + head, html, count=1, flags=re.I)
    if not n:
        html, n = re.subn(r'(<head[^>]*>)', lambda m: m.group(1) + '\n    ' + head, html, count=1, flags=re.I)
    html, m = re.subn(r'(<body[^>]*>)', lambda x: x.group(1) + '\n    ' + body, html, count=1, flags=re.I)
    if not n or not m:
        raise ValueError('index.html has no <head> or <body>')
    # nothing of the engine's may come before it: no script, stylesheet or preload above Qosha's block
    top = html[:html.index(HEAD[0])]
    if re.search(r'<script|<link[^>]+rel="(?:stylesheet|modulepreload|preload)"|<style', top, flags=re.I):
        raise ValueError('an engine script or stylesheet sits above the first-paint block')
    return bake(html, language)


# The engine's built screens name it in places that can reach the page before Qosha's own words load (hidden behind the
# loading screen, but in the page): the brand string in every language (app.brand "Hermes Agent"), the sidebar logo
# ("Hermes" / "Agent" on two lines), the default theme's name and description, the shared-metrics banner, the side
# panel's update button. Swapped in the shipped copy at install (orchestrator, 22 Nov 2026: "the first byte served is
# already Qosha ... no 'Hermes' in the title, the DOM or the screenshot text"). Any of the three JS quotes (Gemini
# fp15 F3); each pattern anchored to its own key or shape (F10). Idempotent; a missing file or pattern is skipped (a
# later engine may have changed them). Text a person reads later on other pages stays index.js's job (its sweep).
_Q = r'([`"\'])'
_K = r'(?<![\w$])'          # a whole property name, not the end of a longer one (GPT fp15 r2 F10)
ASSET_SWAPS = [
    (re.compile(_K + r'(app:\{brand:)' + _Q + r'Hermes Agent\2(,brandShort:)\2HA\2'), r'\1\2Qosha\2\3\2Q\2'),
    (re.compile(_Q + r'Hermes\1,(\(0,[\w$]+\.jsx\)\(\1br\1,\{\}\)),\1Agent\1'), r'\1Qosha\1,\2,\1\1'),
    (re.compile(_K + r'((?:label|description):)' + _Q + r'Hermes Teal'), r'\1\2Qosha Teal'),
    (re.compile(_K + r'(description:)' + _Q + r'Classic dark teal \u2014 the canonical Hermes look\2'),
     '\\1\\2Classic dark teal \u2014 the canonical Qosha look\\2'),
    # (1.20.14 and earlier installs already say "Help improve Qosha?": the same title for them; GPT ep18-05)
    (re.compile(_K + r'((?:sharedMetricsTitle:|sharedMetricsTitle\?\?))' + _Q + r'Help improve (?:Hermes|Qosha)\?\2'), r'\1\2Help improve the AI engine Qosha runs on?\2'),
    # the side panel's update button, in every language: the engine's name wherever it sits in the value (GPT r2 F3)
    (re.compile(_K + r'((?:updateHermes|updateHermesConfirmTitle|updatingHermes):)' + _Q + r'((?:\\.|(?!\2)[^\\])*?)Hermes'),
     r'\1\2\3Qosha'),
    # the name a new Telegram bot gets from the Channels page (shown to the person in Telegram)
    (re.compile(_K + r'(bot_name:)' + _Q + r'Hermes Agent\2'), r'\1\2Qosha\2'),
    # the engine maker's credit in the side panel's footer, every language (orchestrator, 22 Nov 2026: P0)
    (re.compile(_K + r'(footer:\{org:)' + _Q + r'Nous Research\2'), r'\1\2Qosha AI\2'),
    # 22 Nov 2026, the council (Gemini D12): the maker's name elsewhere in the screens. The metrics banner tells the
    # truth about who receives the counts (the engine's makers), without their name.
    (re.compile(_K + r'(label:)' + _Q + r'Nous Blue\2'), r'\1\2Qosha Blue\2'),
    (re.compile(_K + r'(description:)' + _Q + r'Light mode \u2014 vivid Nous-blue accents'), '\\1\\2Light mode \u2014 vivid blue accents'),
    (re.compile(_K + r'((?:sharedMetricsShare:|sharedMetricsShare\?\?))' + _Q + r'Share with Nous\2'), r'\1\2Share with the engine makers\2'),
    (re.compile(_K + r'((?:sharedMetricsBody:|sharedMetricsBody\?\?))' + _Q + r'((?:\\.|(?!\2)[^\\])*?)Sharing sends them to Nous once a day\.'),
     r'\1\2\3Sharing sends them once a day to the makers of the AI engine Qosha runs on.'),
    (re.compile(_K + r'((?:restartGatewayConfirmMessage:|restartGatewayConfirmMessage\?\?))' + _Q + r'This restarts the Hermes gateway process\.'),
     r'\1\2This restarts the Qosha background service.'),
    (re.compile(_K + r'((?:catalogHint:|catalogHint\?\?))' + _Q + r'Curated, Nous-reviewed plugins'), r'\1\2Curated, reviewed plugins'),
    (re.compile(_K + r'(children:)' + _Q + r'Browse Nous-approved MCP servers'), r'\1\2Browse approved MCP servers'),
    # links to the engine's docs and its maker's site (the metrics banner's "Details", the docs and plugin links;
    # Gemini ep18 F3): no destination that shows the engine's or maker's name. The maker's AI provider portal
    # (portal.nousresearch.com) is left for the open provider decision.
    # about:blank, not "#": the same address feeds the Docs page's iframe, and "#" opened another dashboard (GPT/Gemini r2)
    (re.compile(_Q + r'https?://(?:hermes-agent\.)?nousresearch\.com(?:/[^`"\'\s]*)?\1'), r'\1about:blank\1'),
    # the achievements' share text, every language: the engine's name and its symbol
    (re.compile(_K + r'(tweet_text:)' + _Q + r'((?:\\.|(?!\2)[^\\])*?)Hermes Agent(?: \u2624)?'), r'\1\2\3Qosha'),
]


def _write_atomic(f, text):
    """The new text in a fresh, exclusively created sibling temp file (mkstemp: no fixed name another writer or a
    planted link could share; GPT fp15 r2 F11/R2-2), then swapped in (os.replace): a reader never sees a half-written
    file, a failed write leaves the old file whole (Gemini fp15 F2). A file held open on Windows gets a few retries."""
    try:
        fd, tmp = tempfile.mkstemp(dir=str(f.parent), prefix='.%s.' % f.name, suffix='.qosha-tmp')
    except OSError:
        return False
    tmp = Path(tmp)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', newline='') as h:
            h.write(text)
            h.flush()
            os.fsync(h.fileno())
        for i in range(5):
            try:
                os.replace(tmp, f)
                return True
            except PermissionError:
                time.sleep(0.2 * (i + 1))
        return False
    except OSError:
        return False
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass


def brand_assets(dist):
    """Swap the engine's brand words in the built screens (assets/*.js). Returns how many swaps were written. Never
    raises: a file it cannot read or replace is left exactly as it was (the page's title and loading screen come from
    index.html, which the installer writes either way)."""
    n = 0
    try:
        files = sorted((Path(dist) / 'assets').glob('*.js'))
    except OSError:
        return 0
    for f in files:
        try:
            if f.is_symlink() or not f.is_file():
                continue
            with open(f, encoding='utf-8', newline='') as h:   # bytes kept as they are (no line-end change on Windows)
                text = h.read()
        except (OSError, UnicodeDecodeError):
            continue
        new, k = text, 0
        for rx, repl in ASSET_SWAPS:
            new, c = rx.subn(repl, new)
            k += c
        if new != text and _write_atomic(f, new):
            n += k
    try:                                     # the engine's own screens in pt-BR (never in the way of the brand swaps)
        if pt_engine_web(dist) == 'replaced':
            n += 1
    except Exception:
        pass
    return n


# ---- the engine's own screens in Brazilian Portuguese (pt-BR v1, 22 Nov 2026; Ren: "Translation now, extras later") ----
# The engine's dashboard keeps its texts in its built bundle, one object per language (web/src/i18n), and reads the
# language from this browser ('<engine>-locale', set by first-paint.html from Qosha's one setting). Qosha's pt-BR
# (i18n/engine-web-pt-br.json, plus the few texts built by a function in i18n/engine-web-pt-br.fns.js) takes the place
# of the bundle's own Portuguese object. Only that object changes: every other language, English included, keeps its
# bytes. A bundle whose shape is not found is left as it is (reported, never half-written).
PT_MARK = '/*qosha-pt-br*/'
_PT_DIR = Path(__file__).resolve().parent / 'i18n'


def _js_end(t, i):
    """Index just after the object/array literal that opens at t[i] ('{' or '['), across strings and template
    literals (with their ${...} parts); None when it does not close."""
    stack, n, q = [], len(t), None
    j = i
    while j < n:
        c = t[j]
        if q is not None:                       # inside a string
            if c == '\\':
                j += 2
                continue
            if q == '`' and c == '$' and j + 1 < n and t[j + 1] == '{':
                stack.append('${')
                q = None
                j += 2
                continue
            if c == q:
                q = None
            j += 1
            continue
        if c in '"\'`':
            q = c
        elif c in '{[(':
            stack.append(c)
        elif c in '}])':
            if not stack:
                return None
            top = stack.pop()
            if top == '${':
                q = '`'                           # back inside the template literal
            if not stack:
                return j + 1
        j += 1
    return None


def _pt_tree():
    import json as _json
    flat = _json.loads((_PT_DIR / 'engine-web-pt-br.json').read_text(encoding='utf-8'))
    fns = {}
    for ln in (_PT_DIR / 'engine-web-pt-br.fns.js').read_text(encoding='utf-8').splitlines():
        m = re.match(r'^  ("(?:[^"\\]|\\.)*"): (.+),$', ln)
        if m:
            fns[_json.loads(m.group(1))] = m.group(2)
    tree = {}
    for k, v in list(flat.items()) + [(k, ('fn', v)) for k, v in fns.items()]:
        cur, parts = tree, k.split('.')
        for x in parts[:-1]:
            cur = cur.setdefault(x, {})
        cur[parts[-1]] = v
    return tree


def _pt_literal(node):
    import json as _json
    if isinstance(node, tuple):
        return node[1]                                    # a function's source, as written in the fns file
    if isinstance(node, str):
        return _json.dumps(node, ensure_ascii=False).replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')
    keys = list(node)
    if keys and all(k.isdigit() for k in keys) and sorted(int(k) for k in keys) == list(range(len(keys))):
        return '[' + ','.join(_pt_literal(node[str(i)]) for i in range(len(keys))) + ']'
    out = []
    for k in keys:
        name = k if re.match(r'^[A-Za-z_$][\w$]*$', k) else _json.dumps(k)
        out.append('%s:%s' % (name, _pt_literal(node[k])))
    return '{' + ','.join(out) + '}'


def pt_engine_web(dist):
    """Qosha's pt-BR in place of the engine bundle's Portuguese object. Returns 'replaced', 'same' or 'skipped: …'."""
    try:
        new_obj = PT_MARK + _pt_literal(_pt_tree())
    except Exception as e:
        return 'skipped: pt-BR texts unreadable (%s)' % type(e).__name__
    try:
        files = sorted((Path(dist) / 'assets').glob('*.js'))
    except OSError:
        return 'skipped: no assets'
    for f in files:
        try:
            if f.is_symlink() or not f.is_file():
                continue
            with open(f, encoding='utf-8', newline='') as h:
                t = h.read()
        except (OSError, UnicodeDecodeError):
            continue
        m = re.search(r'\{en:[\w$]+,zh:[\w$]+,[^{}]*\}', t)
        if not m:
            continue
        pv = re.search(r'[{,]pt:([\w$]+)[,}]', m.group(0))
        if not pv:
            return 'skipped: the language table has no Portuguese'
        d = re.search(r'(?:^|[,;\s])' + re.escape(pv.group(1)) + r'=(' + re.escape(PT_MARK) + r')?\{common:', t)
        if not d:
            return 'skipped: the Portuguese object was not found'
        start = d.end() - len('{common:')
        end = _js_end(t, start)
        if end is None:
            return 'skipped: the Portuguese object does not close'
        begin = start - (len(PT_MARK) if d.group(1) else 0)
        if t[begin:end] == new_obj:
            return 'same'
        if not _write_atomic(f, t[:begin] + new_obj + t[end:]):
            return 'skipped: could not write %s' % f.name
        return 'replaced'
    return 'skipped: no language table in the bundle'
