/* Qosha's screens in the person's language (contract qosha-ptbr §2.B.3).
   ONE source of truth: the engine's display.language in config.yaml, read from GET /api/plugins/qosha/language (the
   Settings switch, the installer and the chat all write that key). The browser's own language is never used; the
   browser's storage only keeps a copy for when the dashboard does not answer.
   Texts: dashboard/i18n/en.json and pt-br.json, flat {"key": "text"} objects. A key may be the English text itself.
   Keys with {placeholders} are also patterns: "{n} open tasks" turns "3 open tasks" into "3 tarefas abertas", and each
   piece caught by a placeholder is itself looked up ("Email, 2 skills" -> "E-mail, 2 habilidades").
   A missing key falls back to English. In English nothing on the page is touched (the screens stay byte for byte).
   Functions: QoshaI18n.lang ("en" | "pt-br"), .t(key, vars), .tx(englishText), .translate(root), .watch(root),
        .setLanguage(lang) (Settings; reloads the whole window). Loaded synchronously, so a page's own scripts can use
        it at once. */
(function () {
  'use strict';
  // No animated hand-over between whole pages (ptb8 H7-16). The browser may start one when the engine's styles ask for
  // it, and then drop it ("Transition was aborted because of invalid state ... Page already revealed"): an error nobody
  // answered, on the page the person sees. Every page of Qosha loads this file first, so each one skips such a
  // hand-over on both sides of a navigation, and answers its outcome itself. Nothing on the page changes.
  if (!window.__qoshaNoPageTransition) {
    window.__qoshaNoPageTransition = true;
    var quiet = function (ev) {
      var vt = ev && ev.viewTransition;
      if (!vt) return;
      ['ready', 'finished', 'updateCallbackDone'].forEach(function (k) {
        try { if (vt[k] && typeof vt[k].then === 'function') vt[k].then(null, function () { /* skipped on purpose */ }); } catch (e) { /* none */ }
      });
      try { if (typeof vt.skipTransition === 'function') vt.skipTransition(); } catch (e) { /* already over */ }
    };
    try {
      window.addEventListener('pageswap', quiet);
      window.addEventListener('pagereveal', quiet);
    } catch (e) { /* an older browser: it makes no such hand-over */ }
  }
  if (window.QoshaI18n && window.QoshaI18n.loaded) return;
  var BASE = '/dashboard-plugins/qosha/i18n/';
  var LANGS = {'en': 1, 'pt-br': 1};

  function token() {
    try {
      var f = window;
      for (var i = 0; i < 8 && f; i++) {
        var t = f.__HERMES_SESSION_TOKEN__;
        if (typeof t === 'string' && /^[\x21-\x7e]+$/.test(t)) return t;
        if (!f.parent || f.parent === f) break;
        f = f.parent;
      }
    } catch (e) { /* no readable dashboard parent */ }
    return null;
  }
  function getSync(url, auth) {
    try {
      var x = new XMLHttpRequest();
      x.open('GET', url, false);
      if (auth) { var t = token(); if (t) x.setRequestHeader('X-Hermes-Session-Token', t); }
      x.send(null);
      if (x.status >= 200 && x.status < 300) return x.responseText;
    } catch (e) { /* not answering */ }
    return null;
  }
  function fromParent(name) {
    try {
      var f = window;
      for (var i = 0; i < 8; i++) {
        if (!f.parent || f.parent === f) break;
        f = f.parent;
        if (f.QoshaI18n && f.QoshaI18n.loaded && f.QoshaI18n[name] != null) return f.QoshaI18n[name];
      }
    } catch (e) { /* another origin */ }
    return null;
  }
  function readLanguage() {
    var lang = fromParent('lang');
    if (lang && LANGS[lang]) return lang;
    var txt = getSync('/api/plugins/qosha/language', true);
    try { lang = JSON.parse(txt).language; } catch (e) { lang = null; }
    if (lang && LANGS[lang]) {
      try { window.localStorage.setItem('qosha.language', lang); } catch (e) { /* storage off */ }
      return lang;
    }
    try { lang = window.localStorage.getItem('qosha.language'); } catch (e) { lang = null; }
    return lang && LANGS[lang] ? lang : 'en';
  }
  function readCatalog(lang) {
    var c = fromParent('cat_' + lang.replace('-', '_'));
    if (c) return c;
    var txt = getSync(BASE + lang + '.json', false);
    try { c = JSON.parse(txt); } catch (e) { c = null; }
    return c && typeof c === 'object' ? c : {};
  }

  var QI = window.QoshaI18n = {};
  QI.lang = readLanguage();
  QI.cat_en = readCatalog('en');
  QI.cat_pt_br = QI.lang === 'pt-br' ? readCatalog('pt-br') : {};
  var CAT = QI.lang === 'pt-br' ? QI.cat_pt_br : QI.cat_en, EN = QI.cat_en;
  document.documentElement.setAttribute('data-qosha-lang', QI.lang);
  if (QI.lang === 'pt-br') document.documentElement.setAttribute('lang', 'pt-BR');

  function fill(s, vars) {
    if (!vars) return s;
    return String(s).replace(/\{([A-Za-z0-9_]+)\}/g, function (m, k) { return vars[k] != null ? String(vars[k]) : m; });
  }
  // every text this file has already put in the person's language. Writing a translated label or text back into the
  // page makes the watcher see it again; it is never looked up a second time, so the person's own data inside it (an
  // email subject "Save", a conversation called "Home") is never caught by a looser pattern ("{a}: {b}") on that pass
  var MADE = Object.create(null), MADE_N = 0;
  function made(s) {
    if (MADE_N > 20000) { MADE = Object.create(null); MADE_N = 0; }
    if (!(s in MADE)) { MADE[s] = 1; MADE_N++; }
    return s;
  }
  // t(key, vars): the text of a key in the page's language (English when the key is missing in pt-BR)
  QI.t = function (key, vars) {
    var s = CAT[key];
    if (s == null) s = EN[key];
    if (s == null) s = key;
    var out = fill(s, vars);
    if (QI.lang === 'pt-br' && CAT[key] != null && CAT[key] !== EN[key]) made(out);
    return out;
  };
  // the English text -> pt-BR map (en.json value -> pt-br.json value of the same key), and the patterns
  var EXACT = Object.create(null), PATTERNS = [];
  if (QI.lang === 'pt-br') {
    Object.keys(EN).forEach(function (k) {
      var en = EN[k], pt = CAT[k];
      if (typeof en !== 'string' || typeof pt !== 'string' || !en) return;
      if (/\{[A-Za-z0-9_]+\}/.test(en)) {
        var names = [];
        // {n}, {n2}, {count}: a number only; any other placeholder: any text (itself looked up again)
        var rx = '^' + en.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\\\{([A-Za-z0-9_]+)\\\}/g, function (m, n) {
          names.push(n); return /^(n\d?|count)$/.test(n) ? '([0-9][0-9.,]*)' : '([\\s\\S]+?)';
        }) + '$';
        // the pattern's fixed words: a text that lacks one of them can't match, and is never run through the regular
        // expression (long texts against patterns with several open pieces are slow to rule out that way)
        var lits = en.split(/\{[A-Za-z0-9_]+\}/);
        var pre = lits[0], suf = lits.length > 1 ? lits[lits.length - 1] : '';
        lits = lits.filter(function (x) { return x; });
        try { PATTERNS.push({rx: new RegExp(rx), names: names, pt: pt, len: en.length, lits: lits, pre: pre, suf: suf}); } catch (e) { /* not a pattern */ }
      } else if (!(en in EXACT)) {
        EXACT[en] = pt;
      }
    });
    PATTERNS.sort(function (a, b) { return b.len - a.len; });
  }
  // placeholders that always hold the person's own data (an email's subject and recipient, a site and its address, a
  // name or title they gave a file, folder, project, automation or conversation): shown exactly as written, never
  // looked up again (ptb7 U1-U5: a folder named "Home" stays "Home", a subject "Save" stays "Save")
  var DATA_SLOTS = {subject: 1, subj: 1, to: 1, site: 1, url: 1, email: 1, host: 1, path: 1, name: 1, title: 1, label: 1, file: 1};
  // a text already looked up gives the same answer (the catalog does not change while the page is open)
  var SEEN = Object.create(null), SEEN_N = 0;
  // the engine's screens say the engine's name until the main release's brand sweep renames it, and that may run after
  // this lookup: a whole catalog sentence written with "Hermes" where Qosha's English says "Qosha" is the same sentence
  // (v1, 23 Nov 2026: "Connect Hermes to Google Chat via Cloud Pub/Sub." fell to the "Connect {app}" pattern). Whole
  // sentences only: a name the person typed ("Hermes Pardini") is never a catalog sentence.
  var QNAME = /\bHermes\b/g;
  function piece(s, depth) {
    if (s in EXACT) return EXACT[s];
    if (s.indexOf('Hermes') >= 0) { var q = s.replace(QNAME, 'Qosha'); if (q in EXACT) return EXACT[q]; }
    if (depth === 0 && s in SEEN) return SEEN[s];
    var out = piece1(s, depth);
    if (depth === 0) {
      if (SEEN_N > 20000) { SEEN = Object.create(null); SEEN_N = 0; }
      SEEN[s] = out; SEEN_N++;
    }
    return out;
  }
  function fits(p, s) {
    if (p.pre && s.slice(0, p.pre.length) !== p.pre) return false;
    if (p.suf && s.slice(s.length - p.suf.length) !== p.suf) return false;
    for (var k = 0; k < p.lits.length; k++) if (s.indexOf(p.lits[k]) < 0) return false;
    return true;
  }
  function piece1(s, depth) {
    if (depth > 2) return s;
    for (var i = 0; i < PATTERNS.length; i++) {
      var p = PATTERNS[i];
      if (!fits(p, s)) continue;
      var m = p.rx.exec(s);
      if (!m) continue;
      var vars = {};
      for (var j = 0; j < p.names.length; j++) vars[p.names[j]] = DATA_SLOTS[p.names[j]] ? m[j + 1] : piece(m[j + 1], depth + 1);
      return fill(p.pt, vars);
    }
    return s;
  }
  // tx(text): the pt-BR form of an English text Qosha shows (exact, or by pattern); the text itself in English
  QI.tx = function (text) {
    if (QI.lang !== 'pt-br' || text == null) return text;
    var s = String(text), lead = /^\s*/.exec(s)[0], trail = /\s*$/.exec(s)[0], core = s.slice(lead.length, s.length - trail.length);
    if (!core) return s;
    if (core in MADE) return s;               // already in the person's language (see MADE above)
    // the text as it is first: a name the person typed keeps every character, doubled spaces, a tab, a no-break or
    // ideographic space included (ptb8 H7-4: flattening first turned “Q4  plan” into “Q4 plan” in its questions)
    var out = piece(core, 0);
    if (out === core && /\s\s|[\n\t]/.test(core)) {   // text written across lines in a page: looked up as it reads
      var flat = core.replace(/\s+/g, ' ');
      if (flat in MADE) return s;
      var f2 = piece(flat, 0);
      if (f2 !== flat) return lead + made(f2) + trail;
    }
    if (out === core) {
      // a whole sentence made of known sentences ("A. B.") is put together from its parts
      var parts = core.split(/(?<=[.!?])\s+(?=[A-Z])/);
      if (parts.length > 1) {
        var all = true;
        out = parts.map(function (x) { var y = piece(x, 0); if (y === x) all = false; return y; }).join(' ');
        if (!all) out = core;
      }
    }
    return out === core ? s : lead + made(out) + trail;
  };

  var SKIP = /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|TEXTAREA|CODE|PRE)$/;
  var ATTRS = ['title', 'aria-label', 'placeholder', 'alt', 'aria-description', 'data-tip'];
  // own: the element's own tag doesn't count (a text box's placeholder and title are labels; its value is the person's
  // and is never touched)
  function skipped(el, own) {
    for (var n = el; n && n.nodeType === 1; n = n.parentElement) {
      if ((!own || n !== el) && SKIP.test(n.tagName)) return true;
      if (n.isContentEditable) return true;
      if (n.hasAttribute('data-qosha-own') || n.hasAttribute('data-qosha-no-i18n')) return true;
      if (n.classList && (n.classList.contains('cm-editor') || n.classList.contains('monaco-editor'))) return true;
    }
    return false;
  }
  function fixNode(n) {
    var v = n.nodeValue;
    if (!v || !/[A-Za-z]/.test(v) || !n.parentElement || skipped(n.parentElement)) return;
    var nv = QI.tx(v);
    if (nv !== v) n.nodeValue = nv;
  }
  function fixAttrs(el) {
    if (!el.getAttribute || skipped(el, true)) return;
    for (var i = 0; i < ATTRS.length; i++) {
      var v = el.getAttribute(ATTRS[i]);
      if (!v || !/[A-Za-z]/.test(v)) continue;
      var nv = QI.tx(v);
      if (nv !== v) el.setAttribute(ATTRS[i], nv);
    }
    if (el.tagName === 'INPUT' && /^(button|submit|reset)$/i.test(el.type || '') && el.value) {
      var nvv = QI.tx(el.value);
      if (nvv !== el.value) el.value = nvv;
    }
  }
  // translate(root): every text and label under root, once
  QI.translate = function (root) {
    if (QI.lang !== 'pt-br') return;
    root = root || document.documentElement;
    try {
      if (root.nodeType === 3) { fixNode(root); return; }
      var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      while (w.nextNode()) fixNode(w.currentNode);
      if (root.nodeType === 1) fixAttrs(root);
      if (root.querySelectorAll) root.querySelectorAll('*').forEach(function (el) {
        fixAttrs(el);
        if (el.shadowRoot) { QI.translate(el.shadowRoot); if (observeShadow) observeShadow(el.shadowRoot); }
      });
      var tt = document.title, nt = QI.tx(tt);
      if (nt !== tt) document.title = nt;
    } catch (e) { /* a page part that can't be read stays as it is */ }
  };
  // watch(root): translate now, and again whatever the page adds or changes later.
  // A page part drawn in its own (open) shadow root, like the Home composer, is redrawn there where the page's observer
  // can't see: each such root gets its own observer, whether it is found while translating or made later (attachShadow
  // below; a custom element defined after the page has drawn makes its root with no change the page's observer sees).
  var watching = false, observeShadow = null, shadowsSeen = [];
  QI.watch = function (root) {
    if (QI.lang !== 'pt-br' || watching) return;
    watching = true;
    root = root || document.documentElement;
    var queued = [], pending = false;
    function flush() {
      pending = false;
      var list = queued; queued = [];
      list.forEach(function (n) { if (n.isConnected !== false) QI.translate(n); });
    }
    function changed(muts) {
      muts.forEach(function (m) {
        if (m.type === 'characterData') fixNode(m.target);
        else if (m.type === 'attributes') fixAttrs(m.target);
        else m.addedNodes.forEach(function (n) { queued.push(n); });
      });
      if (queued.length && !pending) { pending = true; (window.queueMicrotask || setTimeout)(flush); }
    }
    function observe(r) {
      if (!r || r.__qoshaI18nWatched) return;
      try {
        new MutationObserver(changed).observe(r, {childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS});
        r.__qoshaI18nWatched = true;
      } catch (e) { /* this part was translated once */ }
    }
    observeShadow = observe;
    QI.translate(root);
    shadowsSeen.splice(0).forEach(function (sr) { QI.translate(sr); observe(sr); });
    try {
      observe(root);
      var titleEl = document.querySelector('title');
      if (titleEl) new MutationObserver(function () { var tt = document.title, nt = QI.tx(tt); if (nt !== tt) document.title = nt; })
        .observe(titleEl, {childList: true, characterData: true, subtree: true});
    } catch (e) { /* no observer: the page was translated once */ }
  };
  // The switch reloads the whole window, and a question waiting in a chat does not survive a reload: the engine
  // withdraws it when the chat's connection closes (close_on_disconnect, as 1.19.13 sets it), and the chat page stays
  // loaded behind Settings. So a switch never approves, runs or silently loses a step (contract qosha-ptbr §0 run
  // ptb6): while any Qosha page of this window holds a question that waits for the person's own answer, the switch is
  // REFUSED. Nothing is saved, nothing reloads, the card stays exactly as it is and still answers; the page that holds
  // it says why next to the card, and the caller (Settings) gets a plain sentence in the page's language (err.plain,
  // err.code 'waiting'). A page says what it holds with window.QoshaLanguageHold = {waiting(): number, note(text)}.
  function topWindow() {
    var top = window;
    try { while (top.parent && top.parent !== top && top.parent.location.origin === window.location.origin) top = top.parent; } catch (e) { /* stop here */ }
    return top;
  }
  function holders() {
    var out = [];
    (function walk(w, depth) {
      try {
        var h = w.QoshaLanguageHold;
        if (h && typeof h.waiting === 'function' && h.waiting() > 0) out.push(h);
      } catch (e) { /* another origin, or a page that is going away: it holds nothing of ours */ }
      if (depth >= 6) return;
      var n = 0;
      try { n = w.frames.length; } catch (e) { n = 0; }
      for (var i = 0; i < n; i++) { var c = null; try { c = w.frames[i]; } catch (e) { c = null; } if (c && c !== w) walk(c, depth + 1); }
    })(topWindow(), 0);
    return out;
  }
  function tell(list, text) { list.forEach(function (h) { try { if (typeof h.note === 'function') h.note(text); } catch (e) { /* the card itself is untouched */ } }); }
  // Settings' language switch: writes display.language (the one place it lives), then the whole window reloads
  QI.setLanguage = function (lang) {
    if (!LANGS[lang]) return Promise.reject(new Error('bad language'));
    var held = holders();
    if (held.length) {
      tell(held, QI.t('The language was not changed, because this step is still waiting for your answer. Changing the language reloads Qosha, and the step would be withdrawn. Answer it first, then change the language.'));
      var err = new Error('language not changed: a step is waiting for an answer');
      err.code = 'waiting';
      err.plain = QI.t('The language was not changed: a step in Chat is still waiting for your answer. Open Chat and answer it first, then change the language here.');
      return Promise.reject(err);
    }
    var headers = {'Content-Type': 'application/json'};
    var t = token(); if (t) headers['X-Hermes-Session-Token'] = t;
    return fetch('/api/plugins/qosha/language', {method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: headers,
                                                 body: JSON.stringify({language: lang})}).then(function (r) {
      if (!r.ok) throw new Error('language not saved (' + r.status + ')');
      try { window.localStorage.setItem('qosha.language', lang); } catch (e) { /* storage off */ }
      // a question that arrived while the setting was being saved is not lost either: the language is saved, but
      // nothing reloads by itself; both places say so, and the screens follow at the person's own next reload
      var late = holders();
      if (late.length) {
        tell(late, QI.t('The new language is saved. Answer this step first; Qosha’s screens change the next time the page is reloaded.'));
        return {deferred: true, plain: QI.t('The new language is saved. A step in Chat is still waiting for your answer: answer it first, then reload this page to see Qosha in the new language.')};
      }
      topWindow().location.reload();
      return {deferred: false};
    });
  };
  // the speech language for voice and Talk: the setting's, never the browser's
  QI.speech = function () { return QI.lang === 'pt-br' ? 'pt-BR' : 'en-US'; };
  // dates and times a page writes with the browser's default locale ("toLocaleDateString([], ...)") follow the setting
  // too: in pt-BR they are written the Brazilian way ("ter., 3 de nov."). A locale the page names itself is kept.
  if (QI.lang === 'pt-br') {
    try {
      var DP = Date.prototype;
      ['toLocaleString', 'toLocaleDateString', 'toLocaleTimeString'].forEach(function (m) {
        var f = DP[m];
        if (typeof f !== 'function' || f.qoshaLang) return;
        var w = function (locales, opts) {
          var none = locales == null || (Array.isArray(locales) && !locales.length);
          return f.call(this, none ? 'pt-BR' : locales, opts);
        };
        w.qoshaLang = true;
        DP[m] = w;
      });
    } catch (e) { /* dates stay in the browser's form */ }
  }
  // every open shadow root a Qosha page makes from now on is watched too (see watch above); in English nothing changes
  if (QI.lang === 'pt-br' && !window.__QOSHA_SHELL__) {
    try {
      var EP = Element.prototype, attach = EP.attachShadow;
      if (typeof attach === 'function' && !attach.qoshaLang) {
        var wrapped = function (init) {
          var sr = attach.apply(this, arguments);
          try {
            if (sr && init && init.mode === 'open') { if (observeShadow) observeShadow(sr); else shadowsSeen.push(sr); }
          } catch (e) { /* that part stays as drawn */ }
          return sr;
        };
        wrapped.qoshaLang = true;
        EP.attachShadow = wrapped;
      }
    } catch (e) { /* shadow roots are translated when found */ }
  }
  QI.loaded = true;
  // the engine shell (index.js) translates inside its own text pass; every other page is watched here
  if (QI.lang === 'pt-br' && !window.__QOSHA_SHELL__) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { QI.watch(document.documentElement); });
    else QI.watch(document.documentElement);
  }
})();
