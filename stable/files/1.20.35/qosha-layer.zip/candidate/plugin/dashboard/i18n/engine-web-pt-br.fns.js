// The engine dashboard's texts that are built by a function (web/src/i18n/en.ts), in Brazilian Portuguese: one entry
// per key, the same parameters as the English. Read as text by first_paint.py (pt_engine_web), never run on its own.
({
  "pluginsPage.updateAllDone": (updated, needsReview, failed) => `Atualizados ${updated}, para revisar ${needsReview}, com falha ${failed}`,
  "pluginsPage.autoUpdateDesc": (hours) => `Aplica as atualizações de plugins automaticamente quando o gateway verifica (a cada ${hours} h). O código atualizado é carregado nas novas sessões.`,
  "pluginsPage.updateConsentBody": (name, sha) => `A nova versão fixada no catálogo de ${name} (${sha}) acrescenta pontos de acesso que a versão instalada não tem. Aplique só se você confia neles:`,
  "pluginsPage.updateScanBody": (name, count) => `A verificação de segurança apontou ${count} problema${count === 1 ? "" : "s"} no novo código de ${name}. Atualize mesmo assim só se você confia na origem:`,
  "pluginsPage.updateScanBlocked": (name) => `A verificação de segurança classificou o novo código de ${name} como perigoso. A atualização não foi aplicada.`,
})
