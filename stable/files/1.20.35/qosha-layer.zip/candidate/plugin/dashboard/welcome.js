/* The welcome questions (backlog item 7; Ren 17 Nov 2026, cards 16:35 and his words 16:38: "the prompt can be on the
   home, and if the interview chatbox is created as a popup tile inside of it even better").
   On Home, once an AI account of the person's own is connected: a small prompt card ("May I ask you 6 quick
   questions?" Start / Later / No thanks). Start opens the interview as a pop-up tile over Home: a small chat with
   Qosha's questions, the person's answers, chips under each question, a message box with the microphone (the shared
   dictation, pages/qosha-voice.js), progress dots, Skip / Finish later, and at the end the editable "Here is what I
   will remember" with Save to memory. Nothing reaches Qosha's memory before Save (welcome_api.py writes it with the
   engine's own memory store). A person whose memory is already filled (moved from cloud Qosha) gets "Review what I
   know about you" instead: the same editable summary. Later is offered once more, then only on request ("Qosha,
   interview me again"). Closed only by the person (X or Escape = Finish later, or after Save). English or Portuguese
   (Brazil) from Qosha's language setting. Text only, never HTML from data. Loaded by index.html (Home). */
(function () {
  'use strict';
  if (window.QoshaWelcome) return;
  var API = '/api/plugins/qosha/welcome';
  // the pop-up covers the whole app, as the Connect-your-AI panel does: inside the dashboard it lives in the top window
  var TOPD = document; try { if (window.top !== window && window.top.location.origin === location.origin) TOPD = window.top.document; } catch (e) { TOPD = document; }
  var ICON_URL = new URL('./assets/brand/icons/qosha-icon.svg', location.href).href;
  var DRAFT = 'qosha.welcome.draft.v1';
  // the language is Qosha's own setting (display.language, read by qosha-i18n.js), never the browser's (contract
  // qosha-ptbr §2.B.1)
  var I18N = window.QoshaI18n;
  if (!I18N || !I18N.loaded) { try { I18N = window.parent && window.parent.QoshaI18n; } catch (e) { I18N = null; } }
  var PT = !!(I18N && I18N.loaded && I18N.lang === 'pt-br');
  try { var f = new URLSearchParams(location.search).get('qlang'); if (f === 'pt') PT = true; if (f === 'en') PT = false; } catch (e) {}

  var T = PT ? {
    p_b: 'Posso fazer 6 perguntas rápidas?', p_s: 'Uns 2 minutos, para eu não começar do zero. Pule o que quiser; mude as respostas depois.',
    r_b: 'Quer revisar o que eu sei sobre você?', r_s: 'Eu já lembro algumas coisas. Veja, mude ou apague o que quiser.',
    start: 'Começar', review: 'Revisar', later: 'Depois', no: 'Não, obrigado', welcome: 'Boas-vindas', of: 'Pergunta {n} de 6',
    close: 'Fechar (guarda suas respostas)', send: 'Enviar', skip: 'Pular esta pergunta', fin: 'Terminar depois',
    ph: 'Digite sua resposta, ou toque no microfone e fale', ph_s: 'Digite, ou toque no microfone', intro: 'Ótimo. São 6 perguntas rápidas; pule o que quiser e mude qualquer resposta depois.',
    thanks: 'Obrigado, {n}.', skipped: 'Pulei esta.', sum_lead: 'Pronto, é isso. Isto é o que vou lembrar. Mude o que quiser antes de eu salvar.',
    rev_lead: 'Isto é o que eu já sei sobre você. Mude ou apague o que quiser, depois salve.', rev_alt: 'Responder as 6 perguntas',
    save: 'Salvar na memória', redo: 'Começar de novo', edit: 'Mudar', remove: 'Remover', ok: 'OK',
    note: 'Você pode ver e mudar tudo isso na página Memória, ou simplesmente me dizer: “Qosha, me entrevista de novo.”',
    saved: 'Salvo. Vou usar isso a partir da próxima conversa.', done: 'Fechar', saving: 'Salvando…', nothing: 'Nada para salvar ainda.',
    tz_sub: 'Uma configuração, lida deste computador', fromhere: '(deste computador)', bad_tz: 'Esse fuso horário não é conhecido.',
    err: 'Não foi possível salvar: ', empty: 'Nada para lembrar ainda. Responda uma pergunta ou feche.'
  } : {
    p_b: 'May I ask you 6 quick questions?', p_s: 'About 2 minutes, so I do not start from zero. Skip any; change the answers later.',
    r_b: 'Want to review what I know about you?', r_s: 'I already remember a few things. See, change or remove anything.',
    start: 'Start', review: 'Review', later: 'Later', no: 'No thanks', welcome: 'Welcome', of: 'Question {n} of 6',
    close: 'Close (keeps your answers)', send: 'Send', skip: 'Skip this question', fin: 'Finish later',
    ph: 'Type your answer, or press the mic and say it', ph_s: 'Type, or press the mic', intro: 'Great. Six quick questions; skip any, and change any answer later.',
    thanks: 'Thanks, {n}.', skipped: 'Skipped.', sum_lead: 'That is everything. Here is what I will remember. Change anything before I save it.',
    rev_lead: 'Here is what I already know about you. Change or remove anything, then save.', rev_alt: 'Answer the 6 questions instead',
    save: 'Save to memory', redo: 'Start over', edit: 'Change', remove: 'Remove', ok: 'OK',
    note: 'You can see and change all of this on the Memory page, or just tell me: “Qosha, interview me again.”',
    saved: 'Saved. I will use this from your next conversation on.', done: 'Close', saving: 'Saving…', nothing: 'Nothing to save yet.',
    tz_sub: 'A setting, read from this computer', fromhere: '(from this computer)', bad_tz: 'That time zone is not known.',
    err: 'Could not save: ', empty: 'Nothing to remember yet. Answer a question, or close.'
  };
  // the six questions; `key` is the label of the memory line (English, so a later redo finds and replaces it)
  var Q = PT ? [
    {key: 'Name', label: 'Nome', q: 'Como devo chamar você?', h: 'Só o primeiro nome já está ótimo.', groups: [], text: true, now: true},
    {key: 'Language and style', label: 'Idioma e estilo', q: 'Como devo falar com você?', h: 'Vou responder neste idioma e neste estilo, a não ser que você peça outro.',
      groups: [{t: 'Idioma', one: true, c: ['Português', 'English', 'Español', 'O mesmo da sua mensagem']}, {t: 'Estilo', one: true, c: ['Curto e direto', 'Simpático', 'Formal', 'Detalhado']}]},
    {key: 'Work', label: 'Trabalho', q: 'O que você faz, e em qual empresa?', h: 'Uma linha basta, por exemplo: “Tenho um estúdio de design com 5 pessoas.”',
      groups: [{one: true, c: ['Sou dono do negócio', 'Gerencio uma equipe', 'Vendas', 'Operações', 'Assessoro alguém']}], text: true},
    {key: 'Email', label: 'E-mail', q: 'Como posso ajudar com seus e-mails?', h: 'Escolha quantas quiser. Enviar sempre pede sua confirmação, a menos que você tenha escolhido Sempre permitir.',
      groups: [{c: ['Rascunhar respostas para eu revisar', 'Resumir, sem rascunhar', 'Separar e marcar o que importa', 'Só quando eu pedir', 'Ficar fora dos meus e-mails']}]},
    {key: 'Never', label: 'Nunca', q: 'Tem algo que eu nunca devo fazer?', h: 'Vou levar isso em conta sempre. Enviar, pagar, apagar ou compartilhar continua pedindo sua confirmação, a menos que você tenha escolhido Sempre permitir para esse tipo de ação.',
      groups: [{c: ['Nunca apagar e-mails ou arquivos', 'Nunca falar com clientes por mim', 'Nunca mexer na minha agenda', 'Nunca gastar dinheiro'], none: 'Nada por enquanto'}], text: true},
    {key: 'Important people', label: 'Pessoas importantes', q: 'Quem é mais importante para você?', h: 'Opcional. Diga algumas pessoas ou empresas cujas mensagens vêm primeiro.',
      groups: [], text: true, people: true}
  ] : [
    {key: 'Name', label: 'Name', q: 'What should I call you?', h: 'Your first name is fine.', groups: [], text: true, now: true},
    {key: 'Language and style', label: 'Language and style', q: 'How should I talk to you?', h: 'I will answer in this language and this style, unless you ask otherwise.',
      groups: [{t: 'Language', one: true, c: ['English', 'Português', 'Español', 'Same as your message']}, {t: 'Style', one: true, c: ['Short and direct', 'Friendly', 'Formal', 'Detailed']}]},
    {key: 'Work', label: 'Work', q: 'What do you do, and for which company?', h: 'One line is enough, for example: “I run a 5-person design studio.”',
      groups: [{one: true, c: ['I own the business', 'I manage a team', 'Sales', 'Operations', 'I assist someone']}], text: true},
    {key: 'Email', label: 'Email', q: 'How should I help with your email?', h: 'Pick any. Sending always asks you first, unless you chose Always allow for it.',
      groups: [{c: ['Draft replies for me to check', 'Summarize, don’t draft', 'Sort and flag what matters', 'Only when I ask', 'Keep out of my email']}]},
    {key: 'Never', label: 'Never', q: 'Is there anything I should never do?', h: 'I will keep this in mind every time. Sending, paying, deleting or sharing still asks you first, unless you chose Always allow for that kind of step.',
      groups: [{c: ['Never delete emails or files', 'Never contact clients for me', 'Never change my calendar', 'Never spend money'], none: 'Nothing for now'}], text: true},
    {key: 'Important people', label: 'Important people', q: 'Who matters most?', h: 'Optional. Name a few people or companies whose messages come first.',
      groups: [], text: true, people: true}
  ];
  var KEYS = Q.map(function (q) { return q.key; });

  var CSS = [
    '.qw-card{box-sizing:border-box;display:flex;align-items:center;gap:18px;flex-wrap:wrap;margin:20px 0;padding:20px 24px;border-radius:24px;border:1px solid #DCDBD4;background:#FFFFFF;color:#0B0B0B;',
    '  box-shadow:0 1px 2px rgba(11,11,11,.04),0 8px 28px rgba(11,11,11,.05);font-family:"Google Sans Flex","Helvetica Neue",Arial,sans-serif}',
    /* Home styles every button under .q (padding 0, no background): the welcome's own rules carry one more class (.qw-x) */
    '.qw-card img{width:40px;height:40px;flex:none}',
    '.qw-card .qw-t{flex:1 1 320px;min-width:0}',
    '.qw-card .qw-t b{display:block;font-size:18px;line-height:26px;font-weight:500}',
    '.qw-card .qw-t span{font-size:14px;line-height:20px;color:#3E4B45}',
    '.qw-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}',
    '.qw-x .qw-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:40px;padding:0 18px;border-radius:999px;border:1px solid #0B3326;background:#0B3326;color:#FFFFFF;',
    '  font:inherit;font-size:14px;font-weight:500;cursor:pointer;box-shadow:inset 0 0 0 1px #DCB87A;white-space:nowrap}',
    '.qw-x .qw-btn.gh{background:transparent;color:#0B0B0B;border-color:#848F8A;box-shadow:inset 0 0 0 1px #B8955A}',
    '.qw-x .qw-btn.tx{background:transparent;color:#0B0B0B;border-color:transparent;box-shadow:none;padding:0 10px;text-decoration:underline;text-underline-offset:3px}',
    '.qw-x .qw-btn:focus-visible,.qw-x .qw-chip:focus-visible,.qw-x .qw-ib:focus-visible,.qw-box textarea:focus-visible,.qw-in:focus-visible{outline:2px solid #0B3326;outline-offset:2px}',
    '.qw-scrim{position:fixed;inset:0;z-index:2147483000;display:grid;place-items:center;padding:24px;background:rgba(11,51,38,.42);font-family:"Google Sans Flex","Helvetica Neue",Arial,sans-serif}',
    '.qw-pop{box-sizing:border-box;width:min(640px,100%);height:min(720px,calc(100vh - 48px));display:flex;flex-direction:column;border-radius:28px;background:#F5F4F0;color:#0B0B0B;overflow:hidden;',
    '  border:1px solid #DCDBD4;box-shadow:0 24px 64px rgba(11,51,38,.28)}',
    '.qw-pop *{box-sizing:border-box}',
    '.qw-h{flex:none;display:flex;align-items:center;gap:12px;padding:14px 14px 12px 20px;background:#FFFFFF;border-bottom:1px solid #B8955A}',
    '.qw-h img{width:28px;height:28px;flex:none}',
    '.qw-h .qw-tt{flex:1;min-width:0}',
    '.qw-h .qw-tt b{display:block;font-size:16px;line-height:22px;font-weight:600}',
    '.qw-h .qw-tt span{display:flex;align-items:center;gap:10px;font-size:12px;line-height:16px;color:#5E5D59;white-space:nowrap}',
    '.qw-segs{display:flex;gap:4px}.qw-segs i{display:block;width:22px;height:4px;border-radius:2px;background:#DCDBD4}.qw-segs i.d{background:#0B3326}.qw-segs i.n{background:#B8955A}',
    '.qw-x .qw-ib{display:inline-grid;place-items:center;width:44px;height:44px;flex:none;border-radius:12px;border:1px solid transparent;background:transparent;color:#0B0B0B;cursor:pointer;padding:0}',
    '.qw-x .qw-ib:hover{background:#ECEBE6}',
    '.qw-x .qw-ib svg,.qw-pop .vb svg,.qw-pop .vb .ic{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}',
    '.qw-log{flex:1;min-height:0;overflow-y:auto;display:flex;flex-direction:column;gap:12px;padding:20px 20px 12px}',
    '.qw-b{max-width:86%;padding:10px 14px;font-size:16px;line-height:24px;border-radius:4px 18px 18px 18px;background:#FFFFFF;border:1px solid #DCDBD4;color:#0B0B0B;white-space:pre-wrap;overflow-wrap:anywhere}',
    '.qw-b.me{align-self:flex-end;border-radius:18px 18px 4px 18px;background:#0B3326;border-color:#0B3326;color:#FFFFFF;font-weight:500}',
    '.qw-b.old{color:#3E4B45}',
    '.qw-b .qw-q{display:block;font-size:17px;line-height:25px;font-weight:500}',
    '.qw-b .qw-hint{display:block;font-size:14px;line-height:20px;margin-top:4px;color:#5E5D59}',
    '.qw-under{padding-left:2px}',
    '.qw-under .qw-gl{display:block;margin:4px 0 6px;font-size:12px;line-height:16px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:#5E5D59}',
    '.qw-chips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:6px}',
    '.qw-x .qw-chip{display:inline-flex;align-items:center;gap:8px;min-height:40px;padding:6px 14px;border-radius:999px;border:1px solid #848F8A;background:#FFFFFF;color:#0B0B0B;font:inherit;font-size:15px;line-height:20px;cursor:pointer;text-align:left}',
    '.qw-x .qw-chip:hover{border-color:#0B3326}',
    '.qw-x .qw-chip[aria-pressed="true"]{background:#E3EEE7;color:#0B3326;border:1.5px solid #0B3326;padding:5px 14px 5px 10px;font-weight:500}',
    '.qw-x .qw-chip[aria-pressed="true"]::before{content:"\\2713";font-weight:700}',
    '.qw-f{flex:none;padding:10px 16px 12px;background:#F5F4F0;border-top:1px solid #DCDBD4}',
    '.qw-box{display:flex;align-items:center;gap:6px;min-height:52px;padding:4px 6px 4px 16px;border-radius:26px;border:1px solid #5A6761;background:#FFFFFF}',
    '.qw-box:focus-within{border-color:#0B3326;box-shadow:0 0 0 1px #0B3326}',
    '.qw-box textarea{flex:1;min-width:0;border:0;outline:0;resize:none;background:transparent;color:#0B0B0B;font:inherit;font-size:16px;line-height:22px;padding:11px 0;max-height:110px}',
    '.qw-box textarea::placeholder{color:#5E5D59}',
    '.qw-pop .vb{display:inline-grid;place-items:center;width:44px;height:44px;flex:none;border-radius:999px;border:1.5px solid #B8955A;background:#FFFFFF;color:#0B3326;cursor:pointer;padding:0}',
    '.qw-pop .vb[aria-pressed="true"]{background:#0B3326;color:#FFFFFF}',
    '.qw-pop .vb.busy{opacity:.6}',
    '.qw-links{display:flex;align-items:center;gap:6px;margin-top:6px}',
    '.qw-links .qw-sp{flex:1}',
    '.qw-x .qw-links .qw-btn.tx{min-height:36px;font-size:13px;color:#3E4B45}',
    '.qw-st{margin:6px 2px 0;font-size:13px;line-height:18px;color:#3E4B45;min-height:0}',
    '.qw-st:empty{display:none}.qw-st.err{color:#B3261E}',
    '.qw-mem{list-style:none;margin:0;padding:0;border:1px solid #DCDBD4;border-radius:16px;background:#FFFFFF;overflow:hidden}',
    '.qw-mem li{display:grid;grid-template-columns:150px minmax(0,1fr) auto;gap:10px;align-items:start;padding:10px 6px 10px 14px;border-top:1px solid #DCDBD4;font-size:15px;line-height:22px}',
    '.qw-mem li:first-child{border-top:0}',
    '.qw-mem .qw-k{padding-top:2px;font-size:12px;line-height:18px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:#5E5D59}',
    '.qw-mem .qw-v{overflow-wrap:anywhere}.qw-mem .qw-v small{display:block;font-size:12px;line-height:16px;color:#5E5D59}',
    '.qw-mem .qw-a{display:flex;gap:0;margin-top:-10px}',
    '.qw-mem li.ed{background:#F5F4F0}',
    '.qw-in{width:100%;min-height:40px;padding:6px 10px;border-radius:12px;border:1.5px solid #0B3326;background:#FFFFFF;color:#0B0B0B;font:inherit;font-size:15px}',
    '.qw-end{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-top:4px}.qw-end .qw-sp{flex:1}',
    '.qw-note{margin:2px 2px 0;font-size:13px;line-height:18px;color:#5E5D59}',
    ':root.t-dark .qw-card{background:#0F3024;border-color:#315745;color:#F3F8F5}:root.t-dark .qw-card .qw-t span{color:#ACC5B7}',
    ':root.t-dark .qw-card .qw-btn.gh,:root.t-dark .qw-card .qw-btn.tx{color:#F3F8F5}',
    '@media (max-width:768px){.qw-card{margin:12px 0;padding:16px}.qw-scrim{padding:0;place-items:stretch}.qw-pop{width:100%;height:100vh;height:100dvh;border-radius:0;border:0}',
    '  .qw-segs i{width:14px}.qw-mem li{grid-template-columns:minmax(0,1fr) auto;gap:2px 6px}.qw-mem .qw-k{grid-column:1/-1}.qw-b{max-width:92%}}',
    '@media (prefers-reduced-motion:reduce){.qw-pop *{transition:none !important;animation:none !important}}'
  ].join('\n');

  function svg(name) {
    var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('aria-hidden', 'true');
    var paths = {x: [['M6 6l12 12M18 6L6 18']], pen: [['M4 20h4L19 9l-4-4L4 16z'], ['M13.5 6.5l4 4']]}[name];
    paths.forEach(function (d) { var p = document.createElementNS('http://www.w3.org/2000/svg', 'path'); p.setAttribute('d', d[0]); s.appendChild(p); });
    return s;
  }
  function el(tag, attrs, kids) {
    var e = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') e.textContent = attrs[k]; else if (k === 'class') e.className = attrs[k];
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), attrs[k]); else if (attrs[k] != null) e.setAttribute(k, attrs[k]);
    });
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  function tok() { try { var f = window; for (var i = 0; i < 6; i++) { if (typeof f.__HERMES_SESSION_TOKEN__ === 'string') return f.__HERMES_SESSION_TOKEN__; if (!f.parent || f.parent === f) break; f = f.parent; } } catch (e) {} return ''; }
  function api(m, path, body) {
    var h = {'X-Hermes-Session-Token': tok()}; if (body !== undefined) h['Content-Type'] = 'application/json';
    return fetch(path, {method: m, headers: h, credentials: 'same-origin', cache: 'no-store', body: body !== undefined ? JSON.stringify(body) : undefined}).then(function (r) {
      return r.text().then(function (t) { var d = null; try { d = t ? JSON.parse(t) : null; } catch (e) {}
        if (!r.ok) { var er = new Error((d && (d.plain || d.error)) || ('HTTP ' + r.status)); er.status = r.status; throw er; } return d; });
    });
  }
  function fmt(s, n) { return s.replace('{n}', n); }
  function browserTz() { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (e) { return ''; } }
  function tzName(tz) {
    try { var p = new Intl.DateTimeFormat(PT ? 'pt-BR' : 'en-US', {timeZone: tz, timeZoneName: 'long'}).formatToParts(new Date());
      var n = (p.filter(function (x) { return x.type === 'timeZoneName'; })[0] || {}).value; return n ? n + ' (' + tz + ')' : tz; } catch (e) { return tz; }
  }
  function tzOk(tz) { try { new Intl.DateTimeFormat('en-US', {timeZone: tz}); return true; } catch (e) { return false; } }
  function splitLine(line) {   // "Label: value" for the welcome's own lines; anything else is shown whole
    for (var i = 0; i < KEYS.length; i++) { var k = KEYS[i] + ':'; if (line.indexOf(k) === 0) return {key: KEYS[i], value: line.slice(k.length).trim()}; }
    return {key: '', value: line};
  }
  function labelOf(key) { for (var i = 0; i < Q.length; i++) if (Q[i].key === key) return Q[i].label; return PT ? 'Lembrado' : 'Remembered'; }

  var S = {data: null, card: null, pop: null, lastFocus: null, answers: null, step: 0, mode: 'interview', rows: null, vox: null};

  function loadDraft() { try { var d = JSON.parse(localStorage.getItem(DRAFT) || 'null'); return d && Array.isArray(d.answers) ? d : null; } catch (e) { return null; } }
  function saveDraft() { try { localStorage.setItem(DRAFT, JSON.stringify({answers: S.answers, step: S.step})); } catch (e) {} }
  function dropDraft() { try { localStorage.removeItem(DRAFT); } catch (e) {} }

  // ---- the prompt card on Home ---------------------------------------------------------------------------------
  function place(card) {
    var doc = document, hero = doc.querySelector('section.hero');
    if (hero && hero.parentNode) { hero.parentNode.insertBefore(card, hero.nextSibling); return true; }
    var main = doc.querySelector('main') || doc.body; main.insertBefore(card, main.firstChild); return true;
  }
  function showCard() {
    if (S.card || !S.data || !S.data.offer || !S.data.ai_ready) return;
    var rev = S.data.offer === 'review';
    var start = el('button', {class: 'qw-btn', type: 'button', text: rev ? T.review : T.start, onclick: function () { open(rev ? 'review' : 'interview'); }});
    var card = el('section', {class: 'qw-card qw-x', 'aria-label': rev ? T.r_b : T.p_b, 'data-qw': rev ? 'review' : 'interview'}, [
      el('img', {src: ICON_URL, alt: ''}),
      el('div', {class: 'qw-t'}, [el('b', {text: rev ? T.r_b : T.p_b}), el('span', {text: rev ? T.r_s : T.p_s})]),
      el('div', {class: 'qw-row'}, [start,
        el('button', {class: 'qw-btn gh', type: 'button', text: T.later, onclick: function () { later(); }}),
        el('button', {class: 'qw-btn tx', type: 'button', text: T.no, onclick: function () { decline(); }})])
    ]);
    S.card = card; S.cardStart = start; place(card);
  }
  function hideCard() { if (S.card && S.card.parentNode) S.card.parentNode.removeChild(S.card); S.card = null; }
  function later() { hideCard(); close(true); api('POST', API + '/state', {state: 'later'}).catch(function () {}); }
  function decline() { hideCard(); dropDraft(); api('POST', API + '/state', {state: 'declined'}).catch(function () {}); }

  // ---- the pop-up --------------------------------------------------------------------------------------------------
  function open(mode) {
    if (S.pop) return;
    S.lastFocus = document.activeElement;
    S.mode = mode;
    var d = mode === 'interview' ? loadDraft() : null;
    S.answers = d ? d.answers : Q.map(function () { return null; });
    S.step = d ? Math.min(d.step, Q.length) : 0;
    S.segs = el('span', {class: 'qw-segs', 'aria-hidden': 'true'});
    S.ofTxt = el('span', {});
    S.log = el('div', {class: 'qw-log', 'aria-live': 'polite'});
    S.ta = el('textarea', {rows: '1', 'aria-label': T.ph, placeholder: (TOPD.defaultView || window).innerWidth < 560 ? T.ph_s : T.ph});
    S.st = el('p', {class: 'qw-st', role: 'status'});
    var sendB = el('button', {class: 'qw-btn', type: 'button', text: T.send, onclick: function () { submit(); }});
    var box = el('div', {class: 'qw-box'}, [S.ta]);
    var V = window.QoshaVoice;
    if (V) {   // the shared dictation: the words go in this box; nothing is sent until Send
      var vb = V.buttons(); box.appendChild(vb.mic);
      S.vox = V.attach({mic: vb.mic, voice: vb.voice, box: S.ta, say: function (t, err) { say(t, err); },
        transcribe: function (body) { return api('POST', '/api/audio/transcribe', body); }, heard: function (t) { S.ta.value = t; }});
    }
    box.appendChild(sendB);
    S.foot = el('footer', {class: 'qw-f'}, [box, el('div', {class: 'qw-links'}, [
      el('button', {class: 'qw-btn tx', type: 'button', text: T.skip, onclick: function () { answer(null); }}), el('span', {class: 'qw-sp'}),
      el('button', {class: 'qw-btn tx', type: 'button', text: T.fin, onclick: function () { finishLater(); }})]), S.st]);
    S.pop = el('section', {class: 'qw-pop', role: 'dialog', 'aria-modal': 'true', 'aria-label': T.welcome}, [
      el('header', {class: 'qw-h'}, [el('img', {src: ICON_URL, alt: ''}),
        el('div', {class: 'qw-tt'}, [el('b', {text: T.welcome}), el('span', {}, [S.segs, S.ofTxt])]),
        el('button', {class: 'qw-ib', type: 'button', 'aria-label': T.close, title: T.close, onclick: function () { finishLater(); }}, [svg('x')])]),
      S.log, S.foot]);
    S.scrim = el('div', {class: 'qw-scrim qw-x'}, [S.pop]);
    S.scrim.addEventListener('keydown', keys);
    S.ta.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); submit(); } });
    style(TOPD); TOPD.body.appendChild(S.scrim);
    if (mode === 'review') summary(true); else render();
  }
  function keys(e) {
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finishLater(); return; }
    if (e.key !== 'Tab') return;
    var f = Array.prototype.filter.call(S.pop.querySelectorAll('button,textarea,input,[tabindex]:not([tabindex="-1"])'), function (x) { return !x.disabled && x.offsetParent !== null; });
    if (!f.length) return;
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && TOPD.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && TOPD.activeElement === last) { e.preventDefault(); first.focus(); }
  }
  function close(silent) {
    if (!S.pop) return;
    try { if (S.vox) S.vox.cancel(); } catch (e) {}
    S.scrim.parentNode.removeChild(S.scrim); S.pop = null; S.vox = null;
    var back = S.card && S.cardStart ? S.cardStart : (S.lastFocus && S.lastFocus.focus ? S.lastFocus : null);
    if (back && !silent) try { back.focus(); } catch (e) {}
  }
  // X, Escape and "Finish later" close the pop-up only: the answers so far stay on this computer (never in memory) and
  // the card stays on Home, where Start picks up at the same question. Putting it off is the card's own "Later".
  function finishLater() {
    if (S.mode === 'interview' && !S.savedOk) saveDraft();
    close(false);
  }
  function say(t, err) { S.st.textContent = t || ''; S.st.className = 'qw-st' + (err ? ' err' : ''); }
  function progress(n) {
    S.segs.textContent = '';
    for (var i = 1; i <= 6; i++) S.segs.appendChild(el('i', {class: i < n ? 'd' : i === n ? 'n' : ''}));
    S.ofTxt.textContent = n <= 6 ? fmt(T.of, n) : '';
  }
  function bubble(text, cls, kids) { var b = el('div', {class: 'qw-b' + (cls ? ' ' + cls : '')}, kids || [text]); S.log.appendChild(b); return b; }
  function scrollEnd() { S.log.scrollTop = S.log.scrollHeight; }

  function render() {
    S.log.textContent = ''; say('');
    bubble(T.intro, 'old');
    for (var i = 0; i < S.step && i < Q.length; i++) {
      bubble('', 'old', [el('span', {class: 'qw-q', text: Q[i].q})]);
      bubble(S.answers[i] == null ? T.skipped : S.answers[i], 'me');
    }
    if (S.step >= Q.length) { summary(false); return; }
    S.segs.hidden = false;
    var q = Q[S.step];
    progress(S.step + 1);
    var name = S.answers[0] && S.step > 0 ? fmt(T.thanks, S.answers[0]) + ' ' : '';
    bubble('', '', [el('span', {class: 'qw-q', text: (S.step === 1 ? name : '') + q.q}), el('span', {class: 'qw-hint', text: q.h})]);
    var under = el('div', {class: 'qw-under'}); S.sel = [];
    q.groups.forEach(function (g, gi) {
      S.sel[gi] = [];
      if (g.t) under.appendChild(el('span', {class: 'qw-gl', text: g.t}));
      var row = el('div', {class: 'qw-chips', role: 'group', 'aria-label': g.t || q.q});
      var all = g.c.concat(g.none ? [g.none] : []);
      all.forEach(function (c) {
        var b = el('button', {class: 'qw-chip', type: 'button', 'aria-pressed': 'false', text: c});
        b.addEventListener('click', function () {
          var on = b.getAttribute('aria-pressed') !== 'true';
          if (g.one || c === g.none || (on && S.sel[gi].indexOf(g.none) >= 0)) {
            Array.prototype.forEach.call(row.children, function (x) { x.setAttribute('aria-pressed', 'false'); }); S.sel[gi] = [];
          }
          b.setAttribute('aria-pressed', on ? 'true' : 'false');
          S.sel[gi] = S.sel[gi].filter(function (x) { return x !== c; }); if (on) S.sel[gi].push(c);
        });
        row.appendChild(b);
      });
      under.appendChild(row);
    });
    if (q.now && S.data && S.data.name_hint) {   // the name this computer knows: one press answers
      var nb = el('button', {class: 'qw-chip', type: 'button', 'aria-pressed': 'false', text: S.data.name_hint + ' ' + T.fromhere});
      nb.addEventListener('click', function () { answer(S.data.name_hint); });
      under.appendChild(el('div', {class: 'qw-chips'}, [nb]));
    }
    if (under.childNodes.length) S.log.appendChild(under);
    S.foot.hidden = false; S.ta.value = '';
    scrollEnd();
    setTimeout(function () { try { (under.querySelector('button') || S.ta).focus(); } catch (e) {} }, 0);
  }
  function submit() {
    if (!S.pop || S.step >= Q.length) return;
    var q = Q[S.step], parts = [];
    (S.sel || []).forEach(function (s) { if (s.length) parts.push(s.join(', ')); });
    var typed = S.ta.value.trim();
    if (typed) parts.push(typed);
    if (!parts.length) { say(PT ? 'Escolha uma opção, digite, ou pule esta pergunta.' : 'Pick an option, type an answer, or skip this question.', true); return; }
    answer(parts.join('. ').replace(/\.\./g, '.'));
  }
  function answer(text) {
    S.answers[S.step] = text == null ? null : String(text).slice(0, 300);
    S.step += 1; saveDraft(); render();
  }

  // ---- the summary: what Qosha will remember, each line editable --------------------------------------------------
  function buildRows(review) {
    var user = (S.data && S.data.user) || [], people = (S.data && S.data.people) || [];
    var have = {}; user.forEach(function (l) { var s = splitLine(l); if (s.key) have[s.key] = l; });
    people.forEach(function (l) { have['Important people'] = l; });
    var rows = [];
    if (review) {
      user.forEach(function (l) { var s = splitLine(l); rows.push({target: 'user', key: s.key, old: l, value: s.value}); });
      people.forEach(function (l) { rows.push({target: 'memory', key: 'Important people', old: l, value: splitLine(l).value}); });
    } else {
      Q.forEach(function (q, i) {
        var old = have[q.key] || null, v = S.answers[i];
        if (v == null && !old) return;
        rows.push({target: q.people ? 'memory' : 'user', key: q.key, old: old, value: v == null ? splitLine(old).value : v});
      });
      user.forEach(function (l) { if (!splitLine(l).key) rows.push({target: 'user', key: '', old: l, value: l, keep: true}); });
    }
    var cur = (S.data && S.data.timezone) || '', tz = cur || browserTz();
    if (tz) rows.push({tz: true, old: cur, value: tz});
    return rows;
  }
  function lineOf(r) { return r.removed ? null : (r.key ? r.key + ': ' + r.value : r.value); }
  function summary(review) {
    S.mode = review ? 'review' : 'interview';
    S.rows = buildRows(review);
    S.log.textContent = ''; say(''); progress(7);
    S.ofTxt.textContent = ''; S.segs.hidden = review;   // reviewing what is remembered is not one of the six steps
    S.foot.hidden = true;
    bubble(review ? T.rev_lead : T.sum_lead, '');
    S.list = el('ul', {class: 'qw-mem', 'aria-label': review ? T.rev_lead : T.sum_lead});
    S.log.appendChild(S.list); drawRows();
    S.saveB = el('button', {class: 'qw-btn', type: 'button', text: T.save, onclick: function () { save(); }});
    var alt = review ? el('button', {class: 'qw-btn tx', type: 'button', text: T.rev_alt, onclick: function () { S.answers = Q.map(function () { return null; }); S.step = 0; S.mode = 'interview'; render(); }})
      : el('button', {class: 'qw-btn tx', type: 'button', text: T.redo, onclick: function () { S.answers = Q.map(function () { return null; }); S.step = 0; dropDraft(); render(); }});
    S.endSt = el('p', {class: 'qw-st', role: 'status'});
    S.log.appendChild(el('div', {class: 'qw-end'}, [S.saveB, el('span', {class: 'qw-sp'}), alt]));
    S.log.appendChild(S.endSt);
    S.log.appendChild(el('p', {class: 'qw-note', text: T.note}));
    S.log.scrollTop = 0;
    setTimeout(function () { try { S.saveB.focus(); } catch (e) {} }, 0);
  }
  function drawRows() {
    S.list.textContent = '';
    S.rows.forEach(function (r, i) {
      if (r.removed) return;
      var label = r.tz ? (PT ? 'Fuso horário' : 'Time zone') : labelOf(r.key);
      var li = el('li', {'data-key': r.tz ? 'timezone' : (r.key || 'other')});
      li.appendChild(el('span', {class: 'qw-k', text: label}));
      if (r.editing) {
        li.className = 'ed';
        var inp = el('input', {class: 'qw-in', type: 'text', value: r.value, 'aria-label': label});
        var ok = function () { var v = inp.value.trim(); if (r.tz && !tzOk(v)) { S.endSt.textContent = T.bad_tz; S.endSt.className = 'qw-st err'; return; }
          if (v) r.value = v; else if (!r.tz) r.removed = true; r.editing = false; drawRows(); };
        inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); ok(); } if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); r.editing = false; drawRows(); } });
        li.appendChild(el('span', {class: 'qw-v'}, [inp]));
        li.appendChild(el('span', {class: 'qw-a'}, [el('button', {class: 'qw-btn', type: 'button', text: T.ok, onclick: ok})]));
        S.list.appendChild(li); setTimeout(function () { inp.focus(); }, 0); return;
      }
      var v = el('span', {class: 'qw-v', text: r.tz ? tzName(r.value) : r.value});
      if (r.tz) v.appendChild(el('small', {text: T.tz_sub}));
      li.appendChild(v);
      var acts = el('span', {class: 'qw-a'}, [el('button', {class: 'qw-ib', type: 'button', 'aria-label': T.edit + ': ' + label, title: T.edit, onclick: function () { r.editing = true; drawRows(); }}, [svg('pen')])]);
      if (!r.tz) acts.appendChild(el('button', {class: 'qw-ib', type: 'button', 'aria-label': T.remove + ': ' + label, title: T.remove, onclick: function () { r.removed = true; drawRows(); }}, [svg('x')]));
      li.appendChild(acts);
      S.list.appendChild(li);
    });
  }
  function save() {
    var rows = [], tz = '';
    S.rows.forEach(function (r) {
      if (r.tz) { if (r.value && r.value !== r.old) tz = r.value; return; }
      var text = lineOf(r);
      if (r.keep && text === r.old) return;
      if (text === r.old) return;
      rows.push({target: r.target, old: r.old || null, text: text});
    });
    S.saveB.disabled = true; S.endSt.className = 'qw-st'; S.endSt.textContent = T.saving;
    api('POST', API + '/save', {rows: rows, timezone: tz || null}).then(function (res) {
      S.savedOk = true; dropDraft(); hideCard();
      S.data.user = res.user || []; S.data.people = res.people || []; S.data.offer = '';
      S.log.textContent = '';
      bubble(T.saved, '');
      var list = el('ul', {class: 'qw-mem'});
      (res.user || []).concat(res.people || []).forEach(function (l) { var s = splitLine(l); list.appendChild(el('li', {}, [el('span', {class: 'qw-k', text: labelOf(s.key)}), el('span', {class: 'qw-v', text: s.value}), el('span', {})])); });
      if (list.childNodes.length) S.log.appendChild(list);
      var done = el('button', {class: 'qw-btn', type: 'button', text: T.done, onclick: function () { close(false); }});
      S.log.appendChild(el('div', {class: 'qw-end'}, [done]));
      S.log.appendChild(el('p', {class: 'qw-note', text: T.note}));
      setTimeout(function () { done.focus(); }, 0);
    }, function (e) {
      S.saveB.disabled = false; S.endSt.className = 'qw-st err'; S.endSt.textContent = T.err + e.message;
    });
  }

  // ---- start: read the state; the card waits until an AI account is connected -----------------------------------
  var tries = 0;
  // the one-time setup code comes first on a fresh install (setupcode.py): while it is offered, this card waits;
  // Home's setup card calls refresh() when the code was used or put aside
  function setupOffered() {
    return api('GET', '/api/plugins/qosha/setup/status').then(function (s) { return !!(s && s.offer); }, function () { return false; });
  }
  function refresh() {
    return Promise.all([api('GET', API + '/state'), setupOffered()]).then(function (x) {
      var d = x[0];
      S.data = d;
      if (!d || !d.offer) { hideCard(); return; }
      if (x[1]) { hideCard(); if (tries++ < 360) setTimeout(refresh, 10000); return; }
      if (d.ai_ready) showCard();
      else if (tries++ < 360) setTimeout(refresh, 10000);   // connected later on this same visit: the card appears then
    }, function () {});
  }
  window.QoshaWelcome = {open: function (mode) { open(mode || 'interview'); }, refresh: refresh, _s: S};
  function style(d) { if (!d.getElementById('qw-style')) { var st = d.createElement('style'); st.id = 'qw-style'; st.textContent = CSS; (d.head || d.documentElement).appendChild(st); } }
  function boot() { style(document); if (!document.querySelector('section.hero') && tries++ < 40) { setTimeout(boot, 250); return; } tries = 0; refresh(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
