/* Local renderer for the recovered Design Component dialect.
   Stable template-path keys retain DOM nodes, native focus, input values and CSS animations.
   Packaged copy for the Qosha dashboard extension: identical to ui/app/support.js except for the
   bound-boolean `disabled` rule in build(), which the connected-tasks card relies on, and for patchChildren
   leaving other scripts' nodes alone (17 Nov). */
class DCLogic {
  constructor(props) { this.props = props; this.state = {}; }
  setState(patch) { this.state = Object.assign({}, this.state, patch); render(); }
}
const SVGNS = 'http://www.w3.org/2000/svg';
function look(ctx, path) {
  if (path === 'true') return true;
  if (path === 'false') return false;
  return path.trim().split('.').reduce((v, key) => v == null ? undefined : v[key], ctx);
}
function interp(ctx, str) {
  return str.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (_, key) => String(look(ctx, key) ?? ''));
}
// the person's language (contract qosha-ptbr §2.B.3): rendered words are written in it from the start (qosha-i18n.js),
// so each refresh compares like with like and never puts the English back; the person's own words are left as they are
const QTX_ATTRS = new Set(['title', 'aria-label', 'placeholder', 'alt', 'aria-description']);
function qtx(tnode, s) {
  const I = window.QoshaI18n;
  if (!I || I.lang !== 'pt-br' || typeof I.tx !== 'function' || !s || !/[A-Za-z]/.test(s)) return s;
  const p = tnode && (tnode.nodeType === 1 ? tnode : tnode.parentElement);
  if (p && p.closest && p.closest('[data-qosha-own],[data-qosha-no-i18n],textarea,code,pre,script,style')) return s;
  return I.tx(s);
}
function build(node, ctx, svg, key) {
  if (node.nodeType === 3) {
    const text = document.createTextNode(qtx(node, interp(ctx, node.nodeValue))); text._key = key; return [text];
  }
  if (node.nodeType !== 1) return [];
  const tag = node.tagName.toLowerCase();
  const children = (context, prefix, isSvg) => Array.from(node.childNodes).flatMap((child, i) => build(child, context, isSvg, prefix + '/' + i));
  if (tag === 'sc-if') return look(ctx, node.getAttribute('value').match(/\{\{\s*(.+?)\s*\}\}/)[1]) ? children(ctx, key, svg) : [];
  if (tag === 'sc-for') {
    const list = look(ctx, node.getAttribute('list').match(/\{\{\s*(.+?)\s*\}\}/)[1]) || [];
    return list.flatMap((item, i) => { const local = Object.create(ctx); local[node.getAttribute('as')] = item; return children(local, key + ':' + (item.id ?? i), svg); });
  }
  const isSvg = svg || tag === 'svg';
  const el = isSvg ? document.createElementNS(SVGNS, node.tagName) : document.createElement(tag);
  el._key = key; el._events = {};
  for (const attr of node.attributes) {
    if (/^on/i.test(attr.name)) {
      const match = attr.value.match(/^\{\{\s*(.+?)\s*\}\}$/);
      if (match) { const fn = look(ctx, match[1]); if (typeof fn === 'function') el._events[attr.name.toLowerCase()] = fn; }
    } else if (!attr.name.startsWith('hint-')) {
      const raw = interp(ctx, attr.value);
      const value = QTX_ATTRS.has(attr.name) ? qtx(node, raw) : raw;
      // A bound boolean `disabled="{{flag}}"` that resolves to false/empty is omitted, so the keyed
      // node toggles between enabled and disabled without being rebuilt (focus and value survive).
      if (attr.name === 'disabled' && attr.value.includes('{{') && (value === '' || value === 'false')) continue;
      el.setAttribute(attr.name, value);
    }
  }
  bindEvents(el);
  el.append(...children(ctx, key, isSvg));
  return [el];
}
function bindEvents(node) {
  node._boundEvents ||= new Set();
  for (const event of Object.keys(node._events)) if (!node._boundEvents.has(event)) {
    node.addEventListener(event.slice(2), e => node._events[event]?.(e));
    node._boundEvents.add(event);
  }
}
// Nodes other scripts put between the rendered ones (the Edit tiles bar, the AI accounts row) carry no _key. They are
// left exactly where they are: never used as the place to insert before (that moved every rendered section after
// them on each refresh: focus and typed text lost, entrance animations replayed = the Home "flicker", 17 Nov) and
// never removed.
function ours(node) { while (node && node._key === undefined) node = node.nextSibling; return node; }
function patchChildren(parent, fresh) {
  const old = new Map(Array.from(parent.childNodes).filter(node => node._key !== undefined).map(node => [node._key, node]));
  let cursor = ours(parent.firstChild);
  for (const incoming of fresh) {
    let node = old.get(incoming._key);
    if (!node || node.nodeName !== incoming.nodeName) node = incoming;
    else {
      old.delete(incoming._key);
      if (node.nodeType === 3) { if (node.nodeValue !== incoming.nodeValue) node.nodeValue = incoming.nodeValue; }
      else {
        for (const attr of Array.from(node.attributes)) if (!incoming.hasAttribute(attr.name)) node.removeAttribute(attr.name);
        for (const attr of incoming.attributes) if (node.getAttribute(attr.name) !== attr.value) node.setAttribute(attr.name, attr.value);
        node._events = incoming._events;
        bindEvents(node);
        patchChildren(node, Array.from(incoming.childNodes));
      }
    }
    if (node !== cursor) parent.insertBefore(node, cursor);
    cursor = ours(node.nextSibling);
  }
  for (const node of old.values()) if (node.parentNode === parent) node.remove();
}
let template, root;
function render() {
  if (!root) return;
  const focused = document.activeElement;
  const decision = focused?.closest?.('[data-decision]')?.dataset.decision;
  const taskFocus = focused?.classList?.contains('task');
  const vals = comp.renderVals();
  patchChildren(root, Array.from(template.childNodes).flatMap((node, i) => build(node, vals, false, String(i))));
  const modal = !!root.querySelector('[aria-modal="true"]');
  for (const child of root.querySelector('.q').children) if (!child.classList.contains('scrim')) child.inert = modal;
  if (focused && !focused.isConnected) {
    const fallback = decision ? root.querySelector('[data-decision="' + decision + '"] button')
      : taskFocus ? root.querySelector('.task,[data-qosha-taskviews] [aria-selected="true"]') : null;
    fallback?.focus({preventScroll:true});
  }
}
function boot() {
  const canonical = document.querySelector('x-dc');
  if (canonical) {
    const helmet = canonical.querySelector('helmet'); document.head.append(...helmet.childNodes); helmet.remove();
    template = document.createDocumentFragment(); template.append(...canonical.childNodes);
    root = document.createElement('div'); root.id = 'root'; canonical.replaceWith(root);
  } else { template = document.getElementById('tpl').content; root = document.getElementById('root'); }
  const script = document.createElement('script');
  script.textContent = document.querySelector('script[type="text/x-dc"]').textContent + '\nwindow.comp = new Component({theme:"white"});';
  document.body.append(script);
  render();
  settleFonts();
  wireInteractions();
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  motion.addEventListener('change', () => { if (motion.matches) comp.settleCoin(); });
  watchMotionProbe();
}
// A switch to reduced motion takes effect in the style recalc of whichever rendering frame comes next. If that switch
// lands after the frame's requestAnimationFrame callbacks have run, the component's per-frame check misses that frame,
// and the frame's whole-page restyle can delay its timer past a read that is waiting for the frame to end. A hidden
// probe whose width depends on the media query closes that gap: ResizeObserver reports it right after the layout of
// the very frame that applies the switch, before the frame ends, so an in-flight or queued coin flip is settled there.
function watchMotionProbe() {
  if (typeof ResizeObserver !== 'function') return;
  const style = document.createElement('style');
  style.textContent = '.dc-motion-probe{position:fixed;left:0;top:0;width:0;height:1px;overflow:hidden;visibility:hidden;pointer-events:none}' +
    '@media (prefers-reduced-motion:reduce){.dc-motion-probe{width:1px}}';
  document.head.append(style);
  const probe = document.createElement('span');
  probe.className = 'dc-motion-probe'; probe.setAttribute('aria-hidden', 'true');
  document.body.append(probe);
  new ResizeObserver(entries => {
    const reduced = entries[entries.length - 1].contentRect.width > 0;
    const visual = comp.state.visual;
    if (reduced && visual && (visual.active || visual.queue.length)) comp.settleCoin();
  }).observe(probe);
}
// The brand font is font-display:swap, so the first layout can use a fallback face and reflow later when the font
// arrives. Start fetching it at boot instead of waiting for the first frame to discover it, and reflow synchronously
// the moment it is ready, so the swap never lands in a later frame and moves controls that are already on screen.
function settleFonts() {
  if (!document.fonts || typeof document.fonts.load !== 'function') return;
  document.fonts.load('16px "Google Sans Flex"').then(() => { root.getBoundingClientRect(); }, () => {});
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once:true}); else boot();

function wireInteractions() {
  root.addEventListener('click', event => {
    if (event.defaultPrevented) return;
    const service = event.target.closest('[data-service]');
    if (service) { comp.showInfo(service.dataset.service, service.classList.contains('qb') ? service.textContent.trim() + ' requires a connected service.' : ''); return; }
    const link = event.target.closest('a[href^="#"]');
    if (!link) return;
    event.preventDefault();
    const id = link.getAttribute('href').slice(1);
    if (id) comp.goTo(id);
    else {
      const section = link.closest('section');
      const title = section?.querySelector('h2,h3')?.childNodes[0]?.textContent || 'Workspace';
      comp.showInfo(title + ' · ' + link.textContent.trim(), link.classList.contains('li') ? 'Sample email preview. ' + link.textContent.trim() : 'This panel contains sample data. A live service is not configured.');
    }
  });
  document.addEventListener('keydown', event => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault(); if (comp.state.cmd) comp.closeOverlay(); else comp.openCommand(); return;
    }
    if (event.key === 'Escape') {
      if (comp.state.cmd || comp.state.info) { event.preventDefault(); comp.closeOverlay(); }
      else if (comp.state.notif) { comp.setState({notif:false}); document.querySelector('[aria-label^="Notifications"],[aria-label^="Notificações"]')?.focus(); }
      return;
    }
    const dialog = root.querySelector('[aria-modal="true"]');
    if (dialog && event.key === 'Tab') {
      const focusable = Array.from(dialog.querySelectorAll('button:not([tabindex="-1"]),input,a[href]'));
      const first = focusable[0], last = focusable.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      return;
    }
    if (comp.state.cmd && !event.isComposing) {
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') { event.preventDefault(); comp.moveCommand(event.key === 'ArrowDown' ? 1 : -1); }
      if (event.key === 'Enter' && event.target.id === 'cmd-q') { event.preventDefault(); comp.commands()[comp.state.selected || 0]?.run(); }
      return;
    }
    const tab = event.target.closest?.('[role="tab"]');
    if (tab && ['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) {
      event.preventDefault(); const tabs = Array.from(tab.parentElement.querySelectorAll('[role="tab"]'));
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : (tabs.indexOf(tab) + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
      tabs[next].click(); tabs[next].focus();
    }
  });
  document.addEventListener('click', event => {
    if (comp.state.notif && !event.target.closest('.tools')) comp.setState({notif:false});
  });
}
