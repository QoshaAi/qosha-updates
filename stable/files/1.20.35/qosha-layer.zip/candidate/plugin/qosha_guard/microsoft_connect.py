"""Outlook sign-in and server settings for Qosha on the person's computer (slice 2a + round-1 fixes, 21 Nov 2026).

Outlook (mail, calendar, OneDrive) runs through the pinned open-source server (Softeria ms-365-mcp-server, vendored under
the Qosha home) on the engine's own Node, with Qosha's own Microsoft app (personal accounts). The person signs in with
Microsoft's short code, which Qosha's Connections page shows; Qosha never sees their password. Exactly one Microsoft
account at a time; anything Qosha can't verify is refused, never guessed.
"""
from __future__ import annotations

import json
import os
import re
import secrets
import stat
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional

CLIENT_ID = "8369fe4e-83e4-44a3-a84f-5cd5bc819eca"
TENANT = "common"          # personal AND work/school accounts (Ren, 22 Nov 2026); the app registration allows both
SERVER_REL = Path("tools/qosha-microsoft/node_modules/@softeria/ms-365-mcp-server/dist/index.js")
# READ-ONLY until Qosha's own Microsoft executor lands (Ren, 22 Nov 2026 ~16:10 MST): the server runs with --read-only,
# asks only for read permissions, and offers read tools only. Sending, drafts and changes come in a later update.
ALLOWED = frozenset("""list-mail-messages list-mail-folders list-mail-child-folders list-mail-folder-messages
get-mail-message read-mail-text list-mail-attachments get-mail-attachment-content download-bytes
get-download-url list-calendar-events get-calendar-event get-calendar-view list-calendars list-calendar-event-instances
list-drives get-drive-root-item list-folder-files get-drive-item search-onedrive-files list-drive-item-versions
list-drive-item-permissions get-my-profile verify-login list-accounts""".split())
SCOPES = "openid offline_access User.Read Mail.Read Calendars.Read Files.Read"   # the only permissions it asks for
ENABLED_REGEX = "^(" + "|".join(sorted(ALLOWED)) + ")$"
ENV_KEEP = ("PATH", "HOME", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "SystemRoot", "SYSTEMROOT", "WINDIR", "TEMP",
            "TMP", "TMPDIR", "LANG", "LC_ALL", "LC_CTYPE", "ComSpec", "PATHEXT")
URL_RX = re.compile(r"\S*://\S+")
# Microsoft's own sign-in pages only; tenant "common" sends people to login.microsoft.com/device (22 Nov 2026)
LINK_OK = re.compile(r"https://(?:www\.microsoft\.com|microsoft\.com|login\.microsoftonline\.com|login\.microsoft\.com)/[^\s\"'<>]*")
CODE_RX = re.compile(r"\bcode\s+([A-Z0-9]{6,12})\b")
NODE_DIR = re.compile(r"^node-(\d+)\.(\d+)\.(\d+)(?:-[A-Za-z0-9_.-]+)?$")
START_WAIT = 30.0
FLOW_SECONDS = 900
CMD_TIMEOUT = 30
START_FAILED = "Microsoft's sign-in could not start. Try again in a moment."
NOT_FINISHED = "The Microsoft sign-in did not finish. Press Connect to try again."
UNSURE = "Qosha couldn't check the Outlook sign-in on this computer. Press Disconnect, then Connect."
NOT_REMOVED = "Qosha couldn't remove the Outlook sign-in from this computer. Close Qosha and try again."
CLEANUP_FAILED = ("Qosha couldn't remove a half-finished Outlook sign-in. Close Qosha, open it again, then press "
                  "Connect.")
WIN = os.name == "nt"

RUNNER = subprocess.Popen      # injectable (tests)
NOW = time.monotonic           # injectable (tests)
_FLOWS: Dict[str, Dict[str, Any]] = {}     # flow id -> flow
_ACTIVE: Dict[str, Dict[str, Any]] = {}    # home -> the flow (or reservation) of that home
_DIRTY: Dict[str, bool] = {}               # home -> a half-finished sign-in could not be removed yet (F6)
_CHILDREN: Dict[str, list] = {}            # home -> every sign-in child started for it (G4)


def mark_path(home) -> Path:
    """The persistent "cleanup needed" mark (G7): survives a restart; only a verified cleanup removes it."""
    return data_dir(home) / ".cleanup-needed"


def _set_mark(home) -> None:
    home = str(home)
    with _LOCK:
        _DIRTY[home] = True
    m = mark_path(home)
    try:
        if _data_ok(home) and not os.path.lexists(m):
            data_dir(home).mkdir(parents=True, exist_ok=True)
            os.close(os.open(str(m), os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600))
    except OSError:
        pass                                   # the in-memory mark still holds for this run


def _dirty(home) -> bool:
    home = str(home)
    return bool(_DIRTY.get(home)) or os.path.lexists(mark_path(home))


def _clear_mark(home) -> bool:
    home = str(home)
    m = mark_path(home)
    try:
        if os.path.lexists(m):
            os.unlink(m)                       # a link at the mark path is removed itself, never followed
    except OSError:
        return False
    with _LOCK:
        _DIRTY.pop(home, None)
    return not os.path.lexists(m)


def _live_children(home) -> list:
    with _LOCK:
        kids = [c for c in _CHILDREN.get(str(home), []) if c is not None]
        alive = []
        for c in kids:
            try:
                if c.poll() is None:
                    alive.append(c)
            except Exception:
                alive.append(c)               # can't tell: treated as running
        _CHILDREN[str(home)] = alive
    return alive
_LOCK = threading.Lock()


def _is_link(p) -> bool:
    try:
        st = os.lstat(p)
    except OSError:
        return False
    return stat.S_ISLNK(st.st_mode) or bool(getattr(st, "st_file_attributes", 0) & 0x400)


def node_path(home) -> Optional[str]:
    tools = Path(home) / "tools"
    if _is_link(tools) or not tools.is_dir():
        return None
    found = []
    try:
        entries = list(os.scandir(tools))
    except OSError:
        return None
    for e in entries:
        m = NODE_DIR.match(e.name)
        if not m or _is_link(e.path) or not e.is_dir(follow_symlinks=False):
            continue
        for rel in (("node.exe",), ("bin", "node")):
            p = os.path.join(e.path, *rel)
            if len(rel) == 2 and _is_link(os.path.join(e.path, "bin")):
                continue
            try:
                st = os.lstat(p)
            except OSError:
                continue
            if stat.S_ISREG(st.st_mode) and not _is_link(p):
                found.append((tuple(int(x) for x in m.groups()), p))
    return sorted(found, reverse=True)[0][1] if found else None


PINNED_VERSION = "0.190.2"


def server_path(home) -> Optional[str]:
    """The pinned server's entry file, only when its package says the pinned version (J8)."""
    p = Path(home) / SERVER_REL
    pkg = p.parent.parent / "package.json"
    try:
        if not p.is_file() or json.loads(pkg.read_text(encoding="utf-8")).get("version") != PINNED_VERSION:
            return None
    except Exception:
        return None
    return str(p)


def data_dir(home) -> Path:
    return Path(home) / "microsoft"


def drop_old_cache(home) -> None:
    """The token file of the earlier write-permission sign-in, removed once (that exact path, a plain file only)."""
    p = data_dir(home) / "token-cache.json"
    try:
        # round 2 (GPT H7): never through a linked home or sign-in folder (only this home's own real folder)
        if _is_link(Path(home)) or not os.path.lexists(data_dir(home)) or not _data_ok(home):
            return
        if p.is_file() and not _is_link(p):
            p.unlink()
    except OSError:
        pass


def cache_path(home) -> Path:
    # a new name for the read-only sign-in (22 Nov 2026): a token granted with write permissions before is never reused
    return data_dir(home) / "token-cache-read.json"


def selected_path(home) -> Path:
    return data_dir(home) / "selected-account.json"


def _data_ok(home) -> bool:
    """The sign-in folder is a real folder inside this home (or not there yet)."""
    d = data_dir(home)
    if not os.path.lexists(d):
        return True
    if _is_link(d) or not d.is_dir():
        return False
    try:
        return d.resolve().is_relative_to(Path(home).resolve())
    except OSError:
        return False


def ENV(home) -> Dict[str, str]:
    # the pinned server lets ENABLED_TOOLS / ENABLED_TOOLS_FILE override --enabled-tools: pinned here too (J1)
    return {"MS365_MCP_CLIENT_ID": CLIENT_ID, "MS365_MCP_TENANT_ID": TENANT, "MS365_MCP_USE_KEYTAR": "0",
            "MS365_MCP_TOKEN_CACHE_PATH": str(cache_path(home)),
            "MS365_MCP_SELECTED_ACCOUNT_PATH": str(selected_path(home)),
            "ENABLED_TOOLS": ENABLED_REGEX, "ENABLED_TOOLS_FILE": "",
            "READ_ONLY": "true", "MS365_MCP_ALLOWED_SCOPES": SCOPES}   # the sign-in child too: it gets only this env


def child_env(home) -> Dict[str, str]:
    env = {k: os.environ[k] for k in ENV_KEEP if k in os.environ}
    env.update(ENV(home))
    return env


def server_config(home) -> Optional[Dict[str, Any]]:
    node, server = node_path(home), server_path(home)
    if not node or not server:
        return None
    return {"command": node, "args": [server, "--read-only", "--allowed-scopes", SCOPES, "--enabled-tools", ENABLED_REGEX],
            "env": ENV(home), "enabled": False}


def _ensure_dir(home) -> None:
    d = data_dir(home)
    if not _data_ok(home):
        raise OSError("sign-in folder is not a plain folder in this home")
    d.mkdir(parents=True, exist_ok=True)
    if not WIN:
        try:
            os.chmod(d, 0o700)
        except OSError:
            pass


def _spawn(home, args, runner=None):
    node, server = node_path(home), server_path(home)
    if not node or not server:
        raise FileNotFoundError("outlook server not installed")
    _ensure_dir(home)
    kw = {"stdin": subprocess.DEVNULL, "stdout": subprocess.PIPE, "stderr": subprocess.DEVNULL, "text": True,
          "env": child_env(home), "shell": False}
    if WIN:
        kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return (runner or RUNNER)([node, server] + list(args), **kw)


def _kill(p) -> None:
    try:
        if p is not None and p.poll() is None:
            p.kill()
    except Exception:
        pass


def _run_json(home, args, runner=None) -> Optional[dict]:
    """Run a short server command; its last non-empty line as a JSON object, or None (any doubt)."""
    try:
        p = _spawn(home, args, runner)
    except Exception:
        return None
    try:
        out, _ = p.communicate(timeout=CMD_TIMEOUT)
    except Exception:
        _kill(p)
        return None
    if getattr(p, "returncode", None) != 0:
        return None
    lines = [l.strip() for l in (out or "").splitlines() if l.strip()]
    if not lines:
        return None
    try:
        v = json.loads(lines[-1])
    except Exception:
        return None
    return v if isinstance(v, dict) else None


def account(home, runner=None) -> Dict[str, Any]:
    """{"state": none|one|many|unknown, "signed_in", "account"}; "none" only on a clear, empty answer (K4)."""
    unknown = {"state": "unknown", "signed_in": False, "account": ""}
    if not _data_ok(home):
        return unknown
    r = _run_json(home, ["--list-accounts"], runner)
    accts = r.get("accounts") if isinstance(r, dict) else None
    if not isinstance(accts, list):
        return unknown
    if not accts:
        return {"state": "none", "signed_in": False, "account": ""}
    names = [a.get("username") for a in accts if isinstance(a, dict) and isinstance(a.get("username"), str) and a.get("username").strip()]
    if len(names) != len(accts):
        return unknown
    if len(accts) > 1:
        return {"state": "many", "signed_in": False, "account": ""}
    return {"state": "one", "signed_in": True, "account": names[0]}


def _reader(flow: Dict[str, Any]) -> None:
    try:
        for line in flow["proc"].stdout:
            flow["lines"].append(line.rstrip("\r\n"))
    except Exception:
        pass
    finally:
        flow["done_reading"] = True


def _live(flow) -> bool:
    p = flow.get("proc")
    return p is not None and p.poll() is None


def _flow_answer(fid, f) -> Dict[str, Any]:
    return {"ok": True, "status": "signing_in", "flow_id": fid, "verification_uri": f["uri"], "user_code": f["code"],
            "seconds_left": int(max(0, FLOW_SECONDS - (NOW() - f["started"]))), "reused": True}


def start_flow(home, runner=None, _depth: int = 0) -> Dict[str, Any]:
    drop_old_cache(home)
    home = str(home)
    t_wait = time.monotonic()
    while True:
        with _LOCK:                               # one sign-in per home, reserved before anything is checked (K5)
            cur = _ACTIVE.get(home)
            if cur is not None and cur.get("status") == "signing_in" and _live(cur) and NOW() - cur["started"] < FLOW_SECONDS:
                return _flow_answer(cur["id"], cur)
            ended = [f for f in list(_FLOWS.values()) + ([cur] if cur is not None else [])
                     if f.get("home") == home and f.get("status") == "signing_in"
                     and not (_live(f) and NOW() - f["started"] < FLOW_SECONDS)]
            ended = [f for i, f in enumerate(ended) if f not in ended[:i]]
            if not ended and (cur is None or cur.get("status") not in ("reserved", "starting")):
                flow = {"id": None, "home": home, "proc": None, "lines": [], "done_reading": False, "started": NOW(),
                        "status": "reserved"}
                _ACTIVE[home] = flow
                break
        # an earlier sign-in that ended but was never checked is finished first: identity check, cleanup (F4)
        for f in ended:
            if f.get("id"):
                _evaluate(f)
            else:
                _finish(f, None)
        if ended:
            continue
        # another Connect for this home is starting: wait for it and give the same sign-in (K5)
        if time.monotonic() - t_wait > START_WAIT + CMD_TIMEOUT + 5:
            return {"ok": False, "plain": START_FAILED}
        time.sleep(0.02)
    try:
        if _live_children(home) or _dirty(home):   # G4/G7: nothing starts over a running child or a half sign-in
            ok = all([_stop(c) for c in _live_children(home)])
            if not ok or _live_children(home) or not _clear_half_signin(home):
                return {"ok": False, "plain": CLEANUP_FAILED}
        acct = account(home, runner)
        if flow.get("status") == "cancelled":
            return {"ok": False, "plain": START_FAILED}
        if acct["state"] == "one":
            return {"ok": True, "status": "connected", "account": acct["account"]}
        if acct["state"] != "none":
            return {"ok": False, "plain": UNSURE}
        try:
            proc = _spawn(home, ["--login"], runner)
        except Exception:
            _clear_half_signin(home)                          # F5
            return {"ok": False, "plain": START_FAILED}
        with _LOCK:
            _CHILDREN.setdefault(home, []).append(proc)       # tracked until its exit is confirmed (G4)
        try:
            return _started(home, flow, proc)
        except BaseException:
            _start_failed(home, proc)                         # G5: anything unexpected stops it and cleans up
            return {"ok": False, "plain": START_FAILED}
    finally:
        with _LOCK:
            if _ACTIVE.get(home) is flow and flow.get("status") != "signing_in":
                _ACTIVE.pop(home, None)


def _started(home, flow, proc) -> Dict[str, Any]:
    """From a spawned child to a registered sign-in (or a cleaned-up failure)."""
    if True:
        with _LOCK:
            flow.update(proc=proc, status="starting")   # Disconnect can stop it from here on (K5)
            replaced = _ACTIVE.get(home) is not flow
        if replaced:
            return _start_failed(home, proc)
        threading.Thread(target=_reader, args=(flow,), daemon=True).start()
        t0 = NOW()
        uri = code = None
        while True:
            if flow.get("status") == "cancelled":
                break
            text = " ".join(flow["lines"])
            urls = URL_RX.findall(text)
            m2 = CODE_RX.search(text)
            if urls and m2:
                first = urls[0].rstrip(".,;")
                if LINK_OK.fullmatch(first):
                    uri, code = first, m2.group(1)
                break
            if NOW() - t0 > START_WAIT or (flow["done_reading"] and not _live(flow)):
                break
            time.sleep(0.02)
        if not uri or not code:
            return _start_failed(home, proc)
        fid = secrets.token_urlsafe(18)
        with _LOCK:
            gone = _ACTIVE.get(home) is not flow or flow.get("status") == "cancelled"
            if not gone:
                flow.update(id=fid, status="signing_in", uri=uri, code=code, started=NOW())
                _FLOWS[fid] = flow
        if gone:
            return _start_failed(home, proc)
        return {"ok": True, "status": "signing_in", "flow_id": fid, "verification_uri": uri, "user_code": code,
                "seconds_left": FLOW_SECONDS}


def _stop(proc) -> bool:
    """The sign-in child is stopped; True only when its exit is confirmed within 5 s (F5, F7, G4)."""
    if proc is None:
        return True
    _kill(proc)
    try:
        proc.wait(timeout=5)
    except Exception:
        pass
    try:
        return proc.poll() is not None
    except Exception:
        return False


def _start_failed(home, proc) -> Dict[str, Any]:
    """A start that failed after the child ran: stop it, remove what it wrote, then the reservation goes (F5)."""
    _clear_half_signin(home, exit_ok=_stop(proc))
    return {"ok": False, "plain": START_FAILED}


def _claim(f):
    """The first caller owns the flow's end (F7); it is claimed BEFORE any identity check or cleanup runs."""
    with _LOCK:
        if f.get("final"):
            return False, f.get("final_event")
        ev = f["final_event"] = threading.Event()
        f["final"] = True
        return True, ev


def _wait_result(ev) -> Dict[str, Any]:
    if ev is not None:
        ev.wait(15)
    return None


def _finish(f, account_name=None, plain=NOT_FINISHED, claimed=None) -> Dict[str, Any]:
    """A flow's end, run once (F7): a failure stops the child, removes the half sign-in (verified, F6) and only then
    gives the home back; a success records the account. Later calls get the same answer."""
    first, ev = claimed if claimed is not None else _claim(f)
    if not first:
        _wait_result(ev)
        return dict(f.get("result") or {"status": "error", "plain": NOT_FINISHED})
    try:
        if account_name:
            res = {"status": "connected", "account": account_name}
            _end(f, status="connected", account=account_name, result=res)
        else:
            _clear_half_signin(f["home"], exit_ok=_stop(f.get("proc")))
            res = {"status": "error", "plain": plain}
            _end(f, status="error", plain=plain, result=res)
        return dict(res)
    finally:
        ev.set()


def _ident(v):
    """(given, valid, text) for one identity field of the sign-in's answer (F8)."""
    if v is None:
        return False, True, ""
    if isinstance(v, str) and v and len(v) <= 320 and all(c.isprintable() and not c.isspace() for c in v):
        return True, True, v
    return True, False, ""


def _evaluate(f) -> Dict[str, Any]:
    if f.get("final"):
        return _finish(f)
    p = f["proc"]
    rc = p.poll() if p is not None else -1
    if rc is None:
        if NOW() - f["started"] > FLOW_SECONDS:
            return _finish(f, None)
        return {"status": "signing_in", "seconds_left": int(max(0, FLOW_SECONDS - (NOW() - f["started"])))}
    deadline = NOW() + 2
    while not f["done_reading"] and NOW() < deadline:
        time.sleep(0.02)
    result = None
    last = [l.strip() for l in f["lines"] if l.strip()]
    if last:
        try:
            result = json.loads(last[-1])
        except Exception:
            result = None
    claimed = _claim(f)                       # owned before the identity check runs (F7)
    if not claimed[0]:
        return _finish(f, claimed=claimed)
    if rc == 0 and isinstance(result, dict) and result.get("success") is True:
        ud = result.get("userData", {})           # present but not an object (null included) fails (G8)
        if isinstance(ud, dict):
            g1, ok1, upn = _ident(ud.get("userPrincipalName"))
            g2, ok2, mail = _ident(ud.get("mail"))
            if ok1 and ok2:
                reported = upn if g1 else (mail if g2 else "")
                stored = account(f["home"])       # exactly one account, the same one, is stored (J4, F8)
                if stored["state"] == "one" and (not reported or stored["account"].lower() == reported.lower()):
                    return _finish(f, stored["account"], claimed=claimed)
    return _finish(f, None, claimed=claimed)


def flow_status(flow_id: str) -> Dict[str, Any]:
    f = _FLOWS.get(str(flow_id or ""))
    if not f:
        return {"status": "error", "plain": NOT_FINISHED}
    if f.get("status") == "cancelled":
        return {"status": "error", "plain": NOT_FINISHED}
    if f.get("final") or f.get("status") in ("connected", "error"):
        r = _finish(f) if f.get("final") else {k: v for k, v in f.items() if k in ("status", "account", "plain")}
        return {k: v for k, v in r.items() if k in ("status", "account", "plain")}
    return {k: v for k, v in _evaluate(f).items() if k in ("status", "account", "plain", "seconds_left")}


def _clear_half_signin(home, exit_ok: bool = True) -> bool:
    """A sign-in only ever starts with no account stored, so what it half-wrote is removed (the two files only; J5).
    True only when both are gone; Windows may hold a file briefly, so it retries for 2 s; otherwise the home is marked
    and nothing new starts until it succeeds (F6)."""
    home = str(home)
    if not _data_ok(home):
        with _LOCK:
            _DIRTY[home] = True
        return False
    paths = (cache_path(home), selected_path(home))
    end = time.monotonic() + 2
    while True:
        for p in paths:
            try:
                p.unlink()
            except OSError:
                pass
        if not any(os.path.lexists(p) for p in paths):
            if not exit_ok:                        # the child may still write: not clean (G6)
                _set_mark(home)
                return False
            return _clear_mark(home)
        if time.monotonic() > end:
            _set_mark(home)
            return False
        time.sleep(0.05)


def _end(f, **kw) -> None:
    with _LOCK:
        f.update(**kw)
        if _ACTIVE.get(f.get("home")) is f:
            _ACTIVE.pop(f["home"], None)


def cancel(flow_id: str) -> None:
    f = _FLOWS.get(str(flow_id or ""))
    if f:
        if f.get("status") == "signing_in":
            _finish(f, None)
        else:
            _kill(f.get("proc"))


def disconnect(home, runner=None) -> Dict[str, Any]:
    home = str(home)
    drop_old_cache(home)
    with _LOCK:                                   # every sign-in of this home stops first (K6)
        cur = _ACTIVE.pop(home, None)
        if cur is not None:
            cur["status"] = "cancelled"
            _kill(cur.get("proc"))
        for f in _FLOWS.values():
            if f.get("home") == home and f.get("status") == "signing_in":
                f["status"] = "cancelled"
                _kill(f.get("proc"))
    if not _data_ok(home):
        return {"ok": False, "plain": NOT_REMOVED}
    stopped_all = all([_stop(c) for c in _live_children(home)])
    if not stopped_all or _live_children(home):
        _set_mark(home)                           # a child that won't exit could write again: nothing removed (G4)
        return {"ok": False, "plain": NOT_REMOVED}
    _run_json(home, ["--logout"], runner)
    for p in (cache_path(home), selected_path(home)):
        try:
            p.unlink()
        except FileNotFoundError:
            pass
        except OSError:
            pass
    if os.path.lexists(cache_path(home)) or os.path.lexists(selected_path(home)):
        return {"ok": False, "plain": NOT_REMOVED}
    _clear_mark(home)
    return {"ok": True}
