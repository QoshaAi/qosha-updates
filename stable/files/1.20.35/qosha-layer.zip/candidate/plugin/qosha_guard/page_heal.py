"""Pages held back only by the chat look link are brought up to date (23 Nov 2026: Ren's Air, and very likely Bryan,
kept an old chat.html through every update since the install's look preset linked ren-look into it).

Why after start: on the updater that is already installed, keep_edits.restore() runs AFTER the new release's setup_home
and puts the person's page back on a conflict (with the release's page beside it as <file>.qosha-<version>.new); only
the new release's plugin, once Qosha runs again, comes after that.

How (reviews round 1 and 2): two phases.
  1. At register(), before the dashboard serves anything (round 2, N-2): the PAGE only. A page that qualifies (below) is
     swapped for the release's page + the look line, atomically; keep_edits' record is not touched and the .new stays as
     the marker of pending work. On a failed update the updater's own rollback puts the old page back, as it should.
  2. Only when a .new is pending (N-4), ONE worker thread waits until no update is running (<root>/run/update.lock
     absent), then TAKES that same lock with a token of its own (exclusive create, as the updater does) so neither an
     update nor another Qosha process touches the plugin or the record meanwhile; for each healed page it sets keep_edits'
     record (installed copy + BASE) BEFORE removing that page's .new (N-1), then releases the lock (only its own token).
  A lock it cannot get, or an update still running after the wait, means: nothing now, the next start tries again.

What, for dashboard/pages/chat.html and dashboard/index.html only, each condition required:
  - this release's version is known (not "0") and <file>.qosha-<version>.new exists beside the live page (neither a link);
  - the .new is this release's own page: equal to the package file in <root>/layer/candidate/plugin in one of the ways the
    install writes it (keep_edits._renditions) (G-4);
  - the live page is EXACTLY what the look preset makes of a page: that page with the tag line inserted right before its
    last </head>, with the page's own line ending (G-3);
  - that page is keep_edits' recorded BASE for the file (plugin-base only: review M-7), or a page some Qosha release
    shipped (known_pages.json; council
    23 Nov: after several conflicted updates or an installer-written start, BASE may not be that page);
then: the old page is kept in <home>/qosha/held-pages/<file>.<time>[-n] (a new name, never overwriting; outside the
plugin: review M-9), the live file is re-read and
must still be the checked bytes (G-7), the release's page + the look line goes in (unique temp file, then replace), the
.new is removed, and keep_edits' record says, from that one snapshot: installed copy = the healed page, BASE = the
release's page (G-8/G-9: only for a page healed now, never on an ordinary start). A page already healed (live = the
release page + the link) only has its .new removed (G-11). Anything else is never touched.
Standard library only; the same on Mac and Windows. Never raises."""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import threading
import time
from pathlib import Path

TAGS = '<link rel="stylesheet" href="ren-look.css"><script src="ren-look.js" defer></script>'
PAGES = ("dashboard/pages/chat.html", "dashboard/index.html")
LOCK_WAIT_S = 1800.0


def _with_look(text: str) -> str | None:
    """What the look preset makes of a page: the tag line right before its last </head>, in the page's line ending."""
    low = text.lower()
    if low.count("</head>") != 1 or TAGS in text:      # review M-8: one head end (any case), never a second link
        return None
    i = low.rfind("</head>")
    return text[:i] + TAGS + ("\r\n" if "\r\n" in text else "\n") + text[i:]


def _without_look(text: str) -> str | None:
    """The page the look preset was applied to, only when `text` is exactly that preset's output (G-3)."""
    if text.count(TAGS) != 1:
        return None
    for tag in (TAGS + "\r\n", TAGS + "\n"):
        if text.count(tag) == 1:
            before = text.replace(tag, "", 1)
            if _with_look(before) == text:
                return before
    return None


_KNOWN = None


def _known(rel: str) -> set:
    """sha256 (LF line endings) of every page a Qosha release shipped for rel; empty when the list can't be read."""
    global _KNOWN
    if _KNOWN is None:
        try:
            d = json.loads((Path(__file__).resolve().parent / "known_pages.json").read_text(encoding="utf-8"))
            _KNOWN = {k: set(v) for k, v in (d.get("pages") or {}).items() if isinstance(v, list)}
        except Exception:
            _KNOWN = {}
    return _KNOWN.get(rel, set())


def _lf(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n")


def _sha_lf(text: str) -> str:
    return hashlib.sha256(_lf(text).encode("utf-8")).hexdigest()


def _base_for(home: Path, rel: str, ke) -> bytes | None:
    """keep_edits' recorded BASE for rel (plugin-base) only; never the installed copy, which can hold the person's own
    version (review M-7). None when there is none or it can't be read."""
    try:
        return ke._read_bases(home).get(rel)
    except Exception:
        return None


def _plain_file(p: Path) -> bool:
    try:
        return p.is_file() and not p.is_symlink()
    except OSError:
        return False


def _write(path: Path, data: bytes, expect: bytes | None = None) -> str:
    """A new temp file of our own in the same folder (exclusive, never a link we follow), then replace (G-6/G-10).
    expect: the bytes the file must still hold right before the replace (staged first: N-3); "changed" when it does
    not (nothing written; "same" when it already holds `data`, e.g. another Qosha process healed it meanwhile)."""
    fd, tmp = tempfile.mkstemp(prefix="." + path.name + ".", suffix=".qosha-heal-tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        if expect is not None:
            now = path.read_bytes()
            if now != expect:
                os.unlink(tmp)
                return "same" if now == data else "changed"
        for i in range(6):                                  # Windows: a reader holding the page (review M-6)
            try:
                os.replace(tmp, str(path))
                break
            except PermissionError:
                if i == 5:
                    raise
                time.sleep(0.05)
                if expect is not None:                      # round 2, G-7: an editor's save meanwhile wins
                    try:
                        now = path.read_bytes()
                    except OSError:
                        now = None
                    if now != expect:
                        os.unlink(tmp)
                        return "same" if now == data else "changed"
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return "written"


def held_dir(home: Path) -> Path:
    """Old pages kept by a heal: outside the plugin, so they are neither served nor taken for the person's own files
    by the next update (review M-9)."""
    return Path(home) / "qosha" / "held-pages"


def _keep_aside(home: Path, page: Path, data: bytes) -> Path:
    """The old page under a name that did not exist (exclusive create), never overwriting an earlier copy."""
    d = held_dir(home)
    d.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    for n in range(1, 100):
        held = d / ("%s.%s%s" % (page.name, stamp, "" if n == 1 else "-%d" % n))
        try:
            fd = os.open(str(held), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
        except FileExistsError:
            continue
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        return held
    raise OSError("no free name for the held page")


def _log(root: Path | None, msg: str) -> None:
    if not root:
        return
    try:
        (root / "logs").mkdir(exist_ok=True)
        with open(root / "logs" / "updates.log", "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except OSError:
        try:                                                # the update log can't be written: the engine's own log
            import logging
            logging.getLogger("qosha").warning("Qosha page check: %s", msg)
        except Exception:
            pass


def _release_page_ok(release_dir: Path | None, rel: str, page_text: str, ke) -> bool:
    """The .new is this release's own page (the package file, in one of the ways the install writes it) (G-4)."""
    if release_dir is None:
        return False
    src = release_dir.joinpath(*rel.split("/"))
    if not _plain_file(src):
        return False
    try:
        cands = ke._renditions(rel, src.read_bytes())
    except Exception:
        return False
    want = _lf(page_text)
    for c in cands:
        try:
            if _lf(c.decode("utf-8")) == want:
                return True
        except UnicodeDecodeError:
            continue
    return False


def heal(home: Path, version: str, ke, root: Path | None = None, release_dir: Path | None = None,
         record: bool = True) -> list:
    """Heals what qualifies. record=False (phase 1, at register): the page only; the .new stays. record=True (phase 2):
    the CALLER holds the update lock (run_after_start does); the record is set per page before its .new goes.
    Returns the pages healed (or completed) now."""
    done = []
    try:
        if not version or version == "0":
            return done
        home = Path(home)
        if release_dir is None and root is not None:
            release_dir = Path(root) / "layer" / "candidate" / "plugin"
        live = home / "plugins" / "qosha"
        sv = ke._safe_version(version)
        for rel in PAGES:
            try:                                            # round 2, NEW-3: one page's failure never stops another's
                if _heal_one(home, rel, live, sv, ke, root, release_dir, record):
                    done.append(rel)
            except Exception as exc:
                _log(root, "page check stopped for %s: %s %s" % (rel, type(exc).__name__, str(exc)[:120]))
    except Exception as exc:
        _log(root, "page check stopped: %s %s" % (type(exc).__name__, str(exc)[:120]))
        return done
    return done


def _heal_one(home: Path, rel: str, live: Path, sv: str, ke, root, release_dir, record: bool) -> bool:
    page = live.joinpath(*rel.split("/"))
    new = page.with_name("%s.qosha-%s.new" % (page.name, sv))
    if not _plain_file(new):
        return False                                    # nothing pending for this page (the usual start): no line
    def no(why):
        _log(root, "page check: %s not brought up to date (%s): %s" % (rel, "start" if not record else "after update", why))
        return False
    if not _plain_file(page):
        return no("the page is missing or not a plain file")
    try:
        mine_b = page.read_bytes()
        mine = mine_b.decode("utf-8")
        new_text = new.read_bytes().decode("utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        return no("could not be read (%s)" % type(exc).__name__)
    # the saved update copy may already carry the look link (Air, 23 Nov: the look preset re-links the freshly installed
    # page before keep_edits saves it aside): exactly the preset's line on the release page, nothing else
    rel_page = _without_look(new_text) if new_text.count(TAGS) == 1 else new_text
    if rel_page is None or not _release_page_ok(release_dir, rel, rel_page, ke):
        return no("the saved update copy is not this release's own page (%s)" % (release_dir or "no release folder"))
    healed = rel_page if rel_page.count(TAGS) == 1 else _with_look(rel_page)   # M-8: a release page already equipped
    if healed is None:
        return no("the release's page has no single head end to link the look to")
    if _lf(mine) == _lf(healed):                    # healed in phase 1 or an earlier start
        if record:
            _set_record(home, ke, rel, mine_b, rel_page.encode("utf-8"), root)   # N-1: record first
            try:
                new.unlink()
            except OSError:
                pass
            return True
        return False
    stripped = _without_look(mine)
    if stripped is None:
        return no("the page is not exactly a page plus the look link (%d look link(s))" % mine.count(TAGS))
    base = _base_for(home, rel, ke)
    try:
        same_base = base is not None and _lf(stripped) == _lf(base.decode("utf-8"))
    except UnicodeDecodeError:
        same_base = False
    if not (same_base or _sha_lf(stripped) in _known(rel)):
        return no("the page has the person's own changes besides the look link (kept, as always; %s)"
                  % _sha_lf(stripped)[:12])
    healed_b = healed.encode("utf-8")
    held = _keep_aside(home, page, mine_b)
    # staged first, then the live file compared once more right before the replace (G-7, N-3)
    outcome = _write(page, healed_b, expect=mine_b)
    if outcome == "changed":
        try:
            held.unlink()                                   # the person's page is live again: no stray copy
        except OSError:
            pass
        _log(root, "page not brought up to date: %s changed while it was checked" % rel)
        return False
    _log(root, "page brought up to date: %s was held at an older version only by the chat look link "
               "(old page kept in %s)" % (rel, held))
    if record:
        _set_record(home, ke, rel, healed_b, rel_page.encode("utf-8"), root)   # N-1: record before .new goes
        try:
            new.unlink()
        except OSError:
            pass
    return True


def _set_record(home: Path, ke, rel: str, healed_b: bytes, rel_b: bytes, root: Path | None) -> None:
    """keep_edits' record for one healed page, from one snapshot: installed copy = the healed page, BASE = the release's
    page; only what differs is written. No installed record: nothing is written (the next update compares with the
    release package instead) (G-9). Raises on a write error, so the .new (the pending marker) stays (N-1)."""
    rec_top = ke.installed_dir(home)
    if not rec_top.is_dir():
        _log(root, "page record not changed (no installed record yet)")
        return
    rec = rec_top.joinpath(*rel.split("/"))
    if not rec.parent.is_dir() or rec.parent.is_symlink():
        _log(root, "page record not changed for %s (no installed copy to go with it)" % rel)   # NEW-3: never BASE alone
        return
    try:
        same = rec.read_bytes() == healed_b
    except OSError:
        same = False
    if not same:
        _write(rec, healed_b)
    bases = ke._read_bases(home)
    if bases.get(rel) != rel_b:
        bases[rel] = rel_b
        ke._write_bases(home, bases)


_TOKEN = None          # this process's lock token while it holds the update lock (M-3: never someone else's)
_STATE = threading.Lock()   # guards _TOKEN between the worker and the exit hook (round 2, NEW-1)
_STOP = threading.Event()   # set by the exit hook: the worker never takes the lock after it
_WORKER = None
JOIN_S = 10.0               # at exit, how long a worker that holds the lock may take to finish


def _take_lock(lock: Path, root: Path | None = None) -> bool:
    global _TOKEN
    token = "page-heal %d %s" % (os.getpid(), os.urandom(8).hex())
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        return False                                        # an update or another Qosha process: quietly later
    except OSError as exc:
        _log(root, "page check: the update lock can't be taken (%s)" % type(exc).__name__)   # M-10
        return False
    try:
        os.write(fd, token.encode())
        os.close(fd)
    except OSError as exc:                                  # N-4: a lock we made but could not mark goes again
        try:
            os.close(fd)
        except OSError:
            pass
        try:
            lock.unlink()
        except OSError:
            pass
        _log(root, "page check: the update lock could not be marked (%s)" % type(exc).__name__)
        return False
    _TOKEN = token
    return True


def release_lock(root: Path) -> None:
    """The update lock, only while this process holds it with its own token (also run at exit: a process ending
    mid-heal never leaves it behind, and never removes a lock someone else took since) (M-3)."""
    global _TOKEN
    with _STATE:
        token, _TOKEN = _TOKEN, None
    if token is None:
        return
    try:
        lock = Path(root) / "run" / "update.lock"
        if lock.read_bytes().decode("utf-8", "replace") == token:
            lock.unlink()
    except OSError:
        pass


def pending(home: Path, version: str, ke) -> bool:
    """Is there phase-2 work: a .new of this release beside one of the pages (N-4: otherwise no worker, no lock)."""
    try:
        if not version or version == "0":
            return False
        live = Path(home) / "plugins" / "qosha"
        sv = ke._safe_version(version)
        for rel in PAGES:
            page = live.joinpath(*rel.split("/"))
            if _plain_file(page.with_name("%s.qosha-%s.new" % (page.name, sv))):
                return True
    except Exception:
        pass
    return False


def at_register(home: Path, version: str, ke, root: Path) -> bool:
    """Phase 1 now (the page only), and whether phase 2 has work (the caller then starts run_after_start)."""
    try:
        heal(home, version, ke, root, record=False)
    except Exception as exc:
        _log(root, "page check stopped: %s" % type(exc).__name__)
    return pending(home, version, ke)


def start_worker(home: Path, version: str, ke, root: Path, version_fn=None) -> None:
    """Phase 2 in its own thread, with the exit hook that never unlocks under it (round 2, NEW-1)."""
    global _WORKER
    import atexit
    th = threading.Thread(target=run_after_start, args=(home, version, ke, root),
                          kwargs={"version_fn": version_fn}, daemon=True, name="qosha-page-heal")
    _WORKER = th
    atexit.register(shutdown, root)
    th.start()


def shutdown(root: Path, join_s: float | None = None) -> None:
    """At exit: the worker never takes the lock after this; one that holds it gets up to JOIN_S to finish (its own
    finally releases the lock). The lock is never removed while the worker is still writing (round 2, NEW-1)."""
    with _STATE:
        _STOP.set()
        holding = _TOKEN is not None
    if not holding:
        return
    th = _WORKER
    if th is not None and th is not threading.current_thread():
        th.join(JOIN_S if join_s is None else join_s)
    if th is None or not th.is_alive():
        release_lock(root)                                  # nothing left to do when the worker already released it
    else:
        _log(root, "page check still running at exit: the update lock is left to the updater's stale-lock rule")


def run_after_start(home: Path, version: str, ke, root: Path, wait_s: float = LOCK_WAIT_S, poll_s: float = 5.0,
                    version_fn=None) -> list:
    """The one worker (G-5): waits while an update runs, takes the updater's own lock, heals, releases it. Never raises.
    Round 2: retries when another process got the lock first (NEW-2), stops when the process exits (NEW-1), and does
    nothing when no .new is pending any more or the installed version changed meanwhile (NEW-2)."""
    try:
        if not root:
            return []
        lock = Path(root) / "run" / "update.lock"
        end = time.monotonic() + wait_s
        while True:
            while lock.exists():
                if time.monotonic() >= end or _STOP.wait(poll_s):
                    return []                               # an update still running / exiting: the next start tries
            if not pending(home, version, ke):
                return []                                   # done meanwhile (another Qosha process)
            if version_fn is not None and version_fn(root) != version:
                return []                                   # another release is installed now: its own start heals
            with _STATE:
                if _STOP.is_set():
                    return []
                got = _take_lock(lock, root)
            if got:
                break
            if time.monotonic() >= end or _STOP.wait(poll_s):
                return []
        try:
            return heal(home, version, ke, root, record=True)
        finally:
            release_lock(root)
    except Exception as exc:
        _log(root, "page check stopped: %s" % type(exc).__name__)
        return []
