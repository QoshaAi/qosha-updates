"""outlook_send: the only way Qosha sends an Outlook email (strict v1, Ren 21 Nov 2026).

The person's card (ask.py, kind email.send) shows every recipient, the subject and the whole plain text given to this
tool. After Allow, Qosha's executor sends exactly those values (plain text, no attachments) with ONE Graph sendMail
call; it is never retried. Outlook's own send, reply, forward and draft tools are refused to the assistant (ask.py); this module
calls the server's sendMail tool through the engine's tool registry, which runs no hook a second time.
"""
from __future__ import annotations

import json
import re
from typing import Any, Callable, Dict, List, Optional

NAME = "outlook_send"
SERVER = "microsoft"
_EMAIL = re.compile(r"[^@\s,;<>\"']+@[^@\s,;<>\"']+\.[^@\s,;<>\"'.]+")
ALLOWED = ("to", "cc", "bcc", "subject", "body")
SCHEMA = {
    "name": NAME,
    "description": ("Send a plain-text email from the person's Outlook, after they approve it on Qosha's card. Give "
                    "every recipient (to, and cc/bcc if any), the subject and the whole text. No attachments, no "
                    "formatting, no replies in a thread (v1)."),
    "parameters": {
        "type": "object",
        "properties": {
            "to": {"type": ["array", "string"], "items": {"type": "string"}, "description": "Every To address."},
            "cc": {"type": ["array", "string"], "items": {"type": "string"}},
            "bcc": {"type": ["array", "string"], "items": {"type": "string"}},
            "subject": {"type": "string"},
            "body": {"type": "string", "description": "The whole text, as plain text."},
        },
        "required": ["to", "subject", "body"],
    },
}


def addresses(v: Any) -> Optional[List[str]]:
    """The addresses given (a list, or one comma-separated string), or None when one isn't a plain address."""
    if v is None:
        return []
    if isinstance(v, str):
        items = [x for x in v.split(",")]
    elif isinstance(v, list) and all(isinstance(x, str) for x in v):
        items = list(v)
    else:
        return None
    out = []
    for x in items:
        x = x.strip()
        if not x:
            continue
        if not _EMAIL.fullmatch(x):
            return None
        out.append(x)
    return out


def problem(a: Dict[str, Any]) -> str:
    """Why these arguments can't be sent as v1 shows them ("" when they can)."""
    extra = sorted(k for k in a if k not in ALLOWED)
    if extra:
        return ("Not sent: Qosha v1 sends plain-text emails without attachments, formatting or thread replies (%s was "
                "given). Nothing was sent." % ", ".join(extra))
    to = addresses(a.get("to"))
    cc, bcc = addresses(a.get("cc")), addresses(a.get("bcc"))
    if to is None or cc is None or bcc is None:
        return "Not sent: every recipient must be one plain email address. Nothing was sent."
    if not to:
        return "Not sent: there is no recipient. Nothing was sent."
    if not isinstance(a.get("subject"), str) or not isinstance(a.get("body"), str):
        return "Not sent: the subject and the text must be plain text. Nothing was sent."
    return ""


def _engine_dispatch(name: str, args: dict):
    from tools.registry import registry
    return registry.dispatch(name, args)


def _as_dict(r: Any) -> Optional[dict]:
    if isinstance(r, dict):
        return r
    if isinstance(r, str):
        try:
            v = json.loads(r)
        except Exception:
            return None
        return v if isinstance(v, dict) else None
    return None


_LIMIT = 500


def _parts(r: Any) -> Optional[list]:
    """Every dict anywhere in the result (nested dicts, lists and JSON text, arrays included), or None when there are
    more than Qosha reads (F5: fail closed)."""
    out, todo, seen = [], [r], 0
    while todo:
        seen += 1
        if seen > _LIMIT:
            return None
        x = todo.pop()
        if isinstance(x, str):
            try:
                x = json.loads(x)
            except Exception:
                continue
        if isinstance(x, list):
            todo.extend(x)
        elif isinstance(x, dict):
            out.append(x)
            todo.extend(v for v in x.values() if isinstance(v, (dict, list, str)))
    return out


def _failed(r: Any) -> bool:
    parts = _parts(r)
    if r is None or not parts:
        return True
    return any(("error" in d and d.get("error") not in (None, False)) or d.get("isError") is True or d.get("ok") is False
               for d in parts)


NOT_CONFIRMED = ("Outlook didn't confirm the send, so Qosha doesn't know if it went. Check Sent Items before sending it "
                 "again.")


def _strict_json(text: str) -> Any:
    """json.loads that refuses duplicate keys and NaN/Infinity (H2)."""
    def pairs(items):
        keys = [k for k, _ in items]
        if len(keys) != len(set(keys)):
            raise ValueError("duplicate key")
        return dict(items)

    def no_constant(name):
        raise ValueError("not JSON: %s" % name)
    return json.loads(text, object_pairs_hook=pairs, parse_constant=no_constant)


def confirmed(r: Any) -> bool:
    """The one result counted as sent (G2): the engine's envelope {"result": "{\"success\": true}"} (an optional "_meta"
    object beside it), nothing else."""
    try:
        d = _strict_json(r) if isinstance(r, str) else None
        if not isinstance(d, dict) or "error" in d or not set(d) <= {"result", "_meta"} or not isinstance(d.get("result"), str):
            return False
        if "_meta" in d and not isinstance(d["_meta"], dict):
            return False
        inner = _strict_json(d["result"])
        return isinstance(inner, dict) and inner == {"success": True} and inner["success"] is True
    except Exception:
        return False


def send(args: Dict[str, Any], dispatch: Optional[Callable[[str, dict], Any]] = None) -> str:
    """Send exactly the approved email with ONE Graph sendMail call (G1). Never retried: a second send is worse than a
    missing one."""
    call = dispatch or _engine_dispatch
    a = args if isinstance(args, dict) else {}
    why = problem(a)
    if why:
        return json.dumps({"ok": False, "error": why})
    msg = {"subject": a["subject"], "body": {"contentType": "Text", "content": a["body"]},
           "toRecipients": [{"emailAddress": {"address": x}} for x in addresses(a.get("to"))]}
    for key, field in (("cc", "ccRecipients"), ("bcc", "bccRecipients")):
        got = addresses(a.get(key))
        if got:
            msg[field] = [{"emailAddress": {"address": x}} for x in got]
    try:
        sent = call("mcp__%s__send_mail" % SERVER, {"body": {"message": msg, "saveToSentItems": True}})
    except Exception:
        return json.dumps({"ok": False, "error": NOT_CONFIRMED})
    if not confirmed(sent):
        return json.dumps({"ok": False, "error": NOT_CONFIRMED})
    return json.dumps({"ok": True, "sent": True, "message": "Sent from Outlook."})

def connected() -> bool:
    """Offered only when the Outlook connection is set up (config.yaml has an enabled mcp_servers.microsoft)."""
    try:
        from hermes_cli.config import load_config
        servers = (load_config() or {}).get("mcp_servers") or {}
        return isinstance(servers.get(SERVER), dict) and servers[SERVER].get("enabled", True) is not False
    except Exception:
        return False


READ_ONLY = True        # Outlook is read-only until Qosha's Microsoft executor lands (Ren, 22 Nov 2026 ~16:10 MST)


def register(ctx) -> None:
    if READ_ONLY:
        return              # not offered at all; the guard refuses a direct call too
    ctx.register_tool(name=NAME, toolset="terminal", schema=SCHEMA, handler=lambda args, **_kw: send(args),
                      check_fn=connected, description=SCHEMA["description"], emoji="\U0001F4E7")
