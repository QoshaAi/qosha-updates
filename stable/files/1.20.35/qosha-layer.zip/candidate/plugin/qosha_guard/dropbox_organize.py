"""Qosha's only way to copy, move or create folders in Dropbox (slice 3B, 22 Nov 2026; round 2 fixes).

Only inside the person's OWN, unshared Dropbox folders. Every action (copy, move, create_folder) shows the person a
card first (kind "change"). Before acting, Qosha asks Dropbox (get_file_metadata) about the destination's folder and
every source, and (list_shared_links) whether a link shares the destination folder or one above it; a destination
directly in the top folder runs only when who_am_i says this is a personal account (no team space). Anything shared,
read-only, in a team space or someone else's, anything that doesn't match the path asked about, or anything Dropbox
can't answer about, is refused (fail closed). A copy into a shared folder would be a share with no card.
Known limit: the folder can change between Qosha's check and Dropbox's action (seconds); the card and the check
narrow that, they can't close it.
"""
from __future__ import annotations

import json
import re
import unicodedata
from typing import Any, Callable, Dict, List, Optional

NAME = "dropbox_organize"
PATH_RX = re.compile(r"\A/(?:[^/\x00]+/)*[^/\x00]+\Z")      # fq_path only: no ns:, no id:, no URL, no empty part
MAX_ENTRIES = 20
SCHEMA = {
    "name": NAME,
    "description": ("Copy, move or rename files and folders, make a new folder, or make a new text file, in the "
                    "person's own Dropbox. Only "
                    "inside their own folders: never into, out of or inside a shared folder. Paths start with '/'. "
                    "Each step shows the person a card first."),
    "parameters": {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["copy", "move", "create_folder", "create_file"]},
            "entries": {"type": "array", "items": {"type": "object", "properties": {
                "from": {"type": "string"}, "to": {"type": "string"}}, "required": ["from", "to"]},
                "description": "copy and move: 1-20 pairs of full paths (to includes the final name)"},
            "path": {"type": "string", "description": "create_folder / create_file: the new folder's or file's full path"},
            "content": {"type": "string", "description": "create_file: the whole text of the new file (UTF-8 text)"},
        },
        "required": ["action"],
    },
}
NOT_OWN = "Qosha only organizes inside your own Dropbox folders; %s is shared, so it didn't. Nothing was done."
UNSURE = "Qosha couldn't check %s in your Dropbox. Nothing was done."
BAD = ("Not done: give action copy or move with 1-20 entries of full paths (from, to), create_folder with a full "
       "path, or create_file with a full path and its text. Paths start with '/'. Nothing was done.")


def _path_ok(p: Any) -> bool:
    if not (isinstance(p, str) and PATH_RX.match(p) and ".." not in p.split("/") and "." not in p.split("/")):
        return False
    try:
        p.encode("utf-8")                              # a lone surrogate (a broken character) can't be shown or sent
    except UnicodeEncodeError:
        return False
    return (unicodedata.normalize("NFC", p) == p and len(p) <= 1000
            and not any(unicodedata.category(c) in ("Cc", "Cf", "Cs", "Co", "Cn") for c in p))


def _parent(p: str) -> str:
    head = p.rsplit("/", 1)[0]
    return head or "/"


def problem(args: Any) -> str:
    """The plain refusal for arguments Qosha won't act on, or "" when they are well formed."""
    a = args if isinstance(args, dict) else {}
    act = a.get("action")
    if act == "create_folder":
        return "" if set(a) == {"action", "path"} and _path_ok(a.get("path")) else BAD
    if act == "create_file":
        c = a.get("content")
        ok = set(a) == {"action", "path", "content"} and _path_ok(a.get("path")) and isinstance(c, str)
        try:
            ok = ok and bool(c.encode("utf-8") or True)
        except (UnicodeEncodeError, AttributeError):
            ok = False
        return "" if ok else BAD
    if act in ("copy", "move"):
        e = a.get("entries")
        if set(a) - {"action", "entries"} or not isinstance(e, list) or not 1 <= len(e) <= MAX_ENTRIES:
            return BAD
        for x in e:
            if not isinstance(x, dict) or set(x) != {"from", "to"} or not _path_ok(x["from"]) or not _path_ok(x["to"]):
                return BAD
        return ""
    return BAD


def card_rows(args: Dict[str, Any]) -> List[tuple]:
    act = args.get("action")
    if act == "create_folder":
        return [("What happens", "Make a new folder in your Dropbox (your own folders only)"),
                ("New folder", str(args.get("path")))]
    if act == "create_file":
        c = str(args.get("content"))
        return [("What happens", "Make a new text file in your Dropbox (your own folders only)"),
                ("New file", str(args.get("path"))), ("Text", c if c != "" else "(empty)")]
    rows = [("What happens", ("Copy in your Dropbox (your own folders only)" if act == "copy" else
                              "Move or rename in your Dropbox (your own folders only)"))]
    for i, x in enumerate(args.get("entries") or [], 1):   # separate rows: a name holding an arrow can't blur them
        rows.append(("From (%d)" % i, x["from"]))
        rows.append(("To (%d)" % i, x["to"]))
    return rows


def _engine_dispatch(name: str, args: dict):
    from tools.registry import registry
    return registry.dispatch(name, args)


def _as_dict(r: Any) -> Optional[dict]:
    if isinstance(r, dict):
        return r
    if isinstance(r, str):
        try:
            v = json.loads(r)
            return v if isinstance(v, dict) else None
        except Exception:
            return None
    return None


# Dropbox's live answers (read on the test copy, 22 Nov 2026, journey account): get_file_metadata gives
# {"metadata_type": "file"|"folder", "file"|"folder": {"tag", "path_lower", "sharing_info", ...}}. In the person's own
# space sharing_info.parent_shared_folder_id is their HOME namespace id (who_am_i home_namespace_id); a shared folder
# has shared_folder_id, and anything inside one has another parent_shared_folder_id. Sharing ids may come wrapped as
# {"value": ...}. The older record shape (".tag", sharing_info only when shared) reads the same way.
_SI_KNOWN = frozenset("""last_modifier modified_by parent_shared_folder_id is_parent_shared_folder_read_only read_only
traverse_only no_access is_team_folder shared_folder_id shared_folder_name is_owner""".split())


def _val(x: Any) -> Any:
    if isinstance(x, dict):
        return x.get("value") if "value" in x else (None if not x else x)
    return x


def _shared(meta: dict, home: Any = None) -> bool:
    """Shared, read-only, team, no access or another owner by Dropbox's own keys (never names or paths); a parent
    shared folder other than the person's home space counts as shared; any doubt counts as shared. Every flag may come
    wrapped as {"value": ...} (round 3)."""
    si = meta.get("sharing_info")
    if si is not None and not isinstance(si, dict):
        return True
    si = si or {}
    if any(k not in _SI_KNOWN for k in si):
        return True
    for src in (meta, si):
        for k in ("shared_folder_id", "shared_folder_name", "is_team_folder", "is_inside_team_folder", "read_only",
                  "is_parent_shared_folder_read_only", "no_access", "traverse_only", "has_explicit_shared_members"):
            if _val(src.get(k)) not in (None, False, "", 0):
                return True
        if "is_owner" in src and _val(src.get("is_owner")) not in (None, True):
            return True
        psf = _val(src.get("parent_shared_folder_id"))
        if psf not in (None, "") and (home in (None, "") or str(psf) != str(home)):
            return True
    return False


def _answer(r: Any) -> Optional[dict]:
    """The engine's answer ({"result": "<server text>"}) as Dropbox's own dict, or None (error, text, list, empty)."""
    outer = _as_dict(r)
    if outer is None or outer.get("error") or outer.get("isError"):
        return None
    inner = outer.get("result", outer)
    if isinstance(inner, str):
        inner = _as_dict(inner)
    if not isinstance(inner, dict) or inner.get("error") or inner.get("isError"):
        return None
    return inner


def _key(p: str) -> str:
    return unicodedata.normalize("NFC", p).casefold()


def _metadata(r: Any, path: str = "", tag: str = "") -> Optional[dict]:
    """Dropbox's own file or folder record for exactly `path` (and of kind `tag` when given), or None: fail closed."""
    inner = _answer(r)
    if inner is None:
        return None
    mt = inner.get("metadata_type")
    shapes = [k for k in ("metadata", "file", "folder") if k in inner]
    if len(shapes) > 1 or (shapes and shapes != ["metadata"] and (not isinstance(mt, str) or shapes != [mt])) \
            or (mt is not None and shapes != [mt]):
        return None                                    # two records, or a record its type doesn't name: never chosen
    if isinstance(mt, str) and isinstance(inner.get(mt), dict):
        rec = dict(inner[mt])
    elif isinstance(inner.get("metadata"), dict):
        rec = dict(inner["metadata"])
    else:
        rec = dict(inner)
    outer = {k: v for k, v in inner.items() if k not in ("metadata", "metadata_type", "file", "folder")}
    if outer and (isinstance(mt, str) or isinstance(inner.get("metadata"), dict)):
        rec["_qosha_outer"] = outer                    # checked on its own: it can never mask the record (round 3)
    t = rec.get("tag", rec.get(".tag"))
    if t not in ("file", "folder") or (isinstance(mt, str) and mt != t) or not isinstance(rec.get("path_lower"), str):
        return None
    if tag and t != tag:
        return None
    if path and _key(rec["path_lower"]) != _key(path):
        return None
    return rec


class _Me:
    """who_am_i, asked once per step: the home space id, and whether "/" is the person's own (a personal account whose
    root space IS its home space). Both ids must be readable (round 3: no id, no step)."""

    def __init__(self, call: Callable[[str, dict], Any]):
        try:
            me = _answer(call("mcp__dropbox__who_am_i", {}))
        except Exception:
            me = None
        me = me if isinstance(me, dict) else {}
        ri = me.get("root_info") if isinstance(me.get("root_info"), dict) else {}
        good = lambda v: isinstance(v, (str, int)) and not isinstance(v, bool) and re.fullmatch(r"[0-9A-Za-z:_-]{1,64}", str(v))

        def pick(k):
            """The id, when every place that gives it agrees (top level and root_info); else None (round 3)."""
            got = [_val(src.get(k)) for src in (me, ri) if k in src]   # present at all counts: "" or null is bad
            if not got or not all(good(v) for v in got) or len({str(v) for v in got}) != 1:
                return None
            return str(got[0])
        root, home = pick("root_namespace_id"), pick("home_namespace_id")
        given = lambda k: any(k in src for src in (me, ri))
        conflict = (given("root_namespace_id") and root is None) or (given("home_namespace_id") and home is None)
        self.home = home if not conflict else None      # ids that disagree, or a bad id: no step at all
        self.ok = self.home is not None
        team = any(_val(me.get(k)) for k in ("team_id", "team", "team_member_id")) or \
            ri.get(".tag", ri.get("tag")) == "team"
        self.personal = self.ok and not team and root is not None and root == self.home


def _check(path: str, call: Callable[[str, dict], Any], me: "_Me", tag: str = "") -> str:
    """"" when Dropbox confirms path is in the person's own unshared space, else the plain refusal."""
    if not me.ok:
        return UNSURE % path
    try:
        meta = _metadata(call("mcp__dropbox__get_file_metadata", {"path_or_file_id": path}), path, tag)
    except Exception:
        meta = None
    if meta is None:
        return UNSURE % path
    outer = meta.pop("_qosha_outer", None)
    if _shared(meta, me.home) or (outer is not None and _shared(outer, me.home)):
        return NOT_OWN % path
    return ""


def _ancestors(p: str) -> List[str]:
    out = []
    while p not in ("", "/"):
        out.append(p)
        p = _parent(p)
    return out


def _linked(folder: str, call: Callable[[str, dict], Any]) -> str:
    """"" when Dropbox says no shared link is on folder or a folder above it, else the plain refusal (fail closed).
    Dropbox lists only a path's own links (checked live), so each folder up to the top is asked; the answer must be an
    empty list with has_more exactly false (round 3: any link, or anything else, refuses)."""
    for p in _ancestors(folder):
        try:
            d = _answer(call("mcp__dropbox__list_shared_links", {"path": p}))
        except Exception:
            d = None
        links = d.get("links") if isinstance(d, dict) else None
        if not isinstance(links, list) or d.get("has_more") is not False:
            return UNSURE % folder
        if links:
            return NOT_OWN % folder
    return ""


def _dest_ok(folder: str, call: Callable[[str, dict], Any], me: "_Me") -> str:
    """The folder something lands in: own, unshared, no link over it; the top folder only on a personal account."""
    if folder == "/":
        return "" if me.personal else (UNSURE % "/" if not me.ok else NOT_OWN % "/")
    return _check(folder, call, me, "folder") or _linked(folder, call)


def organize(args: Any, dispatch: Optional[Callable[[str, dict], Any]] = None) -> str:
    call = dispatch or _engine_dispatch
    a = args if isinstance(args, dict) else {}
    why = problem(a)
    if why:
        return json.dumps({"ok": False, "error": why})
    me = _Me(call)
    if a["action"] in ("create_folder", "create_file"):
        why = _dest_ok(_parent(a["path"]), call, me)
        if why:
            return json.dumps({"ok": False, "error": why})
        if a["action"] == "create_file":
            return _relay(call("mcp__dropbox__create_file", {"path": a["path"], "content": a["content"]}))
        return _relay(call("mcp__dropbox__create_folder", {"path": a["path"]}))
    checked = set()
    for x in a["entries"]:
        for p, dest in ((x["from"], False), (_parent(x["to"]), True)):
            if (p, dest) in checked:
                continue
            why = _dest_ok(p, call, me) if dest else _check(p, call, me)
            if why:
                return json.dumps({"ok": False, "error": why})
            checked.add((p, dest))
    tool = "mcp__dropbox__copy" if a["action"] == "copy" else "mcp__dropbox__move"
    return _relay(call(tool, {"entries": [{"source_path": x["from"], "destination_path": x["to"]} for x in a["entries"]],
                              "autorename": False}))


def _relay(r: Any) -> str:
    d = _as_dict(r)
    if d is not None and (d.get("error") or d.get("isError")):
        return json.dumps({"ok": False, "error": "Dropbox didn't do it: %s" % str(d.get("error") or "an error")[:200]})
    return r if isinstance(r, str) else json.dumps(r, default=str)


def available() -> bool:
    try:
        from hermes_cli.config import load_config
        servers = (load_config() or {}).get("mcp_servers") or {}
        return isinstance(servers.get("dropbox"), dict) and servers["dropbox"].get("enabled", True) is not False
    except Exception:
        return False


def register(ctx) -> None:
    ctx.register_tool(name=NAME, toolset="terminal", schema=SCHEMA, handler=lambda args, **_kw: organize(args),
                      check_fn=available, description=SCHEMA["description"], emoji="\U0001F4C1")
