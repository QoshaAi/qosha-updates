"""Qosha makes pictures with the AI accounts the person already connected (Ren, 22 Nov 2026: "I want Qosha to be able
to use the models we have available, and ask them to make something ... and posts it on the chat").

The engine's own picture tool (image_generate) stays off until a picture backend is chosen in its settings, so Qosha
answered that its AI links were text only. Here Qosha registers ONE backend of its own, "qosha", and makes it the
default when the person has not chosen one. It never spends pay-per-use money: it uses subscriptions only, best first:
  1. ChatGPT sign-in: the engine's own "openai-codex" backend (gpt-image-2 through the ChatGPT plan; no API key), only
     when the sign-in's own token goes to ChatGPT's own address;
  2. Gemini sign-in (connected in Qosha): Google's agy, run as an agent whose ONLY tool is its picture tool
     (generate_image), sandboxed, with Qosha's no-tools settings for everything else, in a fresh folder, without any
     API key or Qosha session token in its environment.
A backend the person chose themselves (image_gen.provider, image_gen.use_gateway or image_gen.model in config.yaml) is
used as they chose; Qosha never switches to it on its own. While Qosha's default is in effect the engine's pay-per-use
picture paths refuse. When no subscription can make the picture the tool says so plainly.
Slice 1 (contract IMAGEGEN-S1): making pictures. Slice 2 (contract IMAGEGEN-S2, edits): changing an existing picture
(image_url, reference_image_urls; at most 4 pictures in all) when EVERY source is a local picture this chat may use
(see _check_source): anything else is refused plainly before any account is asked. Only private copies of the checked
bytes are used: ChatGPT gets the copies' paths (the engine's own edit route), Gemini gets them copied into its fresh run
folder as source-1.<ext>, source-2.<ext>..., named only by those names.
Cross-slice fixes (Ren, 22 Nov 2026 ~20:55 MST): ChatGPT's picture is never written into the engine's home-wide cache
(it goes into a private folder of the call, removed once kept and on every failure or Stop), and that cache
(cache/generated/images) is never a source; a project chat takes sources from its own
project's folder only; a source in a place Qosha protects (the viewer's secret rule, the Files page's reserved names)
is refused; Stop and access are checked again right before an edit is uploaded; a "no" or empty picture setting is
not the person's choice.
Each picture is copied into the person's Qosha files folder (a project chat's: that project's folder), never over a
file, and shown in the chat with a MEDIA line (qosha-media.js). Same on Mac and Windows. Stop and ended access end
everything. Fail-open for set-up: if anything here cannot be set up, the engine behaves as before (tool off)."""
from __future__ import annotations

import base64
import dataclasses
import json
import logging
import os
import re
import secrets
import shutil
import stat
import subprocess
import tempfile
import threading
import time
import unicodedata
import zlib
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

log = logging.getLogger("qosha.imagegen")

NAME = "qosha"
ENABLED = True                       # the feature switch (slice 1: off; slice 4, 1.20.19: on)
GEMINI_TIMEOUT = 240                 # seconds for one Gemini picture (Google took 22-55 s in tests on 22 Nov 2026)
MAX_BYTES = 25 * 1024 * 1024
MAX_PROMPT = 4000                    # characters in one picture request (F-AGY 15)
_IMAGE_MAGIC = ((b"\x89PNG\r\n\x1a\n", "png"), (b"\xff\xd8\xff", "jpg"), (b"RIFF", "webp"), (b"GIF87a", "gif"),
                (b"GIF89a", "gif"))
_PICTURE_SUFFIXES = (".png", ".jpg", ".jpeg", ".webp")
_NOT_DEFERRED = "image_generate"
_DASH_PREFIX = "HERMES_DASHBOARD_"
_SECRET_SUFFIXES = ("_API_KEY", "_TOKEN", "_SECRET")

NONE_CONNECTED = ("None of the AI accounts connected to Qosha can make pictures right now. Connect ChatGPT (or "
                  "Gemini) in AI accounts and ask again; Claude's sign-in makes text only.")
MAX_SOURCES = 4                      # pictures to change, in all (image_url + reference_image_urls)
SOURCE_TOO_MANY = ("Qosha can change a picture using at most 4 pictures in all, so nothing was sent. Ask again with "
                   "fewer pictures.")
SOURCE_WEB = ("Qosha changes only pictures on this computer (from this chat or your Qosha files), not a web address, so "
              "nothing was sent.")
SOURCE_NOT_ALLOWED = ("Qosha changes only pictures from this chat or your Qosha files (in a project chat, only that "
                      "project's own folder), so that picture wasn't sent anywhere.")
SOURCE_MISSING = "Qosha couldn't find that picture, so nothing was sent."
SOURCE_PROTECTED = ("That picture is in a place Qosha keeps private (sign-in, pairing or secret files), so it wasn't "
                    "sent anywhere.")
SOURCE_NOT_PICTURE = ("That file isn't a picture Qosha can change (PNG, JPEG, WebP or GIF, at most 25 MB), so nothing "
                      "was sent.")
SOURCE_PREP = "Qosha couldn't prepare the picture to change just now, so nothing was sent. Ask again in a moment."
ACCESS_ENDED = "Your access to Qosha has ended, so Qosha can't make pictures."
STOPPED = "The picture was stopped."
TOO_LONG = ("That picture request is too long (more than 4,000 characters). Describe the picture more briefly and "
            "ask again.")
NO_FOLDER = ("Qosha's files folder isn't available right now, so no picture was made. Check the files folder in "
             "Qosha's settings and ask again.")
SAVE_FAILED = ("The picture was made, but Qosha couldn't save it in your files, so it isn't shown. Check that your "
               "files folder can be changed and ask again.")
PAID_REFUSED = ("Qosha couldn't make the picture just now. Qosha uses only your connected ChatGPT or Gemini "
                "subscriptions for pictures; ask again in a moment.")
CHATGPT_FAILED = "ChatGPT couldn't make this picture just now."
CHATGPT_LIMIT = ("ChatGPT's plan has reached its picture limit for now (it counts against the plan's limits); "
                 "it resets after a while.")
CHATGPT_SIGNIN = "ChatGPT's sign-in in Qosha needs to be connected again (AI accounts)."
CHATGPT_NOT_CONNECTED = "ChatGPT isn't connected in AI accounts."
GEMINI_NOT_SET_UP = "Gemini is not set up on this computer."
GEMINI_NOT_SIGNED_IN = "Gemini is not signed in on this computer yet."
GEMINI_UNREACHABLE = "Qosha could not reach Gemini just now."
GEMINI_UNSAFE = "Gemini couldn't start safely."
GEMINI_PREP = "Qosha could not prepare Gemini's safe settings."
GEMINI_START = "Gemini could not start on this computer just now."
GEMINI_SLOW = "Gemini took too long to make the picture."
GEMINI_OTHER = "Gemini tried to do something other than make the picture, so Qosha stopped it."
GEMINI_MANY = "Gemini tried to make more than one picture, so Qosha stopped it and kept none."
GEMINI_UNCLEAR = "Gemini didn't show clearly which picture it was making, so Qosha stopped it and kept none."
GEMINI_LIMIT = ("Gemini's plan has reached its limit for now (it counts against the plan's limits); it resets after "
                "a while.")
GEMINI_NO_PICTURE = "Gemini couldn't make this picture just now (Google sent no picture back)."
GEMINI_ELSEWHERE = "Gemini's picture was not in Gemini's own folder, so Qosha did not use it."
GEMINI_NO_WORKSPACE = "Qosha could not prepare a place for Gemini to work just now."
GEMINI_NAMES_FILE = ("Gemini isn't given requests that name a file or folder on this computer, so Qosha didn't send "
                     "it. Describe the picture in words only and ask again.")
NOT_AVAILABLE = "Qosha's picture maker isn't available just now, so no picture was made. Ask again in a moment."
NOT_MADE = "Qosha couldn't make the picture just now. Ask again in a moment."

GEMINI_AGENT = """---
name: {name}
description: "Qosha's picture maker: one picture with the picture tool, nothing else."
tools: [generate_image]
mainAgent: true
subagent: false
inheritMcp: false
excludeDefaultComponents: true
---

# Qosha picture maker

Make exactly one picture with the generate_image tool for the request you are given. Use no other tool. Then reply with
only the word DONE.
"""


# --- Stop and access (F-STOP) --------------------------------------------------------------------------------------
def _gate():
    """gemini_cli (access check, agy helpers), loaded lazily so a broken Gemini module never blocks ChatGPT."""
    try:
        from . import gemini_cli
        return gemini_cli
    except Exception:
        return None


def _access_ended() -> bool:
    g = _gate()
    if g is None:
        return True
    try:
        return bool(g._access_gate())
    except Exception:
        return True


def _interrupted() -> bool:
    """The person pressed Stop for this turn (the engine's per-thread interrupt)."""
    try:
        from tools.interrupt import is_interrupted
        return bool(is_interrupted())
    except Exception:
        return False


def _halt(access: bool = True) -> str:
    """The plain reason to stop now ("" to go on): access ended (fails closed) or Stop pressed."""
    if access and _access_ended():
        return ACCESS_ENDED
    if _interrupted():
        return STOPPED
    return ""


# --- where pictures go (F-SAVE) ------------------------------------------------------------------------------------
def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        h = os.environ.get("HERMES_HOME")
        return Path(h) if h else Path.home() / ".hermes"


def _network(p: str) -> bool:
    """A Windows network or device path (\\\\server\\share, //server/share): never used, as in media_api, since Windows
    would contact another computer just to resolve it."""
    return p.startswith("\\\\") or p.startswith("//") or p.startswith("\\/") or p.startswith("/\\")


def _junction(p) -> bool:
    try:
        return bool(getattr(Path(p), "is_junction", lambda: False)())
    except OSError:
        return True


def _linked(p) -> bool:
    try:
        return os.path.islink(str(p)) or _junction(p)
    except OSError:
        return True


def files_folder() -> Optional[Path]:
    """The person's Qosha files folder (the one the Files page and the chat's pictures use): the configured folder, else
    the home's files/ (made when missing). A configured folder that is missing is never replaced by another one; a
    network folder is never used."""
    f = os.environ.get(_DASH_PREFIX + "FILES_ROOT", "").strip()
    if f:
        if _network(f) or not os.path.isabs(f):
            return None
        return Path(f) if os.path.isdir(f) else None
    home = _home()
    if _network(str(home)):
        return None
    d = home / "files"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except OSError:
        return None
    return d if d.is_dir() else None


def _session_cwd() -> str:
    try:
        from agent.runtime_cwd import scoped_session_cwd
        return str(scoped_session_cwd() or "")
    except Exception:
        return ""


def _project_slug(cwd: str, root: str) -> Optional[str]:
    """projects_scope.project_of's rule, with this system's separators: the project's slug when the turn's working
    folder is <files>/Projects/<slug> (or inside it), else None."""
    if not cwd or not root:
        return None
    try:
        from .projects_scope import SLUG_RE
    except Exception:
        return None
    base = os.path.join(root, "Projects")
    nb = os.path.normcase(base)
    for c in (os.path.normpath(cwd), os.path.realpath(cwd)):
        nc = os.path.normcase(c)
        if nc.startswith(nb + os.sep):
            slug = c[len(base) + 1:].split(os.sep, 1)[0]
            return slug if SLUG_RE.match(slug) else None
    return None


def destination() -> Optional[Path]:
    """The folder this turn's picture goes to, checked BEFORE any account is asked: the files folder, or a project
    chat's own project folder. None when it can't be used (the picture is then not made at all)."""
    folder = files_folder()
    if folder is None:
        return None
    try:
        root = os.path.realpath(str(folder))
    except (OSError, ValueError):
        return None
    if _network(str(folder)) or _network(root) or not os.path.isdir(root):
        return None
    slug = _project_slug(_session_cwd(), root)
    if not slug:
        return Path(root)
    projects = os.path.join(root, "Projects")
    target = os.path.join(projects, slug)
    for p in (projects, target):
        if _linked(p) or not os.path.isdir(p):
            return None                  # a project chat's picture never goes anywhere else
    if os.path.normcase(os.path.realpath(target)) != os.path.normcase(target):
        return None
    return Path(target)


def _kind(raw: bytes) -> Optional[str]:
    for magic, ext in _IMAGE_MAGIC:
        if raw.startswith(magic) and (ext != "webp" or raw[8:12] == b"WEBP"):
            return ext
    return None


def _read_picture(p: Path) -> bytes:
    """At most MAX_BYTES + 1 bytes of a regular file that is not a link (O_NOFOLLOW where the system has it)."""
    if _linked(p):
        raise ValueError("linked file")
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(str(p), flags)
    with os.fdopen(fd, "rb") as fh:
        if not stat.S_ISREG(os.fstat(fh.fileno()).st_mode):
            raise ValueError("not a regular file")
        return fh.read(MAX_BYTES + 1)


def keep(src: str, folder: Optional[Path] = None) -> Path:
    """Copies a made picture into `folder` (default: destination()) as picture-YYYYMMDD-HHMMSS[-n].<ext>; returns the
    new path. Never overwrites a file; a half-written copy is removed. Raises ValueError for anything that is not a
    picture (checked by its bytes), too big or a link, OSError when it cannot be saved."""
    p = Path(src)
    try:
        raw = _read_picture(p)
    except OSError as exc:
        raise ValueError("no picture file") from exc
    if not raw or len(raw) > MAX_BYTES:
        raise ValueError("picture too big or empty")
    ext = _kind(raw)
    if not ext:
        raise ValueError("not a picture")
    if folder is None:
        folder = destination()
    if folder is None:
        raise OSError("files folder not available")
    stem = "picture-" + time.strftime("%Y%m%d-%H%M%S")
    for n in range(1, 1000):
        dest = Path(folder) / ("%s%s.%s" % (stem, "" if n == 1 else "-%d" % n, ext))
        try:
            fh = open(dest, "xb")           # never overwrites a file of the person's (nor follows a link there)
        except FileExistsError:
            continue
        try:
            with fh:
                fh.write(raw)
        except BaseException:
            try:
                os.unlink(dest)
            except OSError:
                pass
            raise
        return dest
    raise OSError("no free file name")


def media_line(path: str) -> str:
    """The chat's MEDIA line; a path with white space is quoted."""
    return 'MEDIA:"%s"' % path if any(c.isspace() for c in path) else "MEDIA:" + path


# --- pictures to change (slice 2, F-CONSENT) -----------------------------------------------------------------------
# The home's picture caches a chat's pictures live in (pasted, screenshots), outside a project chat only. The engine's
# generated-picture cache (cache/generated/images) is never a source: any chat's made pictures pass through it (X-1).
_CACHE_PARTS = (("cache", "images"), ("image_cache",), ("cache", "screenshots"))
_ENGINE_MADE = ("cache", "generated", "images")        # never a source, under any spelling (other folders in
#                                                        cache/generated, e.g. a Files folder set there, are not it)
_SCHEME = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]+:")      # an address (http:, data:, file:...); 2+ letters: not a drive
# The places Qosha itself protects (X-2), checked on every name below the folder a picture is taken from: the chat
# viewer's rule (dashboard/media_api.py _SECRET, copied here as it is) and the Files page's reserved names
# (dashboard/files_api.py _SENSITIVE, _SENSITIVE_DIRS, .env.*), plus the hidden names the Files page never lists.
_PROTECTED = re.compile(r"(^\.env|\.env$|\.envrc|config\.ya?ml|auth\.json|auth\.lock|credentials|\.anthropic_oauth|"
                        r"google_token|google_oauth|webhook_subscriptions|bws_cache|\.git-credentials|connector\.key|"
                        r"token|secret|password|netrc|\.pem$|\.key$|\.p12$|\.pfx$|id_rsa|id_ed|id_ecdsa|mcp-tokens|"
                        r"^pairing$)", re.I)
_RESERVED = frozenset({".env", ".envrc", "auth.json", "auth.lock", "credentials", "config.yaml", ".anthropic_oauth.json",
                       "google_token.json", "google_oauth_pending.json", "google_oauth.json",
                       "webhook_subscriptions.json", "bws_cache.json", "bws_cache.enc.json", ".git-credentials",
                       "credentials.json", "connector.key", "mcp-tokens", "pairing"})


def _protected(names) -> bool:
    """One of these names (a folder or the file, below the folder the picture is taken from) is a place Qosha keeps
    private: the viewer's secret rule, the Files page's reserved names, or a hidden name. Each name is first split the
    way the viewer splits (on either slash, media_api.py), so a backslash inside a Mac file name hides no part; every
    part is checked as written and in its NFKC form."""
    for n in names:
        for part in re.split(r"[\\/]", str(n)):
            for t in (part, unicodedata.normalize("NFKC", part)):
                low = t.lower()
                if _PROTECTED.search(t) or low in _RESERVED or low.startswith((".env.", ".")):
                    return True
    return False


class _Refused(Exception):
    """A picture to change that can't be used; .plain is the plain reason (no path, no engine name)."""

    def __init__(self, plain: str):
        super().__init__(plain)
        self.plain = plain


def _source_list(image_url, reference_image_urls) -> list:
    """The pictures to change, image_url first, each exactly as written (never trimmed: a name that differs only by a
    space is another file). An empty field (image_url or reference_image_urls given as "") means none. Refused:
    anything that is not text, a blank entry (empty or only spaces) among the pictures given, more than MAX_SOURCES
    pictures in all."""
    items = []
    if image_url is not None and image_url != "":
        items.append(image_url)
    refs = reference_image_urls
    if isinstance(refs, str):
        refs = [refs] if refs != "" else None
    if refs is not None:
        if not isinstance(refs, (list, tuple)):
            raise _Refused(SOURCE_NOT_ALLOWED)
        items.extend(refs)
    for it in items:
        if not isinstance(it, str):
            raise _Refused(SOURCE_NOT_ALLOWED)
        if not it.strip():
            raise _Refused(SOURCE_MISSING)
    if len(items) > MAX_SOURCES:
        raise _Refused(SOURCE_TOO_MANY)
    return list(items)


def _comps(p: str) -> Tuple[str, list]:
    """(drive, the path's names) split on this system's separators only."""
    drive, rest = os.path.splitdrive(p)
    seps = os.sep + (os.altsep or "")
    return drive, [c for c in re.split("[%s]" % re.escape(seps), rest) if c]


def _under(src: str, base: str) -> Optional[list]:
    """src's names below base (compared name by name, as this system compares them), or None when it is not inside."""
    sd, sc = _comps(src)
    bd, bc = _comps(base)
    if os.path.normcase(sd) != os.path.normcase(bd) or len(sc) <= len(bc):
        return None
    if any(os.path.normcase(a) != os.path.normcase(b) for a, b in zip(sc, bc)):
        return None
    return sc[len(bc):]


def _real_dir(p) -> Optional[str]:
    try:
        r = os.path.realpath(str(p))
    except (OSError, ValueError):
        return None
    if _network(str(p)) or _network(r) or not os.path.isdir(r):
        return None
    return r


def _project_of(cwd: str, root: str) -> Optional[str]:
    """projects_scope.project_of's rule, with this system's separators: None outside the Projects folder, the project's
    slug inside a project's folder, "?" for the Projects folder itself or a name that is not a project (everything in
    the files folder is then refused)."""
    if not cwd or not root:
        return None
    try:
        from .projects_scope import SLUG_RE
    except Exception:
        SLUG_RE = None
    base = os.path.join(root, "Projects")
    nb = os.path.normcase(base)
    for c in (os.path.normpath(cwd), os.path.realpath(cwd)):
        nc = os.path.normcase(c)
        if nc == nb:
            return "?"
        if nc.startswith(nb + os.sep):
            slug = c[len(base) + 1:].split(os.sep, 1)[0]
            return slug if (SLUG_RE is not None and SLUG_RE.match(slug)) else "?"
    return None


def _link_on_way(p: str) -> bool:
    """A link is on the way to the folder p (p itself included) that the person or their programs made: True. Only
    the system's own aliases, owned by the system's administrator account (as macOS's /var and /tmp), are passed
    over; on Windows every link and junction counts. Anything that can't be checked counts as a link."""
    try:
        a = os.path.abspath(str(p))
        drive, names = _comps(a)
        cur = drive + os.sep
        for name in names:
            cur = os.path.join(cur, name)
            st = os.lstat(cur)
            if stat.S_ISLNK(st.st_mode) or _junction(cur):
                if os.name != "nt" and stat.S_ISLNK(st.st_mode) and getattr(st, "st_uid", -1) == 0:
                    continue
                return True
    except (OSError, ValueError):
        return True
    return False


def _spellings(paths, real: str) -> Optional[tuple]:
    """The absolute spellings among `paths` that resolve to exactly the folder `real`, plus `real` itself (so a source
    written either way is recognised; a spelling that leads anywhere else is never used). None when one of those
    spellings reaches the folder through a link (_link_on_way): the folder is then not used at all."""
    out = []
    for p in paths:
        if not p:
            continue
        try:
            if not os.path.isabs(str(p)) or _network(str(p)):
                continue
            a = os.path.abspath(str(p))
            if os.path.normcase(os.path.realpath(a)) != os.path.normcase(real):
                continue
        except (OSError, ValueError):
            continue
        if _link_on_way(a):
            return None
        if a not in out:
            out.append(a)
    if real not in out:
        out.append(real)
    return tuple(out)


def _source_areas() -> list:
    """Where a picture to change may be: [(kind, spellings of the area, real start, names from the start to the area,
    project slug)]. First the engine's generated-picture cache ("never": nothing in it is used), then the files folder
    (its project rule from the turn's working folder) and, outside a project chat only, the home's picture caches (no
    link from the home's real folder down). A files folder or home reached through a link (_spellings) gives no area:
    nothing in it is used. Without a usable files folder the chat's project can't be known: no area at all."""
    areas = []
    folder = files_folder()
    real = _real_dir(folder) if folder is not None else None
    if not real:
        return []
    slug = _project_of(_session_cwd(), real)
    home = _home()
    homes = None
    real_home = None
    if not _network(str(home)):
        real_home = _real_dir(home)
        if real_home:
            homes = _spellings((str(home), os.environ.get("HERMES_HOME", "").strip()), real_home)
            if homes is not None:
                areas.append(("never", tuple(os.path.join(h, *_ENGINE_MADE) for h in homes), real_home, _ENGINE_MADE,
                              None))
    spelled = _spellings((str(folder), os.environ.get(_DASH_PREFIX + "FILES_ROOT", "").strip()), real)
    if spelled is not None:
        areas.append(("files", spelled, real, (), slug))
    if slug is None and homes is not None:              # a project chat uses only its own project's folder (X-1)
        for lead in _CACHE_PARTS:
            areas.append(("cache", tuple(os.path.join(h, *lead) for h in homes), real_home, lead, None))
    return areas


def _same_names(a: list, b: list) -> bool:
    return len(a) >= len(b) and all(x.casefold() == y.casefold() for x, y in zip(a, b))


def _engine_made(real_path: str) -> bool:
    """real_path (a real path, no link on its way) is inside the home's engine-made picture cache, compared name by
    name without regard to case (a case-insensitive disk spells the same folder many ways): never a source."""
    try:
        real_home = os.path.realpath(str(_home()))
    except (OSError, ValueError):
        return True
    hd, hn = _comps(real_home)
    pd, pn = _comps(real_path)
    if hd.casefold() != pd.casefold() or not _same_names(pn, hn):
        return False
    return _same_names(pn[len(hn):], list(_ENGINE_MADE))


def _read_source(start: str, names: tuple) -> Tuple[bytes, str]:
    """The picture at start/names: every folder on the way a real folder (no link), the file itself a regular file
    with one name (no link of any kind), at most MAX_BYTES, a picture by its bytes. (bytes, kind)."""
    cur = start
    st = None
    for i, name in enumerate(names):
        cur = os.path.join(cur, name)
        try:
            st = os.lstat(cur)
        except FileNotFoundError:
            raise _Refused(SOURCE_MISSING)
        except OSError:
            raise _Refused(SOURCE_NOT_ALLOWED)
        if stat.S_ISLNK(st.st_mode) or _junction(cur):
            raise _Refused(SOURCE_NOT_ALLOWED)
        if i < len(names) - 1:
            if not stat.S_ISDIR(st.st_mode):
                raise _Refused(SOURCE_MISSING)
        elif not stat.S_ISREG(st.st_mode):
            raise _Refused(SOURCE_NOT_ALLOWED)
    if st is None:
        raise _Refused(SOURCE_NOT_ALLOWED)
    if os.path.normcase(os.path.realpath(cur)) != os.path.normcase(cur):
        raise _Refused(SOURCE_NOT_ALLOWED)
    if getattr(st, "st_nlink", 1) > 1:                   # another name elsewhere for the same file (a hard link)
        raise _Refused(SOURCE_NOT_ALLOWED)
    if st.st_size <= 0 or st.st_size > MAX_BYTES:
        raise _Refused(SOURCE_NOT_PICTURE)
    flags = (os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
             | getattr(os, "O_NONBLOCK", 0))
    fd = os.open(cur, flags)
    with os.fdopen(fd, "rb") as fh:
        fst = os.fstat(fh.fileno())
        if not stat.S_ISREG(fst.st_mode) or (fst.st_dev, fst.st_ino) != (st.st_dev, st.st_ino):
            raise _Refused(SOURCE_NOT_ALLOWED)            # changed between the check and the read
        raw = fh.read(MAX_BYTES + 1)
    if not raw or len(raw) > MAX_BYTES:
        raise _Refused(SOURCE_NOT_PICTURE)
    kind = _kind(raw)
    use = _whole_picture(raw, kind) if kind else None
    if not use:
        raise _Refused(SOURCE_NOT_PICTURE)
    return use, kind


# --- a whole picture, checked from its first byte to its last ------------------------------------------------------
MAX_PIXEL_BYTES = 1 << 30            # a PNG's unpacked rows, at most (larger ones are not checked, so not used)
_PNG_DEPTHS = {0: (1, (1, 2, 4, 8, 16)), 2: (3, (8, 16)), 3: (1, (1, 2, 4, 8)), 4: (2, (8, 16)), 6: (4, (8, 16))}
_ADAM7 = ((0, 0, 8, 8), (4, 0, 8, 8), (0, 4, 4, 8), (2, 0, 4, 4), (0, 2, 2, 4), (1, 0, 2, 2), (0, 1, 1, 2))
_JPEG_SOF = frozenset(range(0xC0, 0xD0)) - {0xC4, 0xC8, 0xCC}


def _be(b: bytes) -> int:
    return int.from_bytes(b, "big")


def _le(b: bytes) -> int:
    return int.from_bytes(b, "little")


def _padding_only(rest: bytes) -> bool:
    """Nothing but zero bytes after a picture's end (nothing else rides along with it)."""
    return not rest.strip(b"\x00")


def _png_rows_ok(w: int, h: int, depth: int, ch: int, interlaced: bool, idat: list) -> bool:
    """The PNG's compressed picture data unpacks completely (to the end of its stream, nothing after it) into exactly
    the rows its size says, each row with a known filter."""
    rows = []
    for xs, ys, dx, dy in (_ADAM7 if interlaced else ((0, 0, 1, 1),)):
        pw = (w - xs + dx - 1) // dx if w > xs else 0
        ph = (h - ys + dy - 1) // dy if h > ys else 0
        if pw and ph:
            rows.append((ph, 1 + (pw * ch * depth + 7) // 8))
    total = sum(r * n for r, n in rows)
    if not total or total > MAX_PIXEL_BYTES:
        return False

    def row_starts():
        base = 0
        for r, n in rows:
            for i in range(r):
                yield base + i * n
            base += r * n

    starts = row_starts()
    nxt = next(starts, None)
    made = 0
    d = zlib.decompressobj()
    data = b"".join(idat)
    while not d.eof:
        before = len(data)
        out = d.decompress(data, 1 << 20)
        end = made + len(out)
        if end > total:
            return False
        while nxt is not None and nxt < end:
            if out[nxt - made] > 4:
                return False
            nxt = next(starts, None)
        made = end
        data = d.unconsumed_tail
        if not out and (not data or len(data) == before):
            break                                        # nothing more comes: cut short
    return d.eof and not d.unused_data and made == total and nxt is None


_PNG_END = b"\x00\x00\x00\x00IEND\xaeB`\x82"   # a PNG's end mark (no data, its own check sum)


def _png_chunk(raw: bytes, pos: int) -> Optional[tuple]:
    """(type, data, where the next part starts) of the PNG part at pos; None when it is not whole (cut short, a wrong
    check sum, a name that isn't letters)."""
    n = len(raw)
    if pos + 12 > n:
        return None
    ln, typ = _be(raw[pos:pos + 4]), raw[pos + 4:pos + 8]
    if ln > 0x7FFFFFFF or pos + 12 + ln > n or not all(65 <= c <= 90 or 97 <= c <= 122 for c in typ):
        return None
    data = raw[pos + 8:pos + 8 + ln]
    if zlib.crc32(typ + data) & 0xFFFFFFFF != _be(raw[pos + 8 + ln:pos + 12 + ln]):
        return None
    return typ, data, pos + 12 + ln


def _png_tail_ok(raw: bytes, pos: int) -> bool:
    """After the picture data: only whole parts any reader may skip, up to the end mark, then nothing but zero bytes."""
    while True:
        c = _png_chunk(raw, pos)
        if c is None:
            return False
        typ, _data, pos = c
        if typ == b"IEND":
            return _padding_only(raw[pos:])
        if typ in (b"IHDR", b"PLTE", b"IDAT") or not typ[0] & 0x20:
            return False


def _png_picture(raw: bytes) -> Optional[bytes]:
    """The PNG's bytes to use, or None. Every part up to the end of its picture data must be whole (header, palette,
    picture data that unpacks completely into exactly its rows): a cut-off picture is refused. When what follows the
    picture data is its proper ending, the file is used as it is; otherwise (a damaged or missing end mark, anything
    else after the picture) only the picture, up to the end of its data, is used, with a fresh end mark: whatever
    came after the picture is never sent."""
    pos = 8
    ihdr = None
    plte = False
    idat: list = []
    while True:
        c = _png_chunk(raw, pos)
        if c is None:
            if idat:
                break                                    # the picture data has ended; the rest is damaged
            return None
        typ, data, nxt = c
        if ihdr is None:
            if typ != b"IHDR" or len(data) != 13:
                return None
            w, h = _be(data[0:4]), _be(data[4:8])
            depth, color, comp, filt, inter = data[8:13]
            if not (0 < w <= 0x7FFFFFFF and 0 < h <= 0x7FFFFFFF) or color not in _PNG_DEPTHS:
                return None
            ch, depths = _PNG_DEPTHS[color]
            if depth not in depths or comp != 0 or filt != 0 or inter not in (0, 1):
                return None
            ihdr = (w, h, depth, ch, inter == 1, color)
            pos = nxt
            continue
        if typ == b"IDAT":
            idat.append(data)
            pos = nxt
            continue
        if idat:
            break                                        # the picture data has ended at pos
        if typ in (b"IEND", b"IHDR"):
            return None                                  # ended (or started again) before any picture data
        if typ == b"PLTE":
            if plte or ihdr[5] in (0, 4) or not data or len(data) % 3 or len(data) // 3 > 256:
                return None
            plte = True
        elif not typ[0] & 0x20:
            return None                                  # a part every reader must know, that none knows
        pos = nxt
    if ihdr is None or (ihdr[5] == 3 and not plte):
        return None
    if not _png_rows_ok(ihdr[0], ihdr[1], ihdr[2], ihdr[3], ihdr[4], idat):
        return None
    if _png_tail_ok(raw, pos):
        return raw
    out = raw[:pos] + _PNG_END
    return out if len(out) <= MAX_BYTES else None


def _jpeg_ok(raw: bytes) -> bool:
    """Every part of the JPEG in order, from its start to its end mark: one frame with a size, at least one scan
    with data, the end mark, nothing after it."""
    n = len(raw)
    pos = 2
    sof = False
    scans = 0
    while True:
        if pos >= n or raw[pos] != 0xFF:
            return False
        while pos < n and raw[pos] == 0xFF:
            pos += 1
        if pos >= n:
            return False
        m = raw[pos]
        pos += 1
        if m == 0xD9:
            return sof and scans > 0 and _padding_only(raw[pos:])
        if m in (0x00, 0xD8) or 0xD0 <= m <= 0xD7:
            return False
        if m == 0x01:
            continue
        if pos + 2 > n:
            return False
        ln = _be(raw[pos:pos + 2])
        if ln < 2 or pos + ln > n:
            return False
        seg = raw[pos + 2:pos + ln]
        pos += ln
        if m in _JPEG_SOF:
            if sof or len(seg) < 6:
                return False
            nf = seg[5]
            if (not 2 <= seg[0] <= 16 or not _be(seg[1:3]) or not _be(seg[3:5]) or not 1 <= nf <= 4
                    or len(seg) != 6 + 3 * nf):
                return False
            sof = True
        elif m == 0xDA:
            if not sof or not seg or not 1 <= seg[0] <= 4 or len(seg) != 4 + 2 * seg[0]:
                return False
            start = pos
            while True:                                  # the scan's data, up to the next mark
                i = raw.find(b"\xff", pos)
                if i < 0 or i + 1 >= n:
                    return False
                c = raw[i + 1]
                if c == 0x00 or 0xD0 <= c <= 0xD7:
                    pos = i + 2
                    continue
                if c == 0xFF:
                    pos = i + 1
                    continue
                break
            if i == start:
                return False
            pos = i
            scans += 1


def _gif_blocks(raw: bytes, pos: int) -> Tuple[int, int]:
    """(where the sub-blocks starting at pos end, how many data bytes they hold); (-1, 0) when they are cut short."""
    n = len(raw)
    total = 0
    while pos < n:
        k = raw[pos]
        pos += 1
        if k == 0:
            return pos, total
        pos += k
        total += k
    return -1, 0


def _gif_ok(raw: bytes) -> bool:
    """Every block of the GIF in order, up to its end mark: at least one image with a size and picture data, nothing
    after the end mark."""
    n = len(raw)
    if n < 14:
        return False
    packed = raw[10]
    pos = 13 + (3 * (2 << (packed & 7)) if packed & 0x80 else 0)
    images = 0
    while True:
        if pos < 0 or pos >= n:
            return False
        b = raw[pos]
        if b == 0x3B:
            return images > 0 and _padding_only(raw[pos + 1:])
        if b == 0x21:
            if pos + 2 > n:
                return False
            pos, _size = _gif_blocks(raw, pos + 2)
        elif b == 0x2C:
            if pos + 10 > n:
                return False
            if not _le(raw[pos + 5:pos + 7]) or not _le(raw[pos + 7:pos + 9]):
                return False
            p = raw[pos + 9]
            pos += 10 + (3 * (2 << (p & 7)) if p & 0x80 else 0)
            if pos >= n or not 2 <= raw[pos] <= 8:
                return False
            pos, size = _gif_blocks(raw, pos + 1)
            if pos < 0 or not size:
                return False
            images += 1
        else:
            return False


def _riff_chunks(raw: bytes, pos: int, end: int) -> Optional[list]:
    out = []
    while pos < end:
        if pos + 8 > end:
            return None
        cc, ln = raw[pos:pos + 4], _le(raw[pos + 4:pos + 8])
        if pos + 8 + ln > end:
            return None
        out.append((cc, raw[pos + 8:pos + 8 + ln]))
        pos += 8 + ln + (ln & 1)
    return out if pos == end else None


def _webp_frame_ok(cc: bytes, d: bytes) -> bool:
    if cc == b"VP8 ":
        if len(d) < 10:
            return False
        tag = d[0] | d[1] << 8 | d[2] << 16
        return (not tag & 1 and (tag >> 1) & 7 <= 3 and d[3:6] == b"\x9d\x01\x2a" and _le(d[6:8]) & 0x3FFF > 0
                and _le(d[8:10]) & 0x3FFF > 0 and 10 + (tag >> 5) <= len(d))
    if cc == b"VP8L":
        return len(d) > 5 and d[0] == 0x2F and _le(d[1:5]) >> 29 == 0
    return False


def _webp_ok(raw: bytes) -> bool:
    """The WebP's container holds exactly its parts, end to end, with a picture (or every frame of an animation)
    whose header and size are whole."""
    n = len(raw)
    if n < 20 or _le(raw[4:8]) + 8 != n:
        return False
    chunks = _riff_chunks(raw, 12, n)
    if not chunks:
        return False
    cc, d = chunks[0]
    if cc != b"VP8X":
        return len(chunks) == 1 and _webp_frame_ok(cc, d)
    if len(d) < 10:
        return False
    if d[0] & 0x02:                                      # an animation: every frame whole
        frames = [f for c, f in chunks[1:] if c == b"ANMF"]
        if not frames:
            return False
        for f in frames:
            inner = _riff_chunks(f, 16, len(f)) if len(f) > 16 else None
            pics = [(c, x) for c, x in (inner or ()) if c in (b"VP8 ", b"VP8L")]
            if len(pics) != 1 or not _webp_frame_ok(*pics[0]):
                return False
        return True
    pics = [(c, x) for c, x in chunks[1:] if c in (b"VP8 ", b"VP8L")]
    return len(pics) == 1 and _webp_frame_ok(*pics[0])


def _whole_picture(raw: bytes, kind: str) -> Optional[bytes]:
    """The bytes to use when the file is a whole picture of its kind, else None. A cut-off picture is never one. A
    JPEG, GIF or WebP is checked to its last byte (a padded-out file, or one with something else after the picture,
    is not one); a PNG as _png_picture says (what follows its whole picture data is never sent unless it is the
    PNG's proper ending)."""
    try:
        if kind == "png":
            return _png_picture(raw)
        check = {"jpg": _jpeg_ok, "gif": _gif_ok, "webp": _webp_ok}.get(kind)
        return raw if check is not None and check(raw) else None
    except (IndexError, ValueError, TypeError, OverflowError, MemoryError, zlib.error):
        return None


def _check_source(src: str, areas: list) -> Tuple[bytes, str]:
    """One picture to change, checked before any account is asked: an absolute local path (no web, data: or file:
    address, no network share), inside the files folder (in a project chat only that project's folder; outside a
    project chat not inside Projects/) or one of the home's picture caches; then read as _read_source says.
    (bytes, kind), or _Refused."""
    if not isinstance(src, str) or not src or "\x00" in src:
        raise _Refused(SOURCE_NOT_ALLOWED)
    if src.lower().startswith(("http://", "https://", "www.")):
        raise _Refused(SOURCE_WEB)
    if _SCHEME.match(src) or _network(src):
        raise _Refused(SOURCE_NOT_ALLOWED)
    drive, names = _comps(src)
    if not os.path.isabs(src) or (os.name == "nt" and not drive):
        raise _Refused(SOURCE_NOT_ALLOWED)
    if not names or any(n in (".", "..") for n in names) or (os.name == "nt" and any(":" in n for n in names)):
        raise _Refused(SOURCE_NOT_ALLOWED)
    if os.name == "nt" and any(n != n.rstrip(" .") for n in names):
        raise _Refused(SOURCE_NOT_ALLOWED)       # Windows drops a name's last spaces and dots: another file

    for kind, bases, start, lead, slug in areas:
        rel = None
        for b in bases:
            rel = _under(src, b)
            if rel is not None:
                break
        if rel is None:
            continue
        if kind == "never":                     # the engine's generated-picture cache: never a source (X-1)
            raise _Refused(SOURCE_NOT_ALLOWED)
        if kind == "files":                     # inside the files folder: its rule decides, whatever else matches
            if slug is not None:                # a project chat: only its own project's folder
                if slug == "?" or len(rel) < 3 or rel[0] != "Projects" or rel[1] != slug:
                    raise _Refused(SOURCE_NOT_ALLOWED)
            elif rel[0].casefold() == "projects":
                raise _Refused(SOURCE_NOT_ALLOWED)
        if _protected(rel):                     # a place Qosha keeps private (X-2)
            raise _Refused(SOURCE_PROTECTED)
        names = tuple(lead) + tuple(rel)
        if _engine_made(os.path.join(start, *names)):
            raise _Refused(SOURCE_NOT_ALLOWED)  # the engine's made-picture cache, reached another way (X-1)
        try:
            return _read_source(start, names)
        except _Refused:
            raise
        except (OSError, ValueError):
            raise _Refused(SOURCE_NOT_ALLOWED)
    raise _Refused(SOURCE_NOT_ALLOWED)


def _write_new(path: str, raw: bytes) -> str:
    """Writes a new file (never over one, never through a link); a half-written one is removed."""
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0),
                 0o600)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(raw)
    except BaseException:
        try:
            os.unlink(path)
        except OSError:
            pass
        raise
    return path


def _private_copies(pics: list) -> Tuple[str, list]:
    """The checked bytes copied into a new private folder as source-1.<ext>, source-2.<ext>...: (folder, paths). Only
    these copies are used from here on; the caller removes the folder."""
    d = tempfile.mkdtemp(prefix="qosha-img-src-")
    try:
        return d, [_write_new(os.path.join(d, "source-%d.%s" % (i, ext)), raw) for i, (raw, ext) in enumerate(pics, 1)]
    except BaseException:
        shutil.rmtree(d, ignore_errors=True)
        raise


# --- ChatGPT (F-PAID) ----------------------------------------------------------------------------------------------
def _codex():
    """The engine's ChatGPT-sign-in picture backend, or None."""
    try:
        from tools.image_generation_tool import _get_plugin_provider
        return _get_plugin_provider("openai-codex")
    except Exception:
        return None


def _chatgpt_credential() -> Optional[Tuple[str, str]]:
    """(token, address) only when the engine's resolved ChatGPT credential is the auth.json sign-in's own access token
    AND it goes to ChatGPT's official address; else None (a pooled key, another address: the route is not available).
    The request is then sent with exactly this pair (never resolved a second time)."""
    try:
        from agent.auxiliary_client import _read_codex_singleton_token, _resolve_codex_credential_and_base
        from agent.codex_headers import is_official_codex_base_url
        token, base = _resolve_codex_credential_and_base()
        own = _read_codex_singleton_token()
        if not isinstance(token, str) or not isinstance(own, str) or not token.strip() or not own.strip():
            return None
        base = str(base or "")
        if secrets.compare_digest(token.strip(), own.strip()) and is_official_codex_base_url(base):
            return token.strip(), base
    except Exception:
        pass
    return None


def _chatgpt_signed_in() -> bool:
    return _chatgpt_credential() is not None


def _codex_parts(p, edit: bool = False) -> Optional[tuple]:
    """The engine's ChatGPT backend's own request pieces (from its module), so the request goes out with the credential
    Qosha checked: (post, model, size, save[, the edit route's picture inputs]). None when they can't be found (no
    request is made then)."""
    keys = ("_post_image_request", "_resolve_model", "size_for", "save_b64_image")
    if edit:
        keys += ("_normalize_input_images",)
    try:
        ns = type(p).generate.__globals__
        parts = tuple(ns[k] for k in keys)
    except Exception:
        return None
    return parts if all(callable(x) for x in parts) else None


def chatgpt_ready() -> bool:
    if not _chatgpt_signed_in():
        return False
    p = _codex()
    try:
        return bool(p is not None and p.is_available())
    except Exception:
        return False


def _plain_chatgpt_error(res: dict) -> str:
    err = str(res.get("error") or "")
    low = err.lower()
    if "http 429" in low or "usage limit" in low or "rate limit" in low or "usage_limit" in low or "quota" in low:
        return CHATGPT_LIMIT
    if "http 401" in low or "http 403" in low or res.get("error_type") == "auth_required":
        return CHATGPT_SIGNIN
    return CHATGPT_FAILED


def via_chatgpt(prompt: str, aspect: str, sources: Optional[list] = None) -> dict:
    """One ChatGPT picture, sent with the very token and address checked here. With sources (the private copies'
    paths, already checked), the engine's own edit route changes them. {"ok": True, "path", ...} or
    {"ok": False, "plain"[, "made"]}; "made" = a picture came back but could not be saved (no second account then)."""
    p = _codex()
    cred = _chatgpt_credential() if p is not None else None     # checked right before the request, and bound to it
    if p is None or cred is None:
        return {"ok": False, "plain": CHATGPT_NOT_CONNECTED}
    sources = list(sources or [])
    parts = _codex_parts(p, edit=bool(sources))
    if parts is None:
        log.warning("ChatGPT picture backend pieces not found; no request made")
        return {"ok": False, "plain": CHATGPT_FAILED}
    post, model_of, size_of = parts[:3]     # the engine's save_b64_image is not used: it writes home-wide (X-1)
    token, base = cred
    try:
        tier, meta = model_of()
        extra = {}
        if sources:
            images = parts[4](sources[0], sources[1:] or None)
            if not isinstance(images, list) or len(images) != len(sources):
                log.warning("ChatGPT edit inputs not prepared; no request made")
                return {"ok": False, "plain": CHATGPT_FAILED}
            extra["input_images"] = images
        size = size_of(aspect)
        why = _halt()                   # Stop or ended access while the pictures were read and encoded (X-3): the
        if why:                         # request is never sent
            return {"ok": False, "plain": why, "stop": True}
        payload = post(token, prompt=prompt, size=size, quality=meta["quality"], base_url=base, **extra)
    except Exception as exc:
        log.info("ChatGPT picture refused: %s", type(exc).__name__)
        return {"ok": False, "plain": _plain_chatgpt_error({"error": str(exc)})}
    why = _halt()                       # Stop or ended access while ChatGPT worked: nothing is written anywhere
    if why:
        return {"ok": False, "plain": why, "stop": True}
    data = payload.get("data") if isinstance(payload, dict) else None
    b64 = data[0].get("b64_json") if isinstance(data, list) and data and isinstance(data[0], dict) else None
    if not isinstance(b64, str) or not b64:
        log.info("ChatGPT picture refused: no picture in the answer")
        return {"ok": False, "plain": CHATGPT_FAILED}
    # The picture is decoded into a new private folder owned by this call (never the engine's home-wide
    # cache/generated/images, where any chat could pick it up, nor a half-written copy there: X-1). A failed write
    # removes its own file and the folder; the caller removes the folder once keep() is done, on failure and on Stop.
    out_dir = None
    try:
        raw = base64.b64decode(b64)
        out_dir = tempfile.mkdtemp(prefix="qosha-img-out-")
        saved = _write_new(os.path.join(out_dir, "qosha_chatgpt.png"), raw)
    except Exception as exc:                                    # made, but not saved: the request ends here
        log.warning("ChatGPT picture not written: %s", type(exc).__name__)
        _drop_private_result(out_dir)
        return {"ok": False, "plain": SAVE_FAILED, "made": True}
    return {"ok": True, "path": str(saved), "private": out_dir, "model": str(tier or "gpt-image-2"), "by": "ChatGPT"}


def _drop_private_result(folder) -> None:
    """Removes the private folder ChatGPT's picture was written into (via_chatgpt), with everything in it."""
    if not folder:
        return
    try:
        shutil.rmtree(folder)
    except FileNotFoundError:
        return
    except OSError as exc:
        log.warning("ChatGPT's private picture copy not removed: %s", type(exc).__name__)


# --- Gemini (F-CONSENT, F-AGY) -------------------------------------------------------------------------------------
def _agy_path() -> str:
    g = _gate()
    if g is None:
        return ""
    try:
        name, path = g.find()
    except Exception:
        return ""
    return path if name == "agy" and path else ""


def gemini_ready() -> bool:
    """agy present AND Gemini connected in Qosha (Qosha's own marker): a disconnected account is never used."""
    g = _gate()
    if g is None or not _agy_path():
        return False
    try:
        return bool(g.connected())
    except Exception:
        return False


_NAMES_A_FILE = re.compile(
    r"(?<![a-z])file:(?!\s)"                          # file: links (also my_file:, x-file:)
    r"|~[\\/]"                                        # ~/ anywhere (use~/Desktop, -~/Desktop)
    r"|~[a-z_][\w.-]*[\\/]"                           # ~name/
    r"|(?<![a-z0-9])[a-z]:[\\/]"                      # drive letters (C:\, c:/)
    r"|\\\\|\\/|/\\"                                  # network shares (\\server\share) and mixed separators
    r"|(?<!https:)(?<!http:)//"                       # //server/share (only a web link's // is fine)
    r"|(?<![\w%\\/])[\\/](?=[^\s\\/])"                # a token that starts at the root, whatever comes after it
                                                      # (/Users, /@x, /(x), /$x; also image:/Users, path:\Users)
    r"|(?<![\w.])\.{1,2}[\\/]"                        # ./ and ../
    r"|(?:\$\{?[a-z_]\w*\}?|%[a-z_]\w*%)[\\/]"        # $HOME/, %USERPROFILE%\
    r"|[\"'`\u2018\u2019\u201c\u201d(\[<{]\s*[\\/~]\s*[\"'`\u2018\u2019\u201c\u201d)\]>}]"   # a quoted root: '/', "\", (~)
    r"|\b(?:folder|director(?:y|ies)|dir|path|root|drive|disk|volume|location)s?\s*[:=]?\s*[\\/](?![\w.~-])"
                                                      # the root named as a folder: "the folder /", "path: /"
    r"|\A\s*[\\/~]\s*\Z",                             # the request is just a root
    re.IGNORECASE)


_PICTURE_NAME = re.compile(
    r"\w[\w.+@#~-]*\.(?:a?png|jpe?g|jpe|jfif|pjpeg|pjp|webp|gif|bmp|dib|tiff?|heic|heif|avif|svg|ico|icns|psd|raw|dng"
    r"|cr2|cr3|nef|arw|orf|rw2|jxl|jp2|tga)(?!\w)",
    re.IGNORECASE)


def names_a_file(text: str, allowed=()) -> bool:
    """The request text names a file or folder on this computer: a path, or a picture's file name (portrait.png).
    Google's picture tool reads a picture from any path named in the request, even outside its folder and with file
    reading denied, so such a request is never given to Gemini. `allowed`: the only picture names the request may
    use (Qosha's own instruction naming the pictures it copied into the run folder; the person's text gets none).
    Ordinary text with a slash (50/50, red/blue) or a ratio (3:4) is fine."""
    t = unicodedata.normalize("NFKC", text or "")
    t = "".join(c for c in t if unicodedata.category(c) != "Cf")       # no invisible characters in between
    if _NAMES_A_FILE.search(t):
        return True
    ok = {a.casefold() for a in allowed or ()}
    return any(m.group(0).casefold() not in ok for m in _PICTURE_NAME.finditer(t))


def _clean_env(env: Dict[str, str]) -> Dict[str, str]:
    """agy's environment without pay-per-use keys or Qosha's own session tokens."""
    out = {}
    for k, v in env.items():
        u = str(k).upper()
        if u.endswith(_SECRET_SUFFIXES) or u == "FAL_KEY" or u.startswith(_DASH_PREFIX):
            continue
        out[k] = v
    return out


def _models_ok(g, path: str, env: Dict[str, str]) -> dict:
    """gemini_cli._usable's check (`agy models`, which never opens a sign-in), with the cleaned environment. Stop and
    ended access end the listing at once (checked while it runs, as in the picture run's wait)."""
    proc = None
    readers: list = []
    outs: list = []
    errs: list = []
    try:                     # stdin: an empty pipe, closed at once (as for the picture run), not the null device
        proc = subprocess.Popen([path, "models"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, shell=False, env=env, **g._spawn_kw())
        try:
            proc.stdin.close()
        except (OSError, ValueError):
            pass
        readers = [threading.Thread(target=g._drain, args=(proc.stdout, outs), daemon=True),
                   threading.Thread(target=g._drain, args=(proc.stderr, errs), daemon=True)]
        for t in readers:
            t.start()
        end = time.monotonic() + 30
        n = 0
        while proc.poll() is None:
            why = _halt(access=(n % 5 == 0))         # Stop every 0.2 s, access every second: the listing ends at once
            n += 1
            if why:
                return {"ok": False, "plain": why, "stop": True}
            if time.monotonic() > end:
                log.warning("Gemini model list took too long")
                return {"ok": False, "plain": GEMINI_UNREACHABLE}
            time.sleep(0.2)
        _reap(g, proc, readers)                      # all of its output read before it is judged
        code = proc.returncode
    except Exception as exc:
        log.warning("Gemini model list could not run: %s", type(exc).__name__)
        return {"ok": False, "plain": GEMINI_UNREACHABLE}
    finally:
        _reap(g, proc, readers)
    stdout = b"".join(outs)
    text = (stdout + b"".join(errs)).decode("utf-8", "replace").lower()
    if "please sign in" in text or "not logged in" in text or "not signed in" in text:
        return {"ok": False, "plain": GEMINI_NOT_SIGNED_IN}
    if code != 0 or not g._ROW.search(stdout):
        log.warning("Gemini model list unusable (exit %s)", code)
        return {"ok": False, "plain": GEMINI_UNREACHABLE}
    return {"ok": True}


class _Watch:
    """agy's stream-json as it arrives, whole lines only: tool steps (any tool but generate_image counts as other; each
    distinct generate_image step_index counts once; a picture step without a valid step_index is refused) and the
    result event. Every conversation id seen is kept, so a refused run's pictures can be found and removed."""

    def __init__(self, chunks: list):
        self.chunks, self.used, self.buf = chunks, 0, b""
        self.other, self.steps, self.result = False, set(), None
        self.unindexed, self.convs = False, set()

    @staticmethod
    def _index(v) -> Optional[int]:
        """A step_index that names one step: a whole number from 0 (digits as text count the same); else None."""
        if isinstance(v, bool):
            return None
        if isinstance(v, int):
            return v if v >= 0 else None
        if isinstance(v, str) and v.isascii() and v.isdigit():
            return int(v)
        return None

    def _conv(self, d) -> None:
        c = d.get("conversation_id") if isinstance(d, dict) else None
        if isinstance(c, str) and c:
            self.convs.add(c)

    def feed(self) -> None:
        n = len(self.chunks)            # the reader thread only appends
        if n > self.used:
            self.buf += b"".join(self.chunks[self.used:n])
            self.used = n
            *lines, self.buf = self.buf.split(b"\n")
            for ln in lines:
                self._line(ln)

    def finish(self) -> None:
        self.feed()
        if self.buf:
            self._line(self.buf)
            self.buf = b""

    def _line(self, ln: bytes) -> None:
        ln = ln.strip()
        if not ln.startswith(b"{"):
            return
        try:
            ev = json.loads(ln)
        except ValueError:
            return
        if not isinstance(ev, dict):
            return
        self._conv(ev)
        su = ev.get("step_update")
        self._conv(su)
        if isinstance(su, dict) and (su.get("step_type") == "tool" or su.get("tool_name")):
            if str(su.get("tool_name") or "") != "generate_image":
                self.other = True
            else:
                i = self._index(su.get("step_index"))
                if i is None:
                    self.unindexed = True            # no identifiable picture step: refused (fail closed)
                else:
                    self.steps.add(i)
            return
        if ev.get("event") == "result" and isinstance(ev.get("result"), dict):
            self.result = ev["result"]
            self._conv(self.result)


_CONV = re.compile(r"^[0-9a-fA-F-]{8,64}$")


def _brain_picture(conv: str, started: float) -> Tuple[Optional[Path], str]:
    """The one picture agy's picture tool saved for this run in ~/.gemini/antigravity-cli/brain/<conversation>:
    (path, "") or (None, the plain reason). No link anywhere on the way; nothing from before the run's start; exactly
    one picture."""
    if not _CONV.match(conv or ""):
        return None, GEMINI_NO_PICTURE
    home = Path.home()
    brain = home / ".gemini" / "antigravity-cli" / "brain"
    folder = brain / conv
    found = []
    try:
        for p in (home / ".gemini", home / ".gemini" / "antigravity-cli", brain, folder):
            if _linked(p):
                return None, GEMINI_ELSEWHERE
        if not folder.is_dir():
            return None, GEMINI_NO_PICTURE
        real_folder = os.path.normcase(os.path.realpath(str(folder)))
        if real_folder != os.path.normcase(os.path.join(os.path.realpath(str(brain)), conv)):
            return None, GEMINI_ELSEWHERE
        for f in folder.iterdir():
            if f.suffix.lower() not in _PICTURE_SUFFIXES:
                continue
            st = os.lstat(str(f))
            if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode) or _junction(f):
                return None, GEMINI_ELSEWHERE
            if st.st_mtime <= started:
                continue                 # from before this run's actual start, or not provably after it: never used
            if os.path.normcase(os.path.dirname(os.path.realpath(str(f)))) != real_folder:
                return None, GEMINI_ELSEWHERE
            found.append(f)
    except OSError:
        return None, GEMINI_NO_PICTURE
    if len(found) != 1:
        return None, GEMINI_NO_PICTURE
    return found[0], ""


def _drop_run_pictures(convs, started: Optional[float]) -> None:
    """A refused run's pictures are not left behind: in each conversation folder this run named, inside
    ~/.gemini/antigravity-cli/brain with no link on the way, the regular picture files written after this run started
    are removed. Nothing else is touched: no file from before the run, no link, nothing outside Gemini's own folder."""
    if started is None:
        return
    home = Path.home()
    brain = home / ".gemini" / "antigravity-cli" / "brain"
    for conv in sorted(c for c in (convs or ()) if isinstance(c, str)):
        if not _CONV.match(conv):
            continue
        folder = brain / conv
        try:
            if any(_linked(p) for p in (home / ".gemini", home / ".gemini" / "antigravity-cli", brain, folder)):
                continue
            if not folder.is_dir():
                continue
            real_folder = os.path.normcase(os.path.realpath(str(folder)))
            if real_folder != os.path.normcase(os.path.join(os.path.realpath(str(brain)), conv)):
                continue
            for f in list(folder.iterdir()):
                if f.suffix.lower() not in _PICTURE_SUFFIXES:
                    continue
                try:
                    st = os.lstat(str(f))
                    if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode) or _junction(f):
                        continue
                    if st.st_mtime <= started:
                        continue             # from before this run: never this run's, never removed
                    os.unlink(str(f))
                except OSError:
                    continue
        except OSError:
            continue


def _reap(g, proc, readers: list) -> None:
    """Ends agy if it still runs, waits for it (bounded), lets the readers finish and closes its pipes."""
    if proc is None:
        return
    if proc.poll() is None:
        g._kill(proc)
    try:
        proc.wait(10)
    except Exception:
        pass
    for t in readers:
        t.join(5)
    for s in (proc.stdin, proc.stdout, proc.stderr):
        try:
            if s is not None:
                s.close()
        except Exception:
            pass


_SOURCE_NAME = re.compile(r"^source-[1-9][0-9]?\.(png|jpg|webp|gif)$")


def _gemini_ask(prompt: str, aspect: str, names: list) -> str:
    """The request handed to agy. Pictures to change are named only by their names in the run folder."""
    shape = {"landscape": "wide (landscape, about 16:9)", "portrait": "tall (portrait, about 9:16)",
             "square": "square (1:1)"}.get(aspect, "wide (landscape)")
    ask = "Make one picture with the generate_image tool. Shape: %s.\n" % shape
    if names:
        ask += "Start from the picture %s, which is in your working folder" % names[0]
        if len(names) > 1:
            ask += ", and use %s as reference pictures" % ", ".join(names[1:])
        ask += (". Give the generate_image tool these pictures by these names only, and change them as the request "
                "below says.\n")
    return ask + "Picture request:\n%s\n" % prompt


def via_gemini(prompt: str, aspect: str, sources: Optional[list] = None) -> dict:
    """One agy run that may only make one picture. With sources (the private copies' paths, already checked), they are
    copied into the run's fresh folder as source-1.<ext>... and named only by those names; nothing else about the run
    changes. {"ok": True, "path", ...} or {"ok": False, "plain"[, "stop"]}."""
    sources = list(sources or [])
    names = [os.path.basename(s) for s in sources]
    if len(set(names)) != len(names) or not all(_SOURCE_NAME.match(n) for n in names):
        log.warning("Gemini edit inputs not named as expected; not sent")
        return {"ok": False, "plain": GEMINI_NO_WORKSPACE}
    g = _gate()
    path = _agy_path()
    if g is None or not path:
        return {"ok": False, "plain": GEMINI_NOT_SET_UP}
    if not gemini_ready():
        return {"ok": False, "plain": NONE_CONNECTED}
    if names_a_file(prompt):                        # before anything of Google's runs
        log.warning("Gemini picture request names a file or folder; not sent")
        return {"ok": False, "plain": GEMINI_NAMES_FILE}
    why = _halt()
    if why:
        return {"ok": False, "plain": why, "stop": True}
    qenv = g._quiet_env()
    if qenv is None:                                # never where it could open a browser (fail closed)
        return {"ok": False, "plain": GEMINI_UNSAFE}
    env = _clean_env(qenv)
    u = _models_ok(g, path, env)
    if not u.get("ok"):
        return u
    try:
        block = str(g._text_only_settings())        # strict permission; every other tool kind denied
    except OSError:
        return {"ok": False, "plain": GEMINI_PREP}
    why = _halt()
    if why:
        return {"ok": False, "plain": why, "stop": True}
    if not gemini_ready():                          # disconnected while the model list ran: no picture run
        return {"ok": False, "plain": NONE_CONNECTED}
    try:
        work = tempfile.mkdtemp(prefix="qosha-gemini-img-")
    except OSError as exc:
        log.warning("Gemini picture run folder not made: %s", type(exc).__name__)
        return {"ok": False, "plain": GEMINI_NO_WORKSPACE}
    proc = None
    readers: list = []
    watch = None
    started = None
    kept_ok = False
    convs: set = set()
    try:
        agent = "qosha-picture-" + secrets.token_hex(6)
        d = Path(work) / ".agents" / "agents"
        d.mkdir(parents=True, exist_ok=True)
        (d / (agent + ".md")).write_text(GEMINI_AGENT.format(name=agent), encoding="utf-8")
        for src, name in zip(sources, names):      # the private copies, into the run's own fresh folder
            try:
                _write_new(os.path.join(work, name), _read_picture(Path(src)))
            except (OSError, ValueError) as exc:
                log.warning("Gemini edit input not copied: %s", type(exc).__name__)
                return {"ok": False, "plain": GEMINI_NO_WORKSPACE}
        ask = _gemini_ask(prompt, aspect, names)
        if names_a_file(ask, names):                # the whole request names no file or folder but the copies (G4)
            log.warning("Gemini picture request names a file or folder; not sent")
            return {"ok": False, "plain": GEMINI_NAMES_FILE}
        argv = [path, "--output-format", "stream-json", "--print-timeout", "%ds" % (GEMINI_TIMEOUT - 20), "--sandbox",
                "--settings", block, "--agent", agent, "--disable-slash-commands"]
        started = time.time()
        proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=work,
                                shell=False, env=env, **g._spawn_kw())
        outs: list = []
        errs: list = []
        readers = [threading.Thread(target=g._drain, args=(proc.stdout, outs), daemon=True),
                   threading.Thread(target=g._drain, args=(proc.stderr, errs), daemon=True)]
        for t in readers:
            t.start()
        watch = _Watch(outs)
        why = _halt()                               # Stop or access while agy was starting: nothing handed over
        if why:
            return {"ok": False, "plain": why, "stop": True}
        if not gemini_ready():                      # still connected right before the request is handed over
            return {"ok": False, "plain": NONE_CONNECTED}
        threading.Thread(target=g._write_stdin, args=(proc, ask.encode("utf-8")), daemon=True).start()
        end = time.monotonic() + GEMINI_TIMEOUT
        n = 0
        while proc.poll() is None:
            if time.monotonic() > end:
                return {"ok": False, "plain": GEMINI_SLOW}
            why = _halt(access=(n % 5 == 0))         # Stop every 0.2 s, access every second: agy is ended at once
            n += 1
            if why:
                return {"ok": False, "plain": why, "stop": True}
            watch.feed()
            if watch.other or watch.unindexed or len(watch.steps) > 1:   # one known picture step, the picture tool
                break                                                    # only (fail closed)
            if g._signin_seen(outs, errs):
                break
            time.sleep(0.2)
        _reap(g, proc, readers)
        watch.finish()
        out = b"".join(outs).decode("utf-8", "replace")
        err = b"".join(errs).decode("utf-8", "replace")
        if watch.other:
            log.warning("Gemini picture run used another tool; nothing kept")
            return {"ok": False, "plain": GEMINI_OTHER}
        if len(watch.steps) > 1:
            log.warning("Gemini picture run made more than one picture; nothing kept")
            return {"ok": False, "plain": GEMINI_MANY}
        if watch.unindexed:
            log.warning("Gemini picture step without a step index; nothing kept")
            return {"ok": False, "plain": GEMINI_UNCLEAR}
        if g._signin_seen(outs, errs):               # checked again after the run ended
            return {"ok": False, "plain": GEMINI_NOT_SIGNED_IN}
        why = _halt()
        if why:
            return {"ok": False, "plain": why, "stop": True}
        res = watch.result if watch.result is not None else g._envelope(out)
        if isinstance(res, dict):
            convs.add(str(res.get("conversation_id") or ""))      # also an answer without a result event
        good =(proc.returncode == 0                 # a run that exited with an error is never a success
                and isinstance(res, dict) and str(res.get("status") or "").upper() == "SUCCESS" and not res.get("error")
                and not res.get("denied_actions") and not res.get("is_error"))
        if not good:
            low = (out + " " + err).lower()
            if "resource_exhausted" in low or "quota" in low or "rate limit" in low or "usage limit" in low:
                return {"ok": False, "plain": GEMINI_LIMIT}
            return {"ok": False, "plain": GEMINI_NO_PICTURE}
        if len(watch.steps) != 1:
            return {"ok": False, "plain": GEMINI_NO_PICTURE}
        conv = str(res.get("conversation_id") or "")
        pic, why = _brain_picture(conv, started)
        if pic is None:
            return {"ok": False, "plain": why}
        kept_ok = True
        return {"ok": True, "path": str(pic), "model": "Gemini", "by": "Gemini", "conv": conv, "started": started}
    except OSError as exc:
        log.warning("Gemini picture run could not start: %s", type(exc).__name__)
        return {"ok": False, "plain": GEMINI_START}
    finally:
        _reap(g, proc, readers)                     # agy has ended before anything of its run is removed
        if not kept_ok:                             # a refused run leaves no picture behind in Gemini's folder
            try:
                if watch is not None:
                    watch.finish()
                    convs |= watch.convs
                _drop_run_pictures(convs, started)
            except Exception as exc:
                log.warning("Gemini picture run not cleaned up: %s", type(exc).__name__)
        shutil.rmtree(work, ignore_errors=True)


# --- the engine backend --------------------------------------------------------------------------------------------
def _provider_class():
    from agent.image_gen_provider import DEFAULT_ASPECT_RATIO, ImageGenProvider, error_response, \
        resolve_aspect_ratio, success_response

    class QoshaImageGenProvider(ImageGenProvider):
        """Qosha's picture maker: the person's ChatGPT, then Gemini, subscriptions; never a pay-per-use key."""

        @property
        def name(self) -> str:
            return NAME

        @property
        def display_name(self) -> str:
            return "Qosha (your connected AI accounts)"

        def is_available(self) -> bool:
            return True      # always offered: with no account that can, the tool answers so in plain words

        def get_setup_schema(self) -> dict:
            return {"name": self.display_name, "badge": "subscription", "env_vars": [],
                    "tag": "Pictures with your connected ChatGPT or Gemini sign-in; no API key."}

        def list_models(self) -> list:
            return [{"id": "auto", "display": "Best connected account"}]

        def capabilities(self) -> dict:
            # slice 2: edits too; image_url plus at most 3 references (MAX_SOURCES pictures in all)
            return {"modalities": ["text", "image"], "max_reference_images": MAX_SOURCES - 1}

        def generate(self, prompt: str, aspect_ratio: str = DEFAULT_ASPECT_RATIO, *, image_url=None,
                     reference_image_urls=None, **_kw) -> dict:
            given = _take_exact_sources()             # the pictures exactly as the tool call named them
            if given is not None:
                image_url, reference_image_urls = given
            try:
                return self._generate(prompt, aspect_ratio, image_url, reference_image_urls)
            except Exception as exc:                  # never a raw error, a path or an engine name (fixed text)
                log.warning("picture request failed: %s", type(exc).__name__)
                return error_response(error=NOT_MADE, error_type="not_made", provider=NAME, model="auto",
                                      prompt=str(prompt or "")[:MAX_PROMPT],
                                      aspect_ratio=resolve_aspect_ratio(aspect_ratio))

        def _generate(self, prompt, aspect_ratio, image_url, reference_image_urls) -> dict:
            prompt = (prompt or "").strip()
            aspect = resolve_aspect_ratio(aspect_ratio)

            def fail(text, kind="provider_error"):
                return error_response(error=text, error_type=kind, provider=NAME, model="auto",
                                      prompt=prompt[:MAX_PROMPT], aspect_ratio=aspect)

            if not prompt:
                return fail("Say what the picture should show.", "prompt_required")
            if len(prompt) > MAX_PROMPT:
                return fail(TOO_LONG, "prompt_too_long")
            try:
                srcs = _source_list(image_url, reference_image_urls)     # at most MAX_SOURCES, before anything else
            except _Refused as r:
                return fail(r.plain, "source_refused")
            why = _halt()
            if why:
                return fail(why, "access_ended" if why == ACCESS_ENDED else "stopped")
            dest = destination()                      # checked before any account is asked
            if dest is None:
                return fail(NO_FOLDER, "files_unavailable")
            if not srcs:
                return self._make(prompt, aspect, dest, [], fail)
            try:                                      # every picture to change checked before any account is asked
                areas = _source_areas()
                pics = [_check_source(s, areas) for s in srcs]
            except _Refused as r:
                log.info("picture to change refused before any account was asked")
                return fail(r.plain, "source_refused")
            try:
                private, copies = _private_copies(pics)
            except OSError as exc:
                log.warning("pictures to change not copied: %s", type(exc).__name__)
                return fail(SOURCE_PREP, "source_unavailable")
            try:
                return self._make(prompt, aspect, dest, copies, fail)
            finally:
                shutil.rmtree(private, ignore_errors=True)

        def _make(self, prompt, aspect, dest, copies, fail) -> dict:
            """Asks the connected accounts in turn (ChatGPT, else Gemini); copies = the private copies to change."""
            reasons = []
            routes = []
            if chatgpt_ready():
                routes.append("chatgpt")
            else:
                reasons.append(CHATGPT_NOT_CONNECTED)
            if gemini_ready():
                routes.append("gemini")
            if not routes:
                return fail(NONE_CONNECTED, "no_connected_account")
            for r in routes:
                why = _halt()
                if why:
                    return fail(why, "access_ended" if why == ACCESS_ENDED else "stopped")
                got = (via_chatgpt(prompt, aspect, copies) if r == "chatgpt"
                       else via_gemini(prompt, aspect, copies))
                if got.get("stop"):
                    return fail(got.get("plain") or STOPPED, "stopped")
                if got.get("made"):                   # a picture was made but not saved: no second account
                    return fail(SAVE_FAILED, "save_failed")
                if not got.get("ok"):
                    reasons.append(got.get("plain") or "")
                    continue
                def drop():                           # a Gemini picture not kept is not left in Gemini's folder;
                    if r == "gemini":                 # ChatGPT's private copy is never left behind (X-1)
                        try:
                            _drop_run_pictures({got.get("conv")}, got.get("started"))
                        except Exception as exc:
                            log.warning("Gemini picture not cleaned up: %s", type(exc).__name__)
                    else:
                        _drop_private_result(got.get("private"))

                kept = None
                try:
                    why = _halt()                     # before saving
                    if why:
                        return fail(why, "access_ended" if why == ACCESS_ENDED else "stopped")
                    try:
                        kept = keep(got["path"], dest)
                    except (OSError, ValueError) as exc:
                        log.warning("picture not saved: %s", type(exc).__name__)
                        return fail(SAVE_FAILED, "save_failed")   # the picture was made: no second account
                finally:
                    if r == "chatgpt" or kept is None:
                        drop()                        # ChatGPT's private copy goes after keep() and on every failure
                where = str(kept)
                return success_response(
                    image=where, model=got.get("model") or "auto", prompt=prompt, aspect_ratio=aspect,
                    provider=NAME, modality="image" if copies else "text",
                    extra={"made_with": got["by"] + " (your subscription; it counts against that plan's limits)",
                           "saved_in_files": where,
                           "show_it": "Put this line on its own line in your answer: " + media_line(where)})
            return fail(" ".join(x for x in reasons if x) or NONE_CONNECTED, "not_made")

    return QoshaImageGenProvider


# --- Qosha's default (F-PAID) --------------------------------------------------------------------------------------
def _image_gen_config() -> Optional[dict]:
    """config.yaml's image_gen section (a dict), or None when there is none or config.yaml can't be read."""
    try:
        from hermes_cli.config import load_config_readonly
        cfg = load_config_readonly()
    except Exception:
        return None
    sec = cfg.get("image_gen") if isinstance(cfg, dict) else None
    return sec if isinstance(sec, dict) else None


def _is_qosha(sec: Optional[dict]) -> bool:
    """This image_gen section's provider is "qosha" (set by hand)."""
    v = sec.get("provider") if sec is not None else None
    return isinstance(v, str) and v.strip().lower() == NAME


def _truthy(value) -> bool:
    """The engine's own reading of a yes/no setting (utils.env.is_truthy_value); the same rule when it can't be
    loaded."""
    try:
        from utils.env import is_truthy_value
        return bool(is_truthy_value(value))
    except Exception:
        if value is None:
            return False
        if isinstance(value, str):
            return value.strip().lower() in ("1", "true", "yes", "on")
        return bool(value)


def _chose(sec: Optional[dict]) -> bool:
    """This image_gen section is the person's own choice: use_gateway switched on (read as the engine reads it), or a
    provider or model given as text that isn't empty. A hand-typed "no" or an empty setting (use_gateway: false,
    provider: '', model: '') is not a choice: Qosha's default stays (Gemini X-2)."""
    if sec is None:
        return False
    if _truthy(sec.get("use_gateway")):
        return True
    for k in ("provider", "model"):
        v = sec.get(k)
        if isinstance(v, str) and v.strip():
            return True
    return False


def _selected_qosha() -> bool:
    """config.yaml's image_gen.provider is "qosha" (set by hand)."""
    return _is_qosha(_image_gen_config())


def _person_chose() -> bool:
    """config.yaml's image_gen names a provider, a model or use_gateway: the person's own choice."""
    return _chose(_image_gen_config())


def default_in_effect() -> bool:
    """Qosha's backend is the default now: no picture choice of the person's, and the backend is registered."""
    if _person_chose():
        return False
    try:
        from agent.image_gen_registry import get_provider
        return get_provider(NAME) is not None
    except Exception:
        return False


def _paid_refused() -> bool:
    """Once Qosha's guards are in place, the engine's pay-per-use picture paths run only on a picture choice the person
    made in config.yaml that is not Qosha's own backend. Qosha's backend going missing (or config.yaml unreadable)
    never opens them (fails closed); nor does "qosha" set by hand as the picture maker. Decided from ONE read of
    config.yaml, so a second read that fails can never open them; an unreadable config.yaml refuses."""
    sec = _image_gen_config()
    return sec is None or not _chose(sec) or _is_qosha(sec)


_exact = threading.local()          # this thread's tool call: the pictures to change exactly as it named them


def _sources_given(a: tuple, kw: dict) -> tuple:
    """(image_url, reference_image_urls) as given to the backend dispatch (prompt, aspect_ratio, image_url,
    reference_image_urls, ...)."""
    url = kw["image_url"] if "image_url" in kw else (a[2] if len(a) > 2 else None)
    refs = kw["reference_image_urls"] if "reference_image_urls" in kw else (a[3] if len(a) > 3 else None)
    return url, refs


def _take_exact_sources() -> Optional[tuple]:
    """The pictures this thread's tool call named, exactly as written (once), or None outside such a call."""
    given = getattr(_exact, "value", None)
    _exact.value = None
    return given


def _ours(igt) -> bool:
    try:
        p = igt._plugin_provider_name()
        return isinstance(p, str) and p.strip().lower() == NAME
    except Exception:
        return False


def _local_backend() -> bool:
    try:
        from tools.image_source import _is_local_terminal_backend
        return bool(_is_local_terminal_backend())
    except Exception:
        return False


def _keep_exact_sources(igt) -> None:
    """When Qosha's backend makes the picture on this computer, the pictures to change reach it exactly as the tool
    call named them: the engine's local step that may swap a missing name for a similar one on disk is skipped (Qosha
    checks the name itself and refuses what isn't there). Anything else runs as before."""
    cur = getattr(igt, "_confine_source_images", None)
    if cur is None or getattr(cur, "qosha", False):
        return

    def _confine_source_images(image_url, reference_image_urls, *a, **kw):
        if _ours(igt) and _local_backend():
            return image_url, reference_image_urls, None
        return cur(image_url, reference_image_urls, *a, **kw)

    _confine_source_images.qosha = True
    _confine_source_images.original = cur
    igt._confine_source_images = _confine_source_images


def _plain_dispatch(igt) -> None:
    """When Qosha's backend is the selected picture maker (Qosha's default or "qosha" set by hand), only its own answer
    goes back: if it can't be found (the lookup fails or finds nothing) or it raised, the request ends with a fixed
    plain message, never the engine's text (which names commands and settings) and never a fall-through to the
    pay-per-use paths. Any other selection is dispatched by the engine as before."""
    cur = getattr(igt, "_dispatch_to_plugin_provider")
    if getattr(cur, "qosha", False):
        return

    def _dispatch_to_plugin_provider(*a, **kw):
        try:
            p = igt._plugin_provider_name()
            ours = isinstance(p, str) and p.strip().lower() == NAME     # "Qosha", " qosha " count as Qosha's
        except Exception:
            ours = _paid_refused()
        if not ours:
            return cur(*a, **kw)
        try:
            _exact.value = _sources_given(a, kw)        # handed to Qosha's backend untouched (never trimmed)
            raw = cur(*a, **kw)
            got = json.loads(raw) if isinstance(raw, str) else None
        except Exception:
            got = None
        finally:
            _exact.value = None
        if isinstance(got, dict) and got.get("provider") == NAME:
            return raw
        log.warning("Qosha's picture backend not reached; plain refusal")
        return json.dumps({"success": False, "image": None, "error": NOT_AVAILABLE, "error_type": "not_available"})

    _dispatch_to_plugin_provider.qosha = True
    _dispatch_to_plugin_provider.original = cur
    igt._dispatch_to_plugin_provider = _dispatch_to_plugin_provider


def _refuse_paid(igt) -> None:
    """Without a picture choice of the person's, the engine's pay-per-use picture paths (FAL and the managed gateways)
    refuse with a plain message instead of running (e.g. when Qosha's backend can't be found at call time, or its
    registry entry is gone)."""
    for attr in ("image_generate_tool", "_maybe_route_managed_model"):
        cur = getattr(igt, attr)
        if getattr(cur, "qosha", False):
            continue

        def make(original):
            def guarded(*a, **kw):
                if _paid_refused():
                    log.warning("pay-per-use picture path refused while Qosha's default is in effect")
                    return json.dumps({"success": False, "image": None, "error": PAID_REFUSED,
                                       "error_type": "not_available"})
                return original(*a, **kw)
            guarded.qosha = True
            guarded.original = original
            return guarded

        setattr(igt, attr, make(cur))
    _no_paid_probe(igt)
    _plain_dispatch(igt)
    _keep_exact_sources(igt)


def _no_paid_probe(igt) -> None:
    """Without a picture choice of the person's, the engine's availability check (check_image_generation_requirements)
    never probes FAL or the managed gateway (a pay-per-use route Qosha refuses; its lazy install can outlast the check's
    window and drop the picture tool): the FAL probe it calls first answers "not available" without running (neither
    the gateway lookup nor the key check runs), so the check answers from Qosha's backend. The registry keeps the check
    function itself, so the probe it looks up at call time is the one guarded. A choice of the person's runs the
    engine's own probe as before."""
    cur = getattr(igt, "check_fal_api_key")
    if getattr(cur, "qosha", False):
        return

    def check_fal_api_key(*a, **kw):
        if _paid_refused():
            return False
        return cur(*a, **kw)

    check_fal_api_key.qosha = True
    check_fal_api_key.original = cur
    igt.check_fal_api_key = check_fal_api_key


def _own_defer_list() -> bool:
    """The person wrote their own tools.tool_search.defer list in config.yaml (it is then left alone)."""
    try:
        from hermes_cli.config import read_raw_config_readonly
        raw = read_raw_config_readonly() or {}
    except Exception:
        return True
    t = raw.get("tools") if isinstance(raw, dict) else None
    ts = t.get("tool_search") if isinstance(t, dict) else None
    return isinstance(ts, dict) and isinstance(ts.get("defer"), (list, tuple, set))


def _offer_directly() -> None:
    """While Qosha's default is in effect, image_generate is not deferred behind the on-demand tool search: it is
    removed from the curated default deferral (_DEFAULT_DEFERRED_TOOLS, which the loaded settings carry as the default
    list). A person's own tools.tool_search.defer list is left alone."""
    import tools.tool_search as ts
    for attr in ("load_config", "load_config_readonly"):
        cur = getattr(ts, attr)
        if getattr(cur, "qosha", False):
            continue

        def make(original):
            def load(*a, **kw):
                cfg = original(*a, **kw)
                try:
                    names = cfg.effective_defer_tools
                    if _NOT_DEFERRED in names and default_in_effect() and not _own_defer_list():
                        default = frozenset(n for n in ts._DEFAULT_DEFERRED_TOOLS if n != _NOT_DEFERRED)
                        kept = default if cfg.defer_tools is None else frozenset(n for n in names if n != _NOT_DEFERRED)
                        return dataclasses.replace(cfg, defer_tools=kept)
                except Exception:
                    pass
                return cfg
            load.qosha = True
            load.original = original
            return load

        setattr(ts, attr, make(cur))


def make_default() -> bool:
    """With no picture choice in config.yaml (image_gen provider, use_gateway and model unset) and Qosha's backend
    registered, Qosha's backend is the one used, offered directly, and the pay-per-use paths refuse. A choice of the
    person's stays theirs, read as the engine reads it. Idempotent; fail-open (the engine as before)."""
    try:
        import tools.image_generation_tool as igt
        _refuse_paid(igt)                 # first: the default is never set without the paid paths guarded
        cur = igt._read_configured_image_provider
        if not getattr(cur, "qosha", False):
            original = cur

            def _read_configured_image_provider():
                chosen = original()
                if chosen:
                    return chosen
                return NAME if default_in_effect() else chosen

            _read_configured_image_provider.qosha = True
            _read_configured_image_provider.original = original
            igt._read_configured_image_provider = _read_configured_image_provider
    except Exception as exc:
        log.warning("Qosha pictures: default not set (%s)", type(exc).__name__)
        return False
    try:
        _offer_directly()
    except Exception as exc:
        log.warning("Qosha pictures: tool stays on demand (%s)", type(exc).__name__)
    return True


def register(ctx) -> bool:
    """Registers Qosha's picture backend and makes it the default. Fail-open (the engine's tool stays as it was)."""
    if not ENABLED:
        return False
    try:
        ctx.register_image_gen_provider(_provider_class()())
    except Exception as exc:
        log.warning("Qosha pictures not registered: %s", type(exc).__name__)
        return False
    return make_default()
