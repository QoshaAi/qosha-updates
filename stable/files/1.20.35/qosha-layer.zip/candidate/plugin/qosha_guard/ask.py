"""Qosha's ask-first rule on the person's own computer (Ren, 16-17 Nov 2026).

No built-in walls: the assistant may read and change anything, including its own code, settings and skills, and run
commands, like the engine does. Only an action that SENDS, PAYS, DELETES, SHARES/PUBLISHES or changes a calendar is
put to the person first, through the engine's own approval prompt (Allow once / Always allow / Deny). The rule_key is
the KIND of action, so one "Always allow" covers that whole kind from then on (the engine keeps it in its allowlist;
the person can ask Qosha to undo it, and Qosha can edit that setting itself).
Everything else returns None: the engine's own behavior (including its own dangerous-command prompts) applies.
"""
from __future__ import annotations

import json
import os
import re
import secrets
import time
from typing import Any, Dict, Optional, Tuple

try:
    from .i18n import tr, say_value
except ImportError:   # loaded as a single file
    def _i18n_file():
        import importlib.util
        import os
        import sys
        m = sys.modules.get("qosha_guard_i18n_file")
        if m is None:
            spec = importlib.util.spec_from_file_location("qosha_guard_i18n_file", os.path.join(os.path.dirname(os.path.abspath(__file__)), "i18n.py"))
            m = importlib.util.module_from_spec(spec)
            sys.modules["qosha_guard_i18n_file"] = m
            spec.loader.exec_module(m)
        return m

    def tr(key, **kw):
        return _i18n_file().tr(key, **kw)

    def say_value(value, exact=False):
        # the card's English sentences in the person's language (i18n.say_value); as they are if that can't load
        try:
            return _i18n_file().say_value(value, exact)
        except Exception:
            return "" if value is None else str(value)

# KIND_TEXT is the English kind name (rule keys, logs); what the person reads comes from kind_text() in their language
KIND_TEXT = {
    "email.send": "send an email",
    "message.send": "send a message",
    "message.edit": "edit a message you already sent",
    "calendar.change": "change your calendar",
    "calendar.invite": "send a calendar invitation or reply",
    "whatsapp.read": "read your WhatsApp messages",
    "whatsapp.send": "send a WhatsApp message",
    "screen.read": "look at your whole screen",
    "delete": "delete something",
    "pay": "pay, buy or move money",
    "share": "share or publish something",
    "dropbox.change": "copy, move, rename or make files and folders in your own Dropbox",
    "web.post": "send data to a website",
    "web.act": "do a final step on a website (send, buy, delete, confirm, sign in, upload)",
    "google.change": "change something in your Google account (Drive, Gmail, Calendar, Docs, Sheets)",
    "file.organize": "organize your own files (make folders, move, rename, copy)",
    "file.edit": "make or add to your own Docs and Sheets",
    "mail.tidy": "tidy your own email (archive, mark read or unread)",
    "ai.paid": "turn on pay-per-use AI (your Anthropic API key or a paid backup AI)",
    "browser.profile": "let Qosha's browser use your own Chrome profile, where you are signed in",
    "unclear": "do a step Qosha could not read",
}


def kind_text(kind: str) -> str:
    """The kind of action as the person reads it, in their language (glossary rows 22-29)."""
    if kind not in KIND_TEXT:
        return kind
    key = "ask.kind.%s" % kind
    t = tr(key)
    return KIND_TEXT[kind] if t == key else t


def row_label(label: str) -> str:
    """A card row's label in the person's language ("To" -> "Para"); the label itself when it has no translation."""
    key = "ask.row.%s" % label
    t = tr(key)
    if t != key:
        return t
    m = re.fullmatch(r"Body \(([A-Za-z_]{1,40})\)", label)   # a second text field, named by the tool's own field name
    return "%s (%s)" % (row_label("Body"), m.group(1)) if m else label


# the rows whose values are Qosha's own sentences (said in the person's language); every other row holds the person's
# data (To, Subject, Body, an event's title, a website), shown exactly as it is
_SAY_ROWS = ("What happens", "Steps", "Also", "Gmail adds")


class _Own(str):
    """Qosha's own words standing in a row that otherwise holds the person's data ("(no message text)" in Body). It
    reads, compares and saves like the English text it is; `key` names its catalog text, so only THIS value is said in
    the person's language, never a body that happens to hold the same words."""
    key = ""

    def __new__(cls, text: str, key: str = "", kw: Optional[Dict[str, Any]] = None):
        o = str.__new__(cls, text)
        o.key = key
        o.kw = dict(kw or {})      # the values the catalog text names ({id} ...), the same ones the English holds
        return o


def _line_breaks(value: Any) -> Any:
    """A value with every line break as "\\n" (a lone carriage return is one too); a value without one is handed back
    as it is, so Qosha's own stand-in words (_Own) stay recognisable."""
    if isinstance(value, _Own) or (isinstance(value, str) and "\r" not in value):
        return value
    return re.sub(r"\r\n?", "\n", "" if value is None else str(value))


def row_value(label: str, value: Any) -> str:
    """A card row's value as the person reads it: Qosha's sentences in their language, their data unchanged. In English
    it is the value itself, byte for byte."""
    s = "" if value is None else str(value)
    if isinstance(value, _Own) and value.key:
        t = tr(value.key, **getattr(value, "kw", {}))
        return s if t == value.key else t
    if label in _SAY_ROWS:
        return say_value(s)
    if label == "Note from Qosha":       # Qosha's own notes are said in the person's language; a model's note is not
        return say_value(s, True)
    return s


# The card's meaning travels as a language-free reason code on its own line, never the last one (the last line stays
# the footer sentence, which 1.19.12's own checks read). The card (chat.html QoshaCard.plan) strips this line.
REASON_MARK = "[[qosha:reason %s]]"


def reason_line(code: str, arg: str = "") -> str:
    return REASON_MARK % ((code + " " + arg) if arg else code)

# commands, by what they do (checked on the whole command text, case-insensitive)
# A rule must match what the command DOES, never a word that only appears in a file name or in data (Ren, 17 Nov:
# attaching a file and Qosha reading it must never ask). So: programs are matched where a program stands (start of the
# command or after ; & | or sudo/xargs), and payment and mail by their real services and calls, not by plain words.
_AT = r"(?:^|[;&|\n]\s*|\$\(\s*|`\s*)(?:sudo\s+|xargs\s+(?:-\S+\s+)*|env\s+(?:\w+=\S+\s+)*)?"
_GITV = r"(?:'[^']*'|\"[^\"]*\"|\S+)"
_GITW = (r"git(?:\s+(?:-C\s*" + _GITV + r"|-c\s*" + _GITV + r"|"
         r"--(?:git-dir|work-tree|namespace|exec-path|super-prefix|config-env|attr-source)(?:=|\s+)" + _GITV + r"|"
         r"--(?:no-pager|paginate|bare|no-replace-objects|literal-pathspecs|glob-pathspecs|noglob-pathspecs|"
         r"icase-pathspecs|no-optional-locks|no-lazy-fetch|no-advice|exec-path)|-[pP]))*\s+")   # r1210 (r2: attached, quoted)   # git's global options (r1210)
_CMD_RULES = [
    # Outlook: its server program or Microsoft Graph's send calls from a command (refused as a command send, _unseen)
    ("email.send", r"ms-365-mcp-server|@softeria|graph\.microsoft\.com"),
    ("email.send", r"(google_api\.py|\$GAPI|\bgws)\b.*\bgmail\s+(send|reply|forward|drafts?[-_ ]?send|\+send|\+reply|\+forward)(?![\w-])"),
    # Gmail's own API forms, by the wrapper's gws call or straight to Google (GPT vqa/r11913e rshw3 HIGH 5): refused below
    ("email.send", r"\bgmail\s+users\s+(messages|drafts)\s+send\b|\busers\.(messages|drafts)\.send\b|gmail\.googleapis\.com\S*/(messages|drafts)/send"),
    ("message.send", r"slack\.com/api/chat\.(postMessage|postEphemeral|scheduleMessage)|\bchat\.postMessage\b"),
    ("email.send", _AT + r"himalaya\b[^;&|\n]*\b(send|reply|forward)\b"),
    ("email.send", _AT + r"(sendmail|msmtp|mutt|mailx?)\s"),
    ("calendar.change", r"(google_api\.py|\$GAPI|\bgws)\b.*\bcalendar\s+(create|update|delete|add|\+insert|events\s+(insert|patch|update|delete))\b"),
    # deleting something online is a DELETE, not a share (17 Nov: `gh repo delete` was filed as share)
    ("delete", r"(google_api\.py|\$GAPI)\b[^;&|\n]*\bdrive\s+delete\b|"
               + _AT + r"(gh|glab)\s+[a-z-]+\s+delete\b|" + _AT + r"gh\s+api\b[^;&|\n]*(-X\s*|--method[\s=]+)DELETE\b|"
               + _AT + _GITW + r"push\b[^;&|\n]*(\s--delete\b|\s-d\b|\s\+?:[^\s;&|]+)"),
    ("share", r"google_api\.py\b.*\bdrive\s+(share|upload)\b"),
    ("share", _AT + r"(" + _GITW + r"push\b|gh\s+(pr|issue|release|repo|gist)\s+(create|merge|comment|edit)\b|npm\s+publish\b|twine\s+upload\b)"),
    ("pay", r"api\.stripe\.com|" + _AT + r"stripe\s+(charges|payment_intents|payouts|refunds|transfers)\b|api(-m)?\.(sandbox\.)?paypal\.com"),
    ("delete", _AT + r"(rm|rmdir|shred|unlink|trash|del|erase|rd|Remove-Item)(\s|$)|\bfind\b[^;&|\n]*\s-delete\b|"
               + _AT + _GITW + r"(clean\b|reset\b[^;&|\n]*\s--hard\b)|\bdrop\s+(table|database)\s|\bdelete\s+from\s"),
    ("web.post", _AT + r"curl\b[^;&|\n]*(\s-X\s*(POST|PUT|PATCH|DELETE)\b|\s(-d|--data\S*|-F|--form)\s)|Invoke-(WebRequest|RestMethod)[^;&|\n]*-Method\s+(Post|Put|Patch|Delete)"),
]
# code the assistant runs (execute_code): by the calls that act, not by words
_CODE_RULES = [
    ("email.send", r"ms-365-mcp-server|@softeria|graph\.microsoft\.com"),
    ("email.send", r"smtplib\.SMTP|\.sendmail\(|\.send_message\(|\.(messages|drafts)\(\)\.send\(|gmail\.googleapis\.com\S*/(messages|drafts)/send|\bgmail\s+(users\s+messages\s+)?send\b"),
    ("message.send", r"slack\.com/api/chat\.(postMessage|postEphemeral|scheduleMessage)|\bchat[._]post_?[Mm]essage\("),
    ("delete", r"\bos\.(remove|unlink|rmdir|removedirs)\(|\bshutil\.rmtree\(|\.unlink\(\s*(missing_ok\s*=\s*\w+)?\s*\)|\.rmdir\(\)|\bfs\.(rm|unlink|rmdir)(Sync)?\("),
    ("pay", r"api\.stripe\.com|\bstripe\.(Charge|PaymentIntent|Payout|Refund|Transfer)\b|api(-m)?\.(sandbox\.)?paypal\.com"),
    ("web.post", r"\brequests\.(post|put|patch|delete)\(|\bhttpx\.(post|put|patch|delete)\(|method\s*[:=]\s*[\"'](POST|PUT|PATCH|DELETE)[\"']"),
    ("share", r"subprocess[^\n]*git[\"',\s]+push"),
]

# tool names (MCP and connector tools are named <server>_<action> or similar)
_TOOL_RULES = [
    ("email.send", r"(gmail|mail|email|outlook).*(send|reply|forward)|(send|reply|forward).*(mail|email)"),
    ("calendar.change", r"(calendar|event).*(create|update|delete|insert|patch|move)|(create|update|delete).*(event|calendar)"),
    ("pay", r"pay|checkout|purchase|charge|refund|transfer|invoice_send|buy"),
    ("delete", r"delete|remove|trash|destroy|purge|erase"),
    # a chat or message send, before the generic share rule (GPT vqa/r11913e rshw3 HIGH 5: Slack chat_postMessage was
    # filed as a share, and its card showed neither the channel nor the text)
    ("message.send", r"chat[_.]?post|post_?message|add_message|send_?message|message_create|(^|_)send_(dm|sms|text|chat)\b"),
    ("share", r"share|publish|(^|_)post|tweet|upload|invite|permission"),
    ("message.send", r"(^|_)send|message_create|chat_post|reply"),
]
# engine tools that never send/pay/delete on their own (reads, notes, its own UI)
_QUIET = {"read_file", "search_files", "web_search", "web_extract", "vision_analyze", "video_analyze", "skill_view",
          "skills_list", "todo", "todo_list", "memory", "session_search", "clarify", "browser_navigate",
          "browser_snapshot", "browser_scroll", "browser_back", "browser_close", "browser_vision", "set_theme",
          "delegate_task", "write_file", "image_generate", "text_to_speech", "tool_search"}


def _text(v: Any, n: int = 500) -> str:
    s = v if isinstance(v, str) else json.dumps(v, ensure_ascii=False, default=str)
    return s if len(s) <= n else s[:n] + " ..."


# The Google MCP (workspace-mcp 2.5.0, --tool-tier complete): the tools that only read, pinned by name and checked by
# what each one does, not by its name (1.20.8; candidates/gexec/S0-FINDINGS.md 4). get_gmail_attachment_content and
# get_drive_file_download_url write files; get_gmail_message_content writes them with full. Every other tool of the
# server, a new one in a later version included, gets a card.
_GOOGLE_MCP_READS = frozenset((
    "search_gmail_messages", "get_gmail_message_content", "get_gmail_messages_content_batch", "get_gmail_thread_content",
    "get_gmail_threads_content_batch", "list_gmail_labels", "list_gmail_filters", "list_calendars", "get_events",
    "query_freebusy", "search_drive_files", "get_drive_file_content", "list_drive_items", "get_drive_file_permissions",
    "check_drive_file_public_access", "get_drive_shareable_link", "get_doc_content", "search_docs",
    "list_docs_in_folder", "inspect_doc_structure", "debug_table_structure", "get_doc_as_markdown",
    "list_document_comments", "read_sheet_values", "get_spreadsheet_info", "list_spreadsheets", "list_sheet_tables",
    "list_spreadsheet_comments", "list_contacts", "get_contact", "search_contacts", "list_contact_groups",
    "get_contact_group", "list_task_lists", "get_task_list", "list_tasks", "get_task"))


def _google_mcp_read(base: str, a: Dict[str, Any]) -> bool:
    if base not in _GOOGLE_MCP_READS:
        return False
    if base == "get_gmail_message_content":
        # any spelling of the key (the server folds camelCase and case: core/camel_case_middleware.py), and the value
        # as the server reads a yes/no: only a clear "no" is a read; anything else asks (1.20.8 round 3)
        fulls = [v for k, v in a.items() if re.sub(r"[^a-z]", "", str(k).lower()) == "full"]
        return all(v in (None, False, 0) or (isinstance(v, str) and v.strip().lower() in ("", "false", "f", "0", "no", "n", "off", "none"))
                   for v in fulls)
    return True


_PROFILE_TOOLS = ("write_file", "patch", "terminal", "execute_code", "process", "process_manage", "browser_exec")


def _turns_on_real_profile(tool_name: str, args: Any) -> bool:
    """A step that edits settings or runs a command and turns browser.use_real_profile on (the person's own signed-in
    Chrome profile). A line a patch removes, or a value set to off, doesn't count (1.20.8 round 2)."""
    tool, a = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
    if tool not in _PROFILE_TOOLS:
        return False
    text = "\n".join(str(a.get(k) or "") for k in ("content", "patch", "command", "code", "input", "data"))
    if tool == "patch":
        text = "\n".join(ln for ln in text.splitlines() if not ln.startswith("-"))
    # turned on: the key followed by a yes value (yaml "key: true", "key=1", "config set browser.use_real_profile true");
    # a title or a search that only names it is not a settings change (1.20.8 round 3)
    return bool(re.search(r"use_real_profile[\"']?\s*[:=]?\s*[\"']?(true|yes|on|1)\b", text, re.I))


def _google_mcp(tool_name: str, args: Any) -> bool:
    t = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})[0].lower()
    return t.startswith("mcp__google__") or t == "qosha_google_change"   # Qosha's own Google write tool too (1.20.9)


# ---- Outlook (Softeria ms-365-mcp-server, server key "microsoft") and Dropbox (mcp.dropbox.com): STRICT v1 ----------
# (Ren, 21 Nov 2026: "strict v1"). Every tool of these two connections is named here. A tool that gets a card accepts
# only a fixed set of fields, each of a fixed type, in a fixed place; anything else is refused, so the card always shows
# everything the step does. Outlook email goes only through Qosha's outlook_send (outlook_send.py), which writes the
# plain-text email itself from exactly what the card showed and sends it.
# READ-ONLY until Qosha's own Microsoft executor lands (Ren, 22 Nov 2026 ~16:10 MST): only these read tools run;
# every other Outlook or OneDrive tool, writes and sending included, is refused (no card).
_MS_NONE = frozenset("""list_mail_messages list_mail_folders list_mail_child_folders list_mail_folder_messages
get_mail_message read_mail_text list_mail_attachments get_mail_attachment_content download_bytes
get_download_url list_calendar_events get_calendar_event get_calendar_view list_calendars list_calendar_event_instances
list_drives get_drive_root_item list_folder_files get_drive_item search_onedrive_files list_drive_item_versions
list_drive_item_permissions get_my_profile verify_login list_accounts""".split())
MS_READ_ONLY = ("Qosha can read Outlook and OneDrive here; sending and changes come in a coming update. "
                "Nothing was done.")
_MS_ACCOUNT = frozenset("login logout select_account".split())
_MS_REFUSED = frozenset("""send_mail send_draft_message reply_mail_message reply_all_mail_message forward_mail_message
execute_tool graph_batch search_tools get_tool_schema forward_calendar_event create_mail_rule update_mail_rule
update_mailbox_settings delete_mail_message_skip_deleted_items remove_account upload_file_content create_upload_session
get_upload_url upload_attachment_from_file add_mail_attachment create_draft_email create_reply_draft
create_reply_all_draft create_forward_draft download_bytes_to_file""".split())
_MS_SENDS = frozenset("""send_mail send_draft_message reply_mail_message reply_all_mail_message forward_mail_message
execute_tool graph_batch create_draft_email create_reply_draft create_reply_all_draft create_forward_draft""".split())
# Dropbox's live tool names (snake_case since ~Nov 2026; list and schemas: connectors/journeys/
# dropbox-tools-live-2026-11-22.json). Reads run (Dropbox's own read_only_hint); delete and create_shared_link get a
# card; copy / move / create_folder / create_file go only through Qosha's dropbox_organize (own, unshared
# folders only, slice 3B); every other name, new ones included, is refused.
_DBX_NONE = frozenset("""check_job_status download_link get_file_content get_file_content_metadata get_file_metadata
get_file_request get_shared_link_metadata get_usage_and_quota list_file_requests list_file_revisions list_folder
list_restore_events list_shared_links paper_get_doc_history paper_list_recent_docs paper_read_document
run_file_content_extraction search sign_list_signature_requests who_am_i""".split())
_DBX_CARD = frozenset("delete create_shared_link".split())
_DBX_ORGANIZE = frozenset("copy move create_folder create_file".split())   # round 3: create_file too
def _sibling(name: str):
    """A module beside this file: as part of the package, or (when the startup barrier loads this file on its own)
    from its path, so the guard never falls back for want of an import."""
    import importlib
    import importlib.util
    import sys as _sys
    if __package__:
        try:
            return importlib.import_module("%s.%s" % (__package__, name))
        except ImportError:
            pass
    key = "qosha_guard_sibling_" + name
    mod = _sys.modules.get(key)
    if mod is None:
        spec = importlib.util.spec_from_file_location(key, os.path.join(os.path.dirname(os.path.abspath(__file__)), name + ".py"))
        mod = importlib.util.module_from_spec(spec)
        _sys.modules[key] = mod
        spec.loader.exec_module(mod)
    return mod


try:
    DBX_EXPECTED_TOOLS, DBX_SCHEMA_SHA = _sibling("dropbox_pin").EXPECTED, _sibling("dropbox_pin").SCHEMA_SHA   # live pin (3B)
except Exception:          # ask.py loaded with nothing beside it: the guard still loads; the pin only words a refusal
    DBX_EXPECTED_TOOLS, DBX_SCHEMA_SHA = frozenset(), ""
DBX_DRIFT = ("Dropbox changed its tools; Qosha is updating. Reading and organizing Dropbox may not work until then.")
DBX_ORGANIZE_ONLY = "Qosha organizes Dropbox with dropbox_organize (your own folders only). Nothing was done."
_MS_SAFE_FOLDERS = frozenset("inbox archive drafts sentitems junkemail".split())
OUTLOOK_SEND_REFUSAL = ("Not sent: Qosha can read Outlook here; sending comes in a coming update. Nothing was sent.")
_NOT_MINE = object()
_CONNECTORS = {"microsoft": "Outlook", "dropbox": "Dropbox"}
_EMAIL_RX = re.compile(r"[^@\s,;<>\"']+@[^@\s,;<>\"']+\.[^@\s,;<>\"'.]+")

# field types: "str" non-empty string, "str0" any string, "bool" JSON boolean, ("one", {...}) one of these strings
# (case-insensitive), ("dict", fields, required), ("list", item, min)
_WHEN = ("dict", {"dateTime": "str", "timeZone": "str"}, ("dateTime", "timeZone"))
_ATTENDEE = ("dict", {"emailAddress": ("dict", {"address": "email", "name": "str0"}, ("address",)),
                      "type": ("one", {"required", "optional"})}, ("emailAddress",))
_EVENT = {"subject": "str", "start": _WHEN, "end": _WHEN, "location": ("dict", {"displayName": "str0"}, ("displayName",)),
          "attendees": ("list", _ATTENDEE, 0),
          "body": ("dict", {"contentType": ("one", {"text"}), "content": "str0"}, ("contentType", "content")),
          "isOnlineMeeting": "bool", "isAllDay": "bool"}
_RSVP = {"comment": "str0", "sendResponse": "bool"}
# tool -> (top-level ids, body fields or None, required body fields, body required)
_FIELDS = {
    ("microsoft", "create_calendar_event"): ((), _EVENT, ("subject", "start", "end"), True),
    ("microsoft", "update_calendar_event"): (("eventId",), _EVENT, (), True),
    ("microsoft", "delete_calendar_event"): (("eventId",), None, (), False),
    ("microsoft", "cancel_calendar_event"): (("eventId",), {"comment": "str0"}, ("comment",), True),
    ("microsoft", "accept_calendar_event"): (("eventId",), _RSVP, (), False),
    ("microsoft", "decline_calendar_event"): (("eventId",), _RSVP, (), False),
    ("microsoft", "tentatively_accept_calendar_event"): (("eventId",), _RSVP, (), False),
    ("microsoft", "share_drive_item"): (("driveId", "driveItemId"),
                                         {"recipients": ("list", ("dict", {"email": "email"}, ("email",)), 1),
                                          "roles": ("list", ("one", {"read", "write"}), 1),
                                          "sendInvitation": "bool", "requireSignIn": "bool", "message": "str0"},
                                         ("recipients", "roles", "sendInvitation", "requireSignIn"), True),
    ("microsoft", "create_drive_item_share_link"): (("driveId", "driveItemId"),
                                                     {"type": ("one", {"view", "edit"}),
                                                      "scope": ("one", {"anonymous", "organization", "users"})},
                                                     ("type", "scope"), True),
    ("microsoft", "delete_drive_item_permission"): (("driveId", "driveItemId", "permissionId"), None, (), False),
    ("microsoft", "delete_mail_message"): (("messageId",), None, (), False),
    ("microsoft", "delete_mail_attachment"): (("messageId", "attachmentId"), None, (), False),
    ("microsoft", "delete_mail_folder"): (("mailFolderId",), None, (), False),
    ("microsoft", "delete_onedrive_file"): (("driveId", "driveItemId"), None, (), False),
    ("microsoft", "move_mail_message"): (("messageId",), {"destinationId": "str"}, ("destinationId",), True),
}
_KINDS = {"delete_calendar_event": "calendar.change", "share_drive_item": "share", "create_drive_item_share_link": "share",
          "delete_drive_item_permission": "share", "delete_mail_message": "delete", "delete_mail_attachment": "delete",
          "delete_mail_folder": "delete", "delete_onedrive_file": "delete"}


class _Unshowable(Exception):
    pass


def _check(v: Any, t: Any, where: str) -> None:
    """Raise _Unshowable(field) unless v has exactly type t."""
    if t == "str":
        if not isinstance(v, str) or not v.strip():
            raise _Unshowable(where)
    elif t == "str0":
        if not isinstance(v, str):
            raise _Unshowable(where)
    elif t == "email":
        if not isinstance(v, str) or not _EMAIL_RX.fullmatch(v.strip()):
            raise _Unshowable(where)
    elif t == "bool":
        if not isinstance(v, bool):
            raise _Unshowable(where)
    elif t[0] == "one":
        if not isinstance(v, str) or v.strip().lower() not in t[1]:
            raise _Unshowable(where)
    elif t[0] == "dict":
        if not isinstance(v, dict):
            raise _Unshowable(where)
        for k in v:
            if k not in t[1]:
                raise _Unshowable("%s.%s" % (where, k))
            _check(v[k], t[1][k], "%s.%s" % (where, k))
        for k in t[2]:
            if k not in v:
                raise _Unshowable("%s.%s" % (where, k))
    elif t[0] == "list":
        if not isinstance(v, list) or len(v) < t[2]:
            raise _Unshowable(where)
        for i, x in enumerate(v):
            _check(x, t[1], "%s[%d]" % (where, i))
    else:
        raise _Unshowable(where)


def _validate(server: str, base: str, a: Dict[str, Any]) -> None:
    """The fixed fields of a carded Outlook/Dropbox tool (v1 section 2); raises _Unshowable(field)."""
    if server == "dropbox":
        try:
            _dbx_path_ok = _sibling("dropbox_organize")._path_ok
        except Exception:
            _dbx_path_ok = lambda _v: False            # the path rule can't be read: every Dropbox path refused
        def fq(v, where):                              # the same path rule as dropbox_organize (round 2: \n, bidi, ".")
            if not _dbx_path_ok(v):
                raise _Unshowable(where)
        if base == "delete":
            if set(a) != {"entries"} or not isinstance(a["entries"], list) or not 1 <= len(a["entries"]) <= 1000:
                raise _Unshowable(", ".join(sorted(set(a) - {"entries"})) or "entries")
            for e in a["entries"]:
                if not isinstance(e, dict) or set(e) != {"source_path"}:
                    raise _Unshowable("entries")
                fq(e["source_path"], "source_path")
            return
        if base == "create_shared_link":
            ok = {"path_or_file_id", "emails", "access_level", "audience", "expires", "allow_download"}
            if not set(a) <= ok or "path_or_file_id" not in a:      # a link password is never set by Qosha (v1)
                raise _Unshowable(", ".join(sorted(set(a) - ok)) or "path_or_file_id")
            fq(a["path_or_file_id"], "path_or_file_id")
            if "emails" in a:
                _check(a["emails"], ("list", "email", 0), "emails")
            # round 2 (Gemini H1): both written out, exactly, so the card never assumes Dropbox's default. Dropbox
            # accepts "view" (live 22 Nov 2026: "viewer" is rejected with INVALID_ACCESS_LEVEL)
            if a.get("access_level") != "view":
                raise _Unshowable("access_level")
            if a.get("audience") != "no_one":
                raise _Unshowable("audience")
            if "expires" in a:
                _check(a["expires"], "str", "expires")
            if "allow_download" in a:
                ad = a["allow_download"]
                if not (isinstance(ad, dict) and set(ad) == {"value"} and isinstance(ad["value"], bool)):
                    raise _Unshowable("allow_download")
            return
        raise _Unshowable(base)
    ids, body, req, need_body = _FIELDS[(server, base)]
    for k in a:
        if k not in ids and k != "body":
            raise _Unshowable(k)
    for k in ids:
        if k not in a:
            raise _Unshowable(k)
        _check(a[k], "str", k)
    if body is None:
        if "body" in a:
            raise _Unshowable("body")
        return
    if "body" not in a:
        if need_body:
            raise _Unshowable("body")
        return
    _check(a["body"], ("dict", body, req), "body")
    if base == "update_calendar_event" and not a["body"]:
        raise _Unshowable("body")
    if base == "share_drive_item" and len(a["body"]["roles"]) != 1:
        raise _Unshowable("roles")


def _connector(tool: str) -> Tuple[str, str]:
    """(server, tool part) for mcp__microsoft__/mcp__dropbox__ tools, else ("", "")."""
    low = (tool or "").lower()
    if not low.startswith("mcp__"):
        return "", ""
    parts = low.split("__", 2)
    if len(parts) < 3 or parts[1] not in _CONNECTORS:
        return "", ""
    return parts[1], parts[2]


def _invite(base: str, a: Dict[str, Any]) -> bool:
    """Does this calendar step tell other people (an invitation, an update, a cancellation, an answer)?"""
    b = a.get("body") if isinstance(a.get("body"), dict) else {}
    if base in ("create_calendar_event", "update_calendar_event"):
        return bool(b.get("attendees"))
    if base == "cancel_calendar_event":
        return True
    if base in ("accept_calendar_event", "decline_calendar_event", "tentatively_accept_calendar_event"):
        return b.get("sendResponse", True) is not False
    return False


def dbx_check_tools(tools: Any) -> bool:
    """The tools Dropbox offers now ({name: inputSchema}) against the pinned set (dropbox_pin.py): True when they
    match (an earlier note is cleared); otherwise False, and the Connections tile says so (never silently nothing)."""
    return _sibling("dropbox_pin").check(tools)


MS_RECONNECT = ("Outlook needs to be connected again in Qosha's Connections page (Qosha now reads Outlook only). "
                "Nothing was done.")
_MS_CFG = {"at": 0.0, "ok": False}


def _ms_read_only_config() -> bool:
    """The saved Outlook entry is exactly Qosha's own read-only one (microsoft_connect.server_config: same command,
    arguments and environment, no other key such as a url): an entry kept from an earlier install, or changed, is never
    used (fail closed; round 3, GPT H7)."""
    ok = False                                         # read every time (no cache: a changed entry counts at once)
    try:
        from hermes_cli.config import load_config
        e = ((load_config() or {}).get("mcp_servers") or {}).get("microsoft")
        canon = _sibling("microsoft_connect").server_config(_home_str())
        args = [str(x) for x in (canon or {}).get("args") or []]
        i = args.index("--allowed-scopes") if "--allowed-scopes" in args else -1
        scopes = set(args[i + 1].split()) if 0 <= i < len(args) - 1 else set()
        ok = (isinstance(e, dict) and isinstance(canon, dict) and set(e) <= {"command", "args", "env", "enabled"}
              and all(e.get(k) == canon.get(k) for k in ("command", "args", "env"))
              and "--read-only" in args and "Mail.Read" in scopes
              and scopes <= {"openid", "offline_access", "User.Read", "Mail.Read", "Calendars.Read", "Files.Read"}
              and str((canon.get("env") or {}).get("READ_ONLY", "")).lower() == "true")
    except Exception:
        ok = False
    _MS_CFG.update(at=time.time(), ok=ok)
    return ok


def _connector_kind(tool: str, a: Dict[str, Any]):
    """None (runs), (kind, what), ("refuse", words), or _NOT_MINE."""
    server, base = _connector(tool)
    if not server:
        return _NOT_MINE
    svc = _CONNECTORS[server]
    if server == "microsoft":
        if base in _MS_ACCOUNT:
            return "refuse", "Connect or disconnect Outlook in Qosha's Connections page. Nothing was done."
        if base in _MS_NONE:
            if not _ms_read_only_config():
                return "refuse", MS_RECONNECT          # round 2 (GPT H6): settings from before read-only, not used
            return None
        return "refuse", MS_READ_ONLY                  # read-only for now: no Outlook/OneDrive change runs, no card
    else:
        if base in _DBX_NONE:
            return None
        if base in _DBX_ORGANIZE:
            return "refuse", DBX_ORGANIZE_ONLY
        if base not in _DBX_CARD:
            extra = ""
            if base not in DBX_EXPECTED_TOOLS:            # Dropbox changed its tools: say so, never silently nothing
                extra = " " + DBX_DRIFT                   # (the tile's line comes only from dbx_check_tools, round 2)
            return "refuse", "Qosha doesn't use %s on Dropbox. Nothing was done.%s" % (base, extra)
    try:
        _validate(server, base, a)
    except _Unshowable as exc:
        field = re.sub(r"\[\d+\]", "", str(exc) or "this step").split(".")[-1] or "this step"
        return "refuse", "Qosha v1 can't show %s on its card, so it didn't do this. Nothing was done." % field
    if server == "dropbox":
        # round 2 (GPT H1, Gemini H2): a new file could land in a shared folder, so it gets the person's card too
        kind = "delete" if base == "delete" else "share"
        return kind, "%s %s" % (tool, _text(a))
    what = "%s %s" % (tool, _text(a))
    if base == "move_mail_message":
        dest = a["body"]["destinationId"].strip().lower()
        return None if dest in _MS_SAFE_FOLDERS else ("delete", what)
    if base in _KINDS:
        k = _KINDS[base]
        if k == "calendar.change" and _invite(base, a):
            k = "calendar.invite"
        return k, what
    return ("calendar.invite" if _invite(base, a) else "calendar.change"), what


def _when(v: Any) -> str:
    return "%s (%s)" % (v["dateTime"], v["timeZone"]) if isinstance(v, dict) else ""


def connector_rows(kind: str, tool: str, a: Dict[str, Any]) -> Optional[list]:
    """Every field of an (already validated) Outlook/Dropbox step, in full, as card rows; None for other tools."""
    server, base = _connector(tool)
    if not server:
        return None
    b = a.get("body") if isinstance(a.get("body"), dict) else {}
    rows = []
    add = lambda k, v: rows.append((k, v))
    yn = lambda v: "yes" if v else "no"
    if server == "dropbox":
        if base == "delete":
            add("What happens", "Delete in Dropbox (it goes to Dropbox's deleted files)")
            for e in a["entries"]:
                add("Path", e["source_path"])
        else:
            add("What happens", "Make a view-only Dropbox link")
            add("What", a["path_or_file_id"])
            add("Who can open it", ", ".join(a.get("emails") or []) or "only people you invite (none invited now)")
            add("Access", "view only, private (audience no_one, access view)")
            if "expires" in a:
                add("Expires", a["expires"])
            if "allow_download" in a:
                add("Download allowed", yn(a["allow_download"]["value"]))
        return rows
    if base.endswith("_calendar_event"):
        add("Change", {"create_calendar_event": "Add an event to your Outlook calendar",
                       "update_calendar_event": "Change an event in your Outlook calendar",
                       "delete_calendar_event": "Delete an event from your Outlook calendar",
                       "cancel_calendar_event": "Cancel a meeting (every attendee is told)",
                       "accept_calendar_event": "Accept an invitation",
                       "decline_calendar_event": "Decline an invitation",
                       "tentatively_accept_calendar_event": "Answer an invitation with Maybe"}[base])
        if "eventId" in a:
            add("Event id", a["eventId"])
        if "subject" in b:
            add("Event", b["subject"] or "(no title)")
        if "start" in b:
            add("Starts", _when(b["start"]))
        if "end" in b:
            add("Ends", _when(b["end"]))
        if "isAllDay" in b:
            add("All day", yn(b["isAllDay"]))
        if "location" in b:
            add("Where", b["location"]["displayName"] or "(no place)")
        if "attendees" in b:
            att = b["attendees"]
            def who(x):
                e = x["emailAddress"]
                name = e.get("name", "")
                shown = ("%s <%s>" % (name, e["address"].strip())) if name.strip() else e["address"].strip()
                return shown + ((" (%s)" % x["type"].strip().lower()) if "type" in x else "")
            add("Attendees", "\n".join(who(x) for x in att) if att else "removes every attendee")
            if att:
                add("Note from Qosha", "Outlook sends an invitation or update to every attendee listed.")
        if "body" in b:
            add("Body", b["body"]["content"] or "(empty)")
        if "isOnlineMeeting" in b:
            add("Online meeting", yn(b["isOnlineMeeting"]))
        if base in ("accept_calendar_event", "decline_calendar_event", "tentatively_accept_calendar_event"):
            add("Reply to organizer", yn(b.get("sendResponse", True) is not False))
        if "comment" in b:
            add("Comment", b["comment"] or "(none)")
        if base in ("update_calendar_event", "delete_calendar_event"):
            add("Note from Qosha", "Outlook may tell the event's attendees.")
        return rows
    if base == "share_drive_item":
        add("What happens", "Share a OneDrive file or folder")
        add("What", a["driveItemId"]); add("Drive", a["driveId"])
        add("With", "\n".join(r["email"].strip() for r in b["recipients"]))
        add("Can", "%s (%s)" % (b["roles"][0].strip().lower(), "edit" if b["roles"][0].strip().lower() == "write" else "view"))
        add("Sends an invitation email", yn(b["sendInvitation"]))
        add("Sign-in required to open", yn(b["requireSignIn"]))
        if "message" in b:
            add("Invitation message", b["message"] or "(none)")
        return rows
    if base == "create_drive_item_share_link":
        add("What happens", "Make a OneDrive sharing link")
        add("What", a["driveItemId"]); add("Drive", a["driveId"])
        add("Who can open it", {"anonymous": "anyone with the link", "organization": "anyone in the organization",
                                "users": "only people you add"}[b["scope"].strip().lower()])
        add("Can", b["type"].strip().lower())
        return rows
    if base == "delete_drive_item_permission":
        add("What happens", "Stop sharing (remove one person's or one link's access)")
        add("Drive", a["driveId"]); add("Item", a["driveItemId"]); add("Permission", a["permissionId"])
        return rows
    if base == "move_mail_message":
        dest = b["destinationId"]
        if dest.strip().lower() == "deleteditems":
            add("What happens", "Move an email to Deleted Items in Outlook")
        else:
            add("What happens", "Move an email to another folder in Outlook")
            add("To folder", dest)
            add("Note from Qosha", "Qosha can't tell whether this folder is Deleted Items.")
        add("Email", a["messageId"])
        return rows
    add("What happens", {"delete_mail_message": "Delete an email (it goes to Deleted Items)",
                         "delete_mail_attachment": "Remove an attachment from an email",
                         "delete_mail_folder": "Delete an Outlook mail folder",
                         "delete_onedrive_file": "Delete a OneDrive file or folder"}[base])
    for lab, k in (("Email", "messageId"), ("Attachment", "attachmentId"), ("Folder", "mailFolderId"),
                   ("Drive", "driveId"), ("Item", "driveItemId")):
        if k in a:
            add(lab, a[k])
    return rows


def _connector_card_problem(tool: str, rows: list, message: str) -> str:
    """Why a card for an Outlook or Dropbox step can't be shown in full ("" when it can)."""
    try:
        shown = len(message.encode("utf-16-le")) // 2
        disp = _as_shown(message)
        if disp is None:
            return "Qosha could not check how this step's card would look. Nothing was done."
        shown = max(shown, len(disp.encode("utf-16-le")) // 2)
    except UnicodeError:
        return "This step has a broken character that Qosha's card can't show. Nothing was done."
    if shown > CARD_SHOWS:
        return ("This step is too long for Qosha's card to show in full (%d characters; the card shows %d). Nothing was "
                "done. Make it shorter." % (shown, CARD_SHOWS))
    masked = _secret_masked(message)
    if masked is None:
        return "Qosha could not check this step for secrets. Nothing was done."
    if masked:
        return "This step contains a secret, which Qosha's card would hide. Nothing was done."
    return ""

def _tool_call_entries(a: Dict[str, Any]) -> Optional[list]:
    """The calls inside the engine's tool_call meta-tool, read the way the engine reads them
    (tools/tool_search_validation.normalize_tool_call_entries): [(name, arguments), ...], or None when unreadable."""
    raw = a.get("calls")
    if raw is None:
        if not str(a.get("name") or "").strip():
            return None
        raw = [{"name": a.get("name"), "arguments": a.get("arguments")}]
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            return None
    if isinstance(raw, dict):
        raw = [raw]
    if not isinstance(raw, list) or not raw:
        return None
    out = []
    for e in raw:
        if not isinstance(e, dict) or not str(e.get("name") or "").strip():
            return None
        args = e.get("arguments")
        if args is None or (isinstance(args, str) and not args.strip()):
            args = {}
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except Exception:
                return None
        if not isinstance(args, dict):
            return None
        out.append((str(e["name"]).strip(), args))
    return out


ONE_STEP = "Qosha checks one step at a time: call these one by one. Nothing was done."


def kind_of(tool: str, args: Any, task_id: str = "") -> Optional[Tuple[str, str]]:
    """(kind, what to show the person), or None when the call just runs. A shell step that only deletes things that
    are already gone is None too (pre_tool_call then stops it with a plain note: there is nothing to ask about)."""
    tool = (tool or "").strip()
    a = args if isinstance(args, dict) else {}
    # engine v0.22+: rarely used tools (MCP tools among them) are called through the "tool_call" meta-tool; the hook
    # then sees tool_call, so the real tool and its arguments are judged
    for _ in range(3):
        if tool != "tool_call":
            break
        entries = _tool_call_entries(a)
        if entries is None:
            try:
                blob = json.dumps(a)
            except Exception:
                blob = str(a)
            return ("refuse", ONE_STEP) if "whatsapp_" in blob else None   # unreadable: the engine rejects it itself
        if len(entries) > 1:
            if any(str(n).startswith("whatsapp_") for n, _x in entries):
                return "refuse", ONE_STEP         # WhatsApp steps one at a time, each with its own check (F4)
            # several steps in one call: each is judged; if any would get a card or a refusal, none runs (F1)
            if any(n == "computer_use" for n, _x in entries):
                return "refuse", ONE_AT_A_TIME_DESKTOP     # desktop steps one at a time (slice 5 v2)
            if any(kind_of(n, x, task_id) for n, x in entries):
                return "refuse", ONE_STEP
            return None
        tool, a = entries[0]
    if tool == "tool_call":
        return "refuse", ONE_STEP             # wrapped deeper than Qosha reads
    wg = whatsapp_guard_text(tool, a)
    if wg:
        return wg
    if tool == "whatsapp_reply":
        why = whatsapp_reply_problem(a)
        return ("refuse", why) if why else ("whatsapp.send", "WhatsApp message")   # its own Always allow (F3)
    if tool in WA_TOOLS_READ:
        return "whatsapp.read", "WhatsApp"     # held when Qosha's own read check isn't the one asking (F4)
    if tool in ("cronjob_manage", "cronjob", "cron"):
        dv = a.get("deliver")
        parts = dv if isinstance(dv, (list, tuple)) else [dv]
        if any(re.search(r"whats\s*app", str(x or ""), re.I) for x in parts):
            return "refuse", WA_NO_SCHED          # reminders stay in Qosha, never a WhatsApp message (R4)
    if tool == "computer_use":
        # only reached without Qosha's own desktop check (the startup fallback): held (W7)
        return "refuse", "Desktop steps go through Qosha's own check, which isn't running. Nothing was done."
    if tool == "outlook_send":
        return "refuse", MS_READ_ONLY                  # Outlook is read-only until Qosha's Microsoft executor lands
    if tool == "dropbox_organize":                     # Qosha's own Dropbox organizer (slice 3B): moves get a card
        try:
            _dbx_problem = _sibling("dropbox_organize").problem
            why = _dbx_problem(a)
        except Exception:
            why = "Qosha could not check this Dropbox step. Nothing was done."
        if why:
            return "refuse", why
        # round 2: copy and create_folder get the card too (a copy can land where others see it)
        # its own kind (round 3, GPT+Gemini H1): an older "Always allow" for moves never covers new kinds of change
        return "dropbox.change", "Dropbox %s" % str(a.get("action")).replace("_", " ")
    ck = _connector_kind(tool, a)
    if ck is not _NOT_MINE:
        return ck
    if tool in ("terminal", "execute_code", "process", "process_manage"):
        text = "\n".join(str(a.get(k)) for k in ("command", "code", "input", "data", "workdir", "cwd")
                         if a.get(k) not in (None, ""))
        if _SYNTH.search(text):
            return "refuse", NO_SYNTH                 # synthetic key presses or clicks from a command, any app (v3)
        if _WA_ENGINE_CMD.search(text):
            return "refuse", WA_ENGINE                # the engine's own WhatsApp setup, gateway or bridge (v3)
        if re.search(r"\bhermes(?:\.exe)?\s+gateway\b", text, re.I) and _wa_linked():
            return "refuse", WA_ENGINE                # the engine's gateway never runs while WhatsApp is linked (F7)
        if _broad_search(text):
            return "refuse", NO_BROAD_SEARCH          # B2
        if whatsapp_shell(text):
            return "refuse", WHATSAPP_ONLY_READS      # desktop automation of WhatsApp from a command (W8)
        if _engine_cli_send(a):
            return "message.send", _text(text)
        found = _step_kinds(tool, a, task_id)
        return (found[0], _text(text)) if found else None
    if tool == "browser_navigate" and whatsapp_host(a.get("url")):
        return "refuse", WHATSAPP_NO_WEB             # the agent's browser never goes to WhatsApp (W10)
    if tool == "browser_cdp" and str(a.get("method") or "") in ("Page.navigate", "Target.createTarget"):
        _p = a.get("params")
        if isinstance(_p, str):
            try:
                _p = json.loads(_p)               # params given as a JSON string are judged the same (v3)
            except Exception:
                return "refuse", WHATSAPP_NO_WEB
        _p = _p if isinstance(_p, dict) else {}
        if whatsapp_host(_p.get("url")):
            return "refuse", WHATSAPP_NO_WEB
    if tool == "browser_exec" and _WA_HOST_IN_TEXT.search(str(a.get("code") or "")):
        return "refuse", WHATSAPP_NO_WEB
    if tool == "browser_exec":
        # the engine's browser runs Python helpers; reading and moving between pages never asks, acting on a page does
        code = str(a.get("code") or "")
        return ("web.act", _text(code)) if web_plain(code)[3] else None
    if tool == "browser_cdp":
        # raw browser commands: a mouse press, the Enter key or a file given to the page cannot be told apart from a
        # final step, so they ask; everything else (reading, moving about) runs
        method = str(a.get("method") or "")
        params = a.get("params")
        if isinstance(params, str):            # the engine turns a JSON string into the object the browser gets (r1210 r2)
            try:
                params = json.loads(params)
            except Exception:
                params = {"type": "", "key": "Enter"} if re.search(r"Enter|Return|mouse|File", params) else {}
        params = params if isinstance(params, dict) else {}
        pseudo = 'cdp("%s", key="%s")' % (method, str(params.get("key") or "")) if re.fullmatch(r"[A-Za-z.]{1,60}", method) else ""
        if pseudo and re.search(r"Input\.dispatchMouseEvent|DOM\.setFileInputFiles", method) and str(params.get("type") or "mousePressed") in ("mousePressed", "", "mouseReleased"):
            return "web.act", pseudo
        if pseudo and method == "Input.dispatchKeyEvent" and str(params.get("key") or "") in ("Enter", "Return", "NumpadEnter") and str(params.get("type") or "") in ("keyDown", "rawKeyDown", ""):
            return "web.act", pseudo
        return None
    if tool == "patch" and re.search(r"^\*\*\* Delete File:", str(a.get("patch") or ""), re.M):
        return None if _deletes_only_gone(tool, a, task_id) else ("delete", _text(a.get("patch")))
    if tool == "qosha_google_change":
        # Qosha's Google write tool (1.20.9): its operation names the card's kind; an unknown one still asks; the card
        # names the Google account it acts on (rows_for)
        op = str(a.get("operation") or "")
        kind = {"gmail.send": "email.send", "calendar.create": "calendar.change", "calendar.update": "calendar.change",
                "calendar.delete": "calendar.change", "drive.trash": "delete", "drive.share": "share",
                # gap 6: the person's own files only (the executor refuses anything shared or not theirs) (Ren 22 Nov)
                "drive.folder": "file.organize", "drive.move": "file.organize", "drive.rename": "file.organize",
                "drive.copy": "file.organize", "docs.create": "file.edit", "docs.append": "file.edit",
                "sheets.create": "file.edit", "sheets.append": "file.edit",
                # Gmail tidying (SPEC-M): one email of the person's own mailbox, undoable
                "gmail.archive": "mail.tidy", "gmail.unarchive": "mail.tidy", "gmail.mark_read": "mail.tidy",
                "gmail.mark_unread": "mail.tidy"}.get(op, "google.change")
        return kind, "%s %s" % (tool, _text(a))
    if tool == "send_message":
        if str(a.get("target") or "").strip().lower().startswith("whatsapp"):
            return "refuse", WHATSAPP_NO_SEND      # the engine's own WhatsApp channel (W9), before any shortcut
        if str(a.get("action") or "send").lower() in ("list", "targets"):
            return None
        return "message.send", "to %s: %s" % (a.get("target") or "?", _text(a.get("message") or a))
    if tool in _QUIET:
        return None
    low = tool.lower()
    # the engine names MCP tools mcp__<server>__<tool>
    base = low.rsplit("__", 1)[-1] if low.startswith("mcp__") else low
    act = str(a.get("action") or a.get("operation") or a.get("op") or "").lower()
    google = low.startswith("mcp__google__")
    if google and _google_mcp_read(base, a):
        return None
    # Google Workspace MCP (and similar): reads never ask; actions are judged by what they do
    if not google and re.match(r"^(get|list|search|read|check|query|find|fetch|describe)_", base):
        return None
    if act in ("delete", "remove", "trash", "clear", "destroy", "batch_delete"):
        return "delete", "%s %s" % (tool, _text(a))
    if re.search(r"(^|_)(manage_)?event", base) and act in ("create", "update", "rsvp", "respond", "move", "patch", "insert", "quick_add"):
        return "calendar.change", "%s %s" % (tool, _text(a))
    if re.search(r"access|permission|shar", base):
        return "share", "%s %s" % (tool, _text(a))
    if base.startswith("draft_") and not google:
        return None
    for kind, rx in _TOOL_RULES:
        if re.search(rx, base):
            return kind, "%s %s" % (tool, _text(a))
    if google:
        return "google.change", "%s %s" % (tool, _text(a))   # fail closed: any other Google tool is asked (1.20.8)
    return None


# the engine's command or its own sender function; "send" anywhere (send_message, send_message_tool...)
_ENGINE_WORD = re.compile(r"\b(?:hermes|hermes_cli|qosha|send_message_tool|gateway\.outbound)\b", re.I)


# Google's command-line tools (1.20.4, human approval; reproduced by the pt-BR session on 1.19.13: `gws drive files
# delete` and `gws gmail users messages trash` ran with no card): gws (Google Workspace CLI), workspace-cli (the Google
# MCP's own command line, in the engine's gws-venv) and Qosha's Google helper (google_api.py, $GAPI).
# STRICT, after six review rounds found shell forms past every text classifier: a Google program runs only as ONE
# plain command on its own (read with the guard's own shell reader, _segments): a plain read runs, anything else gets a
# card filed from its own command words (one-time, except the helper's and gws calendar-event commands the 1.20.3 table
# already filed), a send is refused like every shell send. Everything else that names a Google program (code, wrappers,
# loops, VAR= prefixes, $(...), redirections first, two Google calls, a Google call next to another protected action)
# is refused with GOOGLE_MIXED. Its name inside a title (gh issue create) or a file a plain reader reads is ignored.
_GPROG = re.compile(r"(?<![\w.-])(gws_bridge\.py|gws|workspace-cli|google_api\.py|\$\{?GAPI\}?)"
                    r"(?:\.(?:exe|cmd|bat|ps1))?(?![\w.-])", re.I)
_GWS_READ = {"list", "get", "export", "search", "query"}
_GWS_READ_HELPERS = {"+triage", "+agenda"}
_GWS_DELETE = {"delete", "trash", "emptytrash", "batchdelete", "remove", "clear", "purge", "destroy", "+delete",
               "+trash"}
_GWS_SEND = {"send", "reply", "forward", "+send", "+reply", "+reply-all", "+forward"}
_GAPI_READ = {("gmail", "search"), ("gmail", "get"), ("gmail", "labels"), ("calendar", "list"), ("drive", "search"),
              ("drive", "get"), ("drive", "download"), ("contacts", "list"), ("sheets", "get"), ("docs", "get")}
# the helper's own commands the 1.20.3 table already filed (their cards and reusable rules stay as they were)
_GAPI_KNOWN = {("gmail", "send"): "email.send", ("gmail", "reply"): "email.send", ("gmail", "forward"): "email.send",
               ("calendar", "create"): "calendar.change", ("calendar", "update"): "calendar.change",
               ("calendar", "delete"): "calendar.change", ("drive", "delete"): "delete", ("drive", "share"): "share",
               ("drive", "upload"): "share"}
_CLI_READ_VERB = {"list", "get", "search", "read", "query", "find", "fetch", "show", "view", "download", "export",
                  "status", "info", "check"}
_CLI_WRITE_WORDS = ("delete", "remove", "trash", "send", "share", "create", "update", "modify", "manage", "set", "add",
                    "move", "copy", "upload", "write", "replace", "insert", "batch", "reply", "forward", "draft", "post")
_READERS = {"cat", "type", "ls", "dir", "head", "tail", "grep", "rg", "wc", "stat", "file", "which",
            "where", "get-content", "select-string", "get-childitem"}
_IDENT = re.compile(r"^[A-Za-z][A-Za-z0-9]*$")
GOOGLE_MIXED = ("Not run: a Google step (gws, workspace-cli or the Google helper) runs only as one plain command on its "
                "own: no other actions, wrappers, loops, variables or code around it, so the person sees exactly what "
                "it does. Run it that way and ask again.")


def _unq(word: str) -> str:
    return re.sub(r"[\"'`\\]", "", word)


def _prog_name(word: str) -> str:
    """The program a command word names: its last path part, lower case, without quotes or .exe/.cmd/.bat/.ps1."""
    if re.search(r"[=<>()]", word) or re.match(r"\d+[<>]", word):
        return ""                              # r1205 #3: FOO=/cat, </tmp/cat, (gws ... are not a program named cat or gws
    w = re.split(r"[\\/]", word.strip("\"'`"))[-1].lower()
    return re.sub(r"\.(?:exe|cmd|bat|ps1)$", "", _unq(w))


_GMODNAME = re.compile(r"(?:(?<![\w-])|(?<=-m))(?:google_api|gws_bridge)(?![\w-])", re.I)   # scripts.google_api too
_GMODONLY = re.compile(r"(?:(?<![\w/\\-])|(?<=-m))(?:google_api|gws_bridge)(?![\w-])(?!\.py\b)", re.I)   # not a path  # a module, not the script   # as a Python module (python -m, import)
_PYWORD = re.compile(r"(?<![\w.-])(?:python[0-9.]*|pythonw|py)(?:\.exe)?(?![\w.-])", re.I)


def _escapes(text: str) -> str:
    """Every \\xHH, \\uHHHH, \\UHHHHHHHH and \\NNN decoded wherever it is (bash's $'...' does it; anywhere else
    decoding only makes the mention check broader) (Gemini on 56053283, HIGH 3)."""
    def one(m):
        try:
            return chr((int(m.group(1), 8) & 0xFF) if m.group(1) else int(m.group(2) or m.group(3) or m.group(4), 16))
        except (ValueError, OverflowError):
            return m.group(0)
    return re.sub(r"\\([0-7]{1,3})|\\x([0-9a-fA-F]{1,2})|\\u([0-9a-fA-F]{1,4})|\\U([0-9a-fA-F]{1,8})", one, text)


def _mentions_google(raw: str) -> bool:
    """Any mention of a Google program, however it is quoted, escaped or split (r1205 round 2): the step is then held to
    _plain_shell. Broad on purpose; whether a Google program RUNS is decided per command afterwards."""
    flat = _escapes(raw)
    flat = re.sub(r"\\\r?\n", "", flat)
    flat = re.sub(r"[\"'`\\${},]", "", flat)
    # a skeleton: letters and digits only, lower case, words kept apart, so quotes, braces, $(), escapes and capitals
    # can't hide a name (Gemini on 352a51d6, HIGH 1-3, 6)
    def skel(text):
        return re.sub(r"[^a-z0-9\s]", "", re.sub(r"\\\r?\n", "", text).lower())
    # bash's $'...': escapes decoded, \c@ is NUL, and a NUL ends the quoted text (Gemini on b51e6a47, HIGH 3)
    ansi = re.sub(r"\$'((?:[^'\\]|\\.)*)'",
                  lambda m: _escapes(m.group(1).replace("\\c@", "\\0")).split("\x00", 1)[0], raw)
    # an expansion that adds nothing: $(...), `...`, ${...}, $NAME (Gemini on b51e6a47, HIGH 2)
    nosub = re.sub(r"\$\([^)]*\)|`[^`]*`|\$\{[^}]*\}|\$[A-Za-z_]\w*", "", raw)
    sks = [skel(_escapes(raw)), skel(ansi), skel(_escapes(nosub)), skel(re.sub(r"\$\([^)]*\)|`[^`]*`|\$\{[^}]*\}|"
                                                                            r"\$[A-Za-z_]\w*", "", ansi))]
    return bool(_names_google(raw) or _GPROG.search(flat) or _GMODNAME.search(flat) or
                any(re.search(r"gws|googleapi|workspacecli", s) for s in sks))


_BARE_BAD = set("$`\\(){}#!*?[]")
_DQ_BAD = set("$`\\!")


def _plain_shell(cmd: str) -> bool:
    """Plain bash text, read the same way by every reader (r1205 round 2). Outside quotes: no $ (except $GAPI), backtick,
    backslash, ( ) { } # ! * ? [ ]; inside double quotes: no $ (except $GAPI), backtick, backslash, !; single-quoted
    text is data. The engine runs bash on Mac and Windows (Git Bash), so this holds on both."""
    cmd = re.sub(r"\$\{GAPI\}|\$GAPI(?![\w{])", "GAPI", cmd)
    i, n = 0, len(cmd)
    while i < n:
        c = cmd[i]
        if c in "'\"":
            j = cmd.find(c, i + 1)
            if j < 0 or (c == '"' and any(ch in _DQ_BAD for ch in cmd[i + 1:j])):
                return False
            i = j + 1
            continue
        if c in _BARE_BAD or cmd.startswith("<<", i):
            return False                       # a heredoc's text is not shell quoting (Gemini on b51e6a47, HIGH 1)
        i += 1
    return True


def _names_google(word: str) -> bool:
    word = word.replace("\\\r\n", "").replace("\\\n", "")       # r1205 #5: g\<newline>ws is gws to the shell
    return bool(_GPROG.search(word) or _GPROG.search(_unq(word)) or _GPROG.search(re.sub(r"[\"'`\\]", " ", word)))


def _is_python(word: str) -> bool:
    return bool(re.fullmatch(r"(?:pythonw?|pypy|ipython|jython|graalpy|micropython)[0-9.]*[a-z0-9_-]*|py", _prog_name(word)))


def _is_helper(word: str) -> bool:
    return _prog_name(word) == "google_api.py" or bool(re.fullmatch(r"\$\{?GAPI\}?", word.strip("\"'")))


def _is_bridge(word: str) -> bool:
    return _prog_name(word) in ("gws_bridge.py", "gws_bridge")


def _gws_kind(rest: list) -> Tuple[str, bool]:
    """(kind, reusable) of a plain gws call, from its own command words; ("read", ...) for a plain read."""
    if rest in (["--help"], ["-h"], ["--version"]):
        return "read", False
    if rest and rest[0].startswith("-"):
        return "refuse", False                 # options before the service: can't be read safely
    sub = []
    for w in rest:
        if w.startswith("-"):
            break
        sub.append(w)
    low = [w.lower() for w in sub]
    args = " ".join(rest[len(sub):])
    if low and low[0] == "schema":
        return "read", False
    helpers = [w for w in low if w.startswith("+")]
    if not helpers and 2 <= len(sub) <= 5 and all(_IDENT.match(w) for w in sub) and low[-1] in _GWS_READ:
        return "read", False
    if helpers and all(h in _GWS_READ_HELPERS for h in helpers) and all(_IDENT.match(w) or w in _GWS_READ_HELPERS for w in low):
        return "read", False
    if set(low) & _GWS_SEND or (low and low[0] == "chat" and set(low) & {"create", "patch", "update", "send"}):
        return ("message.send" if low and low[0] == "chat" else "email.send"), False
    if low and low[0] == "calendar":
        if "acl" in low:
            return "share", False
        if "events" in low and low[-1] in ("insert", "patch", "update", "delete"):
            return "calendar.change", True     # exactly the 1.20.3 table's own calendar rule
        if "events" in low and low[-1] in ("import", "move", "quickadd"):
            return "calendar.change", False    # moving or importing: one-time
        if low[-1] in ("+insert", "+create"):
            return "calendar.change", True
        if set(low) & {"clear", "delete"}:
            return "delete", False
        return "google.change", False
    if set(low) & _GWS_DELETE:
        return "delete", False
    if low[-2:] == ["files", "update"] and re.search(r"\btrashed\W{0,4}(?:true|1)\b", args, re.I):
        return "delete", False
    if set(low) & {"permissions", "+share", "+upload", "share", "publish", "+publish"}:
        return "share", False
    return "google.change", False


def _wcli_kind(rest: list) -> Tuple[str, bool]:
    while rest and rest[0].lower().startswith("--url"):
        url = rest[0].split("=", 1)[1] if "=" in rest[0] else (rest[1] if len(rest) > 1 else "")
        if not re.match(r"^https?://(?:127\.0\.0\.1|localhost|\[::1\])(?::\d+)?(?:/|$)", url.strip("\"'")):
            return "refuse", False             # another server would receive what is asked (a search included)
        rest = rest[1:] if "=" in rest[0] else rest[2:]
    if rest in (["list"], ["--help"], ["-h"]):
        return "read", False
    if len(rest) < 2 or rest[0] != "call" or rest[1].startswith("-"):
        return "refuse", False
    name = rest[1].lower()
    for kind, rx in _TOOL_RULES:
        if kind in ("email.send", "message.send") and re.search(rx, name, re.I):
            return kind, False
    if name.split("_")[0] in _CLI_READ_VERB and not any(w in name for w in _CLI_WRITE_WORDS):
        return "read", False
    if re.search(r"(?:^|_)(?:delete|trash|remove|purge|destroy)(?:_|$)", name):
        return "delete", False
    if re.search(r"share|access|permission", name):
        return "share", False
    return "google.change", False


_GAPI_OPTS = {"--add-labels", "--attendees", "--body", "--calendar", "--cc", "--description", "--domain", "--email",
              "--end", "--export-mime", "--from", "--html", "--location", "--max", "--mime-type", "--name", "--notify",
              "--output", "--parent", "--permanent", "--raw-query", "--remove-labels", "--role", "--sheet-name",
              "--start", "--subject", "--summary", "--text", "--thread-id", "--title", "--to", "--type", "--values",
              "-h", "--help"}


def _gapi_kind(rest: list) -> Tuple[str, bool]:
    if not rest or rest[0].startswith("-"):
        return "refuse", False
    if any(x.startswith("-") and len(x) > 1 and not re.fullmatch(r"-\d+(?:\.\d+)?", x) and x not in _GAPI_OPTS
           for x in rest):
        return "refuse", False                 # an abbreviated (--perm) or name=value option: the card reads exact names (r1205)
    w = tuple(x.lower() for x in rest[:2])
    if w in _GAPI_READ:
        return "read", False
    if w == ("drive", "share") and any(x.lower().startswith("--n") for x in rest):
        return "share", False                  # it also emails the person: never covered by a saved grant
    if w in _GAPI_KNOWN:
        return _GAPI_KNOWN[w], True
    return "google.change", False


_MOD_RUNNERS = {"uv", "uvx", "pipx", "poetry", "pdm", "hatch", "rye", "pixi", "conda", "mamba", "micromamba", "run",
                "exec", "runpy", "import", "importlib", "bash", "sh", "zsh", "dash", "ksh", "fish", "pwsh", "powershell",
                "cmd", "env", "xargs", "eval", "source", "nohup", "timeout", "sudo", "nice", "watch"}   # anything that can run a Python module (r1205 final pass 4: uv run -m google_api)
_SAFE_NEIGHBOURS = _READERS | {"cd", "pwd", "echo", "jq", "sort", "uniq", "mkdir", "true"}


def _runs_program(argv: list) -> bool:
    """A reader option that runs another program (rg --pre, rg -z runs decompressors) (r1205 final pass 3)."""
    p = _prog_name(argv[0])
    return any(w.startswith(("--pre", "--search-z")) or (p == "rg" and re.fullmatch(r"-[A-Za-z]*z[A-Za-z]*", w)) or
               (p == "sort" and w.startswith("--comp")) for w in argv[1:])   # sort --compress-program runs one too


def _plain_git(argv: list) -> bool:
    """git with nothing that runs a program (no -c, --exec-path, --upload-pack, --receive-pack, --config ...)."""
    return _prog_name(argv[0]) == "git" and not any(
        w.startswith(("-c", "--exec-path", "--upload-pack", "--receive-pack", "--config", "--git-dir", "--work-tree",
                      "--namespace", "--super-prefix")) or w in ("-C",) for w in argv[1:])


def _safe_neighbour(argv: list) -> bool:
    """A plain command that runs nothing it reads: a reader, cd, echo ..., or gh posting text."""
    p = _prog_name(argv[0])
    if _runs_program(argv):
        return False
    return p in _SAFE_NEIGHBOURS or (p == "gh" and len(argv) > 2 and argv[1] in ("issue", "pr", "release", "gist")
                                     and argv[2] in ("create", "comment", "edit", "view", "list"))


def kind_words_quoted(cmd: str, prog_word: str, rest: list) -> bool:
    """The program, its command words and option names must appear in the text exactly as bash reads them (unquoted):
    the card reads them from the text."""
    raw = set(w.split("=", 1)[0] for w in cmd.split())
    words, lead = [prog_word], True
    for w in rest:
        if w.startswith("-"):
            words.append(w.split("=", 1)[0])   # every option name
            lead = False
        elif lead and len(words) < 6 and re.fullmatch(r"\+?[A-Za-z][\w.-]*", w):
            words.append(w)                    # the command words before any value with a blank or an option
        else:
            lead = False
    return any(w not in raw for w in words)


def google_verdict(tool_name: str, args: Any) -> Optional[Tuple[str, str, bool]]:
    """What a shell or code step does with Google's command-line tools (1.20.4, fail closed):
    None: no Google program runs in it (at most its name inside a title, or a file a plain reader reads);
    ("read", "", False): one plain call that only reads; ("card", kind, reusable): one plain call that changes
    something (a send is filed as a send and refused like every shell send); ("refuse", "", False): anything else that
    names a Google program (code, wrappers, loops, VAR= prefixes, $(...), redirections first, several Google calls, or a
    Google call next to another protected action)."""
    tool, a = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
    if tool not in ("terminal", "execute_code", "process", "process_manage"):
        return None
    raw = " ".join(str(a.get(k) or "") for k in ("command", "code", "input", "data"))
    if not _mentions_google(raw):
        return None
    cmd = str(a.get("command") or a.get("input") or "")
    if a.get("code") or tool in ("execute_code", "process", "process_manage") or a.get("data") or not cmd \
            or not _plain_shell(cmd):          # text sent to a running process is not one plain command (HIGH 6)
        return "refuse", "", False             # code, or shell text that readers could read differently (r1205)
    segs = _segments(cmd, posix=True)          # bash, on Mac and Windows alike
    if not segs:
        return "refuse", "", False
    calls, others, named_text, has_mod, has_runner, written = [], [], False, False, False, []
    for argv, _sep in segs:
        if not argv:
            continue
        parts = [x for w in argv for x in re.split(r"[^\w.+/-]+", _unq(w)) if x]   # also inside one quoted word, any separator
        runner = any(_is_python(x) or _prog_name(x) in _MOD_RUNNERS or x.startswith("-m") for x in parts)
        names = any(_names_google(w) for w in argv) or (runner and any(_GMODNAME.search(x) for x in parts))
        p = _prog_name(argv[0])     # python -m google_api / gws_bridge, import ...: refused below (run the script)
        has_mod = has_mod or any(_GMODONLY.search(x) for x in parts)
        is_call = p in ("gws", "workspace-cli") or _is_helper(argv[0]) or _is_bridge(argv[0]) or (
            _is_python(argv[0]) and len(argv) > 1 and (_is_helper(argv[1]) or _is_bridge(argv[1])))
        has_runner = has_runner or (not is_call and runner)
        if p in ("gws", "workspace-cli") or _is_helper(argv[0]) or _is_bridge(argv[0]):
            calls.append(("bridge" if _is_bridge(argv[0]) else p if p in ("gws", "workspace-cli") else "helper", argv[1:]))
            written.append(argv[0])
            continue
        if _is_python(argv[0]) and len(argv) > 1 and (_is_helper(argv[1]) or _is_bridge(argv[1])):
            calls.append(("bridge" if _is_bridge(argv[1]) else "helper", argv[2:]))
            written.append(argv[1])
            continue
        if names:
            ok_text = not _runs_program(argv) and (p in _READERS or (
                p == "gh" and len(argv) > 2 and argv[1] in ("issue", "pr", "release", "gist")
                and argv[2] in ("create", "comment", "edit", "view", "list")))
            if not ok_text:
                return "refuse", "", False     # a wrapper, an interpreter, a prefix, a loop ... naming a Google program
            named_text = True
        others.append(" ".join(argv))
    if has_mod and has_runner:
        return "refuse", "", False             # a module name and a Python runner anywhere in the step (Gemini HIGH 2)
    if has_mod and not calls and not all(not argv or _safe_neighbour(argv) or _plain_git(argv) for argv, _sep in segs):
        return "refuse", "", False             # a module name next to anything that could run it (Gemini b51e6a47 HIGH 4)
    if not calls:
        if named_text and any(argv and not _safe_neighbour(argv) for argv, _sep in segs):
            return "refuse", "", False         # a Google name in a reader's text, piped or passed on to a runner (r1205)
        return None
    if len(calls) > 1:
        return "refuse", "", False
    other = " ; ".join(others)
    if other and any(re.search(rx, other, re.I | re.M) for _k, rx in _CMD_RULES):
        return "refuse", "", False             # a Google step next to another protected action
    if kind_words_quoted(cmd, written[0], calls[0][1]):
        return "refuse", "", False             # quoted command words: the card reads them as written (b51e6a47 HIGH 5)
    base = re.split(r"[\\/]", written[0])[-1]
    if base != base.lower() and not re.fullmatch(r"\$\{?GAPI\}?", written[0].strip("\"'")):
        return "refuse", "", False             # GOOGLE_API.PY, GWS: the card reads the usual spelling (Gemini HIGH 6)
    prog, rest = calls[0]
    kind, reusable = (_gws_kind if prog in ("gws", "bridge") else _wcli_kind if prog == "workspace-cli" else _gapi_kind)(rest)
    reusable = reusable and prog != "bridge"   # the skill's bridge forwards anything: never a saved grant (r1205 final)
    if kind == "refuse":
        return "refuse", "", False
    if kind != "read" and re.search(r"[<>]", re.sub(r"'[^']*'|\"[^\"]*\"", "", cmd)):
        return "refuse", "", False             # a redirection glued to a word hides what the call gets (Gemini HIGH 5)
    for argv, _sep in segs:                    # around a Google call only plain commands that run nothing; around one
        if not argv or _prog_name(argv[0]) in ("gws", "workspace-cli") or _is_helper(argv[0]) or _is_bridge(argv[0]) \
                or (_is_python(argv[0]) and len(argv) > 1 and (_is_helper(argv[1]) or _is_bridge(argv[1]))):
            continue                           # that gets a card nothing at all: the card reads flags
        if kind == "read" and _prog_name(argv[0]) in _SAFE_NEIGHBOURS and not _runs_program(argv):   # from the
            continue                           # whole text (r1205 final pass 3); a read gets no card, gh posts are not reads
        return "refuse", "", False             # a card's Google call stands alone, not even a cd (Gemini HIGH 7)
    if kind == "read":
        return "read", "", False
    return "card", kind, reusable


def google_mixed(tool_name: str, args: Any, task_id: str = "") -> bool:
    try:
        v = google_verdict(tool_name, args)
    except Exception:
        return True
    return bool(v) and v[0] == "refuse"


def google_step(tool_name: str, args: Any) -> bool:
    """A card filed by the Google reader that is not one of the 1.20.3 table's own: one-time."""
    try:
        v = google_verdict(tool_name, args)
    except Exception:
        return True
    return bool(v) and (v[0] == "refuse" or (v[0] == "card" and not v[2]))


def _step_kinds(tool: str, a: Dict[str, Any], task_id: str = "") -> list:
    """Every protected kind a shell or code step does, the card's kind first. A step with a Google program call is
    filed from that call alone (its arguments are never read as other actions); every other step as in 1.20.3."""
    v = google_verdict(tool, a)
    if v:
        return [] if v[0] == "read" else [v[1] or "google.change"]
    rules = _CODE_RULES if tool == "execute_code" else _CMD_RULES
    kinds = []
    # every field on its own: command, code, input and data (connectors slice 1 V1.1 F3 / V1.3 H1); a send hidden in
    # one field beside a harmless other field is still found
    for text in (str(a.get(k)) for k in ("command", "code", "input", "data") if a.get(k) not in (None, "")):
        for kind, rx in rules:
            if re.search(rx, text, re.I | re.M):
                if kind == "delete" and _deletes_only_gone(tool, a, task_id):
                    continue   # what it would delete is not there: no card (17 Nov)
                if kind not in kinds:
                    kinds.append(kind)
    return kinds


def mixed_step(tool_name: str, args: Any, task_id: str = "") -> bool:
    """A shell or code step that does more than one protected kind of thing (a calendar change and a post, a refund
    and a spreadsheet change, ...): its card is a one-time one, so no saved grant for one kind covers the other
    (verification 1.20.4 #4). Pre-1.20.4 the first kind's grant covered the whole step."""
    try:
        tool, a = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
        if tool not in ("terminal", "execute_code", "process", "process_manage"):
            return False
        return len(_step_kinds(tool, a, task_id)) > 1
    except Exception:
        return True


def _engine_cli_send(a: Dict[str, Any]) -> bool:
    """A shell or code step that names the engine's command (hermes, hermes_cli, qosha) and the word "send" anywhere,
    read with quotes, backslash-newlines and backslashes removed: treated as a send (refused in _unseen). No parsing of
    how it is written (verification vqa/allowc r6: quoting, flags, line breaks and argv lists all got past a shape
    check). A step that only mentions both words is refused too; that is accepted (orchestrator, 20 Nov 2026)."""
    raw = " ".join(str(a.get(k) or "") for k in ("command", "code", "input", "data"))
    # read two ways, either counts (verification vqa/b1202 r7): quotes and backslashes deleted (h"ermes" s\end is
    # hermes send to the shell), and the same replaced by a space (C:\bin\hermes.exe, r"hermes" keep their word)
    joined = re.sub(r"[\"'`\\]", "", raw.replace("\\\r\n", "").replace("\\\n", ""))
    spaced = re.sub(r"[\"'`\\]", " ", raw)
    return any(_ENGINE_WORD.search(t) for t in (joined, spaced)) and any("send" in t.lower() for t in (joined, spaced))


def _flag_args(text: str) -> Dict[str, str]:
    """--to X --subject "Y" ... from a command line (the Google skill's script); {} when it can't be read."""
    import shlex
    try:
        words = shlex.split(text)
    except ValueError:
        return {}
    out, i = {}, 0
    while i < len(words):
        w = words[i]
        if w.startswith("--") and len(w) > 2:
            if "=" in w:
                k, v = w[2:].split("=", 1)
                out[k] = v
            elif i + 1 < len(words) and not words[i + 1].startswith("--"):
                out[w[2:]] = words[i + 1]
                i += 1
            else:
                out[w[2:]] = "yes"
        i += 1
    return out


def _unwrap(tool: str, a: Dict[str, Any]):
    for _ in range(3):
        if tool != "tool_call":
            break
        entries = _tool_call_entries(a)
        if not entries or len(entries) != 1:
            break
        tool, a = entries[0]
    return tool, a


def _outlook_rows(a: Dict[str, Any]) -> list:
    """The card for outlook_send: every recipient, the subject and the whole plain text."""
    from .outlook_send import addresses
    rows = []
    for lab, key in (("To", "to"), ("Cc", "cc"), ("Bcc", "bcc")):
        got = addresses(a.get(key))
        if got:
            rows.append((lab, ", ".join(got)))
    rows.append(("Subject", a["subject"] if a.get("subject") else "(no subject)"))
    rows.append(("Body", a["body"] if a.get("body") else NO_TEXT))
    rows.append(("Sends from", "Outlook (Qosha writes and sends exactly this, as plain text)"))
    return rows

# Qosha's Google change tool, gap 6 (22 Nov 2026, SPEC-G section 4): what each new operation does, in plain words
_GDRIVE_SAYS = {"drive.folder": "Make a folder in your Google Drive (top level)",
                "drive.move": "Move a file in your Google Drive",
                "drive.rename": "Rename a file or folder in your Google Drive",
                "drive.copy": "Copy a file in your Google Drive",
                "docs.create": "Make a new Google Doc (top level of your Drive)",
                "docs.append": "Add text to the end of a Google Doc",
                "sheets.create": "Make a new Google Sheet (top level of your Drive)",
                "sheets.append": "Add rows to a Google Sheet",
                "gmail.archive": "Archive an email in Gmail (it leaves the inbox; nothing is deleted)",
                "gmail.unarchive": "Move an email back to your Gmail inbox",
                "gmail.mark_read": "Mark an email as read in Gmail",
                "gmail.mark_unread": "Mark an email as unread in Gmail"}


def rows_for(kind: str, tool: str, args: Any, what: str, task_id: str = "") -> list:
    rows = _rows_for(kind, tool, args, what, task_id)
    t, a = _unwrap((tool or "").strip(), args if isinstance(args, dict) else {})
    if kind == "email.send" and (t.lower().startswith("mcp__google__") or t == "qosha_google_change"):
        # Gmail's send tool: its own rows, then every value it is given (from_name, body_format ...) (1.20.8 round 2)
        # the values the email rows already show, by their key (never by an equal value under another key)
        shown = {"to": "To", "cc": "Cc", "bcc": "Bcc", "subject": "Subject", "body": "Body", "thread_id": "In thread",
                 "in_reply_to": "Replying to message"}
        labels = {lab for lab, _v in rows}
        rows = rows + _arg_rows("Google tool", t, {k: v for k, v in a.items() if shown.get(k) not in labels})
    return rows


def _shown_value(v: Any) -> str:
    """An argument as the card shows it: text as is, unless it has a control character the card would lose (a carriage
    return, a tab ...): then written out with escapes, so two different values never look the same (1.20.8 round 3)."""
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False) if re.search(r"[\x00-\x09\x0b-\x1f\x7f\u2028\u2029]", v) else v
    return json.dumps(v, ensure_ascii=False, sort_keys=True, default=str)


def _arg_rows(label: str, tool: str, a: Dict[str, Any], skip: tuple = ()) -> list:
    out = [(label, tool.rsplit("__", 1)[-1].replace("_", " "))]
    for k, v in a.items():
        if k == "_qosha_account":
            continue                           # Qosha's own note for the card (the account row), not an argument
        val = _shown_value(v)
        if val in skip:
            continue                           # already on the card as it is
        out.append((str(k).replace("_", " ").capitalize(), _text(val, 10 ** 9)))
    return out


def _rows_for(kind: str, tool: str, args: Any, what: str, task_id: str = "") -> list:
    """What the person sees on the card, as labelled rows (like the cloud Decision card): [(label, value), ...].
    Plain words only (Ren, 17 Nov): never a command line, code, a flag or a script."""
    tool, a = _unwrap((tool or "").strip(), args if isinstance(args, dict) else {})
    if tool == "outlook_send" and kind == "email.send":
        return _outlook_rows(a)
    if tool == "dropbox_organize" and kind == "dropbox.change":
        _dbx_rows = _sibling("dropbox_organize").card_rows
        return _dbx_rows(a)
    if tool == "whatsapp_reply" and kind == "whatsapp.send":
        return [("App", "WhatsApp"), ("To", _wa_chat_label(str(a.get("chat") or ""))), ("Message", str(a.get("text") or ""))]
    if _connector(tool)[0]:
        crow = connector_rows(kind, tool, a)       # an error here reaches pre_tool_call, which refuses the step
    else:
        crow = None
    if crow is not None:
        return crow or [("What happens", _not_understood(kind, tool))]
    cmd = str(a.get("command") or a.get("code") or "")
    f = _flag_args(cmd) if tool in ("terminal", "execute_code") else {}
    g = lambda *ks: next((str(v) for v in ((a.get(k) if a.get(k) not in (None, "", [], {}) else f.get(k)) for k in ks) if v not in (None, "")), "")
    rows = []
    # an email or message is shown in full (every recipient, every file, the whole body): what is sent is what the
    # person saw (Renato, 19 Nov 2026); a card the page cannot show in full is refused in pre_tool_call (CARD_SHOWS)
    cap = 10 ** 9 if kind in ("email.send", "message.send") else 1500
    add = lambda k, v: rows.append((k, _text(v, cap))) if v not in (None, "", [], {}) else None
    def google_args():
        out = _arg_rows("Google tool", tool, a)
        base = tool.lower().rsplit("__", 1)[-1]
        if base == "manage_drive_access" and str(a.get("action") or "").lower() in ("grant", "grant_batch") \
                and not any(re.sub(r"[^a-z]", "", str(k).lower()) == "sendnotification" for k in a):
            out.append(("Email", _Own("Google emails the person about the share (the tool's default)", "ask.google.row.share_email")))
        return out
    if tool == "qosha_google_change":
        rows.append(("Google account", str(a.get("_qosha_account") or "") or _Own("(not connected)", "ask.google.row.not_connected")))
        said = _GDRIVE_SAYS.get(str(a.get("operation") or ""))
        if said:
            rows.append(("What happens", said))   # gap 6 (SPEC-G section 4): the plain line, then every argument
    if (tool.lower().startswith("mcp__google__") or tool == "qosha_google_change") and kind != "email.send":
        # a Google tool's card: the tool and every value it is given, in full (1.20.8; round 2: every kind)
        if kind == "calendar.change":
            ch = str(a.get("action") or "").lower()
            _ck = {"create": "add", "insert": "add", "update": "change", "patch": "change", "delete": "delete", "move": "move",
                   "rsvp": "answer", "respond": "answer"}.get(ch, "other")
            rows.append(("Change", _Own({"add": "Add an event", "change": "Change an event", "delete": "Delete an event",
                                         "move": "Move an event", "answer": "Answer an invitation"}.get(_ck, "Change your calendar"),
                                        "ask.cal." + _ck)))
        out = rows + google_args()
        if tool == "qosha_google_change" and str(a.get("operation") or "") in ("docs.append", "sheets.append"):
            out.append(("Note from Qosha", "Only files that nobody else can see: Qosha checks this before the change."))
        if tool == "qosha_google_change" and kind == "mail.tidy":
            out.append(("Note from Qosha", "Google's page asks to read, compose and send email; Qosha only archives "
                                           "and marks emails read or unread with this."))
        return out
    if kind == "browser.profile":
        return [("What happens", "Qosha's browser would use a copy of your own Chrome profile, where you are signed in "
                                 "to your accounts (Gmail, banks, everything). Websites would see it as you.")] + \
            _arg_rows("Step", tool, a)
    if kind in ("email.send", "message.send"):
        add("To", g("to", "target", "recipient", "recipients") or
            (g("channel", "channel_id", "channel_name", "conversation_id", "chat_id", "user_id", "space_id") if kind == "message.send" else ""))
        base = tool.lower().rsplit("__", 1)[-1]
        fwd = a.get("forward_message_id") or (a.get("message_id") if "forward" in tool.lower() else None)
        # Gmail's own send tool takes the forward path alone when it forwards: no thread, no reply, no reply all
        # (workspace_mcp send_gmail_message: "Threading, reply, and signature options do not apply when forwarding")
        gmail_fwd = kind == "email.send" and base == "send_gmail_message" and bool(fwd)
        engine_send = kind == "message.send" and _engine_send(tool, a)
        if engine_send:
            # the engine's own tool reads only `target` and `message` (gateway/outbound/send.py): the card shows those two
            # and nothing else the step carries (GPT allowc r1 #1: a `to` or `attachments` it does not use was shown)
            del rows[:]
            add("To", a.get("target") if isinstance(a.get("target"), str) else "")
            if isinstance(a.get("message"), str):
                add("Body", a["message"])
            elif a.get("message") is not None:
                rows.append(("Body", _NOT_TEXT))
            rows.extend(_chat_where(tool, a)[0])
            return rows
        if kind == "message.send":
            rows.extend(_chat_where(tool, a)[0])   # a thread, the whole channel, one person, an edit (Ren, 20 Nov)
        add("Cc", g("cc")); add("Bcc", g("bcc"))
        add("From", g("from", "from_email"))
        add("Subject", g("subject"))
        if tool in ("terminal", "execute_code", "process", "process_manage"):
            # a send from a command or code is refused in pre_tool_call (_unseen); no text is ever assumed for it
            add("Body", g("body", "message", "text", "html_body"))
        else:
            # every text the tool is given is shown, each under its own label (GPT/Gemini vqa/r11913e: html_body was
            # hidden when body was given too); text that is not plain text is marked and refused (_unseen)
            plain = 0
            for bk in _BODY_KEYS:
                bv = a.get(bk)
                if bv is None:
                    continue
                if not isinstance(bv, str):
                    rows.append(("Body", _NOT_TEXT))
                elif bv != "":
                    lab = "HTML body" if bk in ("html_body", "html", "body_html") else ("Body" if not plain else "Body (%s)" % bk)
                    plain += lab != "HTML body"
                    add(lab, bv)
            if kind == "message.send" and a.get("attachments") not in (None, "", [], {}):
                rows.append(("Body", _NOT_TEXT))   # legacy attachments: the card cannot show what the chat would show
            if kind == "message.send" and a.get("blocks") not in (None, "", [], {}):
                # blocks made only of text are shown as the chat would show them, in order; anything else (a button, an
                # image, a field list) is not text the card can show (Ren, 20 Nov: "ask me instead" where Qosha can show it)
                shown = _blocks_text(a.get("blocks"))
                if not shown or not shown.strip():
                    rows.append(("Body", _NOT_TEXT))
                else:
                    add("Body (as blocks)", shown)
                    if texts_given(a):
                        add("Note from Qosha", "The chat shows the blocks; the Body above is the text used in notifications "
                                               "and where blocks can't be shown.")
            texts = [lab for lab, _v in rows if lab.startswith("Body") or lab == "HTML body"]
            if kind == "email.send" and not texts and (any(lab in ("To", "Cc", "Bcc") for lab, _v in rows) or fwd or _truthy(a.get("reply_all"))):
                rows.append(("Body", NO_TEXT))   # no text given: an empty email (or a forward with no note), shown as such
            # what Gmail itself adds after the card (GPT vqa/r11913e rshw3 HIGH 1): said on the card
            adds = []
            if fwd:
                keep = str(a.get("include_forwarded_attachments")).strip().lower() not in ("false", "0", "no", "off")
                adds.append(("Forwards the original email and its attachments" if keep else
                             "Forwards the original email, without its attachments") + " (message %s)" % fwd)
            if gmail_fwd and (a.get("thread_id") or a.get("in_reply_to") or _truthy(a.get("reply_all")) or _truthy(a.get("quote_original"))):
                # what Gmail's send tool really does with a forward that also carries reply fields: the forward only
                left = [x for x in ("thread %s" % a.get("thread_id") if a.get("thread_id") else "",
                                    "reply to message %s" % a.get("in_reply_to") if a.get("in_reply_to") else "",
                                    "reply all" if _truthy(a.get("reply_all")) else "",
                                    "quote the original" if _truthy(a.get("quote_original")) else "") if x]
                adds.append("It goes as a new email that forwards message %s. Gmail's send tool does not use these reply "
                            "settings when it forwards: %s." % (fwd, ", ".join(left)))
            if _truthy(a.get("reply_all")) and not gmail_fwd:
                # no claim about who exactly (GPT vqa/r11913g r5 #2: which of the original To/Cc are kept depends on the
                # other fields); the addresses are not known here
                adds.append("Reply all: Gmail may also send it to the original email's Reply-To address and to other people "
                            "on the original email; they are not listed here.")
            if _truthy(a.get("quote_original")) and a.get("thread_id") and not gmail_fwd:
                adds.append("The email it answers is quoted below the text")
            if kind == "email.send" and base == "send_gmail_message" and not fwd and a.get("include_signature") is False:
                adds.append("Your Gmail signature is not added")
            add("Gmail adds", "\n".join(adds))
        # both, when both are given: the thread, and the message in it that this answers (GPT vqa/r11913f rshw4 HIGH 5)
        if not gmail_fwd and kind == "email.send":
            add("In thread", g("thread_id"))
        if not gmail_fwd:
            add("Replying to message", g("in_reply_to") or ("" if "forward" in tool.lower() else g("message_id")))
        add("Attachments", g("attachments", "attach"))
        if not rows:
            add("What happens", tr("ask.value.no_recipient_email") if kind == "email.send" else tr("ask.value.no_recipient_message"))
    elif kind == "calendar.change":
        ch = (g("action") or (re.search(r"calendar\s+(?:events\s+)?\+?(\w+)", cmd) or [0, ""])[1]).lower()
        add("Change", tr({"create": "ask.cal.add", "insert": "ask.cal.add", "add": "ask.cal.add", "quick_add": "ask.cal.add",
                          "update": "ask.cal.change", "patch": "ask.cal.change", "move": "ask.cal.move",
                          "delete": "ask.cal.delete", "rsvp": "ask.cal.answer", "respond": "ask.cal.answer"}.get(ch, "ask.cal.other")))
        add("Event", g("summary", "title", "event_id"))
        add("Answer", g("response", "rsvp"))
        _st, _en = g("start", "start_time"), g("end", "end_time")
        add("When", tr("ask.when_range", start=_st, end=_en) if _st and _en else (_st or _en))
        add("Where", g("location"))
        add("Guests", g("attendees"))
        add("Calendar", g("calendar_id", "calendar"))
    elif kind in ("delete", "share", "pay"):
        steps, gone, notes = plain_acts(kind, tool, a, task_id)
        if not steps:
            steps = [_not_understood(kind, tool)]
        if len(steps) > 1:
            add("Steps", "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(steps[:12])))
        else:
            add("What happens", steps[0])
        add("Already gone", ", ".join(gone[:12]) + (" and %d more" % (len(gone) - 12) if len(gone) > 12 else ""))
        add("Note from Qosha", " ".join(notes))
    elif kind == "ai.paid":
        from .paid_ai import NOTE
        add("What happens", what)
        add("Note from Qosha", NOTE)
    elif kind in ("web.act", "web.post"):
        # plain words only (Ren, 17 Nov): the person never sees the browser code, a selector or a command
        site, steps, note, _final = web_plain(cmd or what, kind)
        add("Website", site)
        add("Note from Qosha", note)
        add("Steps" if len(steps) > 1 else "What happens", "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(steps)) if len(steps) > 1 else steps[0])
    if not rows:
        add("What happens", _not_understood(kind, tool))
    return rows   # the command or code itself is never added (Ren, 17 Nov)


# ---- delete / share / pay in plain words (Ren, 17 Nov: the card says what will happen; a command is never shown) ----
# Seen on Ren's Mac: a delete card showed `rm "/Users/.../Qosha-Setup.exe"`, a share card a long script. Each step is
# now read like the person would say it: what, which file or folder (by name) and where. What cannot be read is said
# so plainly ("Qosha could not ..."), and the person is still asked. Nothing here runs anything; files are only looked at.
_ZERO_DEC = {"bif", "clp", "djf", "gnf", "jpy", "kmf", "krw", "mga", "pyg", "rwf", "ugx", "vnd", "vuv", "xaf", "xof", "xpf"}
_ROLE = {"reader": "can view", "viewer": "can view", "commenter": "can comment", "writer": "can edit", "editor": "can edit",
         "fileorganizer": "can organize", "organizer": "can organize", "owner": "as the new owner"}
_KNOWN_DIRS = {"downloads": "in Downloads", "desktop": "on the Desktop", "documents": "in Documents", "pictures": "in Pictures",
               "movies": "in Movies", "videos": "in Videos", "music": "in Music", "onedrive": "in OneDrive"}
_SCRATCH = {"cache", "tmp", "temp", "scratch", "sandboxes", "audio_cache", "image_cache", "pending", "attachments", "composer-pastes"}
_DEL_CMDS = {"rm", "unlink", "del", "erase", "remove-item", "ri", "rd", "rmdir", "shred", "trash", "srm"}


def _homes() -> Tuple[str, str]:
    import os
    home = os.path.expanduser("~")
    try:
        from hermes_constants import get_hermes_home
        qh = str(get_hermes_home())
    except Exception:
        qh = os.environ.get("HERMES_HOME") or ""
    return home, qh


def _real(p: str) -> str:
    import os
    try:
        return os.path.normcase(os.path.realpath(p))
    except Exception:
        return os.path.normcase(os.path.abspath(p))


def _under(p: str, root: str) -> bool:
    import os
    if not root:
        return False
    rp, rr = _real(p), _real(root)
    return rp == rr or rp.startswith(rr.rstrip(os.sep) + os.sep)


_OWN_PHRASES = ("your files", "this project", "your home folder", "qosha's own folder", "qosha's scratch folder",
                "downloads", "desktop", "documents", "pictures", "movies", "videos", "music", "onedrive")


def _literal_name(folder: str) -> str:
    """A folder's own name; when it reads like one of Qosha's own phrases ("Your files" ...), in quotes with where it is,
    so the person can tell it from Qosha's own folder (r1210; pt-BR ptb8 H7-5)."""
    import os
    name = os.path.basename(folder.rstrip("/\\")) or folder
    if name.strip().lower() in _OWN_PHRASES:
        home, _qh = _homes()
        shown = folder.rstrip("/\\")
        if home and _under(shown, home):         # where it really is (a link is followed), from the home folder
            rel = os.path.relpath(os.path.realpath(shown), os.path.realpath(home))
            shown = "~" if rel == "." else "~" + os.sep + rel
        return '"%s" (%s)' % (name, shown)
    return name


def _label(folder: str) -> str:
    """A folder as the person knows it: "Downloads", "Your files", "your home folder", or its own name."""
    import os
    home, qh = _homes()
    if qh and _real(folder) == _real(os.path.join(qh, "files")):
        return "Your files"
    if _real(folder) == _real(home):
        return "your home folder"
    if _under(folder, home) and _real(os.path.dirname(folder.rstrip("/\\"))) == _real(home) and os.path.basename(folder.rstrip("/\\")).lower() in _KNOWN_DIRS:
        return os.path.basename(folder.rstrip("/\\"))
    return _literal_name(folder)


def _where(path: str) -> str:
    """Where a file or folder lies, in a few words: "in Downloads", "in Qosha's scratch folder", ..."""
    import os
    import tempfile
    parent = os.path.dirname(path.rstrip("/\\")) or path
    home, qh = _homes()
    if qh and _under(parent, qh):
        rel = os.path.relpath(_real(parent), _real(qh))
        top = rel.split(os.sep)[0].lower() if rel != "." else ""
        if top == "files":
            return "in Your files" if rel == "files" else "in the folder %s (in Your files)" % _literal_name(parent)
        return "in Qosha's scratch folder" if top in _SCRATCH else "in Qosha's own folder"
    if _under(parent, home):
        rel = os.path.relpath(_real(parent), _real(home))
        if rel == ".":
            return "in your home folder"
        parts = rel.split(os.sep)
        top = parts[0].lower()
        if top in _KNOWN_DIRS:
            return _KNOWN_DIRS[top] if len(parts) == 1 else "in the folder %s (%s)" % (_literal_name(parent), _KNOWN_DIRS[top])
        return "in the folder %s (in your home folder)" % _literal_name(parent)
    if any(_under(parent, t) for t in {tempfile.gettempdir(), "/tmp", "/var/tmp", "/private/tmp"}):
        return "in the computer's temporary folder"
    return ("in the folder %s" % _literal_name(parent)) if _literal_name(parent) else "at the top of the disk"


def _count_files(folder: str, cap: int = 5000) -> int:
    import os
    n = 0
    for _r, _d, fs in os.walk(folder):
        n += len(fs)
        if n > cap:
            break
    return n


def _expand(t: str, cwd: str) -> Tuple[Optional[str], str]:
    """(full path or None when it cannot be known before the step runs, why). Only the home and temp folder names are
    filled in; any other $NAME, %NAME% or `...` is only known when the step runs."""
    import os
    import tempfile
    home = os.path.expanduser("~")
    s = t
    s = re.sub(r"^~(?=$|[/\\])", lambda m: home, s)
    s = re.sub(r"\$\{?HOME\}?|%USERPROFILE%|\$env:(USERPROFILE|HOME)", lambda m: home, s, flags=re.I)
    s = re.sub(r"\$\{?TMPDIR\}?|%TEMP%|%TMP%|\$env:(TEMP|TMP)", lambda m: tempfile.gettempdir(), s, flags=re.I)
    if re.search(r"[$`]|%\w+%", s):
        return None, "unknown"
    if re.match(r"^[A-Za-z]:[\\/]", s) and os.name != "nt":
        return None, "windows"          # a Windows path seen on a Mac: its name is known, the file cannot be looked at
    if not os.path.isabs(s):
        if not cwd:
            return None, "relative"
        s = os.path.join(cwd, s)
    return os.path.normpath(s), ""


def _cwd(a: Dict[str, Any], task_id: str = "") -> str:
    """The folder a shell step runs in, as the engine picks it (its workdir, the session's folder, its setting)."""
    import os
    w = str(a.get("workdir") or a.get("cwd") or "")
    if w:
        p, _why = _expand(w, "")
        if p:
            return p
    try:
        from tools.terminal_tool import get_session_cwd, resolve_task_overrides
        for c in ((resolve_task_overrides(task_id) or {}).get("cwd") if task_id else None, get_session_cwd(task_id) if task_id else None):
            if c and os.path.isabs(str(c)):
                return str(c)
    except Exception:
        pass
    try:
        from hermes_cli.config import load_config
        c = str(((load_config() or {}).get("terminal") or {}).get("cwd") or "")
        if c and os.path.isabs(c) and os.path.isdir(c):
            return c
    except Exception:
        pass
    return ""


def _segments(cmd: str, posix: bool = False) -> Optional[list]:
    """The simple commands of a shell text, as word lists, in order (quotes respected). None if it cannot be read."""
    import os
    import shlex
    win = not posix and (os.name == "nt" or bool(re.search(r"(?<![\w$])[A-Za-z]:\\", cmd)))
    text, out_q, i = [], None, 0
    while i < len(cmd):            # line breaks outside quotes end a command, like ;
        c = cmd[i]
        if c == "\\" and not win and out_q != "'" and i + 1 < len(cmd):   # r1205 #6: literal inside '...'
            text.append(" " if cmd[i + 1] == "\n" else c + cmd[i + 1])
            i += 2
            continue
        if out_q:
            out_q = None if c == out_q else out_q
        elif c in "'\"":
            out_q = c
        elif c == "\n":
            c = " ; "
        elif c == "#" and (not text or text[-1] in (" ", "\t", ";", " ; ")):   # not after an escaped one (r1205)
            j = cmd.find("\n", i)       # a comment: to the end of the line
            i = len(cmd) if j < 0 else j
            continue
        text.append(c)
        i += 1
    try:
        lex = shlex.shlex("".join(text), posix=not win, punctuation_chars=";&|")
        lex.whitespace_split = True
        lex.commenters = ""
        toks = list(lex)
    except ValueError:
        return None
    if win:     # cmd and PowerShell join a word with a quoted part in the middle (C:/x/"Your files"): so do we (r1210 r2)
        merged, acc = [], None
        for t in toks:
            if acc is not None:
                acc += " " + t
                if t.count('"') % 2:
                    merged.append(acc)
                    acc = None
                continue
            if t.count('"') % 2 and not (set(t) <= set(";&|")):
                acc = t
                continue
            merged.append(t)
        if acc is not None:
            return None                      # a quote never closed: cannot be read
        toks = [x.replace('"', "") if '"' in x[1:-1] and not (x[0] == x[-1] == '"' and x.count('"') == 2) else x
                for x in merged]
    segs, cur = [], []
    for t in toks:
        if t and set(t) <= set(";&|"):
            if cur:
                segs.append((cur, t))
            cur = []
            continue
        if win and len(t) >= 2 and t[0] == t[-1] and t[0] in "'\"":
            t = t[1:-1]
        cur.append(t)
    if cur:
        segs.append((cur, ""))
    # the separator BEFORE each command matters for "xargs" (its names come from the command before the pipe)
    return [(w, (segs[k - 1][1] if k else "")) for k, (w, _sep) in enumerate(segs)]


def _strip_prefix(w: list) -> Tuple[list, bool]:
    """sudo / env / nohup / time / VAR=value in front of a command are not the command; xargs reads its names from the
    command before it."""
    xargs = False
    while w:
        h = w[0].lower()
        if h in ("sudo", "nohup", "time", "command", "exec", "builtin", "nice"):
            w = w[1:]
            while w and w[0].startswith("-"):
                w = w[1:]
        elif h == "env" or re.fullmatch(r"[A-Za-z_]\w*=.*", w[0]):
            w = w[1:]
            while w and (re.fullmatch(r"[A-Za-z_]\w*=.*", w[0]) or w[0].startswith("-")):
                w = w[1:]
        elif h == "xargs":
            xargs = True
            w = w[1:]
            while w and w[0].startswith("-"):
                w = w[1:]
        else:
            break
    return w, xargs


def _item(t: str, cwd: str) -> Dict[str, Any]:
    """One named target: its name, where it is, whether it is there (True/False/None = cannot tell) and a folder."""
    import ntpath
    import os
    p, why = _expand(t, cwd)
    if p is None:
        name = ntpath.basename(t.rstrip("/\\")) if why == "windows" else os.path.basename(t.rstrip("/\\"))
        where = ""
        if why == "windows":
            par = ntpath.basename(ntpath.dirname(t.rstrip("/\\")))
            where = "in the folder %s" % par if par else ""
        elif why == "relative":
            where = "in the folder Qosha is working in"
        return {"name": name, "where": where, "exists": None, "dir": None, "unknown": why == "unknown", "path": ""}
    there = os.path.lexists(p)
    return {"name": _literal_name(p) if p.rstrip("/\\") else p, "where": _where(p), "exists": there,
            "dir": os.path.isdir(p) if there else None, "unknown": False, "path": p}


def _thing_word(it: Dict[str, Any]) -> str:
    if it["dir"]:
        return "folder"
    if it["dir"] is False:
        return "file"
    return "file" if re.search(r"\.\w{1,8}$", it["name"]) else "item"


def _names(items: list, n: int = 6) -> str:
    names = [i["name"] for i in items]
    return ", ".join(names[:n]) + (" and %d more" % (len(names) - n) if len(names) > n else "")


def _delete_sentences(verb: str, items: list, recursive: bool) -> list:
    """Sentences for one delete command's targets (items that are there, or that cannot be checked)."""
    out = []
    files = [i for i in items if _thing_word(i) == "file"]
    same_where = len({i["where"] for i in items}) == 1
    if len(items) > 1 and len(files) == len(items) and same_where and verb in ("delete", "trash"):
        w = items[0]["where"]
        if verb == "trash":
            return ["Move %d files %s to the Trash: %s" % (len(items), w, _names(items))]
        return ["Delete %d files %s: %s" % (len(items), w, _names(items))]
    import os
    home, qh = _homes()
    for i in items:
        kindw, where = _thing_word(i), i["where"]
        if i["path"] and i["exists"]:
            special = ("everything on the computer's disk" if os.path.dirname(i["path"].rstrip("/\\") or i["path"]) == (i["path"].rstrip("/\\") or i["path"]) or _real(i["path"]) in ("/", _real("/")) else
                       "your whole home folder" if _real(i["path"]) == _real(home) else
                       "Qosha's whole home folder (its chats, settings and sign-ins)" if qh and _real(i["path"]) == _real(qh) else "")
            if special:
                out.append(("Move %s to the Trash" if verb == "trash" else "Delete %s") % special)
                continue
        par = " (%s)" % where if where else ""
        if verb == "trash":
            out.append("Move the %s %s%s to the Trash" % (kindw, i["name"], par))
        elif verb == "shred":
            out.append("Destroy the file %s%s so it cannot be recovered" % (i["name"], par))
        elif kindw == "folder" and verb == "rmdir":
            out.append("Delete the empty folder %s%s" % (i["name"], par))
        elif kindw == "folder" and (recursive or verb == "tree"):
            n = _count_files(i["path"]) if i["path"] and i["exists"] else -1
            size = "" if n < 0 else ("it is empty, " if n == 0 else ("more than 5000 files, " if n > 5000 else "%d file%s, " % (n, "" if n == 1 else "s")))
            out.append("Delete the folder %s and everything in it (%s%s)" % (i["name"], size, where) if where or size else
                       "Delete the folder %s and everything in it" % i["name"])
        else:
            out.append("Delete the %s %s%s" % (kindw, i["name"], par))
    return out


def _seg_delete(w: list, xargs: bool, cwd: str, trust: bool = True) -> Optional[Tuple[list, list, bool]]:
    """(sentences, names already gone, could not check something) for a delete command; None if it is not one.
    trust=False: an earlier part of the same step may create or move things, so "not there now" proves nothing: such
    names are asked about like any other."""
    import glob
    import os
    head = w[0].lower() if w else ""
    head = head[:-4] if head.endswith(".exe") else head
    if head not in _DEL_CMDS:
        return None
    win_style = head in ("del", "erase", "rd") or os.name == "nt"
    recursive, targets, value_next, after_dd = False, [], None, False
    verb = {"shred": "shred", "srm": "shred", "trash": "trash", "rmdir": "rmdir", "rd": "rmdir"}.get(head, "delete")
    for t in w[1:]:
        if re.fullmatch(r"\d*[<>]{1,2}&?", t):      # a redirection: the next word is where output goes, not a target
            value_next = "redirect"
            continue
        if re.match(r"\d*[<>]", t):
            continue
        if value_next:
            if value_next in ("-path", "-literalpath"):
                targets.append(t)
            value_next = None
            continue
        low = t.lower()
        if not after_dd and t == "--":
            after_dd = True
            continue
        if not after_dd and low in ("-path", "-literalpath", "-include", "-exclude", "-filter"):
            value_next = low
            continue
        if not after_dd and win_style and re.fullmatch(r"/[a-z]", low):
            recursive = recursive or low == "/s"
            continue
        if not after_dd and t.startswith("-") and len(t) > 1:
            # rm -r / -rf / -R / --recursive; PowerShell -Recurse (and its short forms). -Force is not recursive.
            if low in ("--recursive", "-recurse", "-recurs", "-recur", "-recu", "-rec") or (head in ("rm", "srm") and re.fullmatch(r"-[a-z]{1,4}", low) and "r" in low):
                recursive = True
            continue
        targets.append(t)
    if recursive and verb == "rmdir":
        verb = "tree"
    if xargs:
        return ["Delete files listed by an earlier part of the step (Qosha could not list them in advance)"], [], True
    items, gone, unknown = [], [], False
    for t in targets:
        if re.search(r"[*?\[]", t):
            p, why = _expand(t, cwd)
            if p is None:
                unknown = True
                continue
            hits = sorted(glob.glob(p))
            if not hits and trust:
                gone.append(os.path.basename(p))
            elif not hits:
                items.append({"name": os.path.basename(p), "where": _where(p), "exists": None, "dir": None, "unknown": False, "path": ""})
            items += [_item(h, "") for h in hits]
            continue
        it = _item(t, cwd)
        if it["unknown"]:
            unknown = True
        elif it["exists"] is False and trust:
            gone.append(it["name"])
        else:
            if it["exists"] is False:
                it.update(exists=None, dir=None, path="")
            items.append(it)
    out = _delete_sentences(verb if verb != "tree" else "delete", items, recursive or verb == "tree")
    if unknown:
        out.append("Delete something whose name is only known when the step runs (Qosha could not check it)")
    if not targets and not xargs:
        out.append("Delete something on this computer (Qosha could not tell what)")
        unknown = True
    cannot_check = unknown or any(i["exists"] is None for i in items)
    return out, gone, cannot_check


def _gapi(w: list) -> Optional[Tuple[str, list, Dict[str, str], list]]:
    """The Google skill's script: (service, action words, --flags, plain words after the action)."""
    for k, t in enumerate(w):
        if t.endswith("google_api.py") or t in ("$GAPI", "${GAPI}"):
            rest = w[k + 1:]
            if len(rest) < 2:
                return None
            flags = _flag_args(" ".join(_q(x) for x in rest))
            pos, skip = [], False
            for x in rest[2:]:
                if skip:
                    skip = False
                    continue
                if x.startswith("--"):
                    skip = "=" not in x
                    continue
                pos.append(x)
            return rest[0].lower(), [rest[1].lower()], flags, pos
    return None


def _q(s: str) -> str:
    import shlex
    return shlex.quote(s)


def _gh_thing(noun: str, arg: str, host: str) -> str:
    names = {"release": "the release %s", "gist": "the gist %s", "issue": "issue %s", "label": "the label %s",
             "secret": "the secret %s", "variable": "the setting %s", "run": "the workflow run %s", "cache": "the saved cache %s",
             "ssh-key": "the key %s", "gpg-key": "the key %s", "codespace": "the codespace %s", "project": "the project %s",
             "ruleset": "the rule set %s", "environment": "the environment %s", "snippet": "the snippet %s", "mr": "merge request %s",
             "deploy-key": "the key %s"}
    return (names.get(noun, "the " + noun.replace("-", " ") + " %s") % arg).strip() + " on " + host


def _money(amount: str, currency: str) -> str:
    cur = (currency or "").lower()
    try:
        n = int(str(amount).strip())
    except ValueError:
        return ""
    if cur in _ZERO_DEC:
        return "%d %s" % (n, cur.upper())
    v = "%d.%02d" % (n // 100, n % 100)
    return "%s %s" % (v, cur.upper()) if cur else "%s in the account's currency" % v


def _stripe(obj: str, data: Dict[str, str]) -> str:
    obj = obj.lower().replace("-", "_")
    amt = _money(data.get("amount", ""), data.get("currency", "")) if data.get("amount") else ""
    who = data.get("destination") or data.get("customer") or data.get("receipt_email") or ""
    if obj.startswith("transfer"):
        return ("Send %s to %s (Stripe)" % (amt, who) if who else "Send %s (Stripe)" % amt) if amt else "Send money through Stripe (Qosha could not tell the amount or who gets it)"
    if obj.startswith("refund"):
        return "Refund %s (Stripe)" % amt if amt else "Make a refund through Stripe (Qosha could not tell the amount)"
    if obj.startswith("payout"):
        return "Pay out %s to the bank account (Stripe)" % amt if amt else "Make a payout through Stripe (Qosha could not tell the amount or who gets it)"
    if obj.startswith("charge") or obj.startswith("payment_intent"):
        return ("Charge %s to %s (Stripe)" % (amt, who) if who else "Charge %s (Stripe)" % amt) if amt else "Take a payment through Stripe (Qosha could not tell the amount or from whom)"
    return "Make a payment through Stripe (Qosha could not tell the amount or who gets it)"


def _curl_parts(w: list) -> Tuple[str, Dict[str, str], str]:
    """(address, form fields, raw body) of a curl command."""
    url, data, raw, nxt = "", {}, "", None
    for t in w[1:]:
        if nxt:
            if nxt == "data":
                if t.lstrip().startswith("{"):
                    raw += t
                else:
                    for kv in t.split("&"):
                        if "=" in kv:
                            k, v = kv.split("=", 1)
                            data[k.strip()] = v.strip()
            nxt = None
            continue
        if t in ("-d", "--data", "--data-raw", "--data-urlencode", "--data-binary", "-F", "--form"):
            nxt = "data"
        elif t.startswith("-") and t in ("-u", "-H", "-X", "--user", "--header", "--request", "-o", "--output", "-A", "-e"):
            nxt = "skip"
        elif re.match(r"https?://", t) and not url:
            url = t
    return url, data, raw


def _paypal(raw: str) -> str:
    try:
        body = json.loads(raw)
    except Exception:
        body = None
    amt, who = "", ""

    def walk(x):
        nonlocal amt, who
        if isinstance(x, dict):
            if "value" in x and "currency_code" in x and not amt:
                amt = "%s %s" % (x["value"], str(x["currency_code"]).upper())
            for k in ("email_address", "receiver", "email"):
                if isinstance(x.get(k), str) and not who:
                    who = x[k]
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
    walk(body)
    if amt:
        return "Pay %s to %s (PayPal)" % (amt, who) if who else "Pay %s (PayPal)" % amt
    return "Make a payment through PayPal (Qosha could not tell the amount or who gets it)"


def _shell_acts(cmd: str, cwd: str, trust: bool = True) -> Tuple[list, list, bool, bool]:
    """(acts as (kind, sentence), names already gone, something could not be checked, every command is a delete or a
    change of folder) for a shell text. Commands that only read or prepare are left out: the card is about what acts."""
    import os
    segs = _segments(cmd, posix=_mentions_google(cmd))   # a Google step: the same bash reading as google_verdict
    if segs is None:
        return [], [], True, False
    acts, gone, unknown, only_del = [], [], False, trust
    for words, sep in segs:
        w, xargs = _strip_prefix(list(words))
        # (xargs: its names come from elsewhere; never checked)
        if not w:
            continue
        h = w[0].lower()
        if h in ("bash", "sh", "zsh") and len(w) >= 3 and w[1] == "-c":
            a2, g2, u2, o2 = _shell_acts(w[2], cwd, only_del)
            acts += a2
            gone += g2
            unknown = unknown or u2
            only_del = only_del and o2
            continue
        if h in ("cd", "pushd", "set-location", "sl", "chdir"):
            dest = next((x for x in w[1:] if not re.fullmatch(r"/d|-\w+", x, re.I)), "~")
            p, _why = _expand(dest, cwd)
            cwd = p if p else ""
            continue
        d = _seg_delete(w, xargs, cwd, trust=only_del)
        if d is not None:
            acts += [("delete", s) for s in d[0]]
            gone += d[1]
            unknown = unknown or d[2]
            continue
        only_del = False
        g = _gapi(w)
        if g:
            svc, (act,), fl, pos = g
            if svc == "drive" and act == "delete":
                acts.append(("delete", "Delete a file in your Google Drive for good" if "permanent" in fl else "Move a file in your Google Drive to its trash"))
            elif svc == "drive" and act == "upload":
                it = _item(pos[0], cwd) if pos else None
                where = (" (%s)" % it["where"]) if it and it["where"] else ""
                name = it["name"] if it else "a file"
                as_name = fl.get("name") if fl.get("name") and it and fl.get("name") != it["name"] else ""
                acts.append(("share", "Upload the file %s%s to your Google Drive%s" % (name, where, (" as %s" % as_name) if as_name else "") if it else "Upload a file to your Google Drive"))
            elif svc == "drive" and act == "share":
                typ = (fl.get("type") or "user").lower()
                who = {"anyone": "anyone who has the link", "domain": "everyone at %s" % fl.get("domain", "a domain")}.get(typ, fl.get("email") or "someone Qosha could not read")
                acts.append(("share", "Share a Google Drive file with %s (%s)" % (who, _ROLE.get((fl.get("role") or "reader").lower(), "access: " + fl.get("role", "")))))
            elif svc == "gmail" and act in ("send", "reply", "forward"):
                acts.append(("email.send", "Send an email%s%s" % ((" to " + fl["to"]) if fl.get("to") else "", (": “%s”" % _say(fl["subject"])) if fl.get("subject") else "")))
            elif svc == "calendar" and act in ("create", "update", "delete"):
                acts.append(("calendar.change", {"create": "Add the event", "update": "Change the event", "delete": "Delete an event"}[act] + ((" “%s”" % _say(fl["summary"])) if fl.get("summary") else "")))
            continue
        if h in ("gh", "glab") and len(w) >= 3:
            host = "GitHub" if h == "gh" else "GitLab"
            noun, verb = w[1].lower(), w[2].lower()
            fl = _flag_args(" ".join(_q(x) for x in w[3:]))
            pos = [x for x in w[3:] if not x.startswith("-")]
            arg = pos[0] if pos else ""
            title = fl.get("title") or fl.get("t") or ""
            if noun == "api":
                if re.search(r"(-X\s*|--method[\s=]+)DELETE\b", " ".join(w), re.I):
                    acts.append(("delete", "Delete something on %s (Qosha could not tell exactly what)" % host))
                continue
            if verb == "delete":
                if noun == "repo":
                    acts.append(("delete", ("Delete the %s repository %s and everything in it" % (host, arg)) if arg else "Delete this project's %s repository and everything in it" % host))
                else:
                    acts.append(("delete", "Delete " + _gh_thing(noun, arg, host)))
            elif noun in ("pr", "mr") and verb == "create":
                acts.append(("share", "Propose code changes on %s: “%s”" % (host, _say(title)) if title else "Propose code changes on %s (a pull request)" % host))
            elif noun == "issue" and verb == "create":
                acts.append(("share", "Post a new issue on %s: “%s”" % (host, _say(title)) if title else "Post a new issue on %s" % host))
            elif noun == "release" and verb == "create":
                acts.append(("share", "Publish the release %s on %s" % (arg, host) if arg else "Publish a release on %s" % host))
            elif noun == "repo" and verb == "create":
                vis = " (public: anyone can see it)" if "public" in fl else " (private)" if "private" in fl else ""
                acts.append(("share", ("Create the %s repository %s%s" % (host, arg, vis)) if arg else "Create a %s repository%s" % (host, vis)))
            elif noun == "gist" and verb == "create":
                acts.append(("share", "Publish a snippet on %s (%s)" % (host, "public: anyone can see it" if "public" in fl or "p" in fl else "anyone with the link can see it")))
            elif verb == "merge":
                acts.append(("share", "Merge the pull request %s on %s" % (arg, host) if arg else "Merge a pull request on %s" % host))
            elif verb == "comment":
                body = fl.get("body") or fl.get("b") or ""
                acts.append(("share", "Post a comment on %s: “%s”" % (host, _say(body)) if body else "Post a comment on %s" % host))
            elif verb == "edit":
                acts.append(("share", "Change %s %s on %s" % ({"pr": "the pull request", "issue": "issue", "release": "the release", "repo": "the repository settings of", "gist": "the gist"}.get(noun, "the " + noun), arg, host)))
            continue
        if h == "git":
            k, proj, gcwd = 1, _label(cwd) if cwd else "this project", cwd
            while k < len(w) and w[k].startswith("-"):
                o = w[k]
                if o.startswith("-C"):
                    d = o[2:] if len(o) > 2 else (w[k + 1] if k + 1 < len(w) else "")
                    p, _why = _expand(d, gcwd)          # each -C is taken from the previous one, as git does
                    proj = _label(p) if p else _literal_name(d)
                    gcwd = p if p else None
                    k += 1 if len(o) == 2 else 0
                elif o == "-c" or (o.startswith("--") and "=" not in o and o[2:] in (
                        "git-dir", "work-tree", "namespace", "super-prefix", "config-env", "attr-source")):
                    k += 1                              # its value is the next word, never the subcommand
                k += 1
            sub = w[k].lower() if k < len(w) else ""
            rest = w[k + 1:]
            if sub == "push":
                pos = [x for x in rest if not x.startswith("-")]
                dels = [x.lstrip("+:") for x in pos[1:] if x.lstrip("+").startswith(":")]
                if any(x in ("--delete", "-d") for x in rest):
                    dels += pos[1:]
                if dels:
                    acts.append(("delete", "Delete the branch%s %s from the online copy of %s" % ("es" if len(dels) > 1 else "", ", ".join(dels), proj)))
                else:
                    acts.append(("share", "Upload the saved code changes in %s to its online copy" % proj))
                    if any(x in ("--force", "-f", "--force-with-lease") or x.startswith("--force") or x.startswith("+") for x in rest):
                        acts.append(("note", "This replaces the online copy: changes there that are not on this computer will be lost."))
            elif sub == "clean":
                acts.append(("delete", "Delete the files in %s that are not part of its saved history" % proj))
            elif sub == "reset" and "--hard" in rest:
                acts.append(("delete", "Throw away the unsaved changes in %s (they cannot be brought back)" % proj))
            continue
        if h == "find" and "-delete" in w:
            roots = [x for x in w[1:] if not x.startswith("-") and not x.startswith("(")][:1] or ["."]
            p, _why = _expand(roots[0], cwd)
            acts.append(("delete", "Delete the files inside %s that a search picks (Qosha could not list them in advance)" % (_label(p) if p else _literal_name(roots[0]))))
            unknown = True
            continue
        if h == "npm" and len(w) > 1 and w[1] == "publish":
            acts.append(("share", "Publish this package on npm, where anyone can download it"))
            continue
        if h == "twine" and len(w) > 1 and w[1] == "upload":
            acts.append(("share", "Publish this package on PyPI, where anyone can download it"))
            continue
        if h == "stripe" and len(w) >= 3:
            fl = _flag_args(" ".join(_q(x) for x in w[3:]))
            acts.append(("pay", _stripe(w[1], fl)))
            continue
        if h == "curl" or h.startswith("invoke-"):
            url, data, raw = _curl_parts(w)
            m = re.match(r"https?://api\.stripe\.com/v\d+/([a-z_]+)", url)
            if m:
                acts.append(("pay", _stripe(m.group(1), data)))
            elif re.match(r"https?://api(-m)?\.(sandbox\.)?paypal\.com", url):
                acts.append(("pay", _paypal(raw)))
            continue
        if re.search(r"\b(drop\s+(table|database)|delete\s+from)\b", " ".join(w), re.I):
            db = next((os.path.basename(x) for x in w[1:] if re.search(r"\.(db|sqlite3?)$", x)), "")
            acts.append(("delete", "Delete data from the database %s" % db if db else "Delete data from a database (Qosha could not tell exactly which)"))
    return acts, gone, unknown, only_del


def _code_acts(code: str) -> Tuple[list, list, bool]:
    """Deletes in code the assistant runs: a name written in the code is looked at; anything else is said plainly."""
    acts, gone, unknown = [], [], False
    # "not there now" counts only when the code does nothing but delete (no line that could make or move a file first)
    trust = all(re.match(r"\s*($|#|import\s|from\s+\S+\s+import\s|(os\.(remove|unlink|rmdir|removedirs)|shutil\.rmtree|fs\.(rm|unlink|rmdir)(Sync)?|Path)\()", ln)
                for ln in code.split("\n"))
    lit = r"\s*(?:r|f)?(?P<q>['\"])(?P<name>[^'\"\n]+)(?P=q)\s*"
    found = False
    for m in re.finditer(r"\b(?P<fn>os\.(?:remove|unlink|rmdir|removedirs)|shutil\.rmtree|fs\.(?:rm|unlink|rmdir)(?:Sync)?)\((?:" + lit + r"[,)])?", code):
        found = True
        name = m.group("name")
        fn = m.group("fn")
        tree = fn == "shutil.rmtree" or fn in ("fs.rm", "fs.rmSync")
        if not name or "{" in name:
            unknown = True
            continue
        it = _item(name, "")
        if it["exists"] is False and trust:
            gone.append(it["name"])
            continue
        acts += [("delete", s) for s in _delete_sentences("delete", [it], tree)]
    for m in re.finditer(r"Path\(" + lit + r"\)\.(?P<m>unlink|rmdir)\(", code):
        found = True
        it = _item(m.group("name"), "")
        if it["exists"] is False and trust:
            gone.append(it["name"])
        else:
            acts += [("delete", s) for s in _delete_sentences("rmdir" if m.group("m") == "rmdir" else "delete", [it], False)]
    if re.search(r"\.unlink\(|\.rmdir\(\)", code) and not found:
        unknown = True
    if unknown or (not acts and not gone):
        acts.append(("delete", "Delete something on this computer whose name the code works out while it runs (Qosha could not check it)"))
        unknown = True
    return acts, gone, unknown


def _code_pay(code: str) -> list:
    m = re.search(r"stripe\.(Charge|PaymentIntent|Payout|Refund|Transfer)\.create\(([^)]*)\)", code)
    if m:
        data = {k: v for k, v in re.findall(r"(\w+)\s*=\s*['\"]?([\w.@-]+)", m.group(2))}
        return [("pay", _stripe({"PaymentIntent": "payment_intents"}.get(m.group(1), m.group(1).lower() + "s"), data))]
    if re.search(r"paypal\.com", code):
        return [("pay", "Make a payment through PayPal (Qosha could not tell the amount or who gets it)")]
    return [("pay", "Make a payment through Stripe (Qosha could not tell the amount or who gets it)")] if re.search(r"stripe", code, re.I) else []


def _service(tool: str) -> str:
    low = tool.lower()
    server = low.split("__")[1] if low.startswith("mcp__") and low.count("__") >= 2 else ""
    base = low.rsplit("__", 1)[-1]
    if server == "google" or re.search(r"drive|gmail|calendar|docs?_|sheet", base):
        for k, v in (("drive", "Google Drive"), ("gmail", "Gmail"), ("calendar", "Google Calendar"), ("doc", "Google Docs"),
                     ("sheet", "Google Sheets"), ("contact", "Google Contacts"), ("task", "Google Tasks"), ("form", "Google Forms"),
                     ("slide", "Google Slides")):
            if k in base:
                return v
        return "Google"
    return server.replace("_", " ").replace("-", " ").title() if server else ""


def _tool_acts(kind: str, tool: str, a: Dict[str, Any]) -> list:
    """Plain words for a connector's own tool (Google Drive, payment apps, ...), from its named arguments."""
    svc = _service(tool)
    base = tool.lower().rsplit("__", 1)[-1]
    get = lambda *ks: next((str(a[k]) for k in ks if a.get(k) not in (None, "", [], {})), "")
    in_svc = (" in %s" % svc) if svc else ""
    if kind == "share":
        act = get("action").lower()
        role = _ROLE.get(get("role").lower(), ("access: " + get("role")) if get("role") else "")
        typ = get("share_type", "type").lower()
        who = "anyone who has the link" if typ == "anyone" else ("everyone at %s" % get("share_with", "domain") if typ == "domain" else
                                                                 get("share_with", "email", "email_address", "user", "recipient"))
        if not who and isinstance(a.get("recipients"), list):
            who = ", ".join(str((r or {}).get("email") or (r or {}).get("email_address") or "") for r in a["recipients"] if isinstance(r, dict))
        what = ("the file %s" % get("file_name", "name", "title")) if get("file_name", "name", "title") else ("a %s file" % svc if svc else "a file")
        if act == "revoke":
            return ["Stop sharing %s with %s" % (what, who or "someone")]
        if act == "transfer_owner":
            return ["Make %s the owner of %s" % (get("new_owner_email") or who or "someone", what)]
        if act == "update":
            return ["Change what %s can do with %s%s" % (who or "someone", what, (" (%s)" % role) if role else "")]
        if re.search(r"upload|create", base):
            return ["Upload %s%s" % (("the file " + get("file_name", "name", "title")) if get("file_name", "name", "title") else "a file", (" to %s" % svc) if svc else "")]
        if who:
            return ["Share %s with %s%s" % (what, who, (" (%s)" % role) if role else "")]
        return ["Share or publish something%s (Qosha could not tell with whom)" % in_svc]
    if kind == "delete":
        name = get("file_name", "name", "title", "path", "summary", "subject")
        obj = re.sub(r"^(batch_)?(delete|remove|trash|destroy|purge|erase|manage)_?", "", base).replace("_", " ").strip() or "item"
        return [("Delete the %s %s%s" % (obj, name, in_svc)) if name else ("Delete a %s%s" % (obj, in_svc))]
    if kind == "pay":
        amt = get("amount", "total", "price", "value")
        who = get("to", "recipient", "payee", "email", "destination", "customer")
        cur = get("currency").upper()
        if amt:
            return ["Pay %s%s%s%s" % (amt, (" " + cur) if cur else "", (" to " + who) if who else "", (" (%s)" % svc) if svc else "")]
        return ["Make a payment%s (Qosha could not tell the amount or who gets it)" % ((" with " + svc) if svc else "")]
    return []


def plain_acts(kind: str, tool: str, a: Dict[str, Any], task_id: str = "") -> Tuple[list, list, list]:
    """(sentences, names already gone, notes) for a delete, share or pay card. The sentences cover every act of the
    step that would be asked about (a script that uploads and then shares shows both), in order."""
    import os
    if tool == "terminal":
        acts, gone, _u, _o = _shell_acts(str(a.get("command") or ""), _cwd(a, task_id))
    elif tool == "execute_code":
        code = str(a.get("code") or "")
        acts, gone = (_code_pay(code), []) if kind == "pay" else (_code_acts(code)[:2] if kind == "delete" else ([], []))
    elif tool == "patch":
        acts, gone = [], []
        cwd = _cwd(a, task_id)
        trust = not re.search(r"^\*\*\* (Add File|Move to):", str(a.get("patch") or ""), re.M)
        for m in re.finditer(r"^\*\*\* Delete File:\s*(.+?)\s*$", str(a.get("patch") or ""), re.M):
            it = _item(m.group(1), cwd)
            if it["exists"] is False and trust:
                gone.append(it["name"])
            else:
                acts += [("delete", s) for s in _delete_sentences("delete", [it], False)]
    else:
        acts, gone = [(kind, s) for s in _tool_acts(kind, tool, a)], []
    notes = [s for k, s in acts if k == "note"]
    steps = [s for k, s in acts if k in ("delete", "share", "pay", "email.send", "calendar.change")]
    return steps, gone, notes


def _not_understood(kind: str, tool: str) -> str:
    svc = _service(tool or "")
    return "Qosha could not put this step into plain words. It may %s%s." % (KIND_TEXT.get(kind, "act"), (" (in %s)" % svc) if svc else "")


def _deletes_only_gone(tool: str, a: Dict[str, Any], task_id: str = "") -> bool:
    """True when every thing the step would delete is checked and already gone (nothing else it does is asked)."""
    try:
        if tool == "terminal":
            acts, gone, unknown, _o = _shell_acts(str(a.get("command") or ""), _cwd(a, task_id))
            return bool(gone) and not unknown and not any(k == "delete" for k, _s in acts)
        if tool == "execute_code":
            acts, gone, unknown = _code_acts(str(a.get("code") or ""))
            return bool(gone) and not unknown and not acts
        if tool == "patch":
            steps, gone, _n = plain_acts("delete", "patch", a, task_id)
            return bool(gone) and not steps
    except Exception:
        return False
    return False


def _gone_only_names(a: Dict[str, Any], task_id: str = "") -> list:
    """For a shell step that does nothing but delete (and change folder), the names when ALL of them are already gone;
    [] otherwise (then the step runs or is asked as usual)."""
    acts, gone, unknown, only_del = _shell_acts(str(a.get("command") or ""), _cwd(a, task_id))
    if gone and not unknown and only_del and not acts:
        return gone
    return []


# ---- website actions in plain words (Ren, 17 Nov: "say what will happen in plain words only; the code is never shown") ----
# The steps are worked out from the code itself, in the order they appear. A step that cannot be put in words is said
# so honestly; nothing is guessed. The model's own first "# comment" may be shown as a note when it is plain language,
# but it never replaces the steps: code that clicks shows "Click ..." whatever its comment says.
_URL = r"https?://[^\s'\"<>)\\]+"
_STR = r"(?:'((?:[^'\\]|\\.)*)'|\"((?:[^\"\\]|\\.)*)\")"
_WEB_TRIGGER = r"click|press|submit|keyboard|Input\.dispatch|send_keys|upload|setFileInputFiles|fetch\([^)]*method"


def _host(url: str) -> str:
    h = re.sub(r"^https?://", "", url or "", flags=re.I).split("/")[0].split("?")[0].split("#")[0].split("@")[-1].split(":")[0].lower()
    return h   # as written: www.example.com is shown as www.example.com


def _say(t: str, n: int = 60) -> str:
    """A piece of page text as the person would read it: one line, no code characters left over, cut short."""
    t = re.sub(r"\\[nrt]", " ", t or "")
    t = re.sub(r"\\(.)", r"\1", t)
    t = re.sub(r"\s+", " ", t).strip(" '\"`")
    return t if len(t) <= n else t[: n - 1].rstrip() + "…"


def _thing(sel: str, default: str = "something on the page") -> str:
    """What a selector points at, in a word or two. Never the selector itself."""
    low = (sel or "").lower()
    if re.search(r"type\s*=\s*[\"']?submit|\[type=submit\]", low):
        return "the form's send button"
    if re.search(r"type\s*=\s*[\"']?password|password|passwd", low):
        return "the password box"
    if re.search(r"type\s*=\s*[\"']?email|e-?mail", low):
        return "the email box"
    if re.search(r"search|name\s*=\s*[\"']?q\b|\[name=q\]|#q\b", low):
        return "the search box"
    if re.search(r"type\s*=\s*[\"']?checkbox", low):
        return "a tick box"
    if re.search(r"type\s*=\s*[\"']?file", low):
        return "a file field"
    if re.search(r"user(name)?|login", low) and re.search(r"input|#|\[", low):
        return "the user name box"
    if re.search(r"(^|[\s>,(])textarea\b|comment|message", low):
        return "the message box"
    if re.search(r"(^|[\s>,(])select\b", low):
        return "a list of choices"
    if re.search(r"(^|[\s>,(])(button)\b|\.btn\b|role\s*=\s*[\"']?button", low):
        return "a button"
    if re.search(r"(^|[\s>,(])a(\b|\[|\.|#|:)|href", low):
        return "a link"
    if re.search(r"(^|[\s>,(])input\b", low):
        return "a box on the page"
    if re.search(r"(^|[\s>,(])form\b", low):
        return "a form"
    return default


def _plain_note(code: str) -> str:
    """The code's own first comment, only when it reads as ordinary language (letters and plain punctuation)."""
    m = re.match(r"\s*#\s*(.+)", code or "")
    if not m:
        return ""
    t = m.group(1).strip()
    if not (8 <= len(t) <= 140) or re.search(r"[(){}\[\]=;<>`$\\|_]|https?:|\.\w+\(|querySelector|\bjs\b", t) or len(t.split()) < 2:
        return ""
    # a note that plays the action down ("just read", "only look") is not shown next to steps that act: the steps
    # alone speak. It must itself name an action to be shown.
    if re.search(r"\b(just|only|merely|simply|read|reads|reading|look|looks|check|checks|view|views|see|nothing|harmless|safe)\b", t, re.I):
        return ""
    if not re.search(r"\b(click|press|type|fill|enter|send|submit|sign|log ?in|upload|choose|select|pick|tick|buy|order|book|post|open)", t, re.I):
        return ""
    return t


# "Only before final actions" (Ren, 17 Nov ~13:10): opening pages, reading, clicking links, typing and moving about
# never ask. A card comes only before a final step: sending or submitting a form, posting, buying or paying, deleting,
# confirming, signing in or up, uploading a file, accepting terms. When the code presses something and it cannot be
# told that it is NOT such a control, it counts as final (asked, in plain words).
_FINAL_WORDS = (
    r"send|submit|post|publish|share|buy|purchase|pay|order|check ?out|place|delete|remove|erase|confirm|sign ?in|log ?in|"
    r"sign ?up|register|create account|accept|agree|consent|save|subscribe|unsubscribe|book|reserve|donate|transfer|apply|"
    r"enviar|publicar|comprar|pagar|finalizar|pedir|excluir|apagar|remover|deletar|confirmar|entrar|acessar|cadastrar|"
    r"criar conta|aceitar|aceito|concordo|salvar|assinar|reservar|doar|transferir|"
    r"eliminar|borrar|quitar|iniciar sesi[oó]n|acceder|registrar|crear cuenta|aceptar|acepto|guardar|suscribir")
_SAFE_WORDS = (
    r"search|find|show|more|less|next|previous|prev|back|menu|open|close|expand|collapse|details|view|filter|sort|tab|"
    r"load|dismiss|cancel|skip|read|learn|about|help|home|"
    r"buscar|pesquisar|procurar|mostrar|ver|mais|menos|pr[oó]xim[oa]|anterior|voltar|abrir|fechar|detalhes|filtrar|ordenar|"
    r"cancelar|pular|ajuda|in[ií]cio|siguiente|volver|cerrar|detalles|ayuda")


def _is_final_word(text: str) -> bool:
    return bool(re.search(r"(?<![a-zà-ú])(%s)" % _FINAL_WORDS, (text or "").lower()))


def _is_safe_word(text: str) -> bool:
    return bool(re.search(r"(?<![a-zà-ú])(%s)" % _SAFE_WORDS, (text or "").lower())) and not _is_final_word(text)


def web_plain(code: str, kind: str = "web.act") -> Tuple[str, list, str, bool]:
    """(site, steps, note, final) for a website action: host only, short human steps in the code's order, an optional
    plain note, and whether any step is a final one (only then is the person asked)."""
    code = str(code or "")
    note = _plain_note(code)
    body = "\n".join(ln for ln in code.split("\n") if not ln.lstrip().startswith("#"))   # comments never count as actions
    urls = re.findall(_URL, body)
    site = _host(urls[0]) if urls else ""
    where = site or "the page that is open"
    found = []     # (position, end, sentence, final)
    covered = []   # more of the code that a step above already accounts for

    def hit(m, text, final=False):
        found.append((m.start(), m.end(), text, final))

    if kind == "web.post":
        where = site or tr("ask.web.open_page")
        key = "ask.web.send_data"
        if re.search(r"\b(DELETE)\b|\.delete\(|-Method\s+Delete", body, re.I):
            key = "ask.web.delete_on"
        elif re.search(r"\b(PUT|PATCH)\b|\.(put|patch)\(|-Method\s+(Put|Patch)", body, re.I):
            key = "ask.web.change_on"
        return site, [tr(key, where=where)], note, True
    for m in re.finditer(r"\b(new_tab|goto_url|goto|navigate|open_url)\(\s*" + _STR, body):
        u = m.group(2) or m.group(3) or ""
        h = _host(u)
        if h:
            path = re.sub(r"^https?://[^/]+", "", u).split("?")[0].split("#")[0].rstrip("/")
            hit(m, "Open %s%s" % (h, (" (the page %s)" % _say(path, 40)) if path else ""))
    boxes = []     # what was typed into, to judge a later Enter
    for m in re.finditer(r"\bfill_input\(\s*" + _STR + r"\s*,\s*" + _STR, body):
        sel, txt = m.group(1) or m.group(2) or "", m.group(3) or m.group(4) or ""
        box = _thing(sel, "a box on the page")
        boxes.append(box)
        if box == "the password box":
            hit(m, "Type a password into the password box")
        else:
            hit(m, "Type “%s” into %s" % (_say(txt), box) if txt.strip() else "Type into %s" % box)
    for m in re.finditer(r"\bfill_input\(\s*(?!['\"])[^)]*\)", body):
        boxes.append("a box on the page")
        hit(m, "Type into a box on the page")
    for m in re.finditer(r"\bclick_at_xy\([^)]*\)|Input\.dispatchMouseEvent", body):
        hit(m, "Click a spot on %s that Qosha could not identify" % where, True)
    for m in re.finditer(r"\.click\(\s*\)", body):
        stmt_start = max(body.rfind("\n", 0, m.start()), body.rfind("js(", 0, m.start()) - 1, 0)
        stmt = body[stmt_start:m.start()].replace("\\'", "'").replace('\\"', '"')   # quotes escaped inside the js("...") string read as plain quotes
        label = re.search(r"(?:textContent|innerText|ariaLabel|aria-label|title|value)[^'\"\n]{0,40}(?:includes\(|===?|==|indexOf\(|startsWith\(|contains\()\s*\\?" + _STR, stmt) \
            or re.search(r"(?:getByText|getByRole|:contains|has-text)\(?\s*\\?" + _STR, stmt) \
            or re.search(r"aria-label\s*[*^$]?=\s*\\?[\"']?([^\"'\]\\]{2,60})", stmt)
        sels = re.findall(r"querySelector(?:All)?\(\s*\\?" + _STR, stmt) or re.findall(r"getElementById\(\s*\\?" + _STR, stmt)
        sel = " ".join(x for pair in sels[-1:] for x in pair if x) if sels else ""
        what = _thing(sel)
        words = _say(next(g for g in label.groups() if g)) if label else ""
        link = what == "a link"
        if what == "the form's send button":
            text, final = ("Press the button “%s” (it sends the form)" % words if words else "Send the form"), True
        elif words and _is_final_word(words):
            text, final = "Press the %s “%s”" % ("link" if link else "button", words), True
        elif words and (link or _is_safe_word(words)):
            text, final = "Click the %s “%s”" % ("link" if link else "button", words), False
        elif words:
            text, final = "Press the button “%s”" % words, True          # a named control that is not known to be harmless
        elif link and not _is_final_word(sel):
            text, final = "Click a link", False
        elif _is_final_word(sel):
            text, final = "Press a button on %s (its name in the page suggests a final step)" % where, True
        else:
            text, final = "Press a button on %s that Qosha could not identify" % where, True
        found.append((m.start(), m.end(), text, final))
        covered.append((stmt_start, m.end()))   # the words that picked the element belong to this step
    for m in re.finditer(r"\.(?:requestSubmit|submit)\(\s*\)", body):
        hit(m, "Send the form", True)
    vals = list(re.finditer(r"\.value\s*=\s*(?!=)", body))
    if vals:
        pw = sum(1 for m in vals if re.search(r"passw", body[max(0, m.start() - 160):m.start()], re.I))
        text = "Fill %d field%s of a form" % (len(vals), "" if len(vals) == 1 else "s") + (" (one is a password)" if pw else "")
        found.append((vals[0].start(), vals[-1].end(), text, False))
        boxes.append("a form")
    for m in re.finditer(r"\.checked\s*=\s*(true|false|True|False)", body):
        near = body[max(0, m.start() - 200):m.start()]
        terms = bool(re.search(r"terms|agree|accept|consent|policy|termos|aceit|concord|t[eé]rminos|acept", near, re.I))
        hit(m, ("Tick the box that accepts the terms" if terms else "Tick a box") if m.group(1).lower() == "true" else "Untick a box", terms and m.group(1).lower() == "true")
    for m in re.finditer(r"\.selectedIndex\s*=|\.selected\s*=\s*true", body):
        hit(m, "Pick a choice from a list")
    for m in re.finditer(r"setFileInputFiles|\bupload\w*\(|input\[type=.?file", body, re.I):
        hit(m, "Upload a file", True)
    # Enter in a form sends it. The one exception is a plain search: the only thing typed into is a search box, so
    # Enter just shows results (moving about, like a link). Anything else typed, or nothing known: it is final.
    only_search = bool(boxes) and all(b == "the search box" for b in boxes)
    for m in re.finditer(r"(?:\bpress\(|\bsend_keys\(|key\s*[:=]\s*|code\s*[:=]\s*)\s*" + _STR, body):
        key = (m.group(1) or m.group(2) or "").strip()
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9+ ]{0,20}", key):
            continue
        key = {"Return": "Enter", "NumpadEnter": "Enter"}.get(key, key)
        if key == "Enter":
            hit(m, "Press Enter to search" if only_search else "Press Enter (it sends what was typed)", not only_search)
        else:
            hit(m, "Press the %s key" % key)
    for m in re.finditer(r"Input\.insertText|\.type\(\s*" + _STR + r"?|keyboard\.type", body):
        hit(m, "Type on the page")
    for m in re.finditer(r"fetch\([^)]{0,200}method\s*:\s*['\"](POST|PUT|PATCH|DELETE)['\"]", body, re.I | re.S):
        hit(m, "Send data to %s" % where, True)
    found.sort()
    steps, final = [], False
    # the website the card names (and "Always allow" is for) is the one the final step happens on: the page opened
    # last before it, not just the first address in the code
    opened = [(m.start(), _host(m.group(2) or m.group(3) or "")) for m in re.finditer(r"\b(new_tab|goto_url|goto|navigate|open_url)\(\s*" + _STR, body)]
    first_final = next((pos for pos, _e, _t, fin in found if fin), None)
    if first_final is not None:
        before = [h for pos, h in opened if pos < first_final and h]
        if before:
            site = before[-1]
    for _s, _e, t, fin in found:
        final = final or fin
        if not steps or steps[-1] != t:          # the same step twice in a row is said once
            steps.append(t)
    # anything that acts on the page and was not put in words above is said honestly, and counts as final
    rest = list(body)
    for s0, e0 in [(a0, b0) for a0, b0, _t, _f in found] + covered:
        for i in range(s0, min(e0, len(rest))):
            rest[i] = " "
    rest = "".join(rest)
    rest = re.sub(r"Input\.dispatchKeyEvent|keyboard", " ", rest) if any(t.startswith(("Press ", "Type on")) for t in steps) else rest
    if re.search(_WEB_TRIGGER, rest, re.I):
        final = True
        steps.append(("And something more on %s" if [t for t in steps if not t.startswith("Open ")] else "Do something on %s") % where
                     + " that Qosha could not describe in plain words")
    return site, steps[:12], note, final


def _asks_path():
    import os
    try:
        from hermes_constants import get_hermes_home
        home = str(get_hermes_home())
    except Exception:
        home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    d = os.path.join(home, "qosha")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "asks.json")


def _asks_edit(fn) -> list:
    """Read-modify-write of the small list of questions waiting in a chat (Home shows them)."""
    import os, time
    path = _asks_path()
    try:
        cur = json.loads(open(path, encoding="utf-8").read())
    except Exception:
        cur = []
    cur = [x for x in cur if isinstance(x, dict) and time.time() - float(x.get("at") or 0) < 3600]
    new = fn(cur)
    if new is not None and new != cur:
        tmp = path + ".tmp%d" % os.getpid()
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(new, fh)
        os.replace(tmp, path)
        cur = new
    return cur


def pending_asks() -> list:
    return _asks_edit(lambda cur: None)


_LAST: Dict[str, Dict[str, Any]] = {}   # message text -> what was asked (this process), for the approval hooks


def pre_approval_request(description: str = "", pattern_key: str = "", session_key: str = "", **_: Any) -> None:
    import time
    if not str(pattern_key).startswith("plugin_rule:qosha:"):
        return
    info = _LAST.get(description) or {}
    item = {"id": "ask-%d" % int(time.time() * 1000), "at": time.time(),
            "kind": ("whatsapp.read" if str(pattern_key).startswith("plugin_rule:" + WA_READ_RULE)
                     else str(pattern_key).split("qosha:", 1)[-1].split(":", 1)[0]),
            "title": info.get("title") or description.split("\n", 1)[0], "rows": info.get("rows") or [],
            "session": info.get("session") or "", "session_key": session_key, "text": description}
    _asks_edit(lambda cur: [x for x in cur if not (x.get("session_key") == session_key and x.get("text") == description)] + [item])


def post_approval_response(description: str = "", pattern_key: str = "", session_key: str = "", **_: Any) -> None:
    if str(pattern_key) == "plugin_rule:" + _FRONT_RULE:
        try:
            if _browser_cfg().get("qosha_stay_behind") is True:
                _stay_behind_watch()
        except Exception:
            pass
        return
    if not str(pattern_key).startswith("plugin_rule:qosha:"):
        return
    if str(pattern_key) == "plugin_rule:qosha:screen.read" or str(pattern_key) == "plugin_rule:" + WA_READ_RULE \
            or str(pattern_key).startswith("plugin_rule:" + WA_READ_RULE + ":"):
        try:
            whatsapp_read_answered(_.get("tool_call_id"), _consented(_.get("choice")))
            _wa_card_answered(_.get("tool_call_id"), _consented(_.get("choice")))
        except Exception:
            pass
        _asks_edit(lambda cur: [x for x in cur if not (x.get("session_key") == session_key and x.get("text") == description)])
        return                                    # a read card never reaches the shell-grant handling below (W5)
    try:
        from . import google_write
        google_write.consent(str(_.get("tool_call_id") or ""), _consented(_.get("choice")))   # Qosha's Google write tool
    except Exception:
        pass
    try:
        # cu20: the person's answer binds exactly the desktop step of THIS card, by its tool call (no: it can never
        # run). No call id, no binding: the step then can't run (GPT r1 CU-3)
        call = str(_.get("tool_call_id") or "")
        bound_step = _CU_CALLS.pop((str(session_key or ""), call), None) if call else None
        if bound_step is not None:
            from . import desktop_use
            desktop_use.allowed(bound_step[0], _consented(_.get("choice")), bound_step[1], bound_step[2])
    except Exception:
        pass
    try:
        # the person allowed the step on Qosha's card: the engine's own check is not asked again for this same step
        call = str(_.get("tool_call_id") or "")
        keys = _CALL_GRANTS.get(call) or (_LAST.get(description) or {}).get("grant") or []
        if keys and _consented(_.get("choice")):
            from . import engine_ask
            if engine_ask.grant(list(keys), call, session_key) and call:
                _GRANT_WHY[call] = "now"
    except Exception:
        pass
    _asks_edit(lambda cur: [x for x in cur if not (x.get("session_key") == session_key and x.get("text") == description)])


def _consented(choice: Any) -> bool:
    try:
        from tools.approval import CONSENT_ANSWERS, canonical_approval_choice
        return canonical_approval_choice(choice) in CONSENT_ANSWERS
    except Exception:
        return str(choice or "").lower() in ("once", "session", "always")


# Website steps no longer use rule_for (see sends_to_web below); its website keys are kept only so older code reads.
WEB_KINDS = ("web.act", "web.post")

# No "Always allow" for a step that sends data to a website (Ren, 19 Nov 2026: "No 'Always allow' for websites"). Such a
# step, and any step that also does one (an email + a POST, a delete + a POST, a payment made with curl), gets "Allow
# this time" only: its rule key is new for every call, so no "always" answer from any screen can ever cover another
# step, and every grant saved before (a website, a www or bare form, "step-...", the old all-websites key) matches
# nothing. Any web client named anywhere in a shell step or code counts, so when unsure the step asks.
_WEB_SEND = re.compile(
    r"(?<![\w.-])(?:curl|wget2?|Invoke-WebRequest|Invoke-RestMethod|Start-BitsTransfer)\b"
    r"|(?:^|[;&|(\n`]|\$\()\s*(?:sudo\s+|env\s+|\w+=\S*\s+)*(?:iwr|irm|https?|xh|httpie|aria2c)\s"
    r"|\b(?:requests|httpx|urllib3|aiohttp|pycurl|httplib2)\s*\.\s*\w+\s*\(|\burllib\.request\b|\bhttp\.client\b"
    r"|\b(?:from|import)\s+(?:requests|httpx|urllib|urllib3|aiohttp|pycurl|httplib2|http\.client)\b"
    r"|\bfetch\s*\(|XMLHttpRequest|sendBeacon|\bWebSocket\b", re.I | re.M)


def sends_to_web(kind: str, tool: str, args: Any) -> bool:
    if kind in WEB_KINDS:
        return True
    tool, a = _unwrap((tool or "").strip(), args if isinstance(args, dict) else {})
    if tool.startswith("browser"):
        return True   # a browser step that asks acts on a website (an upload, a press, a final step)
    if tool not in ("terminal", "execute_code", "process", "process_manage"):
        return False
    # each field on its own (H1): a joined string could hide a web client at the start of one of them
    return any(_WEB_SEND.search(str(a.get(k) or "")) for k in ("command", "code", "input", "data"))


def _once(kind: str) -> str:
    import secrets
    return "qosha:%s:once-%s" % (kind, secrets.token_hex(8))


def rule_for(kind: str, rows: list, code: str) -> str:
    if kind not in WEB_KINDS:
        return "qosha:" + kind
    site = next((str(v) for lab, v in rows if lab == "Website"), "")
    if site and re.fullmatch(r"[a-z0-9.-]{1,253}", site):
        return "qosha:%s:%s" % (kind, site)
    import hashlib
    return "qosha:%s:step-%s" % (kind, hashlib.sha256(str(code).encode("utf-8")).hexdigest()[:16])   # the code itself: only the very same step


# ---- Qosha's own browser on a person's computer (Ren, 17 Nov 13:21 and 13:42) ------------------------------------
# * It runs in the Google Chrome already on the computer when there is one (a separate, empty profile inside Qosha's
#   home; never the person's everyday profile), else in the bundled browser. Looked for before every browser step, so
#   a Chrome installed later is picked up, and one that was removed is dropped.
# * Visible or in the background: `browser.headed` (Settings > Browser "Do it in the background").
# * In front (the default) or behind: `browser.qosha_stay_behind` (Settings > Browser, or by telling Qosha).
# The engine reads its browser settings once per run; when one of them changed, its kept values are dropped and its
# running browser is closed, so the very next step starts a browser as chosen. Nothing here may raise.
FRONT_TITLE = "Qosha is about to open its browser window"
_FRONT_RULE = "qosha:browser.window"


def chrome_path() -> str:
    """The installed Google Chrome's program on this computer, or "" when there is none."""
    import os
    import sys
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        places = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                  home + "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    elif os.name == "nt":
        places = [os.path.join(os.environ.get(v) or "", "Google", "Chrome", "Application", "chrome.exe")
                  for v in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA") if os.environ.get(v)]
    else:
        places = ["/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/opt/google/chrome/chrome"]
    return next((x for x in places if os.path.isfile(x)), "")


def _is_chrome_program(path: str) -> bool:
    low = (path or "").replace("\\", "/").lower()
    return low.endswith("/google chrome.app/contents/macos/google chrome") or low.endswith("/google/chrome/application/chrome.exe") \
        or low in ("/usr/bin/google-chrome", "/usr/bin/google-chrome-stable", "/opt/google/chrome/chrome")


def _browser_cfg() -> dict:
    try:
        from hermes_cli.config import load_config
        return dict((load_config() or {}).get("browser") or {})
    except Exception:
        return {}


def _set_cfg(key: str, value: str) -> None:
    import contextlib
    import io
    from hermes_cli.config import set_config_value
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        set_config_value(key, value, force=True)


def _truthy(v) -> bool:
    return str(v).strip().lower() in ("true", "1", "yes", "on")


_SEEN = {"exe": None, "args": None}


def _browser_sync() -> dict:
    """Bring the engine in line with the settings before a browser step; returns the browser settings as they are now."""
    br = _browser_cfg()
    changed = False
    try:
        # which browser: the installed Chrome unless the person named another program themselves
        cur = str(br.get("executable_path") or "")
        if br.get("qosha_use_chrome", True) is not False and (cur == "" or _is_chrome_program(cur)):
            found = chrome_path()
            if cur != found:
                _set_cfg("browser.executable_path", found)
                br["executable_path"] = found
                changed = True
        # the installed Chrome keeps its passwords in the system's store; Qosha's empty profile must never ask for it
        # or touch it: its own profile uses a plain store of its own (these two flags only concern that profile)
        try:
            from tools import browser_session_cloud as cloud
            if bool(cloud.is_headed_mode()) != _truthy(br.get("headed")):
                changed = True
        except Exception:
            cloud = None
        exe = str(br.get("executable_path") or "")
        if _SEEN["exe"] is not None and _SEEN["exe"] != exe:
            changed = True
        _SEEN["exe"] = exe
        if changed and cloud is not None:
            cloud.reset_caches()
            try:
                from tools.browser_use_cli import stop_harness_daemons
                stop_harness_daemons()
            except Exception:
                pass
            try:
                from tools.browser_launcher import stop_all_browsers
                stop_all_browsers()
            except Exception:
                pass
    except Exception:
        pass
    return br


def _front_app() -> Tuple[str, int]:
    """macOS: (bundle path, process id) of the app in front, or ("", 0)."""
    import subprocess
    try:
        asn = subprocess.run(["lsappinfo", "front"], capture_output=True, text=True, timeout=3).stdout.strip()
        out = subprocess.run(["lsappinfo", "info", "-only", "bundlepath", "-only", "pid", asn], capture_output=True, text=True, timeout=3).stdout
        m = re.search(r'"LSBundlePath"="([^"]+)"', out)
        n = re.search(r'"pid"\s*=\s*(\d+)', out)
        return (m.group(1) if m else ""), (int(n.group(1)) if n else 0)
    except Exception:
        return "", 0


def _is_qoshas_browser(pid: int) -> bool:
    """True only for a browser Qosha started: its profile folder lies inside Qosha's own home. The person's own
    Chrome (same program, their profile) is never touched."""
    import subprocess
    if not pid:
        return False
    try:
        from hermes_constants import get_hermes_home
        home = str(get_hermes_home())
        cmd = subprocess.run(["ps", "-o", "command=", "-p", str(pid)], capture_output=True, text=True, timeout=3).stdout
        import os
        return ("--user-data-dir=" + home) in cmd or ("--user-data-dir=" + os.path.realpath(home)) in cmd
    except Exception:
        return False


def _stay_behind_watch(seconds: float = 25.0) -> None:
    """ "Stay behind": macOS always puts a newly started app in front and the engine starts the browser itself, so the
    window cannot be started behind. The nearest thing: for the next seconds, the moment Qosha's browser takes the
    front, the front is handed straight back to the app the person was in (a brief flash, then their window again)."""
    import sys
    import threading
    if sys.platform != "darwin":
        return   # Windows: the window is started minimized instead (see _window_args)
    was, _was_pid = _front_app()
    if not was:
        return

    def run():
        import subprocess
        import time
        end = time.time() + seconds
        gave = 0
        while time.time() < end and gave < 3:
            time.sleep(0.15)
            now, pid = _front_app()
            if now and pid != _was_pid and _is_qoshas_browser(pid):   # only Qosha's own browser, never the person's Chrome
                try:
                    subprocess.run(["open", "-a", was], capture_output=True, timeout=5)   # brings the person's app back; starts nothing new
                    gave += 1
                except Exception:
                    return
    threading.Thread(target=run, name="qosha-browser-behind", daemon=True).start()


def _window_args(br: dict) -> None:
    """Keep the browser flags in line with the choices: Qosha's own empty profile never uses the system's password
    store; on Windows "stay behind" starts the window minimized."""
    import os
    try:
        args = [str(x) for x in (br.get("chromium_args") or [])]
        want = list(args)
        for flag in ("--mute-audio", "--disable-audio-output"):
            if flag not in want:
                want.append(flag)
        chrome = _is_chrome_program(str(br.get("executable_path") or ""))
        for flag in ("--password-store=basic", "--use-mock-keychain"):
            if chrome and flag not in want:
                want.append(flag)
            if not chrome and flag in want:
                want.remove(flag)   # the bundled browser gets them from the engine itself
        mini = os.name == "nt" and _truthy(br.get("headed")) and br.get("qosha_stay_behind") is True
        if mini and "--start-minimized" not in want:
            want.append("--start-minimized")
        if not mini and "--start-minimized" in want:
            want.remove("--start-minimized")
        if want != args:
            from hermes_cli.config import load_config, save_config
            cfg = load_config()
            cfg.setdefault("browser", {})["chromium_args"] = want
            save_config(cfg)
            br["chromium_args"] = want
    except Exception:
        pass


def _before_browser_step(final: bool) -> Optional[Dict[str, str]]:
    """Settings in line before a browser step; when the person chose "stay behind", the front is handed back to them."""
    br = _browser_sync()
    _window_args(br)
    if not _truthy(br.get("headed")):
        return None
    # Ren, 17 Nov 15:36: the window comes to the FRONT by default and nobody is asked; a person it bothers switches
    # "Keep the browser window behind my other windows" on in Settings > Browser, or tells Qosha in the chat.
    if br.get("qosha_stay_behind") is True:
        _stay_behind_watch()
    return None


# ---- WhatsApp Desktop through the engine's desktop tool, v2 (Ren, 21 Nov 2026 ~23:05 MST: "Yes, simpler plan") -----
# Qosha only READS WhatsApp by looking (a look asks first: Allow this time / Always allow). To reply it opens WhatsApp's
# own prefilled-message link and the person presses Send; every click, key, typing or set_value inside WhatsApp is
# refused. Every desktop step names its app; one Qosha can't place is refused. (Round-1 fixes W1-W9, 21 Nov.)
import collections as _collections
WHATSAPP_ONLY_READS = ("Qosha doesn't click or type in WhatsApp. It reads and replies through its own WhatsApp "
                       "connection, and the person approves each reply. Nothing was done.")
NAME_THE_APP = "Say which app this step is for."
BY_NAME = "Qosha picks desktop apps by name."
NO_OWNER = "Qosha can't tell which chat this step belongs to. Nothing was done."
NOT_ON_SCREEN = "Qosha doesn't act on the whole screen. Nothing was done."
WHATSAPP_NO_SEND = ("Qosha sends WhatsApp messages only with whatsapp_reply, after the person approves the exact "
                    "message. Nothing was sent.")
WA_ENGINE = ("Qosha uses WhatsApp only through its own WhatsApp connection (whatsapp_chats, whatsapp_read, "
             "whatsapp_reply). Nothing was done.")
WA_REPLY_BAD = ("Not sent: Qosha sends one plain text message to one person. Give only chat and text (up to 4096 "
                "characters, no control characters). Nothing was sent.")
NO_SYNTH = "Qosha doesn't press keys or click for other programs from the terminal. Nothing was done."
WA_DATA = "Qosha reads WhatsApp only through its WhatsApp connection. Nothing was done."
WA_TOOLS_READ = ("whatsapp_chats", "whatsapp_read", "whatsapp_search", "whatsapp_open")
WA_NO_SCHED = "Qosha's reminders stay in Qosha; it never sends them on WhatsApp. Nothing was scheduled."
_SYNTH = re.compile(r"(?:osascript|system\s+events)[\s\S]{0,400}?\b(?:keystroke|key\s+code|click)\b|\bcliclick\b|"
                    r"\bxdotool\b|\bydotool\b|\bwtype\b|sendkeys|\bsendinput\b|keybd_event|autohotkey|\.ahk\b|"
                    r"pyautogui|pynput|\bkeyboard\.(?:press|write|send)\b|robotjs|nut-js|@nut-tree", re.I)
_WA_ENGINE_CMD = re.compile(r"(?:whatsapp-bridge|qosha-whatsapp)[\s\S]{0,400}?\bnode(?:\.exe)?\b[^\n]*\bbridge\.js|"
                            r"\bnode(?:\.exe)?\b[^\n]*\bbridge\.js[\s\S]{0,400}?(?:whatsapp-bridge|qosha-whatsapp)|"
                            r"\bhermes(?:\.exe)?\s+(?:whatsapp\b|gateway\b[^\n;&|]*\bwhatsapp|send\b[^\n;&|]*\bwhatsapp)|"
                            r"whatsapp-bridge[/\\]+bridge\.js|qosha-whatsapp[/\\]+bridge\.js|"
                            r"\bWHATSAPP_ENABLED\s*=\s*['\"]?(?:1|true|yes|on)\b|"
                            r"whatsapp-bridge[^\n]*?(?:&&|;)\s*node(?:\.exe)?\s+bridge\.js", re.I)
_WA_LOCAL_SEND = re.compile(r"(?:\b127(?:\.\d{1,3}){3}|localhost|\[?::1\]?|0\.0\.0\.0|\[?::ffff:127\.0\.0\.1\]?)"
                            r"(?::[^/\s\"']*)?/+(?:qosha/|send|send-media|send-poll|send-location|edit|typing|read|"
                            r"messages|chat/|health|auth-proof)", re.I)        # any port form, any bridge path (F7)
_WA_SECRET_NAMES = re.compile(r"\.bridge-token|whatsapp[/\\]+run\.json|whatsapp[/\\]+store|whatsapp[/\\]+session|"
                              r"qosha[/\\]+wa-summary|qosha_wa_summary\.py|/api/plugins/qosha/whatsapp-summary|"
                              r"/api/plugins/qosha/connections/whatsapp", re.I)   # named anywhere, home known or not (F6)
_WA_DATA_RX = re.compile(r"group\.net\.whatsapp|net\.whatsapp\.whatsapp|5319275a\.whatsappdesktop|"
                         r"whatsapp[/\\]+databases|chatstorage\.sqlite", re.I)


def _wa_home_rx():
    try:
        from hermes_constants import get_hermes_home
        home = str(get_hermes_home())
    except Exception:
        home = os.environ.get("HERMES_HOME") or ""
    if not home:
        return None
    def rx_of(path):
        return r"[/\\]+".join(re.escape(x) for x in re.split(r"[/\\]+", path.rstrip("/\\")) if x)
    alts = [rx_of(home)]
    user = os.path.expanduser("~")
    if user and home.lower().startswith(user.lower()) and len(home) > len(user):
        rest = rx_of(home[len(user):].lstrip("/\\"))
        alts.append(r"(?:~|\$HOME|\$\{HOME\}|%USERPROFILE%|\$env:USERPROFILE)[/\\]+" + rest)   # same folder, other spellings
    return re.compile(r"(?:%s)[/\\]+whatsapp(?![\w.-])" % "|".join(alts), re.I)   # any non-name character after it (R4 G-M)


NO_BROAD_SEARCH = "Qosha doesn't search the whole home folder; name a folder inside it. Nothing was done."
QOSHA_SELF = "Qosha doesn't operate its own windows; the person answers its cards. Nothing was done."


def _home_str() -> str:
    try:
        from hermes_constants import get_hermes_home
        return str(get_hermes_home())
    except Exception:
        return os.environ.get("HERMES_HOME") or ""


def _wa_linked() -> bool:
    h = _home_str()
    return bool(h) and os.path.isfile(os.path.join(h, "whatsapp", "session", "creds.json"))


def _too_broad(path: str) -> bool:
    """The home, one of its ancestors, the user folder or a filesystem/drive root (B2)."""
    p = os.path.expandvars(os.path.expanduser(str(path or "").strip().strip("\"'")))
    if not p:
        return False
    if re.fullmatch(r"[A-Za-z]:[\\/]*|[\\/]+", p):
        return True
    try:
        rp = os.path.normcase(os.path.realpath(p))
    except Exception:
        return True
    h = _home_str()
    targets = {os.path.normcase(os.path.realpath(os.path.expanduser("~")))}
    if h:
        hp = os.path.realpath(h)
        targets.add(os.path.normcase(hp))
        targets.update(os.path.normcase(str(x)) for x in __import__("pathlib").Path(hp).parents)
    return rp in targets


_SEARCHERS = re.compile(r"^(?:find|rg|ag|fd|grep|egrep|dir|Get-ChildItem|gci|ls)(?:\.exe)?$", re.I)


def _broad_search(text: str) -> bool:
    """A recursive search whose start folder (any of its path arguments) is the home, above it, or a root (B2)."""
    import shlex
    for seg in re.split(r"&&|\|\||[;|\n]", text or ""):
        try:
            toks = shlex.split(seg, posix=os.name != "nt" and not re.search(r"[A-Za-z]:\\", seg))   # Windows paths
        except ValueError:
            toks = seg.split()
        toks = [t for t in toks if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", t)]   # env assignments first
        if not toks or not _SEARCHERS.match(os.path.basename(toks[0])):
            continue
        cmd, rest = os.path.basename(toks[0]).lower().replace(".exe", ""), toks[1:]
        flags = " ".join(t for t in rest if t.startswith("-") or t.startswith("/"))
        recursive = (cmd in ("find", "rg", "ag", "fd") or
                     (cmd in ("grep", "egrep") and re.search(r"(?:^|\s)-[A-Za-z]*[rR]|--recursive", flags)) or
                     (cmd == "dir" and re.search(r"(?:^|\s)/s\b", flags, re.I)) or
                     (cmd in ("get-childitem", "gci", "ls") and re.search(r"-Recurse|(?:^|\s)-[A-Za-z]*R", flags)))
        if not recursive:
            continue
        for t in rest:
            if t.startswith("-") or (cmd == "dir" and t.startswith("/") and len(t) <= 3):
                continue
            if _too_broad(t):
                return True
    return False


NO_SCREEN_WHILE_WA = ("Qosha doesn't look at the whole screen while WhatsApp is connected; it reads WhatsApp only through "
                      "its WhatsApp connection. Nothing was done.")


def _wa_link_present() -> bool:
    """WhatsApp's link is here: the link-id file or the session file EXISTS, whatever it holds (R7); doubt = present."""
    try:
        h = _home_str()
        return (os.path.lexists(os.path.join(h, "whatsapp", "store", "link-id"))
                or os.path.lexists(os.path.join(h, "whatsapp", "session", "creds.json")))
    except Exception:
        return True


def _wa_gen() -> str:
    """This link's generation (session/link-id, written when the person links): a read grant counts only for it (F9)."""
    h = _home_str()
    try:
        with open(os.path.join(h, "whatsapp", "store", "link-id"), encoding="utf-8") as fh:
            raw = fh.read(4096).strip()
    except Exception:
        return ""
    try:
        v = json.loads(raw)
        if isinstance(v, dict):
            return str(v.get("id") or "")
    except Exception:
        pass
    return raw                                    # any content names the generation


def whatsapp_guard_text(tool: str, a: Dict[str, Any]):
    """Backstops for every tool (slice 5 v3): WhatsApp's data folders, Qosha's own WhatsApp folder, and calls straight
    to a local WhatsApp bridge are refused; ("refuse", words) or None."""
    if tool in ("whatsapp_chats", "whatsapp_read", "whatsapp_search", "whatsapp_open", "whatsapp_reply", "computer_use"):
        return None
    if tool == "search_files" and _too_broad(a.get("path") or a.get("directory") or a.get("root") or ""):
        return "refuse", NO_BROAD_SEARCH          # B2
    try:
        text = json.dumps(a, ensure_ascii=False)
    except Exception:
        text = str(a)
    flat = text.replace("\\\\", "\\")
    if _WA_LOCAL_SEND.search(flat):
        return "refuse", WA_ENGINE
    if _WA_SECRET_NAMES.search(flat):
        return "refuse", WA_DATA
    if _WA_DATA_RX.search(flat):
        return "refuse", WA_DATA
    rx = _wa_home_rx()
    if rx is not None and rx.search(flat):
        return "refuse", WA_DATA
    return None


def whatsapp_reply_problem(a: Dict[str, Any]) -> str:
    if not isinstance(a, dict) or set(a) != {"chat", "text"}:
        return WA_REPLY_BAD
    chat, text = a.get("chat"), a.get("text")
    if not isinstance(chat, str) or not isinstance(text, str):
        return WA_REPLY_BAD
    if not (re.fullmatch(r"[0-9]{5,20}@s\.whatsapp\.net", chat) or re.fullmatch(r"[0-9]{5,30}@lid", chat)):   # ASCII digits only (R4 G-L3)
        return WA_REPLY_BAD                       # one person, by a WhatsApp id Qosha can show plainly (F3)
    if not text.strip() or len(text) > 4096:
        return WA_REPLY_BAD
    if any((ord(c) < 32 and c not in "\n\t") or 127 <= ord(c) <= 159 for c in text + chat):
        return WA_REPLY_BAD
    return ""


def _wa_chat_label(chat: str) -> str:
    """"<name> (+<number>)" from Qosha's local WhatsApp store (names only), else the number or the id."""
    name = ""
    try:
        try:
            from hermes_constants import get_hermes_home
            home = str(get_hermes_home())
        except Exception:
            home = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
        f = os.path.join(home, "whatsapp", "store", "chats.json")
        with open(f, encoding="utf-8") as fh:
            c = json.load(fh).get(chat) or {}
        name = str(c.get("name") or "") if isinstance(c, dict) else ""
    except Exception:
        name = ""
    head = chat.split("@", 1)[0].split(":", 1)[0]
    name = re.sub(r"[\u200e\u200f\u202a-\u202e\u2066-\u2069\u061c\ufeff]", "", name)   # no direction tricks (F3)
    name = re.sub(r"[\r\n\t\u2028\u2029]+", " ", name)          # line breaks (incl. Unicode separators) folded
    name = re.sub(r"[\x00-\x1f\x7f-\x9f]", "", name).strip()[:80]   # other control characters removed (F3)
    digits = head.isascii() and head.isdigit()
    if chat.endswith("@s.whatsapp.net") and digits:
        return "%s (+%s)" % (name, head) if name else "+" + head
    if chat.endswith("@lid") and digits:
        lid = "WhatsApp id %s, not a phone number" % head
        return "%s (%s)" % (name, lid) if name else lid
    return chat
ONE_AT_A_TIME_DESKTOP = "Qosha checks one step at a time: call these one by one. Nothing was done."
_CU = _collections.OrderedDict()          # (kind, id) -> {"read_ok": set of "whatsapp"/"screen"}
_CU_CARDS = _collections.OrderedDict()    # tool_call_id -> ((kind, id), what) for a pending read card
_CU_MAX = 200
_CU_NO_APP_OK = {"list_apps", "list_windows", "wait"}
_CU_LOOKS = {"capture", "scroll", "focus_app"}
_WA_NAMES = ("whatsapp", "net.whatsapp.whatsapp", "whatsapp.exe", "5319275a.whatsappdesktop")
_WA_AUTOMATION = re.compile(r"osascript|system events|tell\s+application|keystroke|pyautogui|pynput|sendkeys|xdotool|"
                            r"ydotool|autohotkey|cliclick|keyboard\.(press|write|send)", re.I)


def _cu_key(session_id: Any, task_id: Any):
    s, t = str(session_id or ""), str(task_id or "")
    return ("session", s) if s else (("task", t) if t else None)


def _cu_rec(key, create: bool = False):
    rec = _CU.get(key)
    if rec is None and create:
        rec = {"read_ok": set()}
    if rec is not None:
        _CU[key] = rec
        _CU.move_to_end(key)
        while len(_CU) > _CU_MAX:
            _CU.popitem(last=False)
    return rec


def is_whatsapp(app: Any) -> bool:
    a = re.sub(r"\s+", "", str(app or "")).lower()
    if not a:
        return False
    if "whats" in a or "sapp" in a or "whatsapp" in a:
        return True
    if len(a) <= 2 and a != "wh":
        return False
    return any(a in n for n in _WA_NAMES)


def _is_screen(app: Any) -> bool:
    return str(app or "").strip().lower() in ("screen", "desktop")


def whatsapp_step(a: Dict[str, Any], session_id: Any = "", task_id: Any = ""):
    """None (today's behaviour), ("block", words) or ("ask", what, app)."""
    act = str(a.get("action") or "").strip().lower()
    if a.get("pid") not in (None, 0) or a.get("window_id") not in (None, 0):
        return "block", BY_NAME
    app = a.get("app")
    if not (isinstance(app, str) and app.strip()):
        return None if act in _CU_NO_APP_OK else ("block", NAME_THE_APP)
    app = app.strip()
    if re.search(r"qosha", app, re.I):
        return "block", QOSHA_SELF                # Qosha's own windows: the person answers its cards (F11)
    screen = _is_screen(app)                  # exactly "screen"/"desktop" first ("desktop" is also part of WhatsApp's id)
    wa = not screen and is_whatsapp(app)
    if not wa and not screen:
        return None
    if wa:                                    # WhatsApp is read only through Qosha's WhatsApp connection (R6 cut 2)
        return "block", WHATSAPP_ONLY_READS
    if screen and _wa_link_present():         # the whole screen could show WhatsApp: no screen looks while it is linked
        return "block", NO_SCREEN_WHILE_WA    # (R7; the connector's own tools read WhatsApp)
    key = _cu_key(session_id, task_id)
    if key is None:
        return "block", NO_OWNER                # WhatsApp or the screen with no chat to tie it to: refused (W6)
    if act in _CU_NO_APP_OK:
        return None
    if act not in _CU_LOOKS or (act == "focus_app" and a.get("raise_window") is True):
        return "block", (WHATSAPP_ONLY_READS if wa else NOT_ON_SCREEN)
    what = "whatsapp" if wa else "screen"
    if what == "screen" and what in ((_cu_rec(key) or {}).get("read_ok") or set()):
        return None                            # (a WhatsApp look is never remembered: R5 cut 4)
    return "ask", what, app


def whatsapp_card_shown(key, tool_call_id: Any, what: str) -> None:
    if str(tool_call_id or ""):
        _CU_CARDS[str(tool_call_id)] = (key, what)
        _CU_CARDS.move_to_end(str(tool_call_id))
        while len(_CU_CARDS) > _CU_MAX:
            _CU_CARDS.popitem(last=False)


def whatsapp_read_answered(tool_call_id: Any, consented: bool) -> None:
    """The answer to a pending read card (matched only by its own call id): a yes lets later looks of that kind in that
    session or task run without asking; any answer ends the pending card."""
    held = _CU_CARDS.pop(str(tool_call_id or ""), None)
    if held and consented:
        _cu_rec(held[0], create=True)["read_ok"].add(held[1])


WA_READ_RULE = "qosha:whatsapp.read-once"   # a key no earlier "Always allow" was ever saved under (R5 cut 4)
_WA_CARDS: Dict[str, Any] = {}           # tool_call_id -> (owner key, what, link generation) of a read card shown
_WA_PASSES: Dict[Any, list] = {}          # (owner key, what) -> link generations the person allowed, one use each


def _wa_reads_once() -> bool:
    """The engine offers only "Allow this time" for a WhatsApp read card: its key joins the engine's own one-run list
    (no session or Always grant is ever stored). False when that list can't be reached; the card then gets a key of
    its own each time, so a remembered answer never matches another read (R5 cut 4)."""
    try:
        import tools.approval as _ap
        key = "plugin_rule:" + WA_READ_RULE
        cur = getattr(_ap, "SMART_MANUAL_ONLY_DESCRIPTIONS")
        if key not in cur:
            _ap.SMART_MANUAL_ONLY_DESCRIPTIONS = frozenset(cur) | {key}
        return key in _ap.SMART_MANUAL_ONLY_DESCRIPTIONS
    except Exception:
        return False


WA_PASS_SECONDS = 120                     # a yes is used soon or not at all (R7)


def _wa_what(tool: str, args: Any) -> str:
    """The exact call: the tool and ALL its arguments (a card for one message of a chat never covers 200 of them, R7)."""
    a = args if isinstance(args, dict) else {}
    try:
        return json.dumps([tool, a], sort_keys=True, default=str)
    except Exception:
        return json.dumps([tool, repr(a)])


def _wa_card_shown(tool_call_id: Any, key, tool: str, gen: str, args: Any = None) -> None:
    """A read card was shown for this exact call: nothing may run until the person answers it (R6 cut 2). A new card
    for the same call voids any older unused yes for it (a cancelled call's pass never serves another, R7)."""
    what = _wa_what(tool, args)
    _WA_PASSES.pop((key, what), None)
    for cid, held in list(_WA_CARDS.items()):   # an older card for the same call can't give a late yes to this one
        if held[0] == key and held[1] == what:
            _WA_CARDS.pop(cid, None)
    if str(tool_call_id or ""):
        _WA_CARDS[str(tool_call_id)] = (key, what, gen)
        while len(_WA_CARDS) > 200:
            _WA_CARDS.pop(next(iter(_WA_CARDS)))


def _wa_card_answered(tool_call_id: Any, consented: bool) -> None:
    """The person's answer to that card: only a yes, for the link that is linked now, gives ONE pass for this call."""
    held = _WA_CARDS.pop(str(tool_call_id or ""), None)
    if not held or not consented:
        return
    key, what, gen = held
    if gen and gen == _wa_gen():
        import time as _t
        q = _WA_PASSES.setdefault((key, what), [])
        q.append((gen, _t.time()))
        del q[:-20]
        while len(_WA_PASSES) > 200:
            _WA_PASSES.pop(next(iter(_WA_PASSES)))


def wa_read_allowed(session_id: Any, task_id: Any, tool: str, args: Any = None) -> bool:
    """At run time: the person allowed this read on its card (same chat, message or words), for the WhatsApp link
    linked now; the pass is used up (R6 cut 2). No answer, a Deny, approvals off, another chat: no pass."""
    key = _cu_key(session_id, task_id)
    q = _WA_PASSES.get((key, _wa_what(tool, args))) if key is not None else None
    if not q:
        return False
    import time as _t
    gen, at = q.pop(0)
    return bool(gen) and gen == _wa_gen() and 0 <= _t.time() - at <= WA_PASS_SECONDS


def forget_whatsapp_grants() -> None:
    """Every WhatsApp read answer this process holds is forgotten (on Disconnect, R4 #7): the connector's grants of any
    link generation, the desktop WhatsApp looks, and pending WhatsApp read cards."""
    for rec in list(_CU.values()):
        ok = rec.get("read_ok") or set()
        for g in list(ok):
            if g == "whatsapp" or str(g).startswith("wa_tools:"):
                ok.discard(g)
    for cid, held in list(_CU_CARDS.items()):
        if held and (held[1] == "whatsapp" or str(held[1]).startswith("wa_tools:")):
            _CU_CARDS.pop(cid, None)
    _WA_CARDS.clear()
    _WA_PASSES.clear()


def whatsapp_shell(text: str) -> bool:
    """A command or code that drives WhatsApp with desktop automation (opening its official link is fine)."""
    return bool(re.search(r"whatsapp", text or "", re.I) and _WA_AUTOMATION.search(text or ""))


WHATSAPP_NO_WEB = ("Qosha doesn't use WhatsApp in its browser. To reply, Qosha opens WhatsApp's own message link and the "
                   "person presses Send. Nothing was done.")
_WA_HOST_IN_TEXT = re.compile(r"(?<![\w.-])(?:(?:[\w-]+\.)*whatsapp\.(?:com|net)|wa\.me)(?![\w-])", re.I)


def whatsapp_host(url: Any) -> bool:
    """A url on WhatsApp's own sites (whatsapp.com/.net and subdomains, wa.me), any case and scheme (W10)."""
    try:
        import unicodedata
        from urllib.parse import unquote, urlsplit
        u = str(url or "").strip()
        for _ in range(3):                        # percent-encoded letters are decoded like the browser does (v3)
            u = unquote(u)
        u = unicodedata.normalize("NFKC", u)
        host = (urlsplit(u if "//" in u else "//" + u).hostname or "").lower().rstrip(".")
        try:
            host = host.encode("idna").decode("ascii").lower()
        except Exception:
            pass
        try:
            host = host.encode("ascii").decode("idna").lower() if "xn--" in host else host
        except Exception:
            pass
        host = unicodedata.normalize("NFKC", host).rstrip(".")
    except Exception:
        return True
    return (host in ("whatsapp.com", "whatsapp.net", "wa.me") or host.endswith(".whatsapp.com")
            or host.endswith(".whatsapp.net"))


GUARD_FORMAT = 20261122      # the startup barrier uses a fallback copy of this file only from this version on (r1210)
ISSUED: Dict[str, bool] = {}               # rule keys Qosha itself gave (r1210 r2, Gemini 1)
VERDICTS: Dict[str, Tuple[str, Any]] = {}   # tool call -> (arguments' key, answer), read once by the startup barrier


def pre_tool_call(tool_name: str = "", args: Any = None, session_id: str = "", task_id: str = "", tool_call_id: str = "",
                  **kw: Any) -> Optional[Dict[str, str]]:
    """Qosha's answer for a step; recorded per tool call so the startup barrier can check it against the arguments that
    actually run (r1210, group 4)."""
    import copy
    import hashlib
    snap = copy.deepcopy(args)         # one private copy is hashed, and judged (r1210 r2, GPT 2) ...
    judged = copy.deepcopy(snap)
    try:                               # ... in the form the tool will get it (the engine's own coercion; GPT 1)
        from tools.arg_coercion import coerce_tool_args
        judged = coerce_tool_args(tool_name, judged) if isinstance(judged, dict) else judged
    except Exception:
        pass
    try:
        r = _pre_tool_call(tool_name, judged, session_id=session_id, task_id=task_id, tool_call_id=tool_call_id, **kw)
    except Exception:                  # an error while judging never lets the step run (connectors, fail closed)
        r = {"action": "block", "message": "Not run: Qosha could not check this step. Nothing was done."}
    try:
        key = hashlib.sha256(json.dumps([tool_name or "", snap if isinstance(snap, dict) else {}], sort_keys=True,
                                        default=str).encode()).hexdigest()
        # by tool call, or by the arguments when the engine gives no id (code-execution calls; GPT 4)
        VERDICTS[str(tool_call_id) if tool_call_id else "args:" + key] = (key, r)
        while len(VERDICTS) > 500:
            VERDICTS.pop(next(iter(VERDICTS)))
        if isinstance(r, dict) and r.get("rule_key"):
            ISSUED[str(r["rule_key"])] = True    # Qosha's own rule keys, so the barrier can tell them from a copy
            while len(ISSUED) > 500:
                ISSUED.pop(next(iter(ISSUED)))
    except Exception:
        pass
    return r


def _pre_tool_call(tool_name: str = "", args: Any = None, session_id: str = "", task_id: str = "", tool_call_id: str = "",
                   **_: Any) -> Optional[Dict[str, str]]:
    try:
        from . import engine_ask
    except Exception:
        engine_ask = None
    if engine_ask is not None:
        engine_ask.revoke(keep_call=tool_call_id)   # a grant given for an earlier step ends when the next one starts
    # cu20: Qosha using the person's computer (the engine's computer_use, also inside tool_call) is judged on its own
    try:
        u_tool = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
    except Exception:
        u_tool = ("", {})
    if u_tool[0] == "computer_use":
        return _desktop_step(u_tool[1], session_id, tool_call_id, engine_ask)
    if u_tool[0] == "qosha_computer_setup":
        return _desktop_setup_card(session_id, u_tool[1])
    try:
        stop_why = _touches_desktop_stop(tool_name, args)
    except Exception:
        stop_why = DESKTOP_STOP_FILES
    if stop_why:
        return {"action": "block", "message": stop_why}
    try:
        _cu_tool, _cu_args = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
    except Exception:
        _cu_tool, _cu_args = "", {}
    if _cu_tool in WA_TOOLS_READ:
        try:
            key = _cu_key(session_id, task_id)
            if key is None:
                return {"action": "block", "message": NO_OWNER}
            wg = whatsapp_guard_text(_cu_tool, _cu_args)
            if wg:
                return {"action": "block", "message": wg[1]}
            # every WhatsApp read asks, "Allow this time" only (R5 cut 4): nothing is remembered, and the link this
            # card is for is recorded so the read refuses to run if WhatsApp was linked again in between
            _wa_card_shown(tool_call_id, key, _cu_tool, _wa_gen(), _cu_args)
            kind = "whatsapp.read"
            title = "Qosha wants to " + KIND_TEXT[kind]
            chat = _cu_args.get("chat") if _cu_tool in ("whatsapp_read", "whatsapp_open") else None
            rows = [("What happens", "Qosha reads your WhatsApp messages through its WhatsApp connection."),
                    ("Chat", "a search of your chats" if _cu_tool == "whatsapp_search" else
                     (_wa_chat_label(str(chat)) if isinstance(chat, str) and chat else "the list of your chats"))]
            message = (title + "\n" + "\n".join("%s: %s" % r for r in rows) +
                       "\n(This answer covers this one read; Qosha asks again for the next one.)")
            _LAST[message] = {"title": title, "rows": [list(r) for r in rows], "session": session_id or "",
                              "grant": [], "kind": kind}
            rule = WA_READ_RULE if _wa_reads_once() else WA_READ_RULE + ":" + secrets.token_hex(6)
        except Exception:
            return {"action": "block", "message": WA_DATA}
        return {"action": "approve", "rule_key": rule, "message": message}
    # a tool_call Qosha can't read is left to the engine, which rejects it itself (slice 1 v11 F1, reviewed)
    if _cu_tool == "" and str(tool_name or "").strip() == "computer_use":
        return {"action": "block", "message": WHATSAPP_ONLY_READS}   # could not read the step: refused
    # computer_use itself is judged only by Qosha's desktop check (cu20's _desktop_step / desktop_use.judge, agreed
    # 22 Nov 2026 with the computer-use session), which also holds the WhatsApp rules (R6: no input in WhatsApp; R7: no
    # WhatsApp or whole-screen capture while WhatsApp is linked). Without that check, kind_of refuses it.
    is_browser = "browser" in str(tool_name) or (tool_name == "tool_call" and "browser" in str((args or {}).get("name") if isinstance(args, dict) else ""))
    try:
        k = kind_of(tool_name, args, task_id)
    except Exception:
        try:
            mine = bool(_connector(_unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})[0])[0])
        except Exception:
            mine = True
        if mine:
            return {"action": "block", "message": "Qosha could not tell what this Outlook or Dropbox step does, so it "
                                                  "didn't do it. Nothing was done."}
        return {"action": "approve", "rule_key": _once("unclear"),
                "message": "%s\n%s\n%s" % (tr("ask.title.unclear"), reason_line("off_unclear"), tr("ask.footer.off_unclear"))}
    if k and k[0] == "refuse":
        # Outlook's own send tools and its "run any tool" meta-tools: never run, never a card, whatever was saved
        return {"action": "block", "message": k[1]}
    try:
        profile = _turns_on_real_profile(tool_name, args)
    except Exception:
        profile = True
    if profile:
        if k:
            return {"action": "block", "message": tr("ask.block.profile_mixed")}
        k = ("browser.profile", _text(args))
    # Qosha's approval code and approval settings (the paid-AI switches among them): asked every time, never "Always
    # allow" (Ren, card 21 Nov 2026 ~21:55 MST, "Yes, both"; qosha_guard/selfguard.py, paid_ai.py)
    sg = None
    try:
        from . import selfguard as sg
        guarded = sg.check(tool_name, args)
    except Exception:
        guarded = tr("ask.self.check_failed")
    if guarded and k and k[0] == "browser.profile" and sg is not None:
        try:               # that setting's own one-time card shows this change, when nothing else is touched
            if sg.only_config_file(tool_name, args):
                guarded = None
        except Exception:
            pass
    if guarded:
        if k:      # a step already known as another kind: refused, so that kind's own refusals are never skipped
            return {"action": "block", "message": getattr(sg, "MIXED", tr("ask.block.self_mixed"))}
        text = sg.card(guarded) if sg else tr("ask.self.card", what=guarded)
        return {"action": "approve", "rule_key": _once("approval.self"), "message": text}
    if k:
        try:
            if google_mixed(tool_name, args, task_id):
                return {"action": "block", "message": tr("ask.block.google_mixed")}
        except Exception:
            return {"action": "block", "message": tr("ask.block.google_mixed")}
    if not k and tool_name == "terminal":
        # a shell step that ONLY deletes things that are already gone: no card, and nothing runs (the engine would
        # otherwise put its own question about a recursive delete); Qosha is told plainly and carries on
        try:
            gone = _gone_only_names(args if isinstance(args, dict) else {}, task_id)
        except Exception:
            gone = []
        if gone:
            return {"action": "block", "message": "Nothing to delete: %s %s already gone, so this step was skipped and "
                    "nothing ran. Carry on without it." % (", ".join(gone[:8]) + (" and more" if len(gone) > 8 else ""),
                                                           "is" if len(gone) == 1 else "are")}
    if is_browser:
        try:
            ask_window = _before_browser_step(bool(k))
        except Exception:
            ask_window = None
        if ask_window and not k:
            return ask_window
    # what the engine's own safety check would ask about for this same shell command (17 Nov 16:41, Ren's Mac: after
    # "Allow this time" on Qosha's card a second, technical card "delete in root path" came up). Qosha's one card
    # says it too, in plain words, and the engine's check is then not asked again for this step.
    eng, risks = [], []
    if engine_ask is not None and tool_name == "terminal" and isinstance(args, dict):
        eng = engine_ask.findings(str(args.get("command") or ""), bool(args.get("background"))) or []   # what it would ask
        if eng or k:
            risks = engine_ask.all_risks(str(args.get("command") or ""), bool(args.get("background")))  # what the card says
        for ek, ed in eng:
            if ek not in [r[0] for r in risks]:
                risks.append((ek, ed))
    gw_account = None
    if not k and not eng:
        return None
    if k:
        kind, what = k
        # a Google Chat edit is its own kind (Ren, 20 Nov, card: "Separate"): Always allow for sends never covers edits
        shown = "message.edit" if kind == "message.send" and _gchat_edit(tool_name, args) else kind
        title = tr("ask.title.kind", what=kind_text(shown))
        if _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})[0] == "qosha_google_change":
            from . import google_write
            gw_account = google_write.account(google_write._home())     # one lookup for the card and the approval
            if not gw_account:
                return {"action": "block", "message": tr("ask.block.google_connect_first")}
        try:
            if gw_account:
                # unwrapped once: the real tool and its own arguments, plus the account (Gemini verification HIGH 1)
                u_tool, u_args = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
                rows = rows_for(kind, u_tool, dict(u_args, _qosha_account=gw_account), what, task_id)
            else:
                rows = rows_for(kind, tool_name, args, what, task_id)
        except Exception:
            if _connector(_unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})[0])[0]:
                return {"action": "block", "message": "Qosha could not build the card for this step, so it didn't do "
                                                      "it. Nothing was done."}
            if kind in ("email.send", "message.send", "whatsapp.send"):
                # an email or message whose card can't be built is not sent (GPT allowc r1 #10, fail closed)
                return {"action": "block", "message": tr("ask.block.no_card.email" if kind == "email.send" else
                                                         "ask.block.no_card.message")}
            rows = [("What happens", _not_understood(kind, tool_name))]
        extra = [(ek, ed) for ek, ed in risks if engine_ask.plain(ed)[0] != kind]   # what Qosha's own kind does not cover
    else:
        kind, what, extra = "engine", "", []
        title = tr("ask.title.engine")
        said = []
        for _ek, ed in risks:
            t = engine_ask.plain(ed)[1]
            if t not in said:
                said.append(t)
        rows = [("Steps", "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(said)))] if len(said) > 1 else [("What happens", said[0])]
    if extra:
        said = []
        for _ek, ed in extra:
            t = engine_ask.plain(ed)[1]
            if t not in said:
                said.append(t)
        rows.append(("Also", "\n".join(said)))
    # one labelled row per line (the label in the person's language); a value's own line breaks are indented so the
    # card can tell them from a new row
    # a lone carriage return is a line break too (GPT vqa/rshw #4: "First\rSecond" must not show as "FirstSecond")
    # The sentences stay English in `rows` (the rule and the checks above and below read them); the person reads them
    # in their language (row_value: unchanged in English)
    lines = ["%s: %s" % (row_label(lab), row_value(lab, _line_breaks(val)).replace("\n", "\n    ")) for lab, val in rows]
    try:
        web = sends_to_web(kind, tool_name, args)
    except Exception:
        web = True
    # the footer sentence (last line, in the person's language) and the language-free reason code the card reads
    gmcp = _google_mcp(tool_name, args)   # every Google tool's card is for this one request only (1.20.8 round 2)
    if web:
        tail = tr("ask.footer.off_web")
        reason = reason_line("off_web")
    elif kind == "browser.profile":
        tail = tr("ask.footer.off_profile")
        reason = reason_line("off")
    elif gmcp:
        tail = tr("ask.footer.off_google_each")
        reason = reason_line("off")
    elif kind == "google.change" or google_step(tool_name, args):
        tail = tr("ask.footer.off_google_unclear")
        reason = reason_line("off")
    elif mixed_step(tool_name, args, task_id):
        tail = tr("ask.footer.off_mixed")
        reason = reason_line("off")
    elif kind == "engine" or extra:
        tail = tr("ask.footer.kind")
        reason = reason_line("kind")
    else:
        tail = tr("ask.footer.kind_named", kind=kind_text(shown))
        reason = reason_line("kind_named", shown)
    if kind == "unclear":
        tail = tr("ask.footer.off_unclear")
        reason = reason_line("off_unclear")
    if web or gmcp or kind in ("google.change", "browser.profile", "unclear") or google_step(tool_name, args) or mixed_step(tool_name, args, task_id):
        rule = _once(kind)      # a Google change Qosha can't name exactly, or a step of several kinds: never covered later
    elif kind == "engine" or extra:
        # the person's "Always allow" is then for exactly these kinds of risk (and Qosha's own kind, if any)
        rule = "qosha:engine:" + "+".join(([kind] if kind != "engine" else []) + sorted({ek for ek, _ed in (extra or risks)}))
    else:
        rule = rule_for(shown, rows, what)
    message = "%s\n%s\n%s\n%s" % (title, "\n".join(lines), reason, tail)
    _ct = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})[0]
    if (kind in ("delete", "share", "calendar.change", "calendar.invite") and _connector(_ct)[0]) or \
            (kind == "dropbox.change" and _ct == "dropbox_organize"):   # round 2 (GPT H5): every card shown in full
        why = _connector_card_problem(tool_name, rows, message)
        if why:
            return {"action": "block", "message": why}
    if kind in ("email.send", "message.send", "whatsapp.send"):   # a WhatsApp reply too (R3 F3; family suite)
        # An email or message goes only as the person sees it on the card. These refusals come BEFORE any saved
        # approval is looked at: Always allow covers the kind of action, never an email the card cannot show
        # (GPT vqa/rshw #1, #3, #5). `message` is the card's text in the person's language, exactly as it is handed
        # to the page (the labels and Qosha's sentences as they read them, the reason line included): its length is
        # the one the page's limit applies to. `rows` keeps the English labels the checks in _unseen read.
        why = _unseen(tool_name, args, rows, message, kind)
        if why:
            return {"action": "block", "message": why}
    elif gmcp or kind == "browser.profile":
        why = _google_unseen(message)          # a Google card the page would cut or mask (1.20.8 round 2)
        if why:
            return {"action": "block", "message": why}
    grant_keys = [ek for ek, _ed in eng]
    _LAST[message] = {"title": title, "rows": [[row_label(r[0]), row_value(r[0], r[1])] for r in rows], "session": session_id or "",
                      "grant": grant_keys}
    if grant_keys and tool_call_id:
        _CALL_GRANTS[tool_call_id] = grant_keys
        for store in (_CALL_GRANTS, _GRANT_WHY):
            if len(store) > 200:
                for key in list(store)[:100]:
                    store.pop(key, None)
        if engine_ask.is_allowed(rule):
            # "Always allow" (or this session) was already chosen for this card: the engine lets it through without
            # asking, and its own check must not ask either
            if engine_ask.grant(grant_keys, tool_call_id):
                _GRANT_WHY[tool_call_id] = "always"
    if len(_LAST) > 200:
        for key in list(_LAST)[:100]:
            _LAST.pop(key, None)
    if gw_account is not None:
        from . import google_write
        # pending until the person's Allow (post_approval_response); bound to the account the card named
        google_write.pending(tool_call_id, _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})[1],
                             gw_account)
    return {"action": "approve", "rule_key": rule, "message": message}


# ---- cu20: Qosha uses the person's computer (desktop_use.py decides; this turns its answer into one card) ----------
DESKTOP_STOP_FILES = ("Not done: this step would touch the files that hold the person's Stop for Qosha using their "
                      "computer (bot-desktop, desktop-stop). Only the person changes that, with Stop and \"Let Qosha "
                      "continue\" in Qosha. Nothing ran.")
DESKTOP_UNCHECKED = ("Not done: Qosha could not check this step on the person's computer, so nothing was clicked or "
                     "typed. Tell the person plainly.")
_DESKTOP_STOP_RX = re.compile(r"bot[-_]desktop|desktop[-_]stop|(?<![\w.-])lease\.json", re.I)
# the screen-control helper itself: the AI's own commands never start or talk to it (only computer_use does, through
# Qosha's check; GPT r1 CU-2)
_DESKTOP_DRIVER_RX = re.compile(r"cua[-_ ]?driver|cuadriver|com\.trycua", re.I)
DESKTOP_DRIVER = ("Not done: this step would start or talk to Qosha's screen-control helper directly. Qosha uses the "
                  "computer only through its computer_use step, where it checks each click and the person can press "
                  "Stop. To reset its macOS permissions, use qosha_computer_setup with repair_permissions=true. "
                  "Nothing ran.")
_DESKTOP_STOP_READS = {"read_file", "search_files", "list_files", "list_directory", "web_search", "web_extract",
                       "vision_analyze", "video_analyze", "skill_view", "skills_list", "session_search", "computer_use"}
_CU_CALLS: Dict[str, Any] = {}       # tool call -> the engine backend whose judged step the person answers


def _approval_key() -> str:
    """The engine's approval session key for this conversation (the same key its answer comes back with)."""
    try:
        from tools.approval import get_current_session_key
        return str(get_current_session_key() or "")
    except Exception:
        return ""


def _touches_desktop_stop(tool_name: str, args: Any) -> Optional[str]:
    """Any step that names the Stop files (the engine's lease folder, Qosha's flag) is refused outright: the AI can't
    lift the person's Stop (council, 22 Nov: hard refusal, never a card)."""
    tool, a = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
    if tool in _DESKTOP_STOP_READS:
        return None
    text = json.dumps(a, default=str)
    try:
        text += " " + json.dumps(json.loads(text), ensure_ascii=False, default=str)
    except Exception:
        pass
    text = text.replace("\\", "/")
    if _DESKTOP_STOP_RX.search(text):
        return DESKTOP_STOP_FILES
    folded = re.sub(r"[\s'\"`/\\^]+", "", text).lower()         # cua''-driver, cua\-driver, "cua"-driver ...
    folded = re.sub(r"[?*\[\]{}]", ".", folded)
    if _DESKTOP_DRIVER_RX.search(text) or re.search(r"cua.{0,4}driv|trycua", folded):
        return DESKTOP_DRIVER       # its permission repair is qosha_computer_setup(repair_permissions=true)
    return None


def _desktop_step(args: Dict[str, Any], session_id: str, tool_call_id: str, engine_ask) -> Optional[Dict[str, str]]:
    from . import desktop_use as du
    try:
        backend = du.backend_for(session_id)
        if not du.bound() and str(args.get("action") or "").lower() not in du.READS:
            return {"action": "block", "message": DESKTOP_UNCHECKED}
        v = du.judge(args, session_id, backend=backend)
        keys = du.engine_keys(args)
        du.note_activity(args, backend, v)
    except Exception:
        return {"action": "block", "message": DESKTOP_UNCHECKED}
    if "block" in v:
        return {"action": "block", "message": v["block"]}
    if v.get("run"):
        if keys and engine_ask is not None:
            engine_ask.grant(keys, tool_call_id)     # Qosha decided: the engine's technical card doesn't ask again
        return None
    kind, rows = v["kind"], v["rows"]
    title = "Qosha wants to %s" % du.KIND_TEXT[kind]
    lines = ["%s: %s" % (lab, du.clean(val, 700)) for lab, val in rows]
    if v.get("once"):
        tail = '("Always allow" is not offered for this step: %s.)' % du.ONCE_ONLY.get(kind, "Qosha asks every time")
        rule = _once(kind)
    else:
        tail = '("Always allow" covers every future action of this kind: %s.)' % du.KIND_TEXT[kind]
        rule = "qosha:" + kind
    message = "%s\n%s\n%s" % (title, "\n".join(lines), tail)
    _LAST[message] = {"title": title, "rows": [list(r) for r in rows], "session": session_id or "", "grant": keys}
    if tool_call_id:
        _CALL_GRANTS[tool_call_id] = keys
        _CU_CALLS[(_approval_key(), tool_call_id)] = (backend, v.get("sig"), v.get("gen"))
        for store in (_CALL_GRANTS, _CU_CALLS):
            if len(store) > 200:
                for key in list(store)[:100]:
                    store.pop(key, None)
    if engine_ask is not None and engine_ask.is_allowed(rule):
        du.allowed(backend, True, v.get("sig"), v.get("gen"))   # "Always allow" for this kind: the engine won't ask
        if keys:
            engine_ask.grant(keys, tool_call_id)
    return {"action": "approve", "rule_key": rule, "message": message}


def _desktop_setup_card(session_id: str, args: Any = None) -> Dict[str, str]:
    """Installing the screen-control helper, or resetting its macOS permissions, is the person's choice: a one-time
    card in plain words (council, 22 Nov; the reset never shows as a raw command, orchestrator 22 Nov)."""
    try:
        from . import desktop_api
        if isinstance(args, dict) and args.get("repair_permissions"):
            title, rows = desktop_api.REPAIR_CARD_TITLE, desktop_api.REPAIR_ROWS
        else:
            title, rows = desktop_api.SETUP_CARD_TITLE, desktop_api.SETUP_ROWS
    except Exception:
        return {"action": "block", "message": DESKTOP_UNCHECKED}
    message = "%s\n%s\n%s" % (title, "\n".join("%s: %s" % r for r in rows),
                               '("Always allow" is not offered for this step: it lets Qosha see and use your computer.)')
    _LAST[message] = {"title": title, "rows": [list(r) for r in rows], "session": session_id or "", "grant": []}
    return {"action": "approve", "rule_key": _once("desktop.setup"), "message": message}


CARD_SHOWS = 6000   # UTF-16 units of an approval the chat page shows (chat.html, function approval: whole.slice(0, 6000))


def _google_unseen(message: str) -> str:
    """Why a Google tool's card can't be approved as shown: too long for the page, or a value the page would mask."""
    no = lambda why, offer: tr("ask.gunseen.refuse", why=why, offer=offer)
    try:
        shown = len(message.encode("utf-16-le")) // 2
        disp = _as_shown(message)
        if disp is None:
            return no(tr("ask.gunseen.why.check"), tr("ask.unseen.offer.again"))
        shown = max(shown, len(disp.encode("utf-16-le")) // 2)
    except UnicodeError:
        return no(tr("ask.gunseen.why.broken"), tr("ask.unseen.offer.rewrite"))
    if shown > CARD_SHOWS:
        return no(tr("ask.gunseen.why.long", shown=shown, limit=CARD_SHOWS), tr("ask.gunseen.offer.smaller"))
    masked = _secret_masked(message)
    if masked is None or masked:
        return no(tr("ask.gunseen.why.masked"), tr("ask.gunseen.offer.without"))
    return ""


def _unseen(tool_name: str, args: Any, rows: list, message: str, kind: str = "email.send") -> str:
    """Why this email or message cannot be sent as the card shows it: the refusal for the model, or "" when it can."""
    tool, _a = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
    what = "email" if kind == "email.send" else "message"
    # Every sentence comes from the catalogs in the person's language (the assistant passes it on to them); in English
    # each is 1.19.13's own wording, byte for byte. `message` is the card as the person would see it, in their language.
    if tool in ("terminal", "execute_code", "process", "process_manage"):
        # a command or code is never read for what it would send (orchestrator, 20 Nov 2026, fail closed: the shell
        # can add text, files and recipients in more ways than a card can show; GPT and Gemini vqa/r11913e). The send
        # tool shows the person its card, so approval is always there that way.
        cmd_text = " ".join(str(_a.get(k) or "") for k in ("command", "code", "input", "data"))
        if re.search(r"ms-365-mcp-server|@softeria|graph\.microsoft\.com", cmd_text, re.I):
            return OUTLOOK_SEND_REFUSAL
        return tr("ask.unseen.shell.email") if what == "email" else tr("ask.unseen.shell.message")
    refuse = lambda why, offer: tr("ask.unseen.refuse", why=why, offer=offer)
    try:
        shown = len(message.encode("utf-16-le")) // 2   # as the page counts it (JavaScript strings: an emoji is 2)
        # the page is handed the engine's display form, where a hidden character (zero-width, bidi) is written out
        # as \u200b and so is longer (GPT vqa/r11913f rshw4 HIGH 8): the longer of the two counts
        disp = _as_shown(message)
        if disp is None:
            # the engine's display form could not be made: the card's length can't be checked, so nothing is sent
            # (GPT vqa/r11913g r5 #4, fail closed)
            return refuse(tr("ask.unseen.why.check.email") if what == "email" else tr("ask.unseen.why.check.message"),
                          tr("ask.unseen.offer.again"))
        shown = max(shown, len(disp.encode("utf-16-le")) // 2)
    except UnicodeError:
        # a broken character (an unpaired surrogate): the card cannot show it reliably (GPT vqa/rshw #5)
        return refuse(tr("ask.unseen.why.broken.email") if what == "email" else tr("ask.unseen.why.broken.message"),
                      tr("ask.unseen.offer.rewrite"))
    if shown > CARD_SHOWS:
        return refuse(tr("ask.unseen.why.long.email", shown=shown, limit=CARD_SHOWS) if what == "email" else
                      tr("ask.unseen.why.long.message", shown=shown, limit=CARD_SHOWS), tr("ask.unseen.offer.shorten"))
    masked = _secret_masked(message)
    if masked is None:
        return refuse(tr("ask.unseen.why.secret_check.email") if what == "email" else tr("ask.unseen.why.secret_check.message"),
                      tr("ask.unseen.offer.again"))
    if masked:
        # the card would show the secret masked, so two different texts could look the same (verification vqa/allowc #2)
        return tr("ask.unseen.secret.email") if what == "email" else tr("ask.unseen.secret.message")
    base = tool.lower().rsplit("__", 1)[-1]
    fwd0 = _a.get("forward_message_id") or (_a.get("message_id") if "forward" in tool.lower() else None)
    if kind == "email.send" and base == "send_gmail_message" and not fwd0 and _a.get("include_signature") is not False:
        # Gmail adds the saved signature unless told not to, and the card can't show it (verification vqa/allowc #3)
        return tr("ask.unseen.signature")
    if any(v == _NOT_TEXT for _lab, v in rows):
        return refuse(tr("ask.unseen.why.not_text.email") if what == "email" else tr("ask.unseen.why.not_text.message"),
                      tr("ask.unseen.offer.plain"))
    a = _a
    if kind == "message.send":
        # a thread, the whole channel or one person is shown on the card when its meaning is certain; otherwise the
        # message is refused with the reason (Ren, 20 Nov: "ask me instead"; GPT vqa/r11913g r5 #1)
        try:
            why = _chat_where(tool, a)[1]
        except Exception:
            why = tr("ask.unseen.why.where_check")
        if why:
            return refuse(why, tr("ask.unseen.offer.chat_plain"))
    fwd = a.get("forward_message_id") or (a.get("message_id") if "forward" in tool.lower() else None)
    if kind == "email.send" and fwd and (a.get("thread_id") or a.get("in_reply_to")):
        # a forward mixed with a reply stays refused, as on 1.19.13: the card can't show the forwarded email's own text
        # and files (GPT allowc r2 H9; GPT vqa/r11913g r5 #3)
        return refuse(tr("ask.unseen.why.fwd_reply_files"), tr("ask.unseen.offer.fwd_or_reply"))
    if kind in ("message.send", "whatsapp.send") and not (any(lab == "To" for lab, _v in rows) and
                                       any(lab.startswith("Body") or lab == "Message" for lab, _v in rows)):
        # a message is shown with where it goes and its text, or not sent (GPT vqa/r11913e rshw3 HIGH 5)
        return refuse(tr("ask.unseen.why.no_to"), tr("ask.unseen.offer.written_out"))
    return ""


def _secret_masked(message: str) -> Optional[bool]:
    """True when the engine's secret masking (as the card is shown: force=True) changes the card's text, None when it
    can't be checked (the send is then refused: fail closed)."""
    try:
        from agent.redact import redact_sensitive_text
        return str(redact_sensitive_text(message, force=True)) != message
    except Exception:
        return None


def _gchat_edit(tool_name: str, args: Any) -> bool:
    """A Google Chat step that edits a message already sent (message_name given)."""
    try:
        tool, a = _unwrap((tool_name or "").strip(), args if isinstance(args, dict) else {})
        return tool != "send_message" and tool.lower().rsplit("__", 1)[-1] == "send_message" and _given(a.get("message_name"))
    except Exception:
        return False


def _as_shown(message: str) -> Optional[str]:
    """The card's text as the engine hands it to the page (gateway: redact_approval_display), or None when the engine's
    function is not there or fails (the send is then refused: fail closed)."""
    try:
        from agent.redact import redact_approval_display
        return str(redact_approval_display(message, force=True))
    except Exception:
        return None


def _engine_send(tool: str, a: Dict[str, Any]) -> bool:
    """The engine's own send_message tool (gateway/outbound/send.py), which reads only action, target and message. Known by
    its exact name (an MCP tool is always mcp__<server>__<tool>); its arguments never change which tool it is (GPT allowc r1 #2)."""
    return tool == "send_message"


_GCHAT_KEYS = {"user_google_email", "space_id", "message_text", "thread_key", "thread_name", "message_name"}


def _given(v: Any) -> bool:
    """A Google Chat optional value as the tool reads it (_none_if_blank): None, "null"/"None" or blank = not given."""
    return isinstance(v, str) and v.strip() != "" and v.strip().lower() not in ("null", "none")


def texts_given(a: Dict[str, Any]) -> bool:
    return any(isinstance(a.get(k), str) and a.get(k) != "" for k in _BODY_KEYS)


_TS = re.compile(r"[0-9]{1,12}(\.[0-9]{1,9})?")
_KEY = re.compile(r"[A-Za-z][A-Za-z0-9_]{0,39}")


def _chat_where(tool: str, a: Dict[str, Any]) -> Tuple[list, str]:
    """Where a chat message goes beyond its channel, as card rows (a thread, the whole channel too, one person, an edit),
    and why the card can't show it ("" when it can). Ren, 20 Nov 2026 ("Yes, ask me instead"): what Qosha can show
    exactly gets the Allow card; a value whose meaning is not certain is refused with the reason. What each value does:
    Google Chat = workspace_mcp gchat send_message; Slack = Slack's own Web API meanings (chat.postMessage thread_ts and
    reply_broadcast, chat.postEphemeral user); the engine's send_message reads only its target and message."""
    rows: list = []
    has = lambda k: a.get(k) not in (None, "", [], {})
    base = tool.lower().rsplit("__", 1)[-1]
    if _engine_send(tool, a):
        notes = []
        t = a.get("target")
        if isinstance(t, str) and t.strip() and not t.partition(":")[2].strip():
            # no channel given: the engine uses that app's home channel, and its home thread when one is set
            notes.append("It goes to your home channel on %s (and into its home thread, if one is set); this card can't "
                         "show which channel that is." % t.partition(":")[0].strip())
        unused = sorted(str(k) for k in a if k not in ("action", "target", "message") and a.get(k) not in (None, "", [], {}, False))
        if unused:
            named = [k for k in unused if _KEY.fullmatch(str(k))][:8]
            notes.append("This tool uses only the place and the text above; it does not use %s." %
                         (", ".join(named) + (" or other settings given" if len(named) < len(unused) else "") if named else "the other settings given"))
        if notes:
            rows.append(("Note from Qosha", " ".join(notes)))
        return rows, ""
    gchat_keys = any(k in a for k in ("space_id", "message_text", "thread_name", "thread_key", "message_name"))
    if base == "send_message" and gchat_keys:
        # Google Chat takes only its own fields; any other one could be shown on the card in place of the space or the
        # text and then be dropped by the tool (Gemini allowc r1 #5, r2 HIGH-1)
        if any(k not in _GCHAT_KEYS for k in a):
            return rows, tr("ask.chat.why.gchat_fields")
        if not (isinstance(a.get("space_id"), str) and a["space_id"].strip() and isinstance(a.get("message_text"), str)
                and a["message_text"].strip()):
            return rows, tr("ask.chat.why.gchat_space")
        # Google Chat: a thread by name or by key (a new thread when it isn't found), or an edit of a message already sent.
        # Each value is read the way the tool reads it (blank or "null" = not given), and shown in full (GPT allowc r1 #5, #6)
        for k in ("thread_name", "thread_key", "message_name"):
            if a.get(k) is not None and not isinstance(a.get(k), str):
                return rows, tr("ask.chat.why.gchat_not_text", field=k.replace("_", " "))
        mn = a.get("message_name")
        if isinstance(mn, str) and not mn.strip():
            # the tool reads a blank message_name as an edit id and fails it (Gemini allowc r2 M1)
            return rows, tr("ask.chat.why.gchat_empty_edit")
        edit = _given(mn)
        if edit and (_given(a.get("thread_name")) or _given(a.get("thread_key"))):
            return rows, tr("ask.chat.why.gchat_edit_thread")
        if edit:
            rows.append(("Edits your message", _Own("%s (its text is replaced by the Body below)" % a["message_name"],
                                                    "ask.chat.row.edit", {"id": a["message_name"]})))
        if _given(a.get("thread_name")):
            rows.append(("In thread", _Own("%s (if Google Chat can't find that thread, it starts a new thread)" % a["thread_name"],
                                           "ask.chat.row.thread_name", {"name": a["thread_name"]})))
        elif _given(a.get("thread_key")):
            rows.append(("In thread", _Own("the thread with key %s (Google Chat starts a new thread if none has this key)" % a["thread_key"],
                                           "ask.chat.row.thread_key", {"key": a["thread_key"]})))
        return rows, ""
    if has("thread_id"):
        # which thread a chat tool's thread_id means is not known here; Slack's own field is thread_ts (GPT allowc r1 #7)
        return rows, tr("ask.chat.why.thread_id")
    rb = a.get("reply_broadcast")
    if rb is not None and not isinstance(rb, bool):
        return rows, tr("ask.chat.why.broadcast_value")
    if rb is True and a.get("thread_ts") is None:
        return rows, tr("ask.chat.why.broadcast_no_thread")
    if a.get("thread_ts") is not None:
        ts = a["thread_ts"]
        if not isinstance(ts, str) or not _TS.fullmatch(ts):
            return rows, tr("ask.chat.why.thread_ts")
        rows.append(("In thread", _Own("reply under message %s%s" % (ts, "" if rb is True else " (seen in the thread only)"),
                                       "ask.chat.row.reply_ts" if rb is True else "ask.chat.row.reply_ts_only", {"ts": ts})))
        if rb is True:
            rows.append(("Also posted to the whole channel", _Own("yes, the reply also shows in the channel", "ask.chat.row.broadcast_yes")))
    if "ephemeral" in base:
        u = a.get("user")
        if not isinstance(u, str) or not u.strip() or u != u.strip() or a.get("user_id") not in (None, u):
            return rows, tr("ask.chat.why.ephemeral_user")
        if rb is True:
            return rows, tr("ask.chat.why.ephemeral_broadcast")
        rows.append(("Only seen by", _Own("%s (nobody else in the channel sees it)" % u, "ask.chat.row.only_seen", {"who": u})))
    elif has("user"):
        return rows, tr("ask.chat.why.user")
    return rows, ""


_TEXT_KEYS = {"plain_text": {"type", "text", "emoji"}, "mrkdwn": {"type", "text", "verbatim"}}
# no "style" (bold, strike...): the card can't show it (GPT allowc r1 #8)
_RICH_KEYS = {"text": ({"type", "text"}, "text"), "link": ({"type", "url", "text"}, "url"),
              "emoji": ({"type", "name", "unicode"}, "name"), "user": ({"type", "user_id"}, "user_id"),
              "channel": ({"type", "channel_id"}, "channel_id")}


def _blocks_text(blocks: Any) -> Optional[str]:
    """Slack blocks made only of text, as the chat would show them (one line per block, in order); None when any block
    is something else (a button, an image, a field list, @here...), which the card can't show."""
    try:
        if isinstance(blocks, str):
            blocks = json.loads(blocks)
        if not isinstance(blocks, list) or not blocks or len(blocks) > 50:
            return None

        def txt(o, kinds=("plain_text", "mrkdwn")):
            if isinstance(o, dict) and o.get("type") in kinds and isinstance(o.get("text"), str) and set(o) <= _TEXT_KEYS[o["type"]]:
                return o["text"]
            return None

        def rich(els):
            parts = []
            if not isinstance(els, list):
                return None
            for e in els:
                spec = _RICH_KEYS.get(e.get("type")) if isinstance(e, dict) else None
                if not spec or not set(e) <= spec[0] or not isinstance(e.get(spec[1]), str):
                    return None
                t = e["type"]
                if t == "text":
                    parts.append(e["text"])
                elif t == "link":
                    if e.get("text") is not None and not isinstance(e.get("text"), str):
                        return None   # Gemini allowc r2 M3
                    label = e.get("text") or ""
                    parts.append("%s (%s)" % (label, e["url"]) if label else e["url"])
                elif t == "emoji":
                    parts.append(":%s:" % e["name"])
                else:
                    parts.append(("<@%s>" if t == "user" else "<#%s>") % e[spec[1]])
            return "".join(parts)

        out = []
        for b in blocks:
            if not isinstance(b, dict):
                return None
            t, extra = b.get("type"), set(b) - {"type", "block_id"}
            v = None
            if t == "header" and extra == {"text"}:
                v = txt(b["text"], ("plain_text",))
            elif t == "section" and extra == {"text"}:
                v = txt(b["text"])
            elif t == "divider" and not extra:
                v = "———"
            elif t == "context" and extra == {"elements"} and isinstance(b["elements"], list) and b["elements"]:
                parts = [txt(e) for e in b["elements"]]
                v = None if None in parts else "  ".join(parts)
            elif t == "rich_text" and extra == {"elements"} and isinstance(b["elements"], list) and b["elements"]:
                lines = []
                for sct in b["elements"]:
                    st = sct.get("type") if isinstance(sct, dict) else None
                    if st in ("rich_text_section", "rich_text_preformatted", "rich_text_quote") and set(sct) <= {"type", "elements", "border"}:
                        r = rich(sct.get("elements"))
                        if r is None:
                            return None
                        lines.append("> " + r if st == "rich_text_quote" else r)
                    elif st == "rich_text_list" and set(sct) <= {"type", "elements", "style", "border"} and isinstance(sct.get("elements"), list) and sct["elements"]:
                        for i, item in enumerate(sct["elements"]):
                            if not isinstance(item, dict) or item.get("type") != "rich_text_section" or not set(item) <= {"type", "elements"}:
                                return None
                            r = rich(item.get("elements"))
                            if r is None:
                                return None
                            lines.append(("%d. " % (i + 1) if sct.get("style") == "ordered" else "• ") + r)
                    else:
                        return None
                v = "\n".join(lines)
            if v is None:
                return None
            out.append(v)
        whole = "\n".join(out)
        # a special mention (<!channel>, <!here>, <!everyone>, <!subteam...>) notifies people the card doesn't name
        return None if "<!" in whole else whole
    except Exception:
        return None


_BODY_KEYS = ("body", "message", "text", "content", "markdown_text", "message_text", "html_body", "html", "body_html")
_NOT_TEXT = _Own("(text Qosha cannot show)", "ask.value.not_text")
NO_TEXT = _Own("(no message text)", "ask.value.no_text")
_CALL_GRANTS: Dict[str, list] = {}   # tool call -> the engine's findings to grant once the person allows that step
_GRANT_WHY: Dict[str, str] = {}      # tool call -> "now" (allowed on Qosha's card for this step) or "always"
_NOTE = re.compile(r"Command was flagged \([^\"\n]*?\) and auto-approved by [^\"\n]*?\.")


def transform_tool_result(tool_name: str = "", result: Any = None, tool_call_id: str = "", **_: Any) -> Optional[str]:
    """The engine notes on a shell step's result that its own check was "auto-approved by an approval the user gave
    earlier in this session", and Qosha repeated that to the person (17 Nov: "it went through without asking you"),
    when the person had just allowed that very step on Qosha's card. For the steps Qosha granted, the note says what
    really happened. Every other result is left as it is."""
    if tool_name == "computer_use" and isinstance(result, str):
        # only the engine's own error answers are reworded (a window's text is never changed; GPT r1 CU-16)
        try:
            res = json.loads(result)
        except Exception:
            res = None
        if isinstance(res, dict) and res.get("ok") is not True and ("error" in res or "hint" in res):
            if res.get("code") == "human_has_control":
                from . import desktop_use
                return json.dumps({"ok": False, "code": "stopped_by_person", "error": desktop_use.STOPPED})
            out, changed = dict(res), False
            for k in ("error", "hint"):
                v = out.get(k)
                if isinstance(v, str) and re.search(r"\bhermes\b|cua|trycua", v, re.I):
                    v = re.sub(r"`?\bhermes(?:\.exe)?\s+(?:computer-use|tools)\b[^`\n\"]*`?", "qosha_computer_setup",
                               v, flags=re.I)
                    v = re.sub(r"\bcom\.trycua\.driver\b|\bCua ?Driver(?:\.app)?\b|\bcua[-_]driver(?:\.exe)?\b|\btrycua\b",
                               "Qosha's screen helper", v, flags=re.I)
                    out[k], changed = re.sub(r"\bhermes\b", "Qosha", v, flags=re.I), True
            if changed:
                return json.dumps(out)
    why = _GRANT_WHY.pop(str(tool_call_id or ""), "")
    if not why or tool_name != "terminal" or not isinstance(result, str) or not _NOTE.search(result):
        return None
    text = ("The person allowed this exact step on Qosha's approval card just now." if why == "now" else
            "The person chose Always allow for this kind of step on Qosha's approval card earlier.")
    return _NOTE.sub(text, result, count=1)


def post_tool_call(tool_name: str = "", tool_call_id: str = "", **_: Any) -> None:
    """The step is over: the engine's grant given for it ends now (also ended at the start of the next step)."""
    try:
        from . import engine_ask
        engine_ask.revoke()
    except Exception:
        pass


_wa_reads_once()                  # at load: WhatsApp read cards are "Allow this time" only (R5 cut 4)
