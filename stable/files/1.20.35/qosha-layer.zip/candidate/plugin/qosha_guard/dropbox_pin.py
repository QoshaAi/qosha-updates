"""Dropbox's live tool list as Qosha last reviewed it (slice 3B, 22 Nov 2026), and the drift check against it.

Kept apart from ask.py so the Connections page can use it without loading the guard. The engine saves every
connector's live tool list after each connect (<home>/cache/mcp_schema_cache.json); when Dropbox's differs from this
pin (names, or a sha256 over the sorted {name: inputSchema}), the Dropbox tile shows one plain line. Nothing is written:
the verdict is worked out on every look (round 3 verification: no note file, so no file can be redirected).
Unknown tool names stay refused by the guard.
"""
from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Iterable

EXPECTED = frozenset("""check_job_status download_link get_file_content get_file_content_metadata get_file_metadata
get_file_request get_shared_link_metadata get_usage_and_quota list_file_requests list_file_revisions list_folder
list_restore_events list_shared_links paper_get_doc_history paper_list_recent_docs paper_read_document
run_file_content_extraction search sign_list_signature_requests who_am_i delete create_shared_link create_file copy
move create_folder create_file_request paper_apply_markdown paper_comment paper_create_document paper_edit_content
paper_edit_table paper_insert paper_insert_image restore_file_revision restore_folder sign_cancel_signature_request
sign_create_signature_request_draft sign_download_signature_request sign_send_signature_request_reminders
transform_file""".split())
SCHEMA_SHA = "f86ac18cde19eebe22fdf283c780e991648ab268fdde13f3e1da8c35599e1061"   # live 22 Nov 2026 (41 tools)


def schema_sha(tools: dict) -> str:
    return hashlib.sha256(json.dumps({n: tools[n] for n in sorted(tools)}, sort_keys=True).encode()).hexdigest()


def _linkish(p: str) -> bool:
    try:
        st = os.lstat(p)
    except OSError:
        return False
    import stat as _st
    return _st.S_ISLNK(st.st_mode) or bool(getattr(st, "st_file_attributes", 0) & 0x400)   # a link or a junction


def check(tools: Any, home: str = "") -> bool:
    """tools: {name: inputSchema} (names with or without mcp__dropbox__). True when they match the pin; False when they
    differ or can't be read. `home` is unused (kept for callers)."""
    try:
        names = {str(n)[len("mcp__dropbox__"):] if str(n).startswith("mcp__dropbox__") else str(n): v
                 for n, v in dict(tools).items()}
        return set(names) == set(EXPECTED) and schema_sha(names) == SCHEMA_SHA
    except Exception:
        return False


def check_engine_cache(home: str) -> Any:
    """The engine's saved live list for Dropbox (<home>/cache/mcp_schema_cache.json), checked: True / False, or None
    when Dropbox has no saved list yet (not connected)."""
    try:
        p = os.path.join(str(home), "cache", "mcp_schema_cache.json")
        with open(p, encoding="utf-8-sig") as fh:
            entry = (json.load(fh) or {}).get("dropbox")
    except (OSError, ValueError, AttributeError):
        return None
    if not isinstance(entry, dict):
        return None
    tools = entry.get("tools")
    if not isinstance(tools, list):
        return False
    try:
        return check({t["name"]: t.get("inputSchema") for t in tools})
    except Exception:
        return False
