"""Qosha's nightly backup (MEM1-SAFE, backup only; Ren's card 20 Nov 2026: "Nightly backup only").

Once a local day Qosha asks the engine to make its usual full backup of the person's home
(<home>/backups/qosha-daily-YYYY-MM-DD-HHMMSS.zip; the engine writes it owner-only and keeps the 7 newest). Qosha reads
and writes nothing else: no notes are read, stored or shown, and it keeps no files or locks of its own.

daily_backup() returns a dict and never raises; logs carry fixed words only.
"""
from __future__ import annotations

import datetime as _dt
import logging
import os
import re
import stat
from pathlib import Path

log = logging.getLogger("qosha.memory")

# WhatsApp's link (full account access), its local text store and the attachments the person opened never enter a
# backup (slice 5 v3, orchestrator 22 Nov 2026): after a restore the person links WhatsApp again.
NO_BACKUP_ROOTS = frozenset({"whatsapp", "whatsapp-media"})


def keep_out_of_backups(eb) -> bool:
    """Add NO_BACKUP_ROOTS to the engine's own root exclusions (this process); True when they are in place."""
    try:
        cur = getattr(eb, "_EXCLUDED_BACKUP_ROOT_DIRS")
        if not NO_BACKUP_ROOTS <= set(cur):
            eb._EXCLUDED_BACKUP_ROOT_DIRS = frozenset(set(cur) | NO_BACKUP_ROOTS)
        return NO_BACKUP_ROOTS <= set(eb._EXCLUDED_BACKUP_ROOT_DIRS)
    except Exception:
        return False


DAILY_PREFIX = "qosha-daily-"
DAILY_KEEP = 7
GOOGLE_SIGN_IN_PREFIXES = ("google_token.tmp.",)
# Every sign-in and credential the engine and Qosha keep (r1210, orchestrator 22 Nov: "Extend the same exclusion to all
# credential files"). Root entries of a home (or of profiles/<name>), credential trees, and outside Your files any file
# whose name says it holds a token or a credential (an Outlook/MSAL cache, a cookie store). After a restore the person
# signs in again (RESTORE-NOTE.txt in each backup says so).
_ROOT_SECRETS = frozenset({"auth.json", "auth.lock", ".env", ".op.env", "mcp-tokens", "vault", "pairing", "webapp",
                           "browser-profile", "browser_profiles", "whatsapp", "whatsapp-media", "honcho.json",
                           "mem0.json", "auth", ".anthropic_oauth.json", "webhook_subscriptions.json", "slack_tokens.json",
                           "feishu_comment_pairing.json", "teams_pipeline_store.json", ".copilot_jwt.json", "npmrc",
                           "chrome-debug", "browser_auth", "proxy"})
_ROOT_COPY = re.compile(r"(?i)^(auth\.json\..+|\.env\.bak.*|\.env\..+)$")
_TREE_SECRETS = (("platforms", "pairing"), ("platforms", "whatsapp", "session"), ("matrix", "store"),
                 ("platforms", "matrix", "store"), ("whatsapp", "session"), ("qosha", "appconn.key"),
                 ("qosha", "egress"), ("qosha", "connector.key"))
_SECRET_NAME = re.compile(r"(?i)(^|[_.-])(tokens?|credentials?|secrets?|msal|cookies|login data|keychain|oauth|jwt)"
                          r"([_.-]|$)|\.(key|pem|p12|pfx)$|^\.env(\..*)?$")
_CODE_DOC = (".py", ".md", ".js", ".mjs", ".cjs", ".ts", ".html", ".css", ".sh", ".ps1")
RESTORE_NOTE = ("Qosha nightly backup.\n\nSign-ins are not in this backup: no Google, Microsoft, WhatsApp or other app "
                "sign-ins, no keys (.env, auth.json). After you restore it, open Qosha and connect your apps again "
                "(Settings > Connections), and add any keys again.\n")


def _credential(rel) -> bool:
    try:
        parts = tuple(x.casefold() for x in Path(str(rel).replace("\\", "/")).parts)   # Mac and Windows ignore case
    except Exception:
        return True
    if len(parts) >= 3 and parts[0] == "profiles":
        parts = parts[2:]
    if not parts:
        return False
    if parts[0] in _ROOT_SECRETS or parts[0] in GOOGLE_SIGN_IN or parts[0].startswith(GOOGLE_SIGN_IN_PREFIXES):
        return True
    if any(parts[:len(t)] == t for t in _TREE_SECRETS):
        return True
    if len(parts) == 1 and _ROOT_COPY.match(parts[0]):
        return True
    if parts[0] == "files":
        return False                           # the person's own files are theirs, whatever their names
    try:                                       # every store the engine itself counts as a credential (r1210 r2, GPT 8)
        from hermes_cli.profiles import profile_path_is_private
        if profile_path_is_private(parts):
            return True
    except Exception:
        pass
    if parts[0] in ("skills", "plugins") or parts[-1].endswith(_CODE_DOC):
        return False                           # code and docs named after what they handle are not secrets (S5)
    return bool(_SECRET_NAME.search(parts[-1]))


def _wrap_exclusions(eb) -> bool:
    """The engine's per-file and per-folder exclusion checks also leave out every credential. False when they can't
    be wrapped: then no backup is made (never one with tokens)."""
    should, in_root = getattr(eb, "_should_exclude", None), getattr(eb, "_in_excluded_root_dir", None)
    if not callable(should) or not callable(in_root):
        return False
    if not getattr(should, "__qosha_creds__", False):
        def _should_exclude(rel_path, _o=should):
            return _credential(rel_path) or _o(rel_path)
        _should_exclude.__qosha_creds__ = True
        eb._should_exclude = _should_exclude
    if not getattr(in_root, "__qosha_creds__", False):
        def _in_excluded_root_dir(rel_path, _o=in_root):
            return _credential(rel_path) or _o(rel_path)
        _in_excluded_root_dir.__qosha_creds__ = True
        eb._in_excluded_root_dir = _in_excluded_root_dir
    return True
GOOGLE_SIGN_IN = frozenset({"google_token.json", "google_client_secret.json", "google_write_client_secret.json",
                            "google_oauth_pending.json", "google_workspace_mcp", "google_reconnect.json"})
_REPARSE = 0x400                          # FILE_ATTRIBUTE_REPARSE_POINT (symlinks, junctions, mount points)
_DAILY_NAME = re.compile(r"^qosha-daily-(\d{4})-(\d{2})-(\d{2})-(\d{6})\.zip$")


def _is_link(p) -> bool:
    """A symlink, a Windows junction or any reparse point. A missing path is not a link."""
    try:
        st = os.lstat(str(p))
    except FileNotFoundError:
        return False
    except OSError:
        return True
    return stat.S_ISLNK(st.st_mode) or bool(getattr(st, "st_file_attributes", 0) & _REPARSE)


def _zip_clean(path: Path) -> bool:
    """No member of the backup is under a WhatsApp root (any profile prefix); unreadable -> not clean."""
    import zipfile
    try:
        with zipfile.ZipFile(str(path)) as z:
            for n in z.namelist():
                parts = [p for p in re.split(r"[/\\]+", n) if p]
                if any(p in NO_BACKUP_ROOTS for p in parts):     # under any prefix (profiles, or anything else)
                    return False
        return True
    except Exception:
        return False


def _local_day(now=None) -> str:
    if isinstance(now, _dt.datetime):
        t = now if now.tzinfo is None else now.astimezone()
    elif isinstance(now, (int, float)) and not isinstance(now, bool) and now >= 0:
        t = _dt.datetime.fromtimestamp(now)
    else:
        t = _dt.datetime.now()
    return t.strftime("%Y-%m-%d")


def _zip_ok(path: Path) -> bool:
    """A real archive: it opens, holds at least one file, no name twice, and every file's checksum is right."""
    try:
        import zipfile
        with zipfile.ZipFile(str(path)) as z:
            names = [i.filename for i in z.infolist()]
            return (len(names) == len(set(names)) and any(not i.is_dir() for i in z.infolist())
                    and z.testzip() is None)
    except Exception:  # noqa: BLE001
        return False


def _unsafe(path) -> bool:
    """An archive holding any sign-in or credential entry (or one that can't be listed). The connectors session's
    HIGH 11: such a zip is never kept or taken as today's backup."""
    try:
        import zipfile
        with zipfile.ZipFile(str(path)) as z:
            return any(_credential(n.rstrip("/")) for n in z.namelist() if n.rstrip("/"))
    except Exception:  # noqa: BLE001
        return True


_CONFIG_NAME = re.compile(r"^(profiles/[^/]+/)?config\.ya?ml$")


def _scrub(v, path="", parent=""):
    """A copy of a settings value with every key or token typed into it blanked: keys the engine names as secret, and
    every value under an MCP server's env or headers. ${NAME} references stay (r1210 r2, GPT 9)."""
    from hermes_cli.config import _ENV_PLACEHOLDER_RE, _is_secret_config_key
    if isinstance(v, dict):
        out = {}
        for k, x in v.items():
            kp = "%s.%s" % (path, k) if path else str(k)
            secret = parent in ("env", "headers") or (isinstance(k, str) and _is_secret_config_key(kp))
            if secret and not isinstance(x, (dict, list, bool)) and x is not None \
                    and not _ENV_PLACEHOLDER_RE.match(str(x)):
                out[k] = ""
            else:
                out[k] = _scrub(x, kp, str(k).lower())
        return out
    if isinstance(v, list):
        return [_scrub(x, path, parent) for x in v]
    return v


def _scrub_configs(out) -> None:
    """Rewrite the archive with its settings files scrubbed. A settings file that can't be read is left out. Raises on
    any other failure (the caller then keeps no archive)."""
    import zipfile
    import yaml
    src = str(out)
    tmp = src + ".qosha-tmp"
    with zipfile.ZipFile(src) as zi, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zo:
        for info in zi.infolist():
            data = zi.read(info)
            if _CONFIG_NAME.match(info.filename):
                try:
                    data = yaml.safe_dump(_scrub(yaml.safe_load(data.decode("utf-8")) or {}), sort_keys=False,
                                          allow_unicode=True).encode("utf-8")
                except Exception:  # noqa: BLE001
                    continue
            zo.writestr(info, data)
    os.chmod(tmp, stat.S_IMODE(os.stat(src).st_mode))      # owner-only, as the engine made it (S6)
    os.replace(tmp, src)


def _verify_scrubbed(src_infos, tmp) -> bool:
    """The rewritten archive opens, passes its checksum test, and holds exactly the kept entries with the same
    checksums, sizes and dates."""
    import zipfile
    try:
        with zipfile.ZipFile(tmp) as z:
            if z.testzip() is not None:
                return False
            got = {i.filename: (i.CRC, i.file_size, i.date_time) for i in z.infolist()}
        return got == {i.filename: (i.CRC, i.file_size, i.date_time) for i in src_infos}
    except Exception:  # noqa: BLE001
        return False


def _scrub_archive(path) -> str:
    """One existing daily backup without its sign-in and credential entries (orchestrator 22 Nov 03:07): written to a
    temporary file beside it, verified, then put in its place; the mode and dates of the file are kept. Nothing else
    in it changes; a backup is never removed. "clean", "scrubbed" or "kept" (left as it was)."""
    import shutil
    import zipfile
    p = str(path)
    tmp = p + ".qosha-tmp"
    try:
        st = os.lstat(p)
        if not stat.S_ISREG(st.st_mode) or getattr(st, "st_file_attributes", 0) & _REPARSE:
            return "kept"
        with zipfile.ZipFile(p) as zi:
            infos = zi.infolist()
            keep = [i for i in infos if not (i.filename.rstrip("/") and _credential(i.filename.rstrip("/")))]
            if len(keep) == len(infos):
                return "clean"
            with zipfile.ZipFile(tmp, "w") as zo:
                for i in keep:
                    if i.is_dir():
                        zo.writestr(i, b"")
                        continue
                    with zi.open(i) as src, zo.open(i, "w", force_zip64=i.file_size > 2 ** 31) as dst:
                        shutil.copyfileobj(src, dst, 1 << 20)
        if not _verify_scrubbed(keep, tmp):
            raise RuntimeError("not verified")
        os.chmod(tmp, stat.S_IMODE(st.st_mode))
        os.utime(tmp, ns=(st.st_atime_ns, st.st_mtime_ns))
        os.replace(tmp, p)
        return "scrubbed"
    except Exception:  # noqa: BLE001
        try:
            os.unlink(tmp)
        except OSError:
            pass
        log.warning("Qosha nightly backup: an older backup still holds sign-ins; tried again later")
        return "kept"


def scrub_old_backups(home) -> dict:
    """Every existing daily backup (and any set aside as unsafe) loses its sign-in and credential entries; the rest of
    each is untouched. Run at the start of each nightly pass."""
    out = {"scrubbed": 0, "kept": 0}
    try:
        b = Path(os.path.expanduser(str(home))) / "backups"
        if _is_link(b.parent) or _is_link(b) or not b.is_dir():
            return out
        for n in sorted(os.listdir(str(b))):
            if n.startswith(DAILY_PREFIX) and (n.endswith(".zip") or n.endswith(".zip.qosha-unsafe")):
                try:                       # a backup readable by others is made owner-only (S6)
                    st = os.lstat(str(b / n))
                    if os.name != "nt" and stat.S_ISREG(st.st_mode) and st.st_mode & 0o077:
                        os.chmod(str(b / n), stat.S_IMODE(st.st_mode) & 0o700)
                except OSError:
                    pass
                r = _scrub_archive(b / n)
                if r in out:
                    out[r] += 1
                if r in ("clean", "scrubbed") and n.endswith(".qosha-unsafe"):
                    back = b / n[:-len(".qosha-unsafe")]       # clean now: its own name back, if free (S7)
                    if not os.path.lexists(str(back)):
                        try:
                            os.rename(str(b / n), str(back))
                        except OSError:
                            pass
    except Exception:  # noqa: BLE001
        log.warning("Qosha nightly backup: older backups not checked this time")
    return out


def _set_aside(path, remove=False) -> None:
    """Out of the daily backups' names: removed when asked, else (or if removal fails) renamed .qosha-unsafe."""
    p = str(path)
    if remove:
        try:
            os.unlink(p)
            return
        except OSError:
            pass
    try:
        os.replace(p, p + ".qosha-unsafe")
    except OSError:
        log.warning("Qosha nightly backup: an unsafe copy could not be set aside")


def _made_today(b: Path, days) -> bool:
    """Today's copy exists only when a plain file named for today really opens; a damaged one never stands in."""
    try:
        names = os.listdir(str(b))
    except OSError:
        return False
    for n in names:
        m = _DAILY_NAME.match(n)
        if not m or "%s-%s-%s" % m.groups()[:3] not in days:
            continue
        try:
            st = os.lstat(str(b / n))
        except OSError:
            continue
        if stat.S_ISREG(st.st_mode) and not getattr(st, "st_file_attributes", 0) & _REPARSE and st.st_size > 0 \
                and _zip_ok(b / n):
            if _unsafe(b / n):            # an older copy with sign-ins in it: set aside, never today's backup
                _set_aside(b / n)
                continue
            return True
    return False


def daily_backup(home, now=None) -> dict:
    """At most one nightly backup per local day, made by the engine's own full-backup code."""
    try:
        if not home:
            return {"ok": False, "status": "unavailable"}
        h = Path(os.path.expanduser(str(home)))
        b = h / "backups"
        if _is_link(h) or _is_link(b):
            return {"ok": False, "status": "refused"}
        try:
            from hermes_cli import backup as eb
            make = getattr(eb, "_create_prefixed_full_backup")
            if not keep_out_of_backups(eb):
                return {"ok": False, "status": "unavailable"}   # never a backup that would carry the WhatsApp link
            probe = getattr(eb, "_backup_operation_lock")
            busy_err = getattr(eb, "BackupInProgressError", None)
        except (ImportError, AttributeError):
            return {"ok": False, "status": "unavailable"}
        try:
            with probe(h):                # another backup running now: leave it, try on a later pass
                scrub_old_backups(h)      # older backups lose their sign-ins, under the engine's backup lock
        except TypeError:
            return {"ok": False, "status": "unavailable"}
        except Exception as exc:  # noqa: BLE001
            if busy_err is not None and isinstance(exc, busy_err):
                return {"ok": False, "status": "busy"}
            raise
        if _made_today(b, {_local_day(now), _local_day(None)}):
            return {"ok": True, "status": "exists"}
        try:
            # the Google sign-in files never go into a backup (1.20.9, CONTRACT-GEXEC)
            ex = getattr(eb, "_EXCLUDED_BACKUP_ROOT_DIRS", None)
            if ex is None or not _wrap_exclusions(eb):
                return {"ok": False, "status": "unavailable"}
            eb._EXCLUDED_BACKUP_ROOT_DIRS = frozenset(ex) | GOOGLE_SIGN_IN
            pre = getattr(eb, "_EXCLUDED_PREFIXES", None)
            if isinstance(pre, tuple) and not set(GOOGLE_SIGN_IN_PREFIXES) <= set(pre):
                eb._EXCLUDED_PREFIXES = pre + GOOGLE_SIGN_IN_PREFIXES
            out = make(h, DAILY_PREFIX, DAILY_KEEP, "daily", "daily backup")
        except (TypeError, ImportError):
            return {"ok": False, "status": "unavailable"}
        if not out:
            return {"ok": False, "status": "failed"}
        try:
            _scrub_configs(out)
        except Exception:  # noqa: BLE001
            _set_aside(out, remove=True)
            try:
                os.unlink(str(out) + ".qosha-tmp")
            except OSError:
                pass
            return {"ok": False, "status": "failed"}
        if _unsafe(out) or not _zip_clean(Path(out)):   # a sign-in or WhatsApp (any prefix, F10): never kept
            _set_aside(out, remove=True)
            return {"ok": False, "status": "failed"}
        try:
            import zipfile
            with zipfile.ZipFile(str(out), "a") as zf:
                if "RESTORE-NOTE.txt" not in zf.namelist():
                    zf.writestr("RESTORE-NOTE.txt", RESTORE_NOTE)
        except Exception:
            pass
        name = Path(out).name
        return {"ok": True, "status": "made", "name": name if _DAILY_NAME.match(name) else "a nightly copy"}
    except Exception:  # noqa: BLE001
        log.warning("Qosha nightly backup not made this time")
        return {"ok": False, "status": "failed"}
