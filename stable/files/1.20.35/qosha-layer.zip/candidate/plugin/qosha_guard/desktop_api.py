"""Qosha uses the person's computer: setup on request, status, Stop and "Let Qosha continue" (cu20, 22 Nov 2026).

Council (GPT-6.2 Astra, Gemini 4 Neon), 22 Nov: the screen-control helper (cua-driver) is installed only when the person
asks (the Qosha window's button, or Qosha's own setup step, which asks first on a one-time card); Stop holds until the
person lifts it; only the Qosha app window can lift it or start the setup (approval_gate).

Routes, under /api/plugins/qosha/desktop:
  GET  /status     installed?, ready (Mac: both permissions on)?, stopped?, what Qosha did last and when
  POST /stop       any Qosha page: Qosha's own flag + the engine's "person has control" lease (every computer_use step,
                   captures included, is refused; a running one's result is thrown away)
  POST /continue   the Qosha app window only: lifts both
  POST /setup      the Qosha app window only: installs the engine's pinned, fingerprint-checked cua-driver; on a Mac
                   opens the two permission requests (Accessibility, Screen Recording) for the person to turn on
The AI's own step: the tool `qosha_computer_setup` (same install), carded by ask.py before it runs.
"""
from __future__ import annotations

import contextlib
import io
import json
import os
import subprocess
import sys
import threading
import time
from typing import Any, Dict

try:
    from . import desktop_use as du
except ImportError:                    # loaded on its own by the dashboard (plugin_api.py): its sibling, by path
    import importlib.util as _ilu
    _spec = _ilu.spec_from_file_location("qosha_desktop_use", os.path.join(os.path.dirname(__file__), "desktop_use.py"))
    du = _ilu.module_from_spec(_spec)
    sys.modules["qosha_desktop_use"] = du
    _spec.loader.exec_module(du)

STOP_VIEWER = "qosha-stop"
ACTIVE_SECONDS = 120
_SETUP = {"state": "idle", "say": "", "at": 0.0}
_SETUP_LOCK = threading.Lock()
SETUP_CARD_TITLE = "Qosha wants to set up using apps on your computer"
SETUP_ROWS = [
    ("What happens", "Qosha downloads its screen helper (checked against a fixed fingerprint) and, on a Mac, "
                     "opens two permission requests (Accessibility and Screen Recording) for you to turn on. macOS "
                     "shows the helper under its maker's name."),
    ("After that", "When you ask, Qosha can look at your screen and click and type in apps. It asks you first before "
                   "anything is sent, paid, deleted, shared or confirmed, and you can press Stop at any time."),
]


def _write_flag(data: Dict[str, Any]) -> None:
    p = du.stop_path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    import uuid
    tmp = "%s.%s.tmp" % (p, uuid.uuid4().hex)
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(data, fh)
    os.replace(tmp, p)


def _flag_saved() -> bool:
    """The flag is really on disk and says stopped (an unreadable flag counts as stopped elsewhere, not as proof)."""
    try:
        with open(du.stop_path(), encoding="utf-8") as fh:
            return json.load(fh).get("stopped") is True
    except Exception:
        return False


def stop() -> Dict[str, Any]:
    """The person's Stop. Qosha's flag first (never expires), then the engine's lease; either one alone refuses."""
    errors = []
    try:
        _write_flag({"stopped": True, "at": time.time()})
    except Exception as exc:
        errors.append(exc)
    try:                                   # the engine's lease too, whatever happened to the flag (Gemini r1 CU-7)
        from tools.bot_desktop import lease
        lease.acquire(STOP_VIEWER, reason="The person pressed Stop in Qosha.")
    except Exception as exc:
        errors.append(exc)
    if not _flag_saved():                   # only the machine-wide flag stops every profile: say it failed (GPT r2 R2-3)
        raise RuntimeError("Stop could not be saved")
    return status()


def resume() -> Dict[str, Any]:
    try:
        from tools.bot_desktop import lease
        lease.release(STOP_VIEWER)
    except Exception:
        pass
    try:
        os.remove(du.stop_path())
    except FileNotFoundError:
        pass
    except OSError:
        _write_flag({"stopped": False, "at": time.time()})
    return status()


NOTICES = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "THIRD-PARTY-NOTICES.md")


def notice_path() -> str:
    """Beside the helper, never inside it: the engine's package manager re-checks a digest of the helper's own folder,
    so a file added there would make it look damaged. <Qosha home>/qosha/third-party/ goes with the install."""
    return os.path.join(du._home(), "qosha", "third-party", "cua-driver-LICENSE.txt")


def ensure_notice() -> bool:
    """The helper's MIT copyright notice and license, copied from Qosha's own notices file (license requirement)."""
    try:
        with open(NOTICES, encoding="utf-8") as fh:
            text = fh.read()
        i = text.index("MIT License")
        body = text[i:text.index("```", i)].rstrip() + "\n"
        p = notice_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        try:
            with open(p, encoding="utf-8") as fh:
                if fh.read() == body:
                    return True
        except OSError:
            pass
        tmp = "%s.%d.tmp" % (p, os.getpid())
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(body)
        os.replace(tmp, p)
        return True
    except Exception:
        return False


def installed() -> bool:
    try:
        from tools.computer_use.cua_backend_driver import cua_driver_binary_available
        return bool(cua_driver_binary_available())
    except Exception:
        return False


def _activity() -> Dict[str, Any]:
    try:
        with open(du.activity_path(), encoding="utf-8") as fh:
            rec = json.load(fh)
        age = time.time() - float(rec.get("at") or 0)
        return {"active": 0 <= age < ACTIVE_SECONDS, "seconds_ago": int(max(age, 0)),
                "app": du.clean(rec.get("app"), 80), "action": du.clean(rec.get("action"), 30),
                "result": du.clean(rec.get("result"), 10)}
    except Exception:
        return {"active": False}


_PROBE: Dict[str, Any] = {"at": 0.0, "st": None}


def _probe() -> Dict[str, Any]:
    """The engine's readiness check (it runs cua-driver), at most every 10 s."""
    if _PROBE["st"] is None or time.monotonic() - _PROBE["at"] > 30:
        from tools.computer_use.permissions import computer_use_status
        _PROBE.update(st=computer_use_status(), at=time.monotonic())
    return dict(_PROBE["st"] or {})


def status(probe: bool = False) -> Dict[str, Any]:
    out = {"platform": sys.platform, "installed": installed(), "stopped": du.stopped(), "activity": _activity(),
           "setup": dict(_SETUP), "ready": None, "needs": []}
    if probe and out["installed"]:
        try:
            st = _probe()
            out["ready"] = st.get("ready")
            if sys.platform == "darwin" and out["ready"] is not True:
                # a permission not confirmed on counts as needed: until the helper has run once macOS can't even be
                # asked (cua-driver reports "unknown"), and that is when the person needs the hint most
                out["needs"] = [name for key, name in (("accessibility", "Accessibility"),
                                                       ("screen_recording", "Screen Recording")) if st.get(key) is not True]
        except Exception:
            out["ready"] = None
    return out


def _open_mac_prompts() -> None:
    """macOS shows its own permission requests for CuaDriver (the engine's grant command, in the background)."""
    if sys.platform != "darwin":
        return
    try:
        from tools.computer_use.cua_backend_driver import resolve_cua_driver_cmd
        from tools.computer_use.permissions import _child_env
        binary = resolve_cua_driver_cmd()
        if binary:
            subprocess.Popen([binary, "permissions", "grant"], env=_child_env(), stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    except Exception:
        pass


def install() -> Dict[str, Any]:
    """The engine's own pinned install (PM pin cua-driver 0.21.0, sha256-checked; Mac: the signed CuaDriver.app is
    checked and registered). Plain words back, never the engine's console text."""
    with _SETUP_LOCK:
        _SETUP.update(state="installing", say="Setting up…", at=time.time())
        ok, err = False, ""
        try:
            from hermes_cli.tools_config_cua import install_cua_driver
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                ok = bool(install_cua_driver(upgrade=False, show_installer_progress=False))
        except Exception as exc:
            err = type(exc).__name__
        if not ok or not installed():
            say = ("Qosha couldn't set up its screen-control helper (%s). Check the internet connection and try again."
                   % (err or "the download or its check failed"))
            _SETUP.update(state="failed", say=say, at=time.time())
            return {"ok": False, "say": say}
        ensure_notice()
        _open_mac_prompts()
        _PROBE["st"] = None
        st = status(probe=True)
        if sys.platform == "darwin" and st.get("ready") is not True:
            say = ("Set up. macOS now asks two permissions for Qosha's screen helper (macOS shows it under its "
                   "maker's name): choose Open System Settings and turn it on under Accessibility and under Screen "
                   "& System Audio Recording. Then ask Qosha again.")
        elif sys.platform == "win32":
            say = ("Set up. Windows needs no extra permission. Qosha can't click in windows that were opened \"as "
                   "administrator\".")
        else:
            say = "Set up. Qosha can now use apps on this computer when you ask."
        _SETUP.update(state="done", say=say, at=time.time())
        return {"ok": True, "say": say, "status": st}


# ---- the AI's own setup step (carded first by ask.py) --------------------------------------------------------------
SCHEMA = {"name": "qosha_computer_setup",
          "description": ("Set up Qosha's ability to use apps on this computer (look at the screen, click and type; "
                          "Qosha still asks the person before anything is sent, paid, deleted, shared or confirmed). "
                          "Use it once, when the person asks Qosha to do something in an app on their computer and "
                          "the computer_use tool is not available yet. On a Mac, with repair_permissions=true, it "
                          "resets the screen helper's two permissions so macOS asks again (when System Settings shows "
                          "them on but Qosha still can't see or click). The person approves it on a card first."),
          "parameters": {"type": "object", "properties": {
              "repair_permissions": {"type": "boolean",
                                     "description": "Mac only: reset the screen helper's permissions and ask again."}},
              "required": []}}
REPAIR_CARD_TITLE = "Qosha wants to reset its screen helper's permissions"
REPAIR_ROWS = [("What happens", "Qosha removes its screen helper's Accessibility and Screen Recording permissions, then "
                                "macOS asks for them again; you turn them on once more (the stored permission no longer "
                                "matches the helper, which happens after an update).")]
_HELPER_ID = "com.trycua.driver"     # the helper's bundle id (macOS keys its permissions to it); never shown


def repair() -> Dict[str, Any]:
    """Reset the helper's two macOS permissions (only takes access away), then let macOS ask again."""
    if sys.platform != "darwin":
        return {"ok": False, "say": "Only a Mac has these permissions; nothing to reset here."}
    ok = True
    for service in ("Accessibility", "ScreenCapture"):
        try:
            r = subprocess.run(["/usr/bin/tccutil", "reset", service, _HELPER_ID], stdin=subprocess.DEVNULL,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
            ok = ok and r.returncode == 0
        except Exception:
            ok = False
    if not ok:
        return {"ok": False, "say": "Qosha couldn't reset its screen helper's permissions. Try again, or remove it "
                                    "in System Settings > Privacy & Security and turn it on again."}
    _PROBE["st"] = None
    _open_mac_prompts()
    return {"ok": True, "say": "Reset. macOS asks again for Qosha's screen helper (it shows its maker's name): turn it "
                               "on under Accessibility and under Screen & System Audio Recording."}


def _handler(args=None, **_kw) -> str:
    if du.stopped():
        return json.dumps({"ok": False, "say": du.STOPPED})
    if isinstance(args, dict) and args.get("repair_permissions"):
        return json.dumps(repair())
    return json.dumps(install())


def register(ctx) -> None:
    try:
        if installed():
            ensure_notice()        # a helper set up before this release gets its notice too
    except Exception:
        pass
    ctx.register_tool(name="qosha_computer_setup", toolset="qosha", schema=SCHEMA, handler=_handler,
                      check_fn=lambda: not installed() or sys.platform == "darwin",
                      description=SCHEMA["description"], emoji="🖥️")


# ---- routes ---------------------------------------------------------------------------------------------------------
def _gate():
    """Qosha's approval gate (the owner check of the app window), loaded the same way as this module."""
    try:
        from . import approval_gate as g
        return g
    except ImportError:
        import importlib.util as _ilu
        mod = sys.modules.get("qosha_approval_gate_for_desktop")
        if mod is None:
            spec = _ilu.spec_from_file_location("qosha_approval_gate_for_desktop",
                                                os.path.join(os.path.dirname(__file__), "approval_gate.py"))
            mod = _ilu.module_from_spec(spec)
            sys.modules["qosha_approval_gate_for_desktop"] = mod
            spec.loader.exec_module(mod)
        return mod


def from_window(scope) -> bool:
    """Only the Qosha app window may lift Stop or set this up (checked here too, not only in the gate; GPT r1 CU-12)."""
    try:
        return bool(_gate().from_qosha_window(scope))
    except Exception:
        return False


WINDOW_ONLY = {"ok": False, "say": "Open the Qosha app to do this: only the Qosha app window can let Qosha use the "
                                   "computer again or set it up."}

try:
    from fastapi import APIRouter, Request
    from fastapi.responses import JSONResponse
    router = APIRouter()

    @router.get("/status")
    def _status(probe: int = 0):
        return status(probe=bool(probe))

    @router.post("/stop")
    def _stop():
        try:
            return stop()
        except Exception:
            return JSONResponse(status_code=500, content={"ok": False, "say": "Stop could not be saved. Try again."})

    @router.post("/continue")
    def _continue(request: Request):
        if not from_window(request.scope):
            return JSONResponse(status_code=403, content=WINDOW_ONLY)
        return resume()

    @router.post("/setup")
    def _setup(request: Request):
        if not from_window(request.scope):
            return JSONResponse(status_code=403, content=WINDOW_ONLY)
        if du.stopped():
            return {"ok": False, "say": "Press \"Let Qosha continue\" first."}
        if _SETUP.get("state") == "installing":
            return {"ok": True, "say": _SETUP.get("say"), "busy": True}
        threading.Thread(target=install, name="qosha-desktop-setup", daemon=True).start()
        return {"ok": True, "say": "Setting up…", "busy": True}
except Exception:                      # no web framework in this process (the gateway): routes aren't needed here
    router = None
