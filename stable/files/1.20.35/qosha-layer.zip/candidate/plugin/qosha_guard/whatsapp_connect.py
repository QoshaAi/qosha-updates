"""WhatsApp for Qosha on the person's computer (slice 5 v3, 22 Nov 2026).

Qosha links the person's WhatsApp with WhatsApp's own "Link a device" QR, using Qosha's copy of the engine's bridge
(home/tools/qosha-whatsapp, made by whatsapp/patch_bridge.py). The engine's auto-reply gateway never runs: Qosha starts
the bridge itself, with every engine intake policy off, and talks to it over loopback with a fresh secret. Reading and
sending go only through Qosha's tools (whatsapp_tools.py); every send is approved on a card first. If WhatsApp warns or
signs Qosha out, the bridge stops and Qosha never links again by itself.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable, Dict, Optional

WIN = os.name == "nt"
BRIDGE_REL = Path("tools") / "qosha-whatsapp" / "bridge.js"
ENV_KEEP = ("PATH", "HOME", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "SystemRoot", "SYSTEMROOT", "WINDIR", "TEMP",
            "TMP", "TMPDIR", "LANG", "LC_ALL", "LC_CTYPE", "ComSpec", "PATHEXT")
LINK_SECONDS = 180
READY_SECONDS = 20
HTTP_TIMEOUT = 30
DEFAULTS = {"min_seconds": 120, "daily_max": 20}

NOT_LOCAL = "WhatsApp works only in the Qosha on this computer."
BACKUP_FIRST = "Back up your WhatsApp chats first (WhatsApp > Settings > Chats > Chat backup), then link."
STOPPED = ("WhatsApp warned or signed Qosha out, so Qosha stopped and won't link again by itself. Check your phone; to "
           "link again, press Disconnect, then Connect.")
NOT_SET_UP = "WhatsApp isn't set up in this Qosha yet. Reinstall Qosha's apps."
LINK_FAILED = "WhatsApp's link didn't finish. Press Connect to try again."
NOT_STOPPED = "Qosha couldn't stop its WhatsApp link. Close Qosha and try again."
UNSURE = ("Qosha can't tell whether its last WhatsApp link is still running. Restart the computer, then try again. "
          "Nothing was changed.")
LINKED_FILES = "WhatsApp's link files are still on this computer. Press Disconnect first, then Connect."
LINK_BUSY = "WhatsApp is already being linked in another Qosha window. Finish or cancel it there first."
NOT_REMOVED = "Qosha couldn't remove the WhatsApp link from this computer. Close Qosha and try again."
FOLDER_BAD = "Qosha's WhatsApp folder on this computer isn't a plain folder. Nothing was done."

RUNNER: Callable[..., Any] = subprocess.Popen
NOW: Callable[[], float] = time.time
_LOCK = threading.RLock()
_LINKS: Dict[str, Dict[str, Any]] = {}          # link id -> pairing state
_LINKING: Dict[str, str] = {}                     # home -> link id in progress
_PROCS: Dict[int, Any] = {}                       # pid -> the bridge process this Qosha started (reaped on stop)


# ---- where things are --------------------------------------------------------------------------------------------
def local() -> bool:
    return not (os.environ.get("QOSHA_BOX") or os.environ.get("QOSHA_LAB") or os.environ.get("QOSHA_CONNECTOR_URL"))


def wa_dir(home) -> Path:
    return Path(home) / "whatsapp"


def session_dir(home) -> Path:
    return wa_dir(home) / "session"


def store_dir(home) -> Path:
    return wa_dir(home) / "store"


def media_dir(home) -> Path:
    """Attachments the person asked Qosha to open (photos, documents, voice notes): a folder they can see."""
    return Path(home) / "whatsapp-media"


def run_file(home) -> Path:
    return wa_dir(home) / "run.json"


def token_file(home) -> Path:
    return session_dir(home) / ".bridge-token"


def bridge_path(home) -> Optional[str]:
    """Qosha's bridge.js, only when no part of its path below the home is a link (F5)."""
    cur = Path(home)
    for part in BRIDGE_REL.parts:
        cur = cur / part
        if _is_link(cur):
            return None
    return str(cur) if cur.is_file() else None


def _is_link(p) -> bool:
    try:
        return os.path.islink(p) or bool(getattr(os.lstat(p), "st_file_attributes", 0) & 0x400)
    except OSError:
        return False


def _unsafe(p) -> bool:
    """A link or junction, or a file with more than one hard link (R5 fix 5); missing is fine, unreadable is not."""
    try:
        st = os.lstat(p)
    except FileNotFoundError:
        return False
    except OSError:
        return True
    import stat as _st
    return (_st.S_ISLNK(st.st_mode) or bool(getattr(st, "st_file_attributes", 0) & 0x400)
            or (_st.S_ISREG(st.st_mode) and st.st_nlink > 1))


def media_file_ok(home, path: Any) -> bool:
    """A downloaded attachment Qosha hands out: a plain single-link file directly in home/whatsapp-media, with no link
    on the way (checked when it is opened, R5 fix 5)."""
    try:
        p = Path(str(path))
        md = media_dir(home)
        if _unsafe(md) or _unsafe(p.parent) or _unsafe(p) or not p.is_file():
            return False
        # the same folder however its path is spelled (e.g. /var and /private/var on a Mac), never another one
        return os.path.normcase(os.path.realpath(str(p.parent))) == os.path.normcase(os.path.realpath(str(md)))
    except Exception:
        return False


def _folders(home):
    s = store_dir(home)
    return (wa_dir(home), session_dir(home), s, s / "messages", s / "media", media_dir(home))


def folder_ok(home) -> bool:
    """home/whatsapp, its parts below (messages, media) and whatsapp-media are real folders inside this home (or not
    there yet), never links (F6)."""
    for p in _folders(home):
        if _is_link(p) or (os.path.lexists(p) and not os.path.isdir(p)):
            return False
    return True


def _icacls(path: str) -> bool:
    user = os.environ.get("USERNAME") or ""
    if not user:
        return False
    r = subprocess.run(["icacls", path, "/inheritance:r", "/grant:r", "%s:(OI)(CI)F" % user], capture_output=True,
                       timeout=30, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return r.returncode == 0


ICACLS: Callable[[str], bool] = _icacls
_OWNER_ONLY: set = set()


def _owner_only(p: Path) -> None:
    """Owner-only access, verified (F6): 0700 on macOS/Linux; on Windows inheritance removed, the person alone."""
    if WIN:
        key = os.path.normcase(str(p))
        if key not in _OWNER_ONLY:
            if not ICACLS(str(p)):
                raise OSError("could not make the folder owner-only")
            _OWNER_ONLY.add(key)
        return
    os.chmod(p, 0o700)
    if os.stat(p).st_mode & 0o077:
        raise OSError("folder is readable by others")


def _mkdirs(home) -> None:
    if not folder_ok(home):
        raise OSError("not a plain folder")
    for p in (wa_dir(home), session_dir(home), store_dir(home)):
        p.mkdir(parents=True, exist_ok=True)
    for p in (wa_dir(home), media_dir(home)):
        p.mkdir(parents=True, exist_ok=True)
        _owner_only(p)


def node_path(home) -> Optional[str]:
    try:
        from .microsoft_connect import node_path as _np
    except ImportError:
        import importlib.util
        spec = importlib.util.spec_from_file_location("qosha_mc_for_wa", Path(__file__).with_name("microsoft_connect.py"))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        _np = m.node_path
    return _np(home)


def _plain_file(p) -> bool:
    """A regular file that is not a link (F6)."""
    return os.path.lexists(p) and not _is_link(p) and os.path.isfile(p)


def files_ok(home) -> bool:
    """No file Qosha reads or deletes under session/ and store/ is a link (F6)."""
    for p in (session_dir(home) / "creds.json", token_file(home), store_dir(home) / "chats.json",
              store_dir(home) / "sends.json", store_dir(home) / "settings.json", store_dir(home) / "stopped.json",
              store_dir(home) / "link-id", store_dir(home) / "sync.json", store_dir(home) / "clear.json", run_file(home)):
        if _unsafe(p):
            return False
    return no_links_below(home)


def no_links_below(home) -> bool:
    """Every file and folder below home/whatsapp and home/whatsapp-media, at any depth (message and media leaves
    included), is a real file or folder, never a link or junction (R4 #9). An unreadable folder counts as not ok."""
    for top in (wa_dir(home), media_dir(home)):
        if not os.path.lexists(top):
            continue
        if _is_link(top):
            return False
        bad = []
        for dirpath, dirnames, filenames in os.walk(str(top), followlinks=False, onerror=lambda e: bad.append(e)):
            for n in dirnames + filenames:
                if _unsafe(os.path.join(dirpath, n)):          # links and multi-linked files (R5 fix 5)
                    return False
        if bad:
            return False
    return True


def linked(home) -> bool:
    return folder_ok(home) and files_ok(home) and _plain_file(session_dir(home) / "creds.json")


def stopped(home) -> str:
    """The reason WhatsApp stopped Qosha ("" when it didn't)."""
    try:
        v = json.loads((store_dir(home) / "stopped.json").read_text(encoding="utf-8"))
        return str(v.get("reason") or "stopped") if isinstance(v, dict) else "stopped"
    except FileNotFoundError:
        return ""
    except Exception:
        return "stopped"


def _write_json(p: Path, data, mode=0o600) -> None:
    tmp = p.with_name(".%s.%s.tmp" % (p.name, secrets.token_hex(6)))
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), mode)
    try:
        raw = json.dumps(data).encode("utf-8")
        with os.fdopen(fd, "wb") as fh:
            fh.write(raw)
        os.replace(str(tmp), str(p))
    except BaseException:
        try:
            os.unlink(str(tmp))
        except OSError:
            pass
        raise


def child_env(home, token: str = "") -> Dict[str, str]:
    env = {k: os.environ[k] for k in ENV_KEEP if k in os.environ}
    env.update({"WHATSAPP_MODE": "bot", "WHATSAPP_DM_POLICY": "disabled", "WHATSAPP_GROUP_POLICY": "disabled",
                "WHATSAPP_ALLOWED_USERS": "", "WHATSAPP_GROUP_ALLOWED_USERS": "", "WHATSAPP_REPLY_PREFIX": "",
                "WHATSAPP_SEND_READ_RECEIPTS": "false", "WHATSAPP_FORWARD_OWNER_MESSAGES": "false",
                "QOSHA_WA_STORE": str(store_dir(home)), "QOSHA_WA_MEDIA": str(media_dir(home))})
    if token:
        env["HERMES_WHATSAPP_BRIDGE_TOKEN"] = token
    return env


def _popen_kw(home, token="", stdout=subprocess.DEVNULL):
    kw = {"stdin": subprocess.DEVNULL, "stdout": stdout, "stderr": subprocess.DEVNULL, "env": child_env(home, token),
          "shell": False, "cwd": str(Path(bridge_path(home) or ".").parent)}
    if stdout is subprocess.PIPE:
        kw["text"] = True
    if WIN:
        kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    else:
        kw["start_new_session"] = True
    return kw


def _refused(plain: str, code: str) -> Dict[str, Any]:
    return {"ok": False, "error": code, "plain": plain}


# ---- linking (WhatsApp's own QR) ---------------------------------------------------------------------------------
_SVG_BAD = re.compile(r"<\s*script|\son[a-z]+\s*=|href|<\s*foreignObject|javascript:", re.I)


def safe_svg(svg: Any) -> str:
    s = svg if isinstance(svg, str) else ""
    return s if s.startswith("<svg") and len(s) < 200000 and not _SVG_BAD.search(s) else ""


def number_of(user_id: Any) -> str:
    s = str(user_id or "")
    head = re.split(r"[:@]", s, maxsplit=1)[0]
    return head if head.isdigit() else ""


def _remove_tree(p: Path) -> bool:
    if not os.path.lexists(p):
        return True
    if _is_link(p):
        try:
            os.unlink(p)
        except OSError:
            return False
        return not os.path.lexists(p)
    shutil.rmtree(p, ignore_errors=True)
    return not os.path.lexists(p)


def _link_reader(state) -> None:
    try:
        for line in state["proc"].stdout:
            line = line.strip()
            if not line.startswith("{"):
                continue
            try:
                ev = json.loads(line)
            except Exception:
                continue
            if not isinstance(ev, dict):
                continue
            kind = ev.get("event")
            with _LOCK:
                if state["status"] not in ("starting", "waiting"):
                    continue
                if kind == "qr":
                    svg = safe_svg(ev.get("svg"))
                    if svg:
                        state.update(status="waiting", qr_svg=svg)
                elif kind == "connected":
                    try:                        # a new link generation: earlier read grants no longer count (F9)
                        store_dir(state["home"]).mkdir(parents=True, exist_ok=True)
                        _write_json(store_dir(state["home"]) / "link-id", {"id": secrets.token_hex(16)})
                    except OSError:
                        pass
                    user = ev.get("user") if isinstance(ev.get("user"), dict) else {}
                    state.update(status="linked", number=number_of(user.get("id")),
                                 name=str(user.get("name") or "")[:80], qr_svg="")
            if kind == "error":                         # WhatsApp ended the pairing: the child is stopped and its
                _stop_child(state.get("proc"))          # record removed once it is proven gone, BEFORE the error shows
                proc = state.get("proc")                # (R5 Windows; R7: no moment where "error" shows a live record)
                gone = proc is None or proc.poll() is not None
                if gone:
                    _pairing_done(state.get("home"), state.get("id"))
                with _LOCK:
                    if state["status"] in ("starting", "waiting"):
                        state.update(status="error", plain=LINK_FAILED, qr_svg="")
                    if gone:
                        state["done"] = True
                break
    except Exception:
        pass
    finally:
        proc = state.get("proc")
        _stop_child(proc)                              # output ended: the child is stopped and must be gone (R6 cut 1)
        if proc is None or proc.poll() is not None:
            with _LOCK:
                state["done"] = True
            _pairing_done(state.get("home"), state.get("id"))


def pairing_file(home) -> Path:
    return wa_dir(home) / "pairing.json"


def _pairing_other(home) -> bool:
    """A pairing started by another Qosha process (or one this process can't place) since the computer last started:
    True. A record from before the last start is removed (R5 cut 1)."""
    p = pairing_file(home)
    if not os.path.lexists(p):
        return False
    if _is_link(p):
        return True
    try:
        v = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        v = None
    if not _after_boot(_record_time(v if isinstance(v, dict) else {}, p)):
        try:
            p.unlink()
        except FileNotFoundError:
            pass
        except OSError:
            return True
        return False
    if isinstance(v, dict) and v.get("pid") == os.getpid():
        lid = v.get("lid")
        if lid in _LINKS and not _LINKS[lid].get("done"):
            return False                               # this process's own pairing, still running
        try:                                           # this process's own pairing that has ended: its record goes
            p.unlink()
        except FileNotFoundError:
            pass                                       # already removed by the pairing's own end
        except OSError:
            return True
        return False
    return True


def _pairing_done(home, lid) -> None:
    p = pairing_file(home)
    try:
        v = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(v, dict) and v.get("pid") == os.getpid() and v.get("lid") == lid and not _is_link(p):
            p.unlink()
    except Exception:
        pass


def _session_has_files(home) -> bool:
    d = session_dir(home)
    if not os.path.lexists(d):
        return False
    if _is_link(d) or not os.path.isdir(d):
        return True
    try:
        return any(True for _ in os.scandir(str(d)))
    except OSError:
        return True


def start_link(home, backup_ok: Any = False, runner=None) -> Dict[str, Any]:
    home = str(home)
    if not local():
        return _refused(NOT_LOCAL, "not_local")
    if not folder_ok(home):
        return _refused(FOLDER_BAD, "folder")
    with _Lifecycle(home):                    # F5
        return _start_link(home, backup_ok, runner)


def _start_link(home, backup_ok: Any = False, runner=None) -> Dict[str, Any]:
    if not local():
        return _refused(NOT_LOCAL, "not_local")
    if backup_ok is not True:
        return _refused(BACKUP_FIRST, "backup_first")
    if not folder_ok(home):
        return _refused(FOLDER_BAD, "folder")
    if stopped(home):
        return _refused(STOPPED, "stopped")
    if linked(home):
        return _refused("WhatsApp is already linked on this computer.", "linked")
    node, bridge = node_path(home), bridge_path(home)
    if not node or not bridge:
        return _refused(NOT_SET_UP, "not_set_up")
    with _LOCK:
        cur = _LINKING.get(home)
        mine = cur and _LINKS.get(cur, {}).get("status") in ("starting", "waiting") and not _LINKS[cur].get("done")
    if not mine and _session_has_files(home):          # never pair over existing link files (R5 cut 1)
        return _refused(LINKED_FILES, "linked")
    with _LOCK:
        cur = _LINKING.get(home)
        if cur and _LINKS.get(cur, {}).get("status") in ("starting", "waiting") and not _LINKS[cur].get("done"):
            return dict(_view(cur), reused=True)
    if _pairing_other(home):                           # another Qosha window is pairing (R5 cut 1)
        return _refused(LINK_BUSY, "link_busy")
    raw = _run_raw(home)                               # a bridge record of any kind owns the session (R6 cut 1)
    if raw:
        if not _after_boot(_record_time(raw, run_file(home))):
            try:
                run_file(home).unlink()                # from before the last restart: stale
            except FileNotFoundError:
                pass
            except OSError:
                return _refused(LINK_BUSY, "link_busy")
        elif raw.get("owner") != os.getpid() or _alive(int(raw.get("pid") or 0) if str(raw.get("pid") or "0").isdigit() else 0):
            return _refused(LINK_BUSY, "link_busy")
    with _LOCK:
        lid = secrets.token_urlsafe(18)
        state = {"id": lid, "home": home, "status": "starting", "qr_svg": "", "number": "", "name": "", "plain": "",
                 "started": NOW(), "proc": None, "done": False}
        _LINKS[lid] = state
        _LINKING[home] = lid
    try:
        _mkdirs(home)
        _write_json(pairing_file(home), {"pid": os.getpid(), "lid": lid, "started": NOW()})
        proc = (runner or RUNNER)([node, bridge, "--pair-only", "--pair-json", "--session", str(session_dir(home))],
                                  **_popen_kw(home, stdout=subprocess.PIPE))
    except Exception:
        with _LOCK:
            state.update(status="error", plain=LINK_FAILED, done=True)
        _pairing_done(home, lid)
        return _refused(LINK_FAILED, "link_failed")
    state["proc"] = proc
    threading.Thread(target=_link_reader, args=(state,), daemon=True).start()
    return dict(_view(lid), ok=True)


def _view(lid) -> Dict[str, Any]:
    s = _LINKS.get(lid) or {}
    return {"ok": True, "link_id": lid, "status": s.get("status", "error"), "qr_svg": s.get("qr_svg", ""),
            "number": s.get("number", ""), "name": s.get("name", ""), "plain": s.get("plain", ""),
            "seconds_left": int(max(0, LINK_SECONDS - (NOW() - s.get("started", 0))))}


def _stop_child(proc) -> None:
    try:
        if proc is not None and proc.poll() is None:
            proc.kill()
            proc.wait(timeout=5)
    except Exception:
        pass


def link_status(lid: str) -> Dict[str, Any]:
    s = _LINKS.get(str(lid or ""))
    if not s:
        return {"ok": False, "status": "error", "plain": LINK_FAILED}
    if s["status"] in ("starting", "waiting"):
        proc = s.get("proc")
        ended = proc is not None and proc.poll() is not None and s.get("done")
        if NOW() - s["started"] > LINK_SECONDS or ended:
            _end_link(s, LINK_FAILED)
    elif s["status"] == "linked" and not linked(s["home"]):
        # the bridge said connected but saved nothing usable: not linked
        proc = s.get("proc")
        if proc is None or proc.poll() is not None:
            _end_link(s, LINK_FAILED)
    return _view(s["id"])


def _end_link(s, plain) -> None:
    _stop_child(s.get("proc"))
    proc = s.get("proc")
    gone = proc is None or proc.poll() is not None
    with _LOCK:
        s.update(status="error", plain=plain, qr_svg="")
        if _LINKING.get(s["home"]) == s["id"]:
            _LINKING.pop(s["home"], None)
        if gone:
            s["done"] = True
    if gone:                                           # the pairing child is proven gone: its record goes now, not
        _pairing_done(s["home"], s["id"])              # only when the reader thread gets to it (Windows, R5)
    if not linked(s["home"]):
        _remove_tree(session_dir(s["home"]))           # a half-written link is removed


def cancel_link(lid: str) -> Dict[str, Any]:
    s = _LINKS.get(str(lid or ""))
    if not s:
        return {"ok": True}
    with _Lifecycle(s["home"]):               # F5
        return _cancel_link(s)


def _cancel_link(s) -> Dict[str, Any]:
    if s["status"] in ("starting", "waiting"):
        _end_link(s, "Stopped.")
        _remove_tree(session_dir(s["home"]))
    return {"ok": True}


# ---- the running bridge ------------------------------------------------------------------------------------------
def _http(method: str, url: str, headers: Dict[str, str], body: Optional[bytes], timeout: float):
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))   # loopback: never through a proxy
    with opener.open(req, timeout=timeout) as r:
        return r.status, r.read(1_000_000)


HTTP: Callable[..., Any] = _http


def _token(home) -> str:
    try:
        if _is_link(token_file(home)):
            return ""
        t = token_file(home).read_text(encoding="utf-8").strip()
        return t if re.fullmatch(r"[0-9a-f]{64}", t) else ""
    except OSError:
        return ""


def _run_raw(home) -> Dict[str, Any]:
    """run.json as written (a "starting" record has no port yet)."""
    try:
        v = json.loads(run_file(home).read_text(encoding="utf-8"))
        return v if isinstance(v, dict) and v else {"state": "unreadable"}   # {} is not "no record" (R6 cut 1)
    except FileNotFoundError:
        return {}
    except Exception:
        return {"state": "unreadable"}


def _run_info(home) -> Dict[str, Any]:
    try:
        v = json.loads(run_file(home).read_text(encoding="utf-8"))
        return v if isinstance(v, dict) and isinstance(v.get("port"), int) else {}
    except Exception:
        return {}


def _call(home, port: int, method: str, path: str, data: Any = None, timeout: float = HTTP_TIMEOUT) -> Dict[str, Any]:
    token = _token(home)
    if not token:
        return {"ok": False, "reason": "bridge"}
    body = json.dumps(data).encode("utf-8") if data is not None else None
    headers = {"Authorization": "Bearer " + token, "Host": "127.0.0.1:%d" % port}
    if body is not None:
        headers["Content-Type"] = "application/json"
    try:
        status, raw = HTTP(method, "http://127.0.0.1:%d%s" % (port, path), headers, body, timeout)
        v = json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as exc:      # the bridge's own refusal (e.g. 404 no_such_attachment) keeps its reason
        try:
            v = json.loads(exc.read(100000).decode("utf-8"))
        except Exception:
            v = None
        reason = v.get("reason") if isinstance(v, dict) else None
        return {"ok": False, "reason": reason if isinstance(reason, str) and re.fullmatch(r"[a-z_]{1,40}", reason) else "bridge"}
    except Exception:
        return {"ok": False, "reason": "bridge"}
    if status != 200 or not isinstance(v, dict):
        return {"ok": False, "reason": "bridge"}
    return v


def _proof_ok(home, port: int) -> bool:
    token = _token(home)
    if not token:
        return False
    challenge = secrets.token_hex(16)
    try:
        status, raw = HTTP("GET", "http://127.0.0.1:%d/auth-proof" % port,
                           {"x-hermes-bridge-challenge": challenge, "Host": "127.0.0.1:%d" % port}, None, 5)
        got = json.loads(raw.decode("utf-8")).get("authProof")
    except Exception:
        return False
    want = hmac.new(token.encode("utf-8"), challenge.encode("utf-8"), hashlib.sha256).hexdigest()
    return status == 200 and isinstance(got, str) and hmac.compare_digest(got, want)


def _ours(home, port: int) -> bool:
    if not _proof_ok(home, port):
        return False
    h = _call(home, port, "GET", "/health", timeout=5)
    return os.path.normcase(os.path.abspath(str(h.get("session") or ""))) == \
        os.path.normcase(os.path.abspath(str(session_dir(home))))


def _free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]
    finally:
        s.close()


PORT: Callable[[], int] = _free_port


_LIFE = threading.RLock()
_LIFE_DEPTH = threading.local()


class _Lifecycle:
    """One lock for every change of WhatsApp's state on this computer (start, stop, disconnect, link, clear): across
    processes (a lock file) and re-entrant inside one (F5)."""
    def __init__(self, home):
        self.p = wa_dir(home) / ".lifecycle.lock"
        self.fh = None
        self.outer = False

    def __enter__(self):
        _LIFE.acquire()
        depth = getattr(_LIFE_DEPTH, "n", 0)
        _LIFE_DEPTH.n = depth + 1
        if depth:
            return self
        self.outer = True
        try:
            self.p.parent.mkdir(parents=True, exist_ok=True)
            self._file_lock()
        except BaseException:
            _LIFE_DEPTH.n -= 1
            _LIFE.release()
            raise
        return self

    def _file_lock(self):
        self.fh = open(self.p, "a+b")
        if WIN:
            import msvcrt
            end = time.monotonic() + READY_SECONDS + 10
            while True:
                try:
                    self.fh.seek(0)
                    msvcrt.locking(self.fh.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    if time.monotonic() > end:
                        raise
                    time.sleep(0.1)
        else:
            import fcntl
            fcntl.flock(self.fh.fileno(), fcntl.LOCK_EX)

    def __exit__(self, *exc):
        try:
            if self.outer and self.fh is not None:
                try:
                    if WIN:
                        import msvcrt
                        self.fh.seek(0)
                        msvcrt.locking(self.fh.fileno(), msvcrt.LK_UNLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(self.fh.fileno(), fcntl.LOCK_UN)
                finally:
                    self.fh.close()
        finally:
            _LIFE_DEPTH.n -= 1
            _LIFE.release()


_StartLock = _Lifecycle


def ensure_running(home, runner=None) -> Dict[str, Any]:
    home = str(home)
    if not local():
        return _refused(NOT_LOCAL, "not_local")
    if not folder_ok(home) or not files_ok(home):
        return _refused(FOLDER_BAD, "folder")
    with _Lifecycle(home):                     # every check happens inside the lifecycle lock (F5)
        if stopped(home):
            return _refused(STOPPED, "stopped")
        if not linked(home):
            return _refused("WhatsApp isn't linked on this computer. Connect it in Qosha's Connections page.", "not_linked")
        with _LOCK:
            cur = _LINKING.get(home)
            pairing_here = bool(cur and not _LINKS.get(cur, {}).get("done"))
        if pairing_here or _pairing_other(home):       # a pairing (this window's or another's) owns the session (R6)
            return _refused(LINK_BUSY, "not_stopped")
        node, bridge = node_path(home), bridge_path(home)
        if not node or not bridge:
            return _refused(NOT_SET_UP, "not_set_up")
        info = _run_info(home)
        if info and _ours(home, info["port"]):
            return {"ok": True, "port": info["port"]}
        raw = _run_raw(home)
        if raw:                                # a bridge we can't prove is ours: proven gone before a new one (F5)
            r = stop(home)
            if not r.get("ok"):
                return r if r.get("error") == "not_stopped" else _refused(
                    "Qosha couldn't start its WhatsApp link. Try again in a moment.", "start_failed")
        _write_json(run_file(home), {"state": "starting", "started": NOW(), "node": node, "bridge": bridge,
                                     "owner": os.getpid()})
        token = secrets.token_hex(32)
        _write_json(token_file(home), None) if False else None
        tf = token_file(home)
        tmp = tf.with_name(".bridge-token.%s.tmp" % secrets.token_hex(6))
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(token)
        os.replace(str(tmp), str(tf))
        port = PORT()
        try:
            proc = (runner or RUNNER)([node, bridge, "--port", str(port), "--session", str(session_dir(home)),
                                       "--mode", "bot"], **_popen_kw(home, token))
        except Exception:
            return _refused("Qosha couldn't start its WhatsApp link. Try again in a moment.", "start_failed")
        if getattr(proc, "pid", 0):
            _PROCS[int(proc.pid)] = proc
        _write_json(run_file(home), {"state": "running", "pid": getattr(proc, "pid", 0), "port": port, "owner": os.getpid(),
                                     "started": NOW(), "node": node, "bridge": bridge})
        end = time.monotonic() + READY_SECONDS
        while time.monotonic() < end:
            if _ours(home, port):
                return {"ok": True, "port": port}
            if proc.poll() is not None:
                break
            time.sleep(0.25)
        _stop_child(proc)
        if stopped(home):
            return _refused(STOPPED, "stopped")
        return _refused("Qosha couldn't start its WhatsApp link. Try again in a moment.", "start_failed")


def _bridge_call(home, method, path, data=None) -> Dict[str, Any]:
    r = ensure_running(home)
    if not r.get("ok"):
        return {"ok": False, "reason": r.get("error") or "bridge", "plain": r.get("plain", "")}
    return _call(home, r["port"], method, path, data)


def chats(home) -> Dict[str, Any]:
    return _bridge_call(home, "GET", "/qosha/chats")


def messages(home, chat: str, limit: int = 50) -> Dict[str, Any]:
    from urllib.parse import quote
    n = max(1, min(200, int(limit or 50)))
    return _bridge_call(home, "GET", "/qosha/messages?chat=%s&limit=%d" % (quote(str(chat), safe=""), n))


def search(home, words: str, limit: int = 30) -> Dict[str, Any]:
    from urllib.parse import quote
    if not isinstance(words, str) or not words.strip():
        return _refused("Give the words to look for. Nothing was read.", "empty")
    n = max(1, min(100, int(limit or 30)))
    return _bridge_call(home, "GET", "/qosha/search?q=%s&limit=%d" % (quote(str(words or ""), safe=""), n))


def open_media(home, chat: str, message_id: str) -> Dict[str, Any]:
    """Download one attachment through WhatsApp's own media link into <home>/whatsapp-media."""
    from urllib.parse import quote
    if _unsafe(media_dir(home)) or not no_links_below(home):
        return _refused(FOLDER_BAD, "folder")
    r = _bridge_call(home, "GET", "/qosha/media?chat=%s&id=%s" % (quote(str(chat), safe=""), quote(str(message_id), safe="")))
    if isinstance(r, dict) and r.get("ok") is True and not media_file_ok(home, r.get("path")):
        return _refused(FOLDER_BAD, "folder")          # what the bridge wrote is checked again before it is opened
    return r


def clear_history(home) -> Dict[str, Any]:
    """Empty the local WhatsApp store (chats, messages, attachment records, sync progress); the link, pace settings
    and send log stay. The bridge is stopped first, so no live copy can write the old state back (F5); a clear
    boundary keeps replayed history out (F1)."""
    home = str(home)
    if not local():
        return _refused(NOT_LOCAL, "not_local")
    if not folder_ok(home):
        return _refused(FOLDER_BAD, "folder")
    if not files_ok(home):
        return _refused(FOLDER_BAD, "folder")
    with _Lifecycle(home):
        r = _stop_locked(home)
        if not r.get("ok"):
            if r.get("error") == "not_stopped":       # another window or an unprovable record (R6 cut 1)
                return r
            return _refused("Qosha couldn't clear the WhatsApp history on this computer. Close Qosha and try again.",
                            "not_cleared")
        st = store_dir(home)
        msgs, chats_f, media, sync_f = st / "messages", st / "chats.json", st / "media", st / "sync.json"
        try:
            if os.path.isdir(st) and not _is_link(st):
                _write_json(st / "clear.json", {"clear_at": NOW()})
            if os.path.isdir(msgs) and not _is_link(msgs):
                for f in os.listdir(msgs):
                    if f.endswith(".jsonl"):
                        os.unlink(os.path.join(str(msgs), f))
            for f in (chats_f, sync_f):
                if os.path.lexists(f):
                    os.unlink(f)
            if os.path.lexists(media):
                _remove_tree(media)
        except OSError:
            pass
        left = (os.path.lexists(chats_f) or os.path.lexists(sync_f) or os.path.lexists(media)
                or (os.path.isdir(msgs) and any(f.endswith(".jsonl") for f in os.listdir(msgs))))
        if left:
            return _refused("Qosha couldn't clear the WhatsApp history on this computer. Close Qosha and try again.",
                            "not_cleared")
        return {"ok": True}


def send(home, chat: str, text: str) -> Dict[str, Any]:
    """ONE POST /qosha/send with exactly this chat and text; never retried."""
    return _bridge_call(home, "POST", "/qosha/send", {"chat": chat, "text": text})


# ---- status, settings, stopping ----------------------------------------------------------------------------------
def settings(home) -> Dict[str, Any]:
    if not local():
        return _refused(NOT_LOCAL, "not_local")
    out = dict(DEFAULTS)
    try:
        v = json.loads((store_dir(home) / "settings.json").read_text(encoding="utf-8"))
    except Exception:
        return out
    if isinstance(v, dict):
        m, d = v.get("min_seconds"), v.get("daily_max")
        if isinstance(m, int) and not isinstance(m, bool) and m >= 30:
            out["min_seconds"] = m
        if isinstance(d, int) and not isinstance(d, bool) and 1 <= d <= 100:
            out["daily_max"] = d
    return out


def set_settings(home, min_seconds: Any, daily_max: Any) -> Dict[str, Any]:
    if not local():
        return _refused(NOT_LOCAL, "not_local")
    ok = (isinstance(min_seconds, int) and not isinstance(min_seconds, bool) and min_seconds >= 30
          and isinstance(daily_max, int) and not isinstance(daily_max, bool) and 1 <= daily_max <= 100)
    if not ok:
        return _refused("The pace must be at least 30 seconds between messages and 1 to 100 a day.", "bad_settings")
    try:
        _mkdirs(home)
        _write_json(store_dir(home) / "settings.json", {"min_seconds": min_seconds, "daily_max": daily_max})
    except OSError:
        return _refused(FOLDER_BAD, "folder")
    return {"ok": True, **settings(home)}


def sends(home):
    """The send ledger: [] when there is none yet; None when it exists but can't be trusted (sending stops, F1)."""
    try:
        raw = (store_dir(home) / "sends.json").read_text(encoding="utf-8")
    except FileNotFoundError:
        return []
    except Exception:
        return None
    try:
        v = json.loads(raw)
    except Exception:
        return None
    import math
    if not isinstance(v, list) or not all(isinstance(x, dict) and isinstance(x.get("ts"), (int, float))
                                          and not isinstance(x.get("ts"), bool) and math.isfinite(x["ts"]) for x in v):
        return None
    return v


def status(home) -> Dict[str, Any]:
    if not local():
        return _refused(NOT_LOCAL, "not_local")
    info = _run_info(home)
    number = ""
    try:
        me = json.loads((session_dir(home) / "creds.json").read_text(encoding="utf-8")).get("me") or {}
        number = number_of(me.get("id"))
    except Exception:
        pass
    try:
        sync = json.loads((store_dir(home) / "sync.json").read_text(encoding="utf-8"))
        sync = {k: sync.get(k) for k in ("progress", "messages", "chats", "done", "at")} if isinstance(sync, dict) else {}
    except Exception:
        sync = {}
    return {"linked": linked(home), "number": number, "stopped": stopped(home), "running": bool(info),
            "settings": settings(home), "sync": sync}


def _cmdline(pid: int) -> str:
    try:
        if WIN:
            out = subprocess.run(["powershell", "-NoProfile", "-Command",
                                  "(Get-CimInstance Win32_Process -Filter \"ProcessId=%d\").CommandLine" % int(pid)],
                                 capture_output=True, text=True, timeout=10,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        else:
            out = subprocess.run(["ps", "-o", "command=", "-p", str(int(pid))], capture_output=True, text=True, timeout=10)
        return out.stdout.strip()
    except Exception:
        return ""


CMDLINE: Callable[[int], str] = _cmdline
_BOOT_CACHE: Dict[str, float] = {}


def _boot_time() -> Optional[float]:
    """When this computer last started (seconds since 1970), or None when it can't be read. A record written before it
    belongs to processes that are surely gone: a restart is what clears an unprovable WhatsApp link (R5 cut 1)."""
    if "t" in _BOOT_CACHE:
        return _BOOT_CACHE["t"]
    t = None
    try:
        if WIN:
            import ctypes
            ms = ctypes.windll.kernel32.GetTickCount64
            ms.restype = ctypes.c_ulonglong
            t = time.time() - ms() / 1000.0
        elif sys.platform == "darwin":
            out = subprocess.run(["sysctl", "-n", "kern.boottime"], capture_output=True, text=True, timeout=10).stdout
            m = re.search(r"sec\s*=\s*(\d+)", out)
            t = float(m.group(1)) if m else None
        else:
            with open("/proc/stat", encoding="ascii") as fh:
                for line in fh:
                    if line.startswith("btime "):
                        t = float(line.split()[1])
    except Exception:
        t = None
    if t is not None:
        _BOOT_CACHE["t"] = t
    return t


BOOT: Callable[[], Optional[float]] = _boot_time


def _after_boot(t: Any) -> bool:
    """True when time t is after the last start of this computer, or when that can't be told (fail closed)."""
    b = BOOT()
    try:
        return b is None or float(t) >= float(b) - 5
    except (TypeError, ValueError):
        return True


def _record_time(info: Dict[str, Any], path: Path) -> Any:
    v = info.get("started") if isinstance(info, dict) else None
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return v
    try:
        return os.lstat(str(path)).st_mtime              # a damaged record: when it was written
    except OSError:
        return None


def _kill_pid(pid: int) -> None:
    try:
        if WIN:
            subprocess.run(["taskkill", "/PID", str(int(pid)), "/T", "/F"], capture_output=True, timeout=10,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        else:
            import signal
            os.kill(int(pid), signal.SIGTERM)
    except Exception:
        pass


KILL: Callable[[int], None] = _kill_pid


def _alive(pid: int) -> bool:
    if not pid:
        return False
    own = _PROCS.get(int(pid))
    if own is not None:                       # a child of this Qosha: poll() also collects it once it has ended
        try:
            return own.poll() is None
        except Exception:
            return False
    if WIN:
        return bool(CMDLINE(pid))
    try:
        os.kill(int(pid), 0)
        return True
    except OSError:
        return False


def stop(home) -> Dict[str, Any]:
    """Stop Qosha's bridge: ask it (after its proof matches), else stop the process only if it is ours."""
    if not local():
        return _refused(NOT_LOCAL, "not_local")
    with _Lifecycle(home):
        return _stop_locked(home)


def _stop_locked(home) -> Dict[str, Any]:
    if _pairing_other(home):                           # another window is pairing this home (R6 cut 1)
        return _refused(LINK_BUSY, "not_stopped")
    info = _run_raw(home)
    if not info:
        return {"ok": True}
    port = info.get("port") if isinstance(info.get("port"), int) else None
    try:
        pid = int(info.get("pid") or 0)
    except (TypeError, ValueError):
        pid = 0
    if port is not None and _proof_ok(home, port):
        _call(home, port, "POST", "/qosha/stop", {}, timeout=5)
        end = time.monotonic() + 5
        while time.monotonic() < end and _alive(pid):
            time.sleep(0.1)
    if _alive(pid):
        cmd = CMDLINE(pid)
        node, bridge = str(info.get("node") or node_path(home) or ""), str(Path(home) / BRIDGE_REL)
        if node and node in cmd and bridge in cmd:
            KILL(pid)
            end = time.monotonic() + 5
            while time.monotonic() < end and _alive(pid):
                time.sleep(0.1)
        if _alive(pid):
            return _refused(NOT_STOPPED, "not_stopped")
    if pid <= 0 or info.get("state") in ("starting", "unreadable"):
        # no pid on record (a crash between spawn and the record, or a damaged file): nothing can prove that bridge
        # gone except a restart of the computer since the record was written (R5 cut 1; no process-list guessing)
        if info.get("owner") != os.getpid() and _after_boot(_record_time(info, run_file(home))):
            return _refused(UNSURE, "not_stopped")     # only this window's own record is proof enough (R6 cut 1)
    try:
        run_file(home).unlink()
    except FileNotFoundError:
        pass
    except OSError:
        return _refused(NOT_STOPPED, "not_stopped")
    return {"ok": True}


def _forget_read_grants() -> None:
    """The guard's WhatsApp read answers held in this process are dropped (R4 #7). Other processes need no call: with
    the link gone there is no link generation, and no grant counts without one."""
    import sys as _sys
    for m in list(_sys.modules.values()):
        f = getattr(m, "forget_whatsapp_grants", None)
        if callable(f) and str(getattr(m, "__name__", "")).split(".")[-1] == "ask":
            try:
                f()
            except Exception:
                pass


def disconnect(home) -> Dict[str, Any]:
    home = str(home)
    if not local():
        return _refused(NOT_LOCAL, "not_local")
    _forget_read_grants()
    with _LOCK:
        lid = _LINKING.pop(home, None)
    if lid and lid in _LINKS:
        _stop_child(_LINKS[lid].get("proc"))
        _LINKS[lid].update(status="error", plain="Stopped.")
    if not folder_ok(home):
        return _refused(FOLDER_BAD, "folder")
    with _Lifecycle(home):                    # F5
        if _pairing_other(home):                                # another Qosha window is pairing: checked first (R6)
            return _refused(LINK_BUSY, "not_stopped")
        r = _stop_locked(home)
        if not r.get("ok"):
            return r
        if lid:
            _pairing_done(home, lid)
        gone = (_remove_tree(session_dir(home)) and _remove_tree(store_dir(home))
                and _remove_tree(media_dir(home)))             # opened attachments go too
        for p in (wa_dir(home), media_dir(home)):               # a new link secures its folders again (R4 G-M)
            _OWNER_ONLY.discard(os.path.normcase(str(p)))
        for p in (run_file(home),):
            try:
                p.unlink()
            except FileNotFoundError:
                pass
            except OSError:
                gone = False
        if not gone or os.path.lexists(session_dir(home)) or os.path.lexists(store_dir(home)):
            return _refused(NOT_REMOVED, "not_removed")
        return {"ok": True}
