"""The executor: the only Qosha code that sends. It sends exactly a decision's stored payload, once, after a person
approved that payload's hash (INTERFACES.md §4.3).

Sending is OFF unless $HERMES_HOME/qosha/executor.json is {"live_send": true} (written by install_connector.py
--allow-send, D22). Off, an approval is recorded as `approved_not_sent` and nothing reaches Google.

With the Qosha connector (D26, founder 3 Nov: one Approve, no macOS window), emails, replies and calendar changes are not
sent from here at all: the person's Approve goes from their browser straight to the connector's approval port, which
no lab process can reach, and `sync` reads what the connector did back into the decision and Recent activity.
"""
from __future__ import annotations

import base64
import json
import os
import re
from email.mime.text import MIMEText
from pathlib import Path
from typing import Any, Callable, Dict, Optional

from . import store
from . import appconn
from . import google as qgoogle
from .i18n import tr


def live_send_enabled(home: Path) -> bool:
    """SENDFIX (Ren, 6 Nov: sending always on): with the Qosha connector, approved actions are sent unless
    executor.json says {"live_send": false} (the emergency off switch; no install or upgrade writes it). Without a
    connector nothing in the lab can send, as before (opt in with {"live_send": true}, tests only)."""
    try:
        cfg = json.loads((home / "qosha" / "executor.json").read_text())
    except FileNotFoundError:
        return connector_mode()
    except (OSError, ValueError):
        return False
    if not isinstance(cfg, dict):
        return False
    return cfg.get("live_send") is not False if connector_mode() else cfg.get("live_send") is True


def _raw(msg: MIMEText) -> str:
    return base64.urlsafe_b64encode(msg.as_bytes()).decode()


def build_request(kind: str, p: Dict[str, Any]) -> Dict[str, Any]:
    """The exact Google request for a payload (pure; tests compare it with the approved payload)."""
    if kind == "email.send":
        m = MIMEText(p["body"], "html" if p.get("html") else "plain")
        m["To"] = p["to"]; m["Subject"] = p["subject"]
        if p.get("cc"):
            m["Cc"] = p["cc"]
        if p.get("bcc"):
            m["Bcc"] = p["bcc"]
        if p.get("from"):
            m["From"] = p["from"]
        body = {"raw": _raw(m)}
        if p.get("thread_id"):
            body["threadId"] = p["thread_id"]
        return {"api": "gmail.messages.send", "body": body}
    if kind == "email.reply":
        m = MIMEText(p["body"])
        m["To"] = p["to"]; m["Subject"] = p["subject"]
        if p.get("from"):
            m["From"] = p["from"]
        if p.get("in_reply_to"):
            m["In-Reply-To"] = p["in_reply_to"]; m["References"] = p["in_reply_to"]
        return {"api": "gmail.messages.send", "body": {"raw": _raw(m), "threadId": p["thread_id"]}}
    if kind == "calendar.create":
        ev = {"summary": p["summary"], "start": {"dateTime": p["start"]}, "end": {"dateTime": p["end"]}}
        if p.get("location"):
            ev["location"] = p["location"]
        if p.get("description"):
            ev["description"] = p["description"]
        if p.get("attendees"):
            ev["attendees"] = [{"email": e.strip()} for e in p["attendees"].split(",") if e.strip()]
        return {"api": "calendar.events.insert", "calendarId": p.get("calendar") or "primary", "body": ev}
    if kind == "calendar.delete":
        return {"api": "calendar.events.delete", "calendarId": p.get("calendar") or "primary", "eventId": p["event_id"]}
    if kind == "calendar.update":
        ev = {k: ({"dateTime": p[k]} if k in ("start", "end") else p[k])
              for k in ("summary", "start", "end", "location", "description") if p.get(k)}
        return {"api": "calendar.events.patch", "calendarId": p.get("calendar") or "primary", "eventId": p["event_id"],
                "body": ev}
    raise ValueError(kind)


def _perform(mod, req: Dict[str, Any]) -> Dict[str, Any]:
    if req["api"] == "gmail.messages.send":
        r = qgoogle.service(mod, "gmail", "v1").users().messages().send(userId="me", body=req["body"]).execute()
        return {"message_id": r.get("id", ""), "thread_id": r.get("threadId", "")}
    if req["api"] == "calendar.events.insert":
        r = qgoogle.service(mod, "calendar", "v3").events().insert(calendarId=req["calendarId"], body=req["body"]).execute()
        return {"event_id": r.get("id", ""), "html_link": r.get("htmlLink", "")}
    if req["api"] == "calendar.events.patch":
        r = qgoogle.service(mod, "calendar", "v3").events().patch(calendarId=req["calendarId"], eventId=req["eventId"],
                                                                  body=req["body"]).execute()
        return {"event_id": r.get("id", ""), "html_link": r.get("htmlLink", "")}
    if req["api"] == "calendar.events.delete":
        qgoogle.service(mod, "calendar", "v3").events().delete(calendarId=req["calendarId"], eventId=req["eventId"]).execute()
        return {"deleted": req["eventId"]}
    raise ValueError(req["api"])


# What a person reads when an approved action did not happen (decision row and Recent activity): plain words.
_PLAIN = {
    "approve_at_connector": "Press Approve on the card in Qosha: emails and calendar changes are approved there.",
    "send_limit": "Not sent: Qosha's hourly limit for emails and calendar changes was reached.",
    "not_pending": "Not sent: this was no longer waiting for approval.",
    "already_approved": "Already approved: it is being sent or was sent, so it can't be declined now.",
    "decline_unconfirmed": "Not declined yet: Qosha's Google connection did not answer. It is still waiting; press "
                           "Decline again in a moment.",
    "repeating_event": "Not changed: this is a repeating event. Change or delete the whole series in Google Calendar.",
    "event_changed": "Not changed: the event changed after you saw it. Ask Qosha again to see it as it is now.",
    "read_only": "Not sent: Qosha's Google connection is read-only. Sign in again with sending allowed.",
    "google_not_signed_in": "Not sent: Google is not connected on this Mac.",
    "google_refresh_failed": "Not sent: Google refused Qosha's sign-in (it may have been revoked). Sign in again.",
    "google_api_error": "Google refused it: %s. It was most likely not done; check Gmail's Sent folder or your calendar "
                        "before asking again.",
    "google_unreachable": "Google could not be reached. It may or may not have gone through: check Gmail's Sent folder "
                          "or your calendar before asking again.",
    "unreachable": "The Qosha connector did not answer. It may or may not have gone through: check Gmail's Sent folder "
                   "or your calendar before asking again.",
    "already_done": "Not repeated: this approval was already used once.",
    "not_approved": "Not sent: the connector did not find this approval.",
    "payload_changed": "Not sent: what would be sent differs from what you approved.",
    "decision_required": "Not sent: the connector did not get the approval it needs.",
    "no_etag": "Not changed: Google did not give a version of the event to pin the change to.",
    "reply_changed": "Not sent: the original message changed after you approved the reply.",
    "no_recipient": "Not sent: the original message has no sender to reply to.",
    "bad_payload": "Not sent: some of the text can't be shown safely on the approval card.",
    # SENDFIX (6 Nov)
    "needs_reconnect": "Not sent: your Google connection doesn't allow this yet. Reconnect Google to allow sending, then "
                       "ask Qosha again.",
    "not_held": "Not sent: Qosha's connector has no record of this request as it was shown. Ask Qosha again.",
    "message_changed": "Not sent: the email changed after you saw it. Ask Qosha again to see it as it is now.",
    "draft_changed": "Not sent: the draft changed after you saw it. Ask Qosha again to see it as it is now.",
    "too_large": "Not sent: it is too large to show on the card. Send it from Gmail.",
}


def plain(code: str, detail: str = "") -> str:
    msg = tr(_PLAIN.get(code) or tr("executor.unconfirmed", reason=(code or "unknown reason")))
    if "%s" in msg:
        d = detail or tr("no reason given")
        if "403" in d:
            d += tr("; the Google sign-in may not allow sending: reconnect Google (on the Mac: run connector-signin again)")
        msg = msg % d
    return msg


class AppActionError(Exception):
    def __init__(self, code: str, detail: str = ""):
        super().__init__(code)
        self.code, self.detail = code, detail


_PLAIN.update({
    "app_not_connected": "Not done: this app is not connected in Qosha. Connect it under Connections, then ask again.",
    "app_tool_missing": "Not done: the app no longer offers this action.",
    "app_connection_changed": "Not done: the app's connection changed after this was asked (a different address, "
                              "account or sign-in). Nothing was sent; ask again.",
    "app_unknown": "Not done: Qosha could not tell exactly which app this action was for.",
    "app_ambiguous": "Not done: two connected apps have names Qosha can't tell apart. Remove one under Connections.",
    "app_refused": "The app refused it: %s. It was not done.",
    "app_uncertain": "Not confirmed as done: the app did not answer clearly (%s). It may or may not have gone through: "
                     "check the app before asking again.",
})


def run_app_action(payload: Dict[str, Any], home: Path) -> Dict[str, Any]:
    """Run exactly one approved connected-app (MCP) call through the engine's own MCP client, then disconnect."""
    import asyncio
    from hermes_cli.mcp_config import _get_mcp_servers, _resolve_mcp_server_config
    from tools.mcp_tool import _connect_server, _ensure_mcp_loop, _run_on_mcp_loop, _stop_mcp_loop_if_idle, mcp_field
    from .policy import _mcp_names_collide
    # exactly the raw server and tool the engine registered when the action was held (part of the approved hash)
    name, raw_tool = payload.get("server"), payload.get("tool")
    if payload.get("resolved") is not True or not isinstance(name, str) or not isinstance(raw_tool, str) \
            or not name or not raw_tool:
        raise AppActionError("app_unknown")
    servers = _get_mcp_servers()
    if name not in servers or servers[name].get("enabled") is False:
        raise AppActionError("app_not_connected")
    if any(_mcp_names_collide(name, other) for other in servers):
        raise AppActionError("app_ambiguous")
    # the same connection the person approved: settings as stored and as the engine will use them, same sign-in
    want = payload.get("connection")
    if not isinstance(want, str) or want == "none" or appconn.fingerprint(name, home) != want \
            or appconn.fingerprint(name, home, servers[name]) != want:
        raise AppActionError("app_connection_changed")
    cfg = _resolve_mcp_server_config(servers[name])
    args = payload.get("arguments") if isinstance(payload.get("arguments"), dict) else {}
    state = {"called": False}

    async def _go():
        server = await asyncio.wait_for(_connect_server(name, cfg), timeout=float(cfg.get("connect_timeout", 30)))
        try:
            if [t.name for t in server._tools].count(raw_tool) != 1:
                raise AppActionError("app_tool_missing")
            tool = raw_tool
            state["called"] = True
            res = await server.session.call_tool(tool, arguments=args)
            text = " ".join(getattr(b, "text", "") for b in (getattr(res, "content", None) or []) if getattr(b, "text", ""))
            return {"is_error": bool(mcp_field(res, "is_error", "isError", False)), "text": text[:2000]}
        finally:
            await server.shutdown()

    _ensure_mcp_loop()
    try:
        out = _run_on_mcp_loop(_go(), timeout=float(cfg.get("connect_timeout", 30)) + float(cfg.get("timeout", 120)))
    except AppActionError:
        raise
    except BaseException as exc:
        if state["called"]:
            raise AppActionError("app_uncertain", type(exc).__name__)
        raise AppActionError("app_not_connected", type(exc).__name__)
    finally:
        _stop_mcp_loop_if_idle()
    if out["is_error"]:
        raise AppActionError("app_refused", out["text"][:300] or "no reason given")
    return {"result": out["text"]}


def run_web_request(payload: Dict[str, Any], home: Path) -> Dict[str, Any]:
    """CAPFIX (owner order, GPT R1 #10): a website write the assistant's code asked for, held by Qosha's read-only proxy:
    sent exactly as shown on the card, once, to a public address only; never to a payment service."""
    import base64
    import ssl
    import urllib.parse
    import urllib.error
    import urllib.request
    from . import egress_proxy
    a = payload.get("arguments") if isinstance(payload.get("arguments"), dict) else {}
    if payload.get("tool") != "web_request" or payload.get("replay") is not True or payload.get("payment_host"):
        raise AppActionError("app_unknown")
    method, url = str(a.get("method") or ""), str(a.get("url") or "")
    u = urllib.parse.urlsplit(url)
    if method not in egress_proxy.REPLAY_METHODS or u.scheme not in ("http", "https") or not u.hostname:
        raise AppActionError("app_unknown")
    if not egress_proxy.public_address(u.hostname, u.port or (443 if u.scheme == "https" else 80)):
        raise AppActionError("app_refused", "not a public address")
    body = base64.b64decode(a.get("body_b64") or "")
    hdrs = {k: v for k, v in (a.get("headers") or {}).items() if k in egress_proxy.REPLAY_HEADERS}

    class _NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kw):
            return None                       # sent once, to the approved address only
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect,
                                         urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    req = urllib.request.Request(url, data=body if body or method != "DELETE" else None, method=method, headers=hdrs)
    try:
        with opener.open(req, timeout=60) as r:
            return {"status": r.status, "result": r.read(2000).decode("utf-8", "replace")}
    except urllib.error.HTTPError as e:
        return {"status": e.code, "result": (e.read(2000) or b"").decode("utf-8", "replace")}
    except OSError as e:
        raise AppActionError("app_uncertain", type(e).__name__)


def _approve_app(decision_id: str, expected_sha256: str, home: Path, runner) -> Dict[str, Any]:
    d = store.claim(decision_id, expected_sha256, "sending", home)   # at most once: only a pending row moves on
    try:
        if store.payload_hash(d["payload"], d["kind"]) != expected_sha256:
            raise store.StoreError("payload_changed", "payload changed after approval")
        web = d["payload"].get("tool") == "web_request" and d["payload"].get("replay") is True
        result = (runner or (run_web_request if web else run_app_action))(d["payload"], home)
    except Exception as exc:  # stays failed; never retried automatically
        code = getattr(exc, "code", "") or "app_uncertain"
        return store.finish(decision_id, "failed", {"error": plain(code, getattr(exc, "detail", "") or type(exc).__name__),
                                                    "code": code}, home)
    return store.finish(decision_id, "sent", result, home)


_PLAIN.update({
    "draft_changed": "Not saved: the draft in Your files is missing or changed after it was put up for approval. Ask "
                     "Qosha to put the new text up again; it needs a new approval.",
    "skill_exists": "Not saved: a skill with this name is already in the library. Ask Qosha for a different name.",
    "skill_invalid": "Not saved: %s",
    "skill_write_failed": "Not saved: the skill could not be written (%s).",
})


def _existing_skill(name: str, skills: Path) -> bool:
    try:
        from tools.skill_manager_tool import _find_skill   # the engine's own collision check (all skill folders)
        if _find_skill(name):
            return True
    except ImportError:
        pass
    return any(p.is_file() for p in [skills / name / "SKILL.md"] + list(skills.glob("*/%s/SKILL.md" % name))
               + list(skills.glob("*/*/%s/SKILL.md" % name)))


def run_skill_save(payload: Dict[str, Any], home: Path) -> Dict[str, Any]:
    """Add exactly the approved text to the library as skills/made-by-you/<name>/SKILL.md, once: only while the draft in
    Your files still has that text, never over an existing skill."""
    from .policy import SKILL_NAME, SKILL_DRAFTS, SKILL_SAVE_CATEGORY, skill_text_problem
    import hashlib
    name, content = payload.get("name"), payload.get("content")
    if not isinstance(name, str) or not SKILL_NAME.match(name) or not isinstance(content, str) \
            or payload.get("category") != SKILL_SAVE_CATEGORY or payload.get("draft") != "%s/%s.md" % (SKILL_DRAFTS, name) \
            or hashlib.sha256(content.encode("utf-8")).hexdigest() != payload.get("content_sha256"):
        raise AppActionError("payload_changed")
    files = os.path.realpath(home / "files")
    draft = os.path.join(files, payload["draft"])
    want = content.encode("utf-8")

    def draft_unchanged() -> bool:
        try:
            if os.path.islink(draft) or os.path.realpath(draft) != draft:
                return False
            with open(draft, "rb") as fh:
                return fh.read(len(want) + 1) == want
        except OSError:
            return False

    if not draft_unchanged():
        raise AppActionError("draft_changed")
    why = skill_text_problem(content, name)
    if why:
        raise AppActionError("skill_invalid", why)
    skills = home / "skills"
    if _existing_skill(name, skills):
        raise AppActionError("skill_exists")
    (skills / SKILL_SAVE_CATEGORY).mkdir(parents=True, exist_ok=True)
    folder = skills / SKILL_SAVE_CATEGORY / name
    try:
        folder.mkdir(exist_ok=False)
    except FileExistsError:
        raise AppActionError("skill_exists")
    except OSError as exc:
        raise AppActionError("skill_write_failed", type(exc).__name__)
    tmp, final = folder / ".SKILL.md.tmp", folder / "SKILL.md"

    made = {"tmp": False}

    def undo() -> None:   # nothing published: remove only what this attempt made (GPT save-6, save-10)
        if made["tmp"]:
            try:
                tmp.unlink()
            except OSError:
                pass
        try:
            folder.rmdir()
        except OSError:
            pass

    if os.path.islink(folder) or not os.path.realpath(folder).startswith(os.path.realpath(skills) + os.sep):
        undo()
        raise AppActionError("skill_write_failed", "outside the skills folder")
    try:
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        made["tmp"] = True
        with os.fdopen(fd, "wb") as fh:
            fh.write(want)
            fh.flush()
            os.fsync(fh.fileno())
    except OSError as exc:
        undo()
        raise AppActionError("skill_write_failed", type(exc).__name__)
    if not draft_unchanged():   # checked again right before it goes live (GPT save-5)
        undo()
        raise AppActionError("draft_changed")
    try:
        os.link(str(tmp), str(final))   # fails if it appeared meanwhile: never overwrites
    except OSError as exc:
        undo()
        raise AppActionError("skill_write_failed", type(exc).__name__)
    try:
        tmp.unlink()                    # ours (made above); published already, a leftover temp file is harmless
    except OSError:
        pass
    return {"saved": "%s/%s" % (SKILL_SAVE_CATEGORY, name)}


def _approve_skill(decision_id: str, expected_sha256: str, home: Path, runner) -> Dict[str, Any]:
    """A new skill: added once, on Approve, whether or not sending to Google is on (it stays on this Mac)."""
    d = store.claim(decision_id, expected_sha256, "sending", home)   # at most once: only a pending row moves on
    try:
        if store.payload_hash(d["payload"], d["kind"]) != expected_sha256:
            raise AppActionError("payload_changed")
        result = (runner or run_skill_save)(d["payload"], home)
    except Exception as exc:  # stays failed; never retried automatically
        code = getattr(exc, "code", "") or "skill_write_failed"
        return store.finish(decision_id, "failed", {"error": plain(code, getattr(exc, "detail", "") or type(exc).__name__),
                                                    "code": code}, home)
    return store.finish(decision_id, "sent", result, home)


# CAPFIX (owner order, 6 Nov): Qosha's settings and deletes outside Your files: done on this Mac, once, on Approve.
LOCAL_KINDS = ("settings.change", "file.delete", "file.write")
_PLAIN.update({
    "settings_changed": "Not changed: Qosha's settings changed after this card was made. Ask Qosha again to see the new "
                        "change.",
    "settings_guard": "Not changed: this would switch off Qosha's approval guard.",
    "settings_conflict_applied": "The approved settings were installed, but another program changed settings at the same "
                                 "time. Its competing version was preserved in Qosha's protected settings backup. "
                                 "Review both versions before making another change.",
    "staged_conflict_applied": "The approved output was installed, but another program changed the original file at "
                               "the same time. Its competing contents were preserved in Qosha's private staged "
                               "backup. Review both versions before making another change.",
    "delete_conflict_trashed": "A different file appeared during the approved move. That replacement was moved to "
                               "Trash and preserved; the requested path is now absent. Review Trash before continuing.",
    "settings_write_failed": "Not changed: the settings file could not be written (%s).",
    "delete_changed": "Not done: %s changed after this card was made (it is not the same file or folder any more). "
                      "Ask Qosha again.",
    "delete_failed": "Not everything was deleted (%s).",
    "delete_protected": "Not done: %s is a sign-in store, a git folder or one of Qosha's own folders.",
    "write_failed": "Not saved: the file could not be written (%s).",
})


def _exchange_files(parent: int, left: str, right: str) -> None:
    """Atomically retain the displaced file. Never use a destructive replacement fallback."""
    import ctypes
    import sys
    libc = ctypes.CDLL(None, use_errno=True)
    if sys.platform == "darwin":
        fn, flag = libc.renameatx_np, 2
    elif hasattr(libc, "renameat2"):
        fn, flag = libc.renameat2, 2
    else:
        raise OSError("atomic file exchange is unavailable")
    fn.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    fn.restype = ctypes.c_int
    if fn(parent, os.fsencode(left), parent, os.fsencode(right), flag):
        code = ctypes.get_errno()
        raise OSError(code, os.strerror(code))


def run_settings_change(payload: Dict[str, Any], home: Path) -> Dict[str, Any]:
    """Apply approved keys with a pinned parent and exclusive random temporary leaf. Preserve displaced config bytes."""
    import hashlib
    import secrets
    import stat
    import yaml
    from .policy import _guard_switched_off
    sets, unsets = payload.get("set"), payload.get("unset")
    if payload.get("file") != "config.yaml" or not isinstance(sets, dict) or not isinstance(unsets, list):
        raise AppActionError("payload_changed")
    parent = _open_parent(str(home / "config.yaml"))
    temp = ".config.yaml.qosha-" + secrets.token_hex(16)
    temp_created = False
    exchanged = False
    def read_current():
        fd = os.open("config.yaml", os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        with os.fdopen(fd, "rb") as fh:
            st = os.fstat(fh.fileno())
            if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1:
                raise AppActionError("settings_changed")
            raw = fh.read(2_000_001)
            if len(raw) > 2_000_000:
                raise AppActionError("settings_changed")
        return raw, st
    try:
        old, before = read_current()
        if hashlib.sha256(old).hexdigest() != payload.get("before_sha256"):
            raise AppActionError("settings_changed")
        data = yaml.safe_load(old.decode('utf-8')) or {}
        if not isinstance(data, dict):
            raise AppActionError("settings_changed")
        for key, value in sets.items():
            node, parts = data, str(key).split(".")
            for k in parts[:-1]:
                if not isinstance(node.get(k), dict):
                    node[k] = {}
                node = node[k]
            node[parts[-1]] = value
        for key in unsets:
            node, parts = data, str(key).split(".")
            for k in parts[:-1]:
                node = node.get(k) if isinstance(node, dict) else None
            if isinstance(node, dict):
                node.pop(parts[-1], None)
        if _guard_switched_off(data):
            raise AppActionError("settings_guard")
        new_text = yaml.safe_dump(data, sort_keys=False, allow_unicode=True)
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     stat.S_IMODE(before.st_mode), dir_fd=parent)
        temp_created = True
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(new_text)
            fh.flush()
            os.fsync(fh.fileno())
        latest, current = read_current()
        if (current.st_dev, current.st_ino) != (before.st_dev, before.st_ino) or latest != old:
            raise AppActionError("settings_changed")
        _exchange_files(parent, temp, "config.yaml")
        exchanged = True
        displaced_fd = os.open(temp, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        with os.fdopen(displaced_fd, "rb") as fh:
            displaced = os.fstat(fh.fileno())
            displaced_bytes = fh.read(2_000_001)
        # The random backup contains the previous configuration. It stays under the protected engine home.
        # If a same-user writer raced the exchange, preserve its bytes and report the conflict explicitly.
        if (displaced.st_dev, displaced.st_ino) != (before.st_dev, before.st_ino) or displaced_bytes != old:
            raise AppActionError("settings_conflict_applied")
        return {"changed": sorted(list(sets) + list(unsets))}
    except AppActionError:
        raise
    except (OSError, ValueError, yaml.YAMLError) as exc:
        raise AppActionError("settings_write_failed", type(exc).__name__)
    finally:
        if temp_created and not exchanged:
            try:
                os.unlink(temp, dir_fd=parent)  # only our uninstalled temporary output, never displaced user data
            except OSError:
                pass
        os.close(parent)


_SECRET_NAME = re.compile(r"^(\.env.*|\.envrc|.*\.pem|.*\.p12|.*\.pfx|.*\.p8|.*\.key|id_(rsa|dsa|ecdsa|ed25519).*|.*\.kdbx?|"
                          r"credentials.*|.*credentials.*\.json|.*client[-_]?secret.*\.json|.*token.*\.json|auth\.json|"
                          r"\.netrc|\.npmrc|\.pypirc|\.git-credentials|.*\.keychain(-db)?)$", re.I)


def _protected(path: str, home: Path) -> bool:
    """Not Qosha's to change, even on Approve: outside the person's home, a top-level dot entry, ~/Library (but iCloud
    Drive and cloud storage folders are documents), the lab (but Your files), a git folder, a sign-in-shaped name."""
    person = os.path.realpath(os.path.expanduser("~"))
    lab = os.path.realpath(str(home.parent))
    files = os.path.realpath(str(home / "files"))
    rel = os.path.relpath(path, person)
    if rel.startswith("..") or rel == "." or os.path.isabs(rel):
        return True
    parts = rel.split("/")
    if parts[0].startswith("."):
        return True
    if parts[0] == "Library" and not (parts[1:2] == ["Mobile Documents"] or parts[1:2] == ["CloudStorage"]):
        return True
    if (path == lab or path.startswith(lab + "/")) and not path.startswith(files + "/"):
        return True
    return any(p == ".git" or p.endswith(".git") for p in parts) or bool(_SECRET_NAME.match(parts[-1]))


def _open_parent(path: str) -> int:
    """GPT R1 #5: the parent folder opened one component at a time, never following a link, so a folder swapped for a
    link after the card was made can't move the action elsewhere. Returns a directory descriptor."""
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
    try:
        for comp in [c for c in os.path.dirname(path).split("/") if c]:
            nxt = os.open(comp, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = nxt
        return fd
    except OSError:
        os.close(fd)
        raise


def run_file_delete(payload: Dict[str, Any], home: Path) -> Dict[str, Any]:
    """Move approved objects into the person's Trash; never permanently unlink their data.

    Parent and object identities are captured when the card is made. Every lookup is relative to a directory opened
    without following links. A changed object is refused; no recursive traversal is needed to trash a directory.
    """
    import datetime
    import secrets
    import stat
    paths, identities = payload.get("paths"), payload.get("identities")
    if (not isinstance(paths, list) or not paths or not isinstance(identities, dict)
            or not all(isinstance(x, str) and x.startswith("/") for x in paths)):
        raise AppActionError("payload_changed")
    handles = []
    trash_fd = date_fd = -1
    try:
        for path in paths:
            if _protected(path, home):
                raise AppActionError("delete_protected", path)
            try:
                fd = _open_parent(path)
                handles.append((path, fd))
                parent = os.fstat(fd)
                target = os.stat(os.path.basename(path), dir_fd=fd, follow_symlinks=False)
            except OSError:
                raise AppActionError("delete_changed", path)
            want = identities.get(path) or {}
            if ([parent.st_dev, parent.st_ino] != want.get("parent")
                    or [target.st_dev, target.st_ino, target.st_mode] != want.get("target")):
                raise AppActionError("delete_changed", path)
            if stat.S_ISDIR(target.st_mode) and not payload.get("recursive"):
                child_fd = os.open(os.path.basename(path), os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                try:
                    with os.scandir(child_fd) as entries:
                        if next(entries, None) is not None:
                            raise AppActionError("delete_failed", "folder is not empty")
                finally:
                    os.close(child_fd)
        person = os.path.realpath(os.path.expanduser("~"))
        person_fd = _open_parent(os.path.join(person, "placeholder"))
        try:
            try:
                os.mkdir(".Trash", mode=0o700, dir_fd=person_fd)
            except FileExistsError:
                pass
            trash_fd = os.open(".Trash", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=person_fd)
        finally:
            os.close(person_fd)
        date_name = datetime.datetime.now().strftime("%Y-%m-%d") + "-Qosha-" + secrets.token_hex(8)
        os.mkdir(date_name, mode=0o700, dir_fd=trash_fd)
        date_fd = os.open(date_name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=trash_fd)
        moved = []
        for index, (path, fd) in enumerate(handles):
            name = os.path.basename(path)
            target = os.stat(name, dir_fd=fd, follow_symlinks=False)
            if [target.st_dev, target.st_ino, target.st_mode] != identities[path]["target"]:
                raise AppActionError("delete_changed", path)
            destination = "%04d-%s" % (index, name)
            os.rename(name, destination, src_dir_fd=fd, dst_dir_fd=date_fd)
            after = os.stat(destination, dir_fd=date_fd, follow_symlinks=False)
            if [after.st_dev, after.st_ino, after.st_mode] != identities[path]["target"]:
                # Preserve an object swapped during rename in Trash rather than overwrite another host file on rollback.
                raise AppActionError("delete_conflict_trashed", path)
            moved.append(path)
        return {"deleted": moved, "trashed": moved, "trash_folder": os.path.join(person, ".Trash", date_name)}
    except AppActionError:
        raise
    except OSError as exc:
        raise AppActionError("delete_failed", type(exc).__name__)
    finally:
        for path, fd in handles:
            os.close(fd)
        if date_fd >= 0:
            os.close(date_fd)
        if trash_fd >= 0:
            os.close(trash_fd)


def run_file_write(payload: Dict[str, Any], home: Path) -> Dict[str, Any]:
    """Save exactly the approved text to the approved file, only while it is still what the card was made from (or
    still absent), through its parent folder opened without following links; an existing file keeps its permissions."""
    import hashlib
    import secrets as _sec
    path, content, before = payload.get("path"), payload.get("content"), payload.get("before_sha256")
    if not isinstance(path, str) or not path.startswith("/") or not isinstance(content, str):
        raise AppActionError("payload_changed")
    if _protected(path, home):
        raise AppActionError("delete_protected", path)
    name = os.path.basename(path)
    try:
        fd = _open_parent(path)
    except OSError:
        raise AppActionError("delete_changed", path)
    tmp = ".%s.qosha-%s" % (name, _sec.token_hex(4))
    try:
        mode = 0o644
        try:
            cur = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=fd)
            with os.fdopen(cur, "rb") as fh:
                now = hashlib.sha256(fh.read()).hexdigest()
                mode = os.fstat(fh.fileno()).st_mode & 0o777
        except FileNotFoundError:
            now = None
        except OSError:
            raise AppActionError("delete_changed", path)
        if now != before:
            raise AppActionError("delete_changed", path)
        w = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode, dir_fd=fd)
        with os.fdopen(w, "w", encoding="utf-8") as fh:
            fh.write(content)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, name, src_dir_fd=fd, dst_dir_fd=fd)
    except AppActionError:
        raise
    except OSError as exc:
        try:
            os.unlink(tmp, dir_fd=fd)
        except OSError:
            pass
        raise AppActionError("write_failed", type(exc).__name__)
    finally:
        os.close(fd)
    return {"saved": path}


def describe_local(kind: str, payload: Dict[str, Any], home: Path) -> Dict[str, Any]:
    """Rebuild an ordinary local card from current source bytes, without writes. The connector compares ALL fields
    before registering its private ledger copy. Never accept a caller-supplied human display as authoritative."""
    import difflib
    import hashlib
    import yaml
    from . import policy
    if not isinstance(payload, dict) or payload.get("codebox_stage"):
        raise AppActionError("payload_changed")
    if kind == "file.delete":
        paths = payload.get("paths")
        if not isinstance(paths, list) or not paths or not all(isinstance(p, str) and p.startswith("/") for p in paths):
            raise AppActionError("payload_changed")
        if type(payload.get("recursive")) is not bool or any(_protected(p, home) for p in paths):
            raise AppActionError("delete_protected")
        return policy._delete_payload(paths, payload["recursive"])
    if kind == "file.write":
        path, content = payload.get("path"), payload.get("content")
        if not isinstance(path, str) or not os.path.isabs(path) or not isinstance(content, str) or len(content) > 200_000:
            raise AppActionError("payload_changed")
        if _protected(path, home):
            raise AppActionError("delete_protected")
        parent = _open_parent(path)
        try:
            try:
                fd = os.open(os.path.basename(path), os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
                with os.fdopen(fd, "rb") as fh:
                    raw = fh.read(2_000_001)
                if len(raw) > 2_000_000:
                    raise AppActionError("payload_changed")
                old, before = raw.decode("utf-8", "replace"), hashlib.sha256(raw).hexdigest()
            except FileNotFoundError:
                old, before = "", None
        finally:
            os.close(parent)
        diff = "".join(difflib.unified_diff(old.splitlines(True), content.splitlines(True), path + " (now)",
                                           path + " (after Approve)", n=2))
        return {"path": path, "before_sha256": before, "content": content, "body": diff or content,
                "what": ("Change %s" if before else "Create %s") % path}
    if kind == "settings.change":
        sets, unsets = payload.get("set"), payload.get("unset")
        if payload.get("file") != "config.yaml" or not isinstance(sets, dict) or not isinstance(unsets, list):
            raise AppActionError("payload_changed")
        parent = _open_parent(str(home / "config.yaml"))
        try:
            fd = os.open("config.yaml", os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
            with os.fdopen(fd, "rb") as fh:
                raw = fh.read(2_000_001)
            if len(raw) > 2_000_000:
                raise AppActionError("payload_changed")
        finally:
            os.close(parent)
        if hashlib.sha256(raw).hexdigest() != payload.get("before_sha256"):
            raise AppActionError("settings_changed")
        data = yaml.safe_load(raw) or {}
        if not isinstance(data, dict):
            raise AppActionError("settings_changed")
        for key, value in sets.items():
            if not isinstance(key, str) or not re.fullmatch(r"[A-Za-z0-9_\-]+(\.[A-Za-z0-9_\-]+)*", key):
                raise AppActionError("payload_changed")
            node, parts = data, key.split(".")
            for part in parts[:-1]:
                if not isinstance(node.get(part), dict):
                    node[part] = {}
                node = node[part]
            node[parts[-1]] = value
        for key in unsets:
            if not isinstance(key, str):
                raise AppActionError("payload_changed")
            node, parts = data, key.split(".")
            for part in parts[:-1]:
                node = node.get(part) if isinstance(node, dict) else None
            if isinstance(node, dict):
                node.pop(parts[-1], None)
        verdict = policy.settings_change("write_file", {"path": str(home / "config.yaml"),
                    "content": yaml.safe_dump(data, sort_keys=False)}, home_override=home)
        if verdict is None or verdict.action != policy.HOLD or verdict.kind != kind:
            raise AppActionError("settings_guard")
        return verdict.payload
    raise AppActionError("payload_changed")


def _approve_local(decision_id: str, expected_sha256: str, home: Path, kind: str) -> Dict[str, Any]:
    d = store.claim(decision_id, expected_sha256, "sending", home)   # at most once
    try:
        if store.payload_hash(d["payload"], d["kind"]) != expected_sha256:
            raise AppActionError("payload_changed")
        result = {"settings.change": run_settings_change, "file.delete": run_file_delete,
                  "file.write": run_file_write}[kind](d["payload"], home)
    except Exception as exc:  # stays failed; never retried automatically
        code = getattr(exc, "code", "") or ("settings_write_failed" if kind == "settings.change" else "delete_failed")
        return store.finish(decision_id, "failed", {"error": plain(code, getattr(exc, "detail", "") or type(exc).__name__),
                                                    "code": code}, home)
    return store.finish(decision_id, "sent", result, home)


GOOGLE_KINDS = ("email.send", "email.reply", "email.forward", "email.draft_send", "email.draft_save", "calendar.create",
                "calendar.update", "calendar.delete")
# approved at the connector's approval port, never here: Google actions and website actions in Qosha's own Chrome
CONNECTOR_KINDS = GOOGLE_KINDS + ("browser.action",)


def is_codebox_decision(row) -> bool:
    if not isinstance(row, dict) or not isinstance(row.get("payload"), dict):
        return False
    payload = row["payload"]
    args = payload.get("arguments")
    return ((row.get("kind") in ("file.delete", "file.write") and payload.get("codebox_stage") is True)
            or (row.get("kind") == "app.action" and isinstance(args, dict) and args.get("source") == "codebox"))


def via_connector(row) -> bool:
    return isinstance(row, dict) and (row.get("kind") in CONNECTOR_KINDS + LOCAL_KINDS or is_codebox_decision(row))



def connector_mode() -> bool:
    """The Qosha connector holds the Google sign-in outside the lab sandbox (council D8)."""
    return bool(os.environ.get("QOSHA_CONNECTOR_URL"))


def approve_url(home: Path) -> str:
    """Where the person's browser sends Approve for a Google action (the connector's approval port, D26), or "" when
    approvals stay in the dashboard (no connector, or sending switched off: approved_not_sent)."""
    if not connector_mode() or not live_send_enabled(home):
        return ""
    url = os.environ.get("QOSHA_APPROVE_URL", "http://127.0.0.1:9240/v1/approve")
    if os.environ.get("QOSHA_BOX") and url == BOX_APPROVE_PATH:
        return url    # SENDFIX: the cloud box's connector, behind Google's sign-in, on this page's own address
    return url if url.startswith(("http://127.0.0.1:", "http://localhost:")) else ""


BOX_APPROVE_PATH = "/qosha-box/approve"


def approve(decision_id: str, expected_sha256: str, home: Path,
            loader: Optional[Callable[[Path], Any]] = None,
            app_runner: Optional[Callable[..., Dict[str, Any]]] = None,
            skill_runner: Optional[Callable[..., Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Approve -> (sending is off) approved_not_sent, or (on) sending -> sent | failed. Raises store.StoreError.

    With the connector, a Google action is never approved here: it is approved at the connector (approve_url) and its
    outcome comes back through `sync`. Without a connector, live sending is refused (tests inject `loader`)."""
    current = store.get(decision_id, home)
    if current is not None and current["kind"] == "google.reconnect":   # a notice with a button: nothing to approve
        raise store.StoreError("not_pending", plain("not_pending"))
    if current is not None and current["kind"] == "skill.save":   # stays on this Mac: not a send
        return _approve_skill(decision_id, expected_sha256, home, skill_runner)
    if is_codebox_decision(current) or (current is not None and current.get("kind") in LOCAL_KINDS):
        raise store.StoreError("approve_at_connector", plain("approve_at_connector"))
    if current is not None and current["kind"] in LOCAL_KINDS:   # CAPFIX: on this Mac, on Approve, once
        return _approve_local(decision_id, expected_sha256, home, current["kind"])
    if not live_send_enabled(home):
        return store.claim(decision_id, expected_sha256, "approved_not_sent", home)
    if current is not None and current["kind"] == "app.action":   # a connected app (MCP): the engine's own client
        return _approve_app(decision_id, expected_sha256, home, app_runner)
    if loader is None:
        if connector_mode():
            raise store.StoreError("approve_at_connector", plain("approve_at_connector"))
        return store.claim(decision_id, expected_sha256, "approved_not_sent", home)
    d = store.claim(decision_id, expected_sha256, "sending", home)
    try:
        if store.payload_hash(d["payload"], d["kind"]) != expected_sha256:   # re-check what we are about to send
            raise store.StoreError("payload_changed", "payload changed after approval")
        result = _perform(loader(home), build_request(d["kind"], d["payload"]))
    except Exception as exc:  # the decision stays failed; it is never retried automatically
        code = getattr(exc, "code", "") or ""
        msg = plain(code or "unclassified", getattr(exc, "detail", "") or type(exc).__name__)   # unknown = uncertain (GPT R-send2)
        return store.finish(decision_id, "failed", {"error": msg, "code": code}, home)
    return store.finish(decision_id, "sent", result, home)


def sync(decision_ids, home: Path, fetch: Optional[Callable[[list], Dict[str, Any]]] = None) -> int:
    """Bring the connector's own record of what it did (its ledger, D26) into the decisions and Recent activity.
    Only Google decisions; a connector that can't be reached changes nothing. Returns how many rows moved."""
    rows = [store.get(i, home) for i in decision_ids]
    rows = [r for r in rows if r and via_connector(r) and r["status"] in ("pending", "sending", "declined", "failed")]
    if not rows or (fetch is None and not connector_mode()):
        return 0
    if fetch is None:
        from . import connector_client
        fetch = connector_client.outcomes
    try:
        got = fetch([r["id"] for r in rows])
    except Exception:
        return 0
    moved = 0
    for r in rows:
        o = got.get(r["id"]) or {}
        state = o.get("state")
        # the connector's own line for what was approved, when this row was changed after the approval (GPT R-email1 #5)
        approved_as = str(o.get("what") or "")[:300] if o.get("payload_sha256") not in (None, "", r["payload_sha256"]) else ""
        if state == "done":
            res = dict(o.get("result") if isinstance(o.get("result"), dict) else {})
            moved += store.apply_outcome(r["id"], "sent", res, home, approved_as)
        elif state == "failed":
            code = str(o.get("error") or "")
            moved += store.apply_outcome(r["id"], "failed", {"error": plain(code or "unclassified", str(o.get("detail") or "")),
                                                             "code": code}, home, approved_as)
        elif state == "claimed":
            if _age(o.get("at")) > STALE_CLAIM_SECONDS:   # the connector stopped midway: say it may or may not have gone
                moved += store.apply_outcome(r["id"], "failed", {"error": plain("unreachable"), "code": "uncertain"}, home,
                                             approved_as)
            elif r["status"] == "pending":
                moved += store.apply_outcome(r["id"], "sending", {}, home, approved_as)
    return moved


STALE_CLAIM_SECONDS = 120   # Google answers within 15 s; a claim this old without an outcome was cut off


def _age(at) -> float:
    from datetime import datetime
    try:
        return datetime.now().astimezone().timestamp() - datetime.fromisoformat(str(at)).timestamp()
    except (TypeError, ValueError):
        return 0.0


def decline(decision_id: str, home: Path, connector_decline: Optional[Callable[[str], Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Decline. An email or calendar change is declined at the connector first (GPT R-email1 #3): if the person's
    Approve already won there, this says so instead of showing "Declined" for something that is being sent."""
    current = store.get(decision_id, home)
    if current is not None and via_connector(current) and current["status"] == "pending" \
            and (connector_decline is not None or connector_mode()):
        if connector_decline is None:
            from . import connector_client
            connector_decline = connector_client.decline
        try:
            connector_decline(decision_id)
        except Exception as exc:
            if getattr(exc, "code", "") == "already_approved":
                sync([decision_id], home)
                raise store.StoreError("already_approved", plain("already_approved"))
            # not acknowledged (e.g. an Approve still holds the connector, or it is down): never shown as declined
            # while an approved send may still go out (GPT R-email2 #3); it stays waiting and can be declined again
            raise store.StoreError("decline_unconfirmed", plain("decline_unconfirmed"))
    return store.claim(decision_id, "", "declined", home)
