"""Brings Qosha's own files up to date when an update held them back by mistake (Ren, 24 Nov 2026 ~06:1x MST: "start it
now"; orchestrator design, 23 Nov 2026 ~21:3x MST).

Why: an installer run over an existing Qosha never refreshed the updater's record of what Qosha installed
(<home>/qosha/plugin-installed). The next update then compared the newer files with the OLD record, counted Qosha's own
files as the person's changes, kept them and saved the update's version beside each one as <name>.qosha-<version>.new.
Qosha keeps working, but on a mix of old and new files.

What: a file that has <name>.qosha-<this version>.new beside it is brought up to date only when BOTH hold:
  (a) the .new is exactly this release's file as an install writes it (keep_edits' own renditions of the package file in
      <root>/layer/candidate/plugin), and
  (b) the live file is a file Qosha itself shipped for that path (layer/known_files.json: the sha256 of every rendition of
      every built release's copy, with the releases that carried it), and it is NEWER than the base the update compared
      it with (the installer-over-an-older-install shape). A person's own edit never matches, and a person who put back
      an OLDER Qosha copy on purpose (older than the base) is kept too (GPT r1 H1).
Then the live file is replaced (only if it did not change meanwhile), then the record is set (its copy = the release
file, its BASE override dropped), the .new removed, and the update notice rebuilt without that file (Gemini r1 H1: the
record never moves ahead of the live file; a stop after the replace is completed at the next check).

Where and when: this file lives in the layer, which every update replaces (it is never held back), and the launcher runs
it at its own start points. Never while an update runs (its record is written after the launcher starts). Python files
(*.py) only before Qosha's dashboard starts, so running code is never swapped; pages and texts at any quiet check.
Standard library only. Never raises."""
import hashlib
import importlib.util
import json
import os
import re
from pathlib import Path

KNOWN_NAME = 'known_files.json'
PY_POINTS = ('before start', 'before restart')
_KE_NAME = 'qosha_keep_edits_stale_heal'


def _keep_edits(root: Path):
    p = root / 'layer' / 'candidate' / 'plugin' / 'qosha_guard' / 'keep_edits.py'
    spec = importlib.util.spec_from_file_location(_KE_NAME, p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def _vt(v) -> tuple:
    try:
        return tuple(int(x) for x in str(v).split('.'))
    except ValueError:
        return ()


def _known(root: Path) -> dict:
    """{rel: {sha256: (oldest release tuple, newest release tuple)}}."""
    d = json.loads((root / 'layer' / KNOWN_NAME).read_text(encoding='utf-8'))
    files = d.get('files') if isinstance(d, dict) else None
    out = {}
    for rel, m in (files or {}).items():
        if isinstance(rel, str) and isinstance(m, dict):
            out[rel] = {h: (_vt(r[0]), _vt(r[1])) for h, r in m.items()
                        if isinstance(r, list) and len(r) == 2 and _vt(r[0]) and _vt(r[1])}
    return out


def _base_of(home: Path, ke, rel: str):
    """The base the update compared rel with: the BASE override when there is one, else the record's copy; None when the
    record has no such file (Qosha added it after the recorded version)."""
    ov = ke._read_bases(home)
    if rel in ov:
        return ov[rel]
    rec = ke.installed_dir(home).joinpath(*rel.split('/'))
    return rec.read_bytes() if _plain(rec) else None


def _version(root: Path) -> str:
    v = json.loads((root / 'layer' / 'RELEASE.json').read_text(encoding='utf-8')).get('version')
    return v if isinstance(v, str) and v else ''


def _plain(p: Path) -> bool:
    try:
        return p.is_file() and not p.is_symlink()
    except OSError:
        return False


def _write(path: Path, data: bytes, expect=None) -> bool:
    """A new temp file of our own beside path (exclusive), then replace; with expect, only if path still holds it.
    False when path changed meanwhile (nothing written)."""
    tmp = path.with_name('.%s.%s.qosha-tmp' % (path.name, os.urandom(6).hex()))     # our own name, never reused (GPT r1 H3)
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_BINARY', 0), 0o600)
    try:
        with os.fdopen(fd, 'wb') as h:
            h.write(data)
        if expect is not None and (not _plain(path) or path.read_bytes() != expect):
            tmp.unlink()
            return False
        os.replace(tmp, path)
        return True
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise


def _record_ok(home: Path, ke, rel: str) -> bool:
    """No linked folder on the record's or the BASE index's path (checked BEFORE the live file is touched; GPT r2)."""
    top, bd = ke.installed_dir(home), ke._base_dir(home)
    if top.is_symlink() or bd.is_symlink() or (bd / 'index.json').is_symlink():
        return False
    q = top
    for part in rel.split('/')[:-1]:
        q = q / part
        if q.is_symlink():
            return False
    return True


def _set_record(home: Path, ke, rel: str, data: bytes) -> None:
    """keep_edits' record for one healed file: its installed copy = the release file, and no BASE override (the copy is
    the base). No record at all: nothing to set (the next update then compares with the release package)."""
    top = ke.installed_dir(home)
    if not top.is_dir() or top.is_symlink():
        return
    rec = top.joinpath(*rel.split('/'))
    q = top
    for part in rel.split('/')[:-1]:                    # never through a linked folder (Gemini r1 M6, GPT r1 H3)
        q = q / part
        if q.is_symlink():
            raise OSError('a linked folder in the record')
    if rec.is_symlink():
        rec.unlink()
    rec.parent.mkdir(parents=True, exist_ok=True)
    if not (_plain(rec) and rec.read_bytes() == data):
        _write(rec, data)
    _drop_base(ke, home, rel)


def _drop_base(ke, home: Path, rel: str) -> None:
    """Only rel's line leaves the BASE index; every other entry stays exactly as written, readable or not (GPT r1 H4)."""
    idx = ke._base_dir(home) / 'index.json'
    if not _plain(idx):
        return
    d = json.loads(idx.read_text(encoding='utf-8'))
    files = d.get('files') if isinstance(d, dict) else None
    if isinstance(files, dict) and rel in files:
        del files[rel]
        _write(idx, json.dumps(d, indent=1, sort_keys=True).encode('utf-8'))


def _prune_notice(root: Path, home: Path, healed: list, version: str) -> None:
    """The update notice no longer lists healed files: rebuilt by this release's own updater from what is left (the
    words the updater itself stores); with nothing left, it says only that Qosha was updated (Gemini r1 H3)."""
    for _ in range(3):                                  # a settings save at the same moment: read again (GPT r2 N2)
        if _prune_once(root, home, healed, version):
            return


def _prune_once(root: Path, home: Path, healed: list, version: str) -> bool:
    """True when done (written, or nothing to do); False when the file changed under the write."""
    f = home / 'qosha' / 'updates.json'
    try:
        raw = f.read_bytes()
        s = json.loads(raw.decode('utf-8'))
        lr = s.get('last_result') if isinstance(s, dict) else None
        rep = lr.get('kept') if isinstance(lr, dict) else None
        if not isinstance(rep, list) or lr.get('version') != version or lr.get('ok') is not True:
            return True                                 # another release's notice is left alone (GPT r1 M9)
        left = [e for e in rep if not (isinstance(e, dict) and e.get('file') in healed)]
        if len(left) == len(rep):
            return True
        m = re.match(r'^(Qosha was updated to \d[0-9A-Za-z.+-]*?\.)(?:\s|$)', str(lr.get('message') or ''))
        if not m:
            return True
        msg = m.group(1)
        if left:
            # the release's own updater words; on Windows its source gets the same port the install gives every *.py
            # (keep_edits._port_text = setup_home's port_text), or it would not load there (Gemini r2 N1)
            upath = root / 'layer' / 'candidate' / 'plugin' / 'qosha_guard' / 'updater.py'
            src = upath.read_text(encoding='utf-8')
            if os.name == 'nt':
                src = _keep_edits(root)._port_text(src)
            import types
            up = types.ModuleType('qosha_updater_words')
            up.__file__ = str(upath)
            exec(compile(src, str(upath), 'exec'), up.__dict__)
            tail = up._edits_text(left)
            if tail:
                msg = msg + ' ' + tail
        lr['kept'], lr['message'] = left, msg
        return _write(f, json.dumps(s, indent=1).encode('utf-8'), expect=raw)
    except Exception:
        return True


def run(root, when: str, log=lambda m: None, busy=lambda: False) -> list:
    """Heals what qualifies; returns the paths (relative to the plugin) brought up to date. busy(): an update started
    meanwhile (checked again before every file; GPT r1 H5). Never raises."""
    healed = []
    try:
        root = Path(root)
        home = root / 'home'
        live = home / 'plugins' / 'qosha'
        if not live.is_dir() or live.is_symlink():
            return healed
        version = _version(root)
        if not version:
            return healed
        known = _known(root)
        if not known:
            return healed
        ke = _keep_edits(root)
        suffix = '.qosha-%s.new' % ke._safe_version(version)
        pkg = root / 'layer' / 'candidate' / 'plugin'
        found = []
        for dirpath, dirnames, filenames in os.walk(live, followlinks=False):
            d = Path(dirpath)
            dirnames[:] = sorted(n for n in dirnames if n != '__pycache__' and not (d / n).is_symlink())
            for n in filenames:
                if n.endswith(suffix) and len(n) > len(suffix):
                    found.append(((d / n[:-len(suffix)]).relative_to(live).as_posix(), d / n[:-len(suffix)], d / n))
        for rel, lp, newp in sorted(found):
            try:
                if busy():
                    log('file check paused: an update started')
                    break
                if rel.endswith('.py') and when not in PY_POINTS:
                    continue                                    # code: only while the dashboard is not running
                if not (_plain(lp) and _plain(newp)):
                    continue
                mine, new = lp.read_bytes(), newp.read_bytes()
                pf = pkg.joinpath(*rel.split('/'))
                if not _plain(pf) or new not in ke._renditions(rel, pf.read_bytes()):
                    log('file check: %s kept (the saved update copy is not this release\'s own file)' % rel)
                    continue
                if not _record_ok(home, ke, rel):
                    log('file check: %s kept (a linked folder in Qosha\'s record)' % rel)
                    continue
                if mine == new:                                 # replaced at an earlier check that stopped before the
                    if busy():                                  # record: finish it (Gemini r1 H1)
                        break
                    _set_record(home, ke, rel, new)
                    newp.unlink()
                    healed.append(rel)
                    continue
                lv = known.get(rel, {}).get(hashlib.sha256(mine).hexdigest())
                if lv is None:
                    continue                                    # the person's own change: kept, as always
                base = _base_of(home, ke, rel)
                if base is not None:
                    bv = known.get(rel, {}).get(hashlib.sha256(base).hexdigest())
                    if bv is None or not lv[0] > bv[1]:
                        continue                                # not strictly newer than its base (no overlap): kept.
                                                                # Fail closed (rule 4): a copy whose releases overlap
                                                                # the base's stays as it is (a working mix), never an
                                                                # overwrite of a person's rollback (GPT r3 H1)
                if busy():
                    log('file check paused: an update started')
                    break
                if not _write(lp, new, expect=mine):            # the live file first; the record only after it
                    log('file check: %s changed while it was checked; left as it is' % rel)
                    continue
                _set_record(home, ke, rel, new)
                newp.unlink()
                healed.append(rel)
            except Exception as exc:
                log('file check stopped for %s: %s %s' % (rel, type(exc).__name__, str(exc)[:120]))
        if healed:
            _prune_notice(root, home, healed, version)
            log('Qosha\'s own files brought up to date (%s; an earlier update had kept them as if changed by the '
                'person): %s' % (when, ', '.join(healed)))
    except Exception as exc:
        log('file check stopped: %s %s' % (type(exc).__name__, str(exc)[:160]))
    return healed
