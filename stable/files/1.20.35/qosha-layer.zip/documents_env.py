"""Qosha's documents environment (Excel, Word, PowerPoint files) and the microsoft-office skill's setup section.

Builds the engine's pinned "documents" side environment once (in the background of setup; offline is fine, the next
update retries), writes its interpreter to <home>/documents-python.txt, and puts Qosha's own Prerequisites section in
the installed microsoft-office skill, so the commands the assistant runs never carry the engine's name. A section the
person edited is left alone. Standard library only; the public functions never raise.
    python3 documents_env.py --root ROOT      # rebuild the environment and refresh the skill section (the repair)
"""
import os
import stat
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PY_FILE = "documents-python.txt"
SKILL = Path("skills") / "productivity" / "microsoft-office" / "SKILL.md"
ENGINE_ARGS = ["pm", "environment", "documents", "--extra", "documents", "--extra", "documents-pdf"]
IMPORTS = "import docx, openpyxl, pptx"
HEADING = "## Prerequisites"
END = "- Optional: LibreOffice"
MARK = "<!-- qosha-documents v1 -->"
UPSTREAM = '    PY="$(hermes pm environment documents --extra documents --extra documents-pdf)"'
# Word comments the skill writes carry an author name; the engine's default would show its name in the person's file
AUTHOR_FILE = Path("skills") / "productivity" / "microsoft-office" / "scripts" / "docx_comments.py"
AUTHOR_OLD = '    p.add_argument("--author", default="Hermes")'
AUTHOR_NEW = '    p.add_argument("--author", default="Qosha")'

QOSHA_SECTION = """## Prerequisites
<!-- qosha-documents v1 -->

- Python 3.10+ with `python-docx`, `python-pptx`, and `openpyxl` (import names
  `docx`, `pptx`, `openpyxl`). Qosha keeps its own documents environment on this
  computer; its interpreter is named in `{py_file}`.
- Set `PY` with `terminal` once per session:

  ```bash
  PY="$(cat "{py_file}" 2>/dev/null)"
  "$PY" -c "{imports}" || echo "documents environment missing"
  export PY
  "$PY" scripts/docx_create.py --help
  ```

  In PowerShell: `$env:PY = Get-Content "{py_file_win}"`.
  If the check fails, tell the person the documents environment is missing and
  offer to repair it; with their OK run: `{repair}`
  Run every helper with `"$PY"`. Never `pip install` into Qosha's own
  environments.
- Synced folders on this computer (OneDrive, Dropbox): {folders}. Files there
  are the person's cloud files: work on them in place, the sync app uploads them.
- Keep the original: write the edited file as a new copy next to it, named
  "<name> (edited).<ext>", unless the person says otherwise. Never overwrite a
  file that is open in Excel, Word or PowerPoint (a "~$<name>" lock file beside
  it means it is open); save a copy and say so.
"""


def _home(root):
    return Path(root) / "home"


def _write_atomic(path: Path, data: bytes) -> None:
    """Through a temp file in the same folder, then os.replace; refuses a link at the target or the folder."""
    if path.is_symlink() or path.parent.is_symlink():
        raise OSError("link")
    tmp = path.with_name(".%s.%d.tmp" % (path.name, os.getpid()))
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        os.replace(str(tmp), str(path))
    except BaseException:
        try:
            os.unlink(str(tmp))
        except OSError:
            pass
        raise


def _imports_ok(python: str, run, timeout=120) -> bool:
    try:
        r = run([python, "-I", "-c", IMPORTS], capture_output=True, text=True, stdin=subprocess.DEVNULL, timeout=timeout)
        return r.returncode == 0
    except Exception:
        return False


def current_python(root):
    """The interpreter documents-python.txt names, or "" when there is none (or the file is a link)."""
    f = _home(root) / PY_FILE
    try:
        if f.is_symlink():
            return ""
        line = f.read_text(encoding="utf-8").strip()
    except (OSError, UnicodeDecodeError):
        return ""
    return line if line and "\n" not in line and os.path.isabs(line) else ""


def build(root, run=subprocess.run, timeout=1800):
    try:
        sys.path.insert(0, str(HERE))
        try:
            import engine_exec
        finally:
            sys.path.remove(str(HERE))
        cmd = engine_exec.command(Path(root), ENGINE_ARGS)
        env = dict(os.environ, HERMES_HOME=str(_home(root)))
        r = run(cmd, capture_output=True, text=True, env=env, stdin=subprocess.DEVNULL, timeout=timeout)
    except subprocess.TimeoutExpired:
        return {"ok": False, "plain": "Building the documents environment took too long; the next update tries again."}
    except BaseException as e:              # SystemExit from a missing launcher included
        return {"ok": False, "plain": "The documents environment could not be built (%s); the next update tries again."
                % type(e).__name__}
    if r.returncode != 0:
        return {"ok": False, "plain": "The documents environment could not be built (it may need the internet); the "
                                      "next update tries again."}
    lines = [x.strip() for x in (r.stdout or "").splitlines() if x.strip()]
    python = lines[-1] if lines else ""
    if not (python and os.path.isabs(python) and os.path.isfile(python)):
        return {"ok": False, "plain": "The documents environment gave no usable Python; the next update tries again."}
    if not _imports_ok(python, run):
        return {"ok": False, "plain": "The documents environment is missing its libraries; the next update tries again."}
    try:
        _write_atomic(_home(root) / PY_FILE, (python + "\n").encode("utf-8"))
    except OSError as e:
        return {"ok": False, "plain": "Qosha couldn't save where the documents environment is (%s)." % type(e).__name__}
    return {"ok": True, "python": python}


def synced_folders(user_home=None, env=None, windows=None):
    try:
        home = Path(user_home) if user_home is not None else Path.home()
        env = os.environ if env is None else env
        windows = (os.name == "nt") if windows is None else windows
        cands = []
        if windows:
            cands += [Path(env[k]) for k in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial") if env.get(k)]
            cands.append(home / "Dropbox")
        else:
            cs = home / "Library" / "CloudStorage"
            try:
                kids = sorted(p for p in cs.iterdir() if p.name.startswith(("OneDrive-", "Dropbox")))
            except OSError:
                kids = []
            cands += kids + [home / "Dropbox"]
        out, seen = [], set()
        for p in cands:
            try:
                if p.is_symlink() or not p.is_dir():
                    continue
                key = os.path.normcase(str(p.resolve()))
            except OSError:
                continue
            if key not in seen:
                seen.add(key)
                out.append(str(p))
        return out
    except Exception:
        return []


def section(home, folders, repair):
    py_file = str(Path(home) / PY_FILE)
    return QOSHA_SECTION.format(py_file=py_file, py_file_win=py_file.replace("/", "\\"), imports=IMPORTS,
                                repair=repair, folders=", ".join(folders) if folders else "none found on this computer")


def patch_skill(home, folders, repair):
    try:
        return _patch(Path(home), folders, repair)
    except Exception:
        return "edited"                       # anything unexpected: the file is left as it is


def _patch(home, folders, repair):
    f = home / SKILL
    if f.is_symlink():
        return "edited"
    if not f.is_file():
        return "missing"
    raw = f.read_bytes()
    text = raw.decode("utf-8")
    crlf = "\r\n" in text
    t = text.replace("\r\n", "\n")
    lines = t.split("\n")
    try:
        a = lines.index(HEADING)
        b = next(i for i in range(a + 1, len(lines)) if lines[i].startswith(END))
    except (ValueError, StopIteration):
        return "edited"
    old = lines[a:b]
    if not (len(old) > 1 and old[1] == MARK) and UPSTREAM not in old:
        return "edited"
    new = section(home, folders, repair)
    if "hermes" in new.lower():
        return "edited"                       # never write the engine's name (a path that holds it, for example)
    out = "\n".join(lines[:a]) + "\n" + new + "\n".join(lines[b:])
    if crlf:
        out = out.replace("\n", "\r\n")
    data = out.encode("utf-8")
    if data == raw:
        return "current"
    _write_atomic(f, data)
    return "patched"


def patch_author(home):
    """docx_comments.py's default comment author becomes "Qosha" (exact line only; an edited file is left alone).
    Returns "patched" | "current" | "edited" | "missing"; never raises."""
    try:
        f = Path(home) / AUTHOR_FILE
        if f.is_symlink():
            return "edited"
        if not f.is_file():
            return "missing"
        raw = f.read_bytes()
        text = raw.decode("utf-8")
        lines = text.split("\n")
        olds = [i for i, l in enumerate(lines) if l.rstrip("\r") == AUTHOR_OLD]
        if not olds:
            return "current" if any(l.rstrip("\r") == AUTHOR_NEW for l in lines) else "edited"
        if len(olds) != 1:
            return "edited"
        i = olds[0]
        lines[i] = AUTHOR_NEW + ("\r" if lines[i].endswith("\r") else "")
        _write_atomic(f, "\n".join(lines).encode("utf-8"))
        return "patched"
    except Exception:
        return "edited"


def _linkish(p) -> bool:
    try:
        st = os.lstat(str(p))
    except FileNotFoundError:
        return False
    except OSError:
        return True
    return stat.S_ISLNK(st.st_mode) or bool(getattr(st, "st_file_attributes", 0) & 0x400)   # link or reparse point


def _inside_envs(home, python) -> bool:
    """python is a real file under <home>/environments with no link or junction on the way (home itself included)."""
    try:
        home, p = Path(home), Path(python)
        rel = p.relative_to(home)
        if not rel.parts or rel.parts[0] != "environments" or ".." in rel.parts or _linkish(home):
            return False
        cur = home
        for part in rel.parts:
            cur = cur / part
            if _linkish(cur):
                return False
        real_envs = os.path.realpath(str(home / "environments"))
        return p.is_file() and os.path.realpath(str(p)).startswith(real_envs + os.sep)
    except (ValueError, OSError):
        return False


def _drop_pointer(home) -> None:
    try:
        os.unlink(str(Path(home) / PY_FILE))       # that exact file (a link there is removed, never followed)
    except OSError:
        pass


def repair_command(root):
    return '"%s" "%s" --root "%s"' % (sys.executable, Path(__file__).resolve(), Path(root))


def setup(root, run=subprocess.run):
    try:
        b = build(root, run=run)
        have = b.get("python") or ""
        if not b["ok"]:
            old = current_python(root)
            # only an interpreter inside the engine's own environments folder is ever run (2c H7): no link or
            # Windows junction anywhere from home down to it (R2-4)
            if old and _inside_envs(_home(root), old) and _imports_ok(old, run):
                have = old
            elif old:
                _drop_pointer(_home(root))         # a pointer Qosha won't run is not left for the skill to use
        s = patch_skill(_home(root), synced_folders(), repair_command(root))
        a = patch_author(_home(root))
        return "documents: %s; skill section %s; comment author %s" % ("ready" if have else b.get("plain", "not ready"), s, a)
    except Exception as e:
        return "documents: skipped (%s)" % type(e).__name__


def main(argv=None):
    a = list(sys.argv[1:] if argv is None else argv)
    if len(a) != 2 or a[0] != "--root":
        print(__doc__.strip().splitlines()[-1].strip(), file=sys.stderr)
        return 2
    line = setup(Path(a[1]).resolve())
    print(line)
    return 0 if ": ready;" in line else 1


if __name__ == "__main__":
    sys.exit(main())
