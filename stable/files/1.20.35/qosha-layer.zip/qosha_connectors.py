"""Qosha's connectors on the person's computer: what setup installs and configures for Outlook, Dropbox and WhatsApp,
and the documents environment (connectors release 1.20.10; slices 2c, 3, 5, 6). Standard library only.

Every step is independent and never raises: it answers "ok", "kept", "skipped: <why>" or "failed: <why>", and one
failing step never stops another or setup. Called from setup_home: install_files() after the plugin is installed,
config_steps(data, ...) inside write_config (the config dict is changed in place), after() at the end.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import shutil
import stat
import sys
import tempfile
import threading
import zipfile
from pathlib import Path
from typing import Any, Dict, List

WA_RULE = "MAP web.whatsapp.com ~NOTFOUND"
MS_PINNED = "0.190.2"
_REPARSE = 0x400


def _is_link(p) -> bool:
    try:
        st = os.lstat(str(p))
    except FileNotFoundError:
        return False
    except OSError:
        return True
    return stat.S_ISLNK(st.st_mode) or bool(getattr(st, "st_file_attributes", 0) & _REPARSE)


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _guard(home: Path) -> Path:
    return Path(home) / "plugins" / "qosha" / "qosha_guard"


# ---- manifests and safe zip extraction -----------------------------------------------------------------------------
def tree_manifest(root: Path) -> str:
    """sha256 over the sorted relative paths and each file's sha256 (links refused: "")."""
    h = hashlib.sha256()
    root = Path(root)
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames.sort()
        for d in dirnames:
            if _is_link(Path(dirpath) / d):
                return ""
        for f in sorted(filenames):
            p = Path(dirpath) / f
            if _is_link(p):
                return ""
            rel = p.relative_to(root).as_posix()
            h.update(rel.encode("utf-8") + b"\0" + hashlib.sha256(p.read_bytes()).hexdigest().encode() + b"\n")
    return h.hexdigest()


def _manifest_of(zpath: Path) -> str:
    try:
        v = json.loads(Path(str(zpath)[:-4] + ".manifest.json").read_text(encoding="utf-8"))
        return str(v.get("tree") or "") if isinstance(v, dict) else ""
    except Exception:
        return ""


def _safe_extract(zpath: Path, dest: Path) -> None:
    """Every entry stays inside dest: no "..", no absolute path, no drive, no link entry (else nothing is kept)."""
    with zipfile.ZipFile(str(zpath)) as z:
        for info in z.infolist():
            n = info.filename
            parts = n.replace("\\", "/").split("/")
            if n.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", n) or ".." in parts:
                raise ValueError("unsafe entry")
            mode = (info.external_attr >> 16) & 0o170000
            if mode == stat.S_IFLNK or info.external_attr & _REPARSE:      # Unix link or a Windows reparse point
                raise ValueError("link entry")
        z.extractall(str(dest))


_OLD_RX = re.compile(r"\.old-[0-9a-f]{8}$")


def _recover(final: Path) -> None:
    """A swap interrupted earlier (H8, R2-5). Only Qosha's own leftovers count: "<name>.old-<8 hex>" that are real
    folders (never a link, never the person's "<name>.old-manual"). When <name> is missing the newest real one is
    put back; the others are removed only once <name> exists again."""
    try:
        if not final.parent.is_dir() or _is_link(final.parent):
            return
        olds = []
        for p in final.parent.iterdir():
            if p.name.startswith(final.name) and _OLD_RX.fullmatch(p.name[len(final.name):]) \
                    and not _is_link(p) and p.is_dir():
                olds.append((os.lstat(str(p)).st_mtime, p))
        olds = [p for _, p in sorted(olds, key=lambda t: t[0], reverse=True)]
        if olds and not os.path.lexists(final):
            os.replace(str(olds[0]), str(final))
            olds = olds[1:]
        if os.path.lexists(final):
            for o in olds:
                shutil.rmtree(str(o), ignore_errors=True)
    except OSError:
        pass


def _swap_in(new: Path, final: Path) -> None:
    old = final.with_name(final.name + ".old-" + os.urandom(4).hex())
    moved = False
    if final.exists() or _is_link(final):
        os.replace(str(final), str(old))
        moved = True
    try:
        os.replace(str(new), str(final))
    except BaseException:
        if moved and not os.path.lexists(final):
            os.replace(str(old), str(final))       # the old install goes back where it was (H8)
        raise
    if old.exists():
        shutil.rmtree(str(old), ignore_errors=True)


def _install_tree(zpath: Path, final: Path, check=None) -> str:
    """Install a vendored tree from zpath into final unless the same manifest is already there."""
    if _is_link(final) or _is_link(final.parent):
        return "failed: the tools folder is a link"
    _recover(final)                                # before any payload check (R2-5)
    want = _manifest_of(zpath)
    if not zpath.is_file() or not want:
        return "skipped: not in this payload"
    if final.is_dir() and tree_manifest(final) == want and (check is None or check(final)):
        return "kept"
    final.parent.mkdir(parents=True, exist_ok=True)
    new = Path(tempfile.mkdtemp(prefix="." + final.name + ".new-", dir=str(final.parent)))
    try:
        _safe_extract(zpath, new)
        if tree_manifest(new) != want or (check is not None and not check(new)):
            raise ValueError("manifest mismatch")
        _swap_in(new, final)
        return "ok"
    except Exception as exc:
        shutil.rmtree(str(new), ignore_errors=True)
        return "failed: %s" % type(exc).__name__


# ---- C2 Outlook ---------------------------------------------------------------------------------------------------
def install_microsoft(home: Path, layer: Path) -> str:
    try:
        def pinned(root: Path) -> bool:
            pkg = root / "node_modules" / "@softeria" / "ms-365-mcp-server" / "package.json"
            return json.loads(pkg.read_text(encoding="utf-8")).get("version") == MS_PINNED
        return _install_tree(Path(layer) / "connectors" / "qosha-microsoft.zip",
                             Path(home) / "tools" / "qosha-microsoft", pinned)
    except Exception as exc:
        return "failed: %s" % type(exc).__name__


def microsoft_entry(data: Dict[str, Any], home: Path, layer: Path = None) -> str:
    """The Outlook entry is taken out FIRST and put back only for a verified install (H1, R2-1): any error, a missing
    helper, zip or manifest leaves no entry at all."""
    servers = data.get("mcp_servers") if isinstance(data.get("mcp_servers"), dict) else None
    old = servers.pop("microsoft", None) if servers is not None else None
    try:
        zpath = Path(layer) / "connectors" / "qosha-microsoft.zip" if layer else None
        want = _manifest_of(zpath) if zpath is not None and zpath.is_file() else ""
        tree = Path(home) / "tools" / "qosha-microsoft"
        verified = bool(want) and tree.is_dir() and not _is_link(tree) and tree_manifest(tree) == want
        canon = None
        if verified:
            mc = _load("qosha_setup_mc", _guard(home) / "microsoft_connect.py")
            canon = mc.server_config(str(home))
        if not isinstance(canon, dict):
            return "skipped: Outlook server not verified on this computer" + (" (entry removed)" if old is not None else "")
        keep = (isinstance(old, dict) and old.get("enabled") is True
                and all(old.get(k) == canon[k] for k in ("command", "args", "env")) and set(old) == set(canon))
        new = dict(canon)
        new["enabled"] = bool(keep)
        if servers is None:
            servers = {}
            data["mcp_servers"] = servers
        servers["microsoft"] = new
        return "kept" if old == new else "ok"
    except Exception as exc:
        return "failed: %s (entry removed)" % type(exc).__name__


# ---- C3 Dropbox ---------------------------------------------------------------------------------------------------
def dropbox_entry(data: Dict[str, Any], home: Path) -> str:
    try:
        cat = json.loads((_guard(home) / "mcp_catalog.json").read_text(encoding="utf-8"))
        eng = next((s.get("engine") for s in cat.get("servers", []) if s.get("name") == "dropbox"), None)
        if not isinstance(eng, dict):
            return "skipped: Dropbox not in this catalog"
        servers = data.get("mcp_servers") if isinstance(data.get("mcp_servers"), dict) else {}
        old = servers.get("dropbox")
        new = json.loads(json.dumps(eng))
        same_url = isinstance(old, dict) and old.get("url") == eng.get("url")
        new["enabled"] = bool(same_url and old.get("enabled") is True)
        if old == new:
            return "kept"
        servers["dropbox"] = new
        data["mcp_servers"] = servers
        return "ok"
    except Exception as exc:
        return "failed: %s" % type(exc).__name__


# ---- C4 WhatsApp bridge -------------------------------------------------------------------------------------------
def install_whatsapp(home: Path, layer: Path, engine: Path) -> str:
    try:
        engine_src = Path(engine) / "scripts" / "whatsapp-bridge"
        pb_path = Path(layer) / "candidate" / "whatsapp" / "patch_bridge.py"
        zpath = Path(layer) / "connectors" / "qosha-whatsapp-node_modules.zip"
        final = Path(home) / "tools" / "qosha-whatsapp"
        if _is_link(final) or _is_link(final.parent):
            return "failed: the tools folder is a link"
        _recover(final)                            # before any payload check (R2-5)
        want = _manifest_of(zpath)
        bridge_want = _manifest_of(Path(layer) / "connectors" / "engine-whatsapp-bridge.zip")
        if not (engine_src.is_dir() and pb_path.is_file() and zpath.is_file() and want and bridge_want):
            return "skipped: not in this payload or engine"
        final.parent.mkdir(parents=True, exist_ok=True)
        # the engine's bridge sources, copied and checked against the reviewed manifest before patching (H3)
        stage = Path(tempfile.mkdtemp(prefix=".qosha-wa-src-", dir=str(final.parent)))
        src = stage / "whatsapp-bridge"
        try:
            shutil.copytree(str(engine_src), str(src), symlinks=True,
                            ignore=shutil.ignore_patterns("node_modules", "*.test.*"))
            if tree_manifest(src) != bridge_want:
                shutil.rmtree(str(stage), ignore_errors=True)
                return "skipped: engine bridge changed" + ("; old install kept" if final.is_dir() else "")
        except Exception as exc:
            shutil.rmtree(str(stage), ignore_errors=True)
            return "failed: %s" % type(exc).__name__
        new = Path(tempfile.mkdtemp(prefix=".qosha-whatsapp.new-", dir=str(final.parent)))
        shutil.rmtree(str(new))                    # patch_bridge makes DEST itself (and refuses an existing one)
        try:
            pb = _load("qosha_setup_pb", pb_path)
            if pb.build(src, new) != 0:
                return "skipped: engine bridge changed" + ("; old install kept" if final.is_dir() else "")
            nm = new / "node_modules"
            nm.mkdir()
            _safe_extract(zpath, nm)
            if tree_manifest(nm) != want:
                raise ValueError("manifest mismatch")
            if final.is_dir() and tree_manifest(final) == tree_manifest(new):
                shutil.rmtree(str(new), ignore_errors=True)
                return "kept"
            _swap_in(new, final)
            return "ok"
        except Exception as exc:
            shutil.rmtree(str(new), ignore_errors=True)
            return "failed: %s" % type(exc).__name__
        finally:
            shutil.rmtree(str(stage), ignore_errors=True)
    except Exception as exc:
        return "failed: %s" % type(exc).__name__


# ---- C5 the engine's WhatsApp gateway off -------------------------------------------------------------------------
def gateway_off(data: Dict[str, Any]) -> str:
    try:
        plats = data.get("platforms")
        if not isinstance(plats, dict):
            plats = {}
        wa = plats.get("whatsapp")
        if not isinstance(wa, dict):
            wa = {}
        if wa.get("enabled") is False and data.get("platforms") is plats:
            return "kept"
        wa["enabled"] = False
        plats["whatsapp"] = wa
        data["platforms"] = plats
        return "ok"
    except Exception as exc:
        return "failed: %s" % type(exc).__name__


_ENV_WA = re.compile(rb"^\s*(?:export\s+)?['\"]?WHATSAPP_ENABLED['\"]?\s*=")


def _env_without_whatsapp(raw: bytes):
    """The .env text rebuilt from the engine's own dotenv parser, every WHATSAPP_ENABLED binding (quoted key or not)
    left out by position, everything else byte for byte (H5). None: can't parse or the pieces don't add up."""
    try:
        from dotenv.parser import parse_stream
    except Exception:
        return None
    import io
    text = raw.decode("utf-8", errors="surrogateescape")
    every, pieces, dropped = [], [], 0
    for b in parse_stream(io.StringIO(text)):
        if getattr(b, "error", False):
            return None
        every.append(b.original.string)
        if str(b.key or "").strip("'\"") == "WHATSAPP_ENABLED":
            dropped += 1
            continue
        pieces.append(b.original.string)
    if "".join(every) != text:                    # the parser's pieces must cover the file exactly
        return None
    return dropped, "".join(pieces).encode("utf-8", errors="surrogateescape")


def env_off(home: Path) -> str:
    try:
        env = Path(home) / ".env"
        if _is_link(env):
            return "skipped: .env is a link"
        if not env.exists():
            return "kept"
        raw = env.read_bytes()
        parsed = _env_without_whatsapp(raw)
        if parsed is not None:
            dropped, new = parsed
            if not dropped:
                return "kept"
            if len(new) >= len(raw):
                return "skipped: .env too complex"
        else:
            lines = raw.splitlines(keepends=True)
            # escaped characters taken out before counting quotes (R2-3): an open quote may start a multiline
            # value whose end can't be found without the parser, so the file is left unchanged
            if any((lambda s: s.count(b"'") % 2 or s.count(b'"') % 2)(re.sub(rb"\\.", b"", l)) or l.rstrip(b"\r\n").endswith(b"\\")
                   for l in lines):
                return "skipped: .env too complex"
            keep = [l for l in lines if not _ENV_WA.match(l)]
            if len(keep) == len(lines):
                return "kept"
            new = b"".join(keep)
        mode = stat.S_IMODE(os.stat(env).st_mode)
        tmp = env.with_name(".env.%s.tmp" % os.urandom(4).hex())
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
        try:
            with os.fdopen(fd, "wb") as fh:
                if os.name != "nt":                   # the old mode exactly, whatever the umask (M); a failure keeps
                    os.fchmod(fh.fileno(), mode)      # the original as it is (R2-9)
                    if stat.S_IMODE(os.fstat(fh.fileno()).st_mode) != mode:
                        raise OSError("mode not kept")
                fh.write(new)
            os.replace(str(tmp), str(env))
        except BaseException:
            try:
                os.unlink(str(tmp))                   # no copy of the secrets left behind (M)
            except OSError:
                pass
            raise
        return "ok"
    except Exception as exc:
        return "failed: %s" % type(exc).__name__


# ---- C6 Qosha's browser never reaches WhatsApp Web ----------------------------------------------------------------
def _rule_covers_whatsapp(rule: str) -> bool:
    import fnmatch
    parts = rule.split()
    if len(parts) < 2 or parts[0].upper() not in ("MAP", "EXCLUDE"):
        return False
    pat = parts[1].lower().split(":")[0]
    return fnmatch.fnmatchcase("web.whatsapp.com", pat)


def browser_flag(data: Dict[str, Any]) -> str:
    """One --host-resolver-rules flag, Qosha's WhatsApp Web block FIRST; the person's other rules kept in order, minus
    any MAP or EXCLUDE that would cover web.whatsapp.com (H6)."""
    try:
        br = data.get("browser") if isinstance(data.get("browser"), dict) else {}
        args = list(br.get("chromium_args") or []) if isinstance(br.get("chromium_args"), list) else []
        theirs, rest = [], []
        for a in args:
            if isinstance(a, str) and a.startswith("--host-resolver-rules="):
                theirs += [r.strip() for r in a.split("=", 1)[1].split(",") if r.strip()]
            else:
                rest.append(a)
        rules = [WA_RULE]
        for r in theirs:
            if r != WA_RULE and not _rule_covers_whatsapp(r) and r not in rules:
                rules.append(r)
        flag = "--host-resolver-rules=" + ", ".join(rules)
        cut = rest.index("--") if "--" in rest else len(rest)    # switches only before Chromium's "--" (R2-6)
        new = rest[:cut] + [flag] + rest[cut:]
        if args == new:
            return "kept"
        br["chromium_args"] = new
        data["browser"] = br
        return "ok"
    except Exception as exc:
        return "failed: %s" % type(exc).__name__


# ---- entry points used by setup_home ------------------------------------------------------------------------------
def install_files(home, layer, engine) -> List[str]:
    out = []
    for name, fn in (("outlook server", lambda: install_microsoft(Path(home), Path(layer))),
                     ("whatsapp bridge", lambda: install_whatsapp(Path(home), Path(layer), Path(engine))),
                     ("whatsapp gateway (.env)", lambda: env_off(Path(home)))):
        try:
            out.append("%s: %s" % (name, fn()))
        except Exception as exc:
            out.append("%s: failed: %s" % (name, type(exc).__name__))
    return out


def config_steps(data: Dict[str, Any], home, layer=None) -> List[str]:
    out = []
    for name, fn in (("outlook entry", lambda: microsoft_entry(data, Path(home), Path(layer) if layer else None)),
                     ("dropbox entry", lambda: dropbox_entry(data, Path(home))),
                     ("whatsapp gateway", lambda: gateway_off(data)),
                     ("browser whatsapp web block", lambda: browser_flag(data))):
        try:
            out.append("%s: %s" % (name, fn()))
        except Exception as exc:
            out.append("%s: failed: %s" % (name, type(exc).__name__))
    return out


def after(root, layer, runner=None) -> str:
    """The documents environment, built by a detached process that outlives setup (setup never waits for it); its
    one-line result goes to <home>/logs/qosha-documents.log."""
    try:
        import subprocess
        script = Path(layer) / "documents_env.py"
        if not script.is_file():
            return "documents: skipped (not in this payload)"
        logs = Path(root) / "home" / "logs"
        logs.mkdir(parents=True, exist_ok=True)
        log = logs / "qosha-documents.log"
        if _is_link(log) or _is_link(logs):
            return "documents: skipped (its log is a link)"
        fd = os.open(str(log), os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
        fh = os.fdopen(fd, "ab")
        kw = {"stdin": subprocess.DEVNULL, "stdout": fh, "stderr": subprocess.STDOUT, "cwd": str(Path(root))}
        if os.name == "nt":
            kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
        else:
            kw["start_new_session"] = True
        (runner or subprocess.Popen)([sys.executable, "-I", str(script), "--root", str(root)], **kw)
        fh.close()
        return "documents: building in the background"
    except Exception as exc:
        return "documents: skipped (%s)" % type(exc).__name__
