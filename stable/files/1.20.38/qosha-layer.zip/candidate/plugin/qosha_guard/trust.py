"""Trust mode (Ren, card 23 Nov 2026 ~16:40 MST, verbatim choice "Go (Recommended)"; design and threats:
proposals/TRUST-MODE-DESIGN.md).

A per-person switch, OFF by default: "Trust mode: Qosha does what you ask without asking first". When ON, no Allow card
is shown for any kind of step; each step that would have asked is written to <home>/qosha/trust-log.jsonl (shown in
Settings > Approvals) and Stop works as always. One exception, as Ren decided the same day ("All but its safety code"):
Qosha's own safety code and approval settings (the approval.self card) still ask every time. A command the engine could
not read to the end still asks too (the engine's own rule for its yolo mode).

Only the person turns it ON, in the Qosha app window (the owner gate refuses every other caller, and the route checks
again). Turning it OFF works from anywhere, and Qosha may do it when asked (qosha_trust). Any other step that names the
switch file is refused, never a card. A missing, unreadable or malformed switch reads as OFF. Nothing here may raise
into the engine.
"""
import json
import logging
import os
import re
import threading
import time

log = logging.getLogger("qosha.trust")

FILE = "trust-mode.json"
# Council 23 Nov 2026 ~19:05 MST (Claude + Gemini "B", GPT "C"; majority B with Gemini's guardrail): until the trusted
# dialog owns the switch (the trusted-surface slices), the switch is honored only on the founder's update ring. Every
# other install ignores it (cards as before), so an AI that writes the file by a spelling the name rule can't see turns
# nothing on there. Remove this gate with the dialog slice.
TRUST_RINGS = ("ren-mac",)
# Council 23 Nov 2026 ~22:10 MST (Claude, GPT-6.2 Astra, Gemini 4 Neon: all "A"): the ring file is AI-writable without a
# card, so the ring alone does not keep clients out. The switch is honored only on the founder's own installs, named here
# by the fingerprint of their install-id.json (_install_tag: sha256, 24 hex; the ID holds 80 random bits and is never
# published). This list is plugin code, so changing it is a safety-code edit (a card every time, never trusted).
# Ren's MacBook Pro now; the Air is added once its fingerprint is read on the Air. Remove with the dialog slice.
TRUST_INSTALLS = ("2c9f3206afd46586e4f575c2",)
NOT_YET = "Trust mode isn't available on this computer yet. It comes with a later Qosha update."
LOG = "trust-log.jsonl"
LOG_MAX = 1_000_000            # bytes; the log is rotated once to trust-log.jsonl.1
STRICT_PREFIX = "plugin_rule:qosha:approval.self"   # approval_gate.SELF_EDIT_KEY: always asks
SCAN_INCOMPLETE = "command too complex to scan fully; review before running"   # tools.approval_detection
UNREAD_PREFIX = "plugin_rule:qosha:unread:"        # ask.py's card for such a command (one time, never trusted)
REFUSED = ("Not done: Trust mode is switched on only by the person, in Settings > Approvals in the Qosha app window. "
           "Qosha never changes that switch or its log with a command or a file edit. To see it or switch it off, use "
           "the qosha_trust tool. Nothing ran.")
NO_ID = "Trust mode can't be turned on yet: this Qosha has no install ID. Restart Qosha and try again."
ON_REFUSED = "Only the Qosha app window can turn on Trust mode. Open the Qosha app and do it in Settings > Approvals."
_READS = {"read_file", "search_files", "list_files", "list_directory", "web_search", "web_extract", "vision_analyze",
          "video_analyze", "skill_view", "skills_list", "session_search", "qosha_trust"}
# the switch and its log, however a step spells the name ("trust-" + "mode.json", trust_mode.json, TRUST\-MODE.JSON)
_NAMES = re.compile(r"trust[\W_]{0,3}mode[\W_]{0,3}json|trust[\W_]{0,3}log[\W_]{0,3}jsonl", re.I)
# a shell pattern on the name (trust-mod?.json, trust*.json), read in the step's raw text: a space, slash or quote ends
# a file name, so "Do you trust? Check app.js" or trust?.a in code is not one
_GLOB = re.compile(r"trust[^\s/\\'\"]{0,12}?[?*\[][^\s/\\'\"]{0,12}?\.js", re.I)
# a path into Qosha's folder that names anything starting with "trust" (trust*, "$HERMES_HOME"/qosha/trust...)
_PATH = re.compile(r"qosha['\"]?[\\/]+['\"]?trust", re.I)
_lock = threading.Lock()


def _home() -> str:
    try:
        from hermes_constants import get_hermes_home
        return str(get_hermes_home())
    except Exception:
        return os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")


def _anchor(home) -> str:
    """The install's main home: a profile's home (<home>/profiles/<name>) shares the install's switch (as
    access.anchor does for the install's ID), so turning Trust off in any profile turns it off for the install."""
    h = os.path.abspath(str(home))
    try:
        up = os.path.dirname(h)
        if os.path.basename(up) == "profiles":
            root = os.path.dirname(up)
            if (os.path.isdir(os.path.join(root, "qosha")) or os.path.exists(os.path.join(root, "config.yaml"))
                    or os.path.isdir(os.path.join(os.path.dirname(root), "engine"))):
                return root
    except OSError:
        pass
    return h


def _dir(home=None) -> str:
    return os.path.join(_anchor(home or _home()), "qosha")


def _install_tag(home=None) -> str:
    """A fingerprint of THIS install's Qosha ID file (<home>/qosha/install-id.json). Importing another install's home
    never brings that file (the installers exclude it), so a switch copied from elsewhere does not match: OFF.
    No ID file = no tag = OFF."""
    import hashlib
    try:
        with open(os.path.join(_dir(home), "install-id.json"), "rb") as fh:
            raw = fh.read(65536)
    except Exception:
        return ""
    return hashlib.sha256(raw).hexdigest()[:24] if raw.strip() else ""


# ---- the switch -----------------------------------------------------------------------------------------------------
def available(home=None) -> bool:
    """This install is one of the founder's (TRUST_INSTALLS) AND on a ring where Trust mode is honored (TRUST_RINGS).
    No ID, unreadable or anything else = not available."""
    try:
        tag = _install_tag(home)
        if not tag or tag not in TRUST_INSTALLS:
            return False
        with open(os.path.join(_dir(home), "updates-config.json"), encoding="utf-8") as fh:
            c = json.load(fh)
        return isinstance(c, dict) and c.get("ring") in TRUST_RINGS
    except Exception:
        return False


def state(home=None) -> dict:
    """{"on": bool, "changed_at": float|None, "by": str}; anything unreadable is OFF."""
    try:
        with open(os.path.join(_dir(home), FILE), encoding="utf-8") as fh:
            d = json.load(fh)
        if isinstance(d, dict):
            tag = _install_tag(home)
            on = d.get("on") is True and bool(tag) and d.get("install") == tag    # copied from another install: OFF
            on = on and available(home)                                          # only on TRUST_RINGS for now
            return {"on": on, "changed_at": d.get("changed_at"), "by": str(d.get("by") or "")}
    except Exception:
        pass
    return {"on": False, "changed_at": None, "by": ""}


def is_on(home=None) -> bool:
    """Read on every approval (two small files, no cache): a switch turned off, or made unreadable, counts at once."""
    try:
        return state(home)["on"] is True
    except Exception:
        return False


def set_on(on: bool, by: str, home=None) -> dict:
    d = _dir(home)
    os.makedirs(d, mode=0o700, exist_ok=True)
    tag = _install_tag(home)
    if on and not tag:
        raise RuntimeError("this install has no Qosha ID yet")      # the switch would read OFF anyway
    if on and not available(home):
        raise LookupError("not on a Trust mode ring")
    rec = {"on": bool(on), "changed_at": time.time(), "by": by, "install": tag}
    import secrets
    tmp = os.path.join(d, FILE + ".tmp%d-%s" % (os.getpid(), secrets.token_hex(4)))
    with _lock:
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(rec, fh)
        os.replace(tmp, os.path.join(d, FILE))
    record({"event": "trust_on" if on else "trust_off", "by": by}, home)
    return state(home)


# ---- the log ----------------------------------------------------------------------------------------------------------
def record(entry: dict, home=None) -> bool:
    """Append one line; False when it could not be written (a step is then not done without asking)."""
    try:
        d = _dir(home)
        os.makedirs(d, mode=0o700, exist_ok=True)
        p = os.path.join(d, LOG)
        line = json.dumps(dict({"at": time.time()}, **entry), ensure_ascii=False, default=str)
        with _lock:
            try:
                if os.path.getsize(p) > LOG_MAX:
                    os.replace(p, p + ".1")
            except OSError:
                pass
            with open(p, "a", encoding="utf-8") as fh:
                fh.write(line + "\n")
                fh.flush()
        return True
    except Exception as exc:
        log.warning("trust log not written: %s", type(exc).__name__)
        return False


def recent(n: int = 20, home=None) -> list:
    try:
        with open(os.path.join(_dir(home), LOG), encoding="utf-8") as fh:
            lines = fh.readlines()[-max(1, min(int(n), 200)):]
    except Exception:
        return []
    out = []
    for ln in reversed(lines):
        try:
            out.append(json.loads(ln))
        except Exception:
            continue
    return out


# ---- the engine's one human-approval function -------------------------------------------------------------------------
def _trusted(keys: list) -> bool:
    if any(str(k).startswith(STRICT_PREFIX) for k in keys):
        return False                       # Qosha's safety code and approval settings: always the person
    if any(SCAN_INCOMPLETE in str(k) or str(k).startswith(UNREAD_PREFIX) for k in keys):
        return False                       # a command nobody could read to the end, alone or in a compound rule
    import sys
    fs = sys.modules.get("qosha_gate_failsafe_state")
    if fs is not None and getattr(fs, "failed", None):
        return False                       # Qosha's approval check is down: nothing is granted (gate_failsafe.py)
    sd = sys.modules.get("qosha_gate_failsafe")
    if sd is not None and getattr(sd, "FAILED", None):
        return False                       # the dashboard's stand-in says the check is down (plugin_api._gate_down)
    return is_on()


def _what(description) -> str:
    s = str(description or "").strip().split("\n", 1)[0]
    return s[:240]


def patch_gate() -> bool:
    """Wrap tools.approval._human_decision (every card and prompt the engine shows a person goes through it). With Trust
    mode ON a step is approved as if the person pressed "Allow this time": the engine's own post_approval_response hook
    fires with choice "once" (decided_by "qosha_trust"), so every consent that hangs off an Allow happens as usual."""
    try:
        from tools import approval as ap
        from tools import approval_context as ac
    except Exception:
        return False
    hd = getattr(ap, "_human_decision", None)
    if hd is None:
        return False
    if getattr(hd, "qosha_trust", False):
        return True

    def _human_decision(spec, *a, **kw):
        try:
            keys = [str(kw.get("pattern_key") or "")] + [str(k) for k in (kw.get("pattern_keys") or [])]
            trusted = _trusted(keys)
        except Exception:
            trusted = False
        if not trusted:
            return hd(spec, *a, **kw)
        sk, desc = kw.get("session_key") or "", kw.get("description") or ""
        if not record({"event": "step", "key": str(kw.get("pattern_key") or "")[:200], "what": _what(desc),
                       "session": str(sk)[:120]}):
            return hd(spec, *a, **kw)         # the step could not be logged: the person is asked, as without Trust
        try:
            ac._fire_approval_hook("post_approval_response", command=kw.get("command"), description=desc,
                                   pattern_key=kw.get("pattern_key"), pattern_keys=list(kw.get("pattern_keys") or []),
                                   session_key=sk, surface="qosha:trust", choice="once", decided_by="qosha_trust")
        except Exception:
            pass
        log.info("Trust mode: allowed without asking: %s", str(kw.get("pattern_key") or "")[:120])
        # never marked as a person's approval (user_approved): the engine would then clear a Stop that is already
        # pending before the command runs (terminal_tool, clear_interrupt)
        return ap._approved()

    _human_decision.qosha_trust = True
    _human_decision.__wrapped__ = hd
    ap._human_decision = _human_decision
    return True


def patch_always_consent() -> bool:
    """A card whose rule the person already set to "Always allow" is approved by the engine without a prompt, and then
    the engine fires no post_approval_response: the consents that hang off an Allow (Qosha's Google write grant, a
    WhatsApp read pass, a desktop step's binding) would never be given, and the step would be refused after all. Here,
    for Qosha's own rules (never its safety code), an approval that came from a saved "Always allow" fires that hook
    with choice "always", exactly as a person's answer "always" does (Ren, 23 Nov 2026: every kind offers Always allow)."""
    try:
        from tools import approval as ap
        from tools import approval_context as ac
    except Exception:
        return False
    gate = getattr(ap, "_run_approval_gate", None)
    if gate is None:
        return False
    if getattr(gate, "qosha_always", False):
        return True

    def _run_approval_gate(*a, **kw):
        pk, sk, saved = str(kw.get("pattern_key") or ""), "", False
        if pk.startswith("plugin_rule:qosha:") and not pk.startswith(STRICT_PREFIX):
            try:
                sk = ap.get_current_session_key()
                saved = bool(ap.is_approved(sk, pk))
            except Exception:
                saved = False
        r = gate(*a, **kw)
        if saved and isinstance(r, dict) and r.get("approved"):
            try:
                ac._fire_approval_hook("post_approval_response", command=kw.get("display_target"),
                                       description=kw.get("description") or "", pattern_key=pk, pattern_keys=[pk],
                                       session_key=sk, surface="qosha:always", choice="always",
                                       decided_by="always_allow")
            except Exception:
                pass
        return r

    _run_approval_gate.qosha_always = True
    _run_approval_gate.__wrapped__ = gate
    ap._run_approval_gate = _run_approval_gate
    return True


# ---- what the assistant may not do -----------------------------------------------------------------------------------
class _TooBig(Exception):
    pass


def _strings(v, out, depth=0):
    if depth > 12 or len(out) > 5000:
        raise _TooBig()                    # not every value was read: the step is refused (fail closed)
    if isinstance(v, dict):
        for k, x in v.items():
            out.append(str(k))
            _strings(x, out, depth + 1)
    elif isinstance(v, (list, tuple, set)):
        for x in v:
            _strings(x, out, depth + 1)
    elif v is not None:
        out.append(str(v))


def _flat(args) -> str:
    """The step's own text values as they are (a Windows path keeps its backslashes as path separators), with quotes,
    joins and separators dropped: "trust-" + "mode.json", an escaped dash, a Windows path all read the same."""
    out: list = []
    _strings(args, out)
    text = "\n".join(out)
    return re.sub(r"[\s'\"`+\\^/]+", "", text)


def pre_tool_call(tool_name: str = "", args=None, **_kw):
    try:
        if str(tool_name or "") in _READS:
            return None
        raw: list = []
        _strings(args, raw)
        text = "\n".join(raw)
        if _NAMES.search(_flat(args)) or _NAMES.search(_flat(tool_name)) or _PATH.search(text) or _GLOB.search(text):
            return {"action": "block", "message": REFUSED}
    except Exception:
        return {"action": "block", "message": REFUSED}
    return None


# ---- the assistant's own tool: see it, or switch it off --------------------------------------------------------------
SCHEMA = {
    "name": "qosha_trust",
    "description": ("See whether Trust mode is on (Qosha acts without asking first), or switch it OFF when the person "
                    "asks. Qosha can never switch it on: only the person can, in Settings > Approvals in the Qosha app."),
    "parameters": {"type": "object", "properties": {"action": {"type": "string", "enum": ["status", "off"]}},
                   "required": ["action"]},
}


def _tool(args=None, **_kw) -> str:
    a = args if isinstance(args, dict) else {}
    if a.get("action") == "off":
        st = set_on(False, "qosha-at-request")
        return json.dumps({"ok": True, "on": st["on"], "say": "Trust mode is off: Qosha asks before it acts again."})
    st = state()
    return json.dumps({"ok": True, "on": st["on"], "say": "Trust mode is %s." % ("on" if st["on"] else "off")})


def register(ctx) -> bool:
    """From the plugin's register() on the person's own computer: the refusal first, then the tool, then the gate.
    Without the refusal the gate is not patched (Trust mode then has no effect: cards as before)."""
    try:
        ctx.register_hook("pre_tool_call", pre_tool_call)
    except Exception as exc:
        log.warning("Trust mode not set up (refusal): %s", type(exc).__name__)
        return False
    try:
        ctx.register_tool(name="qosha_trust", toolset="qosha", schema=SCHEMA, handler=_tool,
                          check_fn=lambda: True, description=SCHEMA["description"], emoji="🤝")
    except Exception as exc:
        log.warning("Trust mode tool not registered: %s", type(exc).__name__)
    if not patch_always_consent():
        log.warning("Always allow: the engine's approval gate was not found; a saved Always allow may still ask")
    ok = patch_gate()
    if not ok:
        log.warning("Trust mode not set up: the engine's approval function was not found; cards stay as they are")
    return ok


# ---- the dashboard's routes (mounted by plugin_api.py) ----------------------------------------------------------------
def mount(router=None) -> None:
    if router is None:
        return
    import sys
    from fastapi import HTTPException, Request

    def _window(request: Request) -> bool:
        gate = sys.modules.get("qosha_approval_gate")
        try:
            return bool(gate is not None and getattr(gate, "_app_installed")() and gate.from_qosha_window(request.scope))
        except Exception:
            return False

    def _get(request: Request):
        st = state()
        return {"on": st["on"], "changed_at": st["changed_at"], "by": st["by"], "window": _window(request),
                "available": available(), "recent": recent(20)}

    def _on(request: Request):
        if not _window(request):
            raise HTTPException(status_code=403, detail={"error": "window_only", "plain": ON_REFUSED})
        if not available():
            raise HTTPException(status_code=409, detail={"error": "not_available", "plain": NOT_YET})
        try:
            st = set_on(True, "app-window")
        except RuntimeError:
            raise HTTPException(status_code=409, detail={"error": "no_install_id", "plain": NO_ID})
        return {"on": st["on"], "changed_at": st["changed_at"], "by": st["by"]}

    def _off(request: Request):
        st = set_on(False, "app-window" if _window(request) else "page")
        return {"on": st["on"], "changed_at": st["changed_at"], "by": st["by"]}

    router.get("/trust")(_get)
    router.post("/trust/on")(_on)
    router.post("/trust/off")(_off)
