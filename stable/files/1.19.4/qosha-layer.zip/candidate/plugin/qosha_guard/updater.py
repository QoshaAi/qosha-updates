"""Qosha updates itself (Ren, 17 Nov 2026 ~16:20: "I want whatever next onboarding or install to follow this method").

What it does, on the person's own computer (Mac and Windows alike):
- Once a day (and when asked: Settings > Version and updates, Home's notice, or in the chat) it reads the update list
  ("manifest") of its channel from the sources in order: the primary address (Qosha's cloud bucket), then the
  fallback (a public repository holding only signed release files). Both addresses come from
  <home>/qosha/updates-config.json, else the defaults below.
- A manifest counts only when its Ed25519 signature matches one of the public keys built into this file (whatever the
  source). Every file must match the size and sha256 the signed manifest gives. Refused: unsigned, wrong signature,
  older or same version, a paused channel or release, a release not meant for this computer's ring
  (ren-mac -> test-pc -> renato -> everyone), or one that needs a newer engine than this one.
- The person sees a small notice (Home and Settings) with one line of what changed: "Update now" or "Tonight"
  (2 AM local; if the computer is not on between 2 and 6 AM it waits for the next night).
- Updating runs in its own process: download and check again, back up Qosha's layer and the person's Qosha settings,
  stop Qosha, unpack the new layer and run its setup_home.py exactly as the installer's layer step does, put back the
  person's customisations, start Qosha the way it was started, then a health check: the dashboard answers, its pages
  load, the conversation list reads the same conversations, the AI accounts state and the sign-in files are unchanged,
  and the running plugin reports the new version. Any failure: automatic roll back to the version before, and one
  plain line for the person.

Customisations (where changes a person, or Qosha for them, make to Qosha's own files live): Qosha's own program files
(<home>/plugins/qosha) are replaced whole by every update and every installer run, so changes made there directly
would be lost. A changed or added file is instead kept in <home>/qosha/custom/plugin/, at the same path it has under
<home>/plugins/qosha/ (for example custom/plugin/dashboard/pages/chat.html); after every update the updater copies that
folder over the new plugin, so the person's version wins. The person's settings (config.yaml, which updates only add
Qosha's own keys to), SOUL.md, memories, skills they made, chats, sign-ins and files are never replaced by an update.
Removing a file from custom/plugin/ gives Qosha's own version back at the next update.

The engine's own self-update is switched off from Qosha's screens and chat (patch_engine_update_gate and
lock_engine_updates): engine versions come only with a Qosha release.

Standard library only, plus `cryptography` (part of the engine's own environment) for the signature check. The same
file runs three ways: imported by the dashboard (routes, daily check), imported by the plugin in the chat (tool), and
as a separate program for the update itself (python updater.py apply --root ROOT --port PORT).
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

# --- trust and sources ---------------------------------------------------------------------------------------------
# Qosha's release signing key(s): key id -> raw Ed25519 public key (base64). The private key never leaves the release
# Mac (~/.qosha-release/). A second key can be added here by a signed release before the first one is retired.
PUBLIC_KEYS = {
    "3b379198e50e171e": "uY2TmE7t4rsP+i5ttCtQMpZI1PJ4oTlQYmEDqgprnTg=",      # made 17 Nov 2026 16:36 MST
}
# Default sources (each needs Ren's OK before it exists; until then a config file names local or other addresses).
DEFAULT_PRIMARY = "https://storage.googleapis.com/qosha-updates"
DEFAULT_FALLBACK = "https://raw.githubusercontent.com/QoshaAi/qosha-updates/main"
CHANNEL = "stable"
RINGS = ("ren-mac", "test-pc", "renato", "everyone")
DEFAULT_RING = "everyone"
MANIFEST_MAX = 256 * 1024
FILE_MAX = 400 * 1024 * 1024
TONIGHT_HOUR = 2
TONIGHT_WINDOW_H = 4                 # 2 AM .. 6 AM; outside it the update waits for the next night
CHECK_EVERY_S = 24 * 3600
# a check that found no usable source (all down, or a half-refreshed file server serving a new list with the old
# signature: 17 Nov 2026, refused as it should be) is tried again sooner, not a day later
RETRY_S = 30 * 60
VERSION_RE = re.compile(r"^\d{1,4}(\.\d{1,6}){1,3}$")
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$")
WIN = os.name == "nt"
UPDATER_VERSION = 1

_lock = threading.Lock()


# --- places ----------------------------------------------------------------------------------------------------------
def home_dir() -> Path:
    h = os.environ.get("HERMES_HOME")
    if h:
        return Path(h)
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path.home() / ".hermes"


def root_dir(home: Path | None = None) -> Path | None:
    """The per-user Qosha folder (engine/, home/, layer/), or None where Qosha does not install this way (cloud box)."""
    h = (home or home_dir()).resolve()
    r = h.parent
    if (r / "layer" / "setup_home.py").is_file() and (r / "engine").is_dir() and h.name == "home":
        return r
    return None


def _qdir(home: Path) -> Path:
    d = home / "qosha"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _read_json(p: Path, default):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write_json(p: Path, data) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name("." + p.name + ".tmp")
    tmp.write_text(json.dumps(data, indent=1, sort_keys=True), encoding="utf-8")
    os.replace(tmp, p)


def load_config(home: Path | None = None) -> dict:
    h = home or home_dir()
    c = _read_json(_qdir(h) / "updates-config.json", {})
    if not isinstance(c, dict):
        c = {}
    ring = c.get("ring") if c.get("ring") in RINGS else DEFAULT_RING
    out = {"ring": ring, "channel": str(c.get("channel") or CHANNEL),
           "primary": str(c.get("primary") if c.get("primary") is not None else DEFAULT_PRIMARY),
           "fallback": str(c.get("fallback") if c.get("fallback") is not None else DEFAULT_FALLBACK),
           "auto_check": c.get("auto_check", True) is not False,
           "tick_seconds": max(1, int(c.get("tick_seconds") or 600))}
    if not re.fullmatch(r"[a-z0-9-]{1,32}", out["channel"]):
        out["channel"] = CHANNEL
    return out


def set_config(changes: dict, home: Path | None = None) -> dict:
    h = home or home_dir()
    p = _qdir(h) / "updates-config.json"
    c = _read_json(p, {})
    c = c if isinstance(c, dict) else {}
    for k, v in changes.items():
        if k == "ring" and v not in RINGS:
            raise ValueError("ring must be one of " + ", ".join(RINGS))
        c[k] = v
    _write_json(p, c)
    return load_config(h)


def load_state(home: Path | None = None) -> dict:
    s = _read_json(_qdir(home or home_dir()) / "updates.json", {})
    return s if isinstance(s, dict) else {}


def save_state(s: dict, home: Path | None = None) -> None:
    _write_json(_qdir(home or home_dir()) / "updates.json", s)


def _log(root: Path | None, msg: str) -> None:
    line = "%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        if root:
            (root / "logs").mkdir(exist_ok=True)
            with open(root / "logs" / "updates.log", "a", encoding="utf-8") as f:
                f.write(line)
    except OSError:
        pass


# --- versions --------------------------------------------------------------------------------------------------------
def vt(v: str) -> tuple:
    if not isinstance(v, str) or not (v == "0" or VERSION_RE.match(v)):
        return (-1,)
    return tuple(int(x) for x in v.split("."))


def current_version(root: Path | None = None) -> str:
    r = root or root_dir()
    if not r:
        return "0"
    rel = _read_json(r / "layer" / "RELEASE.json", {})
    v = rel.get("version") if isinstance(rel, dict) else None
    return v if isinstance(v, str) and VERSION_RE.match(v) else "0"


def engine_version(root: Path) -> str | None:
    st = _read_json(root / "engine" / "install-stamp.json", {})
    v = st.get("baseVersion") if isinstance(st, dict) else None
    return v if isinstance(v, str) and VERSION_RE.match(v) else None


# --- fetching and checking -------------------------------------------------------------------------------------------
class Refused(Exception):
    """A source answered, but what it served is not acceptable (signature, hash, version, ...)."""


def _url_ok(url: str) -> bool:
    u = urllib.parse.urlsplit(url)
    if u.scheme == "https" and u.hostname:
        return True
    return u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost", "::1")


def _get(url: str, limit: int, timeout: float = 20.0) -> bytes:
    if not _url_ok(url):
        raise Refused("address not allowed (https only): %s" % url)
    req = urllib.request.Request(url, headers={"User-Agent": "Qosha-Updater/%d" % UPDATER_VERSION,
                                               "Cache-Control": "no-cache"})
    opener = urllib.request.build_opener()
    if urllib.parse.urlsplit(url).hostname in ("127.0.0.1", "localhost", "::1"):
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req, timeout=timeout) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise Refused("answer too large")
    return data


def verify_signature(data: bytes, sig_doc: bytes) -> str:
    """Returns the key id that signed `data`; raises Refused otherwise (also when the check cannot run: fail closed)."""
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except Exception:
        raise Refused("signature check not available on this computer")
    try:
        d = json.loads(sig_doc.decode("utf-8"))
        sig = base64.b64decode(d["sig"], validate=True)
        assert d.get("alg") == "ed25519" and len(sig) == 64
    except Exception:
        raise Refused("signature file unreadable")
    for kid, pk in PUBLIC_KEYS.items():
        try:
            Ed25519PublicKey.from_public_bytes(base64.b64decode(pk)).verify(sig, data)
            return kid
        except InvalidSignature:
            continue
        except Exception:
            continue
    raise Refused("signature does not match Qosha's key")


def _valid_release(r) -> bool:
    try:
        assert isinstance(r, dict) and VERSION_RE.match(r["version"])
        assert isinstance(r.get("rings"), list) and r["rings"] and all(x in RINGS for x in r["rings"])
        assert isinstance(r.get("notes", ""), str) and len(r.get("notes", "")) <= 300
        assert isinstance(r.get("files"), list) and r["files"]
        for f in r["files"]:
            assert NAME_RE.match(f["name"]) and re.fullmatch(r"[0-9a-f]{64}", f["sha256"])
            assert isinstance(f["size"], int) and 0 < f["size"] <= FILE_MAX
            assert f["path"] == "files/%s/%s" % (r["version"], f["name"])
        assert any(f["name"] == "qosha-layer.zip" for f in r["files"])
        if r.get("min_engine") is not None:
            assert VERSION_RE.match(r["min_engine"])
        return True
    except Exception:
        return False


def read_manifest(base: str, channel: str) -> dict:
    """The signed manifest of one source; raises OSError (source down) or Refused (served something unacceptable)."""
    base = base.rstrip("/")
    bust = "?t=%d" % int(time.time())
    data = _get("%s/%s/manifest.json%s" % (base, channel, bust), MANIFEST_MAX)
    sig = _get("%s/%s/manifest.json.sig%s" % (base, channel, bust), 4096)
    kid = verify_signature(data, sig)
    try:
        m = json.loads(data.decode("utf-8"))
    except ValueError:
        raise Refused("manifest unreadable")
    if not (isinstance(m, dict) and m.get("schema") == 1 and m.get("product") == "qosha"
            and m.get("channel") == channel and isinstance(m.get("releases"), list)):
        raise Refused("manifest is not a Qosha manifest for this channel")
    m["_key_id"] = kid
    return m


def pick_release(m: dict, ring: str, current: str, engine: str | None, skip=()):
    """(release or None, reason) for this computer. `skip`: versions that already failed here (rolled back)."""
    if m.get("paused") is True:
        return None, "paused"
    best, why = None, "up_to_date"
    for r in m["releases"]:
        if not _valid_release(r):
            continue
        if vt(r["version"]) <= vt(current) or r["version"] in skip:
            continue
        if r.get("paused") is True:
            why = why if best else "paused"
            continue
        if ring not in r["rings"] and "everyone" not in r["rings"]:
            why = why if best else "not_for_this_ring"
            continue
        if r.get("min_engine") and (engine is None or vt(engine) < vt(r["min_engine"])):
            why = why if best else "needs_newer_engine"
            continue
        if best is None or vt(r["version"]) > vt(best["version"]):
            best = r
    return (best, "available") if best else (None, why)


def find_update(home: Path | None = None, root: Path | None = None) -> dict:
    """Asks the sources in order. Result: {status, release?, source?, tried:[...]} (no exception)."""
    h = home or home_dir()
    r = root or root_dir(h)
    cfg = load_config(h)
    cur = current_version(r)
    eng = engine_version(r) if r else None
    tried = []
    for name in ("primary", "fallback"):
        base = cfg[name]
        if not base:
            continue
        try:
            m = read_manifest(base, cfg["channel"])
        except Refused as e:
            tried.append({"source": name, "result": "refused", "why": str(e)})
            continue
        except (OSError, ValueError, urllib.error.URLError) as e:
            tried.append({"source": name, "result": "unreachable", "why": type(e).__name__})
            continue
        rel, why = pick_release(m, cfg["ring"], cur, eng, load_state(h).get("failed_versions") or [])
        tried.append({"source": name, "result": why})
        out = {"status": why, "current": cur, "ring": cfg["ring"], "tried": tried, "source": name, "base": base}
        if rel:
            out["release"] = {k: rel[k] for k in ("version", "notes", "rings", "files", "min_engine", "created") if k in rel}
        return out
    return {"status": "unreachable", "current": cur, "ring": cfg["ring"], "tried": tried}


def check(home: Path | None = None, quiet: bool = False) -> dict:
    """Checks now and remembers the answer for the screens."""
    h = home or home_dir()
    res = find_update(h)
    with _lock:
        s = load_state(h)
        s["last_check"] = int(time.time())
        s["last_check_status"] = res["status"]
        if res.get("release"):
            s["available"] = {"version": res["release"]["version"], "notes": res["release"].get("notes", "")}
        elif res["status"] in ("up_to_date", "paused", "not_for_this_ring", "needs_newer_engine"):
            s.pop("available", None)
            if (s.get("tonight") or {}).get("version") and res["status"] != "unreachable":
                s.pop("tonight", None)      # a paused or withdrawn release is not applied at night
        d = s.get("deferred")
        if d and (time.time() >= d.get("until", 0) or d.get("version") != (s.get("available") or {}).get("version")):
            s.pop("deferred", None)         # "Later" lasts until the next day's check, and only for that version
        save_state(s, h)
    _log(root_dir(h), "check: %s (current %s, ring %s; %s)" % (
        res["status"], res["current"], res["ring"],
        "; ".join("%s=%s" % (t["source"], t["result"]) for t in res["tried"])))
    return status(h)


def download(rel: dict, bases: list, dest: Path, channel: str = CHANNEL) -> dict:
    """Every file of the release into dest, checked against the signed size and sha256 (any source may serve it)."""
    dest.mkdir(parents=True, exist_ok=True)
    out = {}
    for f in rel["files"]:
        got, last = None, "no source"
        for base in bases:
            if not base:
                continue
            try:
                data = _get("%s/%s/%s" % (base.rstrip("/"), channel, f["path"]), f["size"] + 1, timeout=120)
            except Refused as e:
                last = str(e)
                continue
            except (OSError, ValueError, urllib.error.URLError) as e:
                last = type(e).__name__
                continue
            if len(data) != f["size"] or hashlib.sha256(data).hexdigest() != f["sha256"]:
                last = "file %s does not match the signed list" % f["name"]
                continue
            got = data
            break
        if got is None:
            raise Refused(last)
        p = dest / f["name"]
        tmp = p.with_name(p.name + ".part")
        tmp.write_bytes(got)
        os.replace(tmp, p)
        out[f["name"]] = p
    return out


# --- status for the screens ------------------------------------------------------------------------------------------
def next_tonight(now: datetime | None = None) -> datetime:
    now = now or datetime.now().astimezone()
    t = now.replace(hour=TONIGHT_HOUR, minute=0, second=0, microsecond=0)
    return t if now < t else t + timedelta(days=1)


def status(home: Path | None = None) -> dict:
    h = home or home_dir()
    r = root_dir(h)
    s = load_state(h)
    cfg = load_config(h)
    cur = current_version(r)
    av = s.get("available")
    if av and vt(av.get("version", "")) <= vt(cur):
        av = None
    applying = s.get("applying")
    if applying and time.time() - applying.get("since", 0) > 30 * 60:
        applying = None                       # a run that never reported back
    tonight = s.get("tonight") if av else None
    d = s.get("deferred") or {}
    deferred = bool(av and d.get("version") == av.get("version") and time.time() < d.get("until", 0))
    # Home's notice: "offer" = the card; "tonight" = one quiet line; "none" = nothing (deferred, or nothing waiting).
    # Settings always shows a waiting update with its buttons, whatever this says.
    notice = "none" if not av or applying else ("tonight" if tonight else ("none" if deferred else "offer"))
    out = {"local": bool(r), "current": cur, "ring": cfg["ring"], "available": av,
           "last_check": s.get("last_check"), "last_check_status": s.get("last_check_status"),
           "tonight": tonight, "applying": bool(applying), "deferred": deferred,
           "deferred_until": d.get("until") if deferred else None, "notice": notice,
           "last_result": s.get("last_result")}
    return out


def schedule_tonight(home: Path | None = None) -> dict:
    h = home or home_dir()
    with _lock:
        s = load_state(h)
        av = s.get("available")
        if not av:
            raise Refused("no update waiting")
        at = next_tonight()
        s["tonight"] = {"version": av["version"], "at": int(at.timestamp()), "label": "%d AM" % TONIGHT_HOUR}
        s.pop("deferred", None)
        save_state(s, h)
    _log(root_dir(h), "scheduled %s for %s" % (av["version"], at.isoformat()))
    return status(h)


def cancel_tonight(home: Path | None = None) -> dict:
    """"Not tonight": the night's update is called off and the notice rests until the next day's check."""
    h = home or home_dir()
    with _lock:
        s = load_state(h)
        s.pop("tonight", None)
        save_state(s, h)
    return defer(h)


DEFER_S = CHECK_EVERY_S


def defer(home: Path | None = None, now: float | None = None) -> dict:
    """"Later" (or the notice's X): Home stops showing this version until the next day's check, in every page,
    tab and window (kept here, not in the page). Settings still shows it with its buttons."""
    h = home or home_dir()
    now = now or time.time()
    with _lock:
        s = load_state(h)
        av = s.get("available")
        if not av:
            raise Refused("no update waiting")
        s["deferred"] = {"version": av["version"], "at": int(now), "until": int(now + DEFER_S)}
        save_state(s, h)
    _log(root_dir(h), "later: %s until the next day's check" % av["version"])
    return status(h)


# --- starting the update (from the dashboard or the chat) ------------------------------------------------------------
def _env_python(root: Path) -> str:
    pat = "installs/*/environments/*/venv/" + ("Scripts/python.exe" if WIN else "bin/python")
    found = sorted((root / "home").glob(pat), key=lambda p: p.stat().st_mtime)
    return str(found[-1]) if found else sys.executable


def _dashboard_port() -> int | None:
    a = sys.argv
    for i, x in enumerate(a[:-1]):
        if x == "--port" and a[i + 1].isdigit():
            return int(a[i + 1])
    return None


def start_apply(port: int | None = None, home: Path | None = None, reason: str = "now") -> dict:
    """Starts the update in its own process (it stops and restarts this dashboard)."""
    h = home or home_dir()
    r = root_dir(h)
    if not r:
        raise Refused("updates are managed elsewhere on this computer")
    port = port or _dashboard_port() or load_state(h).get("port") or 9219
    s = load_state(h)
    if s.get("applying") and time.time() - s["applying"].get("since", 0) < 30 * 60:
        return status(h)
    (r / "run").mkdir(exist_ok=True)
    runner = r / "run" / "qosha-updater.py"
    shutil.copyfile(Path(__file__).resolve(), runner)       # runs from a copy: the update replaces this file
    cmd = [_env_python(r), "-I", str(runner), "apply", "--root", str(r), "--port", str(int(port)), "--why", reason]
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("PYTHON", "PIP_"))}
    env["HERMES_HOME"] = str(h)
    log = open(r / "logs" / "updates-run.log", "ab")
    kw = {}
    if WIN:
        kw["creationflags"] = 0x00000008 | 0x00000200 | 0x08000000     # detached, own group, no window
    else:
        kw["start_new_session"] = True
    try:
        p = subprocess.Popen(cmd, cwd=str(r), env=env, stdin=subprocess.DEVNULL,
                             stdout=log, stderr=subprocess.STDOUT, **kw)
    finally:
        log.close()
    with _lock:
        s = load_state(h)
        s["applying"] = {"since": int(time.time()), "pid": p.pid, "why": reason}
        s["port"] = int(port)
        save_state(s, h)
    _log(r, "update started (%s), process %d" % (reason, p.pid))
    return status(h)


# --- background: daily check and the night's update ------------------------------------------------------------------
_bg = {"started": False}


def tick(home: Path | None = None, now: float | None = None) -> str:
    """One pass of the background work. Returns what it did (for tests and the log)."""
    h = home or home_dir()
    if not root_dir(h):
        return "not_local"
    now = now or time.time()
    cfg = load_config(h)
    s = load_state(h)
    did = "nothing"
    every = RETRY_S if s.get("last_check_status") == "unreachable" else CHECK_EVERY_S
    if cfg["auto_check"] and now - (s.get("last_check") or 0) >= every:
        check(h, quiet=True)
        did = "checked"
        s = load_state(h)
    t = s.get("tonight")
    if t and s.get("available") and not s.get("applying"):
        if now >= t["at"] + TONIGHT_WINDOW_H * 3600:            # the computer was off or asleep in the window
            with _lock:
                s = load_state(h)
                nt = next_tonight()
                s["tonight"]["at"] = int(nt.timestamp())
                save_state(s, h)
            did = "tonight_moved"
        elif now >= t["at"]:
            start_apply(None, h, reason="tonight")
            did = "tonight_started"
    return did


def start_background(home: Path | None = None) -> bool:
    if _bg["started"]:
        return False
    _bg["started"] = True
    h = home or home_dir()

    def work():
        time.sleep(min(60, load_config(h)["tick_seconds"]))
        while True:
            try:
                tick(h)
            except Exception as exc:
                _log(root_dir(h), "background pass failed: %s" % type(exc).__name__)
            time.sleep(load_config(h)["tick_seconds"])
    threading.Thread(target=work, daemon=True, name="qosha-updates").start()
    return True


# --- the update itself (separate process) ----------------------------------------------------------------------------
def _http(port: int, path: str, token: str | None = None, timeout: float = 10.0):
    req = urllib.request.Request("http://127.0.0.1:%d%s" % (port, path),
                                 headers={"X-Hermes-Session-Token": token} if token else {})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(req, timeout=timeout) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, b""
    except Exception:
        return 0, b""


def _token(port: int) -> str | None:
    code, body = _http(port, "/")
    m = re.search(rb'__HERMES_SESSION_TOKEN__\s*=\s*"([^"]+)"', body or b"")
    return m.group(1).decode() if code == 200 and m else None


def _fingerprint(p: Path) -> str:
    """sha256 of a sign-in file, kept in memory only to prove the update did not change it."""
    try:
        return hashlib.sha256(p.read_bytes()).hexdigest()
    except FileNotFoundError:
        return "absent"
    except OSError:
        return "unreadable"


def snapshot(port: int, home: Path) -> dict:
    tok = _token(port)
    snap = {"token": bool(tok), "sessions": None, "accounts": None,
            "files": {n: _fingerprint(home / n) for n in ("auth.json", ".env", "google_token.json")}}
    if tok:
        c, b = _http(port, "/api/sessions?limit=50", tok)
        if c == 200:
            try:
                snap["sessions"] = sorted(x.get("id") for x in json.loads(b).get("sessions", []))
            except Exception:
                pass
        c, b = _http(port, "/api/plugins/qosha/signin/accounts", tok)
        if c == 200:
            try:
                snap["accounts"] = json.loads(b)
            except Exception:
                pass
    return snap


def health(port: int, home: Path, before: dict, expect_version: str | None, wait_s: int = 240) -> tuple:
    t0 = time.time()
    while time.time() - t0 < wait_s:
        if _http(port, "/api/status")[0] == 200:
            break
        time.sleep(1)
    else:
        return False, "Qosha did not start again"
    tok = None
    for _ in range(30):
        tok = _token(port)
        if tok:
            break
        time.sleep(1)
    if not tok:
        return False, "Qosha's screens did not load"
    code, body = _http(port, "/")
    if code != 200 or b"<title>Qosha</title>" not in body:
        return False, "Qosha's start page did not load"
    for page in ("/dashboard-plugins/qosha/index.html", "/dashboard-plugins/qosha/settings.html"):
        c, b = _http(port, page)
        if c != 200 or b"Qosha" not in b:
            return False, "a Qosha page did not load (%s)" % page.rsplit("/", 1)[-1]
    if expect_version:
        c, b = _http(port, "/api/plugins/qosha/updates/status", tok)
        try:
            v = json.loads(b).get("current") if c == 200 else None
        except Exception:
            v = None
        if v != expect_version:
            return False, "the new version did not start (it reports %s)" % (v or "nothing")
    after = snapshot(port, home)
    if before.get("sessions") is not None:
        if after.get("sessions") is None:
            return False, "the conversation list did not read"
        if not set(before["sessions"]) <= set(after["sessions"]):
            return False, "the conversation list changed"
    if before.get("accounts") is not None:
        # the same answers for every account the previous version reported (a newer version may report more)
        b, n = before["accounts"], after.get("accounts")
        if not isinstance(n, dict) or any(k in n and n[k] != v for k, v in b.items()) or not set(b) <= set(n):
            return False, "the AI accounts state changed"
    if after["files"] != before["files"]:
        return False, "a sign-in file changed"
    return True, "ok"


def _ps_rows() -> list:
    """(pid, ppid, command line) of every process of this person."""
    rows = []
    if WIN:
        ps = ("Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine | "
              "ConvertTo-Json -Compress")
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True,
                           text=True, creationflags=0x08000000)
        try:
            data = json.loads(r.stdout or "[]")
        except ValueError:
            data = []
        for d in data if isinstance(data, list) else [data]:
            rows.append((int(d.get("ProcessId") or 0), int(d.get("ParentProcessId") or 0),
                         "%s %s" % (d.get("ExecutablePath") or "", d.get("CommandLine") or "")))
    else:
        r = subprocess.run(["ps", "-axo", "pid=,ppid=,command="], capture_output=True, text=True)
        for line in r.stdout.splitlines():
            parts = line.strip().split(None, 2)
            if len(parts) == 3 and parts[0].isdigit() and parts[1].isdigit():
                rows.append((int(parts[0]), int(parts[1]), parts[2]))
    return rows


def _norm(s: str) -> str:
    return s.replace("\\", "/").lower() if WIN else s


def stop_qosha(root: Path, port: int) -> dict:
    """Stops this install's launcher and dashboard and their children; only processes proven to belong to this
    install (pid file or child of one, AND its command line names this install's folder), never this process.
    Returns how the launcher was running, to start it again the same way."""
    me = os.getpid()
    rows = _ps_rows()
    by_pid = {p: (pp, c) for p, pp, c in rows}
    rootn = _norm(str(root))
    seeds = []
    launcher_cmd = None
    for name in ("launcher.pid", "dashboard.pid"):
        try:
            pid = int((root / "run" / name).read_text().strip())
        except (OSError, ValueError):
            continue
        if pid in by_pid and rootn in _norm(by_pid[pid][1]):
            seeds.append(pid)
            if name == "launcher.pid" and "launcher.py" in by_pid[pid][1]:
                launcher_cmd = by_pid[pid][1]
    kids = {}
    for p, pp, c in rows:
        kids.setdefault(pp, []).append(p)
    todo, seen = list(seeds), set()
    while todo:
        p = todo.pop()
        if p in seen:
            continue
        seen.add(p)
        todo.extend(kids.get(p, []))
    # never this process nor its own parents: on Windows an environment's python.exe is a small launcher that runs
    # the real Python as its child and takes it down with it (found on the test PC, 17 Nov)
    mine, p = set(), me
    while p and p not in mine and p in by_pid and p not in seeds:     # up to the dashboard that started it
        mine.add(p)
        p = by_pid[p][0]
    mine.add(me)
    victims = [p for p in seen if p not in mine and p in by_pid and rootn in _norm(by_pid[p][1])]
    # parents first, so the launcher cannot start a new dashboard in between
    order = [p for p in seeds if p in victims] + [p for p in victims if p not in seeds]
    for p in order:
        try:
            if WIN:
                subprocess.run(["taskkill", "/PID", str(p), "/F"], capture_output=True, creationflags=0x08000000)
            else:
                os.kill(p, 15)
        except Exception:
            pass
    t0 = time.time()
    while time.time() - t0 < 30:
        alive = {p for p, _, _ in _ps_rows()} & set(order)
        if not alive and _http(port, "/api/status", timeout=2)[0] == 0:
            break
        time.sleep(1)
    else:
        if not WIN:
            for p in order:
                try:
                    os.kill(p, 9)
                except Exception:
                    pass
            time.sleep(2)
    _log(root, "stopped %d Qosha processes" % len(order))
    return {"launcher_cmd": launcher_cmd}


def _launch_agent_label(root: Path):
    if WIN:
        return None
    import plistlib
    d = Path.home() / "Library" / "LaunchAgents"
    for p in sorted(d.glob("*.plist")) if d.is_dir() else []:
        try:
            with open(p, "rb") as f:
                pl = plistlib.load(f)
        except Exception:
            continue
        args = pl.get("ProgramArguments") or []
        if pl.get("WorkingDirectory") == str(root) and any(str(a).endswith("launcher.py") for a in args):
            return pl.get("Label"), p
    return None


def start_qosha(root: Path, port: int, how: dict) -> str:
    la = _launch_agent_label(root)
    if la:
        label, plist = la
        uid = os.getuid()
        r = subprocess.run(["launchctl", "kickstart", "gui/%d/%s" % (uid, label)], capture_output=True)
        if r.returncode != 0:
            subprocess.run(["launchctl", "bootstrap", "gui/%d" % uid, str(plist)], capture_output=True)
        return "launchagent %s" % label
    py = None
    tools = sorted((root / "home" / "tools").glob("python-*"))
    if tools:
        py = tools[-1] / ("pythonw.exe" if WIN else "bin/python3")
    if not py or not py.exists():
        py = Path(sys.executable)
    args = [str(py), "-I", str(root / "layer" / "launcher.py"), "--root", str(root), "--port", str(port)]
    cmd = how.get("launcher_cmd") or ""
    m = re.search(r"--apps\s+(\S+)", cmd)
    if m and not WIN:
        args += ["--apps", m.group(1)]
    if WIN:
        flags = 0x00000008 | 0x00000200 | 0x01000000             # detached, own group, out of this job
        try:
            subprocess.Popen(args, cwd=str(root), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, creationflags=flags)
        except OSError:
            subprocess.Popen(args, cwd=str(root), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, creationflags=0x00000008 | 0x00000200)
    else:
        subprocess.Popen(args, cwd=str(root), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    return "launcher"


def _copytree(src: Path, dst: Path) -> None:
    shutil.copytree(src, dst, symlinks=True, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))


def backup(root: Path, home: Path, cur: str) -> Path:
    b = root / "updates" / "backups" / ("%s-from-%s" % (time.strftime("%Y%m%d-%H%M%S"), cur))
    b.mkdir(parents=True)
    _copytree(root / "layer", b / "layer")
    if (home / "plugins" / "qosha").is_dir():
        _copytree(home / "plugins" / "qosha", b / "plugin")
    for n in ("config.yaml", "SOUL.md"):
        if (home / n).is_file():
            shutil.copy2(home / n, b / n)
    (b / "DONE").write_text(cur)
    # keep the three newest backups
    olds = sorted(p for p in (root / "updates" / "backups").iterdir() if p.is_dir())
    for p in olds[:-3]:
        shutil.rmtree(p, ignore_errors=True)
    return b


def run_setup_home(root: Path, home: Path) -> tuple:
    py = _env_python(root)
    lay = root / "layer"
    eng = root / "engine"
    out = []
    for cmd in ([py, "-I", str(lay / "engine_exec.py"), "--root", str(root), "--save"],
                [py, "-I", str(lay / "engine_exec.py"), "--root", str(root), "--script", str(lay / "setup_home.py"),
                 "--engine", str(eng), "--src", str(eng), "--home", str(home)]):
        r = subprocess.run(cmd, capture_output=True, text=True, cwd=str(root), creationflags=0x08000000 if WIN else 0)
        out.append((r.stdout or "")[-4000:] + (r.stderr or "")[-2000:])
        if r.returncode != 0:
            return False, "\n".join(out)
    ok = "SETUP HOME DONE" in out[-1]
    return ok, "\n".join(out)


def install_layer(root: Path, zip_path: Path) -> None:
    new = root / "layer.new"
    if new.exists():
        shutil.rmtree(new)
    new.mkdir()
    with zipfile.ZipFile(zip_path) as z:
        for n in z.namelist():
            if n.startswith("/") or ".." in Path(n).parts or ":" in n:
                raise Refused("package holds a path outside its folder")
        z.extractall(new)
    if not (new / "setup_home.py").is_file() or not (new / "RELEASE.json").is_file():
        raise Refused("package is not a Qosha layer")
    old = root / "layer.old"
    if old.exists():
        shutil.rmtree(old)
    os.replace(root / "layer", old)
    os.replace(new, root / "layer")
    shutil.rmtree(old, ignore_errors=True)


def restore(root: Path, home: Path, b: Path) -> None:
    lay = root / "layer"
    if lay.exists():
        bad = root / "layer.failed"
        if bad.exists():
            shutil.rmtree(bad, ignore_errors=True)
        os.replace(lay, bad)
        shutil.rmtree(bad, ignore_errors=True)
    _copytree(b / "layer", lay)
    for n in ("config.yaml", "SOUL.md"):
        if (b / n).is_file():
            shutil.copy2(b / n, home / n)


# --- customisations --------------------------------------------------------------------------------------------------
CUSTOM_README = """Your own changes to Qosha's own files live here, so updates never undo them.

custom/plugin/ mirrors Qosha's program folder (plugins/qosha). Put a changed or added file at the same path it has
there, for example custom/plugin/dashboard/pages/chat.html. After every update Qosha copies this folder over its new
files, so your version wins. Delete a file here to get Qosha's own version back at the next update.
Your settings, chats, memories, skills, sign-ins and files are never replaced by an update and do not need to be here.
"""


def custom_dir(home: Path) -> Path:
    d = home / "qosha" / "custom"
    (d / "plugin").mkdir(parents=True, exist_ok=True)
    if not (d / "README.txt").exists():
        (d / "README.txt").write_text(CUSTOM_README, encoding="utf-8")
    return d


def apply_customizations(home: Path) -> list:
    """Copies <home>/qosha/custom/plugin/** over <home>/plugins/qosha/. Regular files only, never outside it."""
    src = custom_dir(home) / "plugin"
    dst = (home / "plugins" / "qosha").resolve()
    done = []
    if not dst.is_dir():
        return done
    for f in sorted(src.rglob("*")):
        if f.is_symlink() or not f.is_file() or "__pycache__" in f.parts:
            continue
        rel = f.relative_to(src)
        t = (dst / rel).resolve()
        if dst not in t.parents:
            continue
        t.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(f, t)
        done.append(rel.as_posix())
    return done


# --- the engine's own self-update: off -------------------------------------------------------------------------------
QOSHA_UPDATE_TEXT = "Qosha keeps itself up to date: see Settings > Version and updates, or ask Qosha to check for updates."
_GATE = "# qosha-update-gate"


def patch_engine_update_gate(engine: Path) -> list:
    """Source patches in the engine (like setup_home.py's): its own update command, the chat's /update and the
    dashboard's Update button all refuse with Qosha's line. Idempotent; returns what was patched."""
    done = []
    spots = [
        ("hermes_cli/update_contract.py",
         '    ``None`` means the install is eligible for in-place update (git checkout or unknown-but-\n'
         '    mutable). Never raises; on any internal error it falls back to the heuristic layer only.\n    """\n',
         '    return UpdateRefusal("qosha-managed", %r, "")  %s\n' % (QOSHA_UPDATE_TEXT, _GATE)),
        ("gateway/slash_commands.py",
         '        restart it may trigger; marker files let this or the next gateway process notify the user."""\n',
         '        return %r  %s\n' % (QOSHA_UPDATE_TEXT, _GATE)),
        ("hermes_cli/web_server_files.py",
         ' pip stays blocked in containers: its\n    apply path mutates the running container filesystem.\n    """\n',
         '    return True  %s\n' % _GATE),
    ]
    for rel, anchor, line in spots:
        p = engine / rel
        try:
            t = p.read_text(encoding="utf-8")
        except OSError:
            continue
        if _GATE in t or anchor not in t:
            if _GATE in t:
                done.append(rel)
            continue
        p.write_text(t.replace(anchor, anchor + line, 1), encoding="utf-8")
        done.append(rel)
    a = engine / "hermes_cli" / "web_routers" / "actions.py"
    try:
        t = a.read_text(encoding="utf-8")
        old = '_MANAGED_EXTERNALLY_MESSAGE = "Hermes updates are managed outside this dashboard in containerized environments."'
        if old in t:
            a.write_text(t.replace(old, "_MANAGED_EXTERNALLY_MESSAGE = %r" % QOSHA_UPDATE_TEXT, 1), encoding="utf-8")
        if "_MANAGED_EXTERNALLY_MESSAGE = %r" % QOSHA_UPDATE_TEXT in a.read_text(encoding="utf-8"):
            done.append("hermes_cli/web_routers/actions.py")
    except OSError:
        pass
    return done


def lock_engine_updates() -> bool:
    """In the running dashboard: the Update button stays hidden (can_update_hermes false) and the engine's update
    routes answer with Qosha's line, also on an install whose engine was not patched yet."""
    try:
        import hermes_cli.web_server_files as wsf
        wsf._dashboard_local_update_managed_externally = lambda: True
    except Exception:
        pass
    ws = sys.modules.get("hermes_cli.web_server")
    app = getattr(ws, "app", None)
    if app is None:
        return False
    try:
        from fastapi.responses import JSONResponse
        from fastapi.routing import APIRoute
    except Exception:
        return False
    if any(getattr(r, "name", "") == "qosha_engine_update_check" for r in app.router.routes):
        return True

    async def qosha_engine_update_check():
        return {"install_method": "qosha", "current_version": "", "behind": None, "update_available": False,
                "can_apply": False, "update_command": "", "message": QOSHA_UPDATE_TEXT}

    async def qosha_engine_update_apply():
        return JSONResponse(status_code=409, content={"ok": False, "error": "managed_by_qosha", "message": QOSHA_UPDATE_TEXT})

    app.router.routes.insert(0, APIRoute("/api/hermes/update/check", qosha_engine_update_check, methods=["GET"],
                                         name="qosha_engine_update_check"))
    app.router.routes.insert(0, APIRoute("/api/hermes/update", qosha_engine_update_apply, methods=["POST"],
                                         name="qosha_engine_update_apply"))
    return True


# --- apply (the separate process) ------------------------------------------------------------------------------------
def _result(home: Path, ok: bool, version: str, message: str, **kw) -> None:
    with _lock:
        s = load_state(home)
        s.pop("applying", None)
        if ok:
            s.pop("available", None)
            s.pop("tonight", None)
            s.pop("deferred", None)
        s["last_result"] = dict({"ok": ok, "version": version, "message": message, "at": int(time.time())}, **kw)
        if not ok and kw.get("tried"):          # a version that failed and was rolled back is not offered again
            s["failed_versions"] = sorted(set((s.get("failed_versions") or []) + [kw["tried"]]))
            if (s.get("available") or {}).get("version") == kw["tried"]:
                s.pop("available", None)
                s.pop("tonight", None)
        hist = s.get("history") or []
        hist.append(s["last_result"])
        s["history"] = hist[-20:]
        save_state(s, home)


def apply(root: Path, port: int, why: str = "now") -> int:
    home = root / "home"
    os.environ["HERMES_HOME"] = str(home)
    lockf = root / "run" / "update.lock"
    try:
        fd = os.open(str(lockf), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
    except FileExistsError:
        if time.time() - lockf.stat().st_mtime < 3600:
            _log(root, "another update is running")
            return 3
        lockf.unlink()
        return apply(root, port, why)
    cur = current_version(root)
    try:
        return _apply_locked(root, home, port, cur, why)
    except Exception as exc:          # anything unexpected before the swap: nothing was changed
        _log(root, "update stopped before changing anything: %s" % exc)
        _result(home, False, cur, "Qosha could not update just now; nothing changed. It will try again later.",
                stage="prepare", detail=str(exc)[:200])
        return 2
    finally:
        try:
            lockf.unlink()
        except OSError:
            pass


def _apply_locked(root: Path, home: Path, port: int, cur: str, why: str) -> int:
    cfg = load_config(home)
    found = find_update(home, root)
    rel = found.get("release")
    if not rel:
        _log(root, "nothing to apply (%s)" % found["status"])
        _result(home, False, cur, {"paused": "Updates are paused for now; nothing changed.",
                                   "up_to_date": "Qosha is already up to date."}.get(
                    found["status"], "No update is available for this computer right now; nothing changed."),
                stage="check", detail=found["status"])
        return 1
    new = rel["version"]
    bases = [found["base"]] + [cfg[n] for n in ("primary", "fallback") if cfg[n] and cfg[n] != found["base"]]
    files = download(rel, bases, root / "updates" / "downloads" / new, cfg["channel"])
    _log(root, "downloaded and checked %s (%s)" % (new, ", ".join(sorted(files))))
    before = snapshot(port, home)
    b = backup(root, home, cur)
    _log(root, "backup at %s" % b)
    how = stop_qosha(root, port)
    stage = "install"
    try:
        install_layer(root, files["qosha-layer.zip"])
        ok, out = run_setup_home(root, home)
        _log(root, "setup_home: %s" % ("ok" if ok else "FAILED"))
        if not ok:
            (root / "logs" / ("update-setup-%s.log" % new)).write_text(out, encoding="utf-8")
            raise RuntimeError("Qosha's set-up step did not finish")
        gate = patch_engine_update_gate(root / "engine")
        custom = apply_customizations(home)
        _log(root, "engine update gate: %s; customisations kept: %d" % (", ".join(gate) or "none", len(custom)))
        stage = "start"
        started = start_qosha(root, port, how)
        _log(root, "started (%s)" % started)
        stage = "health"
        ok, why_h = health(port, home, before, new)
        if not ok:
            raise RuntimeError(why_h)
    except Exception as exc:
        _log(root, "update to %s failed at %s: %s; rolling back to %s" % (new, stage, exc, cur))
        ok2 = False
        try:
            stop_qosha(root, port)
            restore(root, home, b)
            ok_s, out = run_setup_home(root, home)
            patch_engine_update_gate(root / "engine")
            apply_customizations(home)
            start_qosha(root, port, how)
            ok2, why2 = health(port, home, before, None)
            _log(root, "rollback: %s (%s)" % ("ok" if ok2 else "FAILED", why2 if not ok2 else "set-up %s" % ("ok" if ok_s else "had errors")))
        except Exception as exc2:
            _log(root, "rollback failed: %s" % exc2)
        if ok2:
            _result(home, False, cur, "The update to %s did not work, so Qosha went back to the version you had. "
                                      "Nothing of yours changed." % new, stage=stage, detail=str(exc)[:200], tried=new)
            return 4
        _result(home, False, cur, "Qosha could not finish an update and could not go back by itself. Your chats and "
                                  "settings are safe; a copy of the previous version is in %s." % b, stage=stage,
                detail=str(exc)[:200], tried=new, needs_help=True)
        return 5
    _result(home, True, new, "Qosha was updated to %s." % new, notes=rel.get("notes", ""), why=why)
    _log(root, "updated %s -> %s (%s)" % (cur, new, why))
    return 0


# --- the dashboard's routes (mounted by plugin_api.py under /api/plugins/qosha/updates) -----------------------------
try:
    from fastapi import APIRouter, Body, Request
    from fastapi.responses import JSONResponse as _JR

    router = APIRouter()

    def _ok(d, code=200):
        return _JR(status_code=code, content=d, headers={"Cache-Control": "no-store"})

    @router.get("/status")
    def _r_status(request: Request):
        h = home_dir()
        if request.url.port:
            with _lock:
                s = load_state(h)
                if s.get("port") != request.url.port:
                    s["port"] = request.url.port
                    save_state(s, h)
        return _ok(status(h))

    @router.post("/check")
    def _r_check():
        if not root_dir():
            return _ok({"error": "not_local"}, 404)
        return _ok(check())

    @router.post("/apply")
    def _r_apply(request: Request, body: dict = Body(default={})):
        when = (body or {}).get("when", "now")
        try:
            if when == "tonight":
                return _ok(schedule_tonight())
            if when == "cancel_tonight":
                return _ok(cancel_tonight())
            if when == "later":
                return _ok(defer())
            if when != "now":
                return _ok({"error": "bad_request"}, 400)
            if not status().get("available"):
                return _ok({"error": "no_update"}, 409)
            return _ok(start_apply(request.url.port))
        except Refused as e:
            return _ok({"error": str(e)}, 409)
except Exception:          # imported outside the dashboard (the chat, the update process)
    router = None


def mount(parent_router) -> None:
    """Called once by the dashboard: the routes, the engine's update switch-off, the daily check."""
    if router is not None:
        parent_router.include_router(router, prefix="/updates")
    lock_engine_updates()
    if root_dir():
        custom_dir(home_dir())
        start_background()


# --- the chat: a tool Qosha uses when the person asks ----------------------------------------------------------------
def _tool(args, **_kw) -> str:
    a = args if isinstance(args, dict) else {}
    act = str(a.get("action") or "check").lower()
    try:
        if not root_dir():
            return json.dumps({"success": False, "error": "This Qosha is updated by Qosha's team, not from here."})
        if act == "check":
            st = check()
        elif act == "update_now":
            st = status()
            if not st.get("available"):
                st = check()
            if not st.get("available"):
                return json.dumps({"success": True, "result": "Qosha is up to date (version %s)." % st["current"]})
            st = start_apply()
            return json.dumps({"success": True, "result": "Updating Qosha to %s now. Qosha restarts in about a minute; "
                               "this chat comes back by itself." % st["available"]["version"]})
        elif act == "tonight":
            st = status()
            if not st.get("available"):
                st = check()
            if not st.get("available"):
                return json.dumps({"success": True, "result": "Qosha is up to date (version %s)." % st["current"]})
            st = schedule_tonight()
            return json.dumps({"success": True, "result": "Qosha will update to %s tonight at 2 AM if this computer "
                               "is on." % st["available"]["version"]})
        else:
            st = status()
        if st.get("available"):
            txt = "Update available: Qosha %s (you have %s). What changed: %s Ask me to update now or tonight." % (
                st["available"]["version"], st["current"], st["available"].get("notes") or "improvements.")
        else:
            txt = "Qosha is up to date (version %s)." % st["current"]
            if st.get("last_check_status") == "unreachable":
                txt = "Qosha could not reach its update source just now (version %s); it tries again later." % st["current"]
        return json.dumps({"success": True, "result": txt})
    except Refused as e:
        return json.dumps({"success": False, "error": str(e)})


TOOL_SCHEMA = {
    "name": "qosha_updates",
    "description": ("Qosha's own updates (this app). action=check: see whether a new tested Qosha version is "
                    "available and what changed; update_now: install it now (Qosha restarts for about a minute; "
                    "use only when the person asked); tonight: install it at 2 AM tonight. The person's chats, "
                    "memories, settings and sign-ins are kept; a failed update goes back by itself."),
    "parameters": {"type": "object", "properties": {
        "action": {"type": "string", "enum": ["check", "update_now", "tonight", "status"]}}, "required": ["action"]},
}


def register(ctx) -> None:
    """From the plugin's register(): the chat tool, and the engine's own /update switched off in this process."""
    ctx.register_tool(name="qosha_updates", toolset="terminal", schema=TOOL_SCHEMA, handler=_tool,
                      check_fn=lambda: bool(root_dir()), description=TOOL_SCHEMA["description"], emoji="⬆️")
    try:
        import gateway.slash_commands as sc

        async def _qosha_update_command(self, event):
            return QOSHA_UPDATE_TEXT
        for obj in vars(sc).values():
            if isinstance(obj, type) and "_handle_update_command" in vars(obj):
                obj._handle_update_command = _qosha_update_command
    except Exception:
        pass


# --- command line ----------------------------------------------------------------------------------------------------
def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="Qosha's updater")
    ap.add_argument("action", choices=["apply", "check", "status", "tick", "gate", "customize", "ring"])
    ap.add_argument("value", nargs="?", help="for ring: one of " + ", ".join(RINGS))
    ap.add_argument("--root")
    ap.add_argument("--port", type=int, default=9219)
    ap.add_argument("--why", default="now")
    a = ap.parse_args(argv)
    root = Path(a.root).resolve() if a.root else root_dir()
    if not root:
        print("not a per-user Qosha install")
        return 2
    os.environ["HERMES_HOME"] = str(root / "home")
    if a.action == "apply":
        return apply(root, a.port, a.why)
    if a.action == "check":
        print(json.dumps(check(root / "home"), indent=1))
    elif a.action == "status":
        print(json.dumps(status(root / "home"), indent=1))
    elif a.action == "tick":
        print(tick(root / "home"))
    elif a.action == "gate":
        print(json.dumps(patch_engine_update_gate(root / "engine")))
    elif a.action == "ring":
        if a.value not in RINGS:
            print("ring must be one of: " + ", ".join(RINGS))
            return 2
        print(json.dumps(set_config({"ring": a.value}, root / "home")))
    elif a.action == "customize":
        print(json.dumps(apply_customizations(root / "home")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
