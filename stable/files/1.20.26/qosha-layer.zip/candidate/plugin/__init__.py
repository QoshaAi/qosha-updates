"""Qosha agent plugin: registers the approval guard on every tool call (INTERFACES.md §4.1), and the file viewer's
version observers (night job 4: they only read the file a write_file / patch is about to change or just changed),
Qosha's own identity in place of the engine's (qosha_guard/identity.py), and Claude seat-first with the API key as
fallback (qosha_guard/seatfirst.py), and Qosha's browser tools on Qosha's own Chrome (qosha_guard/browser_tools.py), and the council (qosha_council/),
and Gemini as a full chat model through Qosha's relay (qosha_guard/gemini_chat.py, CONTRACT G1)."""
from .qosha_guard.hook import pre_tool_call
from .qosha_guard import browser_tools, identity, seatfirst, versions


def _local() -> bool:
    """The person's own computer (no Qosha connector, not a cloud box): the engine's own behavior, plus ask-first."""
    import os
    return not os.environ.get("QOSHA_CONNECTOR_URL") and not os.environ.get("QOSHA_BOX") and not os.environ.get("QOSHA_LAB")


def _access_failed(ctx) -> None:
    """The access check could not be set up: nothing answers and no tool runs (fail closed)."""
    text = "Qosha can't check your access right now, so it can't answer. Restart Qosha; if this stays, ask Qosha's team."
    ctx.register_hook("pre_llm_call", lambda **_kw: {"action": "block", "message": text})
    ctx.register_hook("pre_tool_call", lambda *_a, **_kw: {"action": "block", "message": text})


def register(ctx) -> None:
    # CONTRACT-ACCESS (Ren, 20 Nov 2026: "I just want them to loose access immediately"): registered FIRST and before
    # any environment test (review r2: a process flag must not skip it); access.py decides itself whether this is the
    # person's own computer (a per-user install always is) and does nothing on a cloud box or the lab.
    try:
        from .qosha_guard import access
        access.register(ctx)
    except Exception:
        _access_failed(ctx)
    # 1.20.4: Qosha's wording for the engine's own English (the same files setup_home puts in the home's locales
    # folder) as a language pack, so every profile that runs this plugin says Qosha too (review r2 #7, #12)
    try:
        from pathlib import Path as _P
        ctx.register_locale_dir(_P(__file__).resolve().parent / "locales")
    except Exception:
        pass
    # closed until proven open in the gateway (reviews FO-4, FO2-2, FO2-11): on a computer with the Qosha app, no approval
    # tickets until the gate's own ticket check is in place on the live ticket method (checked after registration below)
    _gfs = None
    try:
        from .qosha_guard import gate_failsafe as _gfs
        if _gfs.local_install():
            _gfs.refuse_gateway_tickets("starting")
        else:
            _gfs = None
    except Exception:
        import logging
        logging.getLogger("qosha").error("Qosha approval gate: the gateway fail-safe could not be set up")
        _gfs = None
    if _local():
        # Ren, 17 Nov: no walls; only sends, payments, deletions, sharing and calendar changes are asked first through
        # the engine's own prompt (Allow once / Always allow). Qosha's extras that stock lacks stay.
        try:
            from .qosha_guard import approval_gate
            approval_gate.register(ctx)   # Ren, 21 Nov ~21:55: only the Qosha window can answer a card (no gateway tickets)
        except Exception as exc:
            import logging
            logging.getLogger("qosha").error("Qosha approval gate not set up (approval tickets stay refused): %s",
                                             type(exc).__name__)
        if _gfs is not None:
            try:
                from gateway.control_socket import GatewayControlServer as _G
                if getattr(getattr(_G, "_session_ticket", None), "qosha_owner_gate", False):
                    _gfs.release_gateway()
                else:
                    import logging
                    logging.getLogger("qosha").error("Qosha approval gate: its ticket check isn't in place; tickets stay refused")
            except Exception:
                pass   # no gateway code in this process: nothing to release
        try:
            from .qosha_guard import claude_limit
            claude_limit.register(ctx)   # Ren, 21 Nov: a Claude subscription limit never falls back to the pay-per-use API key
        except Exception as exc:
            import logging
            logging.getLogger("qosha").warning("Qosha Claude limit rule not set up: %s", type(exc).__name__)
        from .qosha_guard import ask
        # the startup barrier (startup_barrier.py, installed beside the engine) blocks every tool until this hook is
        # registered and has confirmed itself: a send must come back as an ask
        if (ask.pre_tool_call("send_message", {"target": "x", "message": "self-check"}) or {}).get("action") == "approve":
            ask.pre_tool_call.__qosha_guard_ready__ = True
        ctx.register_hook("pre_tool_call", ask.pre_tool_call)
        for _hook in ("pre_approval_request", "post_approval_response", "post_tool_call", "transform_tool_result"):   # Home shows what waits in a chat; one card per step
            try:
                ctx.register_hook(_hook, getattr(ask, _hook))
            except Exception:
                pass
        try:
            from .qosha_guard import updater as _updater
            _updater.register(ctx)   # "check for updates" in the chat; the engine's own /update answers with Qosha's line
        except Exception as exc:
            import logging
            logging.getLogger("qosha").warning("Qosha updates not set up in the chat: %s", type(exc).__name__)
        # 1.20.19 (contract IMAGEGEN-S4): Qosha's picture maker (the person's connected ChatGPT, else Gemini; making
        # pictures, and since slice 2 changing existing ones), on the person's own computer only and BEFORE identity.apply(), which tells the chat about it
        # only when it registered. Fail-open: an error here leaves everything else working and the texts as before.
        # The chat is told about it only when image_generate actually routes to Qosha's picture maker (Qosha's default,
        # or "qosha" chosen by hand): a picture maker the person chose themselves (e.g. image_gen.provider: openai) stays
        # theirs, and the texts then stay as in 1.20.15 (no promise of their ChatGPT/Gemini plan) (S4 review r1 #1).
        _pictures = False
        try:
            from .qosha_guard import imagegen
            _pictures = imagegen.register(ctx) is True
            if _pictures:
                _pictures = bool(imagegen._selected_qosha() or imagegen.default_in_effect())
        except Exception as exc:
            import logging
            logging.getLogger("qosha").warning("Qosha pictures not set up: %s", type(exc).__name__)
            _pictures = False
        for extra in ("google", "council", "identity"):
            try:
                if extra == "google":
                    from .qosha_guard import google_connect, google_write
                    google_connect.register(ctx)   # one-step Google sign-in (no copy-paste)
                    google_write.register(ctx)     # Google changes only here, with a grant held in memory (1.20.9)
                elif extra == "council":
                    from .qosha_council import load as _council_load
                    _council_load().register(ctx)
                else:
                    identity.apply(pictures=_pictures)
            except Exception as exc:
                import logging
                logging.getLogger("qosha").warning("Qosha %s not set up: %s", extra, type(exc).__name__)
        try:
            from .qosha_guard import handoff
            handoff.register(ctx)   # automatic model hand-off for pictures (roadmap item 9)
        except Exception as exc:
            import logging
            logging.getLogger("qosha").warning("Qosha hand-off not set up: %s", type(exc).__name__)
        try:
            from .qosha_guard import waiting
            waiting.register(ctx)   # Qosha never waits on the person in silence: sign-ins in its browser (17 Nov)
        except Exception as exc:
            import logging
            logging.getLogger("qosha").warning("Qosha sign-in wait not set up: %s", type(exc).__name__)
        try:
            from .qosha_guard import inbox_watch
            inbox_watch.register(ctx)   # the inbox watch job can call no tool; its answer becomes notifications (21 Nov)
        except Exception as exc:
            import logging
            logging.getLogger("qosha").warning("Qosha inbox watch not set up: %s", type(exc).__name__)
        try:
            from .qosha_guard import research_search
            research_search.register(ctx)   # web search on the person's ChatGPT plan, else free search (22 Nov)
        except Exception as exc:
            import logging
            logging.getLogger("qosha").warning("Qosha search not set up: %s", type(exc).__name__)
        return
    ctx.register_hook("pre_tool_call", pre_tool_call)
    # GUARDFIX message 1: the startup barrier (qosha_guard/startup_barrier.py) lets tools run only once this guard is
    # registered AND has confirmed itself: a direct send must come back refused
    from .qosha_guard import policy as _policy
    if _policy.classify("send_message", {"action": "send", "target": "x", "message": "self-check"}).action == _policy.DENY:
        pre_tool_call.__qosha_guard_ready__ = True
    # GUARDFIX2: on the Mac lab the assistant's terminal and code start inside its own OS sandbox (confine.py); if
    # this fails the guard refuses those tools there
    try:
        from .qosha_guard import confine
        confine.apply()
    except Exception as exc:
        import logging
        logging.getLogger("qosha.confine").error("Qosha's sandbox for the assistant was not set up: %s", type(exc).__name__)
    ctx.register_hook("pre_tool_call", versions.pre_tool_call)
    ctx.register_hook("post_tool_call", versions.post_tool_call)
    ctx.register_hook("pre_llm_call", seatfirst.pre_llm_call)
    ctx.register_hook("post_llm_call", browser_tools.post_llm_call)   # Qosha's tab closes when the turn ends
    try:
        browser_tools.register(ctx)   # Qosha's own Chrome through the connector (BROWSERCHROME), when switched on
    except Exception as exc:
        # fail-safe: the guard still refuses the engine's page-code tools (browser_tools.classify)
        import logging
        logging.getLogger("qosha.browser").warning("Qosha's browser tools were not registered: %s", type(exc).__name__)
    try:
        from .qosha_guard import selftools
        selftools.register(ctx)       # CAPFIX: Qosha's own screens (read-only) and settings (an Approve card)
    except Exception as exc:
        import logging
        logging.getLogger("qosha.selftools").warning("Qosha's self tools were not registered: %s", type(exc).__name__)
    try:
        from .qosha_council import load as _council_load
        _council_load().register(ctx)  # P0 council: "All", plain words and the qosha_council tool (qosha_council/)
    except Exception as exc:
        import logging
        logging.getLogger("qosha.council").warning("Qosha's council was not registered: %s", type(exc).__name__)
    try:
        identity.apply()
    except Exception:
        pass   # fail-open: the guard above is what must always be registered
    try:
        seatfirst.apply()
    except Exception:
        pass   # fail-open: without it the engine still answers, it just fails over late
    try:
        # CONTRACT G1: Gemini as a full chat model through Qosha's relay (qosha_guard/gemini_chat.py). Only in a box
        # that names the relay; elsewhere it touches nothing.
        from .qosha_guard import gemini_chat
        ctx.register_hook("pre_llm_call", gemini_chat.pre_llm_call)
        gemini_chat.apply()
    except Exception as exc:
        # fail-safe: the screens offer Gemini as a chat model only when gemini_chat.ready() says yes
        import logging
        logging.getLogger("qosha.gemini_chat").warning("Gemini chat was not set up: %s", type(exc).__name__)
