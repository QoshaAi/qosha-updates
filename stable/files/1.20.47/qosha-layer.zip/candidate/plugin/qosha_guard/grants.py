"""The per-kind grant record: which "Always allow for this kind" answers a person gave in Qosha's approval window.

Ren, 23 Nov 2026 (cards): "Keep Always allow (Recommended)"; H5 (builder's pick, accepted): at a protected step a
RECORDED standing grant (Always allow for that kind, or Trust mode ON set through the trusted route) counts as the
person's approval; otherwise a fresh click in the window is needed.

The engine keeps its own "always" list (config command_allowlist / approve_permanent). With the trusted surface on, a
saved "always" for one of Qosha's rule keys counts only when this record has it too: an entry added to the engine's
list any other way (an edited settings file, an old page's answer) asks again. Written only by engine_cards.py's window
worker; bound to this install (an imported home's record reads empty). File: <main home>/qosha/standing-grants.json.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import threading
import time
from typing import Iterable

FILE = "standing-grants.json"
SURFACES = ("trusted-dialog",)
_lock = threading.Lock()


def _home() -> str:
    try:
        from hermes_constants import get_hermes_home
        return str(get_hermes_home())
    except Exception:
        return os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")


def _anchor(home) -> str:
    """A profile's home shares its install's record (as trust.py and access.anchor do)."""
    h = os.path.abspath(str(home))
    up = os.path.dirname(h)
    if os.path.basename(up) == "profiles":
        root = os.path.dirname(up)
        if os.path.isdir(os.path.join(root, "qosha")) or os.path.exists(os.path.join(root, "config.yaml")):
            return root
    return h


def _dir(home=None) -> str:
    return os.path.join(_anchor(home or _home()), "qosha")


def _install_tag(home=None) -> str:
    try:
        with open(os.path.join(_dir(home), "install-id.json"), "rb") as fh:
            raw = fh.read(65536)
    except OSError:
        return ""
    return hashlib.sha256(raw).hexdigest()[:24] if raw.strip() else ""


def _norm(key) -> str:
    k = str(key or "").strip()
    return k if k.startswith("plugin_rule:") or not k.startswith("qosha:") else "plugin_rule:" + k


def _read(home=None) -> dict:
    try:
        with open(os.path.join(_dir(home), FILE), encoding="utf-8") as fh:
            d = json.load(fh)
    except (OSError, ValueError):
        return {}
    tag = _install_tag(home)
    if not isinstance(d, dict) or not tag or d.get("install") != tag or not isinstance(d.get("grants"), dict):
        return {}
    return d["grants"]


class _FileLock:
    """One writer at a time across Qosha's processes (TS-G-08)."""

    def __init__(self, home=None):
        self.path, self.fh = os.path.join(_dir(home), ".grants.lock"), None

    def __enter__(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self.fh = open(self.path, "a+b")
        end = time.monotonic() + 10
        while True:
            try:
                if os.name == "nt":
                    import msvcrt
                    self.fh.seek(0)
                    msvcrt.locking(self.fh.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self.fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                return self
            except OSError:
                if time.monotonic() > end:
                    self.fh.close()
                    raise
                time.sleep(0.05)

    def __exit__(self, *exc):
        try:
            if os.name == "nt":
                import msvcrt
                self.fh.seek(0)
                msvcrt.locking(self.fh.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.fh.fileno(), fcntl.LOCK_UN)
        except OSError:
            pass
        self.fh.close()
        return False


def can_record(home=None) -> bool:
    return bool(_install_tag(home))


def record_always(keys: Iterable, kind: str, *, surface: str, nonce: str, home=None) -> bool:
    """Record an "Always allow" given in the window for these rule keys. False if it could not be written."""
    if surface not in SURFACES:
        return False
    tag = _install_tag(home)
    keys = [_norm(k) for k in keys if str(k or "").strip()]
    if not tag or not keys:
        return False
    with _lock, _FileLock(home):
        grants = _read(home)
        for k in keys:
            grants[k] = {"kind": str(kind), "surface": surface, "at": time.time(), "nonce": str(nonce)[:64]}
        d = _dir(home)
        try:
            os.makedirs(d, exist_ok=True)
            fd, tmp = tempfile.mkstemp(prefix=".grants-", dir=d)
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump({"v": 1, "install": tag, "grants": grants}, fh, indent=1, sort_keys=True)
            os.replace(tmp, os.path.join(d, FILE))
            return True
        except OSError:
            return False


def has(key, home=None) -> bool:
    g = _read(home).get(_norm(key))
    return isinstance(g, dict) and g.get("surface") in SURFACES


def forget(keys: Iterable = (), home=None, everything: bool = False) -> bool:
    """Remove grants (Settings > Approvals: "Stop always allowing"). Removing never needs the window."""
    with _lock, _FileLock(home):
        grants = {} if everything else _read(home)
        for k in keys:
            grants.pop(_norm(k), None)
        tag = _install_tag(home)
        if not tag:
            return False
        try:
            d = _dir(home)
            fd, tmp = tempfile.mkstemp(prefix=".grants-", dir=d)
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump({"v": 1, "install": tag, "grants": grants}, fh, indent=1, sort_keys=True)
            os.replace(tmp, os.path.join(d, FILE))
            return True
        except OSError:
            return False


def listing(home=None) -> list:
    return [dict(v, key=k) for k, v in sorted(_read(home).items()) if isinstance(v, dict)]
