"""With the trusted surface on, the dashboard's gate confirms privileged writes in Qosha's approval window (H2).

Ren's cards 23 Nov 2026 (option B, H1-H6 folded in). The app window loses its special privileges: every caller (the
app window, a browser tab, a program on this computer) gets the browser-tab allowlists in approval_gate.py. A write
those allowlists refuse is not refused outright any more: the dashboard shows what it would do in the approval window
(from the request itself, built here, never words from a page) and lets it through only after Allow this time:
- a waiting decision (POST /decisions/<id>/approve): the decision's own summary and payload from the store; the body's
  payload_sha256 must be the stored one (H1), and the route's atomic claim checks it again;
- settings and the rest (PUT /api/config, PUT /api/env, Trust ON, desktop continue/setup, an automation turned back
  on, ...): method, address and the exact body (an env value is shown only as its length).
Never "Always allow" here (approval settings and safety switches ask every time). One window at a time: while one is
open, another such write is refused at once (no queue a page could fill). Declining a decision passes for every
caller (Stop must always work).
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import sys


def _floor_marker() -> bool:
    """The native floor (council RC6): once this install answered approvals only in Qosha's approval window, the
    marker keeps it so in every later build that honours it (a rollback to N included), without patching any file."""
    try:
        from hermes_constants import get_default_hermes_root
        root = str(get_default_hermes_root())
    except Exception:
        root = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    try:
        return os.path.exists(os.path.join(root, "qosha", "native-approval.json"))
    except Exception:
        return True

log = logging.getLogger("qosha.window_gate")

DECLINED = ("Not done: it was declined in the Qosha approval window (or the window was closed, timed out or could not "
            "open).")
BUSY = "Another Qosha approval window is open: answer it first, then try again."
_ST = sys.modules.get("_qosha_window_gate_state")
if _ST is None:                # one mark per process however many copies of this file are loaded (TS-M2-03)
    import types as _types
    _ST = _types.ModuleType("_qosha_window_gate_state")
    _ST.allowed, _ST.ready = object(), {"ok": False}   # ready only once register() set every hook
    sys.modules["_qosha_window_gate_state"] = _ST
ALLOWED = _ST.allowed          # set on a request's scope by confirm() only; routes' own window checks read it
_DECISION = re.compile(r"^/api/plugins/qosha/decisions/(d_[0-9a-f]{12})/approve/?$")
_JOB = re.compile(r"^/api/cron/jobs/([^/]+)/(?:resume|trigger)/?$")
_DECLINE = re.compile(r"^/api/plugins/qosha/decisions/d_[0-9a-f]{12}/decline/?$")
_KIND_OF_DECISION = (("delete", "delete"), ("send", "send"), ("reply", "send"), ("forward", "send"),
                     ("share", "share"), ("pay", "pay"))


def _guard(name: str):
    """A sibling module of qosha_guard, the same instance the rest of this process uses."""
    p = os.path.join(os.path.dirname(os.path.realpath(__file__)), name + ".py")
    for m in list(sys.modules.values()):
        f = getattr(m, "__file__", None)
        try:
            if f and os.path.realpath(f) == p:
                return m
        except Exception:
            continue
    import importlib
    import importlib.util
    pkg = __name__.rsplit(".", 1)[0] if "." in __name__ else ""
    if pkg:                                              # loaded as part of the plugin's package: its siblings there
        return importlib.import_module(pkg + "." + name)
    for m in list(sys.modules.values()):                 # the plugin's own package, loaded under another name
        f = getattr(m, "__file__", None)
        try:
            if f and os.path.realpath(f) == os.path.join(os.path.dirname(p), "__init__.py") and getattr(m, "__path__", None):
                return importlib.import_module(m.__name__ + "." + name)
        except Exception:
            continue
    if "qosha_guard" not in sys.modules:
        init = os.path.join(os.path.dirname(p), "__init__.py")
        spec = importlib.util.spec_from_file_location("qosha_guard", init,
                                                      submodule_search_locations=[os.path.dirname(p)])
        pkg = importlib.util.module_from_spec(spec)
        sys.modules["qosha_guard"] = pkg
        spec.loader.exec_module(pkg)
    return importlib.import_module("qosha_guard." + name)


def enabled() -> bool:
    """Same source as approval_gate._native (engine_cards.py's text); unreadable = on (fail closed)."""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "engine_cards.py"), encoding="utf-8") as fh:
            if (re.search(r"(?m)^ON = True\b", fh.read()) or _floor_marker()):
                return True
    except Exception:
        return True
    try:
        return bool(_guard("engine_cards").enabled())
    except Exception:
        return False


# the privileged writes the window may confirm (TS-G-14); anything else the allowlists refuse stays refused (403)
_CONFIRMABLE = [
    ({"POST"}, _DECISION),
    ({"PUT"}, re.compile(r"^/api/config/?$")),
    ({"POST"}, re.compile(r"^/api/plugins/qosha/trust/+on/?$")),
    ({"POST"}, re.compile(r"^/api/plugins/qosha/desktop/+(?:continue|setup)/?$")),
    ({"POST"}, re.compile(r"^/api/cron/jobs/[^/]+/(?:resume|trigger)/?$")),
    ({"POST"}, re.compile(r"^/api/plugins/qosha/inbox-watch/settings/?$")),
]
if not hasattr(_ST, "reserve"):
    _ST.reserve, _ST.rlock = {"n": 0}, __import__("threading").Lock()
_reserve, _rlock = _ST.reserve, _ST.rlock


def confirmable(path: str, method: str) -> bool:
    return any(method in ms and rx.match(path) for ms, rx in _CONFIRMABLE)


def _no_duplicate_keys(body: bytes) -> bool:
    """A body whose JSON names a key twice is refused: what the window shows must be what runs (TS-G-11)."""
    if not body.strip():
        return True

    def pairs(items):
        keys = [k for k, _v in items]
        if len(keys) != len(set(keys)):
            raise ValueError("duplicate key")
        return dict(items)
    try:
        json.loads(body.decode("utf-8"), object_pairs_hook=pairs)
        return True
    except ValueError:
        return False
    except Exception:
        return False


def decline_passes(path: str, method: str) -> bool:
    return method == "POST" and bool(_DECLINE.match(path))


def _lang() -> str:
    try:
        return str(_guard("i18n").lang() or "en")
    except Exception:
        return "en"


def _pretty(body: bytes) -> str:
    try:
        return json.dumps(json.loads(body.decode("utf-8")), indent=2, ensure_ascii=False, sort_keys=True)
    except Exception:
        return body.decode("utf-8", "replace")


def describe(path: str, method: str, query: str, body: bytes):
    """(kind, text, facts, payload) for the window, or None when the request can't be shown honestly (refused)."""
    td = _guard("trusted_dialog")
    m = _DECISION.match(path)
    if m and method == "POST" and not _no_duplicate_keys(body):
        return None                                         # a key named twice: refused (TS-G-11)
    if m and method == "POST":
        store = _guard("store")
        row = store.get(m.group(1))
        try:
            parsed = json.loads(body.decode("utf-8") or "{}")
            sent = parsed.get("payload_sha256") if isinstance(parsed, dict) and set(parsed) == {"payload_sha256"} else None
        except Exception:
            sent = None
        if query:
            sent = None                                     # nothing beyond what the window shows (TS-M-05)
        if not row or row.get("status") != "pending" or not sent or sent != row.get("payload_sha256"):
            return None                                     # nothing honest to show: refused (H1)
        dk = str(row.get("kind") or "")
        kind = next((k for w, k in _KIND_OF_DECISION if w in dk), "other")
        raw_payload = row.get("payload")
        payload = raw_payload if isinstance(raw_payload, dict) else {}
        facts = [("@Action", str(row.get("summary") or dk))]
        for label, keys in (("to", ("to", "recipient", "recipients")), ("cc", ("cc",)), ("bcc", ("bcc",)),
                            ("guests", ("attendees", "guests")), ("shared_with", ("share_with", "grantee", "email")),
                            ("amount", ("amount", "total")), ("target", ("path", "url", "target", "file"))):
            for k in keys:                                   # every recipient field, each pinned (TS-M-06)
                v = payload.get(k)
                if v:                                        # one fact per recipient (TS-R-G-07)
                    items = v if isinstance(v, (list, tuple)) else [v]
                    # exactly as stored: no address parsing that could drop or change one (TS-S7-6/7, TS-S7-G-10/11)
                    facts.extend((label, x if isinstance(x, str) else json.dumps(x, ensure_ascii=False, default=str))
                                 for x in items if str(x).strip())
        if dk in ("email.send", "email.reply") and not any(k in ("to", "cc", "bcc") and "@" in v for k, v in facts):
            return None                                     # a send that names no one: refused (TS-R2 G-06)
        text = str(row.get("summary") or "") + "\n\n" + json.dumps(raw_payload, indent=2, ensure_ascii=False,
                                                                  sort_keys=True, default=str)
        return kind, text, facts, {"decision": m.group(1), "sha": row.get("payload_sha256")}
    shown = body
    if not confirmable(path, method) or not _no_duplicate_keys(body):
        return None                                         # refused as before (TS-G-14, TS-G-11)
    mj = _JOB.match(path)
    if mj and method == "POST":
        job = _job(mj.group(1))
        if not job:
            return None
        # the WHOLE job record (working folder, script, delivery origin, everything it runs with: TS-R-G-02 / TS-R-8)
        shown = json.dumps(job, indent=2, ensure_ascii=False, sort_keys=True, default=str)
        sent = body.decode("utf-8", "replace") if body else ""
        text = "%s %s%s\n\n%s%s" % (method, path, ("?" + query) if query else "", shown,
                                    ("\n\n----\n" + sent) if sent.strip() else "")
        return "run", text, [("target", "%s %s" % (method, path))], {"m": method, "p": path, "q": query,
                                                                     "b": td.payload_sha(body),
                                                                     "job": _job_digest(job)}
    kind = "settings"
    if path.rstrip("/").endswith("/trust/on"):
        kind = "trust_on"
    elif "/desktop/" in path:
        kind = "desktop"
    elif path.rstrip("/") == "/api/config":
        try:
            cfg = (json.loads(body.decode("utf-8")) or {}).get("config")
        except Exception:
            cfg = None
        if cfg == {"browser": {"use_real_profile": True}} or cfg == {"browser": {"use_real_profile": False}}:
            kind = "browser_profile"                          # exactly that one switch, nothing else
    text = "%s %s%s\n\n%s" % (method, path, ("?" + query) if query else "", _pretty(shown))
    return kind, text, [("target", "%s %s" % (method, path))], {"m": method, "p": path, "q": query,
                                                                 "b": td.payload_sha(body)}


def _authorized(scope) -> bool:
    """The caller carries the dashboard's own session (the engine's own check), before any window is reserved or
    opened (council RC4). Can't check = no."""
    try:
        ws = sys.modules.get("hermes_cli.web_server")
        fn = getattr(ws, "_has_valid_session_token", None)
        if fn is None:
            return False
        from starlette.requests import Request
        return bool(fn(Request(scope)))
    except Exception:
        return False


async def confirm(app, scope, body: bytes, receive_rest, send, refuse) -> None:
    """Show the request in the approval window; pass it on only after Allow this time (exactly the buffered body)."""
    path, method = scope.get("path") or "", str(scope.get("method") or "").upper()
    if not _authorized(scope):
        return await _answer(send, 401, "Unauthorized", "unauthorized")
    qs = scope.get("query_string") or b""
    query = qs.decode("latin-1") if isinstance(qs, bytes) else str(qs)
    td = _guard("trusted_dialog")
    with _rlock:                                            # one window at a time, reserved before any work (TS-G-14)
        if _reserve["n"] or td.pending():
            busy = True
        else:
            busy, _reserve["n"] = False, 1
    if busy:
        return await _answer(send, 409, BUSY, "qosha_window_busy")
    try:
        return await _confirm_reserved(app, scope, body, receive_rest, send, refuse, path, method, query, td)
    finally:
        with _rlock:
            _reserve["n"] = 0


async def _confirm_reserved(app, scope, body, receive_rest, send, refuse, path, method, query, td) -> None:
    try:
        d = describe(path, method, query, body)
    except Exception as e:
        log.warning("approval window: could not describe %s (%s)", path, e.__class__.__name__)
        d = None
    if d is None:
        return await refuse(send, path)
    kind, text, facts, payload = d
    loop = asyncio.get_running_loop()
    ans = await loop.run_in_executor(None, lambda: td.ask(kind, text, payload, facts=facts, always=False,
                                                          lang=_lang()))
    if not ans.allowed or ans.sha256 != td.payload_sha(payload):
        return await _answer(send, 403, DECLINED, "qosha_declined_in_window")
    replay = [{"type": "http.request", "body": body, "more_body": False}]

    async def again():
        return replay.pop(0) if replay else await receive_rest()
    if isinstance(payload, dict) and payload.get("job"):
        mj = _JOB.match(path)
        now = _job(mj.group(1)) if mj else None
        if not now or _job_digest(now) != payload["job"]:     # changed while the window was open: not run
            return await _answer(send, 409, "Not done: this automation changed while you were deciding. Nothing "
                                            "ran; ask again to see the current version.", "qosha_job_changed")
    log.info("approval window: %s %s allowed by the person", method, path)
    if isinstance(payload, dict) and payload.get("job"):
        # the store itself compares again inside its own lock, right where it resumes / schedules the job (G-01)
        jid = _JOB.match(path).group(1)
        changed = ("Not done: this automation changed while you were deciding. Nothing ran; ask again to see the "
                   "current version.")
        if not _bind_job_store() or jid in _expect():
            # the store can't check it inside its own lock, or this job is already being confirmed: refused (TS-S7-5)
            return await _answer(send, 409, changed, "qosha_job_changed")
        _expect()[jid] = payload["job"]
        try:
            return await app(dict(scope, qosha_window_allowed=ALLOWED), again, send)
        except JobChanged:
            return await _answer(send, 409, changed, "qosha_job_changed")
        finally:
            _expect().pop(jid, None)
    return await app(dict(scope, qosha_window_allowed=ALLOWED), again, send)


class JobChanged(RuntimeError):
    pass


def _expect() -> dict:
    """Jobs confirmed in the window and being dispatched now: id -> digest (one map per process)."""
    m = getattr(_ST, "job_expect", None)
    if m is None:
        m = _ST.job_expect = {}
    return m


def _bind_job_store() -> bool:
    """Wrap the engine's job store resume / trigger once: while a confirmed dispatch for that job is running, the job
    must still have the digest the person confirmed, read inside the store's own lock (an edit between the window's
    check and the store is refused, round-2 G-01)."""
    try:
        import contextlib
        import cron.jobs as cj
    except Exception:
        return False
    for name in ("resume_job", "trigger_job"):
        orig = getattr(cj, name, None)
        if orig is None:
            return False                                   # nothing to check inside: refused (fail closed)
        if getattr(orig, "qosha_bound", False):
            continue

        def wrapped(job_id, *a, _orig=orig, **kw):
            exp = _expect().get(str(job_id))
            if exp is None:
                return _orig(job_id, *a, **kw)
            lock = getattr(cj, "_jobs_lock", None)
            with (lock() if callable(lock) else contextlib.nullcontext()):
                now = cj.get_job(job_id)
                if not now or _job_digest(now) != exp:
                    raise JobChanged("this automation changed after it was confirmed; nothing ran")
                return _orig(job_id, *a, **kw)
        wrapped.qosha_bound = True
        wrapped.__wrapped__ = orig
        setattr(cj, name, wrapped)
    return callable(getattr(cj, "_jobs_lock", None))       # the store's own lock is what makes the check atomic


def _job(job_id: str):
    try:
        from cron.jobs import get_job
        return get_job(job_id)
    except Exception:
        return None


def _job_digest(job) -> str:
    """The WHOLE job record (council RC4: instructions, schedule, destination, tools, model, folder ...)."""
    return _guard("trusted_dialog").payload_sha(json.loads(json.dumps(job, default=str)))


async def _answer(send, status: int, text: str, code: str) -> None:
    body = json.dumps({"detail": text, "error": code}).encode("utf-8")
    await send({"type": "http.response.start", "status": status,
                "headers": [(b"content-type", b"application/json"), (b"content-length", str(len(body)).encode())]})
    await send({"type": "http.response.body", "body": body})
