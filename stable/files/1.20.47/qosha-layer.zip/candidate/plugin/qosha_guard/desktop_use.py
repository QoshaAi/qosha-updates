"""Qosha uses the person's computer: the engine's own `computer_use` tool (cua-driver), gated (cu20, 22 Nov 2026).

Ren's rule: a person approves before anything is sent, paid, deleted or shared ("Allow this time" / "Always allow" per
kind). Council (GPT-6.2 Astra, Gemini 4 Neon), 22 Nov: refuse what Qosha can't identify, check the real program, bind
the check to the exact step that runs. What this module decides for one `computer_use` call:
  * reading (capture, list_apps, list_windows, wait): runs;
  * input into Qosha's own window, a web browser, a terminal or script runner, a launcher, or a password/security
    prompt (checked by the window's real program file, never by the name the AI passes): refused, in plain words;
  * clicks only by element number from Qosha's last look at that window (coordinates, drags, unnamed buttons,
    elements Qosha didn't see: refused). The element's on-screen name decides: send / pay / delete / share / confirm
    get Qosha's card, everything else runs;
  * keyboard only into a text field Qosha itself clicked (editing keys run; Enter gets a one-time card that shows
    what was typed; other shortcuts refused);
  * every step Qosha judged is bound to the window snapshot it judged: a newer look, or a step Qosha never judged,
    is refused at the moment it would run (`bind` wraps the engine's backend).
Nothing here may raise into the engine: on any error the step is refused.
"""
from __future__ import annotations

import json
import os
import re
import sys
import threading
import time
import unicodedata
from typing import Any, Dict, List, Optional, Tuple


def _floor_marker() -> bool:
    """The native floor (council RC6): once this install answered approvals only in Qosha's approval window, the
    marker keeps it so in every later build that honours it (a rollback to N included), without patching any file."""
    try:
        from hermes_constants import get_default_hermes_root
        root = str(get_default_hermes_root())
    except Exception:
        root = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    try:
        return os.path.exists(os.path.join(root, "qosha", "native-approval.json"))
    except Exception:
        return True

TOOL = "computer_use"
READS = frozenset({"capture", "list_apps", "list_windows", "wait"})
CLICKS = frozenset({"click", "double_click", "middle_click", "right_click"})
KEYBOARD = frozenset({"type", "key"})

KIND_TEXT = {
    "desktop.send": "send something from an app on your computer",
    "desktop.pay": "pay or buy something in an app on your computer",
    "desktop.delete": "delete something in an app on your computer",
    "desktop.share": "share or publish something from an app on your computer",
    "desktop.confirm": "confirm something in an app on your computer",
    "desktop.enter": "press Enter in an app on your computer",
}
ONCE_ONLY = {"desktop.pay": "it pays or buys", "desktop.confirm": "Qosha can't see what the confirmation is for",
             "desktop.enter": "Enter can send, confirm or run whatever was typed"}

# ---- the real program behind the window (its file path, lower case, "/" separators) ----------------------------
_APP = r"(?:^|/)(%s)\.app/"
_EXE = r"(?:^|/)(%s)\.exe$"
_GROUPS = [
    # WhatsApp (connectors R6, founder-approved): Qosha reads and replies only through its own WhatsApp connection
    ("whatsapp", re.compile(_APP % r"whatsapp(?: desktop)?" + "|" + _EXE % r"whatsapp" + r"|whatsappdesktop")),
    ("qosha", re.compile(_APP % r"qosha" + "|" + _EXE % r"qosha" + r"|/programs/qosha/|/application support/qosha/"
                         r"|/appdata/local/qosha/")),
    ("browser", re.compile(_APP % (r"safari|google chrome(?: beta| dev| canary)?|chromium|microsoft edge(?: beta| dev"
                                   r"| canary)?|firefox(?: developer edition| nightly)?|brave browser(?: beta| nightly)?"
                                   r"|arc|opera(?: gx)?|vivaldi|orion|duckduckgo|zen(?: browser)?|librewolf|waterfox"
                                   r"|tor browser|yandex|sidekick|sigmaos|comet|dia|safari technology preview"
                                   r"|webkit|chrome(?: for testing)?|thorium|floorp|mullvad browser|ladybird"
                                   r"|firefox beta|brave browser beta|opera air|maxthon|edge") + "|" +
                           _EXE % (r"chrome|msedge|firefox|brave|opera|vivaldi|iexplore|arc|chromium|librewolf|waterfox"
                                   r"|browser|duckduckgo|comet|dia|thorium|floorp|ladybird|chrome_proxy|zen"
                                   r"|msedgewebview2|maxthon|waterfox|palemoon|seamonkey|iexplore"))),
    ("terminal", re.compile(_APP % (r"terminal|iterm2?|warp|alacritty|kitty|wezterm|hyper|ghostty|tabby|script editor"
                                    r"|automator|shortcuts|visual studio code|cursor|windsurf|zed|xcode") + "|" +
                            _EXE % (r"windowsterminal|wt|cmd|powershell|pwsh|powershell_ise|conhost|openconsole|mintty"
                                    r"|bash|wsl|wslhost|putty|code|cursor|windsurf|wscript|cscript|mshta|git-bash"
                                    r"|alacritty|wezterm-gui|wezterm|kitty|hyper|tabby|rundll32"))),
    ("launcher", re.compile(_APP % r"spotlight|alfred(?: \d+)?|raycast|launchbar" + "|" +
                            _EXE % r"searchhost|searchapp|startmenuexperiencehost|powertoys\.powerlauncher")),
    ("security", re.compile(_APP % (r"securityagent|usernotificationcenter|keychain access|passwords|1password(?: \d+)?"
                                    r"|bitwarden|lastpass|dashlane|keepassxc|system settings|system preferences"
                                    r"|coreauthui|coreservicesuiagent|installer|directory utility|disk utility") +
                            r"|coreautha\.bundle/|" +
                            _EXE % (r"consent|credentialuibroker|1password|bitwarden|keepassxc|keepass|lastpass"
                                    r"|dashlane|systemsettings|regedit|control|mmc|msiexec|taskmgr"
                                    r"|applicationframehost|securityhealthhost"))),
]
_FILE_MANAGER = re.compile(_APP % r"finder" + "|" + _EXE % r"explorer")
WHATSAPP_TEXT = ("Qosha doesn't click or type in WhatsApp. It reads and replies through its own WhatsApp connection, and "
                 "the person approves each reply. Nothing was done.")
WHATSAPP_READ = ("Not done: while WhatsApp is linked to Qosha, Qosha doesn't take pictures of WhatsApp or of the whole "
                 "screen (the screen can show WhatsApp). It reads WhatsApp only through its own connection, which asks "
                 "the person each time. Pick the app to look at with app=... (not WhatsApp).")
REFUSE_TEXT = {
    "qosha": "that is Qosha's own window. Qosha never clicks or types in its own window (that is where you approve "
             "its steps).",
    "browser": "that window is a web browser. For websites Qosha uses its own browser, where each final step (send, "
               "buy, delete, sign in) is shown to you first. Use the browser tools for this.",
    "terminal": "that window runs commands or scripts. Qosha runs commands with its own terminal, where each risky "
                "step is shown to you first. Use the terminal tool for this.",
    "launcher": "that window starts programs or commands. Open the app by name with action='focus_app' instead.",
    "security": "that is a password, sign-in or security window. Those are only for you; Qosha doesn't type or click "
                "there. Ask the person to do this step themselves.",
    "unknown": "Qosha could not tell which program that window belongs to, so it doesn't click or type there. Take a "
               "fresh capture of the app first (action='capture' with app=...).",
}


def program_group(pid: Any) -> Tuple[str, str]:
    """(group, program path) for a window's process: qosha / browser / terminal / launcher / security / app, or
    ("unknown", "") when the program can't be read."""
    try:
        import psutil
        p = psutil.Process(int(pid))
        try:
            path = p.exe() or ""
        except Exception:
            path = ""
        if not path:
            return "unknown", ""
    except Exception:
        return "unknown", ""
    return group_of_path(path), path


_BUNDLE_IDS = {"net.whatsapp.whatsapp": "whatsapp", "whatsapp": "whatsapp", "desktop.whatsapp": "whatsapp"}


_BUNDLE_CACHE: Dict[str, str] = {}


def _bundle_id(path: str) -> Optional[str]:
    """The CFBundleIdentifier of the .app a macOS program sits in: "" when it isn't in an .app; None when the .app's
    Info.plist is missing or can't be read (GPT closures #4: unknown = refused, never cached). A renamed copy of an
    app is still that app."""
    m = re.search(r"^(.*?\.app)/", path, re.I)
    if not m:
        return ""
    if path in _BUNDLE_CACHE:
        return _BUNDLE_CACHE[path]
    try:
        import plistlib
        with open(os.path.join(m.group(1), "Contents", "Info.plist"), "rb") as fh:
            got = str(plistlib.load(fh).get("CFBundleIdentifier") or "").lower()
    except Exception:
        return None
    if len(_BUNDLE_CACHE) > 512:
        _BUNDLE_CACHE.clear()
    _BUNDLE_CACHE[path] = got
    return got


def group_of_path(path: str) -> str:
    low = str(path or "").replace("\\", "/").lower()
    if not low:
        return "unknown"
    if sys.platform == "darwin":       # the .app's own identity first: a renamed copy is still that app (closures 4-6)
        bid = _bundle_id(str(path).replace("\\", "/"))
        if bid is None:
            return "unknown"           # missing or unreadable Info.plist: can't tell what it is
        if _BUNDLE_IDS.get(bid):
            return _BUNDLE_IDS[bid]
    for name, rx in _GROUPS:
        if rx.search(low):
            return name
    return "app"


# ---- what an element's on-screen name says it does ---------------------------------------------------------------
def _fold(text: str) -> str:
    t = unicodedata.normalize("NFKD", str(text or "")).encode("ascii", "ignore").decode("ascii").lower()
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]+", " ", t)).strip()


def _words(*alts: str) -> "re.Pattern":
    return re.compile(r"(?:^| )(?:%s)(?= |$)" % "|".join(alts))


_NEGATED = re.compile(r"^(?:cancel|cancelar|no|nao|not now|later|depois|close|fechar|cerrar|dont send|don t send"
                      r"|do not send|nao enviar|dont allow|don t allow|do not allow|nao permitir|no thanks|nao obrigado"
                      r"|annuler|abbrechen|annulla|annuleren|non|nein|nee|fermer|schliessen|chiudi|sluiten)$")
_KINDS = [   # checked in this order on the folded name; first match wins
    ("desktop.pay", _words(r"pay\w*", r"buy\w*", r"purchas\w*", r"checkout", r"check out", r"place (?:your )?order",
                           r"order now", r"subscri\w*", r"donat\w*", r"transfer\w*", r"send money",
                           r"cancel (?:order|subscription|plan|membership)", r"cancelar (?:pedido|assinatura|plano)",
                           r"book now", r"pagar", r"pague", r"pagamento", r"comprar?", r"compre", r"finalizar (?:compra|"
                           r"pedido)", r"assinar", r"assine", r"transferir", r"doar", r"pix", r"comprar ahora",
                           r"suscribir\w*", r"realizar pedido", r"payer", r"acheter", r"commander", r"bezahlen",
                           r"kaufen", r"jetzt kaufen", r"bestellen", r"pagare", r"acquista", r"betalen", r"kopen",
                           r"virement", r"uberweisen", r"bonifico", r"overmaken")),
    ("desktop.delete", _words(r"delet\w*", r"remov\w*", r"trash", r"bin", r"erase", r"discard\w*", r"empty", r"uninstall\w*",
                              r"destroy\w*", r"wipe", r"purge", r"clear all", r"excluir", r"exclua", r"apagar", r"apague",
                              r"deletar", r"remover", r"lixeira", r"descartar", r"esvaziar", r"desinstalar", r"eliminar",
                              r"borrar", r"papelera", r"suprimir", r"recycle", r"move to (?:trash|bin)",
                              r"mover para (?:a )?lixeira", r"dont save", r"don t save", r"do not save",
                              r"nao salvar", r"no guardar", r"supprimer", r"corbeille", r"loschen", r"entfernen",
                              r"papierkorb", r"elimina", r"cestino", r"verwijderen", r"prullenbak",
                              r"ne pas enregistrer", r"nicht speichern", r"non salvare", r"niet opslaan")),
    ("desktop.share", _words(r"shar\w*", r"publish\w*", r"invit\w*", r"upload\w*", r"make public", r"get link",
                             r"copy link", r"add people", r"grant access", r"compartilh\w*", r"publicar", r"publique",
                             r"convidar", r"convide", r"carregar", r"enviar arquivo", r"compartir", r"invitar",
                             r"subir", r"partager", r"publier", r"teilen", r"freigeben", r"veroffentlichen",
                             r"condividi", r"pubblica", r"delen", r"publiceren", r"inviter", r"einladen", r"invita")),
    ("desktop.send", _words(r"send\w*", r"reply all", r"forward\w*", r"post", r"submit\w*", r"comment", r"tweet",
                            r"enviar", r"envie", r"encaminhar", r"responder a todos", r"postar", r"comentar",
                            r"mandar", r"reenviar", r"envoyer", r"repondre a tous", r"transferer", r"senden",
                            r"absenden", r"weiterleiten", r"invia", r"inoltra", r"verzenden", r"versturen",
                            r"doorsturen")),
    ("desktop.confirm", _words(r"ok", r"okay", r"yes", r"confirm\w*", r"continu\w*", r"allow", r"accept\w*", r"agree",
                               r"i agree", r"proceed", r"approve\w*", r"sim", r"aprovar", r"confirmar", r"permitir",
                               r"aceitar", r"concordo", r"prosseguir", r"si", r"aceptar",
                               r"acepto", r"oui", r"accepter", r"ja", r"zustimmen", r"bestatigen", r"conferma",
                               r"accetta", r"akkoord", r"bevestigen", r"toestaan", r"autoriser", r"erlauben",
                               r"consenti")),
]
_EDITABLE = re.compile(r"text ?field|text ?area|search ?field|combo ?box|^edit$|^ax ?document$|^document$", re.I)
_SECURE = re.compile(r"secure|password", re.I)
_SECRET_NAME = re.compile(r"(?:^| )(?:password|passcode|passphrase|pin|senha|contrasena|mot de passe|passwort|"
                          r"kennwort|wachtwoord|otp|one time code|codigo de verificacao|verification code|cvv|cvc)(?: |$)")
_OPENERS = re.compile(r"^(?:open|open with|run|run as administrator|abrir|abrir com|executar|ejecutar|abrir con)\b")
_LINK = re.compile(r"link", re.I)
# a sheet, dialog, popover, alert or second window inside the captured window can be another program's (AutoFill,
# passwords, open/save panels); the driver doesn't say which program owns an element (GPT closure #3)
_HOSTED = re.compile(r"sheet|dialog|popover|alert|remote|drawer|^(?:ax ?)?window$", re.I)
_AUTOFILL = re.compile(r"auto ?fill|passkey|keychain|credential|preenchimento automatico|chaves|llavero|"
                       r"trousseau|schlusselbund|use password|usar senha|fill password|preencher senha|1password|bitwarden")
_VALUE_CONTROL = re.compile(r"slider|stepper|incrementor|pop ?up|combo ?box|spin|scroll ?bar|picker|date", re.I)
_RUNNABLE = re.compile(r"\.(?:command|tool|sh|zsh|bash|csh|py|pl|rb|js|jse|vbs|vbe|wsf|bat|cmd|ps1|psm1|exe|com|scr|msi|"
                       r"msix|appx|pkg|mpkg|dmg|app|scpt|scptd|applescript|workflow|jar|lnk|url|webloc|terminal|"
                       r"inetloc|reg|hta|cpl)\b", re.I)
_UNSAFE_CHARS = re.compile("[\x00-\x1f\x7f-\x9f\u200b-\u200f\u2028-\u202e\u2066-\u2069\ufeff]")


def clean(text: Any, n: int = 200) -> str:
    """On-screen text as it may go on a card: one line, no control or direction-changing characters, cut short."""
    t = _UNSAFE_CHARS.sub(" ", str(text or ""))
    t = re.sub(r"\s+", " ", t).strip()
    return t if len(t) <= n else t[:n - 1] + "\u2026"


def label_kinds(label: str) -> List[str]:
    """Every desktop kind an on-screen name says (send, pay, delete, share, confirm), in priority order."""
    t = _fold(label)
    if not t or _NEGATED.search(t):
        return []
    return [kind for kind, rx in _KINDS if rx.search(t)]


_PAY_SEND = re.compile(r"^(?:send|enviar|envoyer|senden|invia) (?:money|payment|funds|dinheiro|pagamento|dinero|pago|"
                       r"de l argent|geld|denaro)$")


def label_kind(label: str) -> Optional[str]:
    """The one kind a name says; "mixed" when it says two effects (send and delete...): such a control is refused."""
    ks = [k for k in label_kinds(label) if k != "desktop.confirm"] or label_kinds(label)
    if "desktop.pay" in ks and "desktop.send" in ks and _PAY_SEND.search(_fold(label)):
        ks.remove("desktop.send")          # "Send money", "Send payment": one payment (GPT r2 R2-6); not "Pay and send"
    return None if not ks else ks[0] if len(ks) == 1 else "mixed"


# ---- keys ------------------------------------------------------------------------------------------------------
_MOD = {"cmd": "cmd", "command": "cmd", "ctrl": "ctrl",
        "control": "ctrl", "alt": "alt", "option": "alt", "opt": "alt", "shift": "shift", "fn": "fn"}
_ENTER = {"return", "enter", "kp_enter", "numpadenter", "numpad_enter", "kpenter", "linefeed"}
_DELETE_KEYS = {"backspace", "delete", "forwarddelete", "forward_delete", "del"}
_EDIT_KEYS = _DELETE_KEYS | {"left", "right", "up", "down", "home", "end"}
_CLEARS_FOCUS = {"escape", "esc", "tab"} | _ENTER
_UNKNOWN_MODS = {"super", "meta", "win", "windows", "gui", "hyper", "lwin", "rwin", "lcmd", "rcmd", "lctrl", "rctrl",
                 "lalt", "ralt", "lshift", "rshift", "cmdorctrl", "commandorcontrol", "altgr", "globe"}
_KEY_NAME = re.compile(r"^(?:[a-z0-9]|f(?:[1-9]|1[0-9]|2[0-4])|[a-z_]{2,20})$")
_EDIT_COMBOS = {("cmd", "a"), ("cmd", "c"), ("cmd", "v"), ("cmd", "x"), ("cmd", "z"), ("cmd", "y"), ("ctrl", "a"),
                ("ctrl", "c"), ("ctrl", "v"), ("ctrl", "x"), ("ctrl", "z"), ("ctrl", "y")}
_NAV_ANYWHERE = {"escape", "esc", "tab", "left", "right", "up", "down", "pageup", "pagedown", "page_up", "page_down",
                 "home", "end"}


def parse_keys(keys: str) -> Tuple[frozenset, str]:
    """(modifiers, key) split the way the engine splits it (tools/computer_use/cua_backend_parse._parse_key_combo:
    on + and -, the last non-modifier wins)."""
    parts = [p.strip().lower() for p in re.split(r"[+\-]", str(keys or "")) if p.strip()]
    mods = frozenset(_MOD[p] for p in parts if p in _MOD)
    main = [p for p in parts if p not in _MOD]
    if len(main) != 1 or main[0] in _UNKNOWN_MODS or not _KEY_NAME.match(main[0]):
        return mods, ""                           # two keys, an unknown modifier name or an odd token: not read
    return mods, main[0]


# ---- the window snapshot Qosha looked at, per engine backend (kept beside the driver's element tokens) -------------
_LOCK = threading.RLock()


def _state(backend) -> Dict[str, Any]:
    st = getattr(backend, "_qosha_cu", None)
    if not isinstance(st, dict):
        st = {"gen": 0, "elements": {}, "app": "", "title": "", "target": None, "focus": None, "typed": "",
              "checked": None, "win_title": "", "last_click": "", "captured": None, "at": 0.0}
        try:
            backend._qosha_cu = st
        except Exception:
            pass
    return st


def note_capture(backend, cap) -> None:
    """After every capture: this snapshot's elements, and a new generation (so an older check can't be used)."""
    with _LOCK:
        st = _state(backend)
        st["gen"] += 1
        els = {}
        hosted = False
        for e in sorted(list(getattr(cap, "elements", None) or []), key=lambda x: int(getattr(x, "index", 0) or 0)):
            try:
                role = str(e.role or "")
                # the first element may be the captured window itself; any later window, sheet or dialog (and all
                # that follows it in the snapshot) may be hosted by another program
                if _HOSTED.search(role) and (els or not re.search(r"^(?:ax ?)?window$", role, re.I)):
                    hosted = True
                els[int(e.index)] = {"role": role, "label": str(e.label or ""), "pid": int(e.pid or 0),
                                     "hosted": hosted}
            except Exception:
                continue
        st["elements"], st["app"], st["title"] = els, str(getattr(cap, "app", "") or ""), \
            str(getattr(cap, "window_title", "") or "")
        st["at"] = time.monotonic()
        target = (getattr(backend, "_active_pid", None), getattr(backend, "_active_window_id", None))
        if target != st["target"]:
            st["focus"], st["typed"], st["last_click"], st["filled"] = None, "", "", None   # another window
        f = st["focus"]
        if f is not None and not any(e["role"] == f.get("role") and e["label"] == f.get("label") for e in els.values()):
            st["focus"], st["typed"] = None, ""       # the field Qosha typed into is gone from the window
        st["target"], st["captured"] = target, target


def note_window(backend, target: Any) -> None:
    """The window the driver picked (its list entry): its title, for the card when the capture carries none."""
    with _LOCK:
        st = _state(backend)
        st["win_title"] = str((target or {}).get("title") or "") if isinstance(target, dict) else ""


def note_target(backend) -> None:
    """focus_app or a cleared target: a new generation, no elements, no known text field."""
    with _LOCK:
        st = _state(backend)
        st["gen"] += 1
        st["elements"], st["focus"], st["typed"], st["last_click"] = {}, None, "", ""
        st["app"], st["title"], st["win_title"], st["captured"], st["filled"] = "", "", "", None, None
        st["target"] = (getattr(backend, "_active_pid", None), getattr(backend, "_active_window_id", None))


def backend_for(session_id: str):
    """The engine's live computer_use backend for this conversation, or None."""
    try:
        from tools.computer_use import tool as cu
        with cu._backend_lock:
            return cu._backends.get(cu._scoped_sid(session_id))
    except Exception:
        return None


# ---- the person's Stop (Qosha's own flag; the engine's lease is taken too, see desktop_api) -----------------------
STOPPED = ("Not done: the person pressed Stop, so Qosha may not look at or use their computer (no captures, clicks or "
           "typing) until they press \"Let Qosha continue\" in Qosha. If a step had already started, it may have "
           "happened; say so. Tell the person what you still need.")
SNAPSHOT_MAX_AGE = 60.0      # seconds: an older look at a window is not used for a click (council, 22 Nov)


def _home() -> str:
    try:
        from hermes_constants import get_hermes_home
        return str(get_hermes_home())
    except Exception:
        return os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")


def _root() -> str:
    """The default home (profiles live under it): one Stop for every profile on this computer (GPT CU-11)."""
    try:
        from hermes_constants import get_default_hermes_root
        return str(get_default_hermes_root())
    except Exception:
        return _home()


def stop_path() -> str:
    return os.path.join(_root(), "qosha", "desktop-stop.json")


LOCAL_ONLY = ("Not done: Qosha looks at and uses the computer only in a chat on this computer, where the person sees it "
              "and can press Stop; never from a message app, a website hook or an automation. Ask the person to do it "
              "from Qosha on their computer.")


LOCAL_PLATFORMS = {"", "local", "tui", "desktop", "cli"}     # the engine's own names for a chat on this computer


def local_session() -> bool:
    """A chat on this computer (the Qosha app / terminal): no messaging platform, webhook or automation session."""
    try:
        from tools import approval_context as ac
        if str(ac._get_session_platform() or "").strip().lower() not in LOCAL_PLATFORMS:
            return False
        return not ac._is_cron_approval_context()
    except Exception:
        return False


def stopped() -> bool:
    """True while the person's Stop holds. An unreadable flag counts as stopped (fail closed)."""
    p = stop_path()
    try:
        with open(p, encoding="utf-8") as fh:
            data = json.load(fh)
        return data.get("stopped") is not False
    except FileNotFoundError:
        return False
    except Exception:
        return True


def _trusted_dialog():
    """trusted_dialog.py, the same instance the rest of this process uses (this file may be loaded by path)."""
    import importlib.util as _ilu
    p = os.path.join(os.path.dirname(os.path.realpath(__file__)), "trusted_dialog.py")
    for m in list(sys.modules.values()):
        f = getattr(m, "__file__", None)
        if f and os.path.realpath(f) == p:
            return m
    if not os.path.exists(p):
        return None
    spec = _ilu.spec_from_file_location("qosha_trusted_dialog", p)
    m = _ilu.module_from_spec(spec)
    sys.modules["qosha_trusted_dialog"] = m
    spec.loader.exec_module(m)
    return m


class _NoWindow:
    def release(self) -> None:
        return None


def _hold_screen():
    """Qosha's click or keystroke and an approval window never share the screen (TS-G-03): the input takes the same
    cross-process lock the window holds for its whole life, without waiting. None = a window is open, or the lock
    can't be taken (fail closed). A build without the approval window: nothing to hold."""
    if not _surface_on():
        return _NoWindow()
    try:
        td = _trusted_dialog()
        if td is None:
            return _NoWindow()
        if td.pending() > 0:
            return None
        lock = td._CrossLock(shared=True)            # shared: several input steps may run; a window is exclusive
        return lock if lock.acquire(0) else None
    except Exception:
        return None


WINDOW_OPEN = ("Not done: a Qosha approval window is open on this computer, so Qosha may not click or type until the "
               "person answers it. Wait for their answer, then try again.")


def _surface_on() -> bool:
    """The trusted approval surface is on (engine_cards.py's own text next to this file); off: nothing here changes."""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "engine_cards.py"), encoding="utf-8") as fh:
            if (re.search(r"(?m)^ON = True\b", fh.read()) or _floor_marker()):
                return True
    except FileNotFoundError:
        return False
    except Exception:
        return True
    m = sys.modules.get(__name__.rsplit(".", 1)[0] + ".engine_cards") if "." in __name__ else None
    return bool(m is not None and getattr(m, "ON", False) is True)


def window_open() -> bool:
    """A Qosha approval window is open or waiting (any Qosha process): input pauses so Qosha can never press its own
    Allow (H6). Unknown = open (fail closed)."""
    if not _surface_on():
        return False
    try:
        td = _trusted_dialog()
        return bool(td and td.pending() > 0)          # no approval window in this build: nothing to wait for
    except Exception:
        return True


# H6: a terminal or code step that drives the screen by itself (synthetic clicks / keys) could press Qosha's own
# approval window, so with the trusted surface on it gets a card every time (independent programs stay MEDIUM)
_UI_AUTOMATION = re.compile(
    r"system events|\bkeystroke\b|\bkey code\b|\bcliclick\b|\bxdotool\b|\bydotool\b|sendkeys|sendwait|uiautomation"
    r"|automationelement|\bmouse_event\b|\bkeybd_event\b|\bsendinput\b|setcursorpos|pyautogui|\bpynput\b"
    r"|cgevent(?:create|post)|cgeventpost|cgpost(?:mouse|keyboard)event|\bnircmd\b|autohotkey|\.ahk\b|appactivate"
    r"|wscript\.shell|findwindow|enumchildwindows|enumwindows|\b(?:send|post)message[aw]?\s*\((?=[^)]*(?:0x0?0?f5|bm_|wm_))"
    r"|user32|\bbm_click\b|0x00f5\b"
    r"|wm_(?:lbutton|command|keydown|char)|pywinauto|win32gui|win32api|windows\.automation|invokepattern"
    r"|axuielement|kaxpress|axpress|performaction", re.I)
_UI_TOOLS = ("terminal", "execute_code", "shell", "bash", "run_command", "process", "tool_call",
             # writing a helper script that clicks or types is the first half of running it (TS-G-02)
             "write_file", "patch", "edit_file", "str_replace", "replace_in_file", "create_file")


# in a written file's content only call-shaped automation counts (a page may say "keystroke": TS-V-04)
_UI_CALLS = re.compile(
    r"pyautogui|\bpynput\b|cgevent(?:create|post)|cgeventpost|cgpost(?:mouse|keyboard)event|\bcliclick\b|\bxdotool\b"
    r"|\bydotool\b|sendkeys|sendwait|\bkeybd_event\b|\bmouse_event\b|\bsendinput\b|setcursorpos|user32|win32gui"
    r"|win32api|pywinauto|invokepattern|automationelement|axuielement|kaxpress|\bbm_click\b|0x00f5\b|findwindow"
    r"|enumchildwindows|\b(?:send|post)message[aw]?\s*\((?=[^)]*(?:0x0?0?f5|bm_|wm_))|wscript\.shell"
    r"|application\(\s*\\?[\"']system events\\?[\"']\s*\)|tell application \\?\"system events\\?\"|\bnircmd\b"
    r"|autohotkey", re.I)
_WRITE_TOOLS = ("write_file", "edit_file", "str_replace", "replace_in_file", "create_file", "patch")


def drives_screen(tool: str, args: Any) -> bool:
    """The step's own text drives the screen with synthetic input, or writes a script that does (judged on the text,
    like Qosha's other kinds; a tool_call batch is read whole)."""
    if str(tool or "").lower() not in _UI_TOOLS:
        return False
    if str(tool).lower() in ("write_file", "edit_file", "str_replace", "replace_in_file", "create_file") \
            and isinstance(args, dict):
        path = str(args.get("path") or args.get("file_path") or args.get("filepath") or "")
        pass                                          # no path exempts a write's content (TS-V-01)
    try:
        text = json.dumps(args, ensure_ascii=False, default=str) if not isinstance(args, str) else args
    except Exception:
        text = str(args)
    if str(tool).lower() in _WRITE_TOOLS:
        return bool(_UI_CALLS.search(text))
    return bool(_UI_AUTOMATION.search(text))


# ---- the decision ------------------------------------------------------------------------------------------------
def _refuse(why: str) -> Dict[str, Any]:
    return {"block": "Not done: " + why}


def _typed_add(have: Any, text: str) -> Dict[str, Any]:
    """Typing kept as cleaned text: its first 300 and last 300 characters and how many in between, so padding can
    never push the start of a message off the card (GPT r2 M-CU-6, Gemini r2 R2-1)."""
    h = have if isinstance(have, dict) else {"head": "", "tail": "", "skipped": 0}
    text = re.sub(r"\s+", " ", _UNSAFE_CHARS.sub(" ", str(text or "")))   # runs of spaces count as one
    prev = (h["tail"] or h["head"])
    if prev.endswith(" ") and text.startswith(" "):
        text = text[1:]
    if not prev and text.startswith(" "):
        text = text.lstrip(" ")
    whole = h["head"] + h["tail"] + text if not h["skipped"] else None
    if whole is not None and len(whole) <= 600:
        return {"head": whole, "tail": "", "skipped": 0}
    if whole is not None:
        return {"head": whole[:300], "tail": whole[-300:], "skipped": len(whole) - 600}
    t = h["tail"] + text
    return {"head": h["head"], "tail": t[-300:], "skipped": h["skipped"] + max(0, len(t) - 300)}


def _typed_view(text: Any) -> str:
    if isinstance(text, dict):
        if not text.get("skipped"):
            return clean((text.get("head") or "") + (text.get("tail") or ""), 700)
        return "%s … [%d characters not shown] … %s" % (clean(text["head"], 320), text["skipped"], clean(text["tail"], 320))
    t = clean(text, 100000)
    if len(t) <= 600:
        return t
    return "%s … [%d characters not shown] … %s" % (t[:280], len(t) - 560, t[-280:])


def _pending(st) -> bool:
    chk = st.get("checked")       # a card still open for a step on this same look at the window
    return bool(chk and not chk.get("ok") and chk.get("gen") == st.get("gen")
                and time.monotonic() - float(chk.get("t") or 0) < PENDING_MAX)


PENDING_MAX = 600.0          # seconds a card may wait before another desktop step may be judged


def whatsapp_linked() -> bool:
    """WhatsApp is linked to Qosha's own connection (<home>/whatsapp/session/creds.json). Fails closed: unreadable = linked."""
    try:
        os.stat(os.path.join(_home(), "whatsapp", "session", "creds.json"))
        return True
    except (FileNotFoundError, NotADirectoryError):
        return False                                  # confirmed absent
    except Exception:
        return True                                   # can't look (denied, ...): linked (GPT closure #5)


def _names_whatsapp(app: Any) -> bool:
    """WhatsApp by name: "WhatsApp", "WhatsApp Desktop", "net.whatsapp.WhatsApp", "5319275A.WhatsAppDesktop"..."""
    return "whatsapp" in _fold(str(app or "")).replace(" ", "")


def _whatsapp_read(a: Dict[str, Any], action: str, session_id: str, backend: Any) -> Optional[str]:
    """R7 (connectors, founder-approved): while WhatsApp is linked, no look at WhatsApp and no whole-screen look."""
    app = str(a.get("app") or "")
    if _names_whatsapp(app):
        return WHATSAPP_READ
    if a.get("pid") is not None:
        return WHATSAPP_READ if program_group(a.get("pid"))[0] in ("whatsapp", "unknown") else None
    if app:
        return None                                   # another app, by name
    if action == "list_windows":
        return None                                   # window titles only, no pictures
    if backend == "auto":
        backend = backend_for(session_id)
    pid = getattr(backend, "_active_pid", None) if backend is not None else None
    if not pid:
        return WHATSAPP_READ                          # no window picked: the whole screen
    return WHATSAPP_READ if program_group(pid)[0] in ("whatsapp", "unknown") else None


def _int(v: Any) -> Optional[int]:
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def r7_target(backend, target: Any) -> Optional[str]:
    """R7 where the backend picks the window (GPT closure #1/#2): while WhatsApp is linked, the window about to be
    looked at (or used) must be on screen, really owned by the pid given, and that program must be known and not
    WhatsApp. None = fine. Checked again whenever a capture resolves its window, follow-up captures included."""
    if not whatsapp_linked():
        return None
    try:
        pid, wid = _int((target or {}).get("pid")), _int((target or {}).get("window_id"))
        rows = backend.list_windows() if pid and wid else []
    except Exception:
        return WHATSAPP_READ
    owners = [w for w in rows if isinstance(w, dict) and _int(w.get("window_id")) == wid]
    if not pid or len(owners) != 1 or _int(owners[0].get("pid")) != pid:
        return WHATSAPP_READ
    if program_group(pid)[0] in ("whatsapp", "unknown"):
        return WHATSAPP_READ
    return None


UNCONFIRMED = ("Not done: Qosha couldn't confirm which window it was looking at (the first look came back empty), so it "
               "took no picture. Try the step again.")
PIXEL_TOOLS = frozenset({"get_window_state", "screenshot", "get_desktop_state", "zoom"})


def pixel_gate(backend, name: str, args: Any) -> None:
    """Right before the driver is asked for pixels (first try and every retry): Stop, then R7 on the window the
    request names (GPT closure-2 #2). Raises with the plain reason; returns when the request may go."""
    if name not in PIXEL_TOOLS:
        return
    if stopped():
        raise RuntimeError(STOPPED)
    if not whatsapp_linked():
        return
    a = args if isinstance(args, dict) else {}
    if name == "get_desktop_state":
        raise RuntimeError(WHATSAPP_READ)
    why = r7_target(backend, {"pid": a.get("pid") or getattr(backend, "_active_pid", None),
                              "window_id": a.get("window_id") or getattr(backend, "_active_window_id", None)})
    if why:
        raise RuntimeError(why)


def judge(args: Any, session_id: str = "", backend: Any = "auto") -> Dict[str, Any]:
    """{"run": True} | {"block": text} | {"kind", "rows", "once"} for one computer_use call. Records what it judged
    on the backend ("checked"), so `bind` lets exactly that step run once."""
    a = args if isinstance(args, dict) else {}
    action = str(a.get("action") or "").strip().lower()
    if not local_session():
        return {"block": LOCAL_ONLY}
    if stopped():
        return {"block": STOPPED}
    if action not in READS and window_open():
        return {"block": WINDOW_OPEN}
    if action not in READS and _names_whatsapp(a.get("app")):
        return {"block": WHATSAPP_TEXT}               # R6 even before a window resolves (focus_app app="WhatsApp"...)
    if action in ("capture", "list_windows") and whatsapp_linked():
        why = _whatsapp_read(a, action, session_id, backend)
        if why:
            return {"block": why}
    if action in READS:
        return {"run": True}
    if action not in CLICKS | KEYBOARD | {"scroll", "set_value", "focus_app", "drag"}:
        return _refuse("Qosha doesn't know the desktop step %r." % action[:40])
    if a.get("delivery_mode") not in (None, "", "background") or a.get("bring_to_front") or a.get("raise_window"):
        return _refuse("Qosha works in the background only: it doesn't bring windows to the front or take over the "
                       "keyboard focus. Leave delivery_mode, bring_to_front and raise_window unset.")
    if a.get("modifiers"):
        return _refuse("Qosha doesn't click with keys held down (they change what a click does). Click plainly.")
    if action == "drag":
        return _refuse("Qosha doesn't drag on your computer: it can't check where a drop lands (it may move, upload or "
                       "delete something). Use the app's menu or buttons, which Qosha can check.")
    if a.get("coordinate") or a.get("from_coordinate") or a.get("to_coordinate"):
        return _refuse("Qosha clicks and scrolls only on a numbered element from its last look at the window, so it "
                       "can check what it does. Take a capture with mode='som' and use element=N.")
    if backend == "auto":
        backend = backend_for(session_id)
    if action == "focus_app":                   # only picks the window later steps go to; they are judged then
        return {"run": True, "sig": ("focus_app",)} if backend is None else _checked(backend, ("focus_app",), {"run": True})
    if backend is None:
        return _refuse(REFUSE_TEXT["unknown"])
    with _LOCK:
        st = _state(backend)
        if _pending(st):
            return _refuse("another step on the computer is waiting for the person's answer on its card. Wait for it.")
        pid = getattr(backend, "_active_pid", None)
        target = (pid, getattr(backend, "_active_window_id", None))
        if st["target"] is not None and st["target"] != target:
            return _refuse(STALE[len("Not done: "):])
        if st.get("captured") != target or not pid:
            return _refuse("Qosha hasn't looked at this window yet. Take a capture of it first (action='capture').")
        group, path = program_group(pid)
        if group == "whatsapp":
            return {"block": WHATSAPP_TEXT}
        if group != "app":
            return _refuse(REFUSE_TEXT.get(group, REFUSE_TEXT["unknown"]))
        title = st["title"] or st.get("win_title")
        if _FILE_MANAGER.search(path.replace("\\", "/").lower()) and (_fold(title) in RUN_DIALOG_TITLES
                                                                     or clean(title, 40).lower() in RUN_DIALOG_TITLES):
            return _refuse(REFUSE_TEXT["launcher"])
        app = st["app"] or os.path.basename(path)
        rows = [("App", clean(app, 80)), ("Window", clean(title, 160) or "(no title)")]
        if action in CLICKS or action == "set_value" or (action == "scroll" and a.get("element") is not None):
            if a.get("element") is None:
                return _refuse("Qosha clicks only on a numbered element from its last look at the window. Take a "
                               "capture with mode='som' and use element=N.")
            try:
                idx = int(a.get("element"))
            except (TypeError, ValueError):
                return _refuse("the element number is not a number.")
            el = st["elements"].get(idx)
            if el is None:
                return _refuse("element %d wasn't in Qosha's last look at this window. Take a new capture and use "
                               "its numbers." % idx)
            if time.monotonic() - float(st.get("at") or 0) > SNAPSHOT_MAX_AGE:
                return _refuse("Qosha's last look at this window is more than a minute old. Take a new capture and "
                               "use its numbers.")
            # the driver can't prove which program owns an element: what may be another program's sheet, panel or
            # AutoFill is refused (GPT closure #3)
            if el.get("hosted"):
                return _refuse("that is inside a sheet, dialog or pop-up over the app's window, which can belong to "
                               "another program (passwords, AutoFill, file panels). Qosha doesn't click there. Ask "
                               "the person to do this step.")
            if _AUTOFILL.search(_fold(el["label"])):
                return _refuse("that is a password or AutoFill control. Those are only for the person: ask them to "
                               "do this step.")
            if el["pid"] and el["pid"] != pid:
                g2, _ = program_group(el["pid"])
                if g2 == "whatsapp":
                    return {"block": WHATSAPP_TEXT}
                if g2 != "app":
                    return _refuse(REFUSE_TEXT.get(g2, REFUSE_TEXT["unknown"]))
            role, label = el["role"], el["label"]
            shown = "%s \"%s\"" % (clean(role, 40) or "element", clean(label, 120))
            if action == "scroll":
                if _VALUE_CONTROL.search(role):
                    return _refuse("scrolling over that %s would change its value. Use action='set_value' on it, "
                                   "which Qosha can check." % clean(role, 40))
                return _checked(backend, ("scroll", idx, str(a.get("direction") or "down"), _amount(a)), {"run": True})
            if _SECURE.search(role) or (_SECRET_NAME.search(_fold(label)) and not (
                    not _EDITABLE.search(role) and _fold(label) in ("pin", "unpin", "pin to top", "fixar", "desafixar"))):
                return _refuse("that is a password field. Passwords are only for the person: ask them to type it.")
            if _LINK.search(role):
                return _refuse("Qosha doesn't click links in apps (a link in an email or chat can lead anywhere). To "
                               "open a web page, use Qosha's browser with its address.")
            if not _fold(label):
                return _refuse("that %s has no name Qosha can read, so it can't tell what it does. Ask the person "
                               "to press it, or use a named button or menu item." % (clean(role, 40) or "element"))
            editable = bool(_EDITABLE.search(role))
            text_field = editable and not _VALUE_CONTROL.search(role)   # a combo box is a choice: its value is judged
            if action == "set_value" and text_field and re.search(
                    r"[\x00-\x1f\x7f-\x9f\u200b-\u200f\u2028-\u202e\u2066-\u2069\ufeff]", str(a.get("value") or "")):
                return _refuse("Qosha fills a text field with plain text on one line (no line breaks or hidden "
                               "characters). Fill it again without them; press Enter separately (Qosha asks first).")
            if action == "double_click":
                return _refuse("Qosha doesn't double-click on your computer (in a file list it would open or run the "
                               "file, and Qosha can't check what a file runs). Ask the person to open it.")
            if _FILE_MANAGER.search(path.replace("\\", "/").lower()) and _OPENERS.search(_fold(label)):
                return _refuse("Qosha doesn't open or run files from the file manager (it can't check what a file "
                               "runs). Ask the person to open it, or open a document in its own app.")
            kinds = []
            # a text field's new value is text being written, not a button name: only its label is judged (its words
            # show on the Enter card instead); for choices (pop-ups, sliders) the chosen value is judged too
            for t in ((label,) if action != "set_value" or text_field else (label, str(a.get("value") or ""))):
                k = label_kind(t)
                if k and k not in kinds:
                    kinds.append(k)
            if "mixed" in kinds or len([k for k in kinds if k != "desktop.confirm"]) > 1:
                return _refuse("%s names more than one kind of step (for example send and delete), so one OK can't "
                               "cover it. Ask the person to press it." % shown)
            kinds = [k for k in kinds if k != "desktop.confirm"] or kinds
            kind = kinds[0] if kinds else None
            sig = (action, idx, str(a.get("value")) if action == "set_value" else None)
            if kind is None or action == "right_click":
                if action == "set_value" and text_field:
                    return _checked(backend, sig, {"run": True}, label=label, role=role,
                                    typed=str(a.get("value") or ""))
                return _checked(backend, sig, {"run": True}, label=label, role=role,
                                focus_ok=editable and action == "click")
            rows.append(("Button" if action != "set_value" else "Choice", shown))
            if action == "set_value":
                rows.append(("Sets it to", clean(a.get("value"), 200)))
            if kind in ("desktop.send", "desktop.share", "desktop.delete", "desktop.pay"):
                if st.get("last_click"):
                    rows.append(("Clicked before this", clean(st["last_click"], 160)))
                rows.append(("Note", "Qosha can't read exactly what this sends, shares, deletes or pays. Look at the "
                                     "app window before you allow it."))
            return _checked(backend, sig, {"kind": kind, "rows": rows, "once": kind in ONCE_ONLY}, label=label,
                            role=role)
        if action == "scroll":
            return _checked(backend, ("scroll", None, str(a.get("direction") or "down"), _amount(a)), {"run": True})
        # keyboard: only into a text field Qosha clicked (and the click went through), on a recent look
        if time.monotonic() - float(st.get("at") or 0) > SNAPSHOT_MAX_AGE:
            return _refuse("Qosha's last look at this window is more than a minute old. Take a new capture first "
                           "(action='capture'), then type or press the key.")
        focus = st["focus"]
        if focus is not None and focus.get("inputs") != _INPUTS[0]:
            focus = st["focus"] = None            # any other input since this chat's last one: focus unknown
        if action == "type":
            text = str(a.get("text") or "")
            if re.search(r"[\t\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]", text):
                return _refuse("Qosha types plain text only (no Tab or control characters): press Tab on its own "
                               "with action='key', then click the next field.")
            if focus is None:
                return _refuse("Qosha types only into a text field it has clicked (by element number) in this "
                               "window, so it knows where the typing goes. Click the field first.")
            sig = ("type", text)
            if re.search(r"[\r\n  \x85]", text):
                rows += [("Field", clean(focus["label"], 120) or "(text field)"),
                         ("Typed", _typed_view(_typed_add(st["typed"], text)) or "(nothing)")]
                return _checked(backend, sig, {"kind": "desktop.enter", "rows": rows, "once": True}, typed=text,
                                clear_focus=True)
            return _checked(backend, sig, {"run": True}, typed=text)
        keys = str(a.get("keys") or "")
        mods, main = parse_keys(keys)
        sig = ("key", tuple(sorted(mods)), main)
        if not main:
            return _refuse("Qosha could not read the key %r (one key, with cmd, ctrl, alt or shift)." % keys[:40])
        if main in _ENTER:
            filled = st.get("filled") if not focus else None
            rows += [("Field", clean((focus or {}).get("label"), 120) or "(none: Enter goes to whatever is selected)"),
                     ("Typed", _typed_view(st["typed"]) if focus else "(Qosha typed nothing here)")]
            if filled:
                rows.append(("Qosha filled", "%s: %s" % (clean(filled["label"], 80) or "a text field",
                                                         _typed_view(filled["typed"]))))
            return _checked(backend, sig, {"kind": "desktop.enter", "rows": rows, "once": True}, clear_focus=True)
        plain = not (mods - {"shift"})
        combo = (sorted(mods - {"shift"})[0] if len(mods - {"shift"}) == 1 and "shift" not in mods else "", main)
        if main in _DELETE_KEYS:
            return _refuse("Qosha doesn't press Delete or Backspace (with a message or file selected they delete it). "
                           "To change text, select it (cmd/ctrl+a) and type the new text, or use set_value.")
        if focus is not None and ((plain and main in _EDIT_KEYS) or combo in _EDIT_COMBOS):
            return _checked(backend, sig, {"run": True})
        if plain and main in _NAV_ANYWHERE:
            return _checked(backend, sig, {"run": True}, clear_focus=main in _CLEARS_FOCUS)
        return _refuse("Qosha presses only editing keys in a text field it clicked, arrow/Tab/Escape keys, and Enter "
                       "(after your OK). For anything else, use the app's menu or buttons, which Qosha can check.")


RUN_DIALOG_TITLES = {"run", "executar", "ejecutar", "ausfuhren", "executer", "esegui", "uitvoeren", "uruchamianie",
                     "kor", "suorita", "spustit", "futtatas", "calistir", "chay", "jalankan", "実行",
                     "运行", "執行", "실행", "выполнить"}


def _amount(a: Dict[str, Any]) -> int:
    try:
        return max(1, min(50, int(a.get("amount", 3))))
    except (TypeError, ValueError):
        return 3


def _checked(backend, sig, verdict, focus_ok=False, typed=None, clear_focus=False, label="", role="") -> Dict[str, Any]:
    """Record exactly what was judged (snapshot generation, target, the step) so `bind` lets only that step run, once.
    A step that needs the person's card runs only after `allowed` for that same step."""
    st = _state(backend)
    st["checked"] = {"gen": st["gen"], "sig": sig, "focus_ok": focus_ok, "typed": typed, "clear_focus": clear_focus,
                     "ok": bool(verdict.get("run")), "label": label, "role": role, "t": time.monotonic(),
                     "target": st.get("target"), "at": st.get("at"), "inputs": _INPUTS[0]}
    return dict(verdict, sig=sig, gen=st["gen"])


def allowed(backend, yes: bool, sig: Any = None, gen: Any = None) -> None:
    """The person's answer to Qosha's card, for exactly the step `sig` judged on look `gen` (another card's answer,
    even for the same element number on a newer look, never counts; GPT r2 M-CU-8, Gemini r2 G-CU-3)."""
    with _LOCK:
        st = _state(backend)
        chk = st.get("checked")
        if not chk or chk.get("sig") != sig or chk.get("gen") != gen:
            return
        if yes:
            chk["ok"] = True
        else:
            st["checked"] = None


# ---- binding at the moment the driver acts ------------------------------------------------------------------------
_DRIVER_INPUT = {"click": "click", "double_click": "click", "type_text": "type", "press_key": "key", "hotkey": "key",
                 "scroll": "scroll", "set_value": "set_value", "drag": "drag"}
STALE = ("Not done: the window changed after Qosha checked this step (a newer capture, or another window), or Qosha "
         "never checked it. Nothing was clicked or typed. Take a capture and try the step again.")


_ALIAS = {"command": "cmd", "control": "ctrl", "alt": "alt", "option": "alt", "opt": "alt"}


def _norm_keys(keys) -> frozenset:
    return frozenset(_ALIAS.get(str(k).lower(), str(k).lower()) for k in keys)


def admit(backend, driver_name: str, driver_args: Dict[str, Any]) -> Optional[str]:
    """None when this driver call is exactly the step Qosha judged on this snapshot and target (consumed: it runs
    once); else why not."""
    fam = _DRIVER_INPUT.get(driver_name)
    if fam is None:
        return None                                   # session setup, focus, reads: not input
    with _LOCK:
        st = _state(backend)
        chk, st["checked"] = st.get("checked"), None
        if stopped():
            return STOPPED
        if window_open():
            return WINDOW_OPEN
        if not chk or chk["gen"] != st["gen"] or not chk.get("ok"):
            return STALE
        target = (getattr(backend, "_active_pid", None), getattr(backend, "_active_window_id", None))
        if chk.get("target") != target or driver_args.get("pid") not in (None, target[0]) or \
                driver_args.get("window_id") not in (None, target[1]):
            return STALE
        if "delivery_mode" in driver_args or "modifier" in driver_args or "x" in driver_args or "y" in driver_args:
            return STALE
        if time.monotonic() - float(st.get("at") or 0) > SNAPSHOT_MAX_AGE:
            return STALE
        if fam in ("key", "type") and chk.get("inputs") != _INPUTS[0]:
            return STALE               # any input since this was judged (any conversation) may have moved focus
        sig = chk["sig"]
        ok = False
        if fam == "click" and sig[0] in CLICKS:
            want = {"right_click": "right", "middle_click": "middle"}.get(sig[0], "left")
            ok = (driver_args.get("element_index") == sig[1] and str(driver_args.get("button") or "left") == want
                  and (driver_name == "double_click") == (sig[0] == "double_click"))
            ok = ok and time.monotonic() - float(st.get("at") or 0) <= SNAPSHOT_MAX_AGE
        elif fam == "set_value" and sig[0] == "set_value":
            ok = driver_args.get("element_index") == sig[1] and str(driver_args.get("value")) == sig[2]
            ok = ok and time.monotonic() - float(st.get("at") or 0) <= SNAPSHOT_MAX_AGE
        elif fam == "type" and sig[0] == "type":
            ok = driver_args.get("text") == sig[1]
        elif fam == "key" and sig[0] == "key":
            mods, main = frozenset(sig[1]), sig[2]
            if driver_name == "press_key":
                ok = not mods and str(driver_args.get("key") or "").lower() == main
            else:
                ok = bool(mods) and _norm_keys(driver_args.get("keys") or []) == _norm_keys(list(mods) + [main])
        elif fam == "scroll" and sig[0] == "scroll":
            ok = (driver_args.get("element_index") == sig[1] and str(driver_args.get("direction")) == sig[2]
                  and int(driver_args.get("amount") or 0) == sig[3])
        if not ok:
            return STALE
        if fam == "click":
            st["last_click"] = chk.get("label") or ""
            st["focus"], st["typed"] = None, ""       # set again only once the click went through (delivered)
            st["pending_focus"] = {"label": chk.get("label") or "", "role": chk.get("role") or "",
                                   "index": sig[1]} if chk.get("focus_ok") else None
        if chk.get("clear_focus") or fam == "set_value":
            st["focus"], st["typed"] = None, ""
        st["filled"] = None if fam == "set_value" else st.get("filled")
        if fam == "set_value" and chk.get("typed") is not None and _EDITABLE.search(chk.get("role") or ""):
            # shown on the Enter card only once the driver confirms the fill landed (GPT f5)
            st["pending_fill"] = {"label": chk.get("label") or "", "typed": _typed_add(None, chk["typed"])}
            chk = dict(chk, typed=None)
        if chk.get("typed"):
            st["typed"] = _typed_add(st["typed"], chk["typed"])
        if fam not in ("key", "type"):
            st["focus"] = None if fam != "click" else st["focus"]     # scroll / set_value: click the field again
        st["gen"] += 1                 # the window may have changed: the next click needs a new look (council R5)
        st["elements"] = {}
        _INPUTS[0] += 1                # every conversation's text-field focus is unknown after this input ...
        if st["focus"] is not None:
            st["focus"]["inputs"] = _INPUTS[0]    # ... except this chat's own field, which it is typing into
        return None


_INPUTS = [0]                      # inputs admitted on this computer, every conversation (GPT focused pass)
_DISPATCH = threading.RLock()      # admission and the driver's delivery happen as one step, one at a time


def delivered(backend, driver_name: str, ok: bool) -> None:
    """After the driver answered: a text field counts as focused only if the click on it went through (GPT CU-7)."""
    with _LOCK:
        st = _state(backend)
        pf = st.pop("pending_focus", None)
        _INPUTS[0] += 1                  # bumped again once delivered: a step judged meanwhile is stale (Gemini f3 B)
        if st["focus"] is not None:
            st["focus"]["inputs"] = _INPUTS[0]
        fill = st.pop("pending_fill", None)
        if _DRIVER_INPUT.get(driver_name) == "set_value":
            st["filled"] = fill if ok else None
        if _DRIVER_INPUT.get(driver_name) == "click" and ok and pf:
            st["focus"], st["typed"] = dict(pf, inputs=_INPUTS[0]), ""


def bind() -> bool:
    """Wrap the engine's cua-driver backend once: captures and target changes are noted, and every input call must be
    the step Qosha judged. True when in place."""
    try:
        from tools.computer_use.cua_backend import CuaDriverBackend as B
    except Exception:
        return False
    if getattr(B, "_qosha_bound", False):
        return True
    cap0, focus0, clear0, action0 = B.capture, B.focus_app, B._clear_active_target, B._action
    set0, full0 = B._set_active_target, B._capture_full_screen
    try:      # keep an element's owner pid when the driver sends one (the engine's parser drops it; GPT closure #3)
        from tools.computer_use import cua_backend_capture as C
        parse0 = C._parse_elements_from_structured

        def _parse(raw, *a, **k):
            out = parse0(raw, *a, **k)
            by = {r.get("element_index"): r for r in (raw or []) if isinstance(r, dict)}
            for e in out:
                r = by.get(getattr(e, "index", None)) or {}
                for key in ("pid", "owner_pid", "process_id"):
                    if isinstance(r.get(key), int) and r[key] > 0:
                        e.pid = r[key]
                        break
            return out
        C._parse_elements_from_structured = _parse
    except Exception:
        pass

    pixel0, cli0, call0 = B._call_capture_tool, B._cli_refetch, B.call_tool

    def _call_capture_tool(self, name, args, *a, **k):
        pixel_gate(self, str(name), args)
        return pixel0(self, name, args, *a, **k)

    def _cli_refetch(self, name, args, *a, **k):
        if str(name) in PIXEL_TOOLS:               # an empty or failed look is never retried into a capture
            raise RuntimeError(UNCONFIRMED)        # (GPT closure-2 #2; orchestrator: refuse first)
        return cli0(self, name, args, *a, **k)

    def call_tool(self, name, args=None, *a, **k):
        pixel_gate(self, str(name), args)
        return call0(self, name, args, *a, **k)

    try:      # the driver session's own retries (a transport hiccup -> CLI; a closed session -> replay) never send a
        #       second pixel request after the gated one (GPT closure-3 #2; orchestrator: refuse first)
        from tools.computer_use import cua_backend_session as CS
        S = CS._CuaDriverSession
        if not getattr(S, "_qosha_bound", False):
            s_call0, s_async0, s_cli0 = S.call_tool, S._call_tool_async, S._call_tool_via_cli

            def s_call(self, name, args, *a, **k):
                if str(name) not in PIXEL_TOOLS:
                    return s_call0(self, name, args, *a, **k)
                self._qosha_pixel_budget = 1
                try:
                    return s_call0(self, name, args, *a, **k)
                finally:
                    self._qosha_pixel_budget = None

            def s_async(self, name, args, *a, **k):      # builds the request (in the caller's thread)
                if str(name) in PIXEL_TOOLS and getattr(self, "_qosha_pixel_budget", None) is not None:
                    if self._qosha_pixel_budget <= 0:
                        raise RuntimeError(UNCONFIRMED)
                    self._qosha_pixel_budget -= 1
                return s_async0(self, name, args, *a, **k)

            def s_cli(self, name, args, *a, **k):
                if str(name) in PIXEL_TOOLS:
                    raise RuntimeError(UNCONFIRMED)
                return s_cli0(self, name, args, *a, **k)
            S.call_tool, S._call_tool_async, S._call_tool_via_cli = s_call, s_async, s_cli
            S._qosha_bound = True
    except Exception:
        return False                                  # not bound: Qosha's desktop tools stay off (fail closed)

    def _capture_full_screen(self, *a, **k):
        if whatsapp_linked():
            raise RuntimeError(WHATSAPP_READ)     # the whole screen can show WhatsApp (R7, at the capture itself)
        return full0(self, *a, **k)

    def _set_active_target(self, target, *a, **k):
        why = r7_target(self, target)
        if why:
            raise RuntimeError(why)               # before the window is used or any pixel is taken
        r = set0(self, target, *a, **k)
        try:
            note_window(self, target)
        except Exception:
            pass
        return r

    def capture(self, *a, **k):
        if stopped():
            raise RuntimeError(STOPPED)    # the person's Stop holds even for a look (GPT CU-11)
        try:
            cap = cap0(self, *a, **k)
        except BaseException:
            note_target(self)              # the target may have moved before the failure: forget what Qosha saw
            raise
        if stopped():
            note_target(self)
            raise RuntimeError(STOPPED)    # Stop pressed while Qosha was looking: the picture is not used
        if whatsapp_linked() and (str(getattr(cap, "app", "") or "") == "screen" or r7_target(self, {
                "pid": getattr(self, "_active_pid", None), "window_id": getattr(self, "_active_window_id", None)})):
            note_target(self)
            raise RuntimeError(WHATSAPP_READ)   # linked while Qosha was looking: the picture is not used
        try:
            note_capture(self, cap)
        except Exception:
            note_target(self)
        return cap

    def focus_app(self, *a, **k):
        try:
            return focus0(self, *a, **k)
        finally:
            note_target(self)

    def _clear_active_target(self, *a, **k):
        r = clear0(self, *a, **k)
        try:
            note_target(self)
        except Exception:
            pass
        return r

    def _action(self, name, args, *a, **k):
        if str(name) not in _DRIVER_INPUT:      # session setup, focus, reads: not input, no lock (Gemini f3)
            pixel_gate(self, str(name), args)
            return action0(self, name, args, *a, **k)
        with _DISPATCH:           # no other conversation's input can land between this check and this delivery
            screen = _hold_screen()   # the approval window's own lock, held through the delivery (TS-G-03)
            if screen is None:
                from tools.computer_use.backend import ActionResult
                return ActionResult(ok=False, action=str(name), message=WINDOW_OPEN)
            try:
                try:
                    why = admit(self, str(name), dict(args or {}))
                except Exception:
                    why = STALE
                if why:
                    from tools.computer_use.backend import ActionResult
                    return ActionResult(ok=False, action=str(name), message=why)
                res, ok = None, False
                try:
                    res = action0(self, name, args, *a, **k)
                    effect = str(getattr(res, "effect", "") or "").lower()   # not a suspected no-op (GPT r2 M-CU-2)
                    ok = bool(getattr(res, "ok", False)) and "noop" not in effect and effect not in ("none", "no_effect")
                    return res
                finally:
                    try:
                        delivered(self, str(name), ok)
                    except Exception:
                        pass
            finally:
                screen.release()

    B.capture, B.focus_app, B._clear_active_target, B._action = capture, focus_app, _clear_active_target, _action
    B._set_active_target, B._capture_full_screen = _set_active_target, _capture_full_screen
    B._call_capture_tool, B._cli_refetch, B.call_tool = _call_capture_tool, _cli_refetch, call_tool
    B._qosha_bound = True
    return True


def bound() -> bool:
    try:
        from tools.computer_use.cua_backend import CuaDriverBackend as B
        return bool(getattr(B, "_qosha_bound", False))
    except Exception:
        return False


def activity_path() -> str:
    return os.path.join(_home(), "qosha", "desktop-activity.json")


def note_activity(args: Any, backend, verdict: Dict[str, Any]) -> None:
    """For the bar on Qosha's pages ("Qosha is using your computer", Stop): when, which app, what step. Never raises."""
    try:
        a = args if isinstance(args, dict) else {}
        st = _state(backend) if backend is not None else {}
        rec = {"at": time.time(), "action": clean(a.get("action"), 30), "app": clean(st.get("app") or a.get("app"), 80),
               "result": "refused" if "block" in verdict else "asks" if "kind" in verdict else "runs"}
        p = activity_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = "%s.%d.%d.tmp" % (p, os.getpid(), threading.get_ident())
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(rec, fh)
        os.replace(tmp, p)
    except Exception:
        pass


def engine_keys(args: Any) -> List[str]:
    """The engine's own approval keys this call asks for (tool.py _request_approval): Qosha grants exactly these
    once it has decided, so the engine's technical card never shows."""
    a = args if isinstance(args, dict) else {}
    action = str(a.get("action") or "").strip().lower()
    try:
        from tools.computer_use import tool as cu
        spec = cu._ACTIONS.get(action)
        if spec is None or not spec.destructive:
            return []
    except Exception:
        return []
    if a.get("delivery_mode") not in (None, "", "background") or a.get("bring_to_front") or a.get("raise_window"):
        return []                       # refused by judge; never granted (Gemini CU-5)
    return ["cua:%s:background" % action]
