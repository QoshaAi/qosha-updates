"""Qosha's wording in the person's language (contract qosha-ptbr §2.B.4).

tr(key, **kw) -> the text of `key` in the language of the engine's own setting `display.language` (config.yaml), with
{name} placeholders filled from kw. The stored setting decides (also over a HERMES_LANGUAGE in the environment, ptb7
S1); only when config.yaml holds none does the engine's own answer (agent.i18n.get_language()) decide. The engine's
"pt" alias and Qosha's "pt-br" both give Brazilian Portuguese; anything else gives English.
A key missing in a language falls back to English, then to the key itself. tr() never raises.

The texts live in qosha_guard/locales/{en,pt-br}.json (flat {"key": "text"} objects), next to this file, so the
updater's keep_edits keeps the person's own edits to them (contract §2.D.2).
"""
from __future__ import annotations

import json
import os
import re
import threading
from pathlib import Path

LANGS = ("en", "pt-br")
_DIR = Path(__file__).resolve().parent / "locales"
_lock = threading.Lock()
_cache: dict = {}          # lang -> (mtime_ns, {key: text})
_cfg_cache: dict = {}      # path -> (mtime_ns, value)


def normalize(value) -> str:
    """'pt', 'pt-br', 'pt_BR', 'Português (Brasil)' -> 'pt-br'; 'en', 'en-US' -> 'en'; anything else -> ''."""
    v = str(value or "").strip().lower().replace("_", "-")
    if not v:
        return ""
    if v.startswith("pt") or v.startswith("portugu"):
        return "pt-br"
    if v.startswith("en"):
        return "en"
    return ""


def _home() -> Path:
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path(os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes"))


def _homes() -> list:
    """The engine homes whose config.yaml may hold the setting, in order: the process's HERMES_HOME (what the engine's
    own config loader reads), then the engine's resolved home (its override, when one is set). In a normal install
    both are the same folder."""
    out = []
    env = (os.environ.get("HERMES_HOME") or "").strip()
    for h in ([Path(os.path.expanduser(env))] if env else []) + [_home()]:
        if h not in out:
            out.append(h)
    return out


_LANG_LINE = re.compile(r"language[ \t]*:[ \t]*['\"]?([A-Za-z_-]+)")
_LANG_INLINE = re.compile(r"(?:\{|,)[ \t]*language[ \t]*:[ \t]*['\"]?([A-Za-z_-]+)")


def display_language_text(text: str) -> str:
    """display.language read the plain way, one line at a time (no regular expression runs over the file: the old
    multi-line pattern backtracked exponentially on a display block with no language line, 23 Nov 2026). Only the
    top-level "display:" block counts, and only its first-level "language:" line; "display: {language: pt-br}" too.
    '' when unset."""
    inside, indent = False, None
    for raw in (text or "").splitlines():
        line = raw.rstrip("\r")
        if not inside:
            if not line.startswith("display"):
                continue
            head = line[len("display"):].lstrip(" \t")
            if not head.startswith(":"):
                continue
            rest = head[1:].strip()
            if rest.startswith("{"):
                m = _LANG_INLINE.search(rest)
                return m.group(1) if m else ""
            if rest and not rest.startswith("#"):
                return ""                              # display: <a value>, not a block
            inside = True
            continue
        body = line.strip()
        if not body or body.startswith("#"):
            continue
        if line[0] not in " \t":
            return ""                                  # the display block ended without a language line
        lead = line[:len(line) - len(line.lstrip(" \t"))]
        if indent is None:
            indent = lead
        if lead != indent:
            continue                                   # deeper: something nested inside the display block
        m = _LANG_LINE.match(body)
        if m:
            return m.group(1)
    return ""


def _display_language_yaml(text: str):
    """display.language through a YAML library (PyYAML, else the engine's ruamel.yaml); None when neither can read it."""
    data = None
    try:
        import yaml
        data = yaml.safe_load(text) or {}
    except Exception:
        try:
            from ruamel.yaml import YAML
            data = YAML(typ="safe", pure=True).load(text) or {}
        except Exception:
            return None
    disp = data.get("display") if isinstance(data, dict) else None
    if isinstance(disp, dict) and disp.get("language") is not None:
        return str(disp.get("language")).strip()
    return ""


def configured(home=None) -> str:
    """display.language exactly as config.yaml holds it ('' when unset). Read again whenever the file changes, so a
    switch made by another process (Settings, the chat) applies at once. With no home given: the first home of
    _homes() that holds a setting."""
    if home is None:
        for h in _homes():
            v = configured(h)
            if v:
                return v
        return ""
    p = Path(home) / "config.yaml"
    try:
        st = p.stat()
    except OSError:
        return ""
    stamp = (st.st_mtime_ns, st.st_size, getattr(st, "st_ino", 0))
    hit = _cfg_cache.get(str(p))
    if hit and hit[0] == stamp:
        return hit[1]
    val = ""
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
        val = _display_language_yaml(text)
        if val is None:
            val = display_language_text(text)
    except Exception:
        val = ""
    _cfg_cache[str(p)] = (stamp, val)
    return val


_eng_seen: dict = {}       # "stamp": the config files as the engine's language was last asked


def _config_stamp() -> tuple:
    out = [os.environ.get("HERMES_HOME") or "", os.environ.get("HERMES_LANGUAGE") or ""]
    for h in _homes():
        try:
            st = (Path(h) / "config.yaml").stat()
            out.append((str(h), st.st_mtime_ns, st.st_size))
        except OSError:
            out.append((str(h), None, None))
    return tuple(out)


def _engine_language() -> str:
    """The engine's own answer (agent.i18n.get_language). The engine keeps its answer for the whole run; when
    config.yaml changed since it was last asked (Settings, the chat, another process), it is told to read the setting
    again first, so a language that was switched or taken out never lingers. '' when there is no engine here."""
    try:
        import agent.i18n as ai
    except Exception:
        return ""
    try:
        stamp = _config_stamp()
        if _eng_seen.get("stamp") != stamp:
            _eng_seen["stamp"] = stamp
            reset = getattr(ai, "reset_language_cache", None)
            if callable(reset):
                reset()
    except Exception:
        pass
    try:
        return str(ai.get_language() or "")
    except Exception:
        return ""


def language() -> str:
    """'en' or 'pt-br'. The one stored setting, display.language in config.yaml, wins (21 Nov 2026, ptb7 S1: a process
    started with HERMES_LANGUAGE in its environment must not make Qosha's messages, its reply instruction or its
    speech disagree with what Settings shows). Only when config.yaml holds no language: the environment, then the
    engine's own answer (get_language: its aliases and defaults)."""
    stored = normalize(configured())
    if stored:
        return stored
    for v in (os.environ.get("HERMES_LANGUAGE") or "", _engine_language()):
        n = normalize(v)
        if n:
            return n
    return "en"


def speech_language() -> str:
    """The language code a speech recogniser is asked for: 'pt' while Qosha is in pt-BR, else 'en'."""
    return "pt" if language() == "pt-br" else "en"


def replace_config_text(path, text: str) -> None:
    """Writes config.yaml's new text in one step (temp file, then replace) and never loosens it: the file keeps the
    permission bits it had (0600 stays 0600), and a new file is made owner-only (21 Nov 2026, ptb7 S2)."""
    p = Path(path)
    try:
        mode = p.stat().st_mode & 0o777
    except OSError:
        mode = 0o600
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(".config.yaml.qosha-lang-%d.tmp" % os.getpid())
    fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        try:
            os.chmod(str(tmp), mode)                  # the umask never widens or narrows what the file had
        except OSError:
            pass
        os.replace(str(tmp), str(p))
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise


def with_display_language(text: str, lang: str) -> str:
    """config.yaml's text with display.language set to `lang` and every other line as it was. Used only where no YAML
    library can be loaded: it reads the file the plain way (a top-level "display:" block, or none)."""
    text = text or ""
    nl = "\r\n" if "\r\n" in text else "\n"
    lines = text.splitlines(keepends=True)
    for i, raw in enumerate(lines):
        m = re.match(r"^display[ \t]*:[ \t]*(.*?)[ \t]*(?:#.*)?$", raw.rstrip("\r\n"))
        if not m:
            continue
        if not raw.endswith(("\n", "\r")):
            lines[i] = raw = raw + nl
        inline = m.group(1)
        indent, j = None, i + 1
        while j < len(lines):
            body = lines[j].rstrip("\r\n")
            if not body.strip() or body.lstrip().startswith("#"):
                j += 1
                continue
            if body[0] not in " \t":
                break
            lead = body[:len(body) - len(body.lstrip())]
            if indent is None:
                indent = lead
            if lead == indent and re.match(r"^language[ \t]*:", body.lstrip()):
                lines[j] = "%slanguage: %s%s" % (indent, lang, nl)
                return "".join(lines)
            j += 1
        if indent is not None or inline in ("", "{}", "null", "~"):
            if inline:                                # "display: {}" or "display: null": it becomes a block
                lines[i] = "display:" + nl
            lines.insert(i + 1, "%slanguage: %s%s" % (indent or "  ", lang, nl))
            return "".join(lines)
        fm = re.fullmatch(r"\{(.*)\}", inline)
        if fm:                                        # display: {a: 1}
            inner = re.sub(r"(?:^|,)\s*language\s*:\s*[^,]*", "", fm.group(1)).strip().strip(",").strip()
            lines[i] = "display: {%s%slanguage: %s}%s" % (inner, ", " if inner else "", lang, nl)
            return "".join(lines)
        raise ValueError("display is not a block in config.yaml")
    if text and not text.endswith(("\n", "\r")):
        text += nl
    return "%sdisplay:%s  language: %s%s" % (text, nl, lang, nl)


def set_language(lang) -> str:
    """Writes the one stored language, the engine's display.language in config.yaml, the way the engine does (its own
    config call; the file itself only if that is not available), keeping every other setting. Returns the language now
    in force. Raises ValueError for anything but English or Brazilian Portuguese."""
    n = normalize(lang)
    if n not in LANGS:
        raise ValueError("language must be one of: en, pt-br")
    done = False
    try:
        from hermes_cli.config import load_config, save_config
        cfg = load_config()
        if isinstance(cfg, dict):
            disp = cfg.get("display") if isinstance(cfg.get("display"), dict) else {}
            cfg["display"] = dict(disp, language=n)
            save_config(cfg)
            _cfg_cache.clear()
            # stored explicitly, English too (the engine's writer may leave its default out): the choice is kept even
            # where the environment says otherwise; the writer below keeps the file's permissions
            done = normalize(configured(_home())) == n
    except Exception:
        done = False
    if not done:
        p = _home() / "config.yaml"
        old = p.read_text(encoding="utf-8") if p.exists() else ""
        try:
            import yaml                               # the engine's own dependency
            data = yaml.safe_load(old) if old.strip() else {}
            data = data if isinstance(data, dict) else {}
            disp = data.get("display") if isinstance(data.get("display"), dict) else {}
            data["display"] = dict(disp, language=n)
            new = yaml.safe_dump(data, sort_keys=False, allow_unicode=True)
        except ImportError:                           # no YAML library in this process: only that one line is written
            new = with_display_language(old, n)
        replace_config_text(p, new)
    _cfg_cache.clear()
    try:
        import agent.i18n as ai
        ai.reset_language_cache()
    except Exception:
        pass
    return language()


# The chat: the person asks Qosha to speak another language ("fale comigo em português", "switch to English"). It is
# their own display setting, not a send, so no approval card is shown (contract qosha-ptbr §2.B.1).
LANGUAGE_TOOL_SCHEMA = {
    "name": "qosha_language",
    "description": ("The language of Qosha's screens, of its notices and of its answers, stored once for this computer. "
                    "action=get: the language now. action=set with language \"pt-br\" (Brazilian Portuguese) or \"en\" "
                    "(English): use it when the person asks Qosha to use another language with them, for example "
                    "\"fale comigo em português\" or \"switch to English\". It is the person's own display setting: no "
                    "approval is needed. Afterwards answer in the new language, and tell them that Qosha's screens "
                    "follow after a page reload."),
    "parameters": {"type": "object", "properties": {
        "action": {"type": "string", "enum": ["get", "set"]},
        "language": {"type": "string", "enum": list(LANGS)}}, "required": ["action"]},
}


def language_tool(args, **_kw) -> str:
    a = args if isinstance(args, dict) else {}
    try:
        if str(a.get("action") or "get").lower() == "set":
            now = set_language(a.get("language"))
            return json.dumps({"success": True, "language": now,
                               "result": tr_lang(now, "language.set", name=tr_lang(now, "language.name." + now))})
        now = language()
        return json.dumps({"success": True, "language": now, "name": tr_lang(now, "language.name." + now)})
    except ValueError as exc:
        return json.dumps({"success": False, "error": str(exc)})
    except Exception as exc:
        return json.dumps({"success": False, "error": "the language could not be saved (%s)" % type(exc).__name__})


def register_tool(ctx) -> None:
    ctx.register_tool(name="qosha_language", toolset="qosha", schema=LANGUAGE_TOOL_SCHEMA, handler=language_tool,
                      check_fn=lambda: True, description=LANGUAGE_TOOL_SCHEMA["description"], emoji="🌐")


# 25 Nov 2026 (ptbr-cards, GPT review r1 H1): the catalog texts added after 1.20.44 for the approval card (the Google
# tool's plain words, row labels, kinds, Drive sentences). Inside baseline() they are hidden, so the guard can count a
# card exactly as 1.20.44 showed it: its size limit (ask.CARD_SHOWS) never refuses a card 1.20.44 offered because its
# words got longer in this release. What the person sees is still the full card in their language.
_ADDED_PREFIXES = ("ask.google.tool.", "ask.google.op.", "ask.google.role.", "ask.say.gdrive.")
_ADDED_KEYS = frozenset(["ask.row." + x for x in (
    "Operation", "File id", "Name", "New name", "To folder id", "To folder name", "Document id", "Title", "Text", "Rows",
    "Sheet", "Spreadsheet id", "Message id", "Summary", "Start", "End", "Location", "Description", "Attendees",
    "Calendar id", "Event id", "Role")] + ["ask.kind." + x for x in (
    "calendar.invite", "whatsapp.read", "whatsapp.send", "screen.read", "dropbox.change", "file.organize", "file.edit",
    "mail.tidy", "unclear")])
_base = threading.local()
_base_cache: dict = {}     # lang -> (the full catalog, the catalog without the added texts)


class baseline:
    """with baseline(): tr(), say() and the card's templates use the catalogs without the texts added after 1.20.44."""

    def __enter__(self):
        self._prev = getattr(_base, "on", False)
        _base.on = True
        return self

    def __exit__(self, *exc):
        _base.on = self._prev
        return False


def _baselining() -> bool:
    return bool(getattr(_base, "on", False))


def catalog(lang: str) -> dict:
    lang = lang if lang in LANGS else "en"
    d = _catalog_full(lang)
    if not _baselining():
        return d
    with _lock:
        hit = _base_cache.get(lang)
        if hit is None or hit[0] is not d:     # made again only when the full catalog was read again
            hit = (d, {k: v for k, v in d.items() if not (k.startswith(_ADDED_PREFIXES) or k in _ADDED_KEYS)})
            _base_cache[lang] = hit
        return hit[1]


def _catalog_full(lang: str) -> dict:
    lang = lang if lang in LANGS else "en"
    p = _DIR / (lang + ".json")
    try:
        mt = p.stat().st_mtime_ns
    except OSError:
        return {}
    with _lock:
        hit = _cache.get(lang)
        if hit and hit[0] == mt:
            return hit[1]
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            d = {str(k): str(v) for k, v in d.items()} if isinstance(d, dict) else {}
        except Exception:
            d = {}
        _cache[lang] = (mt, d)
        return d


_PH = re.compile(r"\{([A-Za-z0-9_]+)\}")


def fill(text: str, kw: dict) -> str:
    if not kw:
        return text
    return _PH.sub(lambda m: str(kw[m.group(1)]) if m.group(1) in kw else m.group(0), text)


def _text_for(lang, key, kw) -> str:
    try:
        k = "" if key is None else str(key)
        text = catalog(lang if isinstance(lang, str) else "en").get(k)
        if text is None:
            text = catalog("en").get(k)
        if text is None:
            text = k
        return fill(text, kw)
    except Exception:
        try:
            return "" if key is None else str(key)
        except Exception:
            return ""


def tr_lang(*args, **kw) -> str:
    """tr_lang(lang, key, **kw): the text of `key` in `lang`. Any placeholder name may be given (also one called
    "lang" or "key"). Never raises."""
    lang = args[0] if args else kw.pop("lang", "en")
    key = args[1] if len(args) > 1 else kw.pop("key", "")
    return _text_for(lang, key, kw)


def tr(*args, **kw) -> str:
    """tr(key, **kw): the text of `key` in the person's language (see the module docstring), its {name} placeholders
    filled from kw (any name, also one called "key"). Never raises."""
    key = args[0] if args else kw.pop("key", "")
    try:
        lang = language()
    except Exception:
        lang = "en"
    return _text_for(lang, key, kw)


def both(*args, **kw) -> dict:
    """both(key, **kw): {"en": ..., "pt-br": ...}, for an answer a page shows in its own language."""
    key = args[0] if args else kw.pop("key", "")
    return {lang: _text_for(lang, key, dict(kw)) for lang in LANGS}


# ---- sentences built in English, said in the person's language ------------------------------------------------------
# The approval card's plain sentences ("Delete the folder X and everything in it (3 files, in Downloads)") are put
# together in English by ask.py and engine_ask.py, and their English words take part in that code's own decisions
# (what a step is, which rule it gets). So they stay English there, and only the text the person reads is turned into
# their language here, at the very end, by templates: every catalog key that starts with one of SAY_PREFIXES is a
# template whose English (en.json) is matched against the whole sentence; {n}, {n2} and {count} catch a number, {svc},
# {host} and {cur} a name or code, any other placeholder any text. Only the slots of SLOT_FAMILIES are looked up again,
# and only in their own family (a folder's "in Downloads" inside a delete sentence); everything else is the person's
# data, kept as it is. The template with the most fixed words wins. A sentence no template matches is left exactly as
# it is. In English nothing is ever changed, so the English card stays byte for byte what it was.
SAY_PREFIXES = ("ask.say.", "ask.kind.", "ask.web.")
# The placeholders whose text may be Qosha's own words, and the one family of phrases each may take them from
# (21 Nov 2026, ptb7 CARD-16). A slot's text is said in the person's language only when it is, as a whole, one of its
# own family's phrases ("in Downloads" in a {where}, "this project" in a {proj}); anything else in it is the person's
# data or a name they typed ("Open Data", "Budget (in the folder Sales)") and is shown exactly as written, never
# matched against another sentence. Every other placeholder always holds data.
SLOT_FAMILIES = {
    "where": ("ask.say.where.", "ask.web.open_page"),
    "what": ("ask.say.what.",),
    "who": ("ask.say.who.",),
    "role": ("ask.say.role.",),
    "box": ("ask.say.box.",),
    "proj": ("ask.say.label.",),
    "thing": ("ask.say.label.",),
    "amt": ("ask.say.money.",),
    "kind": ("ask.kind.", "ask.say.act"),
}
SAY_RECURSE = frozenset(SLOT_FAMILIES)
# slots whose text has a fixed shape: a number; a product, connector or site name (never brackets or quotes); a
# currency code. A split that puts other text there is not this sentence.
_NUM = re.compile(r"\d[\d.,]*")
_NAME = re.compile(r"[A-Za-z0-9][\w.&'+-]*(?: [\w.&'+-]+){0,4}")
SLOT_SHAPES = {"n": _NUM, "n2": _NUM, "count": _NUM, "svc": _NAME, "host": _NAME, "cur": re.compile(r"[A-Z]{3}")}
_SPLITS_MAX = 400          # ways one sentence is tried against one template, at most
_say_cache: dict = {}      # lang -> (stamp, [(fixed, parts, target, exact, key)])


def _say_templates(lang: str) -> list:
    """Every card-sentence template: (fixed characters, parts [("lit", text) | ("ph", name)], target text, exact, key),
    the most specific (most fixed words) first."""
    en, tgt = catalog("en"), catalog(lang)
    stamp = (id(en), id(tgt))
    ck = (lang, _baselining())          # baseline() has its own templates (see catalog)
    hit = _say_cache.get(ck)
    if hit and hit[0] == stamp:
        return hit[1]
    out = []
    for k, e in en.items():
        if not k.startswith(SAY_PREFIXES) or not isinstance(e, str) or not e or k not in tgt:
            continue
        parts, fixed, pos = [], 0, 0
        for m in _PH.finditer(e):
            lit = e[pos:m.start()]
            if lit:
                parts.append(("lit", lit))
                fixed += len(lit)
            parts.append(("ph", m.group(1)))
            pos = m.end()
        if e[pos:]:
            parts.append(("lit", e[pos:]))
            fixed += len(e[pos:])
        out.append((fixed, parts, tgt[k], not any(p[0] == "ph" for p in parts), k))
    out.sort(key=lambda x: -x[0])
    _say_cache[ck] = (stamp, out)
    return out


def _shape_ok(name: str, value: str) -> bool:
    rx = SLOT_SHAPES.get(name)
    return bool(value) and (rx is None or bool(rx.fullmatch(value)))


def _splits(parts: list, text: str):
    """Every way `text` fills the template's placeholders (each value non-empty, shaped slots shaped), the earlier
    placeholders longest first: a name the person typed may itself hold the template's words ("Budget with Ana"),
    while the words Qosha adds after it never do."""
    n = len(parts)

    def walk(i, pos, vals):
        if i == n:
            if pos == len(text):
                yield list(vals)
            return
        kind, val = parts[i]
        if kind == "lit":
            if text.startswith(val, pos):
                yield from walk(i + 1, pos + len(val), vals)
            return
        if i + 1 == n:                                   # the last part: the rest of the text
            v = text[pos:]
            if _shape_ok(val, v):
                yield vals + [v]
            return
        nxt = parts[i + 1]
        if nxt[0] == "lit":
            ends, at = [], text.find(nxt[1], pos + 1)
            while at >= 0:
                ends.append(at)
                at = text.find(nxt[1], at + 1)
        else:
            ends = list(range(pos + 1, len(text)))
        for end in reversed(ends):
            v = text[pos:end]
            if _shape_ok(val, v):
                yield from walk(i + 1, end, vals + [v])
    return walk(0, 0, [])


def _balanced(s: str) -> bool:
    depth = 0
    for c in s:
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth < 0:
                return False
    return depth == 0 and s.count("“") == s.count("”")


def _match(lang: str, tpl, text: str, depth: int):
    """`text` said with one template, or None when the template does not fit it. Of the ways it fits, the one whose
    values are all well formed (brackets and quotes closed) and whose Qosha-worded slots are most often one of their
    family's phrases wins; then the earliest in _splits' order."""
    _fixed, parts, target, _exact, _key = tpl
    names = [p[1] for p in parts if p[0] == "ph"]
    best, best_score, tried = None, None, 0
    for vals in _splits(parts, text):
        tried += 1
        if tried > _SPLITS_MAX:
            break
        kw, fam = {}, 0
        for nm, v in zip(names, vals):
            said = _say_family(lang, nm, v, depth + 1) if nm in SLOT_FAMILIES else None
            if said is not None:
                fam += 1
            kw[nm] = v if said is None else said
        score = (all(_balanced(v) for v in vals), fam)
        if best_score is None or score > best_score:
            best, best_score = kw, score
            if score == (True, sum(1 for nm in names if nm in SLOT_FAMILIES)):
                break                                    # nothing can do better
    return None if best is None else fill(target, best)


def _say_family(lang: str, slot: str, text: str, depth: int):
    """The slot's text in the person's language when it is one of its family's phrases; None otherwise (data)."""
    if not text or depth > 3:
        return None
    fams = SLOT_FAMILIES.get(slot) or ()
    for tpl in _say_templates(lang):
        key = tpl[4]
        if not any(key == f or (f.endswith(".") and key.startswith(f)) for f in fams):
            continue
        r = _match(lang, tpl, text, depth)
        if r is not None:
            return r
    return None


def _say_lang(lang: str, text: str, depth: int = 0, exact: bool = False) -> str:
    if not text or depth > 3:
        return text
    for tpl in _say_templates(lang):
        if exact and not tpl[3]:
            continue
        r = _match(lang, tpl, text, depth)
        if r is not None:
            return r
    return text


def say(text, exact: bool = False) -> str:
    """One English sentence of the card in the person's language (see above); unchanged in English. exact: only a
    whole sentence of Qosha's own (no template with a placeholder), for text that may be someone else's words.
    Never raises."""
    try:
        s = "" if text is None else str(text)
        lang = language()
        if lang == "en" or not s.strip():
            return s
        return _say_lang(lang, s, exact=exact)
    except Exception:
        return "" if text is None else str(text)


# ---- the engine's own messages: the names and commands it fills in ---------------------------------------------------
# Some of the engine's texts are filled, at the moment they are shown, with values the engine makes itself: a sign-in
# command ({relogin}: "hermes auth add openrouter"), the pairing approval command ({approve_cmd}), Slack's "/hermes
# sethome", the profile selector ({profile_arg}: "-p familia "), and its own name ({agent_name}: "Hermes"). Qosha's
# pt-BR pack cannot reword a value, so in pt-BR those values are said in Qosha's words here, before the engine fills
# them in (ptb8 H7-15, H7-2): no "hermes" on any screen, and no terminal command the person has no program for. Real
# file paths (~/.hermes/backups) are the engine's interface and are kept as they are. English is never changed.
_ENGINE_MARK = "__qosha_engine_words__"
_LOGIN_SUBS = frozenset(("auth", "login", "logout", "model", "models", "portal", "setup", "fallback"))
_NOT_PATH = r"(?<![\w/\\.~$-])"
_SLASH_CMD = re.compile(_NOT_PATH + r"/hermes[ \t]+([A-Za-z][\w-]*)")
_TOKEN = r"(?:<[^<>\n]*>|[^\s`'\"“”<>]+)"
_PROG_CMD = re.compile(_NOT_PATH + r"hermes(?:[ \t]+-p[ \t]+([\w.-]+))?((?:[ \t]+" + _TOKEN + r")+)")
_NAME_AGENT = re.compile(_NOT_PATH + r"Hermes[ \t]+Agent\b(?![/\\])")
_NAME = re.compile(_NOT_PATH + r"hermes\b(?![/\\.-])", re.I)
_PROFILE_SEL = re.compile(r"[ \t]*-p[ \t]+(\S+)[ \t]*")


def _pt_command(m) -> str:
    profile, args = m.group(1), m.group(2).split()
    sub = args[0].lower() if args else ""
    where = " (perfil “%s”)" % profile if profile else ""
    if sub in _LOGIN_SUBS:
        return "entre de novo pela tela “Conecte sua IA” do Qosha%s, no computador" % where
    if sub == "pairing" and len(args) >= 4 and args[1].lower() == "approve":
        return ("peça ao Qosha no chat do seu computador%s para aprovar o código de pareamento %s (%s)"
                % (where, args[3], args[2]))
    return "peça ajuda ao Qosha no chat do seu computador%s" % where


def engine_value_pt(name: str, value: str) -> str:
    """One value the engine fills into its text, in Qosha's pt-BR words (see above). Never raises."""
    try:
        v = str(value)
        if name == "profile_arg":
            m = _PROFILE_SEL.fullmatch(v)
            return "do perfil “%s” " % m.group(1) if m else v
        if "ermes" not in v and "ERMES" not in v:
            return v
        v = _SLASH_CMD.sub(lambda m: "“%s” depois do comando de barra do bot" % m.group(1), v)
        v = _PROG_CMD.sub(_pt_command, v)
        v = _NAME_AGENT.sub("Qosha", v)
        return _NAME.sub("Qosha", v)
    except Exception:
        return value


def _engine_lang(lang) -> str:
    if lang:
        return normalize(lang)
    try:
        import agent.i18n as ai
        return normalize(ai.get_language())
    except Exception:
        return ""


# Only the ENGINE's own values are reworded (orchestrator, 23 Nov 2026: R8-7 is a HIGH, non-negotiable #1): the command
# awaiting approval, its arguments, file paths, tool inputs and anything the person typed are never touched, so an
# approval shows exactly what runs ("echo Hermes" stays "echo Hermes"). Engine-owned: {relogin} and {profile_arg}
# anywhere, and the (text, value) pairs where the engine fills in its own command or name (ptb8 H7-15's call sites,
# engine v0.23.2; fork E's R8-9 rule).
_OWNED_ANY = frozenset(("relogin", "profile_arg"))
_OWNED = frozenset((("gateway.pairing.code_reply", "approve_cmd"),
    ("gateway.startup.db_corrupt", "profile_arg"), ("gateway.startup.db_fts_corrupt", "profile_arg"),
    ("gateway.startup.db_then_restart", "profile_arg"), ("gateway.errors.generic_failed_with_hint", "hint"),
    ("gateway.notify.no_home_channel", "sethome_cmd"), ("cli.resume.label_assistant", "agent_name"),
    ("cli.session.history_assistant_header", "agent_name"), ("cli.stream.reference_header_indexed", "label"),
    ("cli.stream.reference_header", "label"),
    ("platform.discord.security.unauthorized_slash_alert", "reason")))


def _engine_kwargs(lang, kw: dict, key=None) -> dict:
    if not any(isinstance(v, str) and (k == "profile_arg" or "ermes" in v or "ERMES" in v) for k, v in kw.items()):
        return kw
    if _engine_lang(lang) != "pt-br":
        return kw
    return {k: (engine_value_pt(k, v) if isinstance(v, str) and (k in _OWNED_ANY or (key, k) in _OWNED) else v)
            for k, v in kw.items()}


def install_engine_words() -> bool:
    """Wraps the engine's t() (agent.i18n.t, and every engine module that already holds it by name) so the values it
    fills in are said in Qosha's words in pt-BR. Idempotent; fail-open (the engine's own t() stays as it was)."""
    try:
        import functools
        import sys
        import agent.i18n as ai
        cur = getattr(ai, "t", None)
        if not callable(cur):
            return False
        if getattr(cur, _ENGINE_MARK, False):
            wrapped, orig = cur, getattr(cur, "__wrapped__", None)
        else:
            orig = cur

            @functools.wraps(orig)
            def wrapped(key, lang=None, **format_kwargs):
                if format_kwargs:
                    try:
                        format_kwargs = _engine_kwargs(lang, format_kwargs, key)
                    except Exception:
                        pass
                return orig(key, lang, **format_kwargs)

            setattr(wrapped, _ENGINE_MARK, True)
            ai.t = wrapped
        if orig is None:
            return True
        for mod in list(sys.modules.values()):    # engine modules that imported t (or t as _t) before Qosha loaded
            if mod is None or mod is ai:
                continue
            for attr in ("t", "_t"):
                try:
                    # the module's own names only (never a lazy module's __getattr__, which could import something)
                    if vars(mod).get(attr) is orig:
                        setattr(mod, attr, wrapped)
                except Exception:
                    pass
        return True
    except Exception:
        return False


def say_value(value, exact: bool = False) -> str:
    """A card row's value, line by line: "1. <sentence>" keeps its number; other lines are sentences (or data, which
    no template matches and so stays as it is). Unchanged in English. Never raises."""
    try:
        s = "" if value is None else str(value)
        if language() == "en" or not s.strip():
            return s
        out = []
        for ln in s.split("\n"):
            m = re.match(r"^(\s*\d{1,3}\. )(.*)$", ln, re.S)
            out.append(m.group(1) + say(m.group(2), exact) if m else say(ln, exact))
        return "\n".join(out)
    except Exception:
        return "" if value is None else str(value)
