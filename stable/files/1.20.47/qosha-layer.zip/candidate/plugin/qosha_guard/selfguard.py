"""Editing Qosha's approval code or approval settings asks every time, with no "Always allow" (Ren, card, 21 Nov 2026
~21:55 MST, verbatim choice: "Yes, both (Recommended)"; the card said this is the one exception to his "no built-in
limits" rule).

A step of the assistant that changes (never one that only reads):
- Qosha's approval code: the plugin (qosha_guard/, plugins/qosha), the installed layer, the engine's approval, web,
  chat-socket and gateway files, the Qosha app (Qosha.app, Programs\\Qosha, app.asar);
- approval settings: approvals (mode), the allowlists, yolo, hooks, the plugin list, Qosha's paid-AI switches, or runs
  the engine with --yolo;
gets Qosha's card, one time only. Judged on the step's own text like every other kind (paid_ai.py has the helpers);
a name built at run time is not seen (known limit, on the list).
"""
from __future__ import annotations

import json
import os
import re
from typing import Any, Optional

from . import paid_ai


def _floor_marker() -> bool:
    """The native floor (council RC6): once this install answered approvals only in Qosha's approval window, the
    marker keeps it so in every later build that honours it (a rollback to N included), without patching any file."""
    try:
        from hermes_constants import get_default_hermes_root
        root = str(get_default_hermes_root())
    except Exception:
        root = os.environ.get("HERMES_HOME") or os.path.expanduser("~/.hermes")
    try:
        return os.path.exists(os.path.join(root, "qosha", "native-approval.json"))
    except Exception:
        return True

KIND = "approval.self"
TITLE = "Qosha wants to change its own approval code or approval settings"
NOTE = ("Qosha asks every time for this (no \"Always allow\"): these are the parts that decide what Qosha must ask you "
        "first.")
MIXED = ("Not run: this step changes Qosha's approval code or settings and also does something else that needs the "
         "person's OK. Do the change on its own, as one step, so the person sees exactly what changes. Nothing ran.")

_QOSHA_HOME = r"(?:application support[\\/]+qosha|appdata[\\/]+local[\\/]+qosha|localappdata%?[\\/]+qosha|\.hermes)"
_CODE = re.compile(r"qosha_guard|plugins[\\/]+qosha(?:[\\/]|\b)|qosha[\\/]+(?:layer|engine|custom|run)[\\/]"
                   r"|home[\\/]+(?:plugins|qosha[\\/]+custom|installs|tools)[\\/]|\.hermes[\\/]+(?:plugins|hermes-agent)[\\/]"
                   r"|qosha[^\n]*site-packages|qosha_names|sitecustomize"
                   r"|qosha\.app\b|programs[\\/]+qosha\b|app\.asar|tools[\\/]+approval\w*\.py|web_server\w*\.py"
                   r"|web_routers[\\/]|tui_gateway[\\/]|hermes_cli[\\/]+(?:plugins|config\w*)\.py"
                   r"|gateway[\\/]+(?:control_socket|session_authority|session_pending_controls|session_controls"
                   r"|runtime_bootstrap|approval\w*)\.py|shell_hooks\.py|startup_barrier"
                   r"|decisions\.sqlite|-pending\.json|-approved\.json|shell-hooks-allowlist"
                   r"|(?:^|[\s\\/'\"=])\.env\b",                       # the engine loads home/.env into its environment
                   re.I)
# a file in Qosha's home named by a shell pattern (conf*, config.y*): the text can't tell which file changes
_HOME_GLOB = re.compile(_QOSHA_HOME + r"[^\n;&|]*[*?\[]", re.I)
# the engine's own commands that turn the guard off or approve on the person's behalf (review round 2, AG-7, AG-8)
_GUARD_CMDS = re.compile(r"\b(?:hermes|qosha)(?:\.exe)?\b[^\n;&|]*\b(?:plugins?\s+(?:disable|remove|uninstall|reset)"
                         r"|pairing\s+(?:approve|accept)|config\s+(?:set|unset)\s+security)\b", re.I)
# the engine's settings file itself: any change to it asks (a key can be changed without naming it, e.g. sed on a value)
_CONFIG_FILE = re.compile(r"config\.ya?ml\b", re.I)
_CONFIG_CONTEXT = re.compile(r"config\.ya?ml|\bconfig\s+(?:set|unset|edit|reset)\b|/api/config|save_config|"
                             r"load_config|set_config_value|config_set", re.I)
_CONFIG_KEYS = re.compile(r"(?<![\w-])(?:approvals?(?:\.\w+)?|command_allowlist|permanent_allowlist|yolo|hooks|hooks_auto_accept|security(?:\.\w+)?|protected_instruction_files|"
                          r"plugins(?:\.\w+)?)(?![\w-])", re.I)
_YOLO_RUN = re.compile(r"--yolo\b|HERMES_YOLO|\byolo_mode\b|--accept-hooks\b|HERMES_ACCEPT_HOOKS|\b(?:hermes|qosha)(?:\.exe)?\b[^\n;&|]*\s(?:-z|--oneshot)(?![\w-])",
                       re.I)


def check(tool: str, args: Any) -> Optional[str]:
    """Plain words for the card when this step could change Qosha's approval code or settings, else None."""
    if _native():
        return _native_check(tool, args)
    if _surface_on():                                # the window's own state, on its own switch (council RC2)
        try:
            whole_s = json.dumps(args, ensure_ascii=False, default=str)
        except Exception:
            whole_s = str(args)
        t0, a0 = paid_ai._unwrap(str(tool or ""), args)
        batch = str(tool or "") == "tool_call"           # a batch: every entry read whole (TS-R-2)
        if (batch or (paid_ai._changer(t0) and not paid_ai._plain_read(t0, a0))) and _state_named(args, whole_s, str(tool or "")):
            return "This step would change Qosha's approval code or the Qosha app."
    if str(tool or "") == "tool_call":               # a batch, whatever shape its entries have (TS-M2-01; only adds cards)
        try:
            whole = json.dumps(args, ensure_ascii=False, default=str)
        except Exception:
            whole = str(args)
        wf = re.sub(r"[\"'`\\]", "", re.sub(r"\\[nr]", "\n", whole))
        if (_CODE.search(whole) or _CODE.search(wf) or _HOME_GLOB.search(wf) or _GUARD_CMDS.search(wf)
                or _CONFIG_FILE.search(wf) or _YOLO_RUN.search(wf)):
            return "This step would change Qosha's approval code or the Qosha app."
    tool, a = paid_ai._unwrap(str(tool or ""), args)
    if not paid_ai._changer(tool) or paid_ai._plain_read(tool, a):
        return None
    text = paid_ai._flat(a)
    folded = re.sub(r"[\"'`\\]", "", re.sub(r"\\[nr]", "\n", text))
    what = []
    if _CODE.search(text) or _CODE.search(folded) or _HOME_GLOB.search(folded) or _GUARD_CMDS.search(folded):
        what.append("change Qosha's approval code or the Qosha app")
    if (_CONFIG_FILE.search(folded) or (_CONFIG_CONTEXT.search(folded) and _CONFIG_KEYS.search(folded))
            or _YOLO_RUN.search(folded)):
        what.append("change what Qosha may do without asking (approval settings)")
    paid = paid_ai.paid_change(tool, args)
    if paid:
        what.append("turn on pay-per-use AI (" + paid.rstrip(".") + ")")
    if not what:
        return None
    return "This step would " + "; and ".join(what) + "."


def only_config_file(tool: str, args: Any) -> bool:
    """The step's only reason for a card is that it writes the settings file (no approval key, code path, paid switch
    or yolo run named): another one-time card for that setting may then stand on its own."""
    tool, a = paid_ai._unwrap(str(tool or ""), args)
    text = paid_ai._flat(a)
    folded = re.sub(r"[\"'`\\]", "", re.sub(r"\\[nr]", "\n", text))
    return bool(_CONFIG_FILE.search(folded)) and not (
        _CODE.search(text) or _CODE.search(folded) or _HOME_GLOB.search(folded) or _GUARD_CMDS.search(folded)
        or _CONFIG_KEYS.search(folded) or _YOLO_RUN.search(folded) or paid_ai.paid_change(tool, args))


def card(what: str) -> str:
    return "%s\nWhat happens: %s\nNote from Qosha: %s\n(\"Always allow\" is not offered for this step.)" % (TITLE, what, NOTE)


# ---- the trusted approval surface: pages free, everything else as before ----------------------------------------------
# Ren, cards 23 Nov 2026 ~19:00 MST ("Go (Recommended)"): once Allow lives only in Qosha's own approval window, a page
# can no longer answer, hide or reword a card, so pages, style sheets, scripts the pages load, text catalogs, images and
# the look add-on are free. Built the other way round (review TS-G-01): only a path positively identified as such a
# file is taken out of the step's text; every other mention of the plugin, the custom/ overlay or Qosha's home is read
# by 1.20.33's own rule above, so a program file, a loader, a folder as a whole, a name with spaces, a link: carded.
# the trust-mode switch (Ren, card 23 Nov 2026 16:40): an approval setting. Qosha's own config command with the key in
# key position, or the installed switch file (never another program's config, never "trust" as a word or a value)
_TRUST = re.compile(r"\b(?:hermes|qosha|hermes_cli(?:\.[\w.]+)?)(?:\.exe)?\b[^\n;&|]*\bconfig\s+(?:set|unset|edit|reset)\s+(?:-\S+(?:\s+(?![\"']?(?:qosha\.)?trust)[^\s;&|-]\S*)?\s+)*"
                    r"(?:qosha\.)?trust(?:[_-]mode)?(?:\.\w+)?(?![\w-])|"   # round 1's unanchored form, kept (Gemini B r2 R2-01: env/bash -c/cmd /c/exec/a quoted path with spaces); fails closed
                    r"(?:^|[;&|(\n\"`]|:\s)\s*(?:[^\s;&|\"'`]*[\\/])?(?:hermes|qosha|python\d?(?:\.\d+)?(?:\.exe)?\s+-m\s+hermes_cli(?:\.[\w.]+)?)(?:\.exe)?\s+(?:[^\n;&|]*\s)?config\s+(?:set|unset|edit|reset)\s+(?:-\S+(?:\s+(?![\"']?(?:qosha\.)?trust)[^\s;&|-]\S*)?\s+)*"
                    r"(?:qosha\.)?trust(?:[_-]mode)?(?:\.\w+)?(?![\w-])"
                    r"|(?:home|\.hermes|hermes_home[%}]?)[\\/]+qosha[\\/]+trust-mode\.json"
                    # the config API with the key, or the switch file's path built from parts (Gemini B r1 SG-6)
                    r"|(?:set_config_value|save_config|config_set)\s*\(\s*[\"'](?:qosha\.)?trust(?:[_-]mode)?(?:\.\w+)?[\"']"
                    r"|[\"']qosha[\"']\s*[,/]\s*[\"']trust-mode\.json[\"']", re.I)
# a trust: key in config.yaml: on any line (also the first, a patch's + line) or in flow style (Gemini B r1 SG-3)
_TRUST_YAML = re.compile(r"(?:^|\n|content:\s*|[{,]\s*)[+ \t]*[\"']?trust(?:[_-]mode)?[\"']?[ \t]*:", re.I)
_YOLO_RUN = re.compile(r"--yolo\b|HERMES_YOLO|\byolo_mode\b|--accept-hooks\b|HERMES_ACCEPT_HOOKS|\b(?:hermes|qosha)(?:\.exe)?\b[^\n;&|]*\s(?:-z|--oneshot)(?![\w-])",
                       re.I)


_PATHISH_KEYS = ("content", "new_string", "old_string", "text", "body", "description")   # a file's content: no pattern


_PATHISH_KEYS = ("content", "new_string", "old_string", "text", "body", "description")   # a file's content: no pattern


def _leaves(v, key=""):
    if isinstance(v, str):
        yield key, v
    elif isinstance(v, dict):
        for k, x in v.items():
            yield from _leaves(x, str(k).lower())
    elif isinstance(v, (list, tuple)):
        for x in v:
            yield from _leaves(x, key)


def _join_lines(s: str) -> str:
    """A shell line continuation (backslash + newline) joined, as the shell reads it (Gemini B r1 SG-9)."""
    return re.sub(r"\\\r?\n", "", s)


def _home_glob(a) -> bool:
    """A file in Qosha's home named by a shell pattern, read within ONE value of the step (a path, a command), never
    in a file's content (a `*` in CSS/JS comments is not a pattern) (option B, 23 Nov 2026). Windows paths keep their
    backslashes in the second reading. With Qosha's home as the working folder (workdir, or `cd` into it), a pattern
    anywhere in the command counts (Gemini B r1 SG-7)."""
    leaves = list(_leaves(paid_ai._strip_old(a)))
    home_wd = any(k in ("workdir", "cwd", "dir", "directory") and re.search(_QOSHA_HOME, v, re.I) for k, v in leaves)
    for key, leaf in leaves:
        if key in _PATHISH_KEYS:
            continue
        leaf = _join_lines(leaf)
        if (_HOME_GLOB.search(re.sub(r"[\"'`\\]", "", leaf))
                or _HOME_GLOB.search(re.sub(r"[\"'`^]", "", leaf))):
            return True
        if key in ("command", "code", "cmd", "script", "input") and re.search(r"[*?\[]", leaf) and (
                home_wd or re.search(r"\bcd\s+[\"']?[^\n;&|]*" + _QOSHA_HOME, leaf, re.I)):
            return True
    return False


# a "." or ".." path segment in a step that also names Qosha's home or plugin: the path may leave a free folder for a
# protected one (plugins/qosha/./__init__.py, .../pages/../decisions_api.py) (Gemini B r1 SG-4)
_DOTSEG = re.compile(r"(?:^|[\\/\s\"'=:])\.\.?(?=[\\/]|[\"'\s;&|)`>,}{]|$)")
_QOSHA_REF = re.compile(_QOSHA_HOME + r"|plugins[\\/]+qosha|qosha[\\/]+custom|hermes_home|get_hermes_home", re.I)


def _flat(tool: str, a) -> str:
    """The step as text: the removed lines of a diff are dropped only for a patch step (Gemini B r1 SG-8)."""
    v = paid_ai._strip_old(a) if tool.lower().endswith("patch") else a
    try:
        text = json.dumps(v, ensure_ascii=False, default=str)
    except Exception:
        text = str(v)
    return re.sub(r"\\\\\\(?:r\\\\)?n", "", text)     # JSON-encoded shell line continuations: \\ + \n (SG-9)


def _entries(tool: str, args: Any) -> list:
    """The calls a step makes: one, or each entry of the engine's tool_call batch (Gemini B r1 SG-1)."""
    a = args if isinstance(args, dict) else {}
    if tool != "tool_call" or a.get("calls") is None:
        return [(tool, args)]
    raw = a.get("calls")
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            return [("tool_call", {"raw": raw})]
    if isinstance(raw, dict):
        raw = [raw]
    out = []
    for e in raw if isinstance(raw, list) else []:
        if isinstance(e, dict):
            out.append(("tool_call", {"name": e.get("name"), "arguments": e.get("arguments")}))
    return out or [("tool_call", {"raw": str(raw)})]


_RENDER_EXT = r"(?:html?|css|js|svg|png|jpe?g|gif|webp|ico|woff2?|ttf|otf)"
# where a free file may be (TS-M-02): the plugin's dashboard folder (and its copy under custom/plugin), the plugin's
# text catalogs (locales/), and the look add-on's own files (custom/ren-look.*)
_PAGE_PATH = re.compile(
    r"(?:(?:plugins[\\/]+qosha|qosha[\\/]+custom[\\/]+plugin)[\\/]+dashboard((?:[\\/]+[A-Za-z0-9_@+-][A-Za-z0-9_.@+-]*)+?)"
    r"\." + _RENDER_EXT +
    r"|(?:plugins[\\/]+qosha|qosha[\\/]+custom[\\/]+plugin)[\\/]+dashboard[\\/]+i18n((?:[\\/]+[A-Za-z0-9_@+-][A-Za-z0-9_.@+-]*)+?)\.json"
    r"|plugins[\\/]+qosha[\\/]+locales((?:[\\/]+[A-Za-z0-9_@+-][A-Za-z0-9_.@+-]*)+?)\.(?:ya?ml|json)"
    r"|qosha[\\/]+custom((?:[\\/]+ren-look[A-Za-z0-9_.@+-]*?))\.(?:css|js|json|svg|png|jpe?g|webp))(?![\w.-])", re.I)
_LOADER_NAMES = ("manifest", "plugin", "__init__", "sitecustomize", "package", "package-lock", "tsconfig", "pyproject",
                 "setup", "requirements", "composer", "webpack.config", "vite.config")
_LINKS = re.compile(r"\bln\s|\bmklink\b|symlink|hardlink|junction|-itemtype\s+\w*link|createsymbolic|\blink\s*\(", re.I)
# Qosha's own approval state: the grant record, the native-approval marker, the window's lock and markers, the
# install's ID (the grant record's binding)
_STATE = re.compile(r"standing-grants|native-approval|approval-window|install-id\.json|grants\.py|trusted_dialog"
                    r"|engine_cards|window_gate|trust-mode|trust-log|cron[\\/]+jobs", re.I)
_STATE_PARTS = re.compile(r"cron[\"']?\s*[,+/\\]\s*[\"']?jobs", re.I)      # os.path.join(h, 'cron', 'jobs.json')


def _all_strings(x, out):
    if isinstance(x, dict):
        for v in x.values():
            _all_strings(v, out)
    elif isinstance(x, (list, tuple)):
        for v in x:
            _all_strings(v, out)
    elif x is not None:
        out.append(str(x))
    return out


def _state_named(args: Any, whole_s: str, tool: str = "") -> bool:
    """The window's own state named in any spelling the step could run: as written, with shell / PowerShell / cmd line
    continuations joined, with Windows separators, without quotes, or built from parts (TS-R-2, TS-R-F14)."""
    raw = "\n".join(_all_strings(args, [])) + "\n" + whole_s
    joined = re.sub(r"[\\`^]\r?\n", "", raw)
    for v in (raw, joined, joined.replace("\\", "/"), re.sub(r"[\"'`]", "", joined.replace("\\", "/")),
              re.sub(r"[\"'`\\]", "", raw), joined.replace("^", "")):
        if _STATE.search(v) or _STATE_PARTS.search(v):
            return True
        if re.search(r"jobs\.json", v, re.I) and re.search(r"cron", v, re.I):
            return True                          # the job file named through its folder + file name (TS-R2 R-2)
    if tool in _FILE_TOOLS:
        return False                             # a file tool: its path decides (above); its content is the person's text
    flat = re.sub(r"\$\{?[A-Za-z_]\w*\}?|[\"'`^\\+\s\[\]]", "", raw)
    if re.search(r"cron", flat, re.I) and re.search(r"jobs?\W{0,3}\.?json|jobs", flat, re.I):
        return True                              # split by quotes, ^, a stem + suffix, an expansion (TS-S7-2)
    return False


# only a direct file tool may name a free file; a shell or code step that names the plugin is read as before (TS-M-02)
_FILE_TOOLS = ("write_file", "edit_file", "patch", "str_replace", "replace_in_file", "create_file", "read_file")
_PATH_KEYS = ("path", "file_path", "filepath", "target", "filename", "file")


def _page_ok(m) -> bool:
    inner = next((g for g in m.groups() if g), "")
    segs = [x for x in re.split(r"[\\/]+", inner) if x]
    name = segs[-1].lower() if segs else ""
    return bool(segs) and not any(x in (".", "..") or x.lower() in ("__pycache__", "qosha_guard") for x in segs) \
        and name not in _LOADER_NAMES


_FREED = "\x00qosha-page\x00"          # can't appear in a real path or JSON-decoded tool argument


def _strip_paths(tool: str, a) -> Any:
    """The step with its file-tool path values that name a free file replaced by a placeholder; anything else as it is
    (contents, commands, code, other keys)."""
    if str(tool or "").lower() not in _FILE_TOOLS or not isinstance(a, dict):
        return a
    out = dict(a)
    for k in _PATH_KEYS:
        v = out.get(k)
        if isinstance(v, str) and "\n" not in v:
            m = _PAGE_PATH.search(v)
            if m and m.end() == len(v.rstrip()) and _page_ok(m) and not re.search(r"[\s;&|<>`$*?\[\]]", v[m.start():]):
                out[k] = v[:m.start()] + _FREED
    return out


def _linked(a) -> bool:
    """A file tool aimed at a page that is in fact a link to somewhere else: its real target decides (TS-G-01)."""
    for key, leaf in _leaves(a if isinstance(a, dict) else {}):
        if key in ("path", "file_path", "filepath", "target", "filename", "file") and _PAGE_PATH.search(leaf):
            try:
                p = os.path.expanduser(leaf)
                if os.path.islink(p) or (os.path.exists(p) and os.path.realpath(p) != os.path.abspath(p)):
                    return True
            except Exception:
                return True
    return False


_CONTENT_KEYS = ("content", "new_string", "old_string", "text", "body", "new_text", "old_text", "data")


def _free_write(tool: str, a) -> Optional[dict]:
    """A direct file write whose every path names a free file (a page, style sheet, catalog, image, the look add-on):
    the step without its content (which can't change Qosha's code), else None. A patch step is never one (its text
    names its own files)."""
    if str(tool or "").lower() not in _FILE_TOOLS or str(tool).lower() == "patch" or not isinstance(a, dict):
        return None
    paths = [k for k in _PATH_KEYS if isinstance(a.get(k), str)]
    if not paths:
        return None
    b = _strip_paths(tool, a)
    if any("\x00" in str(a.get(k)) for k in paths) or not all(str(b.get(k)).endswith(_FREED) for k in paths):
        return None
    return {k: v for k, v in b.items() if k not in _CONTENT_KEYS}


def _native_one(tool: str, args: Any) -> Optional[str]:
    tool, a = paid_ai._unwrap(str(tool or ""), args)
    if not paid_ai._changer(tool) or paid_ai._plain_read(tool, a):
        return None
    free = _free_write(tool, a)
    if free is not None and _linked(a):
        free = None                                   # a page that is a link: its real target decides
    if free is not None:
        a = free                                      # judged on everything but the page's own content
    text = _join_lines(_flat(tool, a))
    folded = re.sub(r"[\"'`\\]", "", re.sub(r"\\[nr]", "\n", text))
    what = []
    if (_CODE.search(text) or _CODE.search(folded) or _home_glob(a) or _GUARD_CMDS.search(folded)
            or _STATE.search(folded) or (free is None and _linked(a if isinstance(a, dict) else {}))
            or (_LINKS.search(folded) and _QOSHA_REF.search(text))
            or (_DOTSEG.search(text) and _QOSHA_REF.search(text))):
        what.append("change Qosha's approval code or the Qosha app")
    if (_CONFIG_FILE.search(folded) or (_CONFIG_CONTEXT.search(folded) and _CONFIG_KEYS.search(folded))
            or _YOLO_RUN.search(folded) or _TRUST.search(text) or _TRUST.search(folded) or _TRUST_YAML.search(folded)):
        what.append("change what Qosha may do without asking (approval settings)")
    paid = paid_ai.paid_change(tool, args if free is None else a)
    if paid:
        what.append("turn on pay-per-use AI (" + paid.rstrip(".") + ")")
    if not what:
        return None
    return "This step would " + "; and ".join(what) + "."


def _native_check(tool: str, args: Any) -> Optional[str]:
    reasons = []
    pairs = list(_entries(str(tool or ""), args))
    if str(tool or "") == "tool_call":
        # the batch as a whole, read as text and never freed, whatever shape its entries have (TS-M2-01)
        try:
            whole = json.dumps(args, ensure_ascii=False, default=str)
        except Exception:
            whole = str(args)
        folded = re.sub(r"[\"'`\\]", "", re.sub(r"\\[nr]", "\n", whole))
        if (_CODE.search(whole) or _CODE.search(folded) or _STATE.search(folded) or _GUARD_CMDS.search(folded)
                or _CONFIG_FILE.search(folded) or _YOLO_RUN.search(folded) or _TRUST.search(folded)):
            reasons.append("This step would change Qosha's approval code or the Qosha app.")
    for t, a in pairs:
        r = _native_one(t, a)
        if r and r not in reasons:
            reasons.append(r)
    return " ".join(reasons) if reasons else None


def _surface_on() -> bool:
    """The approval window is on (engine_cards.py's ON), whatever PAGES_FREE says. Unreadable = on (cards stay)."""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "engine_cards.py"), encoding="utf-8") as fh:
            if (re.search(r"(?m)^ON = True\b", fh.read()) or _floor_marker()):
                return True
    except FileNotFoundError:
        return False
    except Exception:
        return True
    try:
        import sys as _sys
        m = _sys.modules.get(__name__.rsplit(".", 1)[0] + ".engine_cards") if "." in __name__ else None
        return bool(m and getattr(m, "ON", False) is True)
    except Exception:
        return False


def _native() -> bool:
    """Pages are free: the approval window is on AND its separate PAGES_FREE switch is on, read from engine_cards.py's
    own text next to this file (TS-G-06). Unreadable = off here (pages stay carded)."""
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "engine_cards.py"), encoding="utf-8") as fh:
            src = fh.read()
            if re.search(r"(?m)^ON = True\b", src) and re.search(r"(?m)^PAGES_FREE = True\b", src):
                return True
    except Exception:
        return False
    try:
        import sys as _sys
        m = _sys.modules.get(__name__.rsplit(".", 1)[0] + ".engine_cards") if "." in __name__ else None
        return bool(m and getattr(m, "ON", False) is True and getattr(m, "PAGES_FREE", False) is True)   # tests
    except Exception:
        return False
