"""Paste from Qosha's right-click menu in the Qosha app (P0 Renato, 25 Nov 2026: the menu's Paste pasted nothing).

Why: the Qosha app's window refuses every page a clipboard read (its permission policy), so pages/qosha-rclick.js could
only say "To paste here, press Ctrl+V." while the keyboard paste worked. Here the dashboard reads the computer's
clipboard TEXT for that Paste, and only when the request comes from the Qosha app window itself
(approval_gate.from_qosha_window: the connection's other end is one of the app's own processes). A browser tab, another
program, a missing gate or the trusted-surface mode get 403, and the menu says which keys paste, as before.
Plain text only (never rich text turned into text), at most 1,000,000 UTF-16 units, bounded before it is read; the text is never stored, logged or sent anywhere else (a refusal logs its
reason only). Standard library only (and
the dashboard's own FastAPI)."""
import json
import logging
import os
import subprocess
import sys
import time

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

router = APIRouter()
log = logging.getLogger("qosha.clipboard")
MAX_CHARS = 1_000_000
CF_UNICODETEXT = 13


def from_window(scope) -> bool:
    """True only for the Qosha app window, with the approval gate loaded and the trusted surface off (fail closed)."""
    gate = sys.modules.get("qosha_approval_gate")
    if gate is None:
        log.warning("menu Paste refused: the approval gate is not loaded")
        return False
    try:
        if gate._native():
            log.warning("menu Paste refused: the trusted approval surface is on")
            return False
        if gate.from_qosha_window(scope):
            return True
        log.warning("menu Paste refused: not the Qosha app window")
        return False
    except Exception as exc:
        log.warning("menu Paste refused: %s", type(exc).__name__)
        return False


TOO_LONG = object()      # read_text's answer for a clipboard text over MAX_CHARS (never read whole)
# the plain-text string only (never RTF or EPS turned into text: pbpaste falls back to those, GPT r1 #8), and at most
# MAX_CHARS of it ever reaches this process: a longer text answers "T" alone (r1 #9)
_MAC_READ = ("ObjC.import('AppKit');"
             "var pb = %s;"
             "var s = pb.stringForType($.NSPasteboardTypeString);"
             "(!s || s.isNil()) ? 'O' : (s.length > %d ? 'T' : 'O' + s.js)")   # the length is the native string's,
#                                                         read before any conversion (review v2); both systems count UTF-16 units


def read_text(pasteboard=None):
    """The clipboard's plain text ('' when it holds none), TOO_LONG, or None when it can't be read. Never raises.
    pasteboard: Mac only, a named pasteboard instead of the general one (tests)."""
    try:
        if os.name == "nt":
            return _read_windows()
        if sys.platform == "darwin":
            return _read_mac(pasteboard)
    except Exception:
        return None
    return None


def _read_mac(pasteboard=None):
    pb = "$.NSPasteboard.pasteboardWithName(%s)" % _js_str(pasteboard) if pasteboard else "$.NSPasteboard.generalPasteboard"
    r = subprocess.run(["/usr/bin/osascript", "-l", "JavaScript", "-e", _MAC_READ % (pb, MAX_CHARS)],
                       capture_output=True, timeout=10, stdin=subprocess.DEVNULL)
    if r.returncode != 0:
        return None
    out = r.stdout.decode("utf-8", "replace")
    if out.endswith("\n"):                 # osascript ends its answer with one newline of its own
        out = out[:-1]
    if out == "T":
        return TOO_LONG
    return out[1:] if out.startswith("O") else None


def _js_str(s):
    return json.dumps(str(s))            # a JSON string is a valid JavaScript string literal


def _read_windows():
    import ctypes
    from ctypes import wintypes
    u, k = ctypes.WinDLL("user32", use_last_error=True), ctypes.WinDLL("kernel32", use_last_error=True)
    u.OpenClipboard.argtypes, u.OpenClipboard.restype = [wintypes.HWND], wintypes.BOOL
    u.CloseClipboard.argtypes, u.CloseClipboard.restype = [], wintypes.BOOL
    u.IsClipboardFormatAvailable.argtypes, u.IsClipboardFormatAvailable.restype = [wintypes.UINT], wintypes.BOOL
    u.GetClipboardData.argtypes, u.GetClipboardData.restype = [wintypes.UINT], wintypes.HANDLE
    k.GlobalLock.argtypes, k.GlobalLock.restype = [wintypes.HGLOBAL], wintypes.LPVOID
    k.GlobalUnlock.argtypes, k.GlobalUnlock.restype = [wintypes.HGLOBAL], wintypes.BOOL
    k.GlobalSize.argtypes, k.GlobalSize.restype = [wintypes.HGLOBAL], ctypes.c_size_t
    for _ in range(10):                      # another program may hold the clipboard for a moment
        if u.OpenClipboard(None):
            break
        time.sleep(0.05)
    else:
        return None
    try:
        if not u.IsClipboardFormatAvailable(CF_UNICODETEXT):
            return ""
        h = u.GetClipboardData(CF_UNICODETEXT)
        if not h:
            return None
        size = k.GlobalSize(h)               # the block's own size bounds the read (never past it, r1 #9)
        if not size:
            return None
        if size > (MAX_CHARS + 1) * 4:       # more than MAX_CHARS characters whatever they are: not read at all
            return TOO_LONG
        p = k.GlobalLock(h)
        if not p:
            return None
        try:
            text = ctypes.wstring_at(p, size // 2).split("\0", 1)[0]
        finally:
            k.GlobalUnlock(h)
        return TOO_LONG if len(text.encode("utf-16-le", "surrogatepass")) // 2 > MAX_CHARS else text
    finally:
        u.CloseClipboard()


@router.post("/text")
def clipboard_text(request: Request):
    nostore = {"Cache-Control": "no-store"}
    if not from_window(request.scope):
        return JSONResponse(status_code=403, content={"error": "qosha_app_window_only"}, headers=nostore)
    text = read_text()
    if text is None:
        log.warning("menu Paste: the clipboard could not be read")
        return JSONResponse(status_code=503, content={"error": "unreadable"}, headers=nostore)
    if text is TOO_LONG:
        return JSONResponse(status_code=413, content={"error": "too_long"}, headers=nostore)
    try:
        text.encode("utf-8")                 # a broken character (an unpaired surrogate) can't be sent: 503, never a 500
    except UnicodeError:
        log.warning("menu Paste: the clipboard text has a broken character")
        return JSONResponse(status_code=503, content={"error": "unreadable"}, headers=nostore)
    return JSONResponse(content={"text": text}, headers=nostore)
