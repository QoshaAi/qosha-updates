/* Qosha decisions: one Approve sends (D26, founder 17:10 MST, 3 Nov). Shared by Home (index.html) and the Chat page.
   An email or calendar change, or a step on a website in Qosha's own Chrome (browser.action, D34; BROWSERCHROME), is approved
   straight at the Qosha connector (approve_url, a port the assistant's sandbox
   can't reach); the dashboard then reads the outcome back from the connector (/decisions/<id>/sync). Other kinds
   (a connected app's action, a new skill) are approved through the dashboard as before. One request per decision at a
   time on this page, so a double click never sends twice. Nothing here reads what the assistant writes in the chat. */
(function () {
  'use strict';
  // approved at the connector's own port, never through the dashboard
  var CONNECTOR = {'email.send': 1, 'email.reply': 1, 'calendar.create': 1, 'calendar.update': 1, 'calendar.delete': 1,
                   'browser.action': 1, 'email.forward': 1, 'email.draft_send': 1, 'email.draft_save': 1};
  var DONE = {'browser.action': 'Done in Qosha\u2019s browser', 'email.send': 'Sent', 'email.reply': 'Sent', 'calendar.create': 'Added to your calendar',
              'calendar.update': 'Changed on your calendar', 'calendar.delete': 'Deleted from your calendar',
              'app.action': 'Done', 'skill.save': 'Added to your skills', 'email.forward': 'Sent', 'email.draft_send': 'Sent',
              'email.draft_save': 'Saved in your Gmail drafts', 'google.reconnect': 'Google reconnected',
              'settings.change': 'Changed in Qosha\u2019s settings', 'file.delete': 'Moved to Trash', 'file.write': 'Saved'};
  var inflight = {};
  var chan = null;
  try { chan = new BroadcastChannel('qosha-decisions'); } catch (e) { chan = null; }
  var D = {};

  D.viaConnector = function (kind, payload) {
    return CONNECTOR.hasOwnProperty(kind) || ['file.delete', 'file.write', 'settings.change'].indexOf(kind) >= 0 ||
      (kind === 'app.action' && payload && payload.arguments && payload.arguments.source === 'codebox');
  };
  // SENDFIX (Ren, 6 Nov: sending always on): the one "Reconnect Google" card: a notice with a button, nothing to approve
  D.isReconnect = function (kind) { return kind === 'google.reconnect'; };
  D.reconnectText = function (d) {
    var need = d && d.payload ? d.payload.need : '';
    var what = need === 'calendar' ? 'change your calendar' : need === 'drafts' ? 'save drafts in Gmail' : need === 'connect' ? 'use Google' : 'send email';
    return 'Your Google connection doesn\u2019t let Qosha ' + what + ' yet. Nothing was sent. Reconnect Google once and leave every box ticked; then ask Qosha again.';
  };
  // the attachments a forward or a draft carries, as the card shows them
  D.attachmentsText = function (p) {
    var a = p && Array.isArray(p.attachments) ? p.attachments : [];
    return a.map(function (x) { x = x || {}; return String(x.name || '(no name)') + ' (' + D.size(x.size) + ')'; }).join(', ');
  };
  D.size = function (n) {
    n = Number(n) || 0;
    return n < 1024 ? n + ' bytes' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB';
  };
  // an email's facts as [label, plain text] pairs, exactly as they go out (both pages; text only, never HTML)
  D.emailFacts = function (d) {
    var p = d.payload || {}, f = [];
    var add = function (k, v) { if (v != null && v !== '') f.push([k, String(v)]); };
    add('To', p.to); add('Cc', p.cc); add('Bcc (hidden from the others)', p.bcc); add('From', p.from); add('Subject', p.subject);
    if (d.kind === 'email.draft_save' && !p.to) add('To', '(nobody yet)');
    if (d.kind === 'email.send' && p.html === true) add('Format', 'HTML (shown as its source text)');
    if (d.kind === 'email.send' && p.thread_id) add('Conversation', 'In an existing conversation');
    if (d.kind === 'email.reply' && p.reply_to_message_id) add('Replying to', 'message ' + p.reply_to_message_id);
    if (d.kind === 'email.draft_send' && p.in_reply_to) add('In reply to', p.in_reply_to);
    if (d.kind === 'email.forward' || d.kind === 'email.draft_send') add('Attachments', D.attachmentsText(p) || 'none');
    return f;
  };
  // the exact text that goes out (a forward: the note, then the forwarded email; a draft: its text and its HTML source)
  D.exactText = function (d) {
    var p = d.payload || {};
    if (d.kind === 'email.forward') return (p.body ? String(p.body) + '\n\n' : '') + String(p.forward_block || '');
    if (d.kind === 'email.draft_send') return String(p.body || '') + (p.html_body ? (p.body ? '\n\n' : '') + 'HTML version (source):\n' + String(p.html_body) : '');
    return String(p.body || p.description || '');
  };
  D.isGoogle = D.viaConnector;   // the old name, kept for pages that still call it
  D.isFinal = function (status) { return ['sent', 'failed', 'declined', 'approved_not_sent'].indexOf(status) >= 0; };
  // the outcome in plain words, from Qosha's own record of the decision
  D.statusText = function (d) {
    if (!d) return '';
    var r = d.result || {};
    if (d.status === 'sent' && d.kind === 'browser.action' && d.payload && d.payload.action === 'show') return 'Opened in your browser';
    if (d.status === 'sent' && d.kind === 'email.draft_send') return 'Sent. The draft is still in your Gmail drafts: delete it there if you like.';
    if (d.status === 'sent' && d.kind === 'browser.action' && D.inMyChrome(d.payload) && r.outcome === 'unconfirmed')
      return 'Not confirmed: Qosha asked Chrome to send the form, but no page came back that it could read. It may not have gone out; check the page.';
    if (d.status === 'sent' && d.kind === 'browser.action' && D.inMyChrome(d.payload) && r.note)
      return 'Done in Qosha\u2019s tab in your Chrome. Note: ' + String(r.note);
    if (d.status === 'sent' && d.kind === 'browser.action' && D.inMyChrome(d.payload))
      return d.payload.action === 'open' ? 'Opened in Qosha\u2019s tab in your Chrome' : 'Done in Qosha\u2019s tab in your Chrome';
    if (d.status === 'sent') return DONE[d.kind] || 'Done';
    if (d.status === 'failed') {
      var e = String(r.error || 'it did not go through');
      if (d.kind === 'browser.action' && D.inMyChrome(d.payload)) return /^(Not |Nothing )/.test(e) ? e : 'Not done: ' + e;
      return /^(Not |Google |The |Nothing )/.test(e) ? e : 'Not sent: ' + e;
    }
    if (D.isReconnect(d.kind)) return d.status === 'pending' ? 'Waiting for you to reconnect Google' : d.status === 'sent' ? 'Google reconnected' : 'Dismissed';
    if (d.status === 'declined') return 'Declined. Nothing was sent.';
    if (d.status === 'approved_not_sent') return 'Approved (sending is off on this computer, so nothing was sent)';
    if (d.status === 'sending') return 'Sending…';
    return 'Waiting for your approval';
  };
  D.resultId = function (d) {
    var r = (d && d.result) || {};
    if (d && d.status === 'sent' && typeof r.message_id === 'string' && r.message_id) return 'Gmail id ' + r.message_id;
    if (d && d.status === 'sent' && typeof r.event_id === 'string' && r.event_id) return 'Event id ' + r.event_id;
    return '';
  };
  D.firstTimeNote = function (d) {
    var f = d && Array.isArray(d.first_time) ? d.first_time.filter(function (x) { return typeof x === 'string' && x; }) : [];
    return f.length ? 'First email from Qosha to ' + f.join(', ') + '.' : '';
  };
  // a time as the person reads it; a date-only value is an all-day event: that calendar date, never shifted by time zone
  // the event's own date, time and offset exactly as Google gets them: no conversion, the year and the zone always
  // shown, so neither another year nor a repeated daylight-saving hour can look the same (GPT R3)
  D.when = function (v) {
    var s = String(v == null ? '' : v), m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
    var day = function (y, mo, d) {
      return new Date(Date.UTC(y, mo - 1, d)).toLocaleDateString([], {timeZone: 'UTC', weekday: 'short', month: 'short', day: 'numeric', year: 'numeric'});
    };
    if (m) return day(+m[1], +m[2], +m[3]) + ' (All day)';
    var t = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?$/.exec(s);
    if (!t) return s;
    var z = t[7] ? (t[7] === 'Z' ? 'UTC' : 'UTC' + t[7].replace('-', '\u2212')) : 'no time zone given';
    return day(+t[1], +t[2], +t[3]) + ', ' + t[4] + ':' + t[5] + (t[6] && t[6] !== '00' ? ':' + t[6] : '') + ' (' + z + ')';
  };
  // Qosha's record was changed after the person approved it: its payload is not what was approved (GPT R2)
  D.changedAfter = function (d) { return !!(d && d.result && d.result.changed_after_approval === true); };
  D.changedText = function (d) {
    return 'This record was changed after you approved it. What you approved: ' + String((d && d.result && d.result.approved_as) || 'not known');
  };
  // a failure whose outcome Qosha may still learn (it may have gone through): keep reading it for a while
  D.mayStillLearn = function (d) {
    var c = d && d.result ? d.result.code : undefined;
    return !!d && d.status === 'failed' && (c === 'uncertain' || c === 'unreachable' || c === '' || c == null);
  };
  D.inMyChrome = function (p) { return !!p && p.engine === 'extension'; };
  // the picture on a website card: where it came from, in plain words (it is an aid; Approve acts on the facts above)
  D.shotNote = function (p) {
    if (!p || typeof p.shot !== 'string' || !p.shot) return '';
    return p.shot_kind === 'photo' ? 'Picture of Qosha\u2019s tab, taken when this card was made.'
      : 'Drawn copy of this part of the page (Chrome gives no picture of a tab in the background). Press Show me to see the real page.';
  };
  D.sendingNote = function (d) {
    if (d && d.kind === 'browser.action' && d.payload && d.payload.action === 'show') return 'Approve opens exactly this address once, in your own browser.';
    if (d && d.kind === 'browser.action' && d.payload && d.payload.action === 'signin') return 'Approve lets Qosha\u2019s own browser read this site signed in as you, for ' + String(d.payload.minutes || 15) + ' minutes. Buttons, forms and payments still wait for your Approve.';
    // MYCHROME (Ren, 9 Nov): a card made in the person's own Chrome (the Qosha extension) says so
    if (d && d.kind === 'browser.action' && D.inMyChrome(d.payload) && d.payload.action === 'open') return 'Approve lets Qosha open and read ' + String(d.payload.site || 'this site') + ' in its own tab in your Chrome, signed in as you, for 15 minutes. Buttons, forms and payments still wait for your Approve.';
    if (d && d.kind === 'browser.action' && D.inMyChrome(d.payload)) return 'Approve does exactly this once, in Qosha\u2019s tab in your Chrome, signed in as you. If the page changed since this card was made, nothing is done.';
    if (d && d.kind === 'browser.action') return 'Approve does exactly this once, in Qosha\u2019s own browser (not your everyday Chrome).';
    if (d && d.kind === 'email.draft_save') return 'Approve saves it in your Gmail drafts (it is not sent).';
    // CAPFIX (owner order): Qosha's own settings and deletes outside Your files, done on this computer on Approve
    if (d && d.kind === 'app.action' && d.payload && d.payload.arguments && d.payload.arguments.source === 'codebox') return 'Approve sends the exact retained request once. Credentials stay private. Its response is saved as a file for Qosha to use.';
    if (d && d.kind === 'settings.change') return 'Approve makes exactly these changes to Qosha\u2019s settings (Qosha rewrites the settings file; comments in it are not kept).';
    if (d && d.kind === 'file.write') return 'Approve saves exactly this text to the file (it is a file that runs, so it waits for you).';
    if (d && d.kind === 'file.delete') return 'Approve moves exactly these to Trash. You decide when to empty Trash.';
    return d && String(d.kind).indexOf('calendar') === 0 ? 'Approve changes your calendar at once, from your Google account.'
      : 'Approve sends it at once from your Google account.';
  };

  // a step on a website (browser.action): what Qosha will do, in one line, from the payload only
  D.browserWhat = function (p) {
    p = p || {};
    var e = p.element && typeof p.element === 'object' ? p.element : {};
    if (p.action === 'click') return 'Click “' + String(e.text || '') + '”';
    if (p.action === 'submit') return 'Submit the form with “' + String(e.text || '') + '”';
    if (p.action === 'open') return 'Open ' + String(p.target_url || '');
    if (p.action === 'show') return 'Open ' + String(p.target_url || '') + ' in your browser';
    if (p.action === 'signin') return 'Read ' + String(p.origin || p.site || '') + ' signed in as you for ' + String(p.minutes || 15) + ' minutes, starting with ' + String(p.target_url || '');
    return String(p.action || '');
  };
  // its facts as [label, plain text] pairs: shown as text only by both pages, never read as HTML
  D.browserFacts = function (p) {
    p = p || {};
    var f = [], e = p.element && typeof p.element === 'object' ? p.element : {};
    var add = function (k, v) { if (v != null && v !== '') f.push([k, String(v)]); };
    var list = function (v) { return Array.isArray(v) ? v.map(function (x) { return String(x); }).filter(function (x) { return x; }) : []; };
    add('Website', p.site);
    add('Page', p.page_title ? String(p.page_title) + (p.page_url ? ' — ' + String(p.page_url) : '') : p.page_url);
    add('What', D.browserWhat(p));
    // MYCHROME review (10 Nov): where it happens, and for a link the whole address it goes to, always on the card
    if (D.inMyChrome(p)) add('Where', 'In your Chrome, signed in as you' + (p.visible === 'front' ? ' (opens in front)' : ''));
    if (p.action === 'click' && e.href) add('Link address', e.href);
    if (p.how === 'link') add('How', 'Qosha\u2019s tab goes to exactly this address. Nothing on the page is pressed.');
    if (p.how === 'send') add('How', 'Qosha sends exactly the data below to the address below. The page\u2019s own code is not used.');
    if (p.how === 'press') add('How', 'Qosha presses this button. The page\u2019s own code decides what is sent, and Qosha cannot show you that.');
    add('Why it waits', p.why);
    if (e.form_action) add('Form sends to', String(e.form_action) + (e.form_method ? ' (' + String(e.form_method).toUpperCase() + ')' : ''));
    (Array.isArray(p.fields) ? p.fields : []).forEach(function (x) {
      if (!x || typeof x !== 'object') return;
      var v = x.value == null ? '' : String(x.value);
      f.push(['Types into “' + String(x.label || ('box ' + (x.ref != null ? x.ref : ''))) + '”', v === '' ? '(empty)' : v]);
    });
    add('Everything the form sends', list(e.form_hidden_fields).join(', '));
    if (p.payment === true) {
      var amounts = list(p.amounts_on_page);
      add('Payment', 'This looks like a checkout or payment. Qosha cannot confirm the amount; amounts on the page: '
        + (amounts.length ? amounts.join('; ') : 'none found'));
    }
    return f;
  };

  // the connector's refusal in plain words (it also sends its own sentence as `plain`)
  var REFUSED = {
    payload_changed: 'Not sent: this changed after it was shown to you. Ask Qosha to put it up again.',
    not_pending: 'Not sent: this was already decided.',
    already_done: 'This approval was already used once; it is never repeated.',
    send_limit: 'Not sent: Qosha’s limit of emails and calendar changes per hour was reached. Try again later.',
    read_only: 'Not sent: Qosha’s Google connection only reads right now.',
    origin: 'Not sent: the approval did not come from this Qosha page.',
    bad_payload: 'Not sent: some of the text can’t be shown safely.',
    event_changed: 'Not changed: the event changed after you saw it. Ask Qosha again.',
    decision_required: 'Not sent: the approval was incomplete. Ask Qosha again.',
    repeating_event: 'Not changed: change a repeating event in Google Calendar itself.',
    needs_reconnect: 'Not sent: your Google connection doesn\u2019t allow this yet. Reconnect Google to allow sending.',
    not_held: 'Not sent: Qosha\u2019s connector has no record of this as it was shown. Ask Qosha again.',
    message_changed: 'Not sent: the email changed after you saw it. Ask Qosha again.',
    draft_changed: 'Not sent: the draft changed after you saw it. Ask Qosha again.',
    too_large: 'Not sent: it is too large to show on the card. Send it from Gmail.',
    not_started: 'Nothing was done: Qosha\u2019s tab in your Chrome isn\u2019t ready. Open Chrome, or press Resume, then press Approve again.'
  };
  // only these answers mean the connector did nothing; anything else (a lost answer, a 5xx) may have gone through
  var NOTHING_DONE = ['payload_changed', 'not_pending', 'send_limit', 'read_only', 'origin', 'bad_payload', 'event_changed', 'decision_required', 'repeating_event',
                      'needs_reconnect', 'not_held', 'message_changed', 'draft_changed', 'too_large', 'not_started'];
  var UNSURE = 'Not confirmed: check Gmail’s Sent folder or your calendar before asking again.';
  D.UNSURE = UNSURE;
  function plainAnswer(answer) {
    var b = (answer && answer.body) || {};
    if (answer && !answer.network && answer.status >= 400 && answer.status < 500 && NOTHING_DONE.indexOf(b.error) >= 0)
      return typeof b.plain === 'string' && b.plain ? b.plain : REFUSED[b.error];
    return UNSURE;   // a network error (also a refused CORS check), a 5xx or an unknown answer: never "nothing was sent"
  }

  function atConnector(d, url, api) {
    var answer = null;
    // the Mac: the connector's own port (another origin, no cookies); the cloud box: this page's own address, where
    // nginx passes the person's Google sign-in to the connector (SENDFIX)
    var same = url.charAt(0) === '/';
    return fetch(url, {method: 'POST', mode: same ? 'same-origin' : 'cors', credentials: same ? 'same-origin' : 'omit', cache: 'no-store',
                       headers: {'Content-Type': 'application/json'},
                       // exactly what the page shows: the connector acts only if the stored record equals it (GPT R1)
                       body: JSON.stringify({ref: d.id, kind: d.kind, payload: d.payload, payload_sha256: d.payload_sha256})})
      .then(function (r) {
        return r.text().then(function (t) {
          var j = null; try { j = t ? JSON.parse(t) : null; } catch (e) { j = null; }
          answer = {ok: r.ok, status: r.status, body: j && typeof j === 'object' ? j : {}};
        });
      }, function () { answer = {ok: false, status: 0, body: {}, network: true}; })
      .then(function () {
        // always: the dashboard records what the connector did (sent, failed, or nothing)
        return api('POST', '/decisions/' + encodeURIComponent(d.id) + '/sync', {}).then(function (r) { return r && r.decision; },
          function () { return null; });
      })
      .then(function (dec) {
        if (dec && D.isFinal(dec.status)) return {decision: dec, answer: answer, plain: ''};
        var b = (answer && answer.body) || {};
        if (answer && answer.ok && b.status === 'done') {
          // the connector did it; the dashboard's record has not caught up (sync failed or still pending): say so anyway
          return {decision: Object.assign({}, d, {status: 'sent', result: b.result || {}}), answer: answer, plain: '', fromConnector: true};
        }
        return {decision: dec, answer: answer, plain: plainAnswer(answer)};
      });
  }

  // 1.20.8 (Ren, 21 Nov, "Keep browser chat"): cards are answered only in the Qosha app window. A browser tab still chats
  // and changes ordinary settings; Approve or Decline there is refused by Qosha, and the page says where to do it.
  D.OPEN_APP = 'Open the Qosha app to approve. Cards can only be answered in the Qosha app window, not in a browser tab.';
  D.appOnly = function (e) {
    return !!e && (e.code === 'qosha_app_window_only' || /^Only the Qosha app window/.test(String(e.detail || e.message || '')));
  };
  var inApp = null;   // null: not known yet (buttons show; Qosha still refuses an answer from a browser tab)
  D.inApp = function () { return inApp; };
  D.checkWindow = function (fn) {
    var token = function () {   // the dashboard's page key, read again on every try (it can arrive late; review W11R2-12)
      var t = '', f = window;
      try {
        for (var i = 0; i < 4 && f; i++) {
          if (typeof f.__HERMES_SESSION_TOKEN__ === 'string') { t = f.__HERMES_SESSION_TOKEN__; break; }
          if (!f.parent || f.parent === f) break;
          f = f.parent;
        }
      } catch (e) { /* no readable parent */ }
      return t;
    };
    var tries = 0, wait = [1000, 2000, 4000, 8000, 15000], finished = false;
    var attempt = function () {
      var t = token(), over = false, timer = null;
      var settle = function (j) {
        if (over || finished) return;
        over = true; if (timer) clearTimeout(timer);
        if (j && typeof j.window === 'boolean') { finished = true; inApp = j.window; if (fn) fn(inApp); return; }
        // a passing error (starting up, a dropped or stalled request): ask again; after the last try the page stops
        // waiting and shows the buttons (Qosha itself still refuses an answer that doesn't come from the app window)
        if (tries < wait.length) { setTimeout(attempt, wait[tries++]); return; }
        finished = true; if (fn) fn(null);
      };
      timer = setTimeout(function () { settle(null); }, 10000);   // a stalled try counts as failed (review W11R2-13)
      fetch('/api/plugins/qosha/approval-gate/window', {credentials: 'same-origin', cache: 'no-store',
                                                        headers: t ? {'X-Hermes-Session-Token': t} : {}})
        .then(function (r) { return r.ok ? r.json() : r.status === 404 ? {window: true} : null; })   // 404: no gate here (a cloud box)
        .then(settle, function () { settle(null); });
    };
    attempt();
  };
  var refusedHere = function (d) {
    return function (e) { if (D.appOnly(e)) return {decision: d, plain: D.OPEN_APP, appOnly: true}; throw e; };
  };

  // approve(d, approveUrl, api): api(method, pathUnderQoshaApi, body) -> Promise(data). Resolves to
  // {decision (the stored record after the step, or null), plain (a sentence when nothing was decided)}.
  D.approve = function (d, approveUrl, api) {
    if (inflight[d.id]) return inflight[d.id];
    var p = (D.viaConnector(d.kind, d.payload) && typeof approveUrl === 'string' && approveUrl)
      ? atConnector(d, approveUrl, api)
      : api('POST', '/decisions/' + encodeURIComponent(d.id) + '/approve', {payload_sha256: d.payload_sha256})
          .then(function (r) { return {decision: r && r.decision, plain: ''}; }, refusedHere(d));
    inflight[d.id] = p;
    var clear = function () { delete inflight[d.id]; };
    p.then(function (out) { clear(); D.announce(out && out.decision ? out.decision : d); }, clear);
    return p;
  };
  D.decline = function (d, api) {
    if (inflight[d.id]) return inflight[d.id];
    var p = api('POST', '/decisions/' + encodeURIComponent(d.id) + '/decline').then(function (r) { return {decision: r && r.decision, plain: ''}; },
      function (e) {
        if (D.appOnly(e)) return {decision: d, plain: D.OPEN_APP, appOnly: true};
        if (e && e.code === 'decline_unconfirmed')   // the connector could not confirm: still waiting, buttons stay
          return {decision: d, plain: e.plain || 'Not declined yet: Qosha could not confirm it. Try again in a moment.'};
        if (!e || e.code !== 'already_approved') throw e;
        // approved meanwhile (here or on another page): say so and show what Qosha has now
        var plain = e.plain || 'Already approved: it is being sent or was sent.';
        return api('GET', '/decisions/' + encodeURIComponent(d.id)).then(function (r) { return {decision: r && r.decision, plain: plain}; },
          function () { return {decision: null, plain: plain}; });
      });
    inflight[d.id] = p;
    var clear = function () { delete inflight[d.id]; };
    p.then(function (out) { clear(); D.announce(out && out.decision ? out.decision : d); }, clear);
    return p;
  };
  D.busy = function (id) { return !!inflight[id]; };
  // Home and Chat show the same decision: each tells the other when it changed (they re-read it from Qosha)
  D.announce = function (d) { try { if (chan && d && d.id) chan.postMessage({id: String(d.id)}); } catch (e) { /* closed */ } };
  D.listen = function (fn) { if (chan) chan.addEventListener('message', function (ev) { if (ev.data && typeof ev.data.id === 'string') fn(ev.data.id); }); };
  window.QoshaDecide = D;
})();
