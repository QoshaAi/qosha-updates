"""Access Qosha can revoke (CONTRACT-ACCESS v2, signed by Ren 20 Nov 2026: "I just want them to loose access
immediately"; "there should be no time limit. We decide when user access is revoked").

- Every install has a Qosha ID (Q-XXXX-XXXX-XXXX-XXXX, 80 random bits) in <home>/qosha/install-id.json, made once
  and never changed. A per-person installer may write it before the first start; it is then kept.
- Qosha's team publishes a signed list of REVOKED IDs (sha256 of "qosha-access-v1:" + ID; no names) at
  <source>/access/access.json (+ .sig), on the same sources and with the same Ed25519 release key as the update list
  (updater.py). An ID that is not listed keeps working: access has no end date.
- The list is read at start, every 2 minutes in the dashboard, and before a chat message when the last check is more
  than 60 seconds old (all within 5 seconds). Its "seq" only goes up: a lower one is refused, so a stale copy never
  undoes a newer revoke or restore.
- Stopped = revoked, or no list accepted for more than an hour (Ren's card: 1 hour). Stopped means: a new chat turn
  ends before any AI request (pre_llm_call block), every tool step is refused (pre_tool_call), messaging-app
  messages are dropped without a reply (pre_gateway_dispatch skip), running turns are stopped as with Stop, and
  Qosha's screens show "Access ended" / "Qosha can't confirm your access". Nothing of the person's is deleted,
  moved, locked or sent. The next accepted list without the ID brings everything back as it was.
- Nothing is sent to Qosha's team: the list is downloaded and compared on this computer.

Standard library only (plus `cryptography`, through updater.verify_signature). The same file runs in the dashboard
(loaded by path) and in every engine process (imported by the plugin); they share state through files under a lock.
"""
from __future__ import annotations

import gc
import hashlib
import importlib.util
import json
import os
import secrets
import sys
import threading
import time
from pathlib import Path

WIN = os.name == "nt"
ID_ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ"          # no 0/O, 1/I/L
ID_PREFIX = "qosha-access-v1:"
LIST_PATH = "access/access.json"
LIST_MAX = 512 * 1024
OFFLINE_S = 60 * 60                  # Ren, 20 Nov 2026 card: "1 hour (Recommended)"
POLL_S = 120                         # background check in the dashboard
FRESH_S = 60                         # before a message: check again when the last check is older than this
BUDGET_S = 5.0                       # a check never takes longer than this (all sources, both files)
WATCH_S = 1                          # every engine process looks at the shared state this often
MESSAGE_MAX = 300

TEXT_REVOKED = ("Your access to Qosha has ended, so Qosha can't answer. Your chats and files are still on this "
                "computer.")
TEXT_UNCONFIRMED = ("Qosha can't confirm your access: it hasn't reached the internet for more than an hour. It comes "
                    "back by itself when the connection returns. Your chats and files are still on this computer.")
TOOL_TEXT = ("Qosha's access on this computer has ended or could not be confirmed, so this step was not run. Stop now: "
             "do not try other steps; reply with one short sentence that Qosha can't continue.")

_lock = threading.Lock()


# --- places ----------------------------------------------------------------------------------------------------------
def home_dir() -> Path:
    """The home of the install this file belongs to (<home>/plugins/qosha/qosha_guard/access.py), whatever process
    loads it (verification #1: Qosha's Gemini tool started by another app must check this install's ID); otherwise
    the engine's home."""
    here = Path(__file__).resolve().parents
    if len(here) > 3 and here[2].name == "plugins" and here[1].name == "qosha":
        return here[3]
    h = os.environ.get("HERMES_HOME")
    if h:
        return Path(h)
    try:
        from hermes_constants import get_hermes_home
        return Path(get_hermes_home())
    except Exception:
        return Path.home() / ".hermes"


def anchor(home: Path) -> Path:
    """The install's main home: a profile's home (<home>/profiles/<name>) shares the install's ID and access state
    (review r1 #1: a second profile must not get a second, unrevoked ID)."""
    h = Path(home)
    try:
        if h.parent.name == "profiles" and ((h.parent.parent / "qosha").is_dir() or (h.parent.parent / "config.yaml").exists()
                                            or (h.parent.parent.parent / "engine").is_dir()):
            return h.parent.parent
    except OSError:
        pass
    return h


def _qdir(home: Path) -> Path:
    d = anchor(home) / "qosha"
    d.mkdir(parents=True, exist_ok=True)
    return d


_LOCAL = {}


def _local() -> bool:
    """The person's own computer. A per-user install (engine/, home/, layer/) always counts, whatever the process's
    environment says (review r1 #2); elsewhere the cloud box and the lab markers decide, as in the rest of the plugin."""
    v = _LOCAL.get("v")
    if v is None:
        try:
            v = bool(_updater().root_dir(anchor(home_dir())))
        except Exception:
            v = False
        if not v:
            v = not os.environ.get("QOSHA_CONNECTOR_URL") and not os.environ.get("QOSHA_BOX") and not os.environ.get("QOSHA_LAB")
        _LOCAL["v"] = v
    return v


_UP = {}


def _updater():
    """updater.py beside this file (signature check, sources, the release key). Loaded by path: this file is loaded by
    path in the dashboard and as a package module in the engine."""
    here = Path(__file__).resolve().parent
    p = here / "updater.py"
    if not p.is_file() and (here / "qosha-updater.py").is_file():
        p = here / "qosha-updater.py"           # the update worker's own copy (<root>/run)
    mod = _UP.get(str(p))
    if mod is None:
        for name, m in list(sys.modules.items()):
            if name in ("qosha_updater", "__main__") or name.endswith("qosha_guard.updater"):
                f = getattr(m, "__file__", None)
                if f and Path(f).resolve() == p:
                    mod = m
                    break
        if mod is None:
            spec = importlib.util.spec_from_file_location("qosha_access_updater", str(p))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
        _UP[str(p)] = mod
    return mod


# --- shared state ----------------------------------------------------------------------------------------------------
class _file_lock:
    """One lock for every Qosha process on this computer (fcntl on Mac, msvcrt on Windows)."""

    def __init__(self, home: Path):
        self.p = _qdir(home) / "access.lock"
        self.f = None

    def __enter__(self):
        self.f = open(self.p, "a+b")
        if WIN:
            import msvcrt
            end = time.monotonic() + 10
            while True:
                try:
                    self.f.seek(0)
                    msvcrt.locking(self.f.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    if time.monotonic() > end:
                        self.f.close()
                        raise
                    time.sleep(0.05)
        else:
            import fcntl
            fcntl.flock(self.f.fileno(), fcntl.LOCK_EX)
        return self

    def __exit__(self, *exc):
        try:
            if WIN:
                import msvcrt
                self.f.seek(0)
                msvcrt.locking(self.f.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.f.fileno(), fcntl.LOCK_UN)
        finally:
            self.f.close()
        return False


class Unreadable(OSError):
    """A shared file exists but could not be read for a while (Windows: another process had it open)."""


def _write_json(p: Path, data) -> None:
    """Atomic replace; on Windows a reader holding the file makes the replace fail for a moment, so it is tried again
    for up to 2 seconds (review r1, Gemini #2)."""
    tmp = p.with_name(".%s.%d.%d.tmp" % (p.name, os.getpid(), threading.get_ident()))
    tmp.write_text(json.dumps(data, indent=1, sort_keys=True), encoding="utf-8")
    end = time.monotonic() + 2.0
    while True:
        try:
            os.replace(tmp, p)
            return
        except PermissionError:
            if time.monotonic() > end:
                try:
                    tmp.unlink()
                except OSError:
                    pass
                raise
            time.sleep(0.05)


def _read_raw(p: Path):
    """The file's text; None when it does not exist. A file held open by a writer (Windows) is read again for up to
    1 second, then Unreadable is raised (never taken as "broken")."""
    end = time.monotonic() + 1.0
    while True:
        try:
            return p.read_bytes().decode("utf-8", errors="replace")   # bad bytes = unreadable JSON = corrupt
        except FileNotFoundError:
            return None
        except PermissionError:
            if time.monotonic() > end:
                raise Unreadable(str(p))
            time.sleep(0.05)


def _read_json(p: Path):
    try:
        t = _read_raw(p)
    except Unreadable:
        return None
    try:
        d = json.loads(t) if t is not None else None
        return d if isinstance(d, dict) else None
    except ValueError:
        return None


# --- the Qosha ID ----------------------------------------------------------------------------------------------------
def _new_id() -> str:
    raw = "".join(secrets.choice(ID_ALPHABET) for _ in range(16))
    return "Q-" + "-".join(raw[i:i + 4] for i in range(0, 16, 4))


def valid_id(v) -> bool:
    if not isinstance(v, str) or len(v) != 21 or not v.startswith("Q-"):
        return False
    parts = v[2:].split("-")
    return len(parts) == 4 and all(len(p) == 4 and all(c in ID_ALPHABET for c in p) for p in parts)


def id_hash(qid: str) -> str:
    return hashlib.sha256((ID_PREFIX + qid).encode("ascii")).hexdigest()


def install_id(home: Path | None = None) -> str:
    """This install's Qosha ID; made once, under the lock (two processes starting together get the same one)."""
    h = home or home_dir()
    p = _qdir(h) / "install-id.json"

    def read():
        t = _read_raw(p)                # Unreadable propagates: an ID that exists is never replaced because a
        try:                            # reader could not open it for a moment
            d = json.loads(t) if t is not None else None
        except ValueError:
            d = None
        return d["id"] if isinstance(d, dict) and valid_id(d.get("id")) else None
    qid = read()
    if qid:
        return qid
    with _file_lock(h):
        qid = read()
        if qid:
            return qid
        qid = _new_id()
        _write_json(p, {"id": qid, "created": int(time.time())})
        return qid


# --- state -----------------------------------------------------------------------------------------------------------
def _state_file(home: Path) -> Path:
    return _qdir(home) / "access-state.json"


def _floor_file(home: Path) -> Path:
    return _qdir(home) / "access-floor.json"


def floor(home: Path) -> dict:
    """The highest list accepted here and its sha256, kept apart from the state (review r1 #10): a lost or broken
    state file never lowers it."""
    def strict(p):                      # a file held by another process is an error here, never "seq 0" (review r2)
        t = _read_raw(p)
        try:
            d = json.loads(t) if t is not None else {}
        except ValueError:
            d = {}
        return d if isinstance(d, dict) else {}
    s = strict(_state_file(home))
    f = strict(_floor_file(home))
    cand = [x for x in (s, f) if isinstance(x.get("seq"), int)]
    best = max(cand, key=lambda x: x["seq"]) if cand else {}
    return {"seq": int(best.get("seq") or 0), "sha": best.get("sha") if isinstance(best.get("sha"), str) else None}


def load_state(home: Path | None = None) -> dict:
    """The shared state; {} when there is none yet. A state file that exists but can't be read counts as never
    confirmed (fail closed until the next accepted list), never as a fresh start."""
    p = _state_file(home or home_dir())
    t = _read_raw(p)                    # Unreadable propagates: the callers fail closed for that one call only
    if t is None:
        return {}
    try:
        d = json.loads(t)
        if isinstance(d, dict):
            return d
    except ValueError:
        pass
    return {"state": "active", "seq": 0, "confirmed_at": 0, "checked_at": 0, "message": None, "broken": True}


def _first_state(home: Path, now: float) -> dict:
    """No state yet (a new install, or the update that brings this): the hour counts from when this install's ID was
    made, so deleting the state file never starts a new hour."""
    made = (_read_json(_qdir(home) / "install-id.json") or {}).get("created")
    start = int(made) if isinstance(made, (int, float)) and 0 < made <= now else int(now)
    s = {"state": "active", "seq": 0, "confirmed_at": start, "checked_at": 0, "message": None}
    _write_json(_state_file(home), s)
    return s


CLOCK_SLACK_S = 120


def _mark_expired(h: Path, confirmed_at=None) -> None:
    try:
        with _file_lock(h):
            s = load_state(h)
            # only the confirmation that expired: a check that confirmed meanwhile is never undone (verification #4)
            if s and not s.get("expired") and s.get("confirmed_at") == confirmed_at:
                s["expired"] = True
                _write_json(_state_file(h), s)
    except Exception:
        pass


def effective(s: dict, now: float | None = None, expired_mark=None) -> str:
    """'active', 'revoked' or 'unconfirmed' (no list accepted for more than OFFLINE_S, or the clock now reads earlier
    than the last confirmation: review r1 #9)."""
    now = time.time() if now is None else now
    if s.get("state") == "revoked":
        return "revoked"
    if s.get("state") != "active" or s.get("broken") or s.get("expired"):   # unknown or damaged = fail closed
        return "unconfirmed"            # "expired": the hour passed once; only an accepted list clears it (review r2 #4)
    c = s.get("confirmed_at")
    if not isinstance(c, (int, float)) or now - c > OFFLINE_S or now < c - CLOCK_SLACK_S:
        if expired_mark is not None and isinstance(c, (int, float)) and now - c > OFFLINE_S:
            expired_mark()
        return "unconfirmed"
    return "active"


def status(home: Path | None = None, now: float | None = None) -> dict:
    h = home or home_dir()
    now = time.time() if now is None else now
    if not _local():
        # a cloud box or the lab: managed elsewhere; nothing is created here and no screen is covered (Gemini r1 #6)
        return {"state": "active", "stopped": False, "local": False, "id": None, "seq": 0, "confirmed_at": None,
                "checked_at": None, "message": None, "offline_limit_s": OFFLINE_S}
    qid = install_id(h)
    s = load_state(h)
    if not s:
        with _file_lock(h):
            s = load_state(h)
            if not s:
                s = (dict(_first_state(h, now), broken=True) if floor(h)["seq"] > 0 else _first_state(h, now))
    if not s.get("broken") and int(s.get("seq") or 0) < floor(h)["seq"]:
        s = dict(s, broken=True)        # the floor moved on but this state did not: fail closed (review r2 #5)
    st = effective(s, now, expired_mark=lambda: _mark_expired(h, s.get("confirmed_at")))
    return {"state": st, "stopped": st != "active", "local": True, "id": qid, "seq": s.get("seq", 0),
            "confirmed_at": s.get("confirmed_at"), "checked_at": s.get("checked_at"),
            "message": s.get("message") if st == "revoked" else None, "offline_limit_s": OFFLINE_S}


def stopped(home: Path | None = None, now: float | None = None) -> bool:
    if not _local():
        return False
    try:
        return status(home, now)["stopped"]
    except Exception:
        return True                     # the state can't be read: fail closed (the next check writes it again)


# --- reading the list ------------------------------------------------------------------------------------------------
def valid_list(d) -> bool:
    """The list's shape (explicit checks, never assert: they vanish under python -O)."""
    if not (isinstance(d, dict) and d.get("schema") == 1 and d.get("product") == "qosha" and d.get("kind") == "access"):
        return False
    seq = d.get("seq")
    if not isinstance(seq, int) or isinstance(seq, bool) or seq < 1 or not isinstance(d.get("revoked"), list):
        return False
    for r in d["revoked"]:
        if not isinstance(r, dict) or not isinstance(r.get("id_hash"), str) or len(r["id_hash"]) != 64:
            return False
        if any(c not in "0123456789abcdef" for c in r["id_hash"]):
            return False
        m = r.get("message")
        if not (m is None or (isinstance(m, str) and len(m) <= MESSAGE_MAX)):
            return False
    return True


def read_list(base: str, deadline: float) -> dict:
    """One source's signed list; raises on anything unacceptable (down, unsigned, wrong key, bad JSON)."""
    up = _updater()
    base = base.rstrip("/")

    def left():
        t = deadline - time.monotonic()
        if t <= 0:
            raise TimeoutError("no time left")
        return t
    data = up._get("%s/%s" % (base, LIST_PATH), LIST_MAX, timeout=left())
    sig = up._get("%s/%s.sig" % (base, LIST_PATH), 4096, timeout=left())
    up.verify_signature(data, sig)
    d = json.loads(data.decode("utf-8"))
    if not valid_list(d):
        raise ValueError("not a Qosha access list")
    d["_sha"] = hashlib.sha256(data).hexdigest()
    return d


def sources(home: Path) -> list:
    cfg = _updater().load_config(anchor(home))       # the install's sources, also for a profile (review r2 #3)
    return [b for b in (cfg.get("primary"), cfg.get("fallback")) if b]


def check(home: Path | None = None, now: float | None = None, budget: float = BUDGET_S, fetch=None) -> dict:
    if not _local():
        return dict(status(home, now), result="not_local")      # a cloud box or the lab: nothing fetched or written
    """Reads the list from every source (within `budget` seconds in all), takes the highest seq, and records the
    result. Returns status() plus "result": 'accepted', 'older' (a stale copy; refused) or 'unreachable'."""
    h = home or home_dir()
    now = time.time() if now is None else now
    deadline = time.monotonic() + budget
    fetch = fetch or read_list
    # every source at the same time, each in its own thread, all within ONE wall-clock deadline: a slow first source
    # never uses up the time of the second, and a slow answer is abandoned at the deadline (review r1 #8)
    got = {}

    def one(i, base):
        try:
            d = fetch(base, deadline)
            if not valid_list(d):
                raise ValueError("not a Qosha access list")
            got[i] = d
        except Exception as e:
            got[i] = e
    threads = []
    for i, base in enumerate(sources(h)):
        t = threading.Thread(target=one, args=(i, base), daemon=True)
        t.start()
        threads.append(t)
    for t in threads:
        t.join(max(0.0, deadline - time.monotonic()))
    best, tried, okd = None, [], []
    for i in range(len(threads)):
        d = got.get(i)
        if isinstance(d, dict):
            tried.append("ok")
            okd.append(d)
        else:
            tried.append(type(d).__name__ if d is not None else "timeout")
    if okd:
        top = max(d["seq"] for d in okd)
        at_top = [d for d in okd if d["seq"] == top]
        try:
            fsha = floor(h)["sha"]
        except Exception:
            fsha = None
        # mirrors that disagree at the same number: the copy this computer already accepted wins (review r2 #8)
        best = next((d for d in at_top if fsha and d.get("_sha") == fsha), at_top[0])
    hid = id_hash(install_id(h))
    with _file_lock(h):
        fl = floor(h)
        s = load_state(h) or _first_state(h, now)
        s["checked_at"] = int(now)
        if best is None:
            result = "unreachable"
        elif best["seq"] < fl["seq"]:
            result = "older"            # a stale copy: refused, and not a confirmation either
        elif best["seq"] == fl["seq"] and fl["sha"] and best.get("_sha") and best["_sha"] != fl["sha"]:
            result = "conflict"         # a different list with the same number: refused (review r1 #19)
        else:
            result = "accepted"
            hit = next((r for r in best["revoked"] if r["id_hash"] == hid), None)
            s["state"] = "revoked" if hit else "active"
            s["message"] = (hit.get("message") or None) if hit else None
            s["seq"] = best["seq"]
            s["sha"] = best.get("_sha")
            s["confirmed_at"] = int(now)
            s.pop("broken", None)
            s.pop("expired", None)
            _write_json(_floor_file(h), {"seq": s["seq"], "sha": s["sha"]})
        s["last_result"] = result
        _write_json(_state_file(h), s)
    _log(h, "access check: %s (%s); now %s" % (result, ",".join(tried) or "no source", effective(s, now)))
    out = status(h, now)
    out["result"] = result
    return out


def ensure_fresh(home: Path | None = None, now: float | None = None) -> dict:
    """Before a chat message: checks again when the last check is older than FRESH_S."""
    h = home or home_dir()
    now = time.time() if now is None else now
    s = load_state(h)
    ok_at = s.get("confirmed_at") if isinstance(s.get("confirmed_at"), (int, float)) else 0   # last SUCCESSFUL check
    last = s.get("checked_at") if isinstance(s.get("checked_at"), (int, float)) else 0
    if not s or now - ok_at > FRESH_S or last > now + CLOCK_SLACK_S or ok_at > now + CLOCK_SLACK_S:
        try:
            return check(h, now)
        except Exception:
            pass
    return status(h, now)


def _log(home: Path, msg: str) -> None:
    try:
        root = home.resolve().parent
        if (root / "logs").is_dir():
            with open(root / "logs" / "access.log", "a", encoding="utf-8") as f:
                f.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))
    except OSError:
        pass


def text_for(st: dict) -> str:
    return TEXT_REVOKED if st.get("state") == "revoked" else TEXT_UNCONFIRMED


# --- the engine's hooks (every engine process) -----------------------------------------------------------------------
def pre_llm_call(**_kw):
    """A new chat turn: checks the list when the last check is older than a minute; stopped -> the engine's own block
    (the turn ends before any AI request)."""
    if not _local():
        return None
    try:
        st = ensure_fresh()
    except Exception:
        st = {"stopped": True, "state": "unconfirmed"}
    if st.get("stopped"):
        return {"action": "block", "message": text_for(st)}
    return None


def pre_tool_call(tool_name=None, args=None, **_kw):
    """Every tool step: refused while stopped (from the shared state; no network here). The turn it belongs to is
    stopped too."""
    if not _local():
        return None
    try:
        st = status()
    except Exception:
        st = {"stopped": True, "state": "unconfirmed"}
    if st.get("stopped"):
        threading.Thread(target=stop_running, args=(st,), daemon=True).start()
        return {"action": "block", "message": TOOL_TEXT}
    return None


def admit_stopped(home: Path | None = None) -> bool:
    """For every entry that starts a new answer outside an engine turn (Ask Gemini, the council, a messaging-app
    message): the same freshness check as a chat turn (review r1 #4). Fails closed."""
    if not _local():
        return False
    try:
        return bool(ensure_fresh(home)["stopped"])
    except Exception:
        return True


def pre_gateway_dispatch(**_kw):
    """Messaging apps: while stopped a message is dropped with no reply (nothing goes out to other people)."""
    if admit_stopped():
        return {"action": "skip", "reason": "qosha-access"}
    return None


def transform_llm_output(response_text=None, **_kw):
    """The final reply of a turn that was running when access stopped: replaced by the plain line."""
    if not _local():
        return None
    try:
        st = status()
    except Exception:
        st = {"stopped": True, "state": "unconfirmed"}     # fail closed, like the other hooks
    return text_for(st) if st.get("stopped") else None


def stop_running(st: dict) -> int:
    """Stops every turn running in this process, the same as the Stop button (the agent's own hard_interrupt). Only
    agents with a turn in progress (an execution thread) are touched. Returns how many."""
    n = 0
    try:
        agents = [o for o in gc.get_objects() if type(o).__name__ == "AIAgent"]
    except Exception:
        agents = []
    for obj in agents:
        try:
            if getattr(obj, "_execution_thread_id", None) is None:
                continue
            hi = getattr(type(obj), "hard_interrupt", None)
            if callable(hi):
                hi(obj, text_for(st))
                n += 1
        except Exception:
            continue
    if n:
        _log(home_dir(), "stopped %d running turn(s): access %s" % (n, st.get("state")))
    return n


ENGINE_STALE_S = 150          # no accepted check for this long: no dashboard poller is running, an engine process checks


def engine_tick(now: float | None = None) -> None:
    """In an engine process (terminal, gateway): when the last check is older than ENGINE_STALE_S (the dashboard's
    2-minute poll is not running), this process reads the list itself (final-pass review #7)."""
    h = home_dir()
    now = time.time() if now is None else now
    s = load_state(h)
    last = max([x for x in (s.get("checked_at"), s.get("confirmed_at")) if isinstance(x, (int, float))] or [0])
    if not s or now - last > ENGINE_STALE_S or last > now + CLOCK_SLACK_S:
        check(h, now)


def _watch():
    """In every engine process: within WATCH_S of the state turning to stopped, running turns are stopped."""
    last = None
    n = 0
    while True:
        time.sleep(WATCH_S)
        n += 1
        if n % 15 == 0:                 # every 15 s: fetch the list here if nobody else did lately
            try:
                engine_tick()
            except Exception:
                pass
        try:
            st = status()
            key = (st["state"], st.get("seq"), st.get("confirmed_at")) if st["stopped"] else None
            if key and key != last:
                stop_running(st)
            last = key
        except Exception:
            pass


_bg = {"watch": False, "poll": False}


def start_watch() -> None:
    if _bg["watch"] or not _local():
        return
    _bg["watch"] = True
    threading.Thread(target=_watch, daemon=True, name="qosha-access-watch").start()


def register(ctx) -> None:
    """From the plugin's register(), FIRST (before every other Qosha hook): its block wins over anything else."""
    ctx.register_hook("pre_llm_call", pre_llm_call)
    ctx.register_hook("pre_tool_call", pre_tool_call)
    for name, fn in (("pre_gateway_dispatch", pre_gateway_dispatch), ("transform_llm_output", transform_llm_output)):
        try:
            ctx.register_hook(name, fn)
        except Exception:
            pass
    start_watch()
    if _local():          # a cloud box or the lab gets no ID file
        try:
            install_id()
        except Exception:
            pass          # status() then fails, and every hook above fails closed


# --- the dashboard ---------------------------------------------------------------------------------------------------
def _poll():
    h = home_dir()
    while True:
        try:
            check(h)
        except Exception as e:
            _log(h, "access check failed: %s" % type(e).__name__)
        time.sleep(POLL_S)


def start_poll() -> None:
    if _bg["poll"] or not _local():
        return
    _bg["poll"] = True
    threading.Thread(target=_poll, daemon=True, name="qosha-access-poll").start()


def _root(home: Path):
    try:
        return _updater().root_dir(home)
    except Exception:
        return None


# sign-in and key files are never exported (review r1 #17: names Qosha and the engine use, and anything shaped like them)
import re as _re
SECRET_RE = _re.compile(r"(auth|oauth|token|secret|credential|cookie|password|passwd|apikey|api[-_ ]?key|\bkeys?\b|netrc|\.ssh|\.env$|^\.env|\.pem$|\.key$|\.p12$|"
                        r"\.pfx$|id_rsa|id_ed|id_ecdsa)",
                        _re.I)


def _safe_copy(src_root: Path, rel: Path, dest_root: Path) -> bool:
    """Copies one regular file that really lies inside src_root (no link anywhere on its path). False when skipped."""
    src = src_root / rel
    p = src_root
    for part in rel.parts:
        p = p / part
        if p.is_symlink():
            return False
    try:
        real_root = src_root.resolve(strict=True)
        real = src.resolve(strict=True)
        real.relative_to(real_root)
    except (OSError, ValueError):
        return False
    if not real.is_file() or any(SECRET_RE.search(part) for part in rel.parts) or rel.suffix.lower() not in (".md", ".txt"):
        return False                    # memory notes only (review r2 #17): never keys, certificates or sign-in files
    out = dest_root / rel
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(real, "rb") as fi, open(out, "wb") as fo:
        while True:
            b = fi.read(1 << 20)
            if not b:
                break
            fo.write(b)
    return True


def _request_home() -> Path:
    """The home of the profile this request or process is serving (the engine scopes get_hermes_home per request);
    the plugin's own install home otherwise. Export uses it (final-pass review #1); the ID and access state don't."""
    try:
        import hermes_constants
        return Path(hermes_constants.get_hermes_home())
    except Exception:
        return home_dir()


def export_chats(home: Path | None = None, dest_parent: Path | None = None, run=None) -> dict:
    """Every chat as Markdown (the engine's own `sessions export --format md`), plus memories and SOUL.md, into
    Downloads/Qosha export <date>. Only regular files inside the person's own folders are copied (no link is followed)
    and no sign-in or key file. Works offline. "ok" is true only when every part was saved."""
    import subprocess
    h = home or _request_home()
    parent = dest_parent or (Path.home() / "Downloads")
    parent.mkdir(parents=True, exist_ok=True)
    base = parent / ("Qosha export " + time.strftime("%Y-%m-%d %H.%M"))
    dest, i = base, 2
    while dest.exists():
        dest = Path("%s (%d)" % (base, i))
        i += 1
    (dest / "Chats").mkdir(parents=True)
    root = _root(h)
    py = sys.executable
    if root:
        try:
            py = _updater()._env_python(root)
        except Exception:
            pass
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("PYTHON", "PIP_"))}
    env["HERMES_HOME"] = str(h)
    cmd = [py, "-m", "hermes_cli.main", "sessions", "export", str(dest / "Chats"), "--format", "md"]
    if run is None:
        def run(c):
            return subprocess.run(c, env=env, capture_output=True, text=True, timeout=600, stdin=subprocess.DEVNULL,
                                  creationflags=(0x08000000 if WIN else 0))
    failed = []
    try:
        r = run(cmd)
        if getattr(r, "returncode", 1) != 0:
            failed.append("chats")
    except Exception:
        failed.append("chats")
    copied = []
    mem = h / "memories"
    if mem.is_dir() and not mem.is_symlink():
        n_ok = 0
        try:
            for dirpath, dirnames, filenames in os.walk(mem, followlinks=False):
                dirnames[:] = [d for d in dirnames if not (Path(dirpath) / d).is_symlink()]
                for fn in filenames:
                    rel = (Path(dirpath) / fn).relative_to(h)
                    try:
                        n_ok += 1 if _safe_copy(h, rel, dest) else 0
                    except OSError:
                        failed.append(str(rel))
            copied.append("memories")
        except OSError:
            failed.append("memories")
    if (h / "SOUL.md").exists():
        try:
            if _safe_copy(h, Path("SOUL.md"), dest):
                copied.append("SOUL.md")
        except OSError:
            failed.append("SOUL.md")
    n = sum(1 for _ in (dest / "Chats").rglob("*.md"))
    _log(h, "export: %d chat file(s), %s%s -> %s" % (n, ",".join(copied) or "nothing else",
                                                    ("; not saved: " + ",".join(failed)) if failed else "", dest.name))
    return {"ok": not failed, "folder": str(dest), "chats": n, "also": copied, "failed": failed}


def open_folder(home: Path | None = None, run=None) -> dict:
    import subprocess
    h = home or home_dir()
    target = str(_root(h) or h)
    cmd = ["explorer", target] if WIN else ["/usr/bin/open", target]
    (run or (lambda c: subprocess.Popen(c)))(cmd)
    return {"ok": True, "folder": target}


try:
    from fastapi import APIRouter
    from fastapi.responses import JSONResponse as _JR

    router = APIRouter()

    def _ok(d, code=200):
        return _JR(status_code=code, content=d, headers={"Cache-Control": "no-store"})

    @router.get("/status")
    def _r_status():
        return _ok(status())

    @router.post("/check")
    def _r_check():
        return _ok(check())

    @router.post("/export")
    def _r_export():
        if not _local():
            return _ok({"ok": False, "error": "not_local"}, 404)
        try:
            return _ok(export_chats())
        except Exception as e:
            return _ok({"ok": False, "error": type(e).__name__}, 500)

    @router.post("/open-folder")
    def _r_open():
        if not _local():
            return _ok({"ok": False, "error": "not_local"}, 404)
        return _ok(open_folder())
except Exception:          # imported outside the dashboard (the engine processes)
    router = None


def mount(parent_router) -> None:
    """Called once by the dashboard: the routes, the ID, the 2-minute check (its first pass at once), the watcher."""
    if router is not None:
        parent_router.include_router(router, prefix="/access")
    if _local():
        start_poll()                    # the poll and the watcher start even if the ID file is held for a moment
        start_watch()
        try:
            install_id()
        except Exception:
            pass


def main(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="Qosha access")
    ap.add_argument("action", choices=["id", "status", "check"])
    a = ap.parse_args(argv)
    if a.action == "id":
        print(install_id())
    elif a.action == "status":
        print(json.dumps(status(), indent=1))
    else:
        print(json.dumps(check(), indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
